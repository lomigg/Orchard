package y;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_2616;
import net.minecraft.class_2663;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_742;
import net.minecraft.class_8143;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import x.IIIIlllll;
import x.IlIl;
import x.lIllIIl;
import x.lllIIlII;

@Environment(EnvType.CLIENT)
@Mixin({class_634.class})
public abstract class lllIIIII {
   @Inject(
      method = {"method_11148"},
      at = {@At("TAIL")}
   )
   private void I(class_2663 var1, CallbackInfo var2) {
      lIllIIl var3 = lIllIIl.Il();
      if (var3 != null) {
         class_310 var4 = class_310.method_1551();
         if (var4.field_1687 != null) {
            class_1297 var5 = var1.method_11469(var4.field_1687);
            if (var5 != null && var3.IIl() != null) {
               var3.IIl().lIIll(var5, var1.method_11470());
            }

            if (var1.method_11470() == 35) {
               if (var4.field_1724 != null && var5 != null && var5.method_5628() == var4.field_1724.method_5628()) {
                  IlIl var6 = var3.IIl().IlIlII();
                  if (var6 != null) {
                     var6.lIll();
                  }
               }

               lllIIlII var8 = var3.IIl().IlIl();
               if (var8 != null && var8.IIIIIlI() && var5 instanceof class_742) {
                  class_742 var7 = (class_742)var5;
                  var8.ll(var7);
               }

            }
         }
      }
   }

   @Inject(
      method = {"method_49034"},
      at = {@At("TAIL")}
   )
   private void l(class_8143 var1, CallbackInfo var2) {
      lIllIIl var3 = lIllIIl.Il();
      if (var3 != null && var3.IIl() != null) {
         class_310 var4 = class_310.method_1551();
         if (var4.field_1724 != null && var4.field_1687 != null && var1.comp_1267() == var4.field_1724.method_5628()) {
            IIIIlllll var5 = var3.IIl().IIIII();
            if (var5 != null && var5.IIIIIlI()) {
               var5.lll(var1.method_49071(var4.field_1687));
            }

         }
      }
   }

   @Inject(
      method = {"method_45729"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void II(String var1, CallbackInfo var2) {
      lIllIIl var3 = lIllIIl.Il();
      if (var3 != null && var3.IIl() != null && var3.IIl().lIlII(var1)) {
         var2.cancel();
      }

   }

   @Inject(
      method = {"method_11160"},
      at = {@At("HEAD")}
   )
   private void Il(class_2616 var1, CallbackInfo var2) {
      lIllIIl var3 = lIllIIl.Il();
      if (var3 != null && var3.IIl() != null) {
         class_310 var4 = class_310.method_1551();
         if (var4.field_1687 != null) {
            class_1297 var5 = var4.field_1687.method_8469(var1.method_11269());
            if (var5 != null) {
               var3.IIl().lII(var5, var1.method_11267());
            }

         }
      }
   }
}
