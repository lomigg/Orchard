package y;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import x.IlIIlIlll;
import x.lIllIIl;

@Environment(EnvType.CLIENT)
@Mixin({class_1309.class})
public abstract class lIIllIIl {
   @Inject(
      method = {"method_6028"},
      at = {@At("RETURN")},
      cancellable = true,
      require = 0
   )
   private void I(CallbackInfoReturnable<Integer> var1) {
      class_310 var2 = class_310.method_1551();
      if (var2 != null && var2.field_1724 == this) {
         lIllIIl var3 = lIllIIl.Il();
         if (var3 != null) {
            IlIIlIlll var4 = var3.IIl().IlIllI();
            if (var4 != null && var4.IlII()) {
               var1.setReturnValue(var4.IIlII((Integer)var1.getReturnValue()));
            }

         }
      }
   }
}
