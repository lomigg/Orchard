package y;

import io.netty.channel.ChannelFutureListener;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import x.IIlIIlll;

@Environment(EnvType.CLIENT)
@Mixin({class_2535.class})
public abstract class IllIIlI {
   @ModifyVariable(
      method = {"method_52906(Lnet/minecraft/class_2596;Lio/netty/channel/ChannelFutureListener;Z)V"},
      at = @At("HEAD"),
      argsOnly = true
   )
   private class_2596<?> I(class_2596<?> var1) {
      return IIlIIlll.IllI(var1);
   }

   @Inject(
      method = {"method_52906(Lnet/minecraft/class_2596;Lio/netty/channel/ChannelFutureListener;Z)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void l(class_2596<?> var1, ChannelFutureListener var2, boolean var3, CallbackInfo var4) {
      if (IIlIIlll.I(var1)) {
         var4.cancel();
      }

   }
}
