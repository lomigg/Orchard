package y;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10185;
import net.minecraft.class_243;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_744;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import x.III;
import x.IIIIIIlIl;
import x.IIIIlIIl;
import x.IIIIlllll;
import x.IIlIll;
import x.IlIl;
import x.IlIlIl;
import x.IllllIlI;
import x.lIIIllI;
import x.lIIIllIl;
import x.lIIlIlIl;
import x.lIlIllII;
import x.lIlIllll;
import x.lIllIIl;
import x.lIlllllI;
import x.llIlIII;
import x.lllI;

@Environment(EnvType.CLIENT)
@Mixin({class_746.class})
public abstract class IIlIIIlII {
   @Unique
   private boolean I;
   @Unique
   private boolean l;
   @Unique
   private boolean II;
   @Unique
   private boolean Il;
   @Unique
   private boolean lI;
   @Unique
   private boolean ll;
   @Unique
   private boolean III;
   @Unique
   private boolean IIl;
   @Unique
   private boolean IlI;
   @Unique
   private boolean Ill;
   @Unique
   private boolean lII;
   @Unique
   private boolean lIl;
   @Unique
   private boolean llI;
   @Unique
   private boolean lll;
   @Unique
   private float IIII;
   @Unique
   private boolean IIIl;
   @Unique
   private boolean IIlI;
   @Unique
   private boolean IIll;
   @Unique
   private boolean IlII;
   @Unique
   private float IlIl;
   @Shadow
   public class_744 field_3913;
   @Unique
   private boolean IllI;
   @Unique
   private boolean Illl;
   @Unique
   private boolean lIII;

   @Unique
   private void I(class_310 var1, float var2) {
      float var3 = ((class_746)this).method_36454();
      <undefinedtype> var4 = lIlllllI.I(this.IIll, this.IlI, this.Il, this.III, var3 + var2, var3);
      if (var4.I() != 0.0F || var4.l() != 0.0F) {
         this.lI(var1, var4.I(), var4.l());
      }
   }

   private void l(class_310 var1, double var2) {
      if (var1 != null && var1.field_1690 != null && !(var2 >= 0.999)) {
         float var4 = (this.IIll ? 1.0F : 0.0F) - (this.IlI ? 1.0F : 0.0F);
         float var5 = (this.Il ? 1.0F : 0.0F) - (this.III ? 1.0F : 0.0F);
         float var6 = class_3532.method_15355(var4 * var4 + var5 * var5);
         if (!(var6 <= 1.0E-4F)) {
            if (var6 > 1.0F) {
               var4 /= var6;
               var5 /= var6;
            }

            float var7 = (float)var2;
            this.IIII = var4 * var7;
            this.IlIl = var5 * var7;
            this.llI = true;
         }
      }
   }

   @Unique
   private void II(class_310 var1) {
      if (var1 != null && var1.field_1690 != null) {
         lIllIIl var2 = lIllIIl.Il();
         this.IlII(var2, var1, var1.field_1690.field_1894);
         this.IlII(var2, var1, var1.field_1690.field_1881);
         this.IlII(var2, var1, var1.field_1690.field_1913);
         this.IlII(var2, var1, var1.field_1690.field_1849);
         this.IlII(var2, var1, var1.field_1690.field_1867);
         this.IlII(var2, var1, var1.field_1690.field_1832);
         this.IlII(var2, var1, var1.field_1690.field_1903);
      }
   }

   @Inject(
      method = {"method_6007"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/class_1156;method_4909(Lnet/minecraft/class_744;)V"
)},
      require = 0
   )
   private void Il(CallbackInfo var1) {
      class_310 var2 = class_310.method_1551();
      if (var2.field_1690 != null) {
         boolean var10000;
         label21: {
            class_437 var5 = var2.field_1755;
            if (var5 instanceof lIIIllIl) {
               lIIIllIl var4 = (lIIIllIl)var5;
               if (var4.IllIlIl()) {
                  var10000 = true;
                  break label21;
               }
            }

            var10000 = false;
         }

         boolean var3 = var10000;
         if (var2.field_1755 != null && !var3) {
            this.lIl(var2);
         } else {
            this.IIII(var2);
         }
      }
   }

   @Unique
   private void lI(class_310 var1, float var2, float var3) {
      if (var1 != null && var1.field_1690 != null) {
         this.IIII = var2;
         this.IlIl = var3;
         this.llI = true;
         var1.field_1690.field_1894.method_23481(var2 > 0.0F);
         this.Ill = true;
         var1.field_1690.field_1881.method_23481(var2 < 0.0F);
         this.Illl = true;
         var1.field_1690.field_1913.method_23481(var3 > 0.0F);
         this.IIl = true;
         var1.field_1690.field_1849.method_23481(var3 < 0.0F);
         this.lI = true;
         this.lll = true;
      }
   }

   @Unique
   private void ll(class_310 var1, class_304 var2) {
      if (var2 != null) {
         boolean var3 = this.IlIl(var1, var2);
         var2.method_23481(var3);
         class_3675.class_306 var4 = IllllIlI.IIIlIIl(var2);
         if (!IllllIlI.IllllI(var4)) {
            class_304.method_1416(var4, var3);
         }

      }
   }

   @Unique
   private void III(class_310 var1) {
      if (var1 != null && var1.field_1690 != null) {
         this.IIll = this.IlIl(var1, var1.field_1690.field_1894);
         this.IlI = this.IlIl(var1, var1.field_1690.field_1881);
         this.Il = this.IlIl(var1, var1.field_1690.field_1913);
         this.III = this.IlIl(var1, var1.field_1690.field_1849);
      }
   }

   @Inject(
      method = {"method_6007"},
      at = {@At("TAIL")},
      require = 0
   )
   private void IIl(CallbackInfo var1) {
      class_310 var2 = class_310.method_1551();
      IlIlIl.IIll(var2);
   }

   @Inject(
      method = {"method_5773"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/class_746;method_3136()V",
   shift = Shift.AFTER
)},
      require = 0
   )
   private void IlI(CallbackInfo var1) {
      class_310 var2 = class_310.method_1551();
      IllllIlI.IIIIIlI();
      IlIlIl.IIlII(var2);
      lIlIllll.llIl(var2);
      lIllIIl var3 = lIllIIl.Il();
      if (var3 != null) {
         var3.IIl().llIlIl(var2);
      }
   }

   @Inject(
      method = {"method_6007"},
      at = {@At("HEAD")},
      require = 0
   )
   private void Ill(CallbackInfo var1) {
      lIllIIl var2 = lIllIIl.Il();
      if (var2 != null) {
         class_310 var3 = class_310.method_1551();
         if (var3.field_1690 != null) {
            if (lIlIllll.IIII(var3)) {
               this.II(var3);
            }

            boolean var10000;
            label213: {
               class_437 var6 = var3.field_1755;
               if (var6 instanceof lIIIllIl) {
                  lIIIllIl var5 = (lIIIllIl)var6;
                  if (var5.IllIlIl()) {
                     var10000 = true;
                     break label213;
                  }
               }

               var10000 = false;
            }

            boolean var4 = var10000;
            boolean var22 = var3.field_1755 != null && !var4;
            if (this.I && !var22) {
               this.IIIl(var3);
            }

            this.I = var22;
            if (var22) {
               this.lIl(var3);
            } else {
               if (var4 && !lIlIllll.ll(var3)) {
                  this.IIIl(var3);
               }

               this.lll = false;
               this.ll = false;
               this.llI = false;
               this.IIII = 0.0F;
               this.IlIl = 0.0F;
               this.Ill = false;
               this.Illl = false;
               this.IIl = false;
               this.lI = false;
               this.IIlI = false;
               this.II = false;
               this.lIl = false;
               IIIIIIlIl var23 = var2.IIl() != null ? var2.IIl().IlIIlI() : null;
               boolean var7 = var23 != null && var23.lIII();
               this.IIll = !var7 && var3.field_1690.field_1894.method_1434();
               this.IlI = var7 ? var23.lII() == null.II : var3.field_1690.field_1881.method_1434();
               this.Il = var3.field_1690.field_1913.method_1434();
               this.III = var3.field_1690.field_1849.method_1434();
               this.IlII = !var7 && var3.field_1690.field_1867.method_1434();
               this.lIII = var3.field_1690.field_1832.method_1434();
               this.IIIl = var3.field_1690.field_1903.method_1434();
               III var8 = var2.IIl().lIIIl();
               if (var8 != null && var8.IIIIIlI()) {
                  var3.field_1690.field_1894.method_23481(false);
                  this.Ill = true;
                  var3.field_1690.field_1881.method_23481(false);
                  this.Illl = true;
                  var3.field_1690.field_1913.method_23481(false);
                  this.IIl = true;
                  var3.field_1690.field_1849.method_23481(false);
                  this.lI = true;
                  var3.field_1690.field_1867.method_23481(false);
                  this.IIlI = true;
                  var3.field_1690.field_1832.method_23481(false);
                  this.II = true;
                  var3.field_1690.field_1903.method_23481(false);
                  this.lIl = true;
                  if (this.field_3913 != null) {
                     IllllIlI.llIIIl(this.field_3913, 0.0F, 0.0F);
                  }

                  this.lll = true;
               }

               lIlIllII var9 = var2.IIl().llIllI();
               if (var9 != null && var9.lII()) {
                  this.IIlI(var2, var3, var3.field_1690.field_1867, true);
                  this.lll = true;
               }

               IIIIlllll var10 = var2.IIl().IIIII();
               if (var10 != null) {
                  var10.IlI(var3, var10.lII(var3));
               }

               IIIIlIIl var11 = var2.IIl().IIlIII();
               if (var11 != null && var11.ll(var3)) {
                  this.IIlI(var2, var3, var3.field_1690.field_1903, true);
                  this.lll = true;
               }

               if (var11 != null && var11.IIII(var3)) {
                  this.IIlI(var2, var3, var3.field_1690.field_1867, true);
                  this.lll = true;
               }

               llIlIII var12 = var2.IIl().IlIIl();
               if (var12 != null && var12.IlIl(var3)) {
                  this.IIlI(var2, var3, var3.field_1690.field_1903, true);
                  this.lll = true;
               }

               lIIlIlIl var13 = var2.IIl().IIllII();
               if (var13 != null && var13.IIIIIlI()) {
                  if (var13.lIIl(var3)) {
                     this.IIlI(var2, var3, var3.field_1690.field_1867, true);
                     this.lll = true;
                  }

                  if (var13.IlIl(var3)) {
                     this.IIlI(var2, var3, var3.field_1690.field_1903, true);
                     this.lll = true;
                  }
               }

               IIlIll var14 = var2.IIl().lIlIlI();
               boolean var15 = var14 != null && var14.I(var3);
               if (var15) {
                  this.IIlI(var2, var3, var3.field_1690.field_1832, true);
                  this.l(var3, var14.IIl(var3));
                  this.lll = true;
               }

               if (var14 != null && var14.II(var3)) {
                  this.IIlI(var2, var3, var3.field_1690.field_1867, false);
                  this.lll = true;
               }

               lIIIllI var16 = var2.IIl().llll();
               boolean var17 = var16 != null && var16.IlI();
               boolean var18 = var16 != null && var16.ll();
               boolean var19 = var17 && IlIlIl.IllII(var3);
               if (!this.llI && var19 && var18) {
                  this.llI(var3);
                  this.IllI(var3, IlIlIl.llIIl());
               }

               float var20 = IlIlIl.llII(var3);
               if (!this.llI && Float.isFinite(var20)) {
                  this.llI(var3);
                  this.I(var3, var20);
               }

               if (lIlIllll.lII(var3)) {
                  this.IIll = this.IlIl(var3, var3.field_1690.field_1894);
                  this.IlI = this.IlIl(var3, var3.field_1690.field_1881);
                  this.Il = this.IlIl(var3, var3.field_1690.field_1913);
                  this.III = this.IlIl(var3, var3.field_1690.field_1849);
                  this.IlII = this.IlIl(var3, var3.field_1690.field_1867);
                  this.lIII = this.IlIl(var3, var3.field_1690.field_1832);
                  this.IIIl = this.IlIl(var3, var3.field_1690.field_1903);
                  var3.field_1690.field_1894.method_23481(false);
                  this.Ill = true;
                  var3.field_1690.field_1881.method_23481(false);
                  this.Illl = true;
                  var3.field_1690.field_1913.method_23481(false);
                  this.IIl = true;
                  var3.field_1690.field_1849.method_23481(false);
                  this.lI = true;
                  var3.field_1690.field_1867.method_23481(false);
                  this.IIlI = true;
                  var3.field_1690.field_1832.method_23481(false);
                  this.II = true;
                  var3.field_1690.field_1903.method_23481(false);
                  this.lIl = true;
                  if (this.field_3913 != null) {
                     IllllIlI.llIIIl(this.field_3913, 0.0F, 0.0F);
                  }

                  this.lll = true;
               }

               lIlIllll.II(var3);
               IlIl var21 = var2.IIl().IlIlII();
               if (var21 != null && var21.IIIII(var3)) {
                  lIlIllll.IllI(var3);
               }

               if (lIlIllll.lI(var3)) {
                  this.IllI = this.IlIl(var3, var3.field_1690.field_1886);
                  this.lII = this.IlIl(var3, var3.field_1690.field_1904);
                  var3.field_1690.field_1886.method_23481(false);
                  var3.field_1690.field_1904.method_23481(false);
                  this.l = true;
                  this.lll = true;
               }

            }
         }
      }
   }

   @Inject(
      method = {"method_6007"},
      at = {@At("TAIL")},
      require = 0
   )
   private void lII(CallbackInfo var1) {
      class_310 var2 = class_310.method_1551();
      this.IIII(var2);
      lIllIIl var3 = lIllIIl.Il();
      if (var3 != null) {
         class_746 var4 = (class_746)this;
         if (var2.field_1724 != null) {
            IIIIlIIl var5 = var3.IIl().IIlIII();
            if (var5 != null && var5.lll() && !var4.method_24828()) {
               class_243 var6 = var4.method_18798();
               double var7 = Math.sqrt(var6.field_1352 * var6.field_1352 + var6.field_1350 * var6.field_1350);
               if (var7 > 0.001) {
                  float var9 = var5.II();
                  float var10 = (float)Math.toDegrees(Math.atan2(-var6.field_1352, var6.field_1350));
                  float var11 = class_3532.method_15393(var9 - var10);
                  class_243 var12 = (new class_243(var6.field_1352, (double)0.0F, var6.field_1350)).method_1024(-((float)Math.toRadians((double)var11)));
                  var4.method_18800(var12.field_1352, var6.field_1351, var12.field_1350);
               }
            }

            IllllIlI.llIlIl(var2, var4.method_36454());
         }
      }
   }

   @Unique
   private void lIl(class_310 var1) {
      if (var1 != null && var1.field_1690 != null) {
         var1.field_1690.field_1894.method_23481(false);
         var1.field_1690.field_1881.method_23481(false);
         var1.field_1690.field_1913.method_23481(false);
         var1.field_1690.field_1849.method_23481(false);
         var1.field_1690.field_1867.method_23481(false);
         var1.field_1690.field_1832.method_23481(false);
         var1.field_1690.field_1903.method_23481(false);
         if (this.field_3913 != null) {
            this.field_3913.field_54155 = new class_10185(false, false, false, false, false, false, false);
            IllllIlI.llIIIl(this.field_3913, 0.0F, 0.0F);
         }

      }
   }

   @Unique
   private void llI(class_310 var1) {
      if (var1 != null && var1.field_1690 != null) {
         lIllIIl var2 = lIllIIl.Il();
         IIIIIIlIl var3 = var2 != null && var2.IIl() != null ? var2.IIl().IlIIlI() : null;
         boolean var4 = var3 != null && var3.lIII();
         this.IIll = !var4 && var1.field_1690.field_1894.method_1434();
         this.IlI = var4 ? var3.lII() == null.II : var1.field_1690.field_1881.method_1434();
         this.Il = var1.field_1690.field_1913.method_1434();
         this.III = var1.field_1690.field_1849.method_1434();
      }
   }

   @Inject(
      method = {"method_5773"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/class_746;method_3136()V"
)},
      require = 0
   )
   private void lll(CallbackInfo var1) {
      class_310 var2 = class_310.method_1551();
      IllllIlI.lIlIIl(var2);
      lIllIIl var3 = lIllIIl.Il();
      if (var3 != null) {
         IlIl var4 = var3.IIl().IlIlII();
         if (var4 != null) {
            var4.lIIl(var2);
         }
      }

      IlIlIl.IIIl(var2);
   }

   @Unique
   private void IIII(class_310 var1) {
      if (var1 != null && var1.field_1690 != null && (this.lll || this.llI)) {
         if (this.llI && this.field_3913 != null) {
            IllllIlI.llIIIl(this.field_3913, this.IIII, this.IlIl);
         }

         lIllIIl var2 = lIllIIl.Il();
         IIIIIIlIl var3 = var2 != null && var2.IIl() != null ? var2.IIl().IlIIlI() : null;
         boolean var4 = var3 != null && var3.lIII();
         boolean var5 = this.lll;
         if (var5) {
            if (!lIlIllll.ll(var1)) {
               if (this.Ill && !var4) {
                  this.IlII(var2, var1, var1.field_1690.field_1894);
               }

               if (this.Illl && !var4) {
                  this.IlII(var2, var1, var1.field_1690.field_1881);
               }

               if (this.IIl) {
                  this.IlII(var2, var1, var1.field_1690.field_1913);
               }

               if (this.lI) {
                  this.IlII(var2, var1, var1.field_1690.field_1849);
               }

               if (this.IIlI && !var4) {
                  this.IlII(var2, var1, var1.field_1690.field_1867);
               }

               if (this.II) {
                  this.IlII(var2, var1, var1.field_1690.field_1832);
               }
            }

            if (this.lIl) {
               this.IlII(var2, var1, var1.field_1690.field_1903);
            }
         }

         if (this.l) {
            var1.field_1690.field_1886.method_23481(this.IllI);
            var1.field_1690.field_1904.method_23481(this.lII);
            this.l = false;
         }

         if (var2 != null && var5 && !lIlIllll.ll(var1) && !var4) {
            this.IIll(var1, var2);
         }

         this.lll = false;
         this.llI = false;
      }
   }

   @Unique
   private void IIIl(class_310 var1) {
      if (var1 != null && var1.field_1690 != null) {
         this.ll(var1, var1.field_1690.field_1894);
         this.ll(var1, var1.field_1690.field_1881);
         this.ll(var1, var1.field_1690.field_1913);
         this.ll(var1, var1.field_1690.field_1849);
         this.ll(var1, var1.field_1690.field_1867);
         this.ll(var1, var1.field_1690.field_1832);
         this.ll(var1, var1.field_1690.field_1903);
      }
   }

   @Unique
   private void IIlI(lIllIIl var1, class_310 var2, class_304 var3, boolean var4) {
      if (var2.field_1690 != null) {
         if (var3 == var2.field_1690.field_1894) {
            this.Ill = true;
         } else if (var3 == var2.field_1690.field_1881) {
            this.Illl = true;
         } else if (var3 == var2.field_1690.field_1913) {
            this.IIl = true;
         } else if (var3 == var2.field_1690.field_1849) {
            this.lI = true;
         } else if (var3 == var2.field_1690.field_1867) {
            this.IIlI = true;
         } else if (var3 == var2.field_1690.field_1832) {
            this.II = true;
         } else if (var3 == var2.field_1690.field_1903) {
            this.lIl = true;
         }
      }

      lllI var5 = lllI.lll();
      if (var5 != null) {
         var5.IlI(this, var2, var3, var4);
      } else {
         var3.method_23481(var4);
      }

   }

   @Unique
   private void IIll(class_310 var1, lIllIIl var2) {
      if (var1 != null && var1.field_1724 != null && var1.field_1690 != null && var2 != null) {
         if (var2.IIl() == null || var2.IIl().IlIIlI() == null || !var2.IIl().IlIIlI().lIII()) {
            if (!var1.field_1724.method_5624() && var1.field_1724.method_5805() && !var1.field_1724.method_5715() && !var1.field_1724.method_6115()) {
               IIIIlIIl var3 = var2.IIl().IIlIII();
               boolean var4 = var3 != null && var3.IIII(var1);
               lIlIllII var5 = var2.IIl().llIllI();
               boolean var6 = var5 != null && var5.lII();
               lIIlIlIl var7 = var2.IIl().IIllII();
               boolean var8 = var7 != null && var7.lIIl(var1);
               boolean var9 = this.IlII || var1.field_1690.field_1867.method_1434() || IllllIlI.IIIll(var1, var1.field_1690.field_1867);
               if (var4 || var6 || var8 || var9) {
                  if (var4 || var1.field_1690.field_1894.method_1434() && !var1.field_1690.field_1881.method_1434()) {
                     var1.field_1724.method_5728(true);
                  }
               }
            }
         }
      }
   }

   @Unique
   private void IlII(lIllIIl var1, class_310 var2, class_304 var3) {
      lllI var4 = lllI.lll();
      if (var4 != null) {
         var4.IIIl(this, var2, var3);
      } else {
         var3.method_23481(this.IlIl(var2, var3));
      }

   }

   @Unique
   private boolean IlIl(class_310 var1, class_304 var2) {
      return var2 != null && IllllIlI.IIIll(var1, var2);
   }

   @Unique
   private void IllI(class_310 var1, float var2) {
      float var3 = ((class_746)this).method_36454();
      <undefinedtype> var4 = lIlllllI.I(this.IIll, this.IlI, this.Il, this.III, var3, var2);
      if (var4.I() != 0.0F || var4.l() != 0.0F) {
         this.lI(var1, var4.I(), var4.l());
      }
   }
}
