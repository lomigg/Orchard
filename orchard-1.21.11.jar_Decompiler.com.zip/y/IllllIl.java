package y;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_312;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import x.IIllIlII;
import x.IIlllI;
import x.IIllllllI;
import x.lIllIIl;

@Environment(EnvType.CLIENT)
@Mixin({class_312.class})
public abstract class IllllIl {
   @Shadow
   private double field_1789;
   @Shadow
   private double field_1787;

   @Inject(
      method = {"method_55793"},
      at = {@At("HEAD")}
   )
   private void I(CallbackInfo var1) {
      lIllIIl var2 = lIllIIl.Il();
      if (var2 != null) {
         IIllIlII var3 = var2.IIl();
         if (var3 != null) {
            IIllllllI var4 = var3.l();
            if (var4 != null) {
               var4.lIIII(this.field_1789, this.field_1787);
            }

            IIlllI var5 = var3.llIII();
            if (var5 != null && var5.lll()) {
               float var6 = var5.IIII();
               this.field_1789 *= (double)var6;
               this.field_1787 *= (double)var6;
            }
         }
      }
   }
}
