package y;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import x.III;
import x.IllIIll;
import x.lIlIlIII;
import x.lIllIIl;

@Environment(EnvType.CLIENT)
@Mixin({class_1297.class})
public abstract class lIlII {
   @Inject(
      method = {"method_5872"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void I(double var1, double var3, CallbackInfo var5) {
      lIllIIl var6 = lIllIIl.Il();
      if (var6 != null) {
         class_1297 var7 = (class_1297)this;
         class_310 var8 = class_310.method_1551();
         if (var7 == var8.field_1724) {
            float var9 = (float)var1 * 0.15F;
            float var10 = (float)var3 * 0.15F;
            III var11 = var6.IIl().lIIIl();
            if (var11 != null && var11.IIIIIlI()) {
               var11.I(0.0F, 0.0F, var9, var10);
               var5.cancel();
            } else {
               lIlIlIII var12 = var6.IIl().llIll();
               if (var12 != null && var12.IllIlI()) {
                  var12.llIlII(0.0F, 0.0F, var9, var10);
                  var5.cancel();
               } else {
                  <undefinedtype> var13 = IllIIll.Il();
                  if (var13 != null.l) {
                     IllIIll.II(var13, 0.0F, 0.0F, var9, var10);
                     var5.cancel();
                  }

               }
            }
         }
      }
   }
}
