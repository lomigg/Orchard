package y;

import io.netty.channel.Channel;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelPipeline;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import net.minecraft.class_2598;
import net.minecraft.class_2815;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import x.IIIIIlIll;
import x.IIlIIIllI;
import x.IlIl;
import x.lIIlIl;
import x.lIlIII;
import x.lIllIIl;

@Environment(EnvType.CLIENT)
@Mixin({class_2535.class})
public abstract class lIlIlIll {
   @Shadow
   private Channel field_11651;
   @Unique
   private static final String I = lIlIII.Il("kZhbihpWRA+oGJZXCOzNjpebUg==");
   @Unique
   private IIIIIlIll l;
   @Shadow
   @Final
   private class_2598 field_11643;

   @Inject(
      method = {"method_10743"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void I(class_2596<?> var1, CallbackInfo var2) {
      lIllIIl var3 = lIllIIl.Il();
      if (this.III()) {
         this.II(this.field_11651.pipeline());
      }

      if (var3 != null && var3.IIl() != null) {
         IlIl var4 = var3.IIl().IlIlII();
         if (var4 != null && var4.ll(var1)) {
            var2.cancel();
            return;
         }
      }

      if (var3 != null && var1 instanceof class_2815 var6) {
         lIIlIl var5 = var3.IIl().IIIlII();
         if (var5 != null && var5.lII(var6)) {
            var2.cancel();
            return;
         }
      }

      if (var3 != null && var3.IIl() != null && var3.IIl().IIIlll() != null) {
         var3.IIl().IIIlll().ll(var1);
      }

      if (var3 != null && var3.IIl() != null) {
         var3.IIl().IIlIIIl(var1);
      }

      IIIIIlIll.llIllI(var1);
   }

   @Inject(
      method = {"method_10743"},
      at = {@At("TAIL")}
   )
   private void l(class_2596<?> var1, CallbackInfo var2) {
      lIllIIl var3 = lIllIIl.Il();
      if (var3 != null && var3.IIl() != null) {
         var3.IIl().IIlII(var1);
      }

   }

   @Unique
   private void II(ChannelPipeline var1) {
      IIlIIIllI.Il().l();
      Channel var2 = var1.channel();
      Runnable var3 = () -> {
         if (this.field_11651 == var2 && var2.isOpen()) {
            ChannelHandler var3 = var1.get(I);
            if (var3 instanceof IIIIIlIll) {
               IIIIIlIll var6 = (IIIIIlIll)var3;
               this.l = var6;
            } else if (var3 == null) {
               ChannelHandlerContext var4 = var1.context((ChannelHandler)this);
               IIIIIlIll var5 = new IIIIIlIll();
               if (var4 != null) {
                  var1.addBefore(var4.name(), I, var5);
               } else {
                  var1.addLast(I, var5);
               }

               this.l = var5;
            }
         }
      };
      if (var2.eventLoop().inEventLoop()) {
         var3.run();
      } else {
         try {
            var2.eventLoop().execute(var3);
         } catch (RuntimeException var5) {
         }

      }
   }

   @Inject(
      method = {"method_53859"},
      at = {@At("RETURN")}
   )
   private void Il(ChannelPipeline var1, CallbackInfo var2) {
      if (this.III()) {
         this.II(var1);
      }
   }

   @Inject(
      method = {"channelInactive"},
      at = {@At("HEAD")}
   )
   private void ll(ChannelHandlerContext var1, CallbackInfo var2) {
      IIlIIIllI.Il().IlI();
      if (this.l != null) {
         this.l.lIIIIl();
         this.l = null;
      }

   }

   @Unique
   private boolean III() {
      return this.field_11643 == class_2598.field_11942 && this.field_11651 != null;
   }

   @Inject(
      method = {"channelActive"},
      at = {@At("TAIL")}
   )
   private void IIl(ChannelHandlerContext var1, CallbackInfo var2) {
      if (this.III()) {
         this.II(var1.pipeline());
      }
   }
}
