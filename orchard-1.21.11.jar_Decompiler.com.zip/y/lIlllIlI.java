package y;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import x.IlIl;
import x.IllllIlI;
import x.lIllIIl;
import x.llIIIllI;

@Environment(EnvType.CLIENT)
@Mixin({class_636.class})
public abstract class lIlllIlI {
   @Inject(
      method = {"method_2918"},
      at = {@At("TAIL")}
   )
   private void I(class_1657 var1, class_1297 var2, CallbackInfo var3) {
      IllllIlI.llIlll();
      lIllIIl var4 = lIllIIl.Il();
      if (var4 != null) {
         var4.IIl().ll(var2);
      }

   }

   @Inject(
      method = {"method_2918"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void l(class_1657 var1, class_1297 var2, CallbackInfo var3) {
      lIllIIl var4 = lIllIIl.Il();
      if (var4 != null) {
         IlIl var5 = var4.IIl().IlIlII();
         if (var5 != null && var5.IIIII(class_310.method_1551())) {
            var3.cancel();
            return;
         }

         llIIIllI var6 = var4.IIl().IIIllll();
         if (var6 != null && var6.IIIIIlI() && !IllllIlI.II() && var2 instanceof class_1309) {
            class_1309 var7 = (class_1309)var2;
            var6.IlIl(class_310.method_1551(), var7);
         }

         var4.IIl().lIllII(var2);
      }

   }
}
