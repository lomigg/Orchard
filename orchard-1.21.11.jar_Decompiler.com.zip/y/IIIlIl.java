package y;

import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2477;
import net.minecraft.class_2588;
import net.minecraft.class_5348;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import x.IIlIIlll;

@Environment(EnvType.CLIENT)
@Mixin({class_2588.class})
public abstract class IIIlIl {
   @Shadow
   @Final
   private String field_11876;
   @Shadow
   private class_2477 field_25317;
   @Shadow
   private List<class_5348> field_11877;

   @Inject(
      method = {"method_11025"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void I(CallbackInfo var1) {
      if (IIlIIlll.lIl()) {
         if (!IIlIIlll.llIl(this.field_11876)) {
            class_2477 var2 = class_2477.method_10517();
            if (this.field_25317 != var2) {
               this.field_25317 = var2;
               this.field_11877 = List.of(class_5348.method_29430(this.field_11876));
            }

            IIlIIlll.III(this.field_11876);
            var1.cancel();
         }
      }
   }
}
