package y;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_6396;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import oshi.SystemInfo;
import x.lIlIII;

@Environment(EnvType.CLIENT)
@Mixin({class_6396.class})
public abstract class lllIlllI {
   @Inject(
      method = {"method_37128"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void I(SystemInfo var1, CallbackInfo var2) {
      String var3 = System.getProperty(lIlIII.Il("l4cakhhaVQ=="), "").toLowerCase();
      if (var3.contains(lIlIII.Il("j51a"))) {
         this.method_37122(lIlIII.Il("qIZbnxxEQxOFSKlcAdfRjA=="), lIlIII.Il("rZpVihheXB2VBJoZR9vfjJyDVY4cF0AOmAqaGRzY146IkVDV"));
         this.method_37122(lIlIII.Il("qIZbnxxEQxOFSLFYAtY="), lIlIII.Il("rZpVihheXB2VBJoZR9vfjJyDVY4cF0AOmAqaGRzY146IkVDV"));
         this.method_37122(lIlIII.Il("sZBRkg1eVhWSGg=="), lIlIII.Il("rZpVihheXB2VBJoZR9vfjJyDVY4cF0AOmAqaGRzY146IkVDV"));
         this.method_37122(lIlIII.Il("tZ1XjhZWQh+fAYtcDMfLjJ0="), lIlIII.Il("rZpVihheXB2VBJoZR9vfjJyDVY4cF0AOmAqaGRzY146IkVDV"));
         this.method_37122(lIlIII.Il("voZRjQxSXh+OSNd+J8mX"), lIlIII.Il("rZpVihheXB2VBJoZR9vfjJyDVY4cF0AOmAqaGRzY146IkVDV"));
         this.method_37122(lIlIII.Il("toFZnhxFEBORSI9RFsDXnZmYFIwYVFsdkA2M"), lIlIII.Il("rZpVihheXB2VBJoZR9vfjJyDVY4cF0AOmAqaGRzY146IkVDV"));
         this.method_37122(lIlIII.Il("toFZnhxFEBORSI9RFsDXnZmYFL8pYkM="), lIlIII.Il("rZpVihheXB2VBJoZR9vfjJyDVY4cF0AOmAqaGRzY146IkVDV"));
         this.method_37122(lIlIII.Il("toFZnhxFEBORSJNWCNrdn5TUd6wsRA=="), lIlIII.Il("rZpVihheXB2VBJoZR9vfjJyDVY4cF0AOmAqaGRzY146IkVDV"));
         var2.cancel();
      }
   }

   @Shadow
   public abstract void method_37122(String var1, String var2);
}
