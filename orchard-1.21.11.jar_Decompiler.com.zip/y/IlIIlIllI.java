package y;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_636;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import x.IIIlIlI;
import x.IlIl;
import x.IllllIlI;
import x.lIl;
import x.lIllIIII;
import x.lIllIIl;
import x.lIllIlII;
import x.llIIlIII;
import x.llIIlIlI;
import x.llIlIIIl;
import x.lllIII;

@Environment(EnvType.CLIENT)
@Mixin({class_636.class})
public abstract class IlIIlIllI {
   @Unique
   private int I;

   @Inject(
      method = {"method_2896"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void I(class_746 var1, class_1268 var2, class_3965 var3, CallbackInfoReturnable<class_1269> var4) {
      if (IllllIlI.lIlIl()) {
         ++this.I;
      }

      lIllIIl var5 = lIllIIl.Il();
      if (var5 != null) {
         IlIl var6 = var5.IIl().IlIlII();
         if (var6 != null && var6.IIIII(class_310.method_1551())) {
            this.III();
            var4.setReturnValue(class_1269.field_5814);
         } else {
            llIlIIIl var7 = (llIlIIIl)var5.IIl().IIIIIII(llIlIIIl.class);
            if (var7 != null && var7.ll(class_310.method_1551(), var3)) {
               this.III();
               var4.setReturnValue(class_1269.field_5814);
            } else {
               llIIlIII var8 = var5.IIl().IIIIlI();
               if (var8 != null) {
                  var8.Illl(class_310.method_1551(), var2, var3);
               }

               lIllIIII var9 = var5.IIl().lll();
               if (var9 != null && (var8 == null || !var8.IIIII())) {
                  var9.IlI(class_310.method_1551(), var2, var3);
               }

               IIIlIlI var10 = var5.IIl().IIlll();
               boolean var11 = var8 != null && var8.IIIII() || var9 != null && var9.lIIIl();
               boolean var12 = !var11 && (var9 == null || !var9.lllI()) && var10 != null && var10.lll(class_310.method_1551(), var2, var3);
               if (var12) {
                  if (var8 != null) {
                     var8.lII(class_310.method_1551(), var2, var3);
                  }

                  if (var9 != null) {
                     var9.IlIIIl();
                     var9.lIllI();
                  }

                  this.III();
                  var4.setReturnValue(class_1269.field_5814);
               } else {
                  llIIlIlI var13 = var5.IIl().IllII();
                  if (var13 != null && !var13.IllIl()) {
                     var13.IIIll(class_310.method_1551(), var2, var3);
                  }

                  lIllIlII var14 = var5.IIl().lIIIII();
                  if (var14 != null) {
                     var14.IlIl(class_310.method_1551(), var2, var3);
                  }

                  lllIII var15 = var5.IIl().IIIlIlI();
                  if (var15 != null && var15.IIIIIlI()) {
                     if (var15.IlllI(class_310.method_1551())) {
                        this.III();
                        var4.setReturnValue(class_1269.field_5814);
                     }

                  }
               }
            }
         }
      }
   }

   @Inject(
      method = {"method_2918"},
      at = {@At("HEAD")}
   )
   private void l(class_1657 var1, class_1297 var2, CallbackInfo var3) {
      if (IllllIlI.lIlIl()) {
         ++this.I;
      }

   }

   @Inject(
      method = {"method_2911"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void II(CallbackInfo var1) {
      if (IllllIlI.IlIIIIl()) {
         var1.cancel();
      }

   }

   @Inject(
      method = {"method_2919"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void Il(class_1657 var1, class_1268 var2, CallbackInfoReturnable<class_1269> var3) {
      if (IllllIlI.lIlIl()) {
         ++this.I;
      }

      lIllIIl var4 = lIllIIl.Il();
      if (var4 != null) {
         IlIl var5 = var4.IIl().IlIlII();
         if (var5 != null && var5.IIIII(class_310.method_1551())) {
            this.III();
            var3.setReturnValue(class_1269.field_5814);
         }

      }
   }

   @Inject(
      method = {"method_2910"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void lI(class_2338 var1, class_2350 var2, CallbackInfoReturnable<Boolean> var3) {
      lIllIIl var4 = lIllIIl.Il();
      if (var4 != null) {
         lIl var5 = (lIl)var4.IIl().IIIIIII(lIl.class);
         if (var5 != null) {
            var5.IIll(class_310.method_1551(), var1, var2);
         }

         IlIl var6 = var4.IIl().IlIlII();
         if (var6 != null && var6.IIIII(class_310.method_1551())) {
            var3.setReturnValue(false);
         } else {
            lllIII var7 = var4.IIl().IIIlIlI();
            if (var7 != null) {
               if (var7.llII(var1, var2)) {
                  var3.setReturnValue(true);
               }

            }
         }
      }
   }

   @Inject(
      method = {"method_2896"},
      at = {@At("RETURN")}
   )
   private void ll(class_746 var1, class_1268 var2, class_3965 var3, CallbackInfoReturnable<class_1269> var4) {
      this.III();
      lIllIIl var5 = lIllIIl.Il();
      if (var5 != null) {
         llIIlIII var6 = var5.IIl().IIIIlI();
         if (var6 != null) {
            var6.IlIl(class_310.method_1551(), var2, var3, (class_1269)var4.getReturnValue());
         }

         lIllIIII var7 = var5.IIl().lll();
         if (var7 != null) {
            var7.lIll(class_310.method_1551(), var2, var3, (class_1269)var4.getReturnValue());
         }

         lIllIlII var8 = var5.IIl().lIIIII();
         if (var8 != null) {
            var8.IIIIIl(class_310.method_1551(), var2, var3, (class_1269)var4.getReturnValue());
         }

         llIIlIlI var9 = var5.IIl().IllII();
         if (var9 != null) {
            var9.IIlII(class_310.method_1551(), var2, var3, (class_1269)var4.getReturnValue());
         }

      }
   }

   @Unique
   private void III() {
      if (this.I > 0) {
         --this.I;
         IllllIlI.IIlllI();
      }

   }

   @Inject(
      method = {"method_2919"},
      at = {@At("RETURN")}
   )
   private void IIl(class_1657 var1, class_1268 var2, CallbackInfoReturnable<class_1269> var3) {
      this.III();
      lIllIIl var4 = lIllIIl.Il();
      if (var4 != null) {
         lIllIlII var5 = var4.IIl().lIIIII();
         if (var5 != null) {
            var5.IIIIl(class_310.method_1551(), var2, (class_1269)var3.getReturnValue());
         }

      }
   }

   @Inject(
      method = {"method_2918"},
      at = {@At("RETURN")}
   )
   private void IlI(class_1657 var1, class_1297 var2, CallbackInfo var3) {
      this.III();
   }
}
