package y;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import x.IIlIIllll;
import x.Il;
import x.IlIIlIlII;
import x.IlIIllII;
import x.llIIIIl;

@Environment(EnvType.CLIENT)
@Mixin({class_1297.class})
public abstract class IllIllIl {
   @Inject(
      method = {"method_5476"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void I(CallbackInfoReturnable<class_2561> var1) {
      class_1297 var2 = (class_1297)this;
      if (var2 instanceof class_1657 var3) {
         class_2561 var4 = llIIIIl.Il(var3.method_7334(), (class_2561)var1.getReturnValue());
         var1.setReturnValue(Il.III(var3, IIlIIllll.III(var3, var4)));
      }

   }

   @Inject(
      method = {"method_5756"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void l(class_1657 var1, CallbackInfoReturnable<Boolean> var2) {
      class_1297 var3 = (class_1297)this;
      if (IlIIlIlII.IlI(var3)) {
         var2.setReturnValue(true);
      }

   }

   @Inject(
      method = {"method_5477"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void II(CallbackInfoReturnable<class_2561> var1) {
      class_1297 var2 = (class_1297)this;
      if (var2 instanceof class_1657 var3) {
         class_2561 var4 = llIIIIl.Il(var3.method_7334(), (class_2561)var1.getReturnValue());
         var1.setReturnValue(Il.III(var3, IIlIIllll.III(var3, var4)));
      }

   }

   @Inject(
      method = {"method_5733"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void Il(CallbackInfoReturnable<Boolean> var1) {
      class_1297 var2 = (class_1297)this;
      if (IlIIlIlII.ll(var2) || IlIIllII.Illl(var2)) {
         var1.setReturnValue(false);
      }

   }
}
