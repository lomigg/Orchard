package y;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(EnvType.CLIENT)
@Mixin({class_746.class})
public interface lllll {
   @Accessor("field_3926")
   void virel$setLastXClient(double var1);

   @Accessor("field_3940")
   void virel$setLastYClient(double var1);

   @Accessor("field_3923")
   void virel$setTicksSinceLastPositionPacketSent(int var1);

   @Accessor("field_3924")
   double virel$getLastZClient();

   @Accessor("field_3940")
   double virel$getLastYClient();

   @Accessor("field_3923")
   int virel$getTicksSinceLastPositionPacketSent();

   @Accessor("field_3926")
   double virel$getLastXClient();

   @Accessor("field_3919")
   boolean virel$getLastSprinting();

   @Accessor("field_3941")
   float virel$getLastYawClient();

   @Accessor("field_3925")
   float virel$getLastPitchClient();

   @Accessor("field_3925")
   void virel$setLastPitchClient(float var1);

   @Accessor("field_3919")
   void virel$setLastSprinting(boolean var1);

   @Accessor("field_3924")
   void virel$setLastZClient(double var1);

   @Accessor("field_3941")
   void virel$setLastYawClient(float var1);
}
