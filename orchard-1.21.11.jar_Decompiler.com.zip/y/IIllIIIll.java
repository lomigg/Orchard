package y;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import x.IIllIIIII;
import x.lIllIIl;

@Environment(EnvType.CLIENT)
@Mixin({class_1657.class})
public abstract class IIllIIIll {
   @Redirect(
      method = {"method_75122"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/class_1657;method_5728(Z)V"
)
   )
   private void I(class_1657 var1, boolean var2, class_1297 var3, float var4, class_243 var5) {
      IIllIIIII var6 = II();
      if (var6 == null || !var6.lII(var1)) {
         var1.method_5728(var2);
      }
   }

   @Redirect(
      method = {"method_75122"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/class_243;method_18805(DDD)Lnet/minecraft/class_243;"
)
   )
   private class_243 l(class_243 var1, double var2, double var4, double var6, class_1297 var8, float var9, class_243 var10) {
      class_1657 var11 = (class_1657)this;
      IIllIIIII var12 = II();
      if (var12 != null && var12.ll(var11)) {
         double var13 = var12.IlI();
         return var1.method_18805(var13, var4, var13);
      } else {
         return var1.method_18805(var2, var4, var6);
      }
   }

   private static IIllIIIII II() {
      lIllIIl var0 = lIllIIl.Il();
      return var0 != null && var0.IIl() != null ? var0.IIl().lIll() : null;
   }
}
