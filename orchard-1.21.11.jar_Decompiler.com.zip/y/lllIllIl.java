package y;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(EnvType.CLIENT)
@Mixin({class_304.class})
public interface lllIllIl {
   @Accessor("field_1661")
   int virel$getTimesPressed();

   @Accessor("field_1655")
   class_3675.class_306 virel$getBoundKey();

   @Accessor("field_1661")
   void virel$setTimesPressed(int var1);
}
