package y;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2535;
import net.minecraft.class_2720;
import net.minecraft.class_2856;
import net.minecraft.class_310;
import net.minecraft.class_8673;
import net.minecraft.class_2856.class_2857;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import x.IIlIIlll;
import x.IlIllIII;

@Environment(EnvType.CLIENT)
@Mixin({class_8673.class})
public abstract class IIIllIllI {
   @Shadow
   @Final
   protected class_2535 field_45589;
   @Shadow
   @Final
   protected class_310 field_45588;

   @Inject(
      method = {"method_52784"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void I(class_2720 var1, CallbackInfo var2) {
      if (IIlIIlll.lIl()) {
         if (!IIlIIlll.lI(var1.comp_2158())) {
            var2.cancel();
            IIlIIlll.lIII(var1.comp_2159(), (var2x) -> this.field_45588.execute(() -> {
                  if (!IlIllIII.l() && this.field_45589.method_10758()) {
                     if (!IIlIIlll.lIl()) {
                        this.method_52784(var1);
                     } else if (var2x && IIlIIlll.II(var1.comp_2159())) {
                        IIlIIlll.IIII(var1.comp_2158());
                        this.method_52784(var1);
                     } else {
                        this.field_45589.method_10743(new class_2856(var1.comp_2158(), class_2857.field_47667));
                        IIlIIlll.llI(var1.comp_2159());
                     }
                  }
               }));
         }
      }
   }

   @Shadow
   public abstract void method_52784(class_2720 var1);
}
