package y;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import x.IllllIll;

@Environment(EnvType.CLIENT)
@Mixin({class_1297.class})
public abstract class IlIIlIIl {
   @Inject(
      method = {"method_22861"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void I(CallbackInfoReturnable<Integer> var1) {
      class_1297 var2 = (class_1297)this;
      if (IllllIll.l(var2.method_5667())) {
         var1.setReturnValue(IllllIll.lI(var2.method_5667()));
      }

   }

   @Inject(
      method = {"method_5851"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void l(CallbackInfoReturnable<Boolean> var1) {
      class_1297 var2 = (class_1297)this;
      if (IllllIll.l(var2.method_5667())) {
         var1.setReturnValue(true);
      }

   }
}
