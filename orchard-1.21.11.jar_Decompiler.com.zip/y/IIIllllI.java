package y;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_239;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3966;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import x.IIIIIlIll;
import x.IlIlIl;
import x.IlllIllI;
import x.IllllIlI;
import x.lIIlllll;
import x.lIlIllll;
import x.lIllIIl;
import x.llIllII;

@Environment(EnvType.CLIENT)
@Mixin({class_310.class})
public abstract class IIIllllI {
   @Unique
   private boolean I;
   @Unique
   private class_239 l;

   @Inject(
      method = {"method_1508"},
      at = {@At("TAIL")}
   )
   private void I(CallbackInfo var1) {
      lIllIIl var2 = lIllIIl.Il();
      if (var2 != null) {
         var2.IIl().llIIll(class_310.method_1551());
      }
   }

   @Unique
   private void l(class_310 var1) {
      if (this.I) {
         if (var1 != null) {
            var1.field_1765 = this.l;
         }

         this.l = null;
         this.I = false;
      }
   }

   @Inject(
      method = {"method_1583"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void II(CallbackInfo var1) {
      class_310 var2 = class_310.method_1551();
      if (!IllllIlI.lIIIl() && (lIlIllll.lIIl(var2) || IllllIlI.IlllIl() || IlIlIl.IIIII())) {
         var1.cancel();
      }

   }

   @Inject(
      method = {"method_1574"},
      at = {@At("HEAD")}
   )
   private void Il(CallbackInfo var1) {
      IIIIIlIll.IlllIl();
   }

   @Unique
   private class_3966 lI(class_310 var1, lIllIIl var2) {
      return var1 != null && var2 != null && var2.IIl() != null ? null : null;
   }

   @Inject(
      method = {"method_1583"},
      at = {@At("RETURN")}
   )
   private void ll(CallbackInfo var1) {
      lIllIIl var2 = lIllIIl.Il();
      if (var2 != null && var2.IIl() != null) {
         llIllII var3 = (llIllII)var2.IIl().IIIIIII(llIllII.class);
         if (var3 != null) {
            var3.III(class_310.method_1551());
         }

      }
   }

   @Inject(
      method = {"method_1536"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void III(CallbackInfoReturnable<Boolean> var1) {
      class_310 var2 = class_310.method_1551();
      if (var2 != null) {
         this.l(var2);
         lIllIIl var3 = lIllIIl.Il();
         if (IllllIlI.IIIlI() || IllllIlI.lIIIl() || !lIlIllll.lIIl(var2) && !IllllIlI.IlllIl() && !IlIlIl.IIIII()) {
            if (var3 != null && var3.IIl() != null) {
               class_3966 var4 = this.lI(var2, var3);
               if (var4 != null) {
                  this.l = var2.field_1765;
                  this.I = true;
                  var2.field_1765 = var4;
               }

               class_239 var6 = var2.field_1765;
               if (var6 instanceof class_3966) {
                  class_3966 var5 = (class_3966)var6;
                  if (IllllIlI.IlIllIl(var2, var5.method_17782())) {
                     IllllIlI.IlIlII(var2);
                     var1.setReturnValue(false);
                     return;
                  }
               }

               if (!IllllIlI.IIIlI()) {
                  lIIlllll var7 = var3.IIl().IIlIIl();
                  if (var7 != null && var7.lll(var2)) {
                     var1.setReturnValue(false);
                  }
               }

            }
         } else {
            var1.setReturnValue(false);
         }
      }
   }

   @Inject(
      method = {"method_1536"},
      at = {@At("RETURN")}
   )
   private void IIl(CallbackInfoReturnable<Boolean> var1) {
      this.l(class_310.method_1551());
   }

   @Inject(
      method = {"method_1490"},
      at = {@At("HEAD")}
   )
   private void IlI(CallbackInfo var1) {
      lIllIIl var2 = lIllIIl.Il();
      if (var2 != null) {
         var2.lll();
      }

   }

   @Inject(
      method = {"method_1508"},
      at = {@At("HEAD")}
   )
   private void Ill(CallbackInfo var1) {
      lIllIIl var2 = lIllIIl.Il();
      if (var2 != null) {
         class_310 var3 = class_310.method_1551();
         IlllIllI var4 = var2.IIl().IlIlIl();
         if (var4 != null) {
            var4.Illl(var3);
         }

         if (var2.IIl().lIIIl() != null && var2.IIl().lIIIl().IIIIIlI() && var3 != null && var3.field_1690 != null) {
            class_304 var5 = var3.field_1690.field_1824;
            if (var5 != null) {
               IllllIlI.IIIIllI(var5);
               var5.method_23481(false);
            }
         }

         if (var3 != null && var3.field_1690 != null) {
            IllllIlI.lIIl(var3);
            if (!IllllIlI.lIIIl() && (lIlIllll.lIIl(var3) || IllllIlI.IlllIl() || IlIlIl.IIIII())) {
               if (var3.field_1690.field_1886 != null) {
                  IllllIlI.IIIIllI(var3.field_1690.field_1886);
                  var3.field_1690.field_1886.method_23481(false);
               }

               if (var3.field_1690.field_1904 != null) {
                  IllllIlI.IIIIllI(var3.field_1690.field_1904);
                  var3.field_1690.field_1904.method_23481(false);
               }
            }
         }

         var2.IIl().llllIl(class_310.method_1551());
         if (var4 != null) {
            var4.Illl(var3);
         }

      }
   }
}
