package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class IIIll extends IIIIIIIlI {
   private static String[] I;
   private final IIllIlII l;
   private static final int[] II;
   private static final String[] Il;
   private static final Object[] lI;

   private static void ll() {
      I[0] = IlI(llI(-2066845971, 2089556708).toCharArray(), 66835L, lII(-368995211, 155306012));
      I[1] = IlI(llI(-2066845972, -1782640638).toCharArray(), 98448L, lII(-368995212, -1568078149));
   }

   private static String IlI(char[] var0, long var1, int var3) {
      int var4 = lII(-368995209, -1534748748) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & lII(-368995210, 1976000483);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   static {
      short var6 = 30262;
      String var7 = "끇“涎䙭衉頥춭缳증膩ￎ㡛馰ፎ쎌銟歴㸮맔泄\udd0f\udb5d킾ϳ㝱\ud9b5ú㢑龫⣝ﳴ꼖绀팬\uf71f耬꧊\uf322\uf3b4⚬淋산ꁁ䦺≃꺋댵議";
      char[] var8 = "瘾瘞".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            Il = var9;
            lI = new Object[var9.length];
            int var2 = 512459509;
            byte[] var0 = "\u009eèíh\u009d\u0004\fs\u0010fÂ\u0087\u0081MI\u009f".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            II = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               II[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            I = new String[2];
            ll();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public void lIl() {
      if (this.l != null) {
         for(IIIIIIIlI var2 : this.l.IIIIlII()) {
            if (var2 != this && var2.IIIIIlI()) {
               var2.IIIllIl(false);
            }
         }

         this.IIIllIl(false);
      }

   }

   public IIIll(IIllIlII var1) {
      super((Object)lIlIII.l(I[0]), lIllII.lI, (Object)lIlIII.l(I[1]));
      this.l = var1;
   }

   private static int lII(int var0, int var1) {
      return II[var0 ^ -368995211] ^ var1 ^ var0;
   }

   private static String llI(int var0, int var1) {
      int var3 = var0 ^ -2066845971;
      char[] var4 = Il[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])lI[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         lI[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -711647613;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 244;
               break;
            case 1:
               var9 = 149;
               break;
            case 2:
               var9 = 180;
               break;
            case 3:
               var9 = 177;
               break;
            case 4:
               var9 = 135;
               break;
            case 5:
               var9 = 236;
               break;
            case 6:
               var9 = 91;
               break;
            case 7:
               var9 = 23;
               break;
            case 8:
               var9 = 247;
               break;
            case 9:
               var9 = 155;
               break;
            case 10:
               var9 = 124;
               break;
            case 11:
               var9 = 78;
               break;
            case 12:
               var9 = 206;
               break;
            case 13:
               var9 = 167;
               break;
            case 14:
               var9 = 115;
               break;
            case 15:
               var9 = 151;
               break;
            case 16:
               var9 = 248;
               break;
            case 17:
               var9 = 144;
               break;
            case 18:
               var9 = 225;
               break;
            case 19:
               var9 = 131;
               break;
            case 20:
               var9 = 83;
               break;
            case 21:
               var9 = 93;
               break;
            case 22:
               var9 = 104;
               break;
            case 23:
               var9 = 39;
               break;
            case 24:
               var9 = 199;
               break;
            case 25:
               var9 = 60;
               break;
            case 26:
               var9 = 91;
               break;
            case 27:
               var9 = 43;
               break;
            case 28:
               var9 = 143;
               break;
            case 29:
               var9 = 54;
               break;
            case 30:
               var9 = 54;
               break;
            case 31:
               var9 = 148;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
