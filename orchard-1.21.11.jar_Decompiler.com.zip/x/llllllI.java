package x;

import com.google.gson.JsonElement;
import java.util.Objects;
import java.util.function.BooleanSupplier;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public abstract class llllllI<T> {
   private final <undefinedtype> lI;
   private boolean ll;
   private T III;
   private BooleanSupplier IIl;
   private final T IlI;
   private static final BooleanSupplier Ill = () -> true;

   public String Illl() {
      return this.lI.lIlI();
   }

   public <S extends llllllI<T>> S lIII(BooleanSupplier var1) {
      this.IIl = var1 == null ? Ill : var1;
      return (S)this;
   }

   protected llllllI(String var1, T var2) {
      this((Object)var1, var2);
   }

   public abstract JsonElement lI();

   public <undefinedtype> lIIl() {
      return this.lI;
   }

   public void IIl() {
      this.Il(this.IlI);
   }

   public boolean lIlI() {
      return this.IIl == null || this.IIl.getAsBoolean();
   }

   public abstract void II(JsonElement var1);

   public T l() {
      return this.IlI;
   }

   protected final void llII() {
      lIllIIl var1 = lIllIIl.Il();
      if (var1 != null) {
         var1.IIlI();
      }

   }

   public boolean llIl() {
      return this.ll;
   }

   public void Il(T var1) {
      boolean var2 = !Objects.equals(this.III, var1);
      this.III = var1;
      if (var2) {
         this.llII();
      }

   }

   public T III() {
      return this.III;
   }

   protected llllllI(Object var1, T var2) {
      this.IIl = Ill;
      this.ll = true;
      this.lI = lIlIII.IIIl(var1);
      this.IlI = var2;
      this.III = var2;
   }

   public long lllI() {
      return this.lI.lll();
   }

   public <S extends llllllI<T>> S llll() {
      this.ll = false;
      return (S)this;
   }
}
