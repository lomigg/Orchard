package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;

@Environment(EnvType.CLIENT)
public final class IIlIlll extends IIIIIIIlI {
   private final IIIllIIII I = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IlII(1820399658, -317514155)), (double)10.0F, (double)1.0F, (double)40.0F, (double)1.0F)).IIIl(lIlIII.l(IlII(1820399659, -1404356307))));
   private int l = IIll(1477721114, 863644399);
   private boolean II;
   private int Il = IIll(1477721113, -1703895698);
   private int lI = IIll(1477721112, -2056314623);
   private static final int[] ll;
   private static final String[] III;
   private static final Object[] IIl;

   private boolean II(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         class_1268 var2 = this.ll(var1);
         if (var2 == null) {
            return false;
         } else {
            class_1799 var3 = var2 == class_1268.field_5810 ? var1.field_1724.method_6079() : var1.field_1724.method_6047();
            return var3 != null && !var1.field_1724.method_7357().method_7904(var3);
         }
      } else {
         return false;
      }
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (var1 != null && var1.field_1724 != null && var1.field_1724.method_5805() && var1.field_1755 == null) {
         this.llI(var1);
      } else {
         if (this.II) {
            this.IIII(var1);
         }

      }
   }

   private class_1268 ll(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         class_1799 var2 = var1.field_1724.method_6079();
         if (var2 != null && var2.method_31574(class_1802.field_8255)) {
            return class_1268.field_5810;
         } else {
            class_1799 var3 = var1.field_1724.method_6047();
            return var3 != null && var3.method_31574(class_1802.field_8255) ? class_1268.field_5808 : null;
         }
      } else {
         return null;
      }
   }

   public void III(class_1297 var1) {
      class_310 var2 = class_310.method_1551();
      if (var2 != null && (this.II || var2.field_1724 != null && var2.field_1724.method_6115())) {
         this.IIII(var2);
         IllllIlI.IlI(var2, 2);
      }

   }

   private boolean IlI(class_310 var1) {
      if (var1 != null && var1.field_1690 != null) {
         return var1.field_1690.field_1886.method_1434() || IllllIlI.lIlllI(0) || IllllIlI.IlIIlIl(0) || IllllIlI.IllIlI(var1.field_1690.field_1886) > 0 || IllllIlI.IIIll(var1, var1.field_1690.field_1886);
      } else {
         return false;
      }
   }

   public IIlIlll() {
      super((Object)lIlIII.l(IlII(1820399656, -157538899)), lIllII.I, (Object)lIlIII.l(IlII(1820399657, -996736752)));
   }

   public void lIlI(class_1297 var1) {
      class_310 var2 = class_310.method_1551();
      if (var1 != null && var2 != null && var2.field_1724 != null && var2.field_1724.method_5805()) {
         if (this.II(var2)) {
            this.lI = var2.field_1724.field_6012;
            int var3 = Math.max(1, (int)Math.round((Double)this.I.III()));
            this.Il = var2.field_1724.field_6012 + 1;
            this.l = var2.field_1724.field_6012 + 1 + var3;
         }
      }
   }

   private boolean lII(class_310 var1) {
      if (this.IIIIIlI() && var1 != null && var1.field_1724 != null && var1.field_1761 != null && var1.field_1690 != null && var1.field_1755 == null && var1.field_1724.method_5805()) {
         if (!IllllIlI.lIIIll(var1) && !this.IlI(var1)) {
            if (var1.field_1724.method_6115() && !var1.field_1724.method_6030().method_31574(class_1802.field_8255)) {
               return false;
            } else {
               return IllllIlI.IIIll(var1, var1.field_1690.field_1904) && var1.field_1724.method_6047().method_31574(class_1802.field_8463) ? false : this.II(var1);
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public void lI() {
      this.IIII(class_310.method_1551());
   }

   private void llI(class_310 var1) {
      if (this.IIIIIlI() && var1 != null && var1.field_1724 != null && var1.field_1724.method_5805() && var1.field_1755 == null) {
         if (this.II && this.IIIl(var1)) {
            this.IIII(var1);
            IllllIlI.IlI(var1, 2);
         } else if (this.l != IIll(1477721115, 1755556343) && var1.field_1724.field_6012 >= this.l) {
            this.IIII(var1);
         } else {
            if (this.Il != IIll(1477721116, 909703727) && var1.field_1724.field_6012 >= this.Il && var1.field_1724.field_6012 < this.l) {
               if (!this.II(var1) || IllllIlI.lIIIll(var1) || this.IlI(var1)) {
                  this.IIII(var1);
                  return;
               }

               if (this.II && var1.field_1724.method_6115()) {
                  var1.field_1690.field_1904.method_23481(true);
               } else {
                  this.lll(var1);
               }
            }

         }
      } else {
         if (this.II) {
            this.IIII(var1);
         }

      }
   }

   private void lll(class_310 var1) {
      if (this.lII(var1)) {
         class_1268 var2 = this.ll(var1);
         if (var2 != null) {
            IllllIlI.lIllll(var1);
            if (IllllIlI.IllIIl(var1, var2)) {
               var1.field_1690.field_1904.method_23481(true);
               this.II = true;
            }

         }
      }
   }

   private void IIII(class_310 var1) {
      this.II = false;
      this.Il = IIll(1477721117, -1958694810);
      this.l = IIll(1477721118, 2042977945);
      this.lI = IIll(1477721119, -718001657);
      if (var1 != null && var1.field_1724 != null && var1.field_1690 != null) {
         var1.field_1690.field_1904.method_23481(false);
         if (var1.field_1761 != null && var1.field_1724.method_6115() && var1.field_1724.method_6030().method_31574(class_1802.field_8255)) {
            var1.field_1761.method_2897(var1.field_1724);
         }

      }
   }

   private boolean IIIl(class_310 var1) {
      if (var1 != null && var1.field_1724 != null && var1.field_1690 != null) {
         if (IllllIlI.lIIIll(var1)) {
            return true;
         } else if (this.IlI(var1)) {
            return true;
         } else {
            IIllIlII var2 = lIllIIl.Il() == null ? null : lIllIIl.Il().IIl();
            if (var2 == null || (var2.IIIllll() == null || !var2.IIIllll().llI()) && (var2.lIIl() == null || !var2.lIIl().IIlll()) && (var2.llllII() == null || !var2.llllII().lllI())) {
               return IlIlIl.IIIIll();
            } else {
               return true;
            }
         }
      } else {
         return true;
      }
   }

   public void lllIl(class_310 var1) {
      this.llI(var1);
   }

   public void IllI(class_310 var1) {
      this.llI(var1);
   }

   public int IlIlI() {
      return IIll(1477721104, 1256652253);
   }

   private static int IIll(int var0, int var1) {
      return ll[var0 ^ 1477721112] ^ var1 ^ var0;
   }

   static {
      short var6 = 11512;
      String var7 = "쉆숚쉼슁쉒싁숸싙슇슶싴쉫숞숆슯슃\uf04d\uf011\uf077\uf08a\uf059\uf0cb\uf011\uf0e3\uf089\uf0ad\uf0c5\uf057\uf012\uf016\uf0d7\uf0e3\uf02a\uf06c\uf097\uf014\uf00e\uf01f\uf0a3\uf0b6\uf034\uf046\uf009\uf00f\uf05f\uf071\uf047\uf0c5\uf050\uf01d\uf058\uf09a\uf06a\uf0c4\uf02d\uf0d6\uf0e8\uf0da\uf0d1\uf061\uf060\uf009\uf0fc\uf0e0\uf029\uf05a\uf08d\uf03a\uf027\uf064\uf087\uf0b4\uf00c\uf04a\uf000\uf01e\uf07c\uf047\uf049\uf0ed\uf052\uf038\uf077\uf08c\uf05a\uf0e5\uf02f\uf0d2\uf08c\uf0be\uf0f8\uf058\ud9cf\ud986\ud9c1\ud916\ud9db\ud976\ud9fa\ud90d颎飞飜顏颂領飰顕";
      char[] var8 = "⳨Ⲵ⳰⳰".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            III = var9;
            IIl = new Object[var9.length];
            int var2 = -1923885477;
            byte[] var0 = "Ð(ËBÏ7w,f=À®=äC·c\u007f\u0010hÞ\u0007Z ,\u0082´Ü\u0080sÀC\u009f¡\u001c\u0010".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            ll = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               ll[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static String IlII(int var0, int var1) {
      int var3 = var0 ^ 1820399656;
      char[] var4 = III[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IIl[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IIl[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -1270048185;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 97;
               break;
            case 1:
               var9 = 17;
               break;
            case 2:
               var9 = 104;
               break;
            case 3:
               var9 = 146;
               break;
            case 4:
               var9 = 107;
               break;
            case 5:
               var9 = 234;
               break;
            case 6:
               var9 = 26;
               break;
            case 7:
               var9 = 237;
               break;
            case 8:
               var9 = 130;
               break;
            case 9:
               var9 = 182;
               break;
            case 10:
               var9 = 203;
               break;
            case 11:
               var9 = 91;
               break;
            case 12:
               var9 = 8;
               break;
            case 13:
               var9 = 21;
               break;
            case 14:
               var9 = 192;
               break;
            case 15:
               var9 = 236;
               break;
            case 16:
               var9 = 53;
               break;
            case 17:
               var9 = 69;
               break;
            case 18:
               var9 = 158;
               break;
            case 19:
               var9 = 0;
               break;
            case 20:
               var9 = 57;
               break;
            case 21:
               var9 = 115;
               break;
            case 22:
               var9 = 189;
               break;
            case 23:
               var9 = 167;
               break;
            case 24:
               var9 = 56;
               break;
            case 25:
               var9 = 70;
               break;
            case 26:
               var9 = 105;
               break;
            case 27:
               var9 = 12;
               break;
            case 28:
               var9 = 82;
               break;
            case 29:
               var9 = 68;
               break;
            case 30:
               var9 = 38;
               break;
            case 31:
               var9 = 214;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
