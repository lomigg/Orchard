package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class IlIlIIII extends IIIIIIIlI {
   private static final String[] I;
   private static final Object[] l;

   public IlIlIIII() {
      super((Object)lIlIII.l(ll((short)'\ue2e2', '잩', 2118004431)), lIllII.ll, (Object)lIlIII.l(ll((short)23930, '잨', 291592084)));
   }

   static {
      short var0 = 21027;
      String var1 = "ꢮ꠫꡷ꢍꢿꢗꢌ\ua83c꽈ꢨ꽲\ua878\udee0\udea8\ud9a1\ud985\udec9\ud99f\udff8\ud987\ud9d2\ude22\ud9a7\ud988\ud9b0\ud9fe\udef8\ud985\ud9a1\ud998\ude2e\ude99\ude3c\udee3\udecb\ud98f\ud985\ud9d1\udfeb\ud9c9\ud9dc\uded0\ud9b9\ude97\udef9\ud9a0\udec3\ud9f2\ud999\ud9fd\ude38\ud9cd\ude3e\ud9a5\uded4\ud9cb\udeff\ude22\ud9bb\ude11";
      char[] var2 = "刯刓".toCharArray();
      String[] var3 = new String[var2.length];
      byte var7 = -1;

      while(true) {
         int var4 = 0;
         int var5 = 0;
         int var6 = 0;
         if (var7 == 0) {
            I = var3;
            l = new Object[var3.length];
            return;
         }

         do {
            var6 = var2[var4] ^ var0;
            char[] var8 = var1.substring(var5, var5 + var6).toCharArray();
            int var9 = 0;

            do {
               byte var10000;
               switch (var9 % 6) {
                  case 0:
                  default:
                     var10000 = 77;
                     break;
                  case 1:
                     var10000 = 4;
                     break;
                  case 2:
                     var10000 = 95;
                     break;
                  case 3:
                     var10000 = 79;
                     break;
                  case 4:
                     var10000 = 82;
                     break;
                  case 5:
                     var10000 = 112;
               }

               byte var10 = var10000;
               var8[var9] = (char)(var8[var9] ^ var10);
               ++var9;
            } while(var9 < var8.length);

            var3[var4] = (new String(var8)).intern();
            var5 += var6;
            ++var4;
         } while(var4 < var2.length);

         var7 = 0;
      }
   }

   private static String ll(short var0, char var1, int var2) {
      int var3 = var1 ^ '잩';
      char[] var4 = I[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])l[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         l[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 8533;
      int var9 = 0;

      do {
         int var10 = var4[var9] ^ 19131;
         var10 -= 4149;
         var10 ^= 30878;
         var10 -= 42199;
         var10 += 24174;
         var10 ^= 3711;
         var10 += 16201;
         var10 ^= 249;
         var10 += 40585;
         var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var2 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
