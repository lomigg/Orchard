package x;

import com.mojang.authlib.GameProfile;
import java.lang.reflect.Field;
import java.util.List;
import java.util.UUID;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_5250;
import net.minecraft.class_640;
import net.minecraft.class_642;
import net.minecraft.class_7417;
import net.minecraft.class_8828;

@Environment(EnvType.CLIENT)
public final class Il {
   private static boolean I;
   private static Field l;
   private static final List<<undefinedtype>> II;
   private static final int[] Il;
   private static final String[] lI;
   private static final Object[] ll;

   public static void I() {
      if (!I) {
         I = true;
         ClientPlayConnectionEvents.JOIN.register((ClientPlayConnectionEvents.Join)(var0, var1, var2) -> {
            if (!IlIllIII.l()) {
               class_642 var3 = var0.method_45734();
               if (var3 != null && lllIlIl.II(var3.field_3761)) {
                  var0.method_48296().method_10747(class_2561.method_43470(lIlIII.Il(lIlI(646834550, -790615159))));
               } else {
                  IlIl(lll());
               }
            }
         });
      }
   }

   public static boolean l(class_1657 var0) {
      return var0 != null && lIII(var0.method_5667());
   }

   public static boolean II(UUID var0) {
      return ll(var0) && lll() != null;
   }

   public static class_2561 Il(class_2561 var0) {
      if (var0 == null) {
         return null;
      } else {
         <undefinedtype> var1 = Illl(var0, true);
         return var1.l() ? var1.I() : var0;
      }
   }

   private static boolean ll(UUID var0) {
      return lIII(var0);
   }

   public static class_2561 III(class_1657 var0, class_2561 var1) {
      IIIIIl var2 = lll();
      return var2 != null && var0 != null && var2.ll(var0) ? Il(var1) : var1;
   }

   private static UUID IIl(Object var0) {
      if (var0 == null) {
         return null;
      } else {
         try {
            if (l == null || l.getDeclaringClass() != var0.getClass()) {
               l = var0.getClass().getDeclaredField(lIlIII.Il(lIlI(646834551, 305030947)));
               l.setAccessible(true);
            }

            Object var1 = l.get(var0);
            UUID var10000;
            if (var1 instanceof class_1297) {
               class_1297 var2 = (class_1297)var1;
               var10000 = var2.method_5667();
            } else {
               var10000 = null;
            }

            return var10000;
         } catch (Exception var3) {
            return null;
         }
      }
   }

   public static class_2561 IlI(class_640 var0, class_2561 var1) {
      IIIIIl var2 = lll();
      return var2 != null && var0 != null && var2.lll(var0.method_2966()) ? Il(var1) : var1;
   }

   static void Ill() {
      l = null;
   }

   private static String lII(String var0) {
      String var1 = var0;

      boolean var2;
      do {
         var2 = false;

         for(<undefinedtype> var4 : II) {
            String var5 = var4.lIlI();
            if (IlII(var1, var5)) {
               int var6;
               for(var1 = var1.substring(var5.length()); !var1.isEmpty(); var1 = var1.substring(Character.charCount(var6))) {
                  var6 = var1.codePointAt(0);
                  if (!Character.isWhitespace(var6) && !Character.isSpaceChar(var6) && var6 != lIIl(-1766257542, 1537105697)) {
                     break;
                  }
               }

               var2 = true;
            }
         }
      } while(var2);

      return var1;
   }

   public static boolean lIl(GameProfile var0) {
      return var0 != null && lIII(IIIIlII.I(var0));
   }

   private static boolean llI(class_2561 var0) {
      class_7417 var2 = var0.method_10851();
      boolean var10000;
      if (var2 instanceof class_8828 var1) {
         if (var1.comp_737().isEmpty()) {
            var10000 = true;
            return var10000;
         }
      }

      var10000 = false;
      return var10000;
   }

   private static IIIIIl lll() {
      lIllIIl var0 = lIllIIl.Il();
      if (var0 == null) {
         return null;
      } else {
         IIIIIl var1 = var0.IIl().IIlIlII();
         return var1 != null && var1.IIIIIlI() ? var1 : null;
      }
   }

   private static <undefinedtype> IIII(String var0) {
      if (var0 != null && !var0.isEmpty()) {
         int var1 = 0;
         boolean var2 = false;

         while(var1 < var0.length()) {
            int var3 = var0.codePointAt(var1);
            if (!IIlI(var3)) {
               break;
            }

            var2 = true;

            int var4;
            for(var1 += Character.charCount(var3); var1 < var0.length(); var1 += Character.charCount(var4)) {
               var4 = var0.codePointAt(var1);
               if (!Character.isWhitespace(var4) && !Character.isSpaceChar(var4)) {
                  break;
               }

               var2 = true;
            }
         }

         String var7 = var0.substring(var1);
         String var8 = lII(var7);

         for(var2 |= !var8.equals(var7); !var8.isEmpty(); var2 = true) {
            int var5 = var8.codePointAt(0);
            if (!Character.isWhitespace(var5) && !Character.isSpaceChar(var5) && var5 != lIIl(-1766257541, -589044040) && var5 != lIIl(-1766257544, -395182928)) {
               break;
            }

            var8 = var8.substring(Character.charCount(var5));
         }

         return new Record(var8, var2, var8.isBlank()) {
            private final String I;
            private final boolean l;
            private final boolean II;

            public String I() {
               return this.I;
            }

            private {
               this.I = var1;
               this.l = var2;
               this.II = var3;
            }

            public boolean l() {
               return this.l;
            }

            public boolean II() {
               return this.II;
            }
         };
      } else {
         return new Record("", false, true) {
            private final String I;
            private final boolean l;
            private final boolean II;

            public String I() {
               return this.I;
            }

            private {
               this.I = var1;
               this.l = var2;
               this.II = var3;
            }

            public boolean l() {
               return this.l;
            }

            public boolean II() {
               return this.II;
            }
         };
      }
   }

   public static boolean IIIl(Object var0) {
      return II(IIl(var0));
   }

   private static boolean IIlI(int var0) {
      return var0 == lIIl(-1766257543, 2144851568) || var0 == lIIl(-1766257538, -1048477677) || var0 >= lIIl(-1766257537, -1317915879) && var0 <= lIIl(-1766257540, 2131616226) || var0 >= lIIl(-1766257539, 1800960994) && var0 <= lIIl(-1766257550, 1103412188) || var0 >= lIIl(-1766257549, 1845480167) && var0 <= lIIl(-1766257552, -2006947155);
   }

   public static class_2561 IIll(Object var0, class_2561 var1) {
      IIIIIl var2 = lll();
      return var2 != null && var2.I(IIl(var0)) ? Il(var1) : var1;
   }

   private static boolean IlII(String var0, String var1) {
      return var0.regionMatches(true, 0, var1, 0, var1.length());
   }

   public static void IlIl(IIIIIl var0) {
   }

   public static boolean IllI(UUID var0) {
      return lIII(var0);
   }

   private static <undefinedtype> Illl(class_2561 var0, boolean var1) {
      Object var2 = var0.method_10851();
      boolean var3 = false;
      boolean var4;
      if (var1 && lIIllllI.Illl(var0.method_10866())) {
         var4 = false;
      } else if (var1 && var2 instanceof class_8828) {
         class_8828 var5 = (class_8828)var2;
         <undefinedtype> var6 = IIII(var5.comp_737());
         if (var6.l()) {
            var2 = class_8828.method_54232(var6.I());
            var3 = true;
         }

         var4 = var6.II();
      } else if (var1 && llI(var0)) {
         var4 = true;
      } else {
         var4 = false;
      }

      class_5250 var9 = class_5250.method_43477((class_7417)var2).method_10862(var0.method_10866());

      for(class_2561 var7 : var0.method_10855()) {
         <undefinedtype> var8 = Illl(var7, var4);
         var9.method_10852(var8.I());
         var3 |= var8.l();
         var4 = var8.II();
      }

      return new Record((class_2561)(var3 ? var9 : var0), var3, var4) {
         private final boolean I;
         private final boolean l;
         private final class_2561 II;

         private {
            this.II = var1;
            this.l = var2;
            this.I = var3;
         }

         public class_2561 I() {
            return this.II;
         }

         public boolean l() {
            return this.l;
         }

         public boolean II() {
            return this.I;
         }
      };
   }

   static {
      short var6 = 28270;
      String var7 = "쏛쎇쏈쎐썫쏚쌹쌪쌤썴쌣쌵쏌썺쎭쏘썖쎗쎚썿ďŢğżƦļƍǹ㰄㰅㰍㱵㲫㰏㳞㳺㳕㲦㲢㲦ퟓퟒퟸힲ흹ퟡ흐휍휶흱흾휽똅똄똮뙠뚯똁뛃뛘뛣뚏뛛뚧";
      char[] var8 = "\u0014\b\f\f\f".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            lI = var9;
            ll = new Object[var9.length];
            int var2 = -313522442;
            byte[] var0 = " wu¤§\nÌ<\u0093\u0098ö\u009e\u0004>=ÿºhh\u009bÊ\u009bÛ\u0091\u0004ä\t`\u0010±\u0092i:-RR\u0016\u0016 bó\u0089\u0098Ô".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            Il = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               Il[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            II = List.of(lIlIII.l(lIlI(646834548, -1556933187)), lIlIII.l(lIlI(646834549, 1222913941)), lIlIII.l(lIlI(646834546, 691174674)));
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 67;
                     break;
                  case 1:
                     var10000 = 104;
                     break;
                  case 2:
                     var10000 = 28;
                     break;
                  case 3:
                     var10000 = 15;
                     break;
                  case 4:
                     var10000 = 61;
                     break;
                  case 5:
                     var10000 = 119;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private Il() {
   }

   private static boolean lIII(UUID var0) {
      if (var0 == null) {
         return false;
      } else {
         class_310 var1 = class_310.method_1551();
         if (var1.field_1724 == null) {
            return false;
         } else if (var0.equals(var1.field_1724.method_5667())) {
            return true;
         } else {
            UUID var2 = IIIIlII.I(var1.field_1724.method_7334());
            return var2 != null && var0.equals(var2);
         }
      }
   }

   private static int lIIl(int var0, int var1) {
      return Il[var0 ^ -1766257542] ^ var1 ^ var0;
   }

   private static String lIlI(int var0, int var1) {
      int var3 = var0 ^ 646834550;
      char[] var4 = lI[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])ll[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         ll[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 2060287268;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 112;
               break;
            case 1:
               var9 = 2;
               break;
            case 2:
               var9 = 33;
               break;
            case 3:
               var9 = 96;
               break;
            case 4:
               var9 = 165;
               break;
            case 5:
               var9 = 72;
               break;
            case 6:
               var9 = 173;
               break;
            case 7:
               var9 = 140;
               break;
            case 8:
               var9 = 243;
               break;
            case 9:
               var9 = 160;
               break;
            case 10:
               var9 = 250;
               break;
            case 11:
               var9 = 180;
               break;
            case 12:
               var9 = 86;
               break;
            case 13:
               var9 = 214;
               break;
            case 14:
               var9 = 29;
               break;
            case 15:
               var9 = 26;
               break;
            case 16:
               var9 = 181;
               break;
            case 17:
               var9 = 14;
               break;
            case 18:
               var9 = 1;
               break;
            case 19:
               var9 = 183;
               break;
            case 20:
               var9 = 168;
               break;
            case 21:
               var9 = 225;
               break;
            case 22:
               var9 = 103;
               break;
            case 23:
               var9 = 69;
               break;
            case 24:
               var9 = 193;
               break;
            case 25:
               var9 = 58;
               break;
            case 26:
               var9 = 158;
               break;
            case 27:
               var9 = 165;
               break;
            case 28:
               var9 = 59;
               break;
            case 29:
               var9 = 143;
               break;
            case 30:
               var9 = 84;
               break;
            case 31:
               var9 = 82;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
