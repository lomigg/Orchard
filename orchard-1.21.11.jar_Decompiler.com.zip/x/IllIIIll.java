package x;

import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_465;
import y.lIlIIIl;

@Environment(EnvType.CLIENT)
public final class IllIIIll extends IIIIIIIlI {
   private long I;
   private static final long l = 120L;
   private final lIIIIl II = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lll((short)5608, -91024820, '鳊')), true));
   private static final int Il = 40;
   private int lI = -1;
   private int ll = -1;
   private final IIIllIIII III = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(lll((short)19405, 1571386334, '鳋')), (double)1.0F, (double)1.0F, (double)9.0F, (double)1.0F));
   private long IIl;
   private final llllIlIl IlI = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(lll((short)'肃', 331175095, '鳌')), (double)0.0F, (double)0.0F, (double)0.0F, (double)500.0F, (double)5.0F)).Ill(lIlIII.l(lll((short)'\uf6f1', 346359681, '鳍'))));
   private long Ill;
   private static final int[] lII;
   private static final String[] lIl;
   private static final Object[] llI;

   public void lllIl(class_310 var1) {
      this.lII(var1);
   }

   private long ll() {
      double var1 = this.IlI.IlII();
      double var3 = this.IlI.IlI();
      return var3 <= var1 ? (long)Math.max((double)0.0F, var1) : (long)(var1 + ThreadLocalRandom.current().nextDouble() * (var3 - var1));
   }

   private void IlI() {
      this.lI = -1;
      this.IIl = 0L;
      this.I = 0L;
   }

   private void lII(class_310 var1) {
      if (var1 != null && var1.field_1724 != null && var1.field_1761 != null) {
         class_437 var3 = var1.field_1755;
         if (var3 instanceof class_465) {
            class_465 var2 = (class_465)var3;
            class_1703 var9 = var2.method_17577();
            if (var9 != null && var9.method_34255().method_7960()) {
               class_1735 var4 = ((lIlIIIl)var2).q96fbb2be();
               if (var4 != null && var4.field_7874 >= 0 && var4.method_7681() && var4.method_7677().method_31574(class_1802.field_8288)) {
                  boolean var5 = var1.field_1724.method_6079().method_31574(class_1802.field_8288);
                  int var6 = -1;
                  if (!var5) {
                     var6 = llI(2106712400, -1333173191);
                  } else if ((Boolean)this.II.III()) {
                     int var7 = (int)Math.round((Double)this.III.III()) - 1;
                     if (var7 >= 0 && var7 < llI(2106712401, 2047743688)) {
                        class_1799 var8 = var1.field_1724.method_31548().method_5438(var7);
                        if (!var8.method_31574(class_1802.field_8288) && (var4.field_7871 != var1.field_1724.method_31548() || var4.method_34266() != var7)) {
                           var6 = var7;
                        }
                     }
                  }

                  if (var6 == -1) {
                     this.IlI();
                     return;
                  }

                  long var10 = System.currentTimeMillis();
                  if (var4.field_7874 != this.lI) {
                     this.lI = var4.field_7874;
                     this.IIl = var10;
                     this.I = this.ll();
                  }

                  if (var10 - this.IIl < this.I) {
                     return;
                  }

                  if (var4.field_7874 == this.ll && var10 - this.Ill < 120L + this.I) {
                     return;
                  }

                  if (!lIlIllll.III(var1)) {
                     return;
                  }

                  var1.field_1761.method_2906(var9.field_7763, var4.field_7874, var6, class_1713.field_7791, var1.field_1724);
                  this.ll = var4.field_7874;
                  this.Ill = var10;
                  return;
               }

               this.IlI();
               return;
            }

            return;
         }
      }

      this.IlI();
   }

   public void lI() {
      this.IlI();
      this.ll = -1;
      this.Ill = 0L;
   }

   public void Ill() {
      this.lII(class_310.method_1551());
   }

   public IllIIIll() {
      super((Object)lIlIII.l(lll((short)23754, 1212569324, '鳎')), lIllII.l, (Object)lIlIII.l(lll((short)31904, -605486345, '鳏')));
   }

   private static int llI(int var0, int var1) {
      return lII[var0 ^ 2106712400] ^ var1 ^ var0;
   }

   static {
      short var6 = 20380;
      String var7 = "᱾ᱥᲿᱮ\u1cc8ᲜᲿ᳅Დ᳂᳄ᲞᱭᲜᲸᲸ겁ꭚ검ꬨ겇ꬲ겈ꭚꬢꬲꬱꬥꬡꬪꬲ겎ꬱ게ꬾ겎겉ꬪꬷꬨꬮꬪꬿꭚꭘꬿ\uaaf8ꬩ겉겈걿겏ꭘ꭛ꭅꬨꭀꭗ걿게것ꬢ겅ꫳ軯軳輿轆輗轎軾輪\udf7f\ue22c\ue236\ue250\ue32f\ue338\ue32e\ue481\ue354\ue35a\ue35a\ue33c\ue33d\ue47f\ue2ec\ue48f\ue33e\ue332\ue488\ue48c\ue481\ue32b\ue2e5\ue2e5๔๓ᮉึฯีูลᮈᮆ෮ลᮅท๖\u0de0";
      char[] var8 = "侌侬侔侘侈侌".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            lIl = var9;
            llI = new Object[var9.length];
            int var2 = 489677066;
            byte[] var0 = "Ð7dK\u001a°\u0016\u009a".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lII = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lII[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static String lll(short var0, int var1, char var2) {
      int var3 = var2 ^ '鳎';
      char[] var4 = lIl[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])llI[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         llI[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 13143;
      int var9 = 0;

      do {
         int var10 = var4[var9] + 27425;
         var10 ^= 63838;
         var10 -= 25602;
         var10 -= 56999;
         var10 += 58019;
         var10 += 23865;
         var10 += 26081;
         var10 ^= 31137;
         var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
