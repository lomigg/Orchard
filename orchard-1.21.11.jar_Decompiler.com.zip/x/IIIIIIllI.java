package x;

import java.awt.Color;
import java.lang.reflect.Method;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5250;

@Environment(EnvType.CLIENT)
public class IIIIIIllI {
   private static final <undefinedtype> I;
   private static final double l = (double)2.0F;
   private static double II;
   private static final float Il = 0.0025F;
   private static final Map<Long, <undefinedtype>> lI;
   private static final ThreadLocal<Deque<<undefinedtype>>> ll;
   private static final Method III;
   private static final ThreadLocal<Boolean> IIl;
   private static final long IlI = 4200L;
   private static final float Ill = 0.075F;
   private static final int[] lII;
   private static final String[] lIl;
   private static final Object[] llI;

   public static double I() {
      return Il() * 2.15;
   }

   public static void l(class_332 var0, class_327 var1, class_2561 var2, double var3, double var5, double var7, int var9) {
      lIIll(var0, var1, var2, var3, var5 + (var7 - lllIII(var1)) / (double)2.0F, var9);
   }

   public static void II(double var0) {
      II = Math.max((double)0.0F, var0);
   }

   public static double Il() {
      return Math.max((double)6.0F, I.l() - I.I());
   }

   public static void lI(class_332 var0, class_327 var1, String var2, double var3, double var5, int var7) {
      if (lIIIlIIl.Ill()) {
         llIl(var0, var1, var2, var3 - (double)IlIl(var1, var2), var5, var7);
      } else {
         class_2561 var8 = lIIIllll.llIlI(var2);
         Ill(var0, var1, var8, var3 - (double)lII(var1, var8), var5, var7, false);
      }
   }

   public static void ll(class_332 var0, double var1, double var3, double var5, double var7, double var9, int var11, int var12) {
      int var13 = var11 >>> lllIIl(227094893, -496928699) & lllIIl(227094892, 811585974);
      int var14 = var12 >>> lllIIl(227094895, -1450975849) & lllIIl(227094894, -121004902);
      if (var13 > 0 || var14 > 0) {
         <undefinedtype> var15 = lIIIll(var1, var3, var5, var7, var9, (double)0.0F);
         if (var15.l()) {
            int var16 = var5 < (double)0.0F ? var12 : var11;
            int var17 = var5 < (double)0.0F ? var11 : var12;
            IIIlIlIIl.IIllI(var0, var15.Il(), var15.III(), var15.II(), var15.lI(), var15.ll(), var16, var17);
         }
      }
   }

   private static double III(double var0, double var2, boolean var4) {
      long var5 = IlI(var0, var2);
      long var7 = System.nanoTime();
      double var9 = var4 ? (double)1.0F : (double)0.0F;
      <undefinedtype> var11 = (<undefinedtype>)lI.get(var5);
      if (var11 == null) {
         lI.put(var5, new Record(var9, var7) {
            private final double I;
            private final long l;

            public long I() {
               return this.l;
            }

            public double l() {
               return this.I;
            }

            private {
               this.I = var1;
               this.l = var3;
            }
         });
         return var9;
      } else {
         double var12 = Math.min(0.05, Math.max((double)0.0F, (double)(var7 - var11.I()) / (double)1.0E9F));
         double var14 = (double)1.0F - Math.pow(0.001, var12 / 0.16);
         double var16 = var11.l() + (var9 - var11.l()) * Math.max((double)0.0F, Math.min((double)1.0F, var14));
         if (Math.abs(var16 - var9) < 0.002) {
            var16 = var9;
         }

         lI.put(var5, new Record(var16, var7) {
            private final double I;
            private final long l;

            public long I() {
               return this.l;
            }

            public double l() {
               return this.I;
            }

            private {
               this.I = var1;
               this.l = var3;
            }
         });
         return var16;
      }
   }

   public static void IIl(Boolean var0) {
      if (var0 == null) {
         IIl.remove();
      } else {
         IIl.set(var0);
      }

   }

   private static long IlI(double var0, double var2) {
      long var4 = Math.round(var0 * (double)4.0F);
      long var6 = Math.round(var2 * (double)4.0F);
      return var4 << lllIIl(227094889, 7463903) ^ var6 & 4294967295L;
   }

   private static void Ill(class_332 var0, class_327 var1, class_2561 var2, double var3, double var5, int var7, boolean var8) {
      if (var0 != null && var1 != null && var2 != null && Double.isFinite(var3) && Double.isFinite(var5)) {
         int var9 = (int)Math.round(var3);
         int var10 = (int)Math.round(var5);
         if (IIIIIl(var7, var2)) {
            lll(var0, var1, var2, var9, var10, var7, var8);
         } else {
            IlIIl(var0, var1, var2, var9, var10, var7, var8);
         }
      }
   }

   public static int lII(class_327 var0, class_2561 var1) {
      return var0.method_27525(lIIIllll.IlII(var1));
   }

   public static void lIl(class_332 var0, class_327 var1, String var2, double var3, double var5, double var7, double var9, int var11) {
      lIlII(var0, var1, var2, var3 + var7 / (double)2.0F, var5 + var9 / (double)2.0F, var11);
   }

   public static void llI(class_332 var0, double var1, double var3, double var5, double var7, double var9, int var11, double var12, int var14, double var15) {
      if (var0 != null && !(var5 <= (double)0.0F) && !(var7 <= (double)0.0F) && !(var12 <= (double)0.0F) && var14 > 0 && !(var15 <= (double)0.0F) && (var11 >>> lllIIl(227094888, -2483128) & lllIIl(227094891, -2120886560)) > 0) {
         int var17 = var11 >>> lllIIl(227094890, -795831914) & lllIIl(227094885, -1338190172);
         int var18 = (int)Math.round((double)var17 * IIIIlI.Il(var15));
         if (var18 > 0) {
            int var19 = var18 << lllIIl(227094884, 995900817) | var11 & lllIIl(227094887, -834562847);
            IIIlIlIIl.lIll(var0, var1, var3, var5, var7, var9, var12, var19);
         }
      }
   }

   private static void lll(class_332 var0, class_327 var1, class_2561 var2, int var3, int var4, int var5, boolean var6) {
      String var7 = var2.getString();
      int var8 = var5 >>> lllIIl(227094886, -247969904) & lllIIl(227094881, -1419622689);
      double var9 = (double)var3;
      int var11 = 0;

      for(int var12 = 0; var12 < var7.length(); ++var11) {
         int var13 = var7.codePointAt(var12);
         String var14 = new String(Character.toChars(var13));
         class_5250 var15 = class_2561.method_43470(var14).method_10862(var2.method_10866());
         if (!Character.isWhitespace(var13)) {
            int var16 = lIIlI(var8, var3, var4, var11);
            IlIIl(var0, var1, var15, (int)Math.round(var9), var4, var16, var6);
         }

         var9 += (double)var1.method_27525(var15);
         var12 += Character.charCount(var13);
      }

   }

   public static void IIII(class_332 var0, class_327 var1, class_2561 var2, double var3, double var5, int var7) {
      class_2561 var8 = lIIIllll.IlII(var2);
      Ill(var0, var1, var8, var3 - (double)lII(var1, var8), var5, var7, false);
   }

   public static void IIIl(class_332 var0, class_327 var1, String var2, double var3, double var5, int var7) {
      if (lIIIlIIl.Ill()) {
         llII(var0, var1, var2, var3 - (double)IlIl(var1, var2), var5, var7);
      } else {
         class_2561 var8 = lIIIllll.llIlI(var2);
         Ill(var0, var1, var8, var3 - (double)lII(var1, var8), var5, var7, true);
      }
   }

   public static void IIlI(class_332 var0, class_327 var1, String var2, double var3, double var5, double var7, double var9, double var11, int var13) {
      double var14 = Math.max((double)0.0F, var7 - var11 * (double)2.0F);
      lIl(var0, var1, lIlIlI(var1, var2, var14), var3 + var11, var5, var14, var9, var13);
   }

   public static void IIll(class_332 var0, double var1, double var3, double var5, double var7, double var9, double var11, int var13) {
      if ((var13 >>> lllIIl(227094880, -1700268215) & lllIIl(227094883, 1765228460)) > 0 && !(var11 <= (double)0.0F)) {
         <undefinedtype> var14 = lIIIll(var1, var3, var5, var7, var9, Math.max((double)0.5F, var11));
         if (var14.l()) {
            IIIlIlIIl.ll(var0, var14.Il(), var14.III(), var14.II(), var14.lI(), var14.ll(), var14.I(), var13);
         }
      }
   }

   public static void IlII(class_332 var0, double var1, double var3) {
      IIIlIlIIl.IllIl(var0, var1, var3);
   }

   static {
      short var6 = 2895;
      String var7 = "寑宭嬪审ᝤᜡកᜋ胻肌聲胀胰肊胿肙봥뵹붌봙봨뵒봧뵁쇢쇃섕손";
      char[] var8 = "\u0004\u0004\b\b\u0004".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            lIl = var9;
            llI = new Object[var9.length];
            int var2 = -799292788;
            byte[] var0 = "?³\u008b¼í\u008d\"©tQ.l%\u001bo\u0087Ý£\u0010\u001a\"\bï´\\G%ø\rBbhmî%²æ\u008eÎa\u0013l\u0098õ,ê´bv°µÍGu\u0004½´åÌ¼üÿð\u001d]?é<d\u001c!f.Ì\u001fý\u001e\u0084õ`RÔ\u009c\u0003|£uÃnf\u0089hËÍ£ÍÏPæp]ôPxï\u001f4\u0082±\rZ?ld@¦Î\u0097ê{¸øk\u0005Ð\u009cÔmR\u001e»à\u009aÈm\u0096\u0094ãN!xè\u0082eÌX=²N*Ý\u0099Ê¥1\u009dh(\u00ad°ì\u0082ü \u001bÝ.\u000b\u0007mj\u001d×[<\r¶.!\u0082.\u008b\u0097ÛLzq¶Ö¥q\u000b\u0004^1>\u009a»C>Bt{ª\u00ad*.\u0094¥1{»\u0086\u009d-eôÑ[á\u008a\u001eÍ\u008e>\u0094ûyn°\u000b!\u001b±³MÎ5¼\u009f·\u0090tl¤ý¡/¢\u0003i\u0007T\u0095¾\u008cNQÈÆ(ºÝ}þè×\u0002ãÊ?S¥ú¬Âºp!Y\u0080ÒT\u00adT\u001e\u0090Å<P\u000eºÃëS\u000bqá'2\u0092¯\u009aþÖí«\u0088býì\u0000o\u0019úê!.®Å\u008e1Å\u0006YpBº\u009bf*à½zNë]¼C k^¨Ç\u0000iD1\u000f©\u0096¦ÍuO\u0092°ã\u008c¨\r\u00830\u007f\u0089 \u009dJ*´{ÅØ\u0086i\u009f\u008dòµ\u0084ÖÇù¥û\u001aá\u009dÕ´~{\u009e\u0018!¬Cc\u0010\u0007\u009eQñ(¢'³k B\u0011\u001eh\u0007\u0014fhªl°?0\u00036\u0098ÃÐ\u0099|¡Ä\u009dåä\u0002qÇöòóÊ& )TÀ6Â\u0094©\u0017! PçÛ,\u0004\u001fnÈíÙèø\u0011Æ¿5ÛmZ¦*Â0ß\u008c{%".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lII = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lII[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            II = (double)1.0F;
            III = Illl();
            ll = ThreadLocal.withInitial(ArrayDeque::new);
            IIl = new ThreadLocal();
            lI = new HashMap();
            I = new Record((double)14.0F, (double)4.0F, (double)6.0F) {
               private final double I;
               private final double l;
               private final double II;

               public double I() {
                  return this.l;
               }

               public double l() {
                  return this.I;
               }

               public double II() {
                  return this.II;
               }

               public {
                  this.I = var1;
                  this.l = var3;
                  this.II = var5;
               }
            };
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 26;
                     break;
                  case 1:
                     var10000 = 121;
                     break;
                  case 2:
                     var10000 = 52;
                     break;
                  case 3:
                     var10000 = 1;
                     break;
                  case 4:
                     var10000 = 59;
                     break;
                  case 5:
                     var10000 = 105;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public static int IlIl(class_327 var0, String var1) {
      int var2 = lIIIlIIl.Il(var1);
      return var2 >= 0 ? var2 : var0.method_27525(lIIIllll.llIlI(var1));
   }

   public static void IllI(class_332 var0, double var1, double var3, double var5, double var7, int var9) {
      IllIll(var0, var1, var3, var5, var7, Math.min(Math.abs(var5), Math.abs(var7)) * (double)0.5F, var9);
   }

   private static Method Illl() {
      for(Method var3 : class_332.class.getMethods()) {
         Class[] var4 = var3.getParameterTypes();
         if (var4.length == lllIIl(227094882, 556598261) && var4[0] == class_327.class && var4[1] == class_2561.class && var4[2] == Integer.TYPE && var4[3] == Integer.TYPE && var4[4] == Integer.TYPE && var4[5] == Boolean.TYPE) {
            return var3;
         }
      }

      return null;
   }

   public static void lIII(class_332 var0) {
      if (var0 != null) {
         Deque var1 = (Deque)ll.get();
         if (!var1.isEmpty()) {
            var1.pop();
            var0.method_44380();
         }
      }
   }

   public static void lIIl(class_332 var0, double var1, double var3, double var5, double var7, int var9, int var10) {
      double var11 = Math.min(var1, var5);
      double var13 = Math.max(var1, var5);
      double var15 = Math.min(var3, var7);
      double var17 = Math.max(var3, var7);
      if (!(var13 <= var11) && !(var17 <= var15)) {
         IIIlIlIIl.IIllI(var0, var11, var15, var13 - var11, var17 - var15, (double)0.0F, var9, var10);
      }
   }

   private static int lIlI(int var0, int var1, double var2) {
      double var4 = Math.max((double)0.0F, Math.min((double)1.0F, var2));
      int var6 = (int)Math.round((double)(var0 >>> lllIIl(227094909, -2131944747) & lllIIl(227094908, -1177628055)) + (double)((var1 >>> lllIIl(227094911, -216077290) & lllIIl(227094910, -1017772435)) - (var0 >>> lllIIl(227094905, -1895403538) & lllIIl(227094904, -1586395448))) * var4);
      int var7 = (int)Math.round((double)(var0 >>> lllIIl(227094907, -1280017777) & lllIIl(227094906, 371151044)) + (double)((var1 >>> lllIIl(227094901, 310515097) & lllIIl(227094900, -2144951425)) - (var0 >>> lllIIl(227094903, 852346729) & lllIIl(227094902, 1826597178))) * var4);
      int var8 = (int)Math.round((double)(var0 >>> lllIIl(227094897, -1313426605) & lllIIl(227094896, 323295608)) + (double)((var1 >>> lllIIl(227094899, 1697290482) & lllIIl(227094898, 223225708)) - (var0 >>> lllIIl(227094861, -1882437591) & lllIIl(227094860, 1192926889))) * var4);
      int var9 = (int)Math.round((double)(var0 & lllIIl(227094863, 1227996445)) + (double)((var1 & lllIIl(227094862, -1522896552)) - (var0 & lllIIl(227094857, 294309512))) * var4);
      return var6 << lllIIl(227094856, -1812451771) | var7 << lllIIl(227094859, 393724490) | var8 << lllIIl(227094858, -1241883010) | var9;
   }

   public static void lIll(class_332 var0, double var1, double var3, double var5, double var7, double var9, int var11) {
      if ((var11 >>> lllIIl(227094853, 827330545) & lllIIl(227094852, -972038852)) > 0) {
         <undefinedtype> var12 = lIIIll(var1, var3, var5, var7, var9, (double)1.0F);
         if (var12.l()) {
            if (var12.ll() <= (double)0.0F) {
               llllI(var0, var12.Il(), var12.III(), var12.II(), var12.lI(), var12.I(), var11);
            } else {
               IIIlIlIIl.ll(var0, var12.Il(), var12.III(), var12.II(), var12.lI(), var12.ll(), var12.I(), var11);
            }
         }
      }
   }

   public static void llII(class_332 var0, class_327 var1, String var2, double var3, double var5, int var7) {
      if (!lIIIlIIl.ll(var0, var2, var3, var5, var7, true, IIIIIl(var7, class_2561.method_43470(var2 == null ? "" : var2)))) {
         Ill(var0, var1, lIIIllll.llIlI(var2), var3, var5, var7, true);
      }
   }

   public static void llIl(class_332 var0, class_327 var1, String var2, double var3, double var5, int var7) {
      if (!lIIIlIIl.ll(var0, var2, var3, var5, var7, false, IIIIIl(var7, class_2561.method_43470(var2 == null ? "" : var2)))) {
         Ill(var0, var1, lIIIllll.llIlI(var2), var3, var5, var7, false);
      }
   }

   public static void lllI(class_332 var0, double var1, double var3) {
      IIIlIlIIl.Illl(var0, var1, var3);
   }

   public static void llll(class_332 var0, class_327 var1, class_2561 var2, double var3, double var5, int var7) {
      class_2561 var8 = lIIIllll.IlII(var2);
      Ill(var0, var1, var8, var3 - (double)lII(var1, var8), var5, var7, true);
   }

   public static void IIIII(class_332 var0) {
      Deque var1 = (Deque)ll.get();
      if (var0 == null) {
         var1.clear();
      } else {
         while(!var1.isEmpty()) {
            var1.pop();
            var0.method_44380();
         }

      }
   }

   public static void IIIIl(class_332 var0, class_327 var1, String var2, double var3, double var5, double var7, double var9, double var11, int var13) {
      double var14 = Math.max((double)0.0F, var7 - var11 * (double)2.0F);
      IIIIII(var0, var1, lIlIlI(var1, var2, var14), var3 + var11, var5, var14, var9, var13);
   }

   public static void IIIlI(class_332 var0, double var1, double var3, double var5, double var7, double var9) {
      lllIl(var0, var1, var3, var5, var7, var9, lllIIl(227094855, 44153343), lllIIl(227094854, 1819684920));
   }

   public static Boolean IIIll(Boolean var0) {
      Boolean var1 = (Boolean)IIl.get();
      if (var0 == null) {
         IIl.remove();
      } else {
         IIl.set(var0);
      }

      return var1;
   }

   public static double IIlII() {
      return I.II();
   }

   public static void IIlIl(class_332 var0, double var1, double var3, boolean var5, int var6, int var7) {
      double var8 = Il();
      double var10 = I();
      double var12 = lIllll(III(var1, var3, var5));
      double var14 = Math.max((double)4.0F, var8 - 2.6);
      int var16 = IIIlllIII.lI(var6, Math.max(lllIIl(227094849, 1811730947), var6 >>> lllIIl(227094848, -212245489) & lllIIl(227094851, -1851227514)));
      int var17 = lIlI(var16, var6, var12);
      IllIll(var0, var1, var3, var10, var8, var8 * (double)0.5F, var17);
      double var18 = 1.3;
      double var20 = Math.max((double)0.0F, var10 - var14 - var18 * (double)2.0F);
      double var22 = var1 + var18 + var20 * var12;
      lIIII(var0, var22 + var14 * (double)0.5F, var3 + var8 * (double)0.5F, var14 * (double)0.5F, IIIlllIII.lI(var7, lllIIl(227094850, 192381483)));
   }

   public static void IIllI(class_332 var0, double var1, double var3, double var5, double var7, int var9, int var10, boolean var11) {
      double var12 = (double)12.0F;
      lllII(var0, var1, var3, var5, var7, var12, var10);
      IllIll(var0, var1 + (double)1.0F, var3 + (double)1.0F, var5 - (double)2.0F, var7 - (double)2.0F, Math.max((double)0.0F, var12 - (double)1.0F), var9);
      lIllIl(var0, var1 + (double)1.0F, var3 + (double)1.0F, var5 - (double)2.0F, Math.max((double)12.0F, var7 * (double)0.5F), Math.max((double)0.0F, var12 - (double)1.0F), var11 ? lllIIl(227094877, -1015857904) : lllIIl(227094876, 1234587409), lllIIl(227094879, -1621526650));
   }

   public static void IIlll(class_332 var0, class_327 var1, class_2561 var2, double var3, double var5, int var7) {
      Ill(var0, var1, lIIIllll.IlII(var2), var3, var5, var7, false);
   }

   public static void IlIII(class_332 var0, double var1, double var3, double var5, double var7, int var9) {
      IIIIll(var0, var1, var3, var1 + var5, var3 + var7, var9);
   }

   private static void IlIIl(class_332 var0, class_327 var1, class_2561 var2, int var3, int var4, int var5, boolean var6) {
      if (III != null) {
         try {
            Method var10000 = III;
            Object[] var10002 = new Object[lllIIl(227094878, 1895357760)];
            var10002[0] = var1;
            var10002[1] = var2;
            var10002[2] = var3;
            var10002[3] = var4;
            var10002[4] = var5;
            var10002[5] = var6;
            var10000.invoke(var0, var10002);
            return;
         } catch (ReflectiveOperationException var8) {
         }
      }

   }

   public static void IlIlI(class_332 var0, double var1, double var3, double var5, double var7, double var9, int var11) {
      if (var0 != null && (var11 >>> lllIIl(227094873, 2028177526) & lllIIl(227094872, 1531960910)) > 0 && !(var9 <= (double)0.0F)) {
         double var12 = var5 - var1;
         double var14 = var7 - var3;
         double var16 = Math.hypot(var12, var14);
         if (Double.isFinite(var16) && !(var16 < 0.001)) {
            IIIllI(var0);

            try {
               IlII(var0, var1, var3);
               IIlIlI(var0, Math.toDegrees(Math.atan2(var14, var12)));
               IIIlIlIIl.l(var0, (double)0.0F, var9 * (double)-0.5F, var16, var9, (double)0.0F, var11);
            } finally {
               lIIlIl(var0);
            }

         }
      }
   }

   private static void IlIll(class_332 var0, Object var1) {
      int var2 = (int)Math.floor(var1.I());
      int var3 = (int)Math.floor(var1.Il());
      int var4 = (int)Math.ceil(var1.l());
      int var5 = (int)Math.ceil(var1.II());
      var0.method_44379(var2, var3, Math.max(var2, var4), Math.max(var3, var5));
   }

   public static double IllII() {
      return I.I();
   }

   public static void IllIl(class_332 var0, class_2960 var1, double var2, double var4, double var6, double var8, int var10, int var11, int var12) {
      if ((var12 >>> lllIIl(227094875, 688105518) & lllIIl(227094874, 1473003175)) > 0 && var10 > 0 && var11 > 0) {
         IIIlIlIIl.IIll(var0, var1, (int)Math.round(var2), (int)Math.round(var4), (int)Math.round(var6), (int)Math.round(var8), var10, var11, var12);
      }
   }

   public static void IlllI(class_332 var0, double var1, double var3, double var5, double var7, double var9, double var11, int var13) {
      if ((var13 >>> lllIIl(227094869, -481949512) & lllIIl(227094868, -1285359610)) > 0 && !(var11 <= (double)0.0F)) {
         <undefinedtype> var14 = lIIIll(var1, var3, var5, var7, var9, var11);
         if (var14.l()) {
            IIIlIlIIl.lIlll(var0, var14.Il(), var14.III(), var14.II(), var14.lI(), var14.ll(), var14.I(), var13);
         }
      }
   }

   public static boolean Illll(class_332 var0, class_2960 var1, double var2, double var4, double var6, double var8, float var10, float var11, float var12, float var13, int var14, float var15) {
      return IIIlIlIIl.IlllI(var0, var1, var2, var4, var6, var8, var10, var11, var12, var13, var14, var15);
   }

   public static void lIIII(class_332 var0, double var1, double var3, double var5, int var7) {
      if ((var7 >>> lllIIl(227094871, -966573938) & lllIIl(227094870, 333926330)) > 0 && !(var5 <= (double)0.0F)) {
         IIIlIlIIl.IIII(var0, var1, var3, var5, var7);
      }
   }

   public static void lIIIl(class_332 var0, double var1, double var3, double var5, double var7) {
      IllIII(var0, var1, var3, var5, var7);
   }

   public static int lIIlI(int var0, int var1, int var2, int var3) {
      long var4 = System.currentTimeMillis();
      float var6 = (float)(var4 % 4200L) / 4200.0F;
      float var7 = (float)(var1 + var2) * 0.0025F;
      float var8 = (var6 + (float)var3 * 0.075F + var7) % 1.0F;
      if (var8 < 0.0F) {
         ++var8;
      }

      return var0 << lllIIl(227094865, 1782745001) | llIIll(var8) & lllIIl(227094864, 2043718924);
   }

   public static void lIIll(class_332 var0, class_327 var1, class_2561 var2, double var3, double var5, int var7) {
      Ill(var0, var1, lIIIllll.IlII(var2), var3, var5, var7, true);
   }

   public static void lIlII(class_332 var0, class_327 var1, String var2, double var3, double var5, int var7) {
      if (lIIIlIIl.Ill()) {
         llIl(var0, var1, var2, var3 - (double)IlIl(var1, var2) / (double)2.0F, var5 - lllIII(var1) / (double)2.0F, var7);
      } else {
         class_2561 var8 = lIIIllll.llIlI(var2);
         Ill(var0, var1, var8, var3 - (double)lII(var1, var8) / (double)2.0F, var5 - lllIII(var1) / (double)2.0F, var7, false);
      }
   }

   public static void lIlIl(class_332 var0, double var1, double var3, double var5, double var7, double var9, int var11, int var12, double var13) {
      if (!(var5 <= (double)0.0F) && !(var7 <= (double)0.0F) && !(var13 <= 0.01)) {
         double var15 = Math.max((double)0.0F, var9 - (double)0.5F);
         IllIll(var0, var1, var3, var5, var7, var9, var11);
         double var17 = Math.max((double)3.0F, var7 * 0.45);
         IllIll(var0, var1 + (double)0.5F, var3 + (double)0.5F, var5 - (double)1.0F, var17, var15, (int)Math.round((double)10.0F * var13) << lllIIl(227094867, 2144443072) | lllIIl(227094866, -1984384339));
         double var19 = Math.max((double)2.0F, var7 * 0.2);
         IllIll(var0, var1 + (double)0.5F, var3 + (double)0.5F, var5 - (double)1.0F, var19, var15, (int)Math.round((double)18.0F * var13) << lllIIl(227094829, -1820116097) | lllIIl(227094828, -174599902));
         double var21 = Math.max((double)2.0F, var7 * (double)0.25F);
         IllIll(var0, var1 + (double)0.5F, var3 + var7 - var21, var5 - (double)1.0F, var21, var15, (int)Math.round((double)12.0F * var13) << lllIIl(227094831, 591013049));
         lllII(var0, var1, var3, var5, var7, var9, (int)Math.round((double)28.0F * var13) << lllIIl(227094830, 1041812713) | lllIIl(227094825, 2027397272));
         int var23 = (int)Math.round((double)14.0F * var13);
         if (var23 > 0) {
            IllIll(var0, var1 + (double)1.0F, var3 + (double)1.0F, var5 - (double)2.0F, var7 - (double)2.0F, Math.max((double)0.0F, var9 - (double)1.0F), var23 << lllIIl(227094824, 1738724069) | var12 & lllIIl(227094827, 1577015541));
         }

      }
   }

   public static <undefinedtype> lIllI() {
      return I;
   }

   public static void lIlll(class_332 var0, double var1, double var3, double var5, double var7, double var9) {
      if (var0 != null) {
         double var11 = Math.max((double)0.0F, var9);
         <undefinedtype> var13 = null.lI(var1 - var11, var3 - var11, var5 + var11, var7 + var11);
         Deque var14 = (Deque)ll.get();
         if (!var14.isEmpty()) {
            var13 = var13.ll((<undefinedtype>)var14.peek());
         }

         var14.push(var13);
         IlIll(var0, var13);
      }
   }

   public static void llIII(class_332 var0, double var1, double var3, double var5, double var7, double var9, int var11, int var12, int var13, int var14) {
      <undefinedtype> var15 = lIIIll(var1, var3, var5, var7, var9, (double)0.0F);
      if (var15.l()) {
         int var16 = var11;
         int var17 = var12;
         int var18 = var13;
         int var19 = var14;
         if (var5 < (double)0.0F) {
            var16 = var12;
            var17 = var11;
            var19 = var13;
            var18 = var14;
         }

         if (var7 < (double)0.0F) {
            int var20 = var16;
            var16 = var19;
            var19 = var20;
            var20 = var17;
            var17 = var18;
            var18 = var20;
         }

         IIIlIlIIl.IIlll(var0, var15.Il(), var15.III(), var15.II(), var15.lI(), var15.ll(), var16, var17, var18, var19);
      }
   }

   public static void llIIl(class_332 var0, double var1, double var3, double var5, int var7) {
      IIIIll(var0, var1, var5, var3, var5 + (double)1.0F, var7);
   }

   public static void llIlI(class_332 var0, class_327 var1, class_2561 var2, double var3, double var5, int var7) {
      class_2561 var8 = lIIIllll.IlII(var2);
      Ill(var0, var1, var8, var3 - (double)lII(var1, var8) / (double)2.0F, var5 - lllIII(var1) / (double)2.0F, var7, false);
   }

   public static boolean llIll(class_332 var0, class_2960 var1, double var2, double var4, double var6, double var8, float var10, float var11, float var12, float var13, int var14) {
      return IIIlIlIIl.IIl(var0, var1, var2, var4, var6, var8, var10, var11, var12, var13, var14);
   }

   public static void lllII(class_332 var0, double var1, double var3, double var5, double var7, double var9, int var11) {
      if ((var11 >>> lllIIl(227094826, -1983093893) & lllIIl(227094821, -511509012)) > 0) {
         <undefinedtype> var12 = lIIIll(var1, var3, var5, var7, var9, (double)1.0F);
         if (var12.l()) {
            IIIlIlIIl.ll(var0, var12.Il(), var12.III(), var12.II(), var12.lI(), var12.ll(), var12.I(), var11);
         }
      }
   }

   public static void lllIl(class_332 var0, double var1, double var3, double var5, double var7, double var9, int var11, int var12) {
      llIII(var0, var1, var3, var5, var7, var9, lIlIIIIl.IIlI(lIlIIIIl.l(var11, -1, 0.06), (double)1.0F), lIlIIIIl.IIlI(lIlIIIIl.l(var11, -1, 0.1), (double)1.0F), lIlIIIIl.IIlI(var11, 0.92), lIlIIIIl.IIlI(var11, 0.96));
      lllII(var0, var1, var3, var5, var7, var9, var12);
   }

   public static void llllI(class_332 var0, double var1, double var3, double var5, double var7, double var9, int var11) {
      if ((var11 >>> lllIIl(227094820, 507093179) & lllIIl(227094823, -1405889434)) > 0 && !(var5 <= (double)0.0F) && !(var7 <= (double)0.0F) && !(var9 <= (double)0.0F)) {
         double var12 = Math.min(var9, Math.min(var5, var7) * (double)0.5F);
         IIIIll(var0, var1, var3, var1 + var5, var3 + var12, var11);
         IIIIll(var0, var1, var3 + var7 - var12, var1 + var5, var3 + var7, var11);
         double var14 = var3 + var12;
         double var16 = var3 + var7 - var12;
         if (!(var16 <= var14)) {
            IIIIll(var0, var1, var14, var1 + var12, var16, var11);
            IIIIll(var0, var1 + var5 - var12, var14, var1 + var5, var16, var11);
         }
      }
   }

   public static void lllll(class_332 var0, class_2960 var1, double var2, double var4, double var6, double var8, double var10, int var12) {
      IIIlIlIIl.lIIlI(var0, var1, var2, var4, var6, var8, var10, var12);
   }

   public static void IIIIII(class_332 var0, class_327 var1, String var2, double var3, double var5, double var7, double var9, int var11) {
      IIIlII(var0, var1, var2, var3 + var7 / (double)2.0F, var5 + var9 / (double)2.0F, var11);
   }

   private static boolean IIIIIl(int var0, class_2561 var1) {
      int var2 = var0 >>> lllIIl(227094822, 1333619020) & lllIIl(227094817, 188700890);
      if (var2 > 0 && (var0 & lllIIl(227094816, -1076830125)) != 0 && var1 != null && !var1.getString().isEmpty()) {
         Boolean var3 = (Boolean)IIl.get();
         return var3 != null ? var3 && lIIIllll.IllIl() : false;
      } else {
         return false;
      }
   }

   public static void IIIIlI(class_332 var0, double var1, double var3, double var5, double var7, double var9, int var11) {
      if ((var11 >>> lllIIl(227094819, -1295316643) & lllIIl(227094818, -50569836)) > 0 && !(var5 <= (double)0.0F) && !(var7 <= (double)0.0F) && !(var9 <= (double)0.0F)) {
         IIIlIlIIl.Illll(var0, var1, var3, var5, var7, var9, var11);
      }
   }

   public static void IIIIll(class_332 var0, double var1, double var3, double var5, double var7, int var9) {
      int var10 = (int)Math.floor(Math.min(var1, var5));
      int var11 = (int)Math.floor(Math.min(var3, var7));
      int var12 = (int)Math.ceil(Math.max(var1, var5));
      int var13 = (int)Math.ceil(Math.max(var3, var7));
      if (var12 > var10 && var13 > var11) {
         var0.method_25294(var10, var11, var12, var13, var9);
      }
   }

   public static void IIIlII(class_332 var0, class_327 var1, String var2, double var3, double var5, int var7) {
      if (lIIIlIIl.Ill()) {
         llII(var0, var1, var2, var3 - (double)IlIl(var1, var2) / (double)2.0F, var5 - lllIII(var1) / (double)2.0F, var7);
      } else {
         class_2561 var8 = lIIIllll.llIlI(var2);
         Ill(var0, var1, var8, var3 - (double)lII(var1, var8) / (double)2.0F, var5 - lllIII(var1) / (double)2.0F, var7, true);
      }
   }

   public static void IIIlIl(class_332 var0, class_2960 var1, double var2, double var4, double var6, double var8, int var10) {
      if ((var10 >>> lllIIl(227094845, 1407399599) & lllIIl(227094844, -2069712395)) > 0) {
         IIIlIlIIl.IIIII(var0, var1, (int)Math.round(var2), (int)Math.round(var4), (int)Math.round(var6), (int)Math.round(var8), var10);
      }
   }

   public static void IIIllI(class_332 var0) {
      IIIlIlIIl.lIlII(var0);
   }

   public static void IIIlll(class_332 var0, class_327 var1, String var2, double var3, double var5, double var7, int var9) {
      llII(var0, var1, var2, var3, var5 + (var7 - lllIII(var1)) / (double)2.0F, var9);
   }

   public static void IIlIII(class_332 var0, class_327 var1, class_2561 var2, double var3, double var5, double var7, double var9, int var11) {
      llIlI(var0, var1, var2, var3 + var7 / (double)2.0F, var5 + var9 / (double)2.0F, var11);
   }

   public static void IIlIIl(class_332 var0, double var1, double var3, double var5, double var7, double var9, int var11) {
      if ((var11 >>> lllIIl(227094847, 1186257227) & lllIIl(227094846, 1621671334)) > 0) {
         <undefinedtype> var12 = lIIIll(var1, var3, var5, var7, var9, (double)0.0F);
         if (var12.l()) {
            if (var12.ll() <= (double)0.0F) {
               IlIII(var0, var12.Il(), var12.III(), var12.II(), var12.lI(), var11);
            } else {
               IIIlIlIIl.l(var0, var12.Il(), var12.III(), var12.II(), var12.lI(), var12.ll(), var11);
            }
         }
      }
   }

   public static void IIlIlI(class_332 var0, double var1) {
      IIIlIlIIl.IIlI(var0, var1);
   }

   public static void IIlIll(class_332 var0, double var1, double var3, double var5, double var7, int var9, int var10, boolean var11) {
      IlIllI(var0, var1, var3, var5, var7, var9, var10);
      llIIIl(var0, var1 + (double)1.0F, var3 + (double)1.0F, var1 + var5 - (double)1.0F, var3 + Math.max((double)12.0F, var7 * (double)0.5F), var11 ? lllIIl(227094841, -1701752982) : lllIIl(227094840, -1200380788), lllIIl(227094843, -582727559));
   }

   public static String IIllII(class_327 var0, String var1, double var2) {
      return var0.method_27523(var1, (int)var2);
   }

   private static int IIllIl(Color var0, Color var1, double var2) {
      Color var4 = var0 == null ? Color.WHITE : var0;
      Color var5 = var1 == null ? Color.WHITE : var1;
      double var6 = Math.max((double)0.0F, Math.min((double)1.0F, var2));
      int var8 = (int)Math.round((double)var4.getRed() + (double)(var5.getRed() - var4.getRed()) * var6);
      int var9 = (int)Math.round((double)var4.getGreen() + (double)(var5.getGreen() - var4.getGreen()) * var6);
      int var10 = (int)Math.round((double)var4.getBlue() + (double)(var5.getBlue() - var4.getBlue()) * var6);
      return (var8 & lllIIl(227094842, -763664913)) << lllIIl(227094837, 279428155) | (var9 & lllIIl(227094836, 1831960559)) << lllIIl(227094839, -799947828) | var10 & lllIIl(227094838, 1416785423);
   }

   public static void IIlllI(class_332 var0, class_2960 var1, double var2, double var4, double var6, double var8, int var10, int var11, int var12, int var13, int var14, int var15, int var16) {
      if ((var16 >>> lllIIl(227094833, -144275360) & lllIIl(227094832, 89430748)) > 0 && var12 > 0 && var13 > 0 && var14 > 0 && var15 > 0) {
         IIIlIlIIl.lIllI(var0, var1, (int)Math.round(var2), (int)Math.round(var4), (int)Math.round(var6), (int)Math.round(var8), var10, var11, var12, var13, var14, var15, var16);
      }
   }

   public static void IIllll(class_332 var0, class_327 var1, String var2, double var3, double var5, double var7, int var9) {
      llIl(var0, var1, var2, var3, var5 + (var7 - lllIII(var1)) / (double)2.0F, var9);
   }

   public static String IlIIII(String var0, String var1) {
      String var2 = lIIIIl(var0, var1).trim();
      String var10000;
      if (var2.isEmpty()) {
         var10000 = "";
      } else {
         var10000 = lIlIII.Il(lllIlI(1663555670, -1989844094));
         String var5 = lIlIII.Il(lllIlI(1663555671, -976267248));
         String var3 = var10000;
         var10000 = var3 + var2 + var5;
      }

      return var10000;
   }

   public static void IlIIIl(class_332 var0, double var1, double var3, double var5, double var7, double var9, int var11, int var12, int var13) {
      if (!(var5 <= (double)0.0F) && !(var7 <= (double)0.0F)) {
         lllII(var0, var1, var3, var5, var7, var9, var12);
         double var14 = Math.max((double)0.0F, var9 - (double)1.0F);
         IllIll(var0, var1 + (double)1.0F, var3 + (double)1.0F, var5 - (double)2.0F, var7 - (double)2.0F, var14, var11);
         if (var13 != 0) {
            double var16 = Math.min((double)40.0F, var7 - (double)2.0F);
            lIllIl(var0, var1 + (double)1.0F, var3 + (double)1.0F, var5 - (double)2.0F, var16, var14, lllIIl(227094835, 1075856955) | var13 & lllIIl(227094834, 199947748), 0 | var13 & lllIIl(227094797, 641199587));
         }

      }
   }

   public static boolean IlIIlI(double var0, double var2, double var4, double var6, double var8, double var10) {
      return lIIlIll.I(var0, var2, var4, var6, var8, var10);
   }

   public static void IlIIll(Boolean var0, Runnable var1) {
      Boolean var2 = IIIll(var0);

      try {
         if (var1 != null) {
            var1.run();
         }
      } finally {
         IIl(var2);
      }

   }

   public static void IlIlII(class_332 var0, double var1, double var3, double var5, double var7, int var9, int var10) {
      lllIl(var0, var1, var3, var5, var7, I.II(), var9, var10);
   }

   private static void IlIlIl(class_332 var0, double var1, double var3, double var5, double var7, double var9, int var11, int var12, boolean var13, boolean var14) {
      int var15 = var11 >>> lllIIl(227094796, 140938723) & lllIIl(227094799, 1137365712);
      int var16 = var12 >>> lllIIl(227094798, -1632509027) & lllIIl(227094793, 1132659282);
      if (var15 > 0 || var16 > 0) {
         <undefinedtype> var17 = lIIIll(var1, var3, var5, var7, var9, (double)0.0F);
         if (var17.l()) {
            int var18 = var7 < (double)0.0F ? var12 : var11;
            int var19 = var7 < (double)0.0F ? var11 : var12;
            boolean var20 = var7 < (double)0.0F ? var14 : var13;
            boolean var21 = var7 < (double)0.0F ? var13 : var14;
            if (!var20 && !var21) {
               llIIIl(var0, var17.Il(), var17.III(), var17.Il() + var17.II(), var17.III() + var17.lI(), var18, var19);
            } else {
               IIIlIlIIl.IlIl(var0, var17.Il(), var17.III(), var17.II(), var17.lI(), var17.ll(), var18, var19, var20, var21);
            }
         }
      }
   }

   public static void IlIllI(class_332 var0, double var1, double var3, double var5, double var7, int var9, int var10) {
      IIIIll(var0, var1, var3, var1 + var5, var3 + var7, var10);
      IIIIll(var0, var1 + (double)1.0F, var3 + (double)1.0F, var1 + var5 - (double)1.0F, var3 + var7 - (double)1.0F, var9);
   }

   public static void IlIlll(class_332 var0, double var1, double var3, double var5, double var7, int var9) {
      llllI(var0, var1, var3, var5, var7, (double)1.0F, var9);
   }

   public static void IllIII(class_332 var0, double var1, double var3, double var5, double var7) {
      lIlll(var0, var1, var3, var5, var7, (double)2.0F);
   }

   public static void IllIIl(class_332 var0, class_327 var1, class_1799 var2, int var3, int var4) {
      if (var0 != null && var2 != null && !var2.method_7960()) {
         var0.method_51427(var2, var3, var4);
         if (var1 != null) {
            var0.method_51431(var1, var2, var3, var4);
         }

      }
   }

   public static void IllIlI(class_332 var0, class_327 var1, class_2561 var2, double var3, double var5, int var7) {
      class_2561 var8 = lIIIllll.IlII(var2);
      Ill(var0, var1, var8, var3 - (double)lII(var1, var8) / (double)2.0F, var5 - lllIII(var1) / (double)2.0F, var7, true);
   }

   public static void IllIll(class_332 var0, double var1, double var3, double var5, double var7, double var9, int var11) {
      if ((var11 >>> lllIIl(227094792, 2146779383) & lllIIl(227094795, -40836506)) > 0) {
         <undefinedtype> var12 = lIIIll(var1, var3, var5, var7, var9, (double)0.0F);
         if (var12.l()) {
            IIIlIlIIl.l(var0, var12.Il(), var12.III(), var12.II(), var12.lI(), var12.ll(), var11);
         }
      }
   }

   public static void IlllII(class_332 var0, class_327 var1, class_2561 var2, double var3, double var5, double var7, double var9, int var11) {
      IllIlI(var0, var1, var2, var3 + var7 / (double)2.0F, var5 + var9 / (double)2.0F, var11);
   }

   public static void IlllIl(class_332 var0, double var1, double var3, double var5, double var7, double var9, int var11, int var12) {
      IlIlIl(var0, var1, var3, var5, var7, var9, var11, var12, true, true);
   }

   public static boolean IllllI(class_332 var0, class_2960 var1, double var2, double var4, double var6, double var8, int var10) {
      return IIIlIlIIl.llIIl(var0, var1, var2, var4, var6, var8, var10);
   }

   public static void Illlll(class_332 var0, double var1, double var3, double var5, double var7, double var9, int var11, int var12) {
      if (var0 != null && !(var5 <= (double)0.0F) && !(var7 <= (double)0.0F)) {
         double var13 = Math.min(var5, var7) * (double)0.5F;
         IllIll(var0, var1, var3, var5, var7, var13, var11);
         double var15 = Math.max((double)0.0F, Math.min(var5, var5 * IIIIlI.Il(var9)));
         if (var15 > (double)0.0F) {
            IllIll(var0, var1, var3, var15, var7, Math.min(var13, var15 * (double)0.5F), var12);
         }

      }
   }

   public static void lIIIII(class_332 var0, class_2960 var1, double var2, double var4, double var6, double var8, int var10, int var11) {
      IllIl(var0, var1, var2, var4, var6, var8, var10, var11, -1);
   }

   public static String lIIIIl(String var0, String var1) {
      String var2 = var0 == null ? "" : var0;
      String var3 = var1 == null ? "" : var1.toUpperCase(Locale.ROOT);
      if (var3.contains(lIlIII.Il(lllIlI(1663555668, 1820670126)))) {
         return var2.toUpperCase(Locale.ROOT);
      } else {
         return var3.contains(lIlIII.Il(lllIlI(1663555669, 1365074550))) ? var2.toLowerCase(Locale.ROOT) : var2;
      }
   }

   public static void lIIIlI(class_332 var0) {
      lIII(var0);
   }

   private static <undefinedtype> lIIIll(double var0, double var2, double var4, double var6, double var8, double var10) {
      return lIIlIll.lll(var0, var2, var4, var6, Math.max((double)0.0F, var8 * II), Math.max((double)0.0F, var10));
   }

   public static void lIIlII(class_332 var0, double var1, double var3) {
      IIIlIlIIl.Ill(var0, var1, var3);
   }

   public static void lIIlIl(class_332 var0) {
      IIIlIlIIl.IlIlI(var0);
   }

   public static double lIIllI() {
      return I.l();
   }

   public static void lIIlll(class_332 var0, class_327 var1, String var2, double var3, double var5, double var7, boolean var9, int var10, int var11, int var12) {
      double var13 = I.l();
      IllIll(var0, var3, var5, var7, var13, I.II(), var10);
      if ((var11 >>> lllIIl(227094794, -1244272648) & lllIIl(227094789, -1250385978)) > 0 || var9) {
         lllII(var0, var3, var5, var7, var13, I.II(), var11);
      }

      IIlI(var0, var1, var2, var3, var5, var7, var13, I.I(), var12);
   }

   public static void lIlIII(class_332 var0, class_2960 var1, double var2, double var4, double var6, double var8, int var10, int var11, int var12, int var13, int var14, int var15) {
      IIlllI(var0, var1, var2, var4, var6, var8, var10, var11, var12, var13, var14, var15, -1);
   }

   public static void lIlIIl(class_332 var0, class_327 var1, class_2561 var2, double var3, double var5, double var7, int var9) {
      IIlll(var0, var1, var2, var3, var5 + (var7 - lllIII(var1)) / (double)2.0F, var9);
   }

   public static String lIlIlI(class_327 var0, String var1, double var2) {
      if (var0 != null && !(var2 <= (double)0.0F)) {
         String var4 = var1 == null ? "" : var1;
         if ((double)IlIl(var0, var4) <= var2) {
            return var4;
         } else {
            String var5 = lIlIII.Il(lllIlI(1663555666, 758068730));
            int var6 = IlIl(var0, var5);
            if ((double)var6 > var2) {
               return "";
            } else {
               String var7;
               for(var7 = var0.method_27523(var4, Math.max(0, (int)Math.floor(var2 - (double)var6))).trim(); !var7.isEmpty() && (double)IlIl(var0, var7 + var5) > var2; var7 = var7.substring(0, var7.length() - 1).trim()) {
               }

               return var7.isEmpty() ? var5 : var7 + var5;
            }
         }
      } else {
         return "";
      }
   }

   public static void lIlIll(class_332 var0, double var1, double var3, double var5, double var7, double var9) {
      double var11 = var7 * lIIlIll.lIl(var9, (double)0.0F, (double)1.0F);
      IllIII(var0, var1, var3, var1 + var5, var3 + var11);
   }

   public static double lIllII() {
      return II;
   }

   public static void lIllIl(class_332 var0, double var1, double var3, double var5, double var7, double var9, int var11, int var12) {
      IlIlIl(var0, var1, var3, var5, var7, var9, var11, var12, true, false);
   }

   public static void lIlllI(class_332 var0, double var1, double var3, double var5, double var7, double var9, int var11) {
      IllIll(var0, var1, var3, var5, var7, var9, var11);
   }

   private static double lIllll(double var0) {
      double var2 = Math.max((double)0.0F, Math.min((double)1.0F, var0));
      return var2 * var2 * ((double)3.0F - (double)2.0F * var2);
   }

   public static double llIIII(class_327 var0) {
      return Math.ceil(lllIII(var0) + (double)1.0F);
   }

   public static void llIIIl(class_332 var0, double var1, double var3, double var5, double var7, int var9, int var10) {
      int var11 = (int)Math.floor(Math.min(var1, var5));
      int var12 = (int)Math.floor(Math.min(var3, var7));
      int var13 = (int)Math.ceil(Math.max(var1, var5));
      int var14 = (int)Math.ceil(Math.max(var3, var7));
      if (var13 > var11 && var14 > var12) {
         var0.method_25296(var11, var12, var13, var14, var9, var10);
      }
   }

   public static void llIIlI(class_332 var0, class_2960 var1, double var2, double var4, double var6, double var8) {
      IIIlIl(var0, var1, var2, var4, var6, var8, -1);
   }

   private static int llIIll(float var0) {
      lIIIllll var1 = null;
      lIllIIl var2 = lIllIIl.Il();
      if (var2 != null && var2.IIl() != null) {
         var1 = var2.IIl().IIII();
      }

      Color var3 = var1 == null ? new Color(lllIIl(227094788, -488443724), lllIIl(227094791, 1158751126), lllIIl(227094790, -1586284568)) : var1.IIllII();
      Color var4 = var1 == null ? new Color(lllIIl(227094785, 943124896), lllIIl(227094784, 438567341), lllIIl(227094787, 401888089)) : var1.IlIII();
      Color var5;
      Color var6;
      float var7;
      if (var0 < 0.5F) {
         var5 = var3;
         var6 = var4;
         var7 = var0 * 2.0F;
      } else {
         var5 = var4;
         var6 = var3;
         var7 = (var0 - 0.5F) * 2.0F;
      }

      double var8 = (double)0.5F - Math.cos((double)var7 * Math.PI) * (double)0.5F;
      return IIllIl(var5, var6, var8);
   }

   public static void llIlII(class_332 var0, double var1, double var3, double var5, double var7, int var9) {
      if ((var9 >>> lllIIl(227094786, -1995258540) & lllIIl(227094813, 1232856143)) > 0 && !(var5 <= (double)0.0F) && !(var7 <= (double)0.0F)) {
         IIIlIlIIl.IIIl(var0, var1, var3, var5, var7, var9);
      }
   }

   public static void llIlIl(class_332 var0, double var1, double var3, double var5, double var7, double var9, int var11, int var12, int var13) {
      if (var0 != null && !(var5 <= (double)0.0F) && !(var7 <= (double)0.0F)) {
         llI(var0, var1, var3, var5, var7, var9, lllIIl(227094812, 1803686987), (double)10.0F, lllIIl(227094815, -237572875), 0.44);
         lllIl(var0, var1, var3, var5, var7, var9, var11, var12);
         int var14 = var13 >>> lllIIl(227094814, 356461154) & lllIIl(227094809, 633550293);
         if (var14 > 0) {
            lIllIl(var0, var1 + (double)1.0F, var3 + (double)1.0F, var5 - (double)2.0F, Math.min((double)30.0F, var7 - (double)2.0F), Math.max((double)0.0F, var9 - (double)1.0F), var13, var13 & lllIIl(227094808, -386506447));
         }

      }
   }

   public static void llIllI(class_332 var0, double var1, double var3, double var5, double var7, int var9, int var10, double var11) {
      lllII(var0, var1, var3, var5, var7, var11, var10);
      IllIll(var0, var1 + (double)1.0F, var3 + (double)1.0F, var5 - (double)2.0F, var7 - (double)2.0F, Math.max((double)0.0F, var11 - (double)1.0F), var9);
   }

   public static void llIlll(class_332 var0, class_327 var1, String var2, double var3, double var5, double var7, double var9, boolean var11, int var12, int var13, int var14) {
      double var15 = Math.max((double)1.0F, var9);
      double var17 = Math.min(I.II(), var15 * (double)0.5F);
      IllIll(var0, var3, var5, var7, var15, var17, var12);
      if ((var13 >>> lllIIl(227094811, 2079863231) & lllIIl(227094810, 39749708)) > 0 || var11) {
         lllII(var0, var3, var5, var7, var15, var17, var13);
      }

      String var19 = lIlIlI(var1, var2, Math.max((double)0.0F, var7 - I.I() * (double)2.0F));
      llIl(var0, var1, var19, var3 + (var7 - (double)IlIl(var1, var19)) * (double)0.5F, var5 + (var15 - lllIII(var1)) * (double)0.5F, var14);
   }

   public static double lllIII(class_327 var0) {
      double var1 = lIIIlIIl.IIl();
      if (var1 >= (double)0.0F) {
         return var1;
      } else if (var0 == null) {
         return (double)9.0F;
      } else {
         Objects.requireNonNull(var0);
         return (double)9.0F;
      }
   }

   private static int lllIIl(int var0, int var1) {
      return lII[var0 ^ 227094893] ^ var1 ^ var0;
   }

   private static String lllIlI(int var0, int var1) {
      int var3 = var0 ^ 1663555670;
      char[] var4 = lIl[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])llI[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         llI[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 941848256;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 148;
               break;
            case 1:
               var9 = 147;
               break;
            case 2:
               var9 = 19;
               break;
            case 3:
               var9 = 173;
               break;
            case 4:
               var9 = 185;
               break;
            case 5:
               var9 = 183;
               break;
            case 6:
               var9 = 145;
               break;
            case 7:
               var9 = 218;
               break;
            case 8:
               var9 = 224;
               break;
            case 9:
               var9 = 17;
               break;
            case 10:
               var9 = 241;
               break;
            case 11:
               var9 = 120;
               break;
            case 12:
               var9 = 227;
               break;
            case 13:
               var9 = 104;
               break;
            case 14:
               var9 = 224;
               break;
            case 15:
               var9 = 151;
               break;
            case 16:
               var9 = 60;
               break;
            case 17:
               var9 = 161;
               break;
            case 18:
               var9 = 42;
               break;
            case 19:
               var9 = 28;
               break;
            case 20:
               var9 = 112;
               break;
            case 21:
               var9 = 224;
               break;
            case 22:
               var9 = 217;
               break;
            case 23:
               var9 = 200;
               break;
            case 24:
               var9 = 217;
               break;
            case 25:
               var9 = 24;
               break;
            case 26:
               var9 = 151;
               break;
            case 27:
               var9 = 210;
               break;
            case 28:
               var9 = 213;
               break;
            case 29:
               var9 = 4;
               break;
            case 30:
               var9 = 208;
               break;
            case 31:
               var9 = 77;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
