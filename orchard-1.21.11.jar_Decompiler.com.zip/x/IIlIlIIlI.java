package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_310;

@Environment(EnvType.CLIENT)
public final class IIlIlIIlI extends IIIIIIIlI {
   private static String[] I;
   private int l;
   private <undefinedtype> II;
   private final IIIllIIII Il;
   private long lI;
   private static final int[] ll;
   private static final String[] III;
   private static final Object[] IIl;

   public String Il() {
      long var1 = this.llI();
      String var10000;
      if (var1 <= 0L) {
         var10000 = I[1];
      } else {
         String var5 = lIlIII.Il(I[0]);
         var10000 = var1 + var5;
      }

      return var10000;
   }

   private void ll() {
      this.II = null.Il;
      this.lI = 0L;
      this.l = IIll(1161527568, 281282555);
   }

   public void lIlI(class_1297 var1) {
      if (var1 instanceof class_1309 var2) {
         class_310 var3 = class_310.method_1551();
         if (var3 != null && var3.field_1724 != null && var3.field_1724.method_5624() && var2 != var3.field_1724 && var2.method_5805() && !var2.method_31481()) {
            this.II = null.lI;
            this.lI = System.currentTimeMillis() + this.llI();
            this.l = IIll(1161527569, 1288661789);
         }
      }
   }

   public void lI() {
      this.ll();
   }

   private static String IlI(char[] var0, long var1, int var3) {
      int var4 = IIll(1161527570, 1636760487) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IIll(1161527571, -1333582732);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private static void lII() {
      I[0] = IlI(IlII((short)22895, '\ue60a', -164796703).toCharArray(), 29308L, IIll(1161527572, -1616111861));
      I[1] = IlI("".toCharArray(), 29414L, IIll(1161527573, 11939990));
      I[2] = IlI(IlII((short)26154, '\ue60b', -1664011786).toCharArray(), 65848L, IIll(1161527574, -865699430));
      I[3] = IlI(IlII((short)5949, '\ue608', -323931916).toCharArray(), 81098L, IIll(1161527575, -723662144));
      I[4] = IlI(IlII((short)21669, '\ue609', -1929954562).toCharArray(), 50525L, IIll(1161527576, 983187559));
   }

   public IIlIlIIlI() {
      super((Object)lIlIII.l(I[4]), lIllII.III, (Object)lIlIII.l(I[3]));
      this.Il = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(I[2]), (double)0.0F, (double)0.0F, (double)10.0F, (double)1.0F)).IIl(lIlIII.Il(I[0])));
      this.II = null.Il;
      this.l = IIll(1161527577, -1520868661);
   }

   private long llI() {
      return Math.max(0L, Math.min(10L, Math.round((Double)this.Il.III())));
   }

   private boolean lll(class_310 var1) {
      return var1.field_1690.field_1894.method_1434() && !var1.field_1690.field_1881.method_1434() && !var1.field_1724.method_5715() && !var1.field_1724.method_6115();
   }

   public boolean IIII(class_310 var1) {
      if (this.IIIIIlI() && this.II != null.Il) {
         if (var1 != null && var1.field_1724 != null && var1.field_1690 != null && var1.field_1755 == null && var1.field_1724.method_5805()) {
            if (this.II == null.lI) {
               if (System.currentTimeMillis() < this.lI) {
                  return false;
               } else if (!var1.field_1724.method_5624()) {
                  this.ll();
                  return false;
               } else {
                  var1.field_1724.method_5728(false);
                  this.II = null.l;
                  this.l = var1.field_1724.field_6012 + 1;
                  return true;
               }
            } else if (var1.field_1724.field_6012 < this.l) {
               return false;
            } else {
               boolean var2 = this.lll(var1);
               this.ll();
               if (var2) {
                  var1.field_1724.method_5728(true);
               }

               return false;
            }
         } else {
            this.ll();
            return false;
         }
      } else {
         this.ll();
         return false;
      }
   }

   static {
      short var6 = 15792;
      String var7 = "娽䇁\ufb0c\udcebἺ릏허潞ꍙᵜ骛\uf246挚ꪤ酱饴\udf87忐\u1779ꄾ᪭ꯚ곪ᛣ戨\uaaff䗘뚇\u2fe6\ue40cﷳ䎧羈혊\uea28戀韘䁯㮽疝큝꽽췷⟧⾪䝁楃貜텇\ue5de睷\uea1c턵ᛕ躨䳺\uf1c2螩삊번嵌䋨\uf447ऒ䴒▔ᐮ莉矲裯\ue43d䡫운\ue259ᄄ篅䂺轢ϡ㞱\uf749휪鷖츖袜늼퇋尣쾑뜻바뾷";
      char[] var8 = "㶴㶸㷰㶠".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            III = var9;
            IIl = new Object[var9.length];
            int var2 = 1335097202;
            byte[] var0 = "e\u0093\u008ef9\u0098â\u0081\u0093Q\u0088Ìº+Rê¤^íf\u008e\u0007XT¡½QÔb4çÈt8'ÇÐ\u000eë_".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            ll = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               ll[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            I = new String[5];
            lII();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static int IIll(int var0, int var1) {
      return ll[var0 ^ 1161527568] ^ var1 ^ var0;
   }

   private static String IlII(short var0, char var1, int var2) {
      int var3 = var1 ^ '\ue60a';
      char[] var4 = III[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])IIl[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         IIl[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 26060;
      int var9 = 0;

      do {
         int var10 = var4[var9] + '蓱';
         var10 += 38475;
         var10 += 42666;
         var10 -= 44748;
         var10 ^= 3962;
         var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var2 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
