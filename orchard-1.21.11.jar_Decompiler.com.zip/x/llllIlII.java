package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2596;

@Environment(EnvType.CLIENT)
public final class llllIlII extends IIIIIIIlI {
   private static volatile llllIlII I;
   private static final String[] l;
   private static final Object[] II;

   private llllIlII() {
      super((Object)lIlIII.l(lII(-274335693, 532228661)), lIllII.lI, (Object)lIlIII.l(lII(-274335694, -348895444)));
   }

   public boolean ll(class_2596<?> var1) {
      return false;
   }

   static llllIlII IlI() {
      llllIlII var0 = I;
      if (var0 == null) {
         synchronized(llllIlII.class) {
            var0 = I;
            if (var0 == null) {
               var0 = new llllIlII();
               I = var0;
            }
         }
      }

      return var0;
   }

   static {
      short var0 = 15064;
      String var1 = "\udc42\udc8e\udc12\udc02\udcb7\udcd9\udc1e\udce3\udccf\udc63\udcb1\udc95⣈⠃⢏⢳⠼⡷⣼⡪⡂⣟⡸⡇⡻⠵⢻⣶⣖⢃⡩⡭⣉⣚⣔⣼⣍⡈⢽⣤";
      char[] var2 = "㫔㫄".toCharArray();
      String[] var3 = new String[var2.length];
      byte var7 = -1;

      while(true) {
         int var4 = 0;
         int var5 = 0;
         int var6 = 0;
         if (var7 == 0) {
            l = var3;
            II = new Object[var3.length];
            return;
         }

         do {
            var6 = var2[var4] ^ var0;
            var3[var4] = var1.substring(var5, var5 + var6);
            var5 += var6;
            ++var4;
         } while(var4 < var2.length);

         var7 = 0;
      }
   }

   private static String lII(int var0, int var1) {
      int var3 = var0 ^ -274335693;
      char[] var4 = l[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])II[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         II[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -738089284;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 86;
               break;
            case 1:
               var9 = 156;
               break;
            case 2:
               var9 = 38;
               break;
            case 3:
               var9 = 6;
               break;
            case 4:
               var9 = 184;
               break;
            case 5:
               var9 = 239;
               break;
            case 6:
               var9 = 42;
               break;
            case 7:
               var9 = 214;
               break;
            case 8:
               var9 = 251;
               break;
            case 9:
               var9 = 118;
               break;
            case 10:
               var9 = 238;
               break;
            case 11:
               var9 = 202;
               break;
            case 12:
               var9 = 208;
               break;
            case 13:
               var9 = 128;
               break;
            case 14:
               var9 = 60;
               break;
            case 15:
               var9 = 64;
               break;
            case 16:
               var9 = 125;
               break;
            case 17:
               var9 = 33;
               break;
            case 18:
               var9 = 247;
               break;
            case 19:
               var9 = 231;
               break;
            case 20:
               var9 = 74;
               break;
            case 21:
               var9 = 69;
               break;
            case 22:
               var9 = 9;
               break;
            case 23:
               var9 = 74;
               break;
            case 24:
               var9 = 112;
               break;
            case 25:
               var9 = 237;
               break;
            case 26:
               var9 = 57;
               break;
            case 27:
               var9 = 71;
               break;
            case 28:
               var9 = 82;
               break;
            case 29:
               var9 = 242;
               break;
            case 30:
               var9 = 35;
               break;
            case 31:
               var9 = 49;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
