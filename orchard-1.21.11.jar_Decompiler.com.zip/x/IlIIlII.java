package x;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_12392;
import net.minecraft.class_1304;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_5134;
import net.minecraft.class_746;
import net.minecraft.class_9334;
import net.minecraft.class_1322.class_1323;

@Environment(EnvType.CLIENT)
public final class IlIIlII {
   private static final double I = (double)20.0F;
   private static final double l = (double)5.0F;
   private static final double II = 1.0E-6;
   private static final float Il = 0.85F;

   public static boolean I(class_746 var0, class_1799 var1, float var2) {
      if (var0 != null && var1 != null && !var1.method_7960()) {
         if (var0.method_7357().method_7904(var1)) {
            return false;
         } else {
            double var3 = Ill(ll(var0, var1));
            return III(var0.method_7261(var2), var0.method_7279(), var3);
         }
      } else {
         return false;
      }
   }

   static boolean II(float var0, float var1, double var2, float var4) {
      if (Float.isFinite(var0) && Float.isFinite(var1) && Double.isFinite(var2) && Float.isFinite(var4) && !(var1 <= 0.0F) && !(var2 <= (double)0.0F)) {
         double var5 = Math.max((double)0.0F, Math.min((double)1.0F, (double)var0));
         double var7 = var5 * (double)var1;
         double var9 = Math.max((double)0.0F, (double)var4);
         return var7 + (double)5.0F + 1.0E-6 >= var2 * var9;
      } else {
         return false;
      }
   }

   private static void Il(Map<class_2960, class_1322> var0, Iterable<class_1322> var1) {
      if (var1 != null) {
         for(class_1322 var3 : var1) {
            if (var3 != null) {
               var0.put(var3.comp_2447(), var3);
            }
         }

      }
   }

   static double lI(double var0, Iterable<class_1322> var2, Iterable<class_1322> var3, Iterable<class_1322> var4) {
      LinkedHashMap var5 = new LinkedHashMap();
      Il(var5, var2);
      lIl(var5, var3);
      Il(var5, var4);
      double var6 = var0;

      for(class_1322 var9 : var5.values()) {
         if (var9.comp_2450() == class_1323.field_6328) {
            var6 += var9.comp_2449();
         }
      }

      double var12 = var6;

      for(class_1322 var11 : var5.values()) {
         if (var11.comp_2450() == class_1323.field_6330) {
            var12 += var6 * var11.comp_2449();
         }
      }

      for(class_1322 var14 : var5.values()) {
         if (var14.comp_2450() == class_1323.field_6331) {
            var12 *= (double)1.0F + var14.comp_2449();
         }
      }

      return var12;
   }

   public static double ll(class_746 var0, class_1799 var1) {
      if (var0 != null && var1 != null && !var1.method_7960()) {
         class_1324 var2 = var0.method_5996(class_5134.field_23723);
         if (var2 == null) {
            return (double)0.0F;
         } else {
            double var3 = lI(var2.method_6201(), var2.method_6195(), IIl(var0.method_6047()), IIl(var1));
            return ((class_1320)class_5134.field_23723.comp_349()).method_6165(var3);
         }
      } else {
         return (double)0.0F;
      }
   }

   static boolean III(float var0, float var1, double var2) {
      if (Float.isFinite(var0) && Float.isFinite(var1) && Double.isFinite(var2) && !(var1 <= 0.0F) && !(var2 <= (double)0.0F)) {
         double var4 = Math.max((double)0.0F, Math.min((double)1.0F, (double)var0));
         double var6 = var4 * (double)var1;
         return var6 + 1.0E-6 >= var2 * (double)0.85F;
      } else {
         return false;
      }
   }

   private static List<class_1322> IIl(class_1799 var0) {
      if (var0 != null && !var0.method_7960()) {
         ArrayList var1 = new ArrayList();
         var0.method_57354(class_1304.field_6173, (var1x, var2) -> {
            if (var1x.equals(class_5134.field_23723)) {
               var1.add(var2);
            }

         });
         return var1;
      } else {
         return List.of();
      }
   }

   private IlIIlII() {
   }

   public static class_12392 IlI(class_746 var0, class_1799 var1) {
      if (var0 == null) {
         return null;
      } else {
         class_12392 var2 = class_12392.method_76734(var0);
         return var1 != null && !var1.method_7960() ? (class_12392)var1.method_58695(class_9334.field_64680, var2) : var2;
      }
   }

   static double Ill(double var0) {
      return Double.isFinite(var0) && var0 > (double)0.0F ? (double)20.0F / var0 : Double.POSITIVE_INFINITY;
   }

   public static boolean lII(class_746 var0, class_1799 var1, float var2) {
      if (var0 != null && var1 != null && !var1.method_7960()) {
         if (var0.method_7357().method_7904(var1)) {
            return false;
         } else {
            double var3 = Ill(ll(var0, var1));
            float var5 = (Float)var1.method_58695(class_9334.field_63635, 0.0F);
            return II(var0.method_7261(var2), var0.method_7279(), var3, var5);
         }
      } else {
         return false;
      }
   }

   private static void lIl(Map<class_2960, class_1322> var0, Iterable<class_1322> var1) {
      if (var1 != null) {
         for(class_1322 var3 : var1) {
            if (var3 != null) {
               var0.remove(var3.comp_2447());
            }
         }

      }
   }
}
