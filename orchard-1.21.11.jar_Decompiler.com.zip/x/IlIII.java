package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;

@Environment(EnvType.CLIENT)
public final class IlIII {
   private IlIII() {
   }

   public static boolean I(class_1657 var0) {
      if (var0 == null) {
         return false;
      } else {
         lIllIIl var1 = lIllIIl.Il();
         if (var1 != null && var1.IIl() != null) {
            lI var2 = var1.IIl().IIIIIll();
            if (var2 != null && var2.IlII(var0)) {
               return true;
            } else {
               lIIIlIll var3 = var1.IIl().IIIIIl();
               if (var3 != null && var3.Il(var0)) {
                  return true;
               } else {
                  llIIIIlI var4 = (llIIIIlI)var1.IIl().IIIIIII(llIIIIlI.class);
                  return var4 != null && var4.ll(var0);
               }
            }
         } else {
            return false;
         }
      }
   }

   public static boolean l(class_1309 var0) {
      boolean var10000;
      if (var0 instanceof class_1657 var1) {
         if (I(var1)) {
            var10000 = true;
            return var10000;
         }
      }

      var10000 = false;
      return var10000;
   }

   public static boolean II(class_1297 var0) {
      boolean var10000;
      if (var0 instanceof class_1657 var1) {
         if (I(var1)) {
            var10000 = true;
            return var10000;
         }
      }

      var10000 = false;
      return var10000;
   }
}
