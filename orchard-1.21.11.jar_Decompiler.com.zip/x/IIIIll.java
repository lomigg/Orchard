package x;

import com.google.gson.JsonObject;
import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_746;
import net.minecraft.class_7923;
import net.minecraft.class_239.class_240;

@Environment(EnvType.CLIENT)
public final class IIIIll extends IIIIIIIlI {
   private int I;
   private static final int l = 1;
   private class_239 II;
   private boolean Il;
   private int lI;
   private boolean ll;
   private class_3965 III;
   private <undefinedtype> IIl;
   private long IlI;
   private long Ill;
   private boolean lII;
   private static final double lIl = 0.1;
   private final lIIIIl llI;
   private final lIIIIl lll;
   private final IlIIIlIlI<<undefinedtype>> IIII;
   private int IIIl;
   private final llllIlIl IIlI;
   private boolean IIll;
   private class_3965 IlII;
   private static final int IlIl = 9;
   private final lIIIIl IllI;
   private final lIIIIl Illl;
   private final llllIlIl lIII;
   private static final <undefinedtype> lIIl;
   private static final long lIlI = 1000L;
   private long lIll;
   private long llII;
   private long llIl;
   private long lllI;
   private int llll;
   private class_2338 IIIII;
   private static final int[] IIIIl;
   private static final String[] IIIlI;
   private static final Object[] IIIll;

   private void II(class_310 var1) {
      long var2 = System.currentTimeMillis();
      if (var2 >= this.IlI) {
         if (!IlIlIl.ll() && !this.IIlII()) {
            class_3965 var4 = this.IlII != null ? this.IlII : this.IlI(var1, this.IlII == null ? null : this.IlII.method_17777());
            if (var4 != null && this.IIIl >= 0) {
               boolean[] var5 = new boolean[]{false};
               boolean var6 = IllllIlI.llIll(var1, this, this.IIIl, () -> {
                  var5[0] = true;
                  return IllllIlI.IIlIIII(var1, var4);
               });
               if (var5[0]) {
                  if (!var6) {
                     this.IIIl();
                  } else {
                     this.IIll = true;
                     this.I = var1.field_1724.field_6012 + lIIIl(-1834988483, 1951455574);
                     this.IIl = null.IIl;
                     this.IlIll(var1);
                  }
               }
            } else {
               this.IIIl();
            }
         }
      }
   }

   private void ll(class_310 var1, class_239 var2) {
      if (var1 != null && var2 != null) {
         if (!this.lII) {
            this.II = var1.field_1765;
         }

         var1.field_1765 = var2;
         this.lII = true;
      }
   }

   public void lI() {
      this.lll(class_310.method_1551());
      this.IIIl();
   }

   private boolean III(class_310 var1, class_2338 var2) {
      if (var1 != null && var1.field_1687 != null && var2 != null) {
         class_2680 var3 = var1.field_1687.method_8320(var2);
         return var3.method_27852(class_2246.field_10540) || var3.method_27852(class_2246.field_9987);
      } else {
         return false;
      }
   }

   private class_3965 IlI(class_310 var1, class_2338 var2) {
      if (var1 != null && var2 != null) {
         class_239 var4 = var1.field_1765;
         if (var4 instanceof class_3965) {
            class_3965 var3 = (class_3965)var4;
            if (var3.method_17783() == class_240.field_1332 && var2.equals(var3.method_17777())) {
               return var3;
            }

            return null;
         }
      }

      return null;
   }

   private boolean llI(class_310 var1) {
      return var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var1.field_1690 != null && var1.field_1755 == null && var1.field_1724.method_5805();
   }

   public IIIIll() {
      super((Object)lIlIII.l(lIIlI('Ԇ', 1921281112, '脴')), lIllII.I, (Object)lIlIII.l(lIIlI('⇧', -236173111, '脵')));
      this.IIII = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(lIIlI('\uf3bb', 381311774, '脶')), <undefinedtype>.class, null.II));
      this.lIII = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(lIIlI('へ', 1763316990, '脷')), (double)0.0F, (double)0.0F, (double)0.0F, (double)300.0F, (double)5.0F)).Ill(lIlIII.l(lIIlI('큩', -831380360, '脰'))));
      this.IIlI = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(lIIlI('홴', 1471748032, '脱')), (double)0.0F, (double)0.0F, (double)0.0F, (double)300.0F, (double)5.0F)).Ill(lIlIII.l(lIIlI('ﾐ', -937862551, '脲'))));
      this.lll = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lIIlI('\udd55', -1989869169, '脳')), true));
      this.IllI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lIIlI('ﱞ', -100385771, '脼')), true));
      this.llI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lIIlI('쨇', 1186407063, '脽')), true));
      this.Illl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lIIlI('矟', -1319221754, '脾')), true));
      this.IIl = null.II;
      this.IlI = Long.MIN_VALUE;
      this.lI = lIIIl(-1834988484, 271207627);
      this.llll = -1;
      this.IIIl = -1;
      this.I = lIIIl(-1834988481, 1962693368);
   }

   private void lll(class_310 var1) {
      if (this.lII && var1 != null) {
         var1.field_1765 = this.II;
      }

      this.II = null;
      this.lII = false;
   }

   public boolean IIII(class_310 var1) {
      if (this.llI(var1) && this.IIl == null.II && (!(Boolean)this.lll.III() || var1.field_1724.method_24828())) {
         boolean var2 = var1.field_1690.field_1886.method_1434() || IllllIlI.IllIlI(var1.field_1690.field_1886) > 0;
         boolean var3 = var1.field_1690.field_1904.method_1434() || IllllIlI.IllIlI(var1.field_1690.field_1904) > 0;
         <undefinedtype> var4 = (<undefinedtype>)this.IIII.III();
         if (var4 == null.l) {
            if (var2) {
               return this.Illll(var1);
            }
         } else if (var3) {
            return this.Illll(var1);
         }

         return false;
      } else {
         return false;
      }
   }

   private void IIIl() {
      IllllIlI.IlII(class_310.method_1551(), this, null.II);
      this.IIl = null.II;
      this.IlI = Long.MIN_VALUE;
      this.llIl = 0L;
      this.lIll = 0L;
      this.llII = 0L;
      this.lI = lIIIl(-1834988482, -577588936);
      this.llll = -1;
      this.IIIII = null;
      this.IIIl = -1;
      this.Il = false;
      this.IIll = false;
      this.I = lIIIl(-1834988487, -1724328428);
      this.ll = false;
      this.IlII = null;
      this.III = null;
   }

   private class_1511 IIlI(class_310 var1) {
      if (var1 != null && var1.field_1687 != null && this.IIIII != null) {
         class_238 var2 = (new class_238(this.IIIII.method_10084())).method_1014((double)1.0F);
         class_1511 var3 = null;
         double var4 = Double.MAX_VALUE;
         class_243 var6 = class_243.method_24953(this.IIIII.method_10084());

         for(class_1297 var8 : var1.field_1687.method_8333((class_1297)null, var2, (var0) -> var0 instanceof class_1511)) {
            if (var8 instanceof class_1511) {
               class_1511 var9 = (class_1511)var8;
               if (!var9.method_31481()) {
                  double var10 = var9.method_5829().method_1005().method_1025(var6);
                  if (var10 < var4) {
                     var4 = var10;
                     var3 = var9;
                  }
               }
            }
         }

         return var3;
      } else {
         return null;
      }
   }

   private long IIll(llllIlIl var1) {
      double var2 = var1.IlII();
      double var4 = var1.IlI();
      return var2 == var4 ? Math.max(0L, Math.round(var2)) : Math.max(0L, Math.round(ThreadLocalRandom.current().nextDouble(var2, var4)));
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (this.IIl != null.II) {
         long var2 = System.currentTimeMillis();
         if (!this.llI(var1) || var2 - this.llII > this.IlIII()) {
            this.IIIl();
         }

      }
   }

   private void IlII(class_310 var1) {
      if (this.IIII(var1)) {
         <undefinedtype> var2 = (<undefinedtype>)this.IIII.III();
         class_3965 var3 = (class_3965)var1.field_1765;
         boolean var4 = this.III(var1, var3.method_17777());
         class_2338 var5 = var4 ? var3.method_17777().method_10062() : var3.method_17777().method_10093(var3.method_17780()).method_10062();
         class_1661 var6 = var1.field_1724.method_31548();
         int var7 = var4 ? -1 : this.lIIII(var6, class_1802.field_8281);
         int var8 = this.lIIII(var6, class_1802.field_8301);
         if (var2 == null.l) {
            IllllIlI.IIIIllI(var1.field_1690.field_1886);
            var1.field_1690.field_1886.method_23481(false);
         } else {
            IllllIlI.IIIIllI(var1.field_1690.field_1904);
            var1.field_1690.field_1904.method_23481(false);
         }

         this.llll = var8;
         this.IIIII = var5;
         this.III = this.lllI(var5);
         this.IlII = var4 ? null : var3;
         this.llII = System.currentTimeMillis();
         this.IlI = Long.MIN_VALUE;
         if (var4) {
            this.IIlIl(var1);
            if (this.IIl == null.III) {
               this.IIIll(var1);
            }

         } else {
            this.IIIl = var7;
            this.Il = IllllIlI.lIIlI(var1.field_1724.method_31548()) != var7;
            this.IlI = System.currentTimeMillis() + (this.Il ? this.IIll(this.lIII) : 0L) + this.IIll(this.IIlI);
            this.IIl = null.l;
            this.II(var1);
         }
      }
   }

   public boolean IlIl() {
      return this.IlllI();
   }

   private class_243 Illl(class_310 var1, class_1511 var2) {
      if (var1 != null && var1.field_1724 != null && var2 != null && !var2.method_31481()) {
         class_243 var3 = this.lIIl(var1);
         class_238 var4 = var2.method_5829();
         class_243 var5 = IIllI(var3, var4);
         double var6 = var1.field_1724.method_55755();
         double var8 = var6 - 0.1;
         return !(var8 <= (double)0.0F) && !(var3.method_1025(var5) > var8 * var8) ? var5.method_35590(var4.method_1005(), 1.0E-4) : null;
      } else {
         return null;
      }
   }

   private boolean lIII(class_310 var1, class_2338 var2) {
      class_2680 var3 = var1.field_1687.method_8320(var2);
      return !var3.method_27852(class_2246.field_10540) && !var3.method_27852(class_2246.field_9987) && !var3.method_27852(class_2246.field_23152);
   }

   private class_243 lIIl(class_310 var1) {
      class_746 var2 = var1.field_1724;
      class_243 var3 = var2.method_33571();
      class_243 var4 = new class_243(var2.method_23317(), var2.method_23318(), var2.method_23321());
      return (new class_243(IIlllllI.IIlI(var2), IIlllllI.llll(var2), IIlllllI.lIII(var2))).method_1019(var3.method_1020(var4));
   }

   public void IIl(JsonObject var1) {
      super.IIl(var1);
      this.llIlIl(var1, lIIl.lIlI(), new llllIlIl[]{this.lIII, this.IIlI});
      this.llIlIl(var1, lIlIII.Il(lIIlI('흢', -1866511074, '脿')), new llllIlIl[]{this.lIII});
      this.llIlIl(var1, lIlIII.Il(lIIlI('퍩', 361630798, '脸')), new llllIlIl[]{this.IIlI});
      this.llIlIl(var1, lIlIII.Il(lIIlI('만', -1522726502, '脹')), new llllIlIl[]{this.IIlI});
      this.llIlIl(var1, lIlIII.Il(lIIlI('퀳', -2072613480, '脺')), new llllIlIl[]{this.IIlI});
   }

   static {
      short var6 = 15300;
      String var7 = "渟添渐渓渭渜渐港渄渎淭渐渏添渚済渎渞淚淗쪚쪕쪳쩹쪱쪣쪣쪆쪆쪍쩝쪅쩼쪕쪍쪭쪓쪑쪝쪪쪯쩖쪮쪪쪉쪑쪛쪅쩹쪳쪊쪩쪳쩽쪈쪎쩷쩺쩘쪩쪱쪰쪮쩺쪴쩹쪝쪬쪆쩹쩖쪆쪌쪕쩗쪈쪮쪍쪴쪭쩝쩢쪙쪦쪱쩗쪅쪭쪲쩽쪧쩷\udfa3\udf8c\udf7b\udfb1\udfa8\udf9d\udf60\udf82\udf84\udfa9\udf9c\udf5f\udf93\udf60\udfa1\udfb2䍃䍾䍨䍠䍌䍰䍆䌼䍠䍤䍵䍡䍯䍣䍷䍷蒟蒒蒜葮ﯘ\ufbcfﯱ﮻ﯳﯡﯚ﯁ﯭ\ufbc7ﯴﯧ\ufbc6﯀﯀ﰤ긱긄긪균亐乑五亭乼亮乸乐京乸亍亏亟五亢亙亥亀亃义籬籄籦簻籟籌籋籒籓籩籣籉簹籡籭粯\uf715\uf6d0\uf716\uf702\uf6fa\uf6fc\uf6d4\uf72c\uf72d\uf70f\uf6fd\uf72f\uf71f\uf6f7\uf713\uf6c9봠볼봏봔봪볤봩봜봂봔봜봳봓볠봡봲鈣釞鈈鈮鈫鈔鈢鈰鈏鈎鈫鈅鈔鈌釟鈓ᄈ\u10c9ᄲᄧᄄᄦᄀჾᄴᄚ\u10caᄩᄘჸვვᄛᄈႿჶᄄᄇბბ櫻檺欠欴欐櫽檷欝欞欬櫿欔欨欰檻欇欩櫶欖檼欓檻欙欜欚欗櫃櫃ꊨꊓꊲꉷꊥꉼꊔꊆꊈꊈꊳꊴꉶꊔꊀꊓꉸꊙꉯꉯ浕浦浄浡洼浮浦浦浥浤洹浯浞浖涕浡ᇯሳᇣᇃᇘᇴᇳᇓ";
      char[] var8 = "㯐㮌㯔㯔㯀㯔㯀㯐㯔㯔㯔㯔㯜㯘㯐㯔㯌".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IIIlI = var9;
            IIIll = new Object[var9.length];
            int var2 = -1705325597;
            byte[] var0 = "|ª^\u0080\u0098ÐË\u0014ü\u0006Õ$Uh6å\u0011ÂQÎ\u0092/ºã".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IIIIl = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IIIIl[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            lIIl = lIlIII.l(lIIlI('妓', -827379184, '脻'));
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private boolean lIll(class_310 var1, class_2338 var2) {
      return this.IIIIl(var1, var2.method_10084());
   }

   public void lIl() {
      this.IIIl();
   }

   private class_3965 lllI(class_2338 var1) {
      if (var1 == null) {
         return null;
      } else {
         class_243 var2 = new class_243((double)var1.method_10263() + (double)0.5F, (double)var1.method_10264() + (double)1.0F, (double)var1.method_10260() + (double)0.5F);
         return new class_3965(var2, class_2350.field_11036, var1, false);
      }
   }

   private long IIIII(llllIlIl var1) {
      return Math.max(0L, Math.round(Math.max(var1.IlII(), var1.IlI())));
   }

   public void IllI(class_310 var1) {
      if (!this.llI(var1)) {
         this.lll(var1);
         this.IIIl();
      } else {
         this.Ill = IllllIlI.IIlIIIl();
         this.lllI = IllllIlI.llIlII();
         if ((Boolean)this.lll.III() && !var1.field_1724.method_24828()) {
            this.lll(var1);
            this.IIIl();
         } else if (this.IIl == null.II) {
            this.IlII(var1);
         } else {
            long var2 = System.currentTimeMillis();
            if (this.IIl == null.l) {
               this.II(var1);
            } else if (this.IIl == null.IIl) {
               this.IlIll(var1);
            } else if (this.IIl == null.I && var2 >= this.llIl) {
               this.IIlIl(var1);
            } else if (this.IIl == null.III) {
               this.IIIll(var1);
            } else if (this.IIl == null.ll && var2 >= this.lIll && var1.field_1724.field_6012 >= this.lI) {
               this.IlIIl(var1);
            }

         }
      }
   }

   private boolean IIIIl(class_310 var1, class_2338 var2) {
      class_2680 var3 = var1.field_1687.method_8320(var2);
      return (var3.method_26215() || var3.method_45474()) && var1.field_1687.method_8335((class_1297)null, new class_238(var2)).isEmpty();
   }

   private void IIIll(class_310 var1) {
      if (!IlIlIl.ll() && !this.IIlII()) {
         if (this.IIIII != null && System.currentTimeMillis() >= this.llIl) {
            class_3965 var2 = this.III;
            if (var2 != null && (this.IIll || this.III(var1, var2.method_17777()))) {
               boolean[] var3 = new boolean[]{false};
               boolean var4 = IllllIlI.llIll(var1, this, this.llll, () -> {
                  var3[0] = true;
                  return IllllIlI.IIlIIII(var1, var2);
               });
               if (var3[0]) {
                  if (!var4) {
                     this.IIIl();
                  } else if (!(Boolean)this.Illl.III()) {
                     this.IIl = null.Il;
                  } else {
                     this.IIl = null.ll;
                     long var5 = this.IIll(this.IIlI);
                     this.lI = var1.field_1724.field_6012 + 1;
                     this.lIll = System.currentTimeMillis() + var5;
                  }
               }
            }
         }
      }
   }

   private boolean IIlII() {
      return IllllIlI.IIlIIIl() != this.Ill || IllllIlI.llIlII() != this.lllI;
   }

   private void IIlIl(class_310 var1) {
      if (this.IIIII != null && this.llll >= 0) {
         this.III = this.lllI(this.IIIII);
         this.ll = IllllIlI.lIIlI(var1.field_1724.method_31548()) != this.llll;
         this.llIl = System.currentTimeMillis() + (this.ll ? this.IIll(this.lIII) : 0L) + this.IIll(this.IIlI);
         this.IIl = null.III;
      } else {
         this.IIIl();
      }
   }

   static class_243 IIllI(class_243 var0, class_238 var1) {
      return new class_243(class_3532.method_15350(var0.field_1352, var1.field_1323, var1.field_1320), class_3532.method_15350(var0.field_1351, var1.field_1322, var1.field_1325), class_3532.method_15350(var0.field_1350, var1.field_1321, var1.field_1324));
   }

   private boolean IIlll(class_310 var1, class_2338 var2) {
      class_2680 var3 = var1.field_1687.method_8320(var2);
      return var3.method_26215() || var3.method_45474();
   }

   private long IlIII() {
      return 1000L + 2L * this.IIIII(this.lIII) + 3L * this.IIIII(this.IIlI);
   }

   public void lllIl(class_310 var1) {
      this.lll(var1);
      if (this.IIl == null.Il) {
         this.IIIl();
      }

   }

   private void IlIIl(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         class_1511 var2 = this.IIlI(var1);
         if (var2 != null && !var2.method_31481()) {
            class_239 var4 = var1.field_1765;
            if (var4 instanceof class_3966) {
               class_3966 var3 = (class_3966)var4;
               if (var3.method_17782() != var2) {
                  this.lIll = System.currentTimeMillis();
                  return;
               }
            }

            class_3966 var6;
            label60: {
               var6 = null;
               class_239 var5 = var1.field_1765;
               if (var5 instanceof class_3966) {
                  class_3966 var7 = (class_3966)var5;
                  if (var7.method_17782() == var2) {
                     var6 = var7;
                     break label60;
                  }
               }

               class_3966 var8 = IllllIlI.IlIIllI(var1, var1.field_1724.method_55755());
               if (var8 != null && var8.method_17782() == var2) {
                  var6 = var8;
               }
            }

            if (var6 == null) {
               this.lIll = System.currentTimeMillis();
            } else {
               this.lIll = System.currentTimeMillis();
               if (!IllllIlI.lllII(var1, var6) && !IllllIlI.IlIlIII(var1, var6)) {
                  this.lI = var1.field_1724.field_6012 + 1;
               } else {
                  this.IIIl();
               }

            }
         } else {
            this.lIll = System.currentTimeMillis();
         }
      }
   }

   private void IlIll(class_310 var1) {
      if (this.IIIII != null && var1 != null && var1.field_1724 != null && var1.field_1687 != null) {
         if (!this.III(var1, this.IIIII)) {
            if (var1.field_1724.field_6012 > this.I) {
               this.IIIl();
            }

         } else {
            this.IIl = null.I;
            this.III = this.lllI(this.IIIII);
            this.llIl = System.currentTimeMillis();
            this.IIlIl(var1);
            if (this.IIl == null.III) {
               this.IIIll(var1);
            }

         }
      } else {
         this.IIIl();
      }
   }

   private boolean IllII(class_746 var1) {
      class_1799 var2 = var1 == null ? class_1799.field_8037 : var1.method_6047();
      return !var2.method_7960() && class_7923.field_41178.method_10221(var2.method_7909()).method_12832().endsWith(lIlIII.Il(lIIlI('畺', -1228659202, '脤')));
   }

   private boolean IllIl(class_746 var1) {
      if (var1 == null) {
         return false;
      } else {
         class_1799 var2 = var1.method_6047();
         if (var2.method_7960()) {
            return true;
         } else if ((Boolean)this.llI.III() && this.IllII(var1)) {
            return true;
         } else {
            return (Boolean)this.IllI.III() && var2.method_31574(class_1802.field_8288) ? true : true;
         }
      }
   }

   public boolean IlllI() {
      return this.IIl != null.II;
   }

   private boolean Illll(class_310 var1) {
      if (!lIlIllll.lIIl(var1) && this.IllIl(var1.field_1724)) {
         class_239 var3 = var1.field_1765;
         if (var3 instanceof class_3965) {
            class_3965 var2 = (class_3965)var3;
            if (var2.method_17783() == class_240.field_1332) {
               boolean var6 = this.III(var1, var2.method_17777());
               if (!var6 && !this.lIII(var1, var2.method_17777())) {
                  return false;
               }

               class_2338 var4 = var6 ? var2.method_17777().method_10062() : var2.method_17777().method_10093(var2.method_17780()).method_10062();
               if (var6) {
                  if (!this.lIll(var1, var4)) {
                     return false;
                  }
               } else if (!this.IIlll(var1, var4) || !this.lIll(var1, var4)) {
                  return false;
               }

               class_1661 var5 = var1.field_1724.method_31548();
               return (var6 || this.lIIII(var5, class_1802.field_8281) >= 0) && this.lIIII(var5, class_1802.field_8301) >= 0;
            }
         }
      }

      return false;
   }

   private int lIIII(class_1661 var1, class_1792 var2) {
      for(int var3 = 0; var3 < lIIIl(-1834988488, -1697301199); ++var3) {
         if (var1.method_5438(var3).method_31574(var2)) {
            return var3;
         }
      }

      return -1;
   }

   private static int lIIIl(int var0, int var1) {
      return IIIIl[var0 ^ -1834988483] ^ var1 ^ var0;
   }

   private static String lIIlI(char var0, int var1, char var2) {
      int var3 = var2 ^ '脴';
      char[] var4 = IIIlI[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])IIIll[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         IIIll[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 14176;
      int var9 = 0;

      do {
         int var10 = var4[var9] + 'ퟕ';
         var10 -= 34827;
         var10 ^= 60923;
         var10 ^= 4344;
         var10 ^= 57223;
         var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
