package x;

import com.mojang.authlib.GameProfile;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_640;

@Environment(EnvType.CLIENT)
public final class llIIIIl {
   public static class_2561 I(class_640 var0, class_2561 var1) {
      return var0 == null ? var1 : Il(var0.method_2966(), var1);
   }

   public static boolean l() {
      return llIl.lIlIl() != null;
   }

   private static boolean II() {
      class_310 var0 = class_310.method_1551();
      return var0.field_1724 != null && var0.field_1687 != null;
   }

   private llIIIIl() {
   }

   public static class_2561 Il(GameProfile var0, class_2561 var1) {
      llIl var2 = llIl.lIlIl();
      return var2 == null ? var1 : var2.lII(var0, var1);
   }

   public static String lI(String var0) {
      llIl var1 = llIl.lIlIl();
      return var1 != null && II() && var1.llll() ? var1.llIII(var0) : var0;
   }

   public static Object ll(GameProfile var0) {
      llIl var1 = llIl.lIlIl();
      Object var2 = var1 == null ? null : var1.IlIIII(var0);
      lIllIIl var3 = lIllIIl.Il();
      if (var3 == null) {
         return var2;
      } else {
         IIIllI var4 = var3.IIl().III();
         return var4 == null ? var2 : var4.IIII(var0, var2);
      }
   }

   public static class_2561 III(class_2561 var0) {
      llIl var1 = llIl.lIlIl();
      return var1 != null && II() && var1.llll() ? var1.lIIll(var0) : var0;
   }
}
