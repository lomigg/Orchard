package x;

import java.util.ArrayDeque;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_3675;

@Environment(EnvType.CLIENT)
public final class lllIlIll extends IIIIIIIlI {
   private final IIIllIIII I;
   private final lIIIIl l;
   private final lIIIIl II;
   private static String[] Il;
   private final lllIIlIl lI;
   private boolean ll;
   private final ArrayDeque<IllIllll> III;
   private static final int[] IIl;
   private static final String[] IlI;
   private static final Object[] Ill;

   public void Ill() {
      class_3675.class_306 var1 = (class_3675.class_306)this.lI.III();
      boolean var2 = this.IIIIIlI() && !IllllIlI.IllllI(var1) && IllllIlI.IlIII(class_310.method_1551(), var1);
      if (var2 && !this.ll) {
         String var10001 = lIlIII.Il(Il[1]);
         int var4 = this.III.size();
         String var3 = var10001;
         this.IlI(var3 + var4);
      }

      this.ll = var2;
   }

   public void lIl() {
      this.III.clear();
      this.IlI(lIlIII.Il(Il[0]));
   }

   public void lI() {
      while(!this.III.isEmpty()) {
         IllIllll var1 = (IllIllll)this.III.pollFirst();
         if (var1 != null) {
            var1.Il();
         }
      }

      this.ll = false;
   }

   public lllIlIll() {
      super((Object)lIlIII.l(Il[4]), lIllII.l, (Object)lIlIII.l(Il[5]));
      this.lI = (lllIIlIl)this.IIIlIll(new lllIIlIl(lIlIII.l(Il[llI(-205313310, 627920285)])));
      this.II = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(Il[2]), true));
      this.l = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(Il[3]), false));
      this.I = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(Il[llI(-205313309, -1603532695)]), (double)20.0F, (double)1.0F, (double)40.0F, (double)1.0F));
      this.III = new ArrayDeque();
   }

   private static void ll() {
      Il[0] = lII(lll(1527791998, (short)'뵅', '劫').toCharArray(), 98389L, llI(-205313312, -415011106));
      Il[1] = lII(lll(1973957052, (short)19199, '努').toCharArray(), 28673L, llI(-205313311, -1558739779));
      Il[2] = lII(lll(-225355570, (short)9791, '助').toCharArray(), 98778L, llI(-205313306, -1763291983));
      Il[3] = lII(lll(411963538, (short)21689, '动').toCharArray(), 53560L, llI(-205313305, 1334318256));
      Il[4] = lII(lll(623577217, (short)14610, '劯').toCharArray(), 26821L, llI(-205313308, -1181152373));
      Il[5] = lII(lll(-1720488208, (short)9915, '劮').toCharArray(), 69489L, llI(-205313307, -76133495));
      Il[llI(-205313302, 1892284156)] = lII(lll(-1461236562, (short)'넼', '劭').toCharArray(), 25441L, llI(-205313301, 1352482538));
      Il[llI(-205313304, -2061505559)] = lII(lll(-1038675227, (short)'韈', '劬').toCharArray(), 86091L, llI(-205313303, 702837816));
   }

   static {
      short var6 = 15012;
      String var7 = "奩六蓣퉡暡鹋\u0a63찃垓ꓡꊨ䬔恪ቻ뮡ദ틆⮀钢蛪Ⳡ\uf087荪\uf0af\ue3a9狑╹⤹酯塯\ufde6⽲掊㈹퇔襸귔┍碃彟\ue951\uf7e0\uf897橩塍皵꾼䖙橻垏眗ႅ椽\uf861乞뫯䴏ීߴ꾪쬷㯤퇜Ș쥐闹꿁夎\uf4ed䆯杏妳棙틠ኙ䋏\uf2e7환勻鑈㓫⅊뿡ᦂ씆䀦䞴妌\uf868뉠諚͙㪨ǆ깧蓞慉蚆\uf10a퐗䲊䉐쌑ಇ\ue23e凎셩兤ⅼ嚳乶閔쀼\ud8dc伭䜣モ•叒躝ᯰ\uf5f8\ud974\uf0b5筙帾씳㤽䦃\ue9c7乙䂘\ud7a8홛뫗\u18fd㣭⮨놮\ud8cb裄過\u1b7f쎪㨸풜ཨEꪏ헩ు鐹봦ꦦ葀\ue9ea턹臨駷㺇ഌ썝ꊚ徑듋챮퀠⬘Ი륍鄡⇇냟䋜\ue10fĺꕎㅺ催႔㥺穓蹚ꂁ钉㒼䫳僽";
      char[] var8 = "㪰㪴㪰㪨㪴㫴㪴㪬".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IlI = var9;
            Ill = new Object[var9.length];
            int var2 = -365629362;
            byte[] var0 = "<\u009a\u00977¹\u009bÒÃeO\u000bß\u008dºðZ¼«°ÒË×>Â\\\u0099½¢!»Ù0i>,^\u001eZï¼\u009cè1H$\u009bC\u009cÕà\u0090=z\u009dÕ\u0090u¸\u009c\u0000".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IIl = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IIl[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            Il = new String[llI(-205313298, -870888811)];
            ll();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private void IlI(String var1) {
      class_310 var2 = class_310.method_1551();
      if (var2.field_1724 != null && var2.field_1687 != null) {
         IllIllll var3 = new IllIllll(var2.field_1724, var1, ((Double)this.I.III()).floatValue(), (Boolean)this.II.III(), (Boolean)this.l.III());
         var3.II();
         this.III.add(var3);
      } else {
         this.IIIllIl(false);
      }
   }

   private static String lII(char[] var0, long var1, int var3) {
      int var4 = llI(-205313297, 141963262) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & llI(-205313300, 1817134685);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private static int llI(int var0, int var1) {
      return IIl[var0 ^ -205313310] ^ var1 ^ var0;
   }

   private static String lll(int var0, short var1, char var2) {
      int var3 = var2 ^ 21163;
      char[] var4 = IlI[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])Ill[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         Ill[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 14215;
      int var9 = 0;

      do {
         int var10 = var4[var9] - '뢃';
         var10 ^= 18735;
         var10 -= 2046;
         var10 -= 17700;
         var10 += 8632;
         var10 ^= 49389;
         var10 += 35723;
         var10 ^= 10188;
         var10 ^= 30748;
         var10 -= 40415;
         var4[var9] = (char)(var10 ^ var8 ^ var1 ^ var0 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
