package x;

import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_310;

@Environment(EnvType.CLIENT)
public final class IIIlIllll extends IIIIIIIlI {
   private static String[] I;
   private static final int[] l;
   private static final String[] II;
   private static final Object[] Il;

   static {
      short var6 = 13692;
      String var7 = "哙맙\ud932鋔\ud949뾔⇚\uddbeᮙ셱\ue53d\ud82fџ︂╽歎沝\udd3e棺ꊄ핳鶩漞ぎ奸Гྐ琹郔誉踲엿ᬧƫअ‵賗Ꭽ像\uf199嫟㞖\ued6f뀎비\ueb6d⬔ẘ䓃렂쎄Ꜵ碞됑\uf59aਫ출蒗ク┿\uf3f2\ueea8蟯ꊨ艆Ǚㄺᖖ嬏᪄䆼販鿍馂㵯楚츍츒ꠥ\u0e80\uf11b閭ｾ绗ᥴ垓ꛃ㫁ﲺ恃婲䘊ꄣ\ud994宥亢\uf59c㷦\ue408柍";
      char[] var8 = "㔠㕴".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            II = var9;
            Il = new Object[var9.length];
            int var2 = 413151329;
            byte[] var0 = "¯Ê\u0014¿×7\u001c÷í7\u001di¸µº¦".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            l = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               l[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            I = new String[2];
            IlI();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private Color ll(class_1657 var1) {
      lIllIIl var2 = lIllIIl.Il();
      if (var2 != null && var2.IIl() != null && var2.IIl().llI() != null) {
         Color var3 = var2.IIl().llI().lllI();
         double var4 = var1 == null ? (double)0.0F : (double)var1.method_5628() * 0.173;
         return IIlIIllIl.Ill(var3, null.ll, var4);
      } else {
         return Color.WHITE;
      }
   }

   public void Ill() {
      IllllIll.Ill();
      class_310 var1 = class_310.method_1551();
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null) {
         for(class_1297 var3 : var1.field_1687.method_18112()) {
            if (var3 instanceof class_1657) {
               class_1657 var4 = (class_1657)var3;
               if (IIlIIIIl.llIIl(var1, var4)) {
                  int var5 = this.ll(var4).getRGB();
                  IllllIll.II(var4.method_5667(), var5);
               }
            }
         }

      }
   }

   public IIIlIllll() {
      super((Object)lIlIII.l(I[1]), lIllII.ll, (Object)lIlIII.l(I[0]));
   }

   private static void IlI() {
      I[0] = lII(lll(-732308770, -1860285238).toCharArray(), 24992L, llI(224205686, -717775816));
      I[1] = lII(lll(-732308769, -1287423572).toCharArray(), 28434L, llI(224205687, 1449811531));
   }

   private static String lII(char[] var0, long var1, int var3) {
      int var4 = llI(224205684, -1284688633) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & llI(224205685, -1387753139);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   public void lI() {
      IllllIll.Ill();
   }

   private static int llI(int var0, int var1) {
      return l[var0 ^ 224205686] ^ var1 ^ var0;
   }

   private static String lll(int var0, int var1) {
      int var3 = var0 ^ -732308770;
      char[] var4 = II[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])Il[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         Il[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -15531190;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 112;
               break;
            case 1:
               var9 = 253;
               break;
            case 2:
               var9 = 30;
               break;
            case 3:
               var9 = 134;
               break;
            case 4:
               var9 = 185;
               break;
            case 5:
               var9 = 47;
               break;
            case 6:
               var9 = 2;
               break;
            case 7:
               var9 = 190;
               break;
            case 8:
               var9 = 91;
               break;
            case 9:
               var9 = 3;
               break;
            case 10:
               var9 = 50;
               break;
            case 11:
               var9 = 127;
               break;
            case 12:
               var9 = 31;
               break;
            case 13:
               var9 = 25;
               break;
            case 14:
               var9 = 7;
               break;
            case 15:
               var9 = 187;
               break;
            case 16:
               var9 = 55;
               break;
            case 17:
               var9 = 244;
               break;
            case 18:
               var9 = 232;
               break;
            case 19:
               var9 = 91;
               break;
            case 20:
               var9 = 240;
               break;
            case 21:
               var9 = 162;
               break;
            case 22:
               var9 = 147;
               break;
            case 23:
               var9 = 208;
               break;
            case 24:
               var9 = 15;
               break;
            case 25:
               var9 = 66;
               break;
            case 26:
               var9 = 253;
               break;
            case 27:
               var9 = 208;
               break;
            case 28:
               var9 = 35;
               break;
            case 29:
               var9 = 249;
               break;
            case 30:
               var9 = 59;
               break;
            case 31:
               var9 = 175;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
