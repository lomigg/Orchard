package x;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_332;

@Environment(EnvType.CLIENT)
public final class IIIIIllII extends IIIIIIIlI implements llIlIIII {
   private static final <undefinedtype> I;
   private static final Color l;
   private final IlIIIlIlI<<undefinedtype>> II;
   private final IIIIllIII Il;
   private final IlIIIlIlI<<undefinedtype>> lI;
   private final IIIllIIII ll;
   private final IIIllIIII III;
   private final IIIllIIII IIl;
   private static final List<<undefinedtype>> IlI;
   private static final double Ill = (double)3.0F;
   private final Map<String, <undefinedtype>> lII;
   private final IIIllIIII lIl;
   private static final <undefinedtype> llI;
   private double lll;
   private double IIII;
   private final IIllIlIII IIIl;
   private static final <undefinedtype> IIlI;
   private final IlIIIlIlI<<undefinedtype>> IIll;
   private final IIIllIIII IlII;
   private final lIIIIl IlIl;
   private static final long IllI = 50000000L;
   private final IIIllIIII Illl;
   private final IIIllIIII lIII;
   private final IlIIIlIlI<<undefinedtype>> lIIl;
   private final lIIIIl lIlI;
   private final IIllIlIII lIll;
   private final IIIllIIII llII;
   private final IIIllIIII llIl;
   private long lllI;
   private static final List<<undefinedtype>> llll;
   private final IIIllIIII IIIII;
   private List<<undefinedtype>> IIIIl;
   private static final double IIIlI = (double)3.0F;
   private boolean IIIll;
   private final Supplier<List<IIIIIIIlI>> IIlII;
   private final IlIIIlIlI<<undefinedtype>> IIlIl;
   private final lIIIllll IIllI;
   private final lIIIIl IIlll;
   private static final <undefinedtype> IlIII;
   private final lIIIIl IlIIl;
   private final IlIIIlIlI<<undefinedtype>> IlIlI;
   private static final <undefinedtype> IlIll;
   private final IIIllIIII IllII;
   private final llllIIII IllIl;
   private final IIIllIIII IlllI;
   private static final <undefinedtype> Illll;
   private final IIIllIIII lIIII;
   private final lIIIIl lIIIl;
   private static final int[] lIIlI;
   private static final String[] lIIll;
   private static final Object[] lIlII;

   public void IIl(class_332 var1, int var2, int var3, float var4) {
      this.lllI(var1, false, false);
   }

   public double Il() {
      return this.llIll(this.llll());
   }

   public void III(class_332 var1, int var2, int var3, float var4, boolean var5) {
      this.lllI(var1, true, var5);
   }

   public double llll() {
      return this.lll * this.IIIII();
   }

   public List<llllllI<?>> IIIlll() {
      List var1 = super.IIIlll();
      ArrayList var2 = new ArrayList(var1.size());

      for(llllllI var4 : var1) {
         if (var4 != this.lI && var4 != this.IllII && var4 != this.IlIIl && var4 != this.IlIl) {
            long var5 = var4.lllI();
            if (var5 != lIlIII.l(IIIIll(-338508941, 830934356)).lll() && var5 != lIlIII.l(IIIIll(-338508942, -1691408172)).lll() && var5 != lIlIII.l(IIIIll(-338508943, -715779386)).lll() && var5 != lIlIII.l(IIIIll(-338508944, 1231890639)).lll() && var5 != lIlIII.l(IIIIll(-338508937, 18117312)).lll() && (this.IIlIl.III() != null.II || var5 != lIlIII.l(IIIIll(-338508938, 751108210)).lll()) && (this.IIlIl.III() != null.l || var5 != lIlIII.l(IIIIll(-338508939, 833899567)).lll()) && var5 != lIlIII.l(IIIIll(-338508940, 754717000)).lll() && ((Boolean)this.lIlI.III() || var4 != this.lIIl && var4 != this.III) && (this.IIll.III() == null.ll || var5 != lIlIII.l(IIIIll(-338508933, -1895603503)).lll() && var5 != lIlIII.l(IIIIll(-338508934, -563205609)).lll()) && (this.IIll.III() != null.I || var5 != lIlIII.l(IIIIll(-338508935, -1325892485)).lll())) {
               var2.add(var4);
            }
         }
      }

      return Collections.unmodifiableList(var2);
   }

   private boolean IlI() {
      return this.IIlIl.III() == null.II;
   }

   private <undefinedtype> lII(class_310 var1, Object var2, double var3) {
      <undefinedtype> var5 = var2.I == null ? lIlIII.III("") : var2.I;
      <undefinedtype> var6 = var2.II == null ? lIlIII.III("") : var2.II;
      double var7 = Math.max((double)0.0F, var3);
      double var9 = this.llI();
      double var11 = var2.l;
      double var13 = var2.lI;
      double var15 = var11 + (var13 > (double)0.0F ? var9 + var13 : (double)0.0F);
      if (!Double.isInfinite(var7) && !(var15 <= var7)) {
         if (!var6.lIIl() && !(var13 <= (double)0.0F)) {
            if (var13 >= var7) {
               <undefinedtype> var23 = this.IlIII(var1, var6, var7);
               double var24 = this.llllI(var1, var23);
               return new Record(lIlIII.III(""), var23, (double)0.0F, var24, var24) {
                  private final double I;
                  private final <undefinedtype> l;
                  private final <undefinedtype> II;
                  private final double Il;
                  private final double lI;

                  public <undefinedtype> I() {
                     return this.l;
                  }

                  public double l() {
                     return this.Il;
                  }

                  public <undefinedtype> II() {
                     return this.II;
                  }

                  private {
                     this.l = var1;
                     this.II = var2;
                     this.lI = var3;
                     this.I = var5;
                     this.Il = var7;
                  }

                  public double Il() {
                     return this.I;
                  }

                  public double lI() {
                     return this.lI;
                  }
               };
            } else {
               double var22 = Math.max((double)0.0F, var7 - var13 - var9);
               <undefinedtype> var19 = this.IlIII(var1, var5, var22);
               double var20 = this.llllI(var1, var19);
               return var19.lIIl() ? new Record(lIlIII.III(""), var6, (double)0.0F, var13, var13) {
                  private final double I;
                  private final <undefinedtype> l;
                  private final <undefinedtype> II;
                  private final double Il;
                  private final double lI;

                  public <undefinedtype> I() {
                     return this.l;
                  }

                  public double l() {
                     return this.Il;
                  }

                  public <undefinedtype> II() {
                     return this.II;
                  }

                  private {
                     this.l = var1;
                     this.II = var2;
                     this.lI = var3;
                     this.I = var5;
                     this.Il = var7;
                  }

                  public double Il() {
                     return this.I;
                  }

                  public double lI() {
                     return this.lI;
                  }
               } : new Record(var19, var6, var20, var13, var20 + var9 + var13) {
                  private final double I;
                  private final <undefinedtype> l;
                  private final <undefinedtype> II;
                  private final double Il;
                  private final double lI;

                  public <undefinedtype> I() {
                     return this.l;
                  }

                  public double l() {
                     return this.Il;
                  }

                  public <undefinedtype> II() {
                     return this.II;
                  }

                  private {
                     this.l = var1;
                     this.II = var2;
                     this.lI = var3;
                     this.I = var5;
                     this.Il = var7;
                  }

                  public double Il() {
                     return this.I;
                  }

                  public double lI() {
                     return this.lI;
                  }
               };
            }
         } else {
            <undefinedtype> var17 = this.IlIII(var1, var5, var7);
            double var18 = this.llllI(var1, var17);
            return new Record(var17, lIlIII.III(""), var18, (double)0.0F, var18) {
               private final double I;
               private final <undefinedtype> l;
               private final <undefinedtype> II;
               private final double Il;
               private final double lI;

               public <undefinedtype> I() {
                  return this.l;
               }

               public double l() {
                  return this.Il;
               }

               public <undefinedtype> II() {
                  return this.II;
               }

               private {
                  this.l = var1;
                  this.II = var2;
                  this.lI = var3;
                  this.I = var5;
                  this.Il = var7;
               }

               public double Il() {
                  return this.I;
               }

               public double lI() {
                  return this.lI;
               }
            };
         }
      } else {
         return new Record(var5, var6, var11, var13, var15) {
            private final double I;
            private final <undefinedtype> l;
            private final <undefinedtype> II;
            private final double Il;
            private final double lI;

            public <undefinedtype> I() {
               return this.l;
            }

            public double l() {
               return this.Il;
            }

            public <undefinedtype> II() {
               return this.II;
            }

            private {
               this.l = var1;
               this.II = var2;
               this.lI = var3;
               this.I = var5;
               this.Il = var7;
            }

            public double Il() {
               return this.I;
            }

            public double lI() {
               return this.lI;
            }
         };
      }
   }

   private double llI() {
      return (double)3.0F;
   }

   private <undefinedtype> lll(class_310 var1, String var2, Object var3, Object var4) {
      double var5 = this.llllI(var1, var3);
      double var7 = var4 != null && !var4.lIIl() ? this.llllI(var1, var4) : (double)0.0F;
      double var9 = var5 + (var7 > (double)0.0F ? this.llI() + var7 : (double)0.0F);
      return new Record(var2, var3, var4, var5, var7, var9) {
         private final double I;
         private final double l;
         private final String II;
         private final <undefinedtype> Il;
         private final <undefinedtype> lI;
         private final double ll;

         public <undefinedtype> I() {
            return this.Il;
         }

         public double l() {
            return this.I;
         }

         private {
            this.II = var1;
            this.lI = var2;
            this.Il = var3;
            this.l = var4;
            this.I = var6;
            this.ll = var8;
         }

         public double II() {
            return this.l;
         }

         public double Il() {
            return this.ll;
         }

         public String lI() {
            return this.II;
         }

         public <undefinedtype> ll() {
            return this.lI;
         }
      };
   }

   private double IIll(double var1, double var3, double var5) {
      return Math.max(var3, Math.min(var5, var1));
   }

   private <undefinedtype> IlII(Object var1) {
      if (var1 == null) {
         return lIlIII.III("");
      } else {
         return this.II.III() == null.ll ? var1 : lIlIII.III(this.IIIIl(var1.lIlI()).trim());
      }
   }

   private void IlIl(class_332 var1, class_310 var2, Object var3, double var4, double var6, int var8) {
      double[] var9 = new double[]{var4};
      var3.Ill((var6x) -> {
         String var7 = new String(Character.toChars(var6x));
         IIIIIIllI.llIl(var1, var2.field_1772, var7, var9[0], var6, var8);
         var9[0] += (double)IIIIIIllI.IlIl(var2.field_1772, var7);
      });
   }

   private <undefinedtype> Illl(double var1, double var3, Object var5) {
      double var6 = this.llIlI();
      double var8 = (Double)this.IlII.III() + (double)3.0F;
      double var10 = var1 + var8 + (this.IlI() ? (double)0.0F : var6);
      double var12 = var1 + var3 - var8 - (this.IlI() ? var6 : (double)0.0F);
      double var14 = Math.max((double)0.0F, var12 - var10);
      double var16 = Math.min(var5.l(), var14);
      double var18 = Math.min(var5.lI(), var16);
      double var20 = var5.lI() > (double)0.0F && var5.Il() > (double)0.0F ? this.llI() : (double)0.0F;
      double var22 = this.IIlIl.III() == null.II ? var12 - var16 : var10;
      var22 = this.IIll(var22, var10, Math.max(var10, var12 - var16));
      double var24 = var5.Il() > (double)0.0F ? var22 + var18 + var20 : var22;
      return new Record(var22, var24) {
         private final double I;
         private final double l;

         public double I() {
            return this.I;
         }

         public double l() {
            return this.l;
         }

         private {
            this.l = var1;
            this.I = var3;
         }
      };
   }

   static {
      // $FF: Couldn't be decompiled
   }

   private Color lIII() {
      Color var1 = (Color)this.lIll.III();
      return var1.getRGB() != (new Color(IIIIlI(1491428505, 2030761852), IIIIlI(1491428504, -1141716364), IIIIlI(1491428507, 909961582), IIIIlI(1491428506, 2084609650))).getRGB() ? var1 : this.IIllI.IlIII();
   }

   public IIIIIllII(Supplier<List<IIIIIIIlI>> var1, lIIIllll var2) {
      super((Object)lIlIII.l(IIIIll(-338508952, -996783565)), lIllII.IIl, (Object)lIlIII.l(IIIIll(-338508945, -710319056)), true);
      this.IlIlI = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IIIIll(-338508946, -989957574)), <undefinedtype>.class, null.Il));
      this.IIlIl = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IIIIll(-338508947, 736259097)), <undefinedtype>.class, null.II));
      this.IIIII = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IIIIll(-338508948, -1238956139)), (double)1.0F, (double)0.0F, (double)300.0F, (double)1.0F)).IIIl(lIlIII.l(IIIIll(-338508973, -1551085284))));
      this.IIl = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IIIIll(-338508974, 1238371032)), (double)14.0F, (double)0.0F, (double)300.0F, (double)1.0F)).IIIl(lIlIII.l(IIIIll(-338508975, 123273261))));
      this.ll = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IIIIll(-338508976, 1115380674)), (double)38.0F, (double)0.0F, (double)3000.0F, (double)1.0F)).IIIl(lIlIII.l(IIIIll(-338508969, 1042245611))));
      this.IlllI = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IIIIll(-338508970, -2006300159)), (double)100.0F, (double)60.0F, (double)180.0F, (double)5.0F)).IIIl(lIlIII.l(IIIIll(-338508971, -88797201))));
      this.llIl = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IIIIll(-338508972, -2103168454)), (double)14.0F, (double)12.0F, (double)24.0F, (double)1.0F)).IIIl(lIlIII.l(IIIIll(-338508965, 1883853472))));
      this.IlII = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IIIIll(-338508966, -1790283730)), (double)0.25F, (double)0.25F, (double)12.0F, (double)0.25F)).IIIl(lIlIII.l(IIIIll(-338508967, -1758693715))));
      this.llII = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IIIIll(-338508968, 1323442303)), (double)2.0F, (double)0.0F, (double)10.0F, (double)0.5F)).IIIl(lIlIII.l(IIIIll(-338508961, 909789152))));
      this.lI = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IIIIll(-338508962, 1086542942)), <undefinedtype>.class, null.lI));
      this.lIlI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIIIll(-338508963, -1462695354)), true));
      this.lIIl = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IIIIll(-338508964, -1089727737)), <undefinedtype>.class, null.Il));
      this.II = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IIIIll(-338508989, -1576250813)), <undefinedtype>.class, null.ll));
      this.IlIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIIIll(-338508990, 585695768)), true));
      this.IIll = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IIIIll(-338508991, -1182177551)), <undefinedtype>.class, null.III));
      this.IIIl = (IIllIlIII)this.IIIlIll(new IIllIlIII(lIlIII.l(IIIIll(-338508992, 1537349691)), new Color(IIIIlI(1491428509, -139263359), IIIIlI(1491428508, 995841878), IIIIlI(1491428511, -1294885239), IIIIlI(1491428510, -1471703822))));
      this.lIll = (IIllIlIII)this.IIIlIll(new IIllIlIII(lIlIII.l(IIIIll(-338508985, -328511681)), new Color(IIIIlI(1491428497, 992087382), IIIIlI(1491428496, 331231198), IIIIlI(1491428499, -586273591), IIIIlI(1491428498, -1261998928))));
      this.IllII = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(IIIIll(-338508986, 1238334666)), (double)132.0F, (double)0.0F, (double)255.0F, (double)1.0F));
      this.III = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IIIIll(-338508987, -286569228)), (double)2.0F, (double)1.0F, (double)6.0F, (double)0.5F)).IIIl(lIlIII.l(IIIIll(-338508988, 508376040))));
      this.lIl = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(IIIIll(-338508981, -31762448)), 0.6, 0.2, (double)1.0F, 0.1));
      this.lIIII = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(IIIIll(-338508982, -1530956631)), (double)16.0F, (double)2.0F, (double)64.0F, (double)1.0F));
      this.Illl = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IIIIll(-338508983, 1404382443)), (double)24.0F, (double)0.0F, (double)80.0F, (double)1.0F)).IIIl(lIlIII.l(IIIIll(-338508984, 1089487186))));
      this.lIII = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(IIIIll(-338508977, 83918183)), 0.7, 0.05, 0.7, 0.01));
      this.lIIIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIIIll(-338508978, -1491125606)), true));
      this.IlIIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIIIll(-338508979, -1369497441)), true));
      this.Il = (IIIIllIII)this.IIIlIll(new IIIIllIII(lIlIII.l(IIIIll(-338508980, 1694447691)), llll, Set.of(IlIII, IIlI)));
      this.IIlll = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIIIll(-338509005, 713312077)), true));
      this.lII = new LinkedHashMap();
      this.IllIl = new llllIIII();
      this.IIIIl = List.of();
      this.lllI = Long.MIN_VALUE;
      this.lll = (double)0.0F;
      this.IIII = (double)0.0F;
      this.IIlII = var1;
      this.IIllI = var2;
      IlIIIlIlI var10000 = this.lIIl;
      lIIIIl var10001 = this.lIlI;
      Objects.requireNonNull(var10001);
      var10000.lIII(var10001::III);
      IIIllIIII var3 = this.III;
      var10001 = this.lIlI;
      Objects.requireNonNull(var10001);
      var3.lIII(var10001::III);
      this.IIIllIl(true);
   }

   private void lllI(class_332 var1, boolean var2, boolean var3) {
      class_310 var4 = class_310.method_1551();
      if (var4.field_1724 != null && var4.field_1772 != null) {
         <undefinedtype> var5 = this.lIIlI(var2);
         if (!var5.II().isEmpty()) {
            double var6 = this.IIIII();
            double var8 = this.Ill();
            double var10 = (Double)this.llIl.III();
            double var12 = this.lll;
            double var14 = var12 * var6;
            double var16 = this.llIll(var14);
            ArrayList var18 = new ArrayList(var5.II().size());

            for(<undefinedtype> var20 : var5.II()) {
               <undefinedtype> var21 = (<undefinedtype>)this.lII.get(var20.IlI());
               if (var21 != null) {
                  var18.add(new Record(var21, var20) {
                     private final <undefinedtype> I;
                     private final <undefinedtype> l;

                     private {
                        this.l = var1;
                        this.I = var2;
                     }

                     public <undefinedtype> I() {
                        return this.I;
                     }

                     public <undefinedtype> l() {
                        return this.l;
                     }
                  });
               }
            }

            int var70 = 0;

            for(<undefinedtype> var73 : var18) {
               if (var73.I().Il() > 0.001) {
                  ++var70;
               }
            }

            if (var70 != 0) {
               double var72 = this.lllll(var4);
               <undefinedtype> var22 = this.IIll.III() == null.ll ? this.lIIll() : null;
               boolean var23 = this.IIlII() && this.lIIl.III() == null.Il;
               <undefinedtype> var24 = var23 ? this.lIIIl(var4, var18, var72) : null;
               Boolean var25 = IIIIIIllI.IIIll(false);
               IIIIIIllI.IIIllI(var1);

               try {
                  IIIIIIllI.IlII(var1, var16, var8);
                  IIIIIIllI.lllI(var1, var6, var6);
                  int var26 = 0;

                  for(<undefinedtype> var28 : var18) {
                     <undefinedtype> var29 = var28.I();
                     double var30 = var29.Il();
                     if (!(var30 <= 0.001)) {
                        <undefinedtype> var32 = this.lII(var4, var28.l(), var72);
                        double var33 = Math.max((double)0.0F, var29.lI());
                        double var35 = ((double)1.0F - var30) * (Double)this.Illl.III();
                        double var37 = this.IIlIl.III() == null.II ? var35 : -var35;
                        double var39 = this.IIlIl.III() == null.II ? var12 - var33 + var37 : var37;
                        double var41 = var29.IIl();
                        Color var43 = this.IlIIl(var26++, var70);
                        Color var44 = var22 == null ? var43 : var22.I();
                        Color var45 = var22 == null ? var43 : var22.l();
                        <undefinedtype> var46 = this.Illl(var39, var33, var32);
                        double var47 = var46.l();
                        double var49 = var46.I();
                        double var51 = this.Illll(var4, var41, var10);
                        int var53 = this.IlllI(var43.getRGB(), (int)Math.round((double)235.0F * var30));
                        int var54 = this.IlllI(var44.getRGB(), (int)Math.round((double)235.0F * var30));
                        int var55 = this.IlllI(var45.getRGB(), (int)Math.round((double)235.0F * var30));
                        double var56 = this.IIlII() ? (Double)this.III.III() + (double)1.0F : (double)0.0F;
                        double var58 = this.IlI() ? var39 : var39 + var56;
                        double var60 = Math.max((double)0.0F, var33 - var56);
                        this.lIIII(var1, var16, var8, var6, var58, var41, var60, var10, var3, var30);
                        if (this.IIlII() && !var23) {
                           if (!this.IlI()) {
                              IIIIIIllI.IIlIIl(var1, var39 + (double)1.0F, var41 + (double)1.0F, (Double)this.III.III(), var10 - (double)2.0F, Math.max((double)1.0F, (Double)this.llII.III() - (double)1.0F), var22 == null ? var53 : var54);
                           } else {
                              IIIIIIllI.IIlIIl(var1, var39 + var33 - (Double)this.III.III() - (double)1.0F, var41 + (double)1.0F, (Double)this.III.III(), var10 - (double)2.0F, Math.max((double)1.0F, (Double)this.llII.III() - (double)1.0F), var22 == null ? var53 : var55);
                           }
                        }

                        int var62 = Math.max(0, Math.min(IIIIlI(1491428501, -754712038), (int)Math.round((double)255.0F * var30)));
                        int var63 = this.IlllI(0, Math.max(0, Math.min(IIIIlI(1491428500, -1454713705), (int)Math.round((double)160.0F * var30))));
                        if ((Boolean)this.lIIIl.III()) {
                           if (!var32.I().lIIl()) {
                              this.IIIIII(var1, var4, var32.I(), var47 + (double)1.0F, var51 + (double)1.0F, var63, false);
                           }

                           if (!var32.II().lIIl()) {
                              this.IIIIII(var1, var4, var32.II(), var49 + (double)1.0F, var51 + (double)1.0F, var63, false);
                           }
                        }

                        int var64 = var43.getRGB();
                        int var65 = this.IlllI(var64, var62);
                        int var66 = this.IlllI(this.IllIl(var43).getRGB(), var62);
                        if (!var32.I().lIIl()) {
                           this.IIIIII(var1, var4, var32.I(), var47, var51, var65, true);
                        }

                        if (!var32.II().lIIl()) {
                           this.IIIIII(var1, var4, var32.II(), var49, var51, var66, false);
                        }
                     }
                  }

                  if (var23 && var24 != null && var24.Il()) {
                     this.lIlIl(var1, var24, var22, var70);
                  }
               } finally {
                  IIIIIIllI.lIIlIl(var1);
                  IIIIIIllI.IIl(var25);
               }

            }
         }
      }
   }

   private double IIIII() {
      return this.IIll((Double)this.IlllI.III() / (double)100.0F, 0.6, 1.8);
   }

   public double Ill() {
      return (Double)this.ll.III();
   }

   private String IIIIl(String var1) {
      String var2 = var1 == null ? "" : var1;
      String var10000;
      switch (((<undefinedtype>)this.II.III()).ordinal()) {
         case 0 -> var10000 = var2;
         case 1 -> var10000 = var2.toUpperCase(Locale.ROOT);
         case 2 -> var10000 = var2.toLowerCase(Locale.ROOT);
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   private boolean IIIll(IIIIIIIlI var1) {
      return var1 != null && var1.IlIIIII() != null && this.Il.IIII(llIIl(var1.IlIIIII()));
   }

   private boolean IIlII() {
      return (Boolean)this.lIlI.III();
   }

   private double IIlIl(Object var1) {
      return var1.l() + (Double)this.IlII.III() * (double)2.0F + this.IIlll() + (double)8.0F;
   }

   private <undefinedtype> IIllI(String var1) {
      return lIlIII.III(this.IIIIl(var1).trim());
   }

   private double IIlll() {
      return this.IIlII() ? (Double)this.III.III() : (double)0.0F;
   }

   private <undefinedtype> IlIII(class_310 var1, Object var2, double var3) {
      if (var2 != null && !var2.ll() && !(var3 <= (double)0.0F)) {
         if (this.llllI(var1, var2) <= var3) {
            return var2;
         } else {
            <undefinedtype> var5 = lIlIII.l(IIIIll(-338509006, 593304844));
            double var6 = this.llllI(var1, var5);
            int[] var8 = new int[]{0};
            double[] var9 = new double[]{(double)0.0F};
            boolean[] var10 = new boolean[]{true};
            var2.Ill((var8x) -> {
               if (var10[0]) {
                  double var9x = (double)IIIIIIllI.IlIl(var1.field_1772, new String(Character.toChars(var8x)));
                  if (var9[0] + var9x + var6 > var3) {
                     var10[0] = false;
                  } else {
                     var9[0] += var9x;
                     int var10002 = var8[0]++;
                  }
               }
            });
            return var2.l(var8[0]).IIII(var5);
         }
      } else {
         return lIlIII.III("");
      }
   }

   private Color IlIIl(int var1, int var2) {
      Color var3 = this.lIllI();
      if (this.IIll.III() == null.ll) {
         return this.llIII((double)0.5F);
      } else if (this.IIll.III() != null.I && var2 > 1) {
         double var4 = (double)var1 / (double)(var2 - 1);
         return this.IllII(var3, this.lIII(), var4);
      } else {
         return var3;
      }
   }

   private Color IllII(Color var1, Color var2, double var3) {
      double var5 = Math.max((double)0.0F, Math.min((double)1.0F, var3));
      int var7 = (int)Math.round((double)var1.getRed() + (double)(var2.getRed() - var1.getRed()) * var5);
      int var8 = (int)Math.round((double)var1.getGreen() + (double)(var2.getGreen() - var1.getGreen()) * var5);
      int var9 = (int)Math.round((double)var1.getBlue() + (double)(var2.getBlue() - var1.getBlue()) * var5);
      int var10 = (int)Math.round((double)var1.getAlpha() + (double)(var2.getAlpha() - var1.getAlpha()) * var5);
      return new Color(var7, var8, var9, var10);
   }

   private Color IllIl(Color var1) {
      return l;
   }

   private int IlllI(int var1, int var2) {
      return (var2 & IIIIlI(1491428503, -2144125900)) << IIIIlI(1491428502, 1886915670) | var1 & IIIIlI(1491428489, 584698948);
   }

   private double Illll(class_310 var1, double var2, double var4) {
      double var6 = var1 != null && var1.field_1772 != null ? IIIIIIllI.lllIII(var1.field_1772) : (double)9.0F;
      double var8 = var2 + (var4 - var6) * (double)0.5F;
      return (double)Math.round(var8 * (double)2.0F) * (double)0.5F;
   }

   private void lIIII(class_332 var1, double var2, double var4, double var6, double var8, double var10, double var12, double var14, boolean var16, double var17) {
      if (!this.IIlII()) {
         lllIIlI.II(var1, llI, var8, var10, var12, var14, var16, var17);
      } else {
         boolean var19 = !this.IlI();
         boolean var20 = this.IlI();
         double var23 = var8 - (var19 ? var14 : (double)0.0F);
         double var25 = var12 + (!var19 && !var20 ? (double)0.0F : var14);
         double var27 = var2 + var8 * var6;
         double var29 = var4 + var10 * var6;
         IIIIIIllI.lIlll(var1, var27, var29, var27 + var12 * var6, var29 + var14 * var6, (double)0.0F);

         try {
            lllIIlI.II(var1, llI, var23, var10, var25, var14, var16, var17);
         } finally {
            IIIIIIllI.lIII(var1);
         }

      }
   }

   private <undefinedtype> lIIIl(class_310 var1, List<<undefinedtype>> var2, double var3) {
      double var5 = Double.POSITIVE_INFINITY;
      double var7 = Double.NEGATIVE_INFINITY;
      double var9 = Double.POSITIVE_INFINITY;
      double var11 = Double.NEGATIVE_INFINITY;
      int var13 = 0;

      for(<undefinedtype> var15 : var2) {
         <undefinedtype> var16 = var15.I();
         double var17 = var16.Il();
         if (!(var17 <= 0.001)) {
            double var19 = Math.max((double)0.0F, var16.lI());
            double var21 = ((double)1.0F - var17) * (Double)this.Illl.III();
            double var23 = this.IIlIl.III() == null.II ? var21 : -var21;
            double var25 = this.IIlIl.III() == null.II ? this.lll - var19 + var23 : var23;
            double var27 = var16.IIl();
            var5 = Math.min(var5, var25);
            var7 = Math.max(var7, var25 + var19);
            var9 = Math.min(var9, var27);
            var11 = Math.max(var11, var27 + (Double)this.llIl.III());
            ++var13;
         }
      }

      if (var13 == 0) {
         return new Record((double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F, 0) {
            private final double I;
            private final int l;
            private final double II;
            private final double Il;
            private final double lI;

            private {
               this.I = var1;
               this.Il = var3;
               this.II = var5;
               this.lI = var7;
               this.l = var9;
            }

            public double I() {
               return this.Il;
            }

            public double l() {
               return this.II;
            }

            public int II() {
               return this.l;
            }

            private boolean Il() {
               return this.l > 0 && this.Il > this.I && this.lI > this.II;
            }

            public double lI() {
               return this.I;
            }

            public double ll() {
               return this.lI;
            }
         };
      } else {
         return new Record(var5, var7, var9, var11, var13) {
            private final double I;
            private final int l;
            private final double II;
            private final double Il;
            private final double lI;

            private {
               this.I = var1;
               this.Il = var3;
               this.II = var5;
               this.lI = var7;
               this.l = var9;
            }

            public double I() {
               return this.Il;
            }

            public double l() {
               return this.II;
            }

            public int II() {
               return this.l;
            }

            private boolean Il() {
               return this.l > 0 && this.Il > this.I && this.lI > this.II;
            }

            public double lI() {
               return this.I;
            }

            public double ll() {
               return this.lI;
            }
         };
      }
   }

   private <undefinedtype> lIIlI(boolean var1) {
      // $FF: Couldn't be decompiled
   }

   private <undefinedtype> lIIll() {
      return new Record(this.llIII((double)0.0F), this.llIII((double)1.0F)) {
         private final Color I;
         private final Color l;

         public Color I() {
            return this.l;
         }

         private {
            this.l = var1;
            this.I = var2;
         }

         public Color l() {
            return this.I;
         }
      };
   }

   private void lIlIl(class_332 var1, Object var2, Object var3, int var4) {
      Color var5 = this.IlIIl(0, Math.max(1, var4));
      int var6 = this.IlllI(var5.getRGB(), IIIIlI(1491428488, 2076011169));
      int var7 = this.IlllI((var3 == null ? var5 : var3.I()).getRGB(), IIIIlI(1491428491, -1794731299));
      int var8 = this.IlllI((var3 == null ? var5 : var3.l()).getRGB(), IIIIlI(1491428490, -156902282));
      double var9 = Math.max((double)1.0F, (Double)this.llII.III() - (double)1.0F);
      double var11 = (double)1.0F;
      Math.max((double)0.0F, var2.I() - var2.lI() - var11 * (double)2.0F);
      double var15 = Math.max((double)0.0F, var2.ll() - var2.l() - var11 * (double)2.0F);
      double var17;
      if (!this.IlI()) {
         var17 = var2.lI() + var11;
      } else {
         var17 = var2.I() - (Double)this.III.III() - var11;
      }

      if (var3 == null) {
         IIIIIIllI.IIlIIl(var1, var17, var2.l() + var11, (Double)this.III.III(), var15, var9, var6);
      } else {
         IIIIIIllI.ll(var1, var17, var2.l() + var11, (Double)this.III.III(), var15, var9, var7, var8);
      }

   }

   public double lIIl() {
      return this.IIII * this.IIIII();
   }

   private Color lIllI() {
      Color var1 = (Color)this.IIIl.III();
      return var1.getRGB() != (new Color(IIIIlI(1491428493, 271376910), IIIIlI(1491428492, -1588205890), IIIIlI(1491428495, -21268551), IIIIlI(1491428494, 249188817))).getRGB() ? var1 : this.IIllI.IIllII();
   }

   public boolean IIlI(double var1, double var3) {
      return var1 >= this.Il() && var1 <= this.Il() + this.llll() && var3 >= this.Ill() && var3 <= this.Ill() + this.lIIl();
   }

   private static String lIlll(long var0) {
      return Long.toUnsignedString(var0, IIIIlI(1491428481, 955369211));
   }

   public void IIIlI(class_332 var1, int var2, int var3, float var4) {
      this.lllI(var1, false, false);
   }

   private Color llIII(double var1) {
      double var3 = (Double)this.lIl.III() * 0.0018;
      double var5 = Math.max((double)1.0F, (Double)this.lIIII.III());
      double var7 = (double)System.currentTimeMillis() * var3 + var1 * (var5 / (double)16.0F);
      double var9 = (double)0.5F + (double)0.5F * Math.sin(var7 * Math.PI * (double)2.0F);
      return this.IllII(this.lIllI(), this.lIII(), var9);
   }

   private static <undefinedtype> llIIl(lIllII var0) {
      <undefinedtype> var10000;
      switch (null.I[var0.ordinal()]) {
         case 1 -> var10000 = I;
         case 2 -> var10000 = IIlI;
         case 3 -> var10000 = IlIII;
         case 4 -> var10000 = Illll;
         case 5 -> var10000 = IlIll;
         case 6 -> var10000 = null;
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   private double llIlI() {
      return this.IIlII() ? (Double)this.III.III() + (double)2.0F : (double)0.0F;
   }

   private double llIll(double var1) {
      class_310 var3 = class_310.method_1551();
      double var4 = var3.method_22683() == null ? (double)0.0F : (double)var3.method_22683().method_4486();
      return this.IIlIl.III() == null.II ? Math.max((double)0.0F, var4 - (Double)this.IIIII.III() - var1) : Math.max((double)0.0F, (Double)this.IIl.III());
   }

   private List<<undefinedtype>> lllII(class_310 var1, boolean var2, long var3) {
      if (this.lllI != Long.MIN_VALUE && var3 >= this.lllI && var3 - this.lllI < 50000000L && var2 == this.IIIll) {
         return this.IIIIl;
      } else {
         ArrayList var5 = new ArrayList();

         for(IIIIIIIlI var7 : (List)this.IIlII.get()) {
            if (var7.IIlIlIl() && var7.IIIIIlI() && !(var7 instanceof llIlIIII) && var7.IlIIIII() != lIllII.lI && this.IIIll(var7)) {
               <undefinedtype> var8 = this.IlII(var7.lllllI());
               <undefinedtype> var9 = this.IIllI(var7.I());
               if (!var8.lIIl() || !var9.lIIl()) {
                  var5.add(this.lll(var1, lIlll(var7.IIlIllI()), var8, var9));
               }
            }
         }

         if (var5.isEmpty() && var2 && (Boolean)this.IIlll.III()) {
            for(int var12 = 0; var12 < IlI.size(); ++var12) {
               <undefinedtype> var13 = (<undefinedtype>)IlI.get(var12);
               String var10 = lIlIII.Il(IIIIll(-338509007, -1233897773));
               var5.add(this.lll(var1, var10 + var12, this.IlII(var13.I()), this.IlII(var13.l())));
            }
         }

         var5.sort(Comparator.comparingDouble(<undefinedtype>::Il).reversed());
         this.IIIIl = List.copyOf(var5);
         this.lllI = var3;
         this.IIIll = var2;
         return this.IIIIl;
      }
   }

   private double llllI(class_310 var1, Object var2) {
      if (var2 != null && !var2.ll()) {
         double[] var3 = new double[]{(double)0.0F};
         var2.Ill((var2x) -> var3[0] += (double)IIIIIIllI.IlIl(var1.field_1772, new String(Character.toChars(var2x))));
         return var3[0];
      } else {
         return (double)0.0F;
      }
   }

   private double lllll(class_310 var1) {
      if (var1.method_22683() == null) {
         return Double.POSITIVE_INFINITY;
      } else {
         double var2 = (double)var1.method_22683().method_4486();
         double var4 = this.IIlIl.III() == null.II ? (Double)this.IIIII.III() : (Double)this.IIl.III();
         double var6 = Math.max((double)0.0F, var2 - Math.max((double)0.0F, var4)) / this.IIIII();
         return Math.max((double)0.0F, var6 - (Double)this.IlII.III() * (double)2.0F - this.IIlll() - (double)8.0F);
      }
   }

   private void IIIIII(class_332 var1, class_310 var2, Object var3, double var4, double var6, int var8, boolean var9) {
      if (var9 && this.IIll.III() == null.III) {
         IIIIIIllI.IlIIll(true, () -> this.IlIl(var1, var2, var3, var4, var6, var8));
      } else {
         this.IlIl(var1, var2, var3, var4, var6, var8);
      }
   }

   public void lIlI(double var1, double var3) {
      class_310 var5 = class_310.method_1551();
      if (var5.method_22683() != null) {
         double var6 = this.llll();
         double var8 = (double)var5.method_22683().method_4486();
         if (this.IIlIl.III() == null.II) {
            this.IIIII.III(Math.max((double)0.0F, var8 - var1 - var6));
         } else {
            this.IIl.III(Math.max((double)0.0F, var1));
         }

         this.ll.III(Math.max((double)0.0F, var3));
      }
   }

   private static int IIIIlI(int var0, int var1) {
      return lIIlI[var0 ^ 1491428505] ^ var1 ^ var0;
   }

   private static String IIIIll(int var0, int var1) {
      int var3 = var0 ^ -338508941;
      char[] var4 = lIIll[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])lIlII[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         lIlII[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 915533116;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 187;
               break;
            case 1:
               var9 = 213;
               break;
            case 2:
               var9 = 203;
               break;
            case 3:
               var9 = 8;
               break;
            case 4:
               var9 = 168;
               break;
            case 5:
               var9 = 169;
               break;
            case 6:
               var9 = 104;
               break;
            case 7:
               var9 = 196;
               break;
            case 8:
               var9 = 101;
               break;
            case 9:
               var9 = 11;
               break;
            case 10:
               var9 = 72;
               break;
            case 11:
               var9 = 155;
               break;
            case 12:
               var9 = 237;
               break;
            case 13:
               var9 = 57;
               break;
            case 14:
               var9 = 106;
               break;
            case 15:
               var9 = 13;
               break;
            case 16:
               var9 = 178;
               break;
            case 17:
               var9 = 227;
               break;
            case 18:
               var9 = 115;
               break;
            case 19:
               var9 = 235;
               break;
            case 20:
               var9 = 246;
               break;
            case 21:
               var9 = 145;
               break;
            case 22:
               var9 = 48;
               break;
            case 23:
               var9 = 56;
               break;
            case 24:
               var9 = 39;
               break;
            case 25:
               var9 = 68;
               break;
            case 26:
               var9 = 118;
               break;
            case 27:
               var9 = 216;
               break;
            case 28:
               var9 = 30;
               break;
            case 29:
               var9 = 71;
               break;
            case 30:
               var9 = 146;
               break;
            case 31:
               var9 = 8;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
