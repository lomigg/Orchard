package x;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;

@Environment(EnvType.CLIENT)
public final class lIllIlII extends IIIIIIIlI {
   private <undefinedtype> I;
   private static final double l = (double)4.5F;
   private final llllIlIl II;
   private final IIIllIIII Il;
   private static final double lI = (double)9.0F;
   private int ll;
   private static final int III = 120;
   private static final int IIl = 2;
   private int IlI;
   private long Ill;
   private final IlIIIlIlI<<undefinedtype>> lII;
   private class_2338 lIl;
   private static final int llI = 2;
   private int lll;
   private int IIII;
   private boolean IIIl;
   private Object IIlI;
   private long IIll;
   private final llllIlIl IlII;
   private class_1268 IlIl;
   private final Map<class_2338, Integer> IllI;
   private static final double Illl = (double)20.25F;
   private int lIII;
   private int lIIl;
   private <undefinedtype> lIlI;
   private final IlIIIlIlI<<undefinedtype>> lIll;
   private final IlIlIll llII;
   private static final class_2350[] llIl;
   private <undefinedtype> lllI;
   private long llll;
   private static final double IIIII = 0.01;
   private final IlIIIlIlI<<undefinedtype>> IIIIl;
   private boolean IIIlI;
   private <undefinedtype> IIIll;
   private final lIIIIl IIlII;
   private static final double IIlIl = (double)3.0F;
   private int IIllI;
   private <undefinedtype> IIlll;
   private static final int[] IlIII;
   private static final String[] IlIIl;
   private static final Object[] IlIlI;

   private boolean ll(class_310 var1, class_2338 var2) {
      if (var2 != null && !this.IllI.containsKey(var2)) {
         class_3610 var3 = var1.field_1687.method_8316(var2);
         if (var3 != null && var3.method_15771()) {
            boolean var10000;
            switch (((<undefinedtype>)this.IIIIl.III()).ordinal()) {
               case 0 -> var10000 = var3.method_39360(class_3612.field_15908);
               case 1 -> var10000 = var3.method_39360(class_3612.field_15910);
               case 2 -> var10000 = var3.method_39360(class_3612.field_15910) || var3.method_39360(class_3612.field_15908);
               default -> throw new MatchException((String)null, (Throwable)null);
            }

            return var10000;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private int lII(class_310 var1) {
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null) {
         for(int var2 = 0; var2 < IIIlII(-165875476, -1046762830); ++var2) {
            class_1799 var3 = var1.field_1724.method_31548().method_5438(var2);
            if (this.IIIIII(var1, var3)) {
               return var2;
            }
         }

         return -1;
      } else {
         return -1;
      }
   }

   private <undefinedtype> llI(class_310 var1, class_2338 var2, double var3) {
      if (this.llIll(var1, var2)) {
         return null;
      } else {
         for(class_2350 var8 : llIl) {
            class_2338 var9 = var2.method_10093(var8);
            class_2680 var10 = var1.field_1687.method_8320(var9);
            if (this.lllII(var1, var9, var10)) {
               class_2350 var11 = var8.method_10153();
               class_243 var12 = class_243.method_24953(var9).method_1031((double)var11.method_10148() * (double)0.5F, (double)var11.method_10164() * (double)0.5F, (double)var11.method_10165() * (double)0.5F);
               class_243 var13 = this.Illl(var12, var11);
               if (var1.field_1724.method_33571().method_1025(var12) <= (double)20.25F && this.lIlIl(var1, var13, var9)) {
                  return new Record(var2.method_10062(), var12, var9.method_10062(), var11, var13, var3) {
                     private final class_243 I;
                     private final class_243 l;
                     private final class_2350 II;
                     private final class_2338 Il;
                     private final class_2338 lI;
                     private final double ll;

                     public class_2338 I() {
                        return this.Il;
                     }

                     public class_243 l() {
                        return this.I;
                     }

                     public class_2338 II() {
                        return this.lI;
                     }

                     public class_243 Il() {
                        return this.l != null ? this.l : this.I;
                     }

                     public class_2350 lI() {
                        return this.II;
                     }

                     public class_243 ll() {
                        return this.l;
                     }

                     private {
                        this.lI = var1;
                        this.I = var2;
                        this.Il = var3;
                        this.II = var4;
                        this.l = var5;
                        this.ll = var6;
                     }

                     public double III() {
                        return this.ll;
                     }
                  };
               }
            }
         }

         return null;
      }
   }

   private void lll(class_310 var1) {
      if (this.lll >= 0) {
         if (var1.field_1724.field_6012 >= this.lIIl) {
            int var2 = this.lll;
            this.lll = -1;
            this.lIIl = 0;
            this.IIll(var1, var2);
         }
      }
   }

   private long IIII(llllIlIl var1) {
      if (var1 == null) {
         return 0L;
      } else {
         double var2 = var1.IlII();
         double var4 = var1.IlI();
         return var2 >= var4 ? Math.round(var2) : Math.round(ThreadLocalRandom.current().nextDouble(var2, var4));
      }
   }

   private void IIll(class_310 var1, int var2) {
      if (var1 != null && var1.field_1724 != null && var2 >= 0 && var2 < IIIlII(-165875475, 1625591185)) {
         IllllIlI.IlII(var1, this, null.II);
         int var3 = IllllIlI.lIIlI(var1.field_1724.method_31548());
         if (var3 != var2) {
            IllllIlI.lIll(var1, this, var2, 0, true);
         }
      }
   }

   public void lIl() {
      this.IllII(class_310.method_1551());
      this.llll = 0L;
      this.IIII = -1;
      this.IIIll = null;
      this.lll = -1;
      this.lIIl = 0;
      ++this.Ill;
      this.I = null;
      this.lIlI = null;
      this.llII.IIlIIII();
      this.IIIl = false;
      this.IIlll = null;
      this.lllI = null;
      this.IIIlI = false;
      this.lIII = -1;
      this.IIllI = -1;
      this.lIllI();
   }

   private int IlII(class_746 var1) {
      if (var1 == null) {
         return -1;
      } else {
         for(int var2 = 0; var2 < IIIlII(-165875474, -2145471854); ++var2) {
            class_1799 var3 = var1.method_31548().method_5438(var2);
            if (var3 != null && var3.method_31574(class_1802.field_8550)) {
               return var2;
            }
         }

         return -1;
      }
   }

   public void IlIl(class_310 var1, class_1268 var2, class_3965 var3) {
      this.lIllI();
      if (this.IlIII(var1) && var2 != null && var3 != null) {
         this.IllII(var1);
         class_1799 var4 = var1.field_1724.method_5998(var2);
         if (var4 != null && (var4.method_31574(class_1802.field_8705) || var4.method_31574(class_1802.field_8187))) {
            class_2338 var5 = var3.method_17777();
            class_2680 var6 = var1.field_1687.method_8320(var5);
            class_2338 var7 = var6.method_45474() ? var5 : var5.method_10093(var3.method_17780());
            this.lIl = var7.method_10062();
            this.IlIl = var2;
            this.ll = var1.field_1724.field_6012;
         }
      }
   }

   private class_243 Illl(class_243 var1, class_2350 var2) {
      return var1 != null && var2 != null ? var1.method_1031((double)var2.method_10148() * 0.01, (double)var2.method_10164() * 0.01, (double)var2.method_10165() * 0.01) : var1;
   }

   private <undefinedtype> lIII(class_310 var1, class_2338 var2, class_243 var3, double var4, int var6, int var7) {
      if (var6 >= 0) {
         <undefinedtype> var8 = this.IIlIl(var1, var2, var3, var4);
         if (var8 != null) {
            return new Record(var8, null.II, var6, var7 >= 0) {
               private final boolean I;
               private final <undefinedtype> l;
               private final <undefinedtype> II;
               private final int Il;

               public int I() {
                  return this.Il;
               }

               public boolean l() {
                  return this.I;
               }

               private {
                  this.II = var1;
                  this.l = var2;
                  this.Il = var3;
                  this.I = var4;
               }

               public <undefinedtype> II() {
                  return this.II;
               }

               public <undefinedtype> Il() {
                  return this.l;
               }
            };
         }
      }

      if (var7 >= 0 && !this.llIll(var1, var2)) {
         <undefinedtype> var9 = this.llI(var1, var2, var4);
         return var9 == null ? null : new Record(var9, null.I, var7, false) {
            private final boolean I;
            private final <undefinedtype> l;
            private final <undefinedtype> II;
            private final int Il;

            public int I() {
               return this.Il;
            }

            public boolean l() {
               return this.I;
            }

            private {
               this.II = var1;
               this.l = var2;
               this.Il = var3;
               this.I = var4;
            }

            public <undefinedtype> II() {
               return this.II;
            }

            public <undefinedtype> Il() {
               return this.l;
            }
         };
      } else {
         return null;
      }
   }

   private void lIIl(class_310 var1, int var2) {
      if ((Boolean)this.IIlII.III() && var1 != null && var1.field_1724 != null && var2 >= 0 && var2 < IIIlII(-165875473, -1284434513)) {
         this.lll = var2;
         this.lIIl = var1.field_1724.field_6012 + 1;
      } else {
         this.lll = -1;
         this.lIIl = 0;
      }
   }

   private boolean llII(class_310 var1, long var2, Object var4) {
      <undefinedtype> var5 = this.I;
      if (var5 != null && var5.l() == var2) {
         this.I = null;
         this.lIlI = null;
         boolean var6 = this.lIIII(var1, var4);
         if (var6) {
            this.IllI.remove(var4.Il().II());
         }

         if (!var6) {
            <undefinedtype> var7 = this.lIIIl(var1, var4);
            if (var7 != null) {
               this.lIlI = var7;
               return false;
            }
         }

         this.IlllI(var1, var4.II());
         return var6;
      } else {
         return false;
      }
   }

   private void lllI(class_310 var1) {
      if (var1 != null && var1.field_1690 != null) {
         var1.field_1690.field_1904.method_23481(false);
         IIlllllI.IlIl(var1, 4);
      }
   }

   private boolean IIIII(class_310 var1, Object var2) {
      if (var2.I() != null && var2.lI() != null && var2.ll() != null && this.ll(var1, var2.II()) && this.lIlIl(var1, var2.ll(), var2.I())) {
         if (!this.llllI(var1, null.I)) {
            return false;
         } else {
            this.lllI(var1);
            class_1269 var3 = IllllIlI.lIlII(var1, class_1268.field_5808, this.IIIll(var2));
            return var3 != null && var3.method_23665();
         }
      } else {
         return false;
      }
   }

   public void IIIIl(class_310 var1, class_1268 var2, class_1269 var3) {
      this.lIlll(var1, var2, var3);
   }

   private class_3965 IIIll(Object var1) {
      return var1 != null && var1.I() != null && var1.lI() != null ? new class_3965(var1.l(), var1.lI(), var1.I(), false) : null;
   }

   private void IIlII(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         int var2 = var1.field_1724.field_6012;
         this.IllI.entrySet().removeIf((var3) -> var2 - (Integer)var3.getValue() > IIIlII(-165875480, -494811246) || !this.IIIIlI(var1, (class_2338)var3.getKey()));
      }
   }

   private <undefinedtype> IIlIl(class_310 var1, class_2338 var2, class_243 var3, double var4) {
      return this.llIIl(var1, var3, var2) ? new Record(var2.method_10062(), var3, (class_2338)null, (class_2350)null, (class_243)null, var4) {
         private final class_243 I;
         private final class_243 l;
         private final class_2350 II;
         private final class_2338 Il;
         private final class_2338 lI;
         private final double ll;

         public class_2338 I() {
            return this.Il;
         }

         public class_243 l() {
            return this.I;
         }

         public class_2338 II() {
            return this.lI;
         }

         public class_243 Il() {
            return this.l != null ? this.l : this.I;
         }

         public class_2350 lI() {
            return this.II;
         }

         public class_243 ll() {
            return this.l;
         }

         private {
            this.lI = var1;
            this.I = var2;
            this.Il = var3;
            this.II = var4;
            this.l = var5;
            this.ll = var6;
         }

         public double III() {
            return this.ll;
         }
      } : null;
   }

   private class_243 IIlll(class_310 var1) {
      return new class_243(var1.field_1724.method_23317(), var1.field_1724.method_23318(), var1.field_1724.method_23321());
   }

   private boolean IlIII(class_310 var1) {
      return var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var1.field_1755 == null && var1.field_1724.method_5805() && !var1.field_1724.method_6115() && !var1.field_1724.method_6039() && !IllllIlI.lllllI(var1.field_1724);
   }

   private boolean IlIIl(class_310 var1, Object var2) {
      return IlIlIl.III(var1, this.IIIll(var2));
   }

   private void IlIll(class_310 var1) {
      <undefinedtype> var2 = this.lIlI;
      if (var2 != null) {
         if (!this.ll(var1, var2.Il().II())) {
            this.lIlI = null;
            this.IlllI(var1, var2.II());
         } else if (this.lIIll(var1, var2.III())) {
            if (!this.llllI(var1, var2.ll())) {
               this.lIlI = null;
               this.IlllI(var1, var2.II());
            } else if (this.lIIlI(var1, var2.III(), var2.ll()) && IllllIlI.lIllI(var1) <= 0) {
               if (this.lIlII(var1, var2)) {
                  this.lIlI = null;
               }

            }
         }
      }
   }

   private void IllII(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         int var2 = var1.field_1724.hashCode();
         class_638 var3 = var1.field_1687;
         if (var2 != this.IlI || var3 != this.IIlI) {
            this.IlI = var2;
            this.IIlI = var3;
            this.IllI.clear();
            this.llll = 0L;
            this.IIII = -1;
            this.IIIll = null;
            this.lll = -1;
            this.lIIl = 0;
            ++this.Ill;
            this.I = null;
            this.lIlI = null;
            this.lIllI();
         }

      }
   }

   private boolean IllIl(class_310 var1) {
      <undefinedtype> var2 = this.I;
      if (var2 == null) {
         return false;
      } else if (var1.field_1724.field_6012 < var2.II()) {
         return true;
      } else {
         this.I = null;
         ++this.Ill;
         <undefinedtype> var3 = var2.I();
         if (var3.I() >= 2) {
            this.IlllI(var1, var3.II());
            return true;
         } else {
            this.lIlI = var3.l(var3.I() + 1);
            return false;
         }
      }
   }

   private void IlllI(class_310 var1, int var2) {
      ++this.Ill;
      this.I = null;
      this.lIlI = null;
      this.llll = 0L;
      this.IIII = -1;
      this.IIIll = null;
      if (!(Boolean)this.IIlII.III()) {
         this.lll = -1;
         this.lIIl = 0;
         IllllIlI.IlII(var1, this, null.Il);
      } else if (var2 >= 0 && var2 < IIIlII(-165875479, -1207906635)) {
         this.lIIl(var1, var2);
      } else {
         this.lll = -1;
         this.lIIl = 0;
         IllllIlI.IlII(var1, this, null.II);
      }
   }

   public void lI() {
      class_310 var1 = class_310.method_1551();
      ++this.Ill;
      this.I = null;
      this.lIlI = null;
      IllllIlI.IlII(var1, this, (Boolean)this.IIlII.III() ? null.II : null.Il);
      this.llll = 0L;
      this.IIII = -1;
      this.IIIll = null;
      this.lll = -1;
      this.lIIl = 0;
      this.llII.IIIlIll();
      this.IIIl = false;
      this.IIlll = null;
      this.lllI = null;
      this.IIIlI = false;
      this.lIII = -1;
      this.IIllI = -1;
      this.lIllI();
   }

   private int Illll(llllIlIl var1) {
      long var2 = this.IIII(var1);
      return (int)Math.max(0L, (var2 + 25L) / 50L);
   }

   private boolean lIIII(class_310 var1, Object var2) {
      if (var2 != null && var2.Il() != null) {
         boolean var10000;
         switch (var2.ll().ordinal()) {
            case 0 -> var10000 = this.IIIIll(var1, var2.Il());
            case 1 -> var10000 = this.IIIII(var1, var2.Il());
            default -> throw new MatchException((String)null, (Throwable)null);
         }

         return var10000;
      } else {
         return false;
      }
   }

   private <undefinedtype> lIIIl(class_310 var1, Object var2) {
      if (var2 != null && var2.lI() && var2.ll() == null.II && this.IlIII(var1)) {
         int var3 = this.lII(var1);
         if (var3 < 0) {
            return null;
         } else {
            <undefinedtype> var4 = var2.Il();
            <undefinedtype> var5 = this.llI(var1, var4.II(), var4.III());
            return var5 == null ? null : new Record(var5, null.I, var2.II(), var3, false, 0) {
               private final int I;
               private final <undefinedtype> l;
               private final int II;
               private final int Il;
               private final <undefinedtype> lI;
               private final boolean ll;

               public int I() {
                  return this.I;
               }

               private {
                  this.lI = var1;
                  this.l = var2;
                  this.II = var3;
                  this.Il = var4;
                  this.ll = var5;
                  this.I = var6;
               }

               public <undefinedtype> l(int var1) {
                  return new <anonymous constructor>(this.lI, this.l, this.II, this.Il, this.ll, var1);
               }

               public int II() {
                  return this.II;
               }

               public <undefinedtype> Il() {
                  return this.lI;
               }

               public boolean lI() {
                  return this.ll;
               }

               public <undefinedtype> ll() {
                  return this.l;
               }

               public int III() {
                  return this.Il;
               }
            };
         }
      } else {
         return null;
      }
   }

   private boolean lIIlI(class_310 var1, int var2, Object var3) {
      return var1 != null && var1.field_1724 != null && var2 >= 0 && var2 < IIIlII(-165875478, -1475651715) && IllllIlI.lIIlI(var1.field_1724.method_31548()) == var2 && this.llllI(var1, var3);
   }

   private boolean lIIll(class_310 var1, int var2) {
      if (var1 != null && var1.field_1724 != null && var2 >= 0 && var2 < IIIlII(-165875477, 1626054702)) {
         if (this.IIIll == null || this.IIIll.ll() != var2) {
            boolean var3 = IllllIlI.IIlIl(var1) != var2;
            int var4 = var3 ? this.Illll(this.II) : 0;
            this.IIIll = IllllIlI.lIll(var1, this, var2, var4, true);
            this.IIII = var2;
            this.llll = 0L;
         }

         if (!IllllIlI.IlIllII(var1, this.IIIll)) {
            return false;
         } else {
            if (this.llll == 0L) {
               this.llll = System.currentTimeMillis() + this.IIII(this.IlII);
            }

            return System.currentTimeMillis() >= this.llll;
         }
      } else {
         return false;
      }
   }

   private boolean lIlII(class_310 var1, Object var2) {
      <undefinedtype> var3 = var2 == null ? null : var2.Il();
      if (var3 != null && this.ll(var1, var3.II()) && this.lIIlI(var1, var2.III(), var2.ll()) && IllllIlI.lIllI(var1) <= 0) {
         boolean var4 = this.IlIIl(var1, var3);
         float var5;
         float var6;
         if (var4) {
            var5 = var1.field_1724.method_36454();
            var6 = var1.field_1724.method_36455();
         } else {
            float[] var7 = IlIlIl.llIlI(var1, var3.l());
            if (var7 == null) {
               return false;
            }

            var5 = var7[0];
            var6 = var7[1];
         }

         long var10 = ++this.Ill;
         boolean var9 = IlIlIl.IIIIlI(var1, IIIlII(-165875484, -556262056), var5, var6, () -> this.llII(var1, var10, var2));
         if (!var9) {
            ++this.Ill;
            return false;
         } else {
            this.I = new Record(var10, var2, var1.field_1724.field_6012 + 2) {
               private final long I;
               private final <undefinedtype> l;
               private final int II;

               public <undefinedtype> I() {
                  return this.l;
               }

               private {
                  this.I = var1;
                  this.l = var3;
                  this.II = var4;
               }

               public long l() {
                  return this.I;
               }

               public int II() {
                  return this.II;
               }
            };
            return true;
         }
      } else {
         return false;
      }
   }

   private boolean lIlIl(class_310 var1, class_243 var2, class_2338 var3) {
      if (var2 != null && var3 != null) {
         class_3965 var4 = var1.field_1687.method_17742(new class_3959(var1.field_1724.method_33571(), var2, class_3960.field_17558, class_242.field_1348, var1.field_1724));
         return var4 == null || var4.method_17777().equals(var3);
      } else {
         return false;
      }
   }

   private void lIllI() {
      this.lIl = null;
      this.IlIl = null;
      this.ll = IIIlII(-165875483, -778848679);
   }

   static {
      short var6 = 18359;
      String var7 = "鸞僚阮滑虜驪嵐綾洛讀嵐笠\ue5b4\ue538\ue521\ue58d\ue5a1\ue51a\ue5ef\ue5d9\ue582\ue5c9\ue59c\ue56a\ue57d\ue58b\ue5a5\ue58d\ue56b\ue5bf\ue528\ue577\ue575\ue527\ue55b\ue586\ue522\ue568\ue5cf\ue5c3\ue554\ue5e3\ue57b\ue520\ue5da\ue534\ue518\ue5d2\ue59f\ue578\ue5f6\ue5fa\ue5f7\ue5f2\ue5f9\ue564\ue562\ue5f4\ue5aa\ue5c5\ue560\ue5a3\ue54d\ue569\ue577\ue509\ue563\ue5ef\ue518\ue528\ue591\ue5ea遠郩郰遂遵郮逓逄遄逍遰邺邪遠遫逸⤅⦍⧼⤵⤗⦉⥕⥯⤀⥼⤟⧐⧍⤜⥞⥟袒蠤衂袲袅蠚袗裂袮裆袌行術袇袱袖衆袚衻蠤\u31eaㄘㄌ㇌ㇾㅡㆺㆎ㇜ㆄ\u31e9ㅑ鯬鬞鬆鯩鯼魷鮨鮿鯍鮄鯗鬹鬥鯩鮸鯍⎵⌷⍯⏴ཧ\u0ffbྤབྷ༮\u0ff9ཡ༂མ༊༄ྭ䣊䡈䠐䢋驮骜骄驫驾髵騪騽驏騆騊骿骦騔驞騳";
      char[] var8 = "\f<\u0010\u0010\u0014\f\u0010\u0004\f\u0004\u0010".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            IlIIl = var9;
            IlIlI = new Object[var9.length];
            int var2 = -1017495152;
            byte[] var0 = "ôÝ\u001bÇU¢<åµX\u0003å\u00867¤Ù×Çv\u0092\u008dF\u007fÅ\u009dMæ\u000eU\u00ad\u0011\\ë\u009e¬HdÕ\u0007,2$/ci\"\u0097d".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IlIII = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IlIII[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            llIl = new class_2350[]{class_2350.field_11033, class_2350.field_11043, class_2350.field_11035, class_2350.field_11039, class_2350.field_11034};
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 51;
                     break;
                  case 1:
                     var10000 = 126;
                     break;
                  case 2:
                     var10000 = 65;
                     break;
                  case 3:
                     var10000 = 122;
                     break;
                  case 4:
                     var10000 = 123;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (this.IlIII(var1) && !lIlIllll.lIIl(var1)) {
         if (!this.IllIl(var1)) {
            if (this.lIlI != null) {
               this.IlIll(var1);
            } else if (!this.IIIl) {
               this.IllII(var1);
               this.IIlII(var1);
               this.lll(var1);
               if (this.lll < 0) {
                  <undefinedtype> var9 = this.llIII(var1);
                  if (var9 != null) {
                     <undefinedtype> var10 = var9.II();
                     int var11 = var9.I();
                     int var5 = this.IIIll != null ? this.IIIll.I() : IllllIlI.lIIlI(var1.field_1724.method_31548());
                     if (this.lIIll(var1, var11)) {
                        long var12 = System.currentTimeMillis();
                        if (this.IIII != var11 || var12 >= this.llll) {
                           if (this.lIIlI(var1, var11, var9.Il()) && IllllIlI.lIllI(var1) <= 0) {
                              if (this.lIll.III() == null.l) {
                                 this.IIlll = var10;
                                 this.lllI = var9.Il();
                                 this.IIIlI = var9.l();
                                 this.lIII = var5;
                                 this.IIllI = var11;
                                 this.IIIl = true;
                                 this.IIll = System.currentTimeMillis();
                              } else {
                                 Record var8 = new Record(var10, var9.Il(), var5, var11, var9.l(), 0) {
                                    private final int I;
                                    private final <undefinedtype> l;
                                    private final int II;
                                    private final int Il;
                                    private final <undefinedtype> lI;
                                    private final boolean ll;

                                    public int I() {
                                       return this.I;
                                    }

                                    private {
                                       this.lI = var1;
                                       this.l = var2;
                                       this.II = var3;
                                       this.Il = var4;
                                       this.ll = var5;
                                       this.I = var6;
                                    }

                                    public <undefinedtype> l(int var1) {
                                       return new <anonymous constructor>(this.lI, this.l, this.II, this.Il, this.ll, var1);
                                    }

                                    public int II() {
                                       return this.II;
                                    }

                                    public <undefinedtype> Il() {
                                       return this.lI;
                                    }

                                    public boolean lI() {
                                       return this.ll;
                                    }

                                    public <undefinedtype> ll() {
                                       return this.l;
                                    }

                                    public int III() {
                                       return this.Il;
                                    }
                                 };
                                 if (!this.lIlII(var1, var8)) {
                                    this.lIlI = var8;
                                 }
                              }

                           }
                        }
                     }
                  }
               }
            } else if (this.IIlll != null && this.lllI != null) {
               boolean var2 = this.IlIIl(var1, this.IIlll);
               float var3 = var2 ? 0.0F : this.llII.IlIl(var1, this.IIlll.l(), ((Double)this.Il.III()).floatValue());
               long var4 = System.currentTimeMillis();
               if (var2 || var3 <= 0.5F || var4 - this.IIll >= 1500L) {
                  this.IIIl = false;
                  Record var6 = new Record(this.IIlll, this.lllI, this.lIII, this.IIllI, this.IIIlI, 0) {
                     private final int I;
                     private final <undefinedtype> l;
                     private final int II;
                     private final int Il;
                     private final <undefinedtype> lI;
                     private final boolean ll;

                     public int I() {
                        return this.I;
                     }

                     private {
                        this.lI = var1;
                        this.l = var2;
                        this.II = var3;
                        this.Il = var4;
                        this.ll = var5;
                        this.I = var6;
                     }

                     public <undefinedtype> l(int var1) {
                        return new <anonymous constructor>(this.lI, this.l, this.II, this.Il, this.ll, var1);
                     }

                     public int II() {
                        return this.II;
                     }

                     public <undefinedtype> Il() {
                        return this.lI;
                     }

                     public boolean lI() {
                        return this.ll;
                     }

                     public <undefinedtype> ll() {
                        return this.l;
                     }

                     public int III() {
                        return this.Il;
                     }
                  };
                  if (!this.lIlII(var1, var6)) {
                     this.lIlI = var6;
                  }
               }

            } else {
               this.IIIl = false;
            }
         }
      }
   }

   private void lIlll(class_310 var1, class_1268 var2, class_1269 var3) {
      class_2338 var4 = this.lIl;
      class_1268 var5 = this.IlIl;
      if (var4 != null && var2 != null && var2 == var5) {
         int var6 = this.ll;
         this.lIllI();
         if (this.IlIII(var1) && var3 != null && var3.method_23665() && var1.field_1724.field_6012 - var6 >= 0 && var1.field_1724.field_6012 - var6 <= IIIlII(-165875482, 123903519)) {
            this.IllI.put(var4, var1.field_1724.field_6012);
         }
      }
   }

   private <undefinedtype> llIII(class_310 var1) {
      boolean var2 = this.lII.III() != null.I;
      boolean var3 = this.lII.III() != null.l;
      int var4 = var2 ? this.IlII(var1.field_1724) : -1;
      int var5 = var3 ? this.lII(var1) : -1;
      if (var4 < 0 && var5 < 0) {
         return null;
      } else {
         class_2338 var6 = var1.field_1724.method_24515();
         class_2338.class_2339 var7 = new class_2338.class_2339();
         int var8 = (int)Math.ceil((double)3.0F);
         <undefinedtype> var9 = null;

         for(int var10 = -var8; var10 <= var8; ++var10) {
            for(int var11 = -var8; var11 <= var8; ++var11) {
               for(int var12 = -var8; var12 <= var8; ++var12) {
                  var7.method_10103(var6.method_10263() + var11, var6.method_10264() + var10, var6.method_10260() + var12);
                  class_2338 var13 = var7.method_10062();
                  if (this.ll(var1, var13)) {
                     class_243 var14 = class_243.method_24953(var13);
                     double var15 = this.IIlll(var1).method_1025(var14);
                     if (!(var15 > (double)9.0F) && !(var1.field_1724.method_33571().method_1025(var14) > (double)20.25F)) {
                        <undefinedtype> var17 = this.lIII(var1, var13, var14, var15, var4, var5);
                        if (var17 != null && (var9 == null || var17.II().III() < var9.II().III())) {
                           var9 = var17;
                        }
                     }
                  }
               }
            }
         }

         return var9;
      }
   }

   private boolean llIIl(class_310 var1, class_243 var2, class_2338 var3) {
      if (var2 != null && var3 != null) {
         class_3965 var4 = var1.field_1687.method_17742(new class_3959(var1.field_1724.method_33571(), var2, class_3960.field_17558, class_242.field_1347, var1.field_1724));
         return var4 != null && var4.method_17777().equals(var3);
      } else {
         return false;
      }
   }

   public lIllIlII() {
      super((Object)lIlIII.l(IIIlIl(-412420599, -1630532169)), lIllII.l, (Object)lIlIII.l(IIIlIl(-412420600, -2109725365)));
      this.IIIIl = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IIIlIl(-412420597, -141467991)), <undefinedtype>.class, null.l));
      this.lII = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IIIlIl(-412420598, 1324760138)), <undefinedtype>.class, null.l));
      this.lIll = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IIIlIl(-412420595, -278504620)), <undefinedtype>.class, null.Il));
      this.Il = (IIIllIIII)this.IIIlIll((IIIllIIII)(new IIIllIIII(lIlIII.l(IIIlIl(-412420596, 1444812514)), (double)50.0F, (double)1.0F, (double)100.0F, (double)1.0F)).lIII(() -> this.lIll.III() == null.l));
      this.llII = new IlIlIll();
      this.lIII = -1;
      this.IIllI = -1;
      this.II = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(IIIlIl(-412420593, -65508140)), (double)55.0F, (double)60.0F, (double)0.0F, (double)300.0F, (double)5.0F)).Ill(lIlIII.l(IIIlIl(-412420594, 1146899266))));
      this.IlII = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(IIIlIl(-412420607, 1754299464)), (double)10.0F, (double)25.0F, (double)0.0F, (double)500.0F, (double)5.0F)).Ill(lIlIII.l(IIIlIl(-412420608, 790840499))));
      this.IIlII = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIIlIl(-412420605, -40213325)), true));
      this.IllI = new HashMap();
      this.ll = IIIlII(-165875481, -597416429);
      this.IIII = -1;
      this.lll = -1;
   }

   private boolean llIll(class_310 var1, class_2338 var2) {
      if (var1 != null && var1.field_1687 != null && var2 != null) {
         class_238 var3 = new class_238(var2);
         return !var1.field_1687.method_8333((class_1297)null, var3, (var0) -> !var0.method_7325() && (var0 instanceof class_1309 || var0.method_5863())).isEmpty();
      } else {
         return true;
      }
   }

   private boolean lllII(class_310 var1, class_2338 var2, class_2680 var3) {
      if (var2 != null && var3 != null && !var3.method_26215()) {
         return var3.method_26212(var1.field_1687, var2) && var3.method_26227().method_15769() && !var3.method_26220(var1.field_1687, var2).method_1110();
      } else {
         return false;
      }
   }

   private boolean llllI(class_310 var1, Object var2) {
      if (var1 != null && var1.field_1724 != null) {
         int var3 = IllllIlI.lIIlI(var1.field_1724.method_31548());
         class_1799 var4 = var1.field_1724.method_31548().method_5438(var3);
         boolean var10000;
         switch (var2.ordinal()) {
            case 0 -> var10000 = var4.method_31574(class_1802.field_8550);
            case 1 -> var10000 = this.IIIIII(var1, var4);
            default -> throw new MatchException((String)null, (Throwable)null);
         }

         return var10000;
      } else {
         return false;
      }
   }

   private boolean IIIIII(class_310 var1, class_1799 var2) {
      if (var2 != null) {
         class_1792 var4 = var2.method_7909();
         if (var4 instanceof class_1747) {
            class_1747 var3 = (class_1747)var4;
            class_2680 var5 = var3.method_7711().method_9564();
            return var5 != null && !var5.method_26215() && var5.method_26227().method_15769() && !var5.method_26220(var1.field_1687, class_2338.field_10980).method_1110();
         }
      }

      return false;
   }

   public void IIIIIl(class_310 var1, class_1268 var2, class_3965 var3, class_1269 var4) {
      if (var4 != class_1269.field_5811) {
         this.lIlll(var1, var2, var4);
      }
   }

   private boolean IIIIlI(class_310 var1, class_2338 var2) {
      if (var2 != null && var1.field_1687 != null) {
         class_3610 var3 = var1.field_1687.method_8316(var2);
         return var3 != null && !var3.method_15769();
      } else {
         return false;
      }
   }

   private boolean IIIIll(class_310 var1, Object var2) {
      if (!this.llIIl(var1, var2.l(), var2.II())) {
         return false;
      } else if (!this.llllI(var1, null.II)) {
         return false;
      } else {
         this.lllI(var1);
         class_1269 var3 = IllllIlI.lllIlI(var1, class_1268.field_5808);
         return var3 != null && var3.method_23665();
      }
   }

   private static int IIIlII(int var0, int var1) {
      return IlIII[var0 ^ -165875476] ^ var1 ^ var0;
   }

   private static String IIIlIl(int var0, int var1) {
      int var3 = var0 ^ -412420599;
      char[] var4 = IlIIl[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IlIlI[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IlIlI[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -939949717;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 138;
               break;
            case 1:
               var9 = 112;
               break;
            case 2:
               var9 = 45;
               break;
            case 3:
               var9 = 211;
               break;
            case 4:
               var9 = 202;
               break;
            case 5:
               var9 = 34;
               break;
            case 6:
               var9 = 130;
               break;
            case 7:
               var9 = 188;
               break;
            case 8:
               var9 = 214;
               break;
            case 9:
               var9 = 159;
               break;
            case 10:
               var9 = 169;
               break;
            case 11:
               var9 = 48;
               break;
            case 12:
               var9 = 2;
               break;
            case 13:
               var9 = 253;
               break;
            case 14:
               var9 = 210;
               break;
            case 15:
               var9 = 155;
               break;
            case 16:
               var9 = 33;
               break;
            case 17:
               var9 = 230;
               break;
            case 18:
               var9 = 102;
               break;
            case 19:
               var9 = 56;
               break;
            case 20:
               var9 = 9;
               break;
            case 21:
               var9 = 85;
               break;
            case 22:
               var9 = 53;
               break;
            case 23:
               var9 = 228;
               break;
            case 24:
               var9 = 119;
               break;
            case 25:
               var9 = 126;
               break;
            case 26:
               var9 = 166;
               break;
            case 27:
               var9 = 175;
               break;
            case 28:
               var9 = 7;
               break;
            case 29:
               var9 = 156;
               break;
            case 30:
               var9 = 117;
               break;
            case 31:
               var9 = 114;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
