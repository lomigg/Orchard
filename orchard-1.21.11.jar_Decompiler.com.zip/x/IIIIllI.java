package x;

import com.sun.jna.Library;
import com.sun.jna.Native;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
interface IIIIllI extends Library {
   IIIIllI I;
   int l = 4;
   int II = 16;
   String[] Il;
   int lI = 2;
   int ll = 8;
   int[] III;
   String[] IIl;
   Object[] IlI;

   static String I(char[] var0, long var1, int var3) {
      int var4 = Il(-1202849738, -1705714539) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & Il(-1202849737, 388464122);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   static void l() {
      Il[0] = I(lI(-1495837319, -1928984276).toCharArray(), 98772L, Il(-1202849740, 1250897811));
   }

   void II(int var1, int var2, int var3, int var4, int var5);

   static {
      short var6 = 3392;
      String var7 = "轋\uebed跶ȁ覔릐㿌汮";
      char[] var8 = "ൈ".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IIl = var9;
            IlI = new Object[var9.length];
            int var2 = -1817945340;
            byte[] var0 = "\u0080è:¬<ÎÞ6&\u0097\u008e\u009a".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            III = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               III[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            Il = new String[1];
            l();
            I = (IIIIllI)Native.load(lIlIII.Il(Il[0]), IIIIllI.class);
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   static int Il(int var0, int var1) {
      return III[var0 ^ -1202849738] ^ var1 ^ var0;
   }

   private static String lI(int var0, int var1) {
      int var3 = var0 ^ -1495837319;
      char[] var4 = IIl[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IlI[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IlI[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -45852804;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 81;
               break;
            case 1:
               var9 = 57;
               break;
            case 2:
               var9 = 64;
               break;
            case 3:
               var9 = 240;
               break;
            case 4:
               var9 = 169;
               break;
            case 5:
               var9 = 180;
               break;
            case 6:
               var9 = 237;
               break;
            case 7:
               var9 = 223;
               break;
            case 8:
               var9 = 97;
               break;
            case 9:
               var9 = 185;
               break;
            case 10:
               var9 = 205;
               break;
            case 11:
               var9 = 90;
               break;
            case 12:
               var9 = 32;
               break;
            case 13:
               var9 = 140;
               break;
            case 14:
               var9 = 51;
               break;
            case 15:
               var9 = 166;
               break;
            case 16:
               var9 = 183;
               break;
            case 17:
               var9 = 190;
               break;
            case 18:
               var9 = 195;
               break;
            case 19:
               var9 = 16;
               break;
            case 20:
               var9 = 22;
               break;
            case 21:
               var9 = 181;
               break;
            case 22:
               var9 = 37;
               break;
            case 23:
               var9 = 14;
               break;
            case 24:
               var9 = 116;
               break;
            case 25:
               var9 = 91;
               break;
            case 26:
               var9 = 173;
               break;
            case 27:
               var9 = 214;
               break;
            case 28:
               var9 = 228;
               break;
            case 29:
               var9 = 183;
               break;
            case 30:
               var9 = 145;
               break;
            case 31:
               var9 = 214;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
