package x;

import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10185;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_744;

@Environment(EnvType.CLIENT)
public final class IIIIIIlIl extends IIIIIIIlI {
   private long I;
   private <undefinedtype> l;
   private int II;
   private int Il;
   private final llllIlIl lI;
   private final llllIlIl ll;
   private boolean III;
   private final IlIIIlIlI<<undefinedtype>> IIl;
   private class_1297 IlI;
   private long Ill;
   private final IIIllIIII lII;
   private boolean lIl;
   private final lIIIIl llI;
   private static final int[] lll;
   private static final String[] IIII;
   private static final Object[] IIIl;

   private void ll() {
      this.IlI = null;
      this.lIl = false;
   }

   public void III(class_1297 var1) {
      this.ll();
      class_310 var2 = class_310.method_1551();
      if (this.IlI(var2, var1)) {
         this.IlI = var1;
         this.lIl = true;
      }

   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (var1 != null && var1.field_1724 != null && var1.field_1690 != null && this.l != null.I) {
         long var2 = System.currentTimeMillis();
         if (this.l == null.l) {
            if (var2 >= this.I && var1.field_1724.field_6012 >= this.Il) {
               this.l = null.II;
               this.III = false;
               var1.field_1724.method_5728(false);
               this.IIll(var1);
            }
         } else if (this.l == null.II) {
            if (var2 >= this.Ill && var1.field_1724.field_6012 >= this.II) {
               this.llII(var1);
            } else {
               var1.field_1724.method_5728(false);
               this.IIll(var1);
            }
         }

      }
   }

   private boolean IlI(class_310 var1, class_1297 var2) {
      boolean var10000;
      if (var2 instanceof class_1309 var3) {
         if (var1 != null && var1.field_1724 != null && var1.field_1690 != null && var1.field_1755 == null && ((Boolean)this.llI.III() || var1.field_1724.method_24828()) && var3 != var1.field_1724 && var3.method_5805() && !var3.method_31481()) {
            if (!var1.field_1724.method_5624()) {
            }

            if (this.lllI()) {
               var10000 = true;
               return var10000;
            }
         }
      }

      var10000 = false;
      return var10000;
   }

   public String Il() {
      return ((<undefinedtype>)this.IIl.III()).toString();
   }

   public <undefinedtype> lII() {
      return (<undefinedtype>)this.IIl.III();
   }

   private long llI(llllIlIl var1) {
      double var2 = Math.min(var1.IlII(), var1.IlI());
      double var4 = Math.max(var1.IlII(), var1.IlI());
      return var4 <= var2 ? Math.max(0L, Math.round(var2)) : Math.max(0L, Math.round(ThreadLocalRandom.current().nextDouble(var2, var4)));
   }

   private boolean lll(class_310 var1) {
      return var1 != null && var1.field_1724 != null && var1.field_1690 != null && var1.field_1755 == null && (IllllIlI.IIIll(var1, var1.field_1690.field_1894) || var1.field_1690.field_1894.method_1434()) && !IllllIlI.IIIll(var1, var1.field_1690.field_1881) && !var1.field_1724.method_5715() && !var1.field_1724.method_6115();
   }

   public void lI() {
      class_310 var1 = class_310.method_1551();
      this.llII(var1);
   }

   private void IIII(class_310 var1, class_744 var2) {
      this.IIll(var1);
      class_10185 var3 = var2.field_54155;
      boolean var4 = this.IIl.III() == null.II;
      boolean var5 = this.IIl.III() == null.II ? var3.comp_3161() : false;
      boolean var6 = this.IIl.III() == null.II ? var3.comp_3162() : false;
      var2.field_54155 = new class_10185(false, var4, var5, var6, var3.comp_3163(), var3.comp_3164(), false);
      float var7 = var4 ? -1.0F : 0.0F;
      float var8 = var5 == var6 ? 0.0F : (var5 ? 1.0F : -1.0F);
      if (var7 != 0.0F && var8 != 0.0F) {
         float var9 = 0.70710677F;
         var7 *= var9;
         var8 *= var9;
      }

      IllllIlI.llIIIl(var2, var7, var8);
   }

   private void IIll(class_310 var1) {
      if (var1 != null && var1.field_1690 != null) {
         lllI var2 = lllI.lll();
         this.IlII(var1, var2, var1.field_1690.field_1894, false);
         var1.field_1690.field_1894.method_23481(false);
         if (this.IIl.III() == null.II) {
            this.IlII(var1, var2, var1.field_1690.field_1881, true);
            var1.field_1690.field_1881.method_23481(true);
         } else {
            this.IlII(var1, var2, var1.field_1690.field_1881, false);
            var1.field_1690.field_1881.method_23481(false);
         }

      }
   }

   private void IlII(class_310 var1, lllI var2, class_304 var3, boolean var4) {
      if (var3 != null) {
         if (var2 != null) {
            var2.IlI(this, var1, var3, var4);
         } else {
            var3.method_23481(var4);
         }

      }
   }

   public void lllIl(class_310 var1) {
      if (var1 != null && var1.field_1724 != null && var1.field_1690 != null && this.l != null.I) {
         long var2 = System.currentTimeMillis();
         if (this.l == null.l) {
            if (var2 >= this.I) {
               this.l = null.II;
               this.III = false;
               var1.field_1724.method_5728(false);
               this.IIll(var1);
            }
         } else if (this.l == null.II) {
            if (var2 >= this.Ill) {
               this.llII(var1);
            } else {
               var1.field_1724.method_5728(false);
               this.IIll(var1);
            }
         }

      }
   }

   private void IlIl() {
      this.l = null.I;
      this.I = 0L;
      this.Ill = 0L;
      this.Il = IIIIl(-41610074, -1877393025);
      this.II = IIIIl(-41610073, 358290998);
      this.III = false;
      this.ll();
   }

   public IIIIIIlIl() {
      super((Object)lIlIII.l(IIIll(2058369385, -1595256512)), lIllII.III, (Object)lIlIII.l(IIIll(2058369384, -1727694954)));
      this.IIl = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IIIll(2058369387, 114976089)), <undefinedtype>.class, null.Il));
      this.ll = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(IIIll(2058369386, 884243876)), (double)100.0F, (double)150.0F, (double)20.0F, (double)500.0F, (double)5.0F)).Ill(lIlIII.l(IIIll(2058369389, -83857012))));
      this.lI = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(IIIll(2058369388, -935066080)), (double)0.0F, (double)15.0F, (double)0.0F, (double)200.0F, (double)1.0F)).Ill(lIlIII.l(IIIll(2058369391, 187177261))));
      this.llI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIIll(2058369390, 1868173360)), true));
      this.lII = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IIIll(2058369377, 82653356)), (double)100.0F, (double)0.0F, (double)100.0F, (double)1.0F)).IIIl(lIlIII.l(IIIll(2058369376, 1871215645))));
      this.l = null.I;
      this.Il = IIIIl(-41610076, 203873085);
      this.II = IIIIl(-41610075, -869018829);
   }

   public boolean Illl(class_310 var1, class_744 var2) {
      if (this.l == null.I) {
         return false;
      } else if (this.IIIIIlI() && var1 != null && var1.field_1724 != null && var1.field_1690 != null && var2 != null && var2.field_54155 != null && var1.field_1755 == null) {
         long var3 = System.currentTimeMillis();
         if (this.l == null.l) {
            if (var3 < this.I || var1.field_1724.field_6012 < this.Il) {
               return false;
            }

            this.l = null.II;
            this.III = false;
         }

         if (var3 >= this.Ill && var1.field_1724.field_6012 >= this.II) {
            this.llII(var1);
            return false;
         } else {
            var1.field_1724.method_5728(false);
            this.III = true;
            this.IIII(var1, var2);
            return true;
         }
      } else {
         this.llII(var1);
         return false;
      }
   }

   public boolean lIII() {
      return this.IIIIIlI() && this.l == null.II;
   }

   public void lIlI(class_1297 var1) {
      class_310 var2 = class_310.method_1551();
      boolean var3 = this.lIl && var1 == this.IlI;
      if (!var3 && this.IlI(var2, var1)) {
         var3 = true;
      }

      this.ll();
      if (var3 && var1 instanceof class_1309 var4) {
         if (var2 != null && var2.field_1724 != null && var2.field_1690 != null && var2.field_1755 == null && var4 != var2.field_1724 && var4.method_5805() && !var4.method_31481()) {
            long var5 = System.currentTimeMillis();
            long var7 = this.llI(this.lI);
            this.I = var5 + var7;
            this.Il = var2.field_1724.field_6012 + (var7 <= 0L ? 0 : (int)Math.ceil((double)var7 / (double)50.0F));
            long var9 = Math.max(1L, this.llI(this.ll));
            this.Ill = this.I + var9;
            this.II = this.Il + Math.max(2, (int)Math.ceil((double)var9 / (double)50.0F));
            this.III = false;
            this.l = var7 <= 0L ? null.II : null.l;
            if (this.l == null.II) {
               var2.field_1724.method_5728(false);
               this.III = true;
               this.IIll(var2);
            }

            return;
         }
      }

   }

   private void lIIl(class_310 var1) {
      if (var1 != null && var1.field_1690 != null) {
         lllI var2 = lllI.lll();
         if (var2 != null) {
            var2.IIl(this, var1);
         } else {
            this.IIIII(var1, (lllI)null, var1.field_1690.field_1894);
            this.IIIII(var1, (lllI)null, var1.field_1690.field_1881);
         }

      }
   }

   private void llII(class_310 var1) {
      this.lIIl(var1);
      if (this.III && this.lll(var1)) {
         var1.field_1724.method_5728(true);
      }

      this.IlIl();
   }

   private boolean lllI() {
      double var1 = (Double)this.lII.III();
      if (var1 >= (double)100.0F) {
         return true;
      } else if (var1 <= (double)0.0F) {
         return false;
      } else {
         return ThreadLocalRandom.current().nextDouble((double)100.0F) < var1;
      }
   }

   private void IIIII(class_310 var1, lllI var2, class_304 var3) {
      if (var3 != null) {
         if (var2 != null) {
            var2.IIIl(this, var1, var3);
         } else {
            var3.method_23481(var1 != null && IllllIlI.IIIll(var1, var3));
         }

      }
   }

   private static int IIIIl(int var0, int var1) {
      return lll[var0 ^ -41610074] ^ var1 ^ var0;
   }

   static {
      short var6 = 1364;
      String var7 = "혗훌횪홢횩혦홺혨홌횐횉혇훚홤혷혲\ueff8\uef67\uef51\uef82\uef47\uefca\uefc0\uefc6\uefbf\uef56\uef20\uefe5\uef36\uefa2\ueff1\uefb8\uef03\uefd9\uef9e\uefec\uefc8\uef53\ueffa\uef51\uef0c\uef12\uefb5\uefe3\uef34\uef7e\uefe3\uefdb\uefb8\uef6d\uef38\uef99\uef48\uefca\uefc6\uefc7\uef94\uef67\uef4c\uefe6\uef40\uef95\uefcd\uefb2\uef08\uefba\uef94\uefff\ueffb\uef57\uefd6\uef7a\uef3e\uef19\uefb6\ueff2\uef1c\uef10\ueff9\ueff2\uefe4\uef73\uef45\uefac\uef41\ueff3\uefab\uefd6\uefad\uef6f\uef3d\ueffa\uef32\uefe7\ueffa\uefb8瀢炒炼灄炘瀕瀓灡䉎䋯䋠䈼䋵䉻䉱䉗䈓䋞䋳䈡跠赋赱跲뺹븦븐뻝븅뺭뺁뺧뻣븮븆뺴빼뻙뺚뻷빁뻞뻠뻂緈絣絙線ᦣᤒᤠ\u19ccᤞᦳᦚᦄᧀᤚᤘᦪᥥ᧗\u19ae᧳爔狊犇牴犩爛物爸ᤷ\u19cbᦧ\u197a";
      char[] var8 = "ՄԄ՜\u0558ՐՀՐՄ՜Ր".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IIII = var9;
            IIIl = new Object[var9.length];
            int var2 = 1987123569;
            byte[] var0 = "\u009bíL¨\u001e¯\u001bà\u0007ÒÖèÇÇÞç".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lll = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lll[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static String IIIll(int var0, int var1) {
      int var3 = var0 ^ 2058369385;
      char[] var4 = IIII[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IIIl[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IIIl[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -1679738906;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 75;
               break;
            case 1:
               var9 = 213;
               break;
            case 2:
               var9 = 213;
               break;
            case 3:
               var9 = 8;
               break;
            case 4:
               var9 = 232;
               break;
            case 5:
               var9 = 89;
               break;
            case 6:
               var9 = 51;
               break;
            case 7:
               var9 = 65;
               break;
            case 8:
               var9 = 56;
               break;
            case 9:
               var9 = 213;
               break;
            case 10:
               var9 = 201;
               break;
            case 11:
               var9 = 111;
               break;
            case 12:
               var9 = 179;
               break;
            case 13:
               var9 = 16;
               break;
            case 14:
               var9 = 105;
               break;
            case 15:
               var9 = 34;
               break;
            case 16:
               var9 = 134;
               break;
            case 17:
               var9 = 46;
               break;
            case 18:
               var9 = 12;
               break;
            case 19:
               var9 = 124;
               break;
            case 20:
               var9 = 97;
               break;
            case 21:
               var9 = 223;
               break;
            case 22:
               var9 = 81;
               break;
            case 23:
               var9 = 240;
               break;
            case 24:
               var9 = 150;
               break;
            case 25:
               var9 = 137;
               break;
            case 26:
               var9 = 31;
               break;
            case 27:
               var9 = 123;
               break;
            case 28:
               var9 = 167;
               break;
            case 29:
               var9 = 234;
               break;
            case 30:
               var9 = 74;
               break;
            case 31:
               var9 = 125;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
