package x;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_239.class_240;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;

@Environment(EnvType.CLIENT)
public final class IIlIIllI extends IIIIIIIlI {
   private final llllIlIl I;
   private final IlIlIll l;
   private long II;
   private final llllIlIl Il;
   private final lIIIIl lI;
   private final lIIIIl ll;
   private final IlIIIlIlI<<undefinedtype>> III;
   private final IIIllIIII IIl;
   private final IIIllIIII IlI;
   private static final int[] Ill;
   private static final String[] lII;
   private static final Object[] lIl;

   private boolean II(class_310 var1) {
      return var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var1.field_1755 == null && var1.field_1724.method_5805() && !lIlIllll.lIIl(var1);
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (this.II(var1) && System.currentTimeMillis() >= this.II) {
         if (!IlIlIl.ll() && !IllllIlI.IlllIl()) {
            class_1657 var2 = this.lIll(var1);
            int var3 = this.IlII(var1);
            if (var2 != null && var3 >= 0) {
               <undefinedtype> var4 = this.Illl(var1, var2);
               if (var4 == null) {
                  this.l.IIllII();
               } else if (this.III.III() != null.II) {
                  boolean var9 = IlIlIl.IIlIII(var1, llII(657180406, -930650380), var4.I(), () -> IllllIlI.llIll(var1, this, var3, () -> {
                        boolean var2 = IllllIlI.IIlIIII(var1, var4.l());
                        if (var2) {
                           var1.field_1724.method_6104(class_1268.field_5808);
                        }

                        return var2;
                     }));
                  if (var9) {
                     this.II = System.currentTimeMillis() + this.lIIl(this.I) + this.lIIl(this.Il);
                  }

               } else {
                  boolean var10000;
                  label75: {
                     label74: {
                        float var5 = this.l.IlIl(var1, var4.I(), ((Double)this.IlI.III()).floatValue());
                        if (!(var5 <= 1.0F)) {
                           class_239 var8 = var1.field_1765;
                           if (!(var8 instanceof class_3965)) {
                              break label74;
                           }

                           class_3965 var7 = (class_3965)var8;
                           if (!var7.method_17777().equals(var4.l().method_17777()) || var7.method_17780() != var4.l().method_17780()) {
                              break label74;
                           }
                        }

                        var10000 = true;
                        break label75;
                     }

                     var10000 = false;
                  }

                  boolean var6 = var10000;
                  if (var6) {
                     this.l.IIllII();
                     boolean var10 = IllllIlI.llIll(var1, this, var3, () -> {
                        boolean var2 = IllllIlI.IIlIIII(var1, var4.l());
                        if (var2) {
                           var1.field_1724.method_6104(class_1268.field_5808);
                        }

                        return var2;
                     });
                     if (var10) {
                        this.II = System.currentTimeMillis() + this.lIIl(this.I) + this.lIIl(this.Il);
                     }
                  }

               }
            } else {
               this.l.IIllII();
            }
         }
      }
   }

   public void lI() {
      this.l.IIIlIll();
      this.l.IIllII();
   }

   public void lIl() {
      this.l.IIlIIII();
   }

   private List<class_2338> lII(class_1657 var1) {
      class_238 var2 = var1.method_5829();
      int var3 = (int)Math.floor(var2.field_1322 + (double)1.0F + 1.0E-4);
      class_2338 var4 = class_2338.method_49637(var1.method_23317(), (double)var3, var1.method_23321());
      ArrayList var5 = new ArrayList();
      var5.add(var4);
      class_243 var6 = var1.method_18798();
      double var7 = Math.hypot(var6.field_1352, var6.field_1350);
      boolean var9 = (Boolean)this.ll.III() && (var7 > 0.04 || Math.abs(var6.field_1351) > 0.05);
      class_238 var10 = var9 ? var2.method_989(var6.field_1352 * Math.min(1.8, var7 * (double)2.5F), var6.field_1351 * Math.min(1.2, Math.abs(var6.field_1351) * (double)2.0F), var6.field_1350 * Math.min(1.8, var7 * (double)2.5F)) : var2;
      class_243 var11 = var9 ? var10.method_1005() : var2.method_1005();
      int var12 = (int)Math.floor(Math.min(var2.field_1323, var10.field_1323));
      int var13 = (int)Math.floor(Math.max(var2.field_1320, var10.field_1320) - 1.0E-7);
      int var14 = (int)Math.floor(Math.min(var2.field_1321, var10.field_1321));
      int var15 = (int)Math.floor(Math.max(var2.field_1324, var10.field_1324) - 1.0E-7);
      int var16 = (int)Math.floor(var10.field_1322 + (double)1.0F + 1.0E-4);

      for(int var17 = var12; var17 <= var13; ++var17) {
         for(int var18 = var14; var18 <= var15; ++var18) {
            class_2338 var19 = new class_2338(var17, var3, var18);
            if (!var5.contains(var19)) {
               var5.add(var19);
            }

            if (var16 != var3) {
               class_2338 var20 = new class_2338(var17, var16, var18);
               if (!var5.contains(var20)) {
                  var5.add(var20);
               }
            }
         }
      }

      var5.sort(Comparator.comparingDouble((var1x) -> class_243.method_24953(var1x).method_1025(var11)));
      return var5;
   }

   private boolean lll(class_310 var1, class_243 var2) {
      double var3 = Math.max((double)0.0F, var1.field_1724.method_55754() - 0.1);
      return var1.field_1724.method_33571().method_1025(var2) <= var3 * var3;
   }

   private boolean IIll(class_1657 var1) {
      if (var1 == null) {
         return false;
      } else if (!var1.method_24828() && !var1.method_6101() && !var1.method_5799() && !var1.method_5771() && !var1.method_6128()) {
         return var1.field_6017 > (double)0.0F || var1.method_18798().field_1351 < -0.05;
      } else {
         return false;
      }
   }

   private int IlII(class_310 var1) {
      for(int var2 = 0; var2 < llII(657180407, -582009704); ++var2) {
         class_1799 var3 = var1.field_1724.method_31548().method_5438(var2);
         if (var3 != null && var3.method_31574(class_1802.field_8786)) {
            return var2;
         }
      }

      return -1;
   }

   private <undefinedtype> Illl(class_310 var1, class_1657 var2) {
      for(class_2338 var4 : this.lII(var2)) {
         <undefinedtype> var5 = this.lIII(var1, var4);
         if (var5 != null) {
            return var5;
         }
      }

      return null;
   }

   private <undefinedtype> lIII(class_310 var1, class_2338 var2) {
      if (!var1.field_1687.method_8320(var2).method_45474()) {
         return null;
      } else {
         for(class_2350 var6 : class_2350.values()) {
            class_2338 var7 = var2.method_10093(var6);
            class_2680 var8 = var1.field_1687.method_8320(var7);
            if (!var8.method_26215() && !var8.method_45474() && !var8.method_26220(var1.field_1687, var7).method_1110()) {
               class_2350 var9 = var6.method_10153();
               class_243 var10 = class_243.method_24953(var7).method_1019(class_243.method_24954(var9.method_62675()).method_1021((double)0.5F));
               if (this.lll(var1, var10)) {
                  class_243 var11 = var10.method_1020(class_243.method_24954(var9.method_62675()).method_1021(0.01));
                  class_3965 var12 = var1.field_1687.method_17742(new class_3959(var1.field_1724.method_33571(), var11, class_3960.field_17559, class_242.field_1348, var1.field_1724));
                  if (var12 != null && var12.method_17783() == class_240.field_1332 && var12.method_17777().equals(var7) && var2.equals(var7.method_10093(var12.method_17780()))) {
                     return new Record(var12.method_17784(), var12) {
                        private final class_243 I;
                        private final class_3965 l;

                        private {
                           this.I = var1;
                           this.l = var2;
                        }

                        public class_243 I() {
                           return this.I;
                        }

                        public class_3965 l() {
                           return this.l;
                        }
                     };
                  }
               }
            }
         }

         return null;
      }
   }

   private long lIIl(llllIlIl var1) {
      double var2 = var1.IlII();
      double var4 = var1.IlI();
      return var2 == var4 ? Math.max(0L, Math.round(var2)) : Math.max(0L, Math.round(ThreadLocalRandom.current().nextDouble(var2, var4)));
   }

   private class_1657 lIll(class_310 var1) {
      double var2 = (Double)this.IIl.III() * (Double)this.IIl.III();
      class_1657 var4 = null;
      double var5 = Double.POSITIVE_INFINITY;

      for(class_1657 var8 : var1.field_1687.method_18456()) {
         if (var8 != var1.field_1724 && var8.method_5805() && !var8.method_7325() && !var8.method_68878() && !IlIII.I(var8) && (!(Boolean)this.lI.III() || this.IIll(var8))) {
            double var9 = var1.field_1724.method_5858(var8);
            if (var9 <= var2 && var9 < var5) {
               var4 = var8;
               var5 = var9;
            }
         }
      }

      return var4;
   }

   public IIlIIllI() {
      super((Object)lIlIII.l(lllI((short)24976, -965522426, '䂍')), lIllII.I, (Object)lIlIII.l(lllI((short)4770, 272171376, '䂌')));
      this.III = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(lllI((short)'\uee02', -1860955720, '䂏')), <undefinedtype>.class, null.l));
      this.IlI = (IIIllIIII)this.IIIlIll((IIIllIIII)(new IIIllIIII(lIlIII.l(lllI((short)'\udd79', 518263216, '䂎')), (double)50.0F, (double)1.0F, (double)100.0F, (double)1.0F)).lIII(() -> this.III.III() == null.II));
      this.IIl = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(lllI((short)9033, -648991332, '䂉')), (double)4.5F, (double)1.0F, (double)6.0F, 0.1)).IIIl(lIlIII.l(lllI((short)'ꎣ', -831383103, '䂈'))));
      this.Il = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(lllI((short)29967, 548558160, '䂋')), (double)0.0F, (double)0.0F, (double)0.0F, (double)300.0F, (double)5.0F)).Ill(lIlIII.l(lllI((short)30960, -369541304, '䂊'))));
      this.I = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(lllI((short)20752, -314948049, '䂅')), (double)50.0F, (double)75.0F, (double)0.0F, (double)500.0F, (double)5.0F)).Ill(lIlIII.l(lllI((short)'\uedf7', 2070240004, '䂄'))));
      this.ll = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lllI((short)11848, 1115710188, '䂇')), true));
      this.lI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lllI((short)27906, -1855235140, '䂆')), false));
      this.l = new IlIlIll();
   }

   private static int llII(int var0, int var1) {
      return Ill[var0 ^ 657180406] ^ var1 ^ var0;
   }

   static {
      short var6 = 18471;
      String var7 = "㸁㹝㹮㹥㸋䪵㷸䪷㹞㹒䪲㹠㹓㹫㸌㸃㹰㹕䫩䫩ꜭꞲ꜔ꞶꜞꜤꜤ\ua7e9\ua7e9ꞺꝫꟄꞻꝙꞺꜚ\ua7e7ꞾꜚꜛꝫꜬ꜡ꞽ\ua7e6ꞲꝬꟄ\ua7e6ꝭꝤꟁ꜔ꜗꟉꟊꟄꞽꞴꞴꜞꜬꜝꟈ꜠Ꞷ\ua7e8ꜛ\ua7e8꜠ꝥꞶ\ua7e9ꜘꜛꞲꝫꝬꜫꞳꝬꜘꝪꞷ꜡ꟂꟂꟅ꜡Ꞷ꜠\ua7e9ꟊ\ua7cdꜥꞴꞺꝘꝭꞾꞸꝥꞴ\ua7cb꜓ꟂꜙꟆ\ua7e6ꞲꞹꞳ\ua7e6ꝭ\ua7e9Ʂꜞ\ua7cd꜡ꜛꟄꞽꞴꞴ꜓ꞽꝱꝱ㊰㊱㊥㍀㊛㍐㋰㊔㌹㊙㌽㌹㍧㌷㌿㊕㌾㊒㋬㋬\uea2b\ue6d0\uea57\ue6d0\uea59\ue6e9\uea16\ue6be\ue6cc\ue6b8\uea13\ue6ca꾪꾫뀹꾚꾞꾣꾘꿮萇葢葚葔萈葪菼菿颷鰊鰔颺颿飈颶颼鰛鰚颿鰙飈鰠鰋飇咮唳咭哟\uf23b\uf1a8\uf197\uf246\uf17a\uf199\uf17c\uf19a\uf195\uf1ab\uf17b\uf1ae寉富嬒存腚脂胵能腮脍脍脦能脍脨胲脍腘脞脞놨녺놈뇓놅뇬뇬뇔놈눻녳뉦뇬녺뇰뇫";
      char[] var8 = "䠳䡋䠳䠫䠯䠯䠷䠣䠫䠣䠷䠷".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            lII = var9;
            lIl = new Object[var9.length];
            int var2 = -747093706;
            byte[] var0 = "<Ôáü)\u001c»P".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            Ill = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               Ill[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static String lllI(short var0, int var1, char var2) {
      int var3 = var2 ^ 16525;
      char[] var4 = lII[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])lIl[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         lIl[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 19767;
      int var9 = 0;

      do {
         int var10 = var4[var9] - 16069;
         var10 -= 7597;
         var10 ^= 23405;
         var10 ^= 709;
         var10 -= 36956;
         var10 ^= 10906;
         var10 ^= 5030;
         var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
