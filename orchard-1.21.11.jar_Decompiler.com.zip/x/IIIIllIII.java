package x;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import java.util.AbstractSet;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class IIIIllIII extends llllllI<Set<String>> {
   private final List<<undefinedtype>> I;

   public Set<String> I() {
      return III(lll((Set)this.l(), this.I));
   }

   public IIIIllIII(Object var1, List<<undefinedtype>> var2, Collection<?> var3) {
      super((Object)var1, IIll(var3, var2));
      this.I = List.copyOf(var2);
      this.Ill(var3);
   }

   public boolean l(String var1) {
      return var1 != null && this.IlI().l(lIlIII.II(var1));
   }

   public boolean ll(Object var1) {
      return var1 != null && this.IlI().l(var1.lI());
   }

   private static Set<String> III(Object var0) {
      LinkedHashSet var1 = new LinkedHashSet();

      for(String var3 : var0) {
         var1.add(var3);
      }

      return Collections.unmodifiableSet(var1);
   }

   public JsonElement lI() {
      JsonArray var1 = new JsonArray();

      for(String var3 : this.IlI()) {
         var1.add(var3);
      }

      return var1;
   }

   public void IIl(Object var1) {
      if (var1 != null && this.I.contains(var1)) {
         LinkedHashSet var2 = new LinkedHashSet(this.IlI().I());
         if (!var2.remove(var1.lI())) {
            var2.add(var1.lI());
         }

         super.Il(new AbstractSet<String>(this.I, var2) {
            private final List<<undefinedtype>> I;
            private final Set<Long> l;

            private Set<Long> I() {
               return this.l;
            }

            public boolean equals(Object var1) {
               if (var1 == this) {
                  return true;
               } else if (var1 instanceof <undefinedtype>) {
                  <undefinedtype> var2 = (<undefinedtype>)var1;
                  return this.l.equals(var2.l);
               } else {
                  return super.equals(var1);
               }
            }

            public Iterator<String> iterator() {
               Iterator var1 = this.l.iterator();
               return new Iterator<String>(var1) {
                  // $FF: synthetic field
                  final Iterator I;
                  // $FF: synthetic field
                  final <undefinedtype> l;

                  public boolean hasNext() {
                     return this.I.hasNext();
                  }

                  {
                     this.I = var2;
                     this.l = var1;
                  }

                  public String I() {
                     if (!this.I.hasNext()) {
                        throw new NoSuchElementException();
                     } else {
                        <undefinedtype> var1 = this.l.II((Long)this.I.next());
                        if (var1 == null) {
                           throw new NoSuchElementException();
                        } else {
                           return var1.ll();
                        }
                     }
                  }
               };
            }

            private boolean l(long var1) {
               return this.l.contains(var1);
            }

            public boolean contains(Object var1) {
               Long var2 = IIIIllIII.IIlI(var1);
               return var2 != null && this.l(var2);
            }

            public int size() {
               return this.l.size();
            }

            private {
               this.I = List.copyOf(var1);
               this.l = Collections.unmodifiableSet(new LinkedHashSet(var2));
            }

            public int hashCode() {
               int var1 = 0;

               for(long var3 : this.l) {
                  <undefinedtype> var5 = this.II(var3);
                  if (var5 != null) {
                     var1 += var5.l;
                  }
               }

               return var1;
            }

            private <undefinedtype> II(long var1) {
               for(<undefinedtype> var4 : this.I) {
                  if (var4.lI() == var1) {
                     return var4;
                  }
               }

               return null;
            }
         });
      }
   }

   private <undefinedtype> IlI() {
      return lll((Set)super.III(), this.I);
   }

   private void Ill(Collection<?> var1) {
      super.Il(IIll(var1, this.I));
   }

   public Set<String> lII() {
      return III(this.IlI());
   }

   public List<<undefinedtype>> lIl() {
      return this.I;
   }

   public void llI(Set<String> var1) {
      this.Ill(var1);
   }

   public void II(JsonElement var1) {
      if (var1 != null && !var1.isJsonNull()) {
         ArrayList var2 = new ArrayList();
         if (var1.isJsonArray()) {
            for(JsonElement var4 : var1.getAsJsonArray()) {
               if (var4 != null && var4.isJsonPrimitive()) {
                  var2.add(var4.getAsString());
               }
            }
         } else if (var1.isJsonPrimitive()) {
            var2.add(var1.getAsString());
         }

         this.IIIl(var2);
      }
   }

   public IIIIllIII(String var1, List var2, Collection var3) {
      this((Object)var1, var2, var3);
   }

   private static <undefinedtype> lll(Set<String> var0, List<<undefinedtype>> var1) {
      <undefinedtype> var10000;
      if (var0 instanceof <undefinedtype> var2) {
         var10000 = var2;
      } else {
         var10000 = IIll(var0, var1);
      }

      return var10000;
   }

   public boolean IIII(Object var1) {
      return var1 != null && this.IlI().l(var1.lll());
   }

   public void IIIl(Collection<String> var1) {
      this.Ill(var1);
   }

   private static Long IIlI(Object var0) {
      if (var0 instanceof String var3) {
         return lIlIII.II(var3);
      } else if (var0 instanceof <undefinedtype> var2) {
         return var2.lll();
      } else if (var0 instanceof <undefinedtype> var1) {
         return var1.lI();
      } else {
         return null;
      }
   }

   private static <undefinedtype> IIll(Collection<?> var0, List<<undefinedtype>> var1) {
      List var2 = List.copyOf(var1);
      LinkedHashSet var3 = new LinkedHashSet();

      for(<undefinedtype> var5 : var2) {
         var3.add(var5.lI());
      }

      LinkedHashSet var9 = new LinkedHashSet();
      if (var0 instanceof <undefinedtype> var10) {
         for(long var7 : var10.I()) {
            if (var3.contains(var7)) {
               var9.add(var7);
            }
         }
      } else if (var0 != null) {
         for(Object var12 : var0) {
            Long var8 = IIlI(var12);
            if (var8 != null && var3.contains(var8)) {
               var9.add(var8);
            }
         }
      }

      return new AbstractSet<String>(var2, var9) {
         private final List<<undefinedtype>> I;
         private final Set<Long> l;

         private Set<Long> I() {
            return this.l;
         }

         public boolean equals(Object var1) {
            if (var1 == this) {
               return true;
            } else if (var1 instanceof <undefinedtype>) {
               <undefinedtype> var2 = (<undefinedtype>)var1;
               return this.l.equals(var2.l);
            } else {
               return super.equals(var1);
            }
         }

         public Iterator<String> iterator() {
            Iterator var1 = this.l.iterator();
            return new Iterator<String>(var1) {
               // $FF: synthetic field
               final Iterator I;
               // $FF: synthetic field
               final <undefinedtype> l;

               public boolean hasNext() {
                  return this.I.hasNext();
               }

               {
                  this.I = var2;
                  this.l = var1;
               }

               public String I() {
                  if (!this.I.hasNext()) {
                     throw new NoSuchElementException();
                  } else {
                     <undefinedtype> var1 = this.l.II((Long)this.I.next());
                     if (var1 == null) {
                        throw new NoSuchElementException();
                     } else {
                        return var1.ll();
                     }
                  }
               }
            };
         }

         private boolean l(long var1) {
            return this.l.contains(var1);
         }

         public boolean contains(Object var1) {
            Long var2 = IIIIllIII.IIlI(var1);
            return var2 != null && this.l(var2);
         }

         public int size() {
            return this.l.size();
         }

         private {
            this.I = List.copyOf(var1);
            this.l = Collections.unmodifiableSet(new LinkedHashSet(var2));
         }

         public int hashCode() {
            int var1 = 0;

            for(long var3 : this.l) {
               <undefinedtype> var5 = this.II(var3);
               if (var5 != null) {
                  var1 += var5.l;
               }
            }

            return var1;
         }

         private <undefinedtype> II(long var1) {
            for(<undefinedtype> var4 : this.I) {
               if (var4.lI() == var1) {
                  return var4;
               }
            }

            return null;
         }
      };
   }
}
