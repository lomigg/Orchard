package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;

@Environment(EnvType.CLIENT)
public final class lIlIllII extends IIIIIIIlI {
   private static String[] I;
   private static final int[] l;
   private static final String[] II;
   private static final Object[] Il;

   private static void ll() {
      I[0] = IlI(lll(1160157517, 2062878173).toCharArray(), 69906L, llI(964107943, -512578077));
      I[1] = IlI(lll(1160157516, 2029142474).toCharArray(), 40871L, llI(964107942, -464034300));
   }

   private static String IlI(char[] var0, long var1, int var3) {
      int var4 = llI(964107941, 1399433030) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & llI(964107940, -2146588900);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   public lIlIllII() {
      super((Object)lIlIII.l(I[0]), lIllII.III, (Object)lIlIII.l(I[1]));
   }

   public boolean lII() {
      if (!this.IIIIIlI()) {
         return false;
      } else {
         class_310 var1 = class_310.method_1551();
         if (var1.field_1724 != null && var1.field_1690 != null && var1.field_1755 == null) {
            if (var1.field_1724.method_5805() && !var1.field_1724.method_5715() && !var1.field_1724.method_6115()) {
               return var1.field_1690.field_1894.method_1434() && !var1.field_1690.field_1881.method_1434();
            } else {
               return false;
            }
         } else {
            return false;
         }
      }
   }

   static {
      short var6 = 31781;
      String var7 = "પ覶덑뗠ﲠ嘚⼊횼죛很궻۾拡\ue9be衧ꀗ㭏녌㻞傉ҕ괠双笠ᰘ趼䭏忀㲇成\udc8cⵣ坖㪅㝌쎂潈\udc8e僁≯\uf27f궘᳦\udb9dŌ㒇ὴȿ♬뵢췘顐磈㎭嘦ะ汩ﺫ\ue02d쉽\uddc8\uedcb빺㼔۹휫浴\u0b3b斑냉懃Ȋ夂陥呒썅";
      char[] var8 = "簭籡".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            II = var9;
            Il = new Object[var9.length];
            int var2 = 1022056254;
            byte[] var0 = "N\u0013\u0015\u0080\u0012TÀ\b´Í¯T\u0085\u0091îy".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            l = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               l[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            I = new String[2];
            ll();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 116;
                     break;
                  case 1:
                     var10000 = 86;
                     break;
                  case 2:
                     var10000 = 6;
                     break;
                  case 3:
                     var10000 = 98;
                     break;
                  case 4:
                     var10000 = 7;
                     break;
                  case 5:
                     var10000 = 9;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static int llI(int var0, int var1) {
      return l[var0 ^ 964107943] ^ var1 ^ var0;
   }

   private static String lll(int var0, int var1) {
      int var3 = var0 ^ 1160157517;
      char[] var4 = II[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])Il[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         Il[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -603902081;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 156;
               break;
            case 1:
               var9 = 26;
               break;
            case 2:
               var9 = 20;
               break;
            case 3:
               var9 = 161;
               break;
            case 4:
               var9 = 236;
               break;
            case 5:
               var9 = 181;
               break;
            case 6:
               var9 = 135;
               break;
            case 7:
               var9 = 186;
               break;
            case 8:
               var9 = 156;
               break;
            case 9:
               var9 = 201;
               break;
            case 10:
               var9 = 53;
               break;
            case 11:
               var9 = 208;
               break;
            case 12:
               var9 = 178;
               break;
            case 13:
               var9 = 140;
               break;
            case 14:
               var9 = 224;
               break;
            case 15:
               var9 = 115;
               break;
            case 16:
               var9 = 131;
               break;
            case 17:
               var9 = 138;
               break;
            case 18:
               var9 = 254;
               break;
            case 19:
               var9 = 212;
               break;
            case 20:
               var9 = 18;
               break;
            case 21:
               var9 = 91;
               break;
            case 22:
               var9 = 223;
               break;
            case 23:
               var9 = 88;
               break;
            case 24:
               var9 = 193;
               break;
            case 25:
               var9 = 157;
               break;
            case 26:
               var9 = 79;
               break;
            case 27:
               var9 = 65;
               break;
            case 28:
               var9 = 5;
               break;
            case 29:
               var9 = 122;
               break;
            case 30:
               var9 = 21;
               break;
            case 31:
               var9 = 240;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
