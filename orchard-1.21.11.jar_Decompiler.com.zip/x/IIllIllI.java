package x;

import java.util.ArrayDeque;
import java.util.regex.Pattern;

public final class IIllIllI {
   private int I;
   private final ArrayDeque<Long> l = new ArrayDeque();
   private static final double II = (double)0.5F;
   private int Il;
   public static final int lI = 5;
   private static final double ll = 0.35;
   public static final double III = (double)2.75F;
   private double IIl;
   private static final int IlI = 3;
   private long Ill = Long.MIN_VALUE;
   private double lII;
   private long lIl = Long.MIN_VALUE;
   public static final double llI = (double)12.0F;
   public static final int lll = 3;
   private static final Pattern IIII;
   private int IIIl;
   private double IIlI;
   private double IIll;
   public static final int IlII = 40;
   private static final double IlIl = (double)2.0F;
   private double IllI;
   private double Illl = Double.NaN;
   private static final int lIII = 20;
   private static final double lIIl = (double)3.0F;
   private static final int lIlI = 2;
   private static String[] lIll;
   private static final int[] llII;
   private static final String[] llIl;
   private static final Object[] lllI;

   private static double I(double var0, double var2, double var4, double var6, double var8, double var10) {
      double var12 = var6 - var0;
      double var14 = var8 - var2;
      double var16 = var10 - var4;
      return Math.sqrt(var12 * var12 + var14 * var14 + var16 * var16);
   }

   private <undefinedtype> l(Object var1, long var2) {
      int var4 = this.lIl < var2 ? 0 : (int)Math.min(2147483647L, this.lIl - var2);
      return new Record(this.IIl, this.IllI, this.IIl >= var1.ll() && this.IllI >= var1.l(), var4) {
         private final double I;
         private final int l;
         private final boolean II;
         private final double Il;

         public double I() {
            return this.I;
         }

         public boolean l() {
            return this.II;
         }

         public {
            this.I = var1;
            this.Il = var3;
            this.II = var5;
            this.l = var6;
         }

         public int II() {
            return this.l;
         }

         public double Il() {
            return this.Il;
         }
      };
   }

   private boolean II(long var1) {
      while(!this.l.isEmpty() && var1 - (Long)this.l.peekFirst() > 40L) {
         this.l.removeFirst();
      }

      this.l.addLast(var1);
      return this.l.size() >= 3;
   }

   static {
      short var6 = 9072;
      String var7 = "\uefdd䔨嘼壤ꛮ쎝写\uf8cd軲뇼ꩶ툀鄶衰䑁\uf53a좋嫹\udae1桂뽾勅夊ꅃ盳翥涁\uf897雛忊䐷䈐";
      char[] var8 = "⍨⍸".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            llIl = var9;
            lllI = new Object[var9.length];
            int var2 = -321965447;
            byte[] var0 = "\u001d¥B\u0003¦7\u0014nd\u0015ÕÄô.É\u0000§\u0001®\u0099".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            llII = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               llII[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            lIll = new String[2];
            ll();
            IIII = Pattern.compile(lIlIII.Il(lIll[0]));
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 106;
                     break;
                  case 1:
                     var10000 = 17;
                     break;
                  case 2:
                     var10000 = 118;
                     break;
                  case 3:
                     var10000 = 1;
                     break;
                  case 4:
                     var10000 = 109;
                     break;
                  case 5:
                     var10000 = 94;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public <undefinedtype> Il(Object var1, Object var2) {
      if (var1 == null) {
         throw new IllegalArgumentException(lIlIII.Il(lIll[1]));
      } else {
         <undefinedtype> var3 = var2 == null ? null.IIl : var2;
         if (var1.II() == this.Ill) {
            return this.l(var3, var1.II());
         } else {
            if (var1.II() < this.Ill) {
               this.lI();
            }

            boolean var4 = this.Ill != Long.MIN_VALUE;
            long var5 = var4 ? var1.II() - this.Ill : 1L;
            double var7 = 0.35 * (double)Math.min(Math.max(1L, var5), 40L);
            this.IIl = Math.max((double)0.0F, this.IIl - var7);
            this.IllI = Math.max((double)0.0F, this.IllI - var7);
            boolean var9 = var4 && var5 == 1L;
            double var10 = var9 && IIl(var1) ? I(this.IIlI, this.lII, this.IIll, var1.lII(), var1.lI(), var1.ll()) : Double.NaN;
            boolean var12 = var9 && !var1.IIl() && Double.isFinite(var10);
            boolean var13 = var12 && var1.Il();
            boolean var14 = var1.II() <= this.lIl;
            boolean var15 = false;
            if (var12 && var10 >= (double)12.0F) {
               this.lIl = var1.II() + 5L;
               var14 = true;
               this.Il = 0;
               if (var1.Il()) {
                  var15 = this.II(var1.II());
               }
            } else {
               double var16 = Double.isFinite(this.Illl) ? Math.min((double)0.5F, Math.max((double)0.0F, this.Illl) * (double)0.25F) : (double)0.0F;
               double var18 = (double)2.75F + var16;
               if (var13 && !var14 && var10 >= var18) {
                  ++this.Il;
               } else {
                  this.Il = 0;
               }
            }

            boolean var23 = var1.l() && var1.Il();
            boolean var17 = var1.lIl() && var1.Il();
            this.I = var23 ? (var9 ? this.I + 1 : 1) : 0;
            this.IIIl = var17 ? (var9 ? this.IIIl + 1 : 1) : 0;
            boolean var24 = this.I >= 3;
            boolean var19 = this.IIIl >= lIl(497508700, -322105038);
            boolean var20 = this.Il >= 2;
            if (var1.Ill()) {
               if (!var1.IlI()) {
                  ++this.IIl;
               }

               if (!var1.III()) {
                  ++this.IIl;
               }

               if (var1.llI()) {
                  this.IIl += (double)2.0F;
               }

               if (var24) {
                  this.IllI += 0.8;
               }

               if (var19) {
                  ++this.IllI;
               }

               if (var20) {
                  this.IllI += (double)2.5F;
               }

               if (var15) {
                  this.IllI += (double)2.5F;
               }

               if (var1.IlI() && var1.III() && !var1.llI()) {
                  this.IIl = Math.max((double)0.0F, this.IIl - (double)3.0F);
               }

               boolean var21 = !var23 && !var17 && !var15 && (!var13 || var10 < (double)2.75F);
               if (var21) {
                  this.IllI = Math.max((double)0.0F, this.IllI - (double)2.0F);
               }
            }

            this.IIl = Math.min(this.IIl, var3.ll() * (double)2.0F);
            this.IllI = Math.min(this.IllI, var3.l() * (double)2.0F);
            this.Ill = var1.II();
            if (IIl(var1)) {
               this.IIlI = var1.lII();
               this.lII = var1.lI();
               this.IIll = var1.ll();
            }

            this.Illl = Double.isFinite(var1.I()) ? Math.max((double)0.0F, var1.I()) : Double.NaN;
            return this.l(var3, var1.II());
         }
      }
   }

   public void lI() {
      this.IIl = (double)0.0F;
      this.IllI = (double)0.0F;
      this.Ill = Long.MIN_VALUE;
      this.Illl = Double.NaN;
      this.lIl = Long.MIN_VALUE;
      this.l.clear();
      this.I = 0;
      this.IIIl = 0;
      this.Il = 0;
   }

   private static void ll() {
      lIll[0] = lII(llI(1363756378, -591711724).toCharArray(), 76591L, lIl(497508701, -906603329));
      lIll[1] = lII(llI(1363756379, -1479273497).toCharArray(), 62627L, lIl(497508702, -196037793));
   }

   public static boolean III(String var0) {
      return var0 != null && IIII.matcher(var0).matches();
   }

   private static boolean IIl(Object var0) {
      return Double.isFinite(var0.lII()) && Double.isFinite(var0.lI()) && Double.isFinite(var0.ll());
   }

   public static boolean IlI(long var0, long var2, long var4) {
      return var4 >= 0L && var0 - var2 > var4;
   }

   public <undefinedtype> Ill(Object var1) {
      return this.l(var1 == null ? null.IIl : var1, this.Ill);
   }

   private static String lII(char[] var0, long var1, int var3) {
      int var4 = lIl(497508703, -831531601) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & lIl(497508696, 1449786695);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private static int lIl(int var0, int var1) {
      return llII[var0 ^ 497508700] ^ var1 ^ var0;
   }

   private static String llI(int var0, int var1) {
      int var3 = var0 ^ 1363756378;
      char[] var4 = llIl[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])lllI[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         lllI[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -1504374182;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 31;
               break;
            case 1:
               var9 = 143;
               break;
            case 2:
               var9 = 200;
               break;
            case 3:
               var9 = 164;
               break;
            case 4:
               var9 = 155;
               break;
            case 5:
               var9 = 32;
               break;
            case 6:
               var9 = 150;
               break;
            case 7:
               var9 = 166;
               break;
            case 8:
               var9 = 107;
               break;
            case 9:
               var9 = 75;
               break;
            case 10:
               var9 = 10;
               break;
            case 11:
               var9 = 64;
               break;
            case 12:
               var9 = 51;
               break;
            case 13:
               var9 = 75;
               break;
            case 14:
               var9 = 14;
               break;
            case 15:
               var9 = 251;
               break;
            case 16:
               var9 = 200;
               break;
            case 17:
               var9 = 141;
               break;
            case 18:
               var9 = 143;
               break;
            case 19:
               var9 = 39;
               break;
            case 20:
               var9 = 216;
               break;
            case 21:
               var9 = 253;
               break;
            case 22:
               var9 = 154;
               break;
            case 23:
               var9 = 116;
               break;
            case 24:
               var9 = 85;
               break;
            case 25:
               var9 = 207;
               break;
            case 26:
               var9 = 90;
               break;
            case 27:
               var9 = 199;
               break;
            case 28:
               var9 = 217;
               break;
            case 29:
               var9 = 92;
               break;
            case 30:
               var9 = 241;
               break;
            case 31:
               var9 = 161;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
