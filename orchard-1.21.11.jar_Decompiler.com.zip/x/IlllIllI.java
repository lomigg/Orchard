package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_239;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_3966;

@Environment(EnvType.CLIENT)
public final class IlllIllI extends IIIIIIIlI {
   private static final int I = 2;
   private int l = IlIII(296621808, -1964256976);
   private int II;
   private boolean Il;
   private class_3675.class_306 lI;
   private int ll;
   private int III = IlIII(296621809, 1502748594);
   private class_3675.class_306 IIl;
   private boolean IlI;
   private static final int[] Ill;
   private static final String[] lII;
   private static final Object[] lIl;

   public boolean IIIIIII() {
      return IIlIlllll.lI();
   }

   public void lI() {
      this.lIIl(class_310.method_1551());
   }

   public boolean ll() {
      return IllllIlI.llIllI(class_310.method_1551());
   }

   public boolean IlI(class_310 var1) {
      return this.IIII(var1, false);
   }

   public boolean lII(class_3675.class_306 var1) {
      return var1 != null && (var1.equals(this.IIl) || var1.equals(this.lI));
   }

   public boolean llI() {
      return false;
   }

   public void lll(class_310 var1) {
      this.lIIl(var1);
   }

   private boolean IIII(class_310 var1, boolean var2) {
      if (!this.IIlIl(var1)) {
         return false;
      } else {
         boolean var3 = var2 ? this.Il : this.IlI;
         if (var3) {
            return false;
         } else {
            class_304 var4 = var2 ? var1.field_1690.field_1886 : var1.field_1690.field_1904;
            class_3675.class_306 var5 = IllllIlI.IIIlIIl(var4);
            if (!IllllIlI.IllllI(var5) && !IllllIlI.IIIll(var1, var4)) {
               class_304 var6 = var2 ? var1.field_1690.field_1904 : var1.field_1690.field_1886;
               if (var5.equals(IllllIlI.IIIlIIl(var6))) {
                  return false;
               } else {
                  class_3675.class_306 var7 = var2 ? this.IIl : this.lI;
                  if (var7 != null && !var7.equals(var5)) {
                     return false;
                  } else {
                     int var8 = var1.field_1724.field_6012 + 2;
                     if (var2) {
                        this.IIl = var5;
                        this.III = var8;
                     } else {
                        this.lI = var5;
                        this.l = var8;
                     }

                     if (!IIlIlllll.Il(var1, var5, true, false)) {
                        if (var7 == null) {
                           this.lIII(var1, var2);
                        }

                        return false;
                     } else {
                        if (var2) {
                           ++this.ll;
                        } else {
                           ++this.II;
                        }

                        if (var2) {
                           this.Il = true;
                        } else {
                           this.IlI = true;
                        }

                        boolean var9 = IIlIlllll.Il(var1, var5, false, true);
                        if (var9) {
                           if (var2) {
                              this.Il = false;
                           } else {
                              this.IlI = false;
                           }
                        }

                        return var9;
                     }
                  }
               }
            } else {
               return false;
            }
         }
      }
   }

   public void Ill() {
      this.lllI(class_310.method_1551());
   }

   private void IIll(class_310 var1, boolean var2) {
      class_3675.class_306 var3 = var2 ? this.IIl : this.lI;
      if (var3 != null) {
         class_304 var4 = var2 ? var1.field_1690.field_1886 : var1.field_1690.field_1904;
         int var5 = var2 ? this.III : this.l;
         int var6 = var2 ? this.ll : this.II;
         if (var1.field_1724.field_6012 > var5) {
            this.lIII(var1, var2);
         } else {
            if (var4 != null && var3.equals(IllllIlI.IIIlIIl(var4)) && var6 > 0 && IllllIlI.IllIlI(var4) > 0) {
               int var7 = IllllIlI.IllIlI(var4);
               int var8 = Math.min(var7, var6);
               IIlllllI.lll(var4, var7 - var8);
               if (var2) {
                  this.ll -= var8;
               } else {
                  this.II -= var8;
               }

               var4.method_23481(IllllIlI.IIIll(var1, var4));
               if ((var2 ? this.ll : this.II) == 0) {
                  this.lIII(var1, var2);
               }
            }

         }
      }
   }

   public IlllIllI() {
      super((Object)lIlIII.l(IlIIl(1992471337, 1422659352)), lIllII.lI, (Object)lIlIII.l(IlIIl(1992471336, 1631456116)));
      IIlIlllll.III();
   }

   public boolean IlII(class_310 var1, class_239 var2) {
      if (var2 instanceof class_3966 var8) {
         return IllllIlI.lllII(var1, var8);
      } else if (var1 == null) {
         return false;
      } else {
         class_239 var3 = var1.field_1765;
         if (var2 != null) {
            var1.field_1765 = var2;
         }

         boolean var4;
         try {
            var4 = IllllIlI.IIlIlII(var1);
         } finally {
            var1.field_1765 = var3;
         }

         return var4;
      }
   }

   private void IlIl(class_310 var1, boolean var2) {
      class_3675.class_306 var3 = var2 ? this.IIl : this.lI;
      boolean var4 = var2 ? this.Il : this.IlI;
      if (var4 && var3 != null && IIlIlllll.Il(var1, var3, false, true)) {
         if (var2) {
            this.Il = false;
         } else {
            this.IlI = false;
         }

      }
   }

   public void Illl(class_310 var1) {
      this.lllI(var1);
      if (var1 != null && var1.field_1724 != null && var1.field_1690 != null) {
         this.IIll(var1, true);
         this.IIll(var1, false);
      } else {
         this.lIIl(var1);
      }
   }

   private void lIII(class_310 var1, boolean var2) {
      this.IlIl(var1, var2);
      if (var2) {
         if (this.Il) {
            return;
         }

         this.IIl = null;
         this.III = IlIII(296621811, 727630657);
         this.ll = 0;
      } else {
         if (this.IlI) {
            return;
         }

         this.lI = null;
         this.l = IlIII(296621810, 194079405);
         this.II = 0;
      }

   }

   private void lIIl(class_310 var1) {
      this.lIII(var1, true);
      this.lIII(var1, false);
   }

   public static void llII(class_310 var0) {
      lIllIIl var1 = lIllIIl.Il();
      if (var1 != null && var1.IIl() != null && var1.IIl().IlIlIl() != null) {
         var1.IIl().IlIlIl().IIIIl(var0);
      }

   }

   public void lllI(class_310 var1) {
      this.IlIl(var1, true);
      this.IlIl(var1, false);
      if (this.IIl != null && this.ll == 0 && !this.Il) {
         this.lIII(var1, true);
      }

      if (this.lI != null && this.II == 0 && !this.IlI) {
         this.lIII(var1, false);
      }

      if (var1 != null && var1.field_1724 != null) {
         if (this.IIl != null && var1.field_1724.field_6012 > this.III) {
            this.lIII(var1, true);
         }

         if (this.lI != null && var1.field_1724.field_6012 > this.l) {
            this.lIII(var1, false);
         }

      } else {
         this.lIIl(var1);
      }
   }

   public void IIIII() {
      this.ll();
   }

   public boolean IIIIl(class_310 var1) {
      return this.IIII(var1, true);
   }

   public boolean IIIll(class_310 var1, class_239 var2) {
      return var2 == null ? IllllIlI.llIllI(var1) : IllllIlI.lIIIlI(var1, var2);
   }

   public boolean IIlII() {
      return IllllIlI.IIlIlII(class_310.method_1551());
   }

   private boolean IIlIl(class_310 var1) {
      return this.IIIIIlI() && var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1755 == null && var1.field_1690 != null && var1.method_1569() && IIlIlllll.lI();
   }

   public void IIllI() {
      this.IIlII();
   }

   public boolean IIlll() {
      return false;
   }

   private static int IlIII(int var0, int var1) {
      return Ill[var0 ^ 296621809] ^ var1 ^ var0;
   }

   static {
      short var6 = 6085;
      String var7 = "袒裭裴裟裍袋蠋袡血蠪蠍衼裠衅袹袩蠣裾袂袥蠞袤裙袾뵤봟뵟봓봸뵓뷦뵜붹뷢뷅붪봉붧뵏뵕뷑뵆뵆뵧붴뵯봭봨붾뷟붅뷀뵥뵚뷁뵅봟뵀뵚뵥뵄봧뷜봕뷘뷖분붣봭뷡봑봃뷺봥뵽봠붥뵘뵌뵼";
      char[] var8 = "៝\u17fd".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            lII = var9;
            lIl = new Object[var9.length];
            int var2 = -1559566458;
            byte[] var0 = "k6îÅ¸O F\u0019ú2495\u009bÙ".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            Ill = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               Ill[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 44;
                     break;
                  case 1:
                     var10000 = 78;
                     break;
                  case 2:
                     var10000 = 75;
                     break;
                  case 3:
                     var10000 = 102;
                     break;
                  case 4:
                     var10000 = 13;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static String IlIIl(int var0, int var1) {
      int var3 = var0 ^ 1992471337;
      char[] var4 = lII[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])lIl[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         lIl[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 1755276671;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 73;
               break;
            case 1:
               var9 = 20;
               break;
            case 2:
               var9 = 85;
               break;
            case 3:
               var9 = 95;
               break;
            case 4:
               var9 = 44;
               break;
            case 5:
               var9 = 93;
               break;
            case 6:
               var9 = 142;
               break;
            case 7:
               var9 = 48;
               break;
            case 8:
               var9 = 253;
               break;
            case 9:
               var9 = 221;
               break;
            case 10:
               var9 = 244;
               break;
            case 11:
               var9 = 209;
               break;
            case 12:
               var9 = 97;
               break;
            case 13:
               var9 = 251;
               break;
            case 14:
               var9 = 120;
               break;
            case 15:
               var9 = 94;
               break;
            case 16:
               var9 = 168;
               break;
            case 17:
               var9 = 14;
               break;
            case 18:
               var9 = 20;
               break;
            case 19:
               var9 = 120;
               break;
            case 20:
               var9 = 219;
               break;
            case 21:
               var9 = 33;
               break;
            case 22:
               var9 = 99;
               break;
            case 23:
               var9 = 103;
               break;
            case 24:
               var9 = 155;
               break;
            case 25:
               var9 = 217;
               break;
            case 26:
               var9 = 131;
               break;
            case 27:
               var9 = 168;
               break;
            case 28:
               var9 = 33;
               break;
            case 29:
               var9 = 101;
               break;
            case 30:
               var9 = 220;
               break;
            case 31:
               var9 = 26;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
