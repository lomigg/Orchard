package x;

import java.io.DataInputStream;
import java.io.InputStream;
import java.net.IDN;
import java.net.InetAddress;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2596;
import net.minecraft.class_2817;
import net.minecraft.class_310;
import net.minecraft.class_8709;
import net.minecraft.class_8710;

@Environment(EnvType.CLIENT)
public final class IIlIIlll {
   private static final <undefinedtype> I;
   private static final <undefinedtype> l;
   private static final ExecutorService II;
   private static final byte[][] Il;
   private static final Map<String, Long> lI;
   private static final <undefinedtype> ll;
   private static final int III = 4;
   private static final int IIl = 100000;
   private static final Set<UUID> IlI;
   private static final <undefinedtype> Ill;
   private static final long lII = 2500L;
   private static final AtomicInteger lIl;
   private static final int llI = 16;
   private static final int[] lll;
   private static final String[] IIII;
   private static final Object[] IIIl;

   public static boolean I(class_2596<?> var0) {
      return IIlI(var0, lIl());
   }

   public static void l() {
      IlI.clear();
      lIl.set(0);
      lI.clear();
      II.shutdownNow();
   }

   public static boolean II(String var0) {
      <undefinedtype> var1 = IIl(var0);
      return var1 != null && Il(var1.I());
   }

   private static boolean Il(String var0) {
      try {
         InetAddress[] var1 = InetAddress.getAllByName(var0);
         if (var1.length == 0) {
            return false;
         } else {
            for(InetAddress var5 : var1) {
               if (llII(var5)) {
                  return false;
               }
            }

            return true;
         }
      } catch (Exception var6) {
         return false;
      }
   }

   public static boolean lI(UUID var0) {
      return var0 != null && IlI.remove(var0);
   }

   private static byte[][] ll() {
      try {
         InputStream var0 = IIlIIlll.class.getResourceAsStream(lIlIII.Il(llll(1993350008, 488797187)));

         byte[][] var13;
         label95: {
            byte[][] var15;
            label96: {
               byte[][] var14;
               try {
                  if (var0 == null) {
                     var13 = new byte[0][];
                     break label95;
                  }

                  DataInputStream var1 = new DataInputStream(var0);

                  label85: {
                     try {
                        int var2 = var1.readInt();
                        if (var2 < 1 || var2 > lllI(1385108899, 863475411)) {
                           var14 = new byte[0][];
                           break label85;
                        }

                        var14 = new byte[var2][lllI(1385108898, -1531438296)];

                        for(byte[] var7 : var14) {
                           var1.readFully(var7);
                        }

                        var15 = var14;
                     } catch (Throwable var10) {
                        try {
                           var1.close();
                        } catch (Throwable var9) {
                           var10.addSuppressed(var9);
                        }

                        throw var10;
                     }

                     var1.close();
                     break label96;
                  }

                  var1.close();
               } catch (Throwable var11) {
                  if (var0 != null) {
                     try {
                        var0.close();
                     } catch (Throwable var8) {
                        var11.addSuppressed(var8);
                     }
                  }

                  throw var11;
               }

               if (var0 != null) {
                  var0.close();
               }

               return var14;
            }

            if (var0 != null) {
               var0.close();
            }

            return var15;
         }

         if (var0 != null) {
            var0.close();
         }

         return var13;
      } catch (Exception var12) {
         return new byte[0][];
      }
   }

   public static void III(String var0) {
      if (!IlII(lIlIII.Il(llll(1993350009, -295150864)))) {
         Illl(l, I);
      }
   }

   private static <undefinedtype> IIl(String var0) {
      if (var0 != null && !var0.isBlank()) {
         try {
            URI var1 = URI.create(var0);
            String var2 = var1.getScheme();
            if (var2 != null && (var2.equalsIgnoreCase(lIlIII.Il(llll(1993350010, -224118288))) || var2.equalsIgnoreCase(lIlIII.Il(llll(1993350011, -500478725)))) && var1.getRawUserInfo() == null && var1.getPort() != 0 && var1.getPort() <= lllI(1385108897, -2076975286)) {
               String var3 = var1.getHost();
               if (var3 != null && !var3.isBlank()) {
                  String var4 = IDN.toASCII(var3).toLowerCase(Locale.ROOT);
                  return !var4.equals(lIlIII.Il(llll(1993350012, 907836323))) && !var4.endsWith(lIlIII.Il(llll(1993350013, -333309461))) ? new Record(var4) {
                     private final String I;

                     private {
                        this.I = var1;
                     }

                     public String I() {
                        return this.I;
                     }
                  } : null;
               } else {
                  return null;
               }
            } else {
               return null;
            }
         } catch (Exception var5) {
            return null;
         }
      } else {
         return null;
      }
   }

   private static boolean lII(byte var0, byte var1, byte var2, byte var3) {
      int var4 = Byte.toUnsignedInt(var0);
      int var5 = Byte.toUnsignedInt(var1);
      return var4 == 0 || var4 == lllI(1385108896, -133659516) || var4 == lllI(1385108903, -2083358384) || var4 == lllI(1385108902, -1470358709) && var5 == lllI(1385108901, 1215036033) || var4 == lllI(1385108900, -588387594) && var5 >= lllI(1385108907, -200793405) && var5 <= lllI(1385108906, 159012310) || var4 == lllI(1385108905, 1038112412) && var5 == lllI(1385108904, -2083789195);
   }

   static {
      short var6 = 22946;
      String var7 = "ሐዼኽቜዏትዖኗኤሣ\u12c1በሚዩኒቧዱክላሌሥኒኲዔሸ\u12c7ቂቱኗቔሗቭሻዌኳሰከሸኼኃ\ue11f\ue1f2\ue1c8\ue13d\ue180\ue13e\ue1af\ue1cb\ue1e8\ue11f\ue1bc\ue13a\ue155\ue18b\ue198\ue13f\ue1a3\ue1e5\ue120\ue16a\ue16f\ue1e4\ue1fd\ue1a7\ue166\ue19c\ue133\ue139\ue1cf\ue10c\ue13e\ue108\ue171\ue1d1\ue1b7\ue114\ufdcdﴇﴮ\ufdd2﵈\ufdcbﴔﵩ\ued42\ued88\ueda1\ued5d\uedc7\ued44\uedc9\uede6㥲㦼㦠㥳㧴㥠㧇㦊㦒㥚㦚㥎\ue311\ue3b8\ue382\ue377\ue3ca\ue374\ue3c7\ue3b0\ue3a3\ue351\ue3c0\ue371\ue310\ue3f0\ue3da\ue310ᇯᅇᄃᇀᅲᇥᅻᅔ製蠐蠪裟衢補衍蠩蠊製衞裷袿蠯衾袪衝衱袽袣袏蠬蠩衵쇘섵섏쇺셇쇹셨섌섯쇘셻쇽솒셌셟쇸셤섢쇧솭솨섣섺셠송셛쇴쇾섈쇋쇹쇏솶섖셰쇓矆眫眑矤睙矧睶眒眱矆睥矲瞊睨睁矦睳眖瞴瞆矬眢眊睛瞿眄瞩矉ⳅⰨⰒ⳧ⱚⳤⱵⰑⰲⳅⱦⳏⲇⰗⱆⲒⱥⱉⲅⲛⲷⰔⰑⱍ跲赜贱趇贷跺赿贲贕跗贑趪ҞѬѨҠМҊЭѤѵҖѦӝ诵講謏诠譮语譊謢謆诗謑讪䝝䞐䞽䝥䟛䝌䟊䞖䞽䝀䟉䝶䜋䟏䞅䝸䟷䞩䜓䜆䜧䟷䟒䟿䜨䟲䜢䜕遭邟邛道郯遹郞邗邆遥邕逮얾앓앩얜씡얟씎앪앉얾씝얊엲씐씹얞씋앮엌엾얔앚앲씣엇야엑얱ﮅשּﭧﮉﬆﮕﭐףּ";
      char[] var8 = "($\b\b\f\u0010\b\u0018$\u001c\u0018\f\f\f\u001c\f\u001c\b".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            IIII = var9;
            IIIl = new Object[var9.length];
            int var2 = 1423418482;
            byte[] var0 = "5.¡¢¢àªè\u0082k\u0091fþP5\\\u0085\u008aÈú®\u0004ª6N3K¨Úµ[\u008còP\u0093\n\u000f\"ä\u0011;¸ç\u0087\u0085\u0093W\u0007À \r\u000eÅ?\u0005\u0081@\u0090-`'`_Ð_©\u0080H³yXùû³ )\u0086Ý<\u0019\u0097û\u0010\\dl°\u0091¡Ë\u0096åe)¦º".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lll = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lll[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            l = lIlIII.l(llll(1993350014, -1836178251));
            ll = lIlIII.l(llll(1993350015, 194851862));
            I = lIlIII.l(llll(1993350000, 1119364544));
            Ill = lIlIII.l(llll(1993350001, -190423458));
            IlI = ConcurrentHashMap.newKeySet();
            lI = new ConcurrentHashMap();
            lIl = new AtomicInteger();
            II = Executors.newFixedThreadPool(2, (var0x) -> {
               Thread var1 = new Thread(var0x);
               var1.setDaemon(true);
               return var1;
            });
            Il = ll();
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 118;
                     break;
                  case 1:
                     var10000 = 22;
                     break;
                  case 2:
                     var10000 = 6;
                     break;
                  case 3:
                     var10000 = 34;
                     break;
                  case 4:
                     var10000 = 44;
                     break;
                  case 5:
                     var10000 = 84;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public static boolean lIl() {
      lIllIIl var0 = lIllIIl.Il();
      if (var0 != null && var0.IIl() != null) {
         IIIlIIIII var1 = var0.IIl().IIIlIl();
         return var1 != null && var1.IIIIIlI();
      } else {
         return false;
      }
   }

   public static void llI(String var0) {
      if (!IlII(lIlIII.Il(llll(1993350002, 598881404)))) {
         Illl(l, ll);
      }
   }

   public static void IIII(UUID var0) {
      if (var0 != null) {
         IlI.add(var0);
      }

   }

   private static int IIIl(byte[] var0, byte[] var1) {
      for(int var2 = 0; var2 < lllI(1385108911, -965165885); ++var2) {
         int var3 = Byte.toUnsignedInt(var0[var2]) - Byte.toUnsignedInt(var1[var2]);
         if (var3 != 0) {
            return var3;
         }
      }

      return 0;
   }

   static boolean IIlI(class_2596<?> var0, boolean var1) {
      if (!var1) {
         return false;
      } else if (var0 instanceof class_2817) {
         class_2817 var2 = (class_2817)var0;
         if (var2.comp_1647() instanceof class_8709) {
            return false;
         } else {
            lIlI(var2.comp_1647().method_56479().comp_2242().toString());
            return true;
         }
      } else {
         return false;
      }
   }

   private static byte[] IIll(String var0) {
      try {
         return Arrays.copyOf(MessageDigest.getInstance(lIlIII.Il(llll(1993350003, -2103304941))).digest(var0.getBytes(StandardCharsets.UTF_8)), lllI(1385108910, -1016613811));
      } catch (Exception var2) {
         return null;
      }
   }

   private static boolean IlII(String var0) {
      long var1 = System.currentTimeMillis();
      Long var3 = (Long)lI.get(var0);
      if (var3 != null && var1 - var3 < 2500L) {
         return true;
      } else {
         lI.put(var0, var1);
         return false;
      }
   }

   public static String IlIl() {
      lIllIIl var0 = lIllIIl.Il();
      if (var0 != null && var0.IIl() != null) {
         IIIIIl var1 = var0.IIl().IIlIlII();
         if (var1 != null && var1.IIIIIlI()) {
            String var10000;
            switch (var1.lII()) {
               case Il -> var10000 = lIlIII.Il(llll(1993350004, 198531187));
               case ll -> var10000 = lIlIII.Il(llll(1993350005, -2069742794));
               case II -> var10000 = lIlIII.Il(llll(1993350006, 1209014036));
               default -> throw new MatchException((String)null, (Throwable)null);
            }

            return var10000;
         }
      }

      return lIlIII.Il(llll(1993350007, -1624899174));
   }

   public static class_2596<?> IllI(class_2596<?> var0) {
      return lIll(var0, lIl());
   }

   private static void Illl(Object var0, Object var1) {
      class_310 var2 = class_310.method_1551();
      if (var2 != null) {
         var2.execute(() -> {
            IIlllIlI var2 = IIlllIlI.II();
            if (var2 != null) {
               var2.IIl(null.l, var0, var1, 4000L);
            }

         });
      }
   }

   private IIlIIlll() {
   }

   public static void lIII(String var0, Consumer<Boolean> var1) {
      <undefinedtype> var2 = IIl(var0);
      if (var2 == null) {
         var1.accept(false);
      } else {
         int var3 = lIl.incrementAndGet();
         if (var3 > 4) {
            lIl.decrementAndGet();
            var1.accept(false);
         } else {
            try {
               CompletableFuture.supplyAsync(() -> Il(var2.I()), II).orTimeout(3L, TimeUnit.SECONDS).whenComplete((var1x, var2x) -> {
                  lIl.decrementAndGet();
                  var1.accept(var2x == null && Boolean.TRUE.equals(var1x));
               });
            } catch (RuntimeException var5) {
               lIl.decrementAndGet();
               var1.accept(false);
            }

         }
      }
   }

   public static void lIlI(String var0) {
      if (!IlII(lIlIII.Il(llll(1993349992, -889581158)))) {
         Illl(l, Ill);
      }
   }

   static class_2596<?> lIll(class_2596<?> var0, boolean var1) {
      if (!var1) {
         return var0;
      } else if (var0 instanceof class_2817) {
         class_2817 var2 = (class_2817)var0;
         class_8710 var3 = var2.comp_1647();
         return (class_2596<?>)(!(var3 instanceof class_8709) ? var0 : new class_2817(new class_8709(IlIl())));
      } else {
         return var0;
      }
   }

   private static boolean llII(InetAddress var0) {
      if (var0 != null && !var0.isAnyLocalAddress() && !var0.isLoopbackAddress() && !var0.isLinkLocalAddress() && !var0.isSiteLocalAddress() && !var0.isMulticastAddress()) {
         byte[] var1 = var0.getAddress();
         if (var1.length == lllI(1385108909, 1187552431)) {
            if ((var1[0] & lllI(1385108908, 557379312)) == lllI(1385108915, 1508979061)) {
               return true;
            }

            boolean var2 = true;

            for(int var3 = 0; var3 < lllI(1385108914, -1256068813); ++var3) {
               var2 &= var1[var3] == 0;
            }

            var2 &= var1[lllI(1385108913, -34926112)] == -1 && var1[lllI(1385108912, -2138731056)] == -1;
            if (var2) {
               return lII(var1[lllI(1385108919, -1851547243)], var1[lllI(1385108918, 1647575384)], var1[lllI(1385108917, -1483528404)], var1[lllI(1385108916, 1668355955)]);
            }
         }

         return var1.length == 4 && lII(var1[0], var1[1], var1[2], var1[3]);
      } else {
         return true;
      }
   }

   public static boolean llIl(String var0) {
      if (var0 == null) {
         return false;
      } else if (var0.startsWith(lIlIII.Il(llll(1993349993, -187033090)))) {
         return true;
      } else if (Il.length == 0) {
         return false;
      } else {
         byte[] var1 = IIll(var0);
         if (var1 == null) {
            return false;
         } else {
            int var2 = 0;
            int var3 = Il.length - 1;

            while(var2 <= var3) {
               int var4 = var2 + var3 >>> 1;
               int var5 = IIIl(Il[var4], var1);
               if (var5 == 0) {
                  return true;
               }

               if (var5 < 0) {
                  var2 = var4 + 1;
               } else {
                  var3 = var4 - 1;
               }
            }

            return false;
         }
      }
   }

   private static int lllI(int var0, int var1) {
      return lll[var0 ^ 1385108899] ^ var1 ^ var0;
   }

   private static String llll(int var0, int var1) {
      int var3 = var0 ^ 1993350008;
      char[] var4 = IIII[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IIIl[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IIIl[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 903663212;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 179;
               break;
            case 1:
               var9 = 59;
               break;
            case 2:
               var9 = 9;
               break;
            case 3:
               var9 = 210;
               break;
            case 4:
               var9 = 109;
               break;
            case 5:
               var9 = 189;
               break;
            case 6:
               var9 = 60;
               break;
            case 7:
               var9 = 33;
               break;
            case 8:
               var9 = 23;
               break;
            case 9:
               var9 = 212;
               break;
            case 10:
               var9 = 70;
               break;
            case 11:
               var9 = 133;
               break;
            case 12:
               var9 = 203;
               break;
            case 13:
               var9 = 66;
               break;
            case 14:
               var9 = 4;
               break;
            case 15:
               var9 = 234;
               break;
            case 16:
               var9 = 104;
               break;
            case 17:
               var9 = 80;
               break;
            case 18:
               var9 = 214;
               break;
            case 19:
               var9 = 181;
               break;
            case 20:
               var9 = 175;
               break;
            case 21:
               var9 = 25;
               break;
            case 22:
               var9 = 57;
               break;
            case 23:
               var9 = 62;
               break;
            case 24:
               var9 = 232;
               break;
            case 25:
               var9 = 81;
               break;
            case 26:
               var9 = 237;
               break;
            case 27:
               var9 = 254;
               break;
            case 28:
               var9 = 30;
               break;
            case 29:
               var9 = 161;
               break;
            case 30:
               var9 = 223;
               break;
            case 31:
               var9 = 212;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
