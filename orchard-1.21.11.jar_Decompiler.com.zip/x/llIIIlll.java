package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_746;

@Environment(EnvType.CLIENT)
public final class llIIIlll extends IIIIIIIlI {
   private boolean I;
   private static String[] l;
   private static final String II;
   private boolean Il;
   private final lIIIIl lI;
   private int ll;
   private boolean III;
   private String IIl;
   private static final String IlI;
   private boolean Ill;
   private final lIIIIl lII;
   private static final double lIl = (double)2304.0F;
   private class_243 llI;
   private static final int lll = 9;
   private <undefinedtype> IIII;
   private static final int[] IIIl;
   private static final String[] IIlI;
   private static final Object[] IIll;

   private void l(class_310 var1, class_746 var2) {
      boolean var3 = var2.method_5805();
      class_243 var4 = new class_243(var2.method_23317(), var2.method_23318(), var2.method_23321());
      String var5 = var1.field_1687 != null ? var1.field_1687.method_27983().method_29177().toString() : l[IIll(-112937298, -1556572096)];
      if (!this.III) {
         this.III = true;
         this.Ill = var3;
         this.llI = var4;
         this.IIl = var5;
      } else {
         boolean var6 = this.Ill && !var3;
         boolean var7 = this.IIl != null && !this.IIl.equals(var5);
         boolean var8 = var3 && this.llI != null && var4.method_1025(this.llI) >= (double)2304.0F;
         if ((Boolean)this.lII.III() && (var6 || var7 || var8)) {
            this.lll();
         }

         this.Ill = var3;
         this.llI = var4;
         this.IIl = var5;
      }
   }

   private void II(class_310 var1, int var2) {
      if (this.IIII == null || !this.IIII.III() || !IllllIlI.IIII(var1, this.IIII) || this.IIII.ll() != var2) {
         this.IIII = IllllIlI.lIll(var1, this, var2, 0, true);
      }

      if (IllllIlI.IlIllII(var1, this.IIII)) {
         this.IIII = null;
         float var3 = var1.field_1724.method_36454();
         float var4 = var1.field_1724.method_36455();
         this.Il = IlIlIl.IIIlIl(var1, IIll(-112937297, -129352281), var3, var4, () -> {
            this.Il = false;
            this.ll = IIll(-112937302, -1570796721);
            if (this.IIIIIlI() && (Boolean)this.lII.III() && this.I && var1.field_1724 != null && var1.field_1761 != null && var1.field_1724.method_31548().method_5438(var2).method_31574(class_1802.field_8477) && IllllIlI.IIlIl(var1) == var2) {
               IllllIlI.lIllll(var1);
               class_1269 var3 = var1.field_1761.method_2919(var1.field_1724, class_1268.field_5808);
               if (var3 != null && var3.method_23665()) {
                  this.I = false;
                  IllllIlI.llIIlI(var1, this, var2);
                  return true;
               } else {
                  return false;
               }
            } else {
               return false;
            }
         });
         this.ll = this.Il ? var1.field_1724.field_6012 + 1 : IIll(-112937300, 368504606);
      }
   }

   public void lIl() {
      this.IlI();
   }

   public void lI() {
      IllllIlI.IlII(class_310.method_1551(), this, null.II);
      this.IlI();
   }

   public llIIIlll() {
      super((Object)lIlIII.l(l[3]), lIllII.l, (Object)lIlIII.l(l[5]));
      this.lI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(l[4]), true));
      this.lII = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(l[2]), false));
      this.ll = IIll(-112937299, 265060922);
   }

   private void ll(class_310 var1, class_746 var2) {
      if (var1 != null && var2 != null) {
         class_1661 var3 = var2.method_31548();
         int var4 = this.IIII(var3);
         if (var4 >= 0 && !this.Il) {
            this.II(var1, var4);
         }

      }
   }

   private void IlI() {
      this.I = false;
      this.III = false;
      this.Ill = false;
      this.llI = null;
      this.IIl = null;
      this.Il = false;
      this.ll = IIll(-112937301, -580298307);
      this.IIII = null;
   }

   private void lII(String var1) {
      class_310 var2 = class_310.method_1551();
      if (var2.field_1724 != null && var2.method_1562() != null) {
         var2.method_1562().method_45730(var1);
      }
   }

   public void llI(String var1) {
      if (this.IIIIIlI() && var1 != null && II.equals(var1.trim())) {
         if ((Boolean)this.lI.III()) {
            this.lII(IlI);
         }

         if ((Boolean)this.lII.III()) {
            this.lll();
         }

      }
   }

   private void lll() {
      this.I = true;
      this.Il = false;
      this.ll = IIll(-112937304, -1781029767);
   }

   private int IIII(class_1661 var1) {
      if (var1 == null) {
         return -1;
      } else {
         for(int var2 = 0; var2 < IIll(-112937303, 789248476); ++var2) {
            class_1799 var3 = var1.method_5438(var2);
            if (var3.method_31574(class_1802.field_8477)) {
               return var2;
            }
         }

         return -1;
      }
   }

   static {
      short var6 = 19536;
      String var7 = "ㇲꖀ䆧ꖼ\udf8d\ueb64ऌド㮊㧄漇懦䛠˾쩃꿢芠撊俌\ude0e\ufdd0⣙猸䊺햪\uddd0盞⋲ᷭ㲺뺁\ud907씲래ꪭ쪞ᑇ\ue2f4讻书ᩖḱ鼌괸鏷鐏膤㙗爟媘㢬㥊⯕徴\u19ce睗즳떷鼃䱴秕鶐㐕僞\ue14b娊肹띑읷趩峨䁐銗馱플蜓ꅓ흹鯊긏\uf345냠䙴貮쏙峨齢碽팲屽漃Гᮌ稐癮羺暦龦\uf4a6䨯\u1ade\udad1蚾啿젦ⰵ\uf0ff爄ꬣ먋\uf13c\u2efaㆧ겳ꗬ\ue6e5誡䃼瞳꽕셖瓁纵鱒復譋뺚눆⌗㹺㺋퉺븆፮鑼魦╤᳥\udd13횯\ue091ᐔ㮟䵌";
      char[] var8 = "䱘䱸䱀䱀䱀䱠".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IIlI = var9;
            IIll = new Object[var9.length];
            int var2 = 664749806;
            byte[] var0 = "}ãh\u0006&\u0091ÍpK-\u001f\\Q\u0017ryü\u0084{\u000b\u0083²©øË\fT?ñÑ\t\u0092hO\r\u0095ë\u009d×ÐÛ\u0003\u001eó¹«¡kr\u009b¯ºxC©Miê¬U¦\u0014ÙrBî¡ø\u000e*óÕ+¯ãýÜI³õ".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IIIl = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IIIl[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            l = new String[IIll(-112937306, -1231749670)];
            IIlI();
            II = lIlIII.Il(l[1]);
            IlI = lIlIII.Il(l[0]);
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static String IIIl(char[] var0, long var1, int var3) {
      int var4 = IIll(-112937305, -1235061925) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IIll(-112937308, 98102854);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   public void Ill() {
      if (this.IIIIIlI()) {
         class_310 var1 = class_310.method_1551();
         if (var1 != null && var1.field_1724 != null) {
            this.l(var1, var1.field_1724);
            if ((Boolean)this.lII.III() && this.I && var1.field_1724.method_5805()) {
               if (this.Il && var1.field_1724.field_6012 > this.ll) {
                  this.Il = false;
                  this.ll = IIll(-112937307, -412069600);
               }

               this.ll(var1, var1.field_1724);
            }
         }
      }
   }

   private static void IIlI() {
      l[0] = IIIl(IlII('麟', -2029953289, (short)30370).toCharArray(), 10504L, IIll(-112937310, -1871492164));
      l[1] = IIIl(IlII('麞', 1888755082, (short)7953).toCharArray(), 65446L, IIll(-112937309, -699577538));
      l[2] = IIIl(IlII('麝', 1179653020, (short)'퀢').toCharArray(), 16317L, IIll(-112937312, -2079504237));
      l[3] = IIIl(IlII('麜', -847365171, (short)'뛛').toCharArray(), 46154L, IIll(-112937311, -622585806));
      l[4] = IIIl(IlII('麛', -74555822, (short)'츠').toCharArray(), 78296L, IIll(-112937282, 518601706));
      l[5] = IIIl(IlII('麚', -1552001045, (short)'녪').toCharArray(), 45788L, IIll(-112937281, -310555946));
      l[IIll(-112937284, -176942167)] = IIIl("".toCharArray(), 20768L, IIll(-112937283, -1971001055));
   }

   private static int IIll(int var0, int var1) {
      return IIIl[var0 ^ -112937298] ^ var1 ^ var0;
   }

   private static String IlII(char var0, int var1, short var2) {
      int var3 = var0 ^ '麟';
      char[] var4 = IIlI[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])IIll[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         IIll[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 28995;
      int var9 = 0;

      do {
         int var10 = var4[var9] ^ 15226;
         var10 -= 34426;
         var10 -= 11713;
         var10 -= 6889;
         var10 -= 43563;
         var10 -= 61162;
         var10 ^= 53720;
         var4[var9] = (char)(var10 ^ var8 ^ var2 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
