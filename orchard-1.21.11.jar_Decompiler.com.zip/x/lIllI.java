package x;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2680;
import net.minecraft.class_2743;
import net.minecraft.class_310;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;

@Environment(EnvType.CLIENT)
public final class lIllI extends IIIIIIIlI {
   private int I;
   private static final int l = 3;
   private class_243 II;
   private boolean Il;
   private boolean lI;
   private static final int ll = 8;
   private static final int III = 9;
   private int IIl;
   private float IlI;
   private final lIIIIl Ill = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIlll(-80788996, 1474261881)), true));
   private int lII;
   private final IIIllIIII lIl;
   private final IlIlIll llI;
   private final IIIllIIII lll = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IIlll(-80788998, 1225148252)), (double)100.0F, (double)0.0F, (double)100.0F, (double)1.0F)).IIIl(lIlIII.l(IIlll(-80788995, 652348430))));
   private int IIII;
   private final IlIIIlIlI<<undefinedtype>> IIIl;
   private int IIlI;
   private static final int[] IIll;
   private static final String[] IlII;
   private static final Object[] IlIl;

   private double IlI(class_238 var1, class_2338 var2) {
      double var3 = Math.max((double)0.0F, Math.min(var1.field_1320, (double)var2.method_10263() + (double)1.0F) - Math.max(var1.field_1323, (double)var2.method_10263()));
      double var5 = Math.max((double)0.0F, Math.min(var1.field_1324, (double)var2.method_10260() + (double)1.0F) - Math.max(var1.field_1321, (double)var2.method_10260()));
      return var3 * var5;
   }

   private boolean lII(class_1657 var1) {
      lIllIIl var2 = lIllIIl.Il();
      llIlIlI var3 = var2 != null && var2.IIl() != null ? var2.IIl().IlIlll() : null;
      return var3 != null && var3.IIIIIlI() && var3.IIlIIl(var1);
   }

   private class_243 llI(class_310 var1, class_1309 var2) {
      float var3 = (float)Math.toRadians(this.IIl == var2.method_5628() ? (double)this.IlI : (double)var1.field_1724.method_36454());
      class_243 var4 = new class_243(-Math.sin((double)var3), (double)0.0F, Math.cos((double)var3));
      class_243 var5 = new class_243(var2.method_23317() - var1.field_1724.method_23317(), (double)0.0F, var2.method_23321() - var1.field_1724.method_23321());
      if (var4.method_1027() < 1.0E-6) {
         return var5.method_1027() < 1.0E-6 ? class_243.field_1353 : var5.method_1029();
      } else {
         var4 = var4.method_1029();
         return var5.method_1027() > 1.0E-6 && var4.method_1026(var5.method_1029()) <= (double)0.0F ? var5.method_1029() : var4;
      }
   }

   private boolean lll(class_310 var1, Object var2) {
      this.Il = true;

      boolean var5;
      try {
         IllllIlI.lIllll(var1);
         class_1269 var3 = IllllIlI.lIlII(var1, class_1268.field_5808, var2.l());
         boolean var4 = var3 != null && var3.method_23665();
         if (var4) {
            var1.field_1724.method_6104(class_1268.field_5808);
         }

         var5 = var4;
      } finally {
         this.Il = false;
      }

      return var5;
   }

   private boolean IIII() {
      double var1 = (Double)this.lll.III();
      return var1 >= (double)100.0F || var1 > (double)0.0F && ThreadLocalRandom.current().nextDouble((double)100.0F) < var1;
   }

   public void IIIl(class_2596<?> var1) {
      class_310 var2 = class_310.method_1551();
      if (var2 != null && var2.field_1724 != null && this.IIl >= 0 && var1 instanceof class_2743 var3) {
         if (var3.method_11818() == this.IIl) {
            class_243 var4 = var3.method_73085();
            if (var4 != null) {
               this.II = var4;
               this.I = var2.field_1724.field_6012;
            }

            return;
         }
      }

   }

   private class_243 IIll(class_310 var1, class_1309 var2) {
      class_243 var3 = this.IIl == var2.method_5628() && this.I != IIllI(156024243, -1845709496) && var1.field_1724.field_6012 - this.I <= 3 ? this.II : var2.method_18798();
      return var3 == null ? class_243.field_1353 : new class_243(var3.field_1352, (double)0.0F, var3.field_1350);
   }

   public String Il() {
      long var10000 = Math.round((Double)this.lll.III());
      String var3 = lIlIII.Il(IIlll(-80788999, 198509593));
      long var1 = var10000;
      return var1 + var3;
   }

   public boolean IlII() {
      return this.IIIIIlI() && this.Il;
   }

   private int IlIl(class_310 var1) {
      for(int var2 = 0; var2 < IIllI(156024242, 1845622506); ++var2) {
         class_1799 var3 = var1.field_1724.method_31548().method_5438(var2);
         if (var3.method_31574(class_1802.field_8786)) {
            return var2;
         }
      }

      return -1;
   }

   public void lI() {
      this.lIll();
      this.llI.IIIlIll();
      this.llI.IIllII();
      this.Il = false;
      class_310 var1 = class_310.method_1551();
      if (var1 != null && var1.field_1724 != null) {
         IllllIlI.IlII(var1, this, null.II);
      }

   }

   private <undefinedtype> Illl(class_310 var1, class_2338 var2) {
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null && var2 != null && this.IIIll(var1, var2)) {
         double var3 = Math.max((double)0.0F, var1.field_1724.method_55754() - 0.1);

         for(class_2350 var8 : class_2350.values()) {
            class_2338 var9 = var2.method_10093(var8);
            if (this.IIlIl(var1, var9)) {
               class_2350 var10 = var8.method_10153();
               class_243 var11 = class_243.method_24953(var9).method_1019(class_243.method_24954(var10.method_62675()).method_1021((double)0.5F));
               if (!(var1.field_1724.method_33571().method_1025(var11) > var3 * var3)) {
                  class_243 var12 = var11.method_1020(class_243.method_24954(var10.method_62675()).method_1021(0.001));
                  class_3965 var13 = var1.field_1687.method_17742(new class_3959(var1.field_1724.method_33571(), var12, class_3960.field_17559, class_242.field_1348, var1.field_1724));
                  if (var13 != null && var13.method_17777().equals(var9) && var2.equals(var9.method_10093(var13.method_17780()))) {
                     return new Record(var2.method_10062(), var9.method_10062(), var11, var13) {
                        private final class_3965 I;
                        private final class_2338 l;
                        private final class_2338 II;
                        private final class_243 Il;

                        public class_2338 I() {
                           return this.II;
                        }

                        public class_3965 l() {
                           return this.I;
                        }

                        public class_243 II() {
                           return this.Il;
                        }

                        public class_2338 Il() {
                           return this.l;
                        }

                        private {
                           this.l = var1;
                           this.II = var2;
                           this.Il = var3;
                           this.I = var4;
                        }
                     };
                  }
               }
            }
         }

         return null;
      } else {
         return null;
      }
   }

   private <undefinedtype> lIII(class_310 var1, List<class_2338> var2) {
      for(class_2338 var4 : var2) {
         <undefinedtype> var5 = this.Illl(var1, var4);
         if (var5 != null) {
            return var5;
         }
      }

      return null;
   }

   public void lIl() {
      this.llI.IIlIIII();
   }

   public lIllI() {
      super((Object)lIlIII.l(IIlll(-80789000, -435341516)), lIllII.I, (Object)lIlIII.l(IIlll(-80788997, -1962992952)));
      this.IIIl = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IIlll(-80788993, 1522336251)), <undefinedtype>.class, null.I));
      this.lIl = (IIIllIIII)this.IIIlIll((IIIllIIII)(new IIIllIIII(lIlIII.l(IIlll(-80788994, 1509438770)), (double)50.0F, (double)1.0F, (double)100.0F, (double)1.0F)).lIII(() -> this.IIIl.III() == null.Il));
      this.llI = new IlIlIll();
      this.IIl = -1;
      this.IIlI = IIllI(156024241, -1718773965);
      this.IIII = IIllI(156024240, -1068061560);
      this.lII = IIllI(156024247, 1660358907);
      this.I = IIllI(156024246, 216293320);
      this.II = class_243.field_1353;
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (this.IIl >= 0 && var1 != null && var1.field_1724 != null) {
         if (var1.field_1724.field_6012 > this.IIII) {
            this.lIll();
         } else {
            if (this.lI) {
               if (var1.field_1724.field_6012 - this.lII <= 3) {
                  return;
               }

               this.lI = false;
               this.IIlI = var1.field_1724.field_6012;
            }

            this.IIIII(var1);
         }
      }
   }

   private <undefinedtype> lIIl(class_310 var1, class_1309 var2) {
      if ((Boolean)this.Ill.III()) {
         <undefinedtype> var3 = this.lIII(var1, this.IIlII(var1, var2));
         if (var3 != null) {
            return var3;
         }
      }

      return this.lIII(var1, List.of(var2.method_24515()));
   }

   private void lIll() {
      this.IIl = -1;
      this.IIlI = IIllI(156024245, 1159876405);
      this.IIII = IIllI(156024244, -1038008392);
      this.lII = IIllI(156024251, 2008166184);
      this.I = IIllI(156024250, -1389458538);
      this.IlI = 0.0F;
      this.II = class_243.field_1353;
      this.lI = false;
      this.llI.IIllII();
   }

   private void llII(class_310 var1, int var2, boolean var3) {
      this.lI = false;
      this.lII = IIllI(156024249, -1058940547);
      if (var2 == this.IIl) {
         if (var3) {
            this.lIll();
         } else {
            if (var1 != null && var1.field_1724 != null) {
               this.IIlI = var1.field_1724.field_6012 + 1;
            }

         }
      }
   }

   private void IIIII(class_310 var1) {
      if (this.IIl >= 0 && var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var1.field_1755 == null && var1.field_1724.field_6012 >= this.IIlI) {
         lIllIIl var2 = lIllIIl.Il();
         IIIIIIIl var3 = var2 != null && var2.IIl() != null ? var2.IIl().lIIl() : null;
         if ((var3 == null || !var3.IIlll()) && !IlIlIl.ll() && !IllllIlI.IlllIl() && !lIlIllll.lIIl(var1)) {
            class_1297 var4 = var1.field_1687.method_8469(this.IIl);
            if (var4 instanceof class_1309) {
               class_1309 var5 = (class_1309)var4;
               if (var5.method_5805() && !IllllIlI.ll(var5)) {
                  if (var5 instanceof class_1657) {
                     class_1657 var6 = (class_1657)var5;
                     if (this.lII(var6)) {
                        this.lIll();
                        return;
                     }
                  }

                  int var13 = this.IlIl(var1);
                  <undefinedtype> var7 = var13 < 0 ? null : this.lIIl(var1, var5);
                  if (var7 == null) {
                     this.IIlI = var1.field_1724.field_6012 + 1;
                     return;
                  }

                  int var8 = this.IIl;
                  if (this.IIIl.III() != null.Il) {
                     float[] var14 = IlIlIl.llIlI(var1, var7.II());
                     if (var14 == null) {
                        this.IIlI = var1.field_1724.field_6012 + 1;
                        return;
                     }

                     boolean var15 = IlIlIl.IIIIlI(var1, IIllI(156024248, -1699030603), var14[0], var14[1], () -> {
                        boolean var5 = IllllIlI.llIll(var1, this, var13, () -> this.lll(var1, var7));
                        this.llII(var1, var8, var5);
                        return var5;
                     });
                     if (!var15) {
                        this.IIlI = var1.field_1724.field_6012 + 1;
                        return;
                     }

                     this.lI = true;
                     this.lII = var1.field_1724.field_6012;
                     return;
                  }

                  boolean var10000;
                  label122: {
                     label121: {
                        float var9 = this.llI.IlIl(var1, var7.II(), ((Double)this.lIl.III()).floatValue());
                        if (!(var9 <= 1.0F)) {
                           class_239 var12 = var1.field_1765;
                           if (!(var12 instanceof class_3965)) {
                              break label121;
                           }

                           class_3965 var11 = (class_3965)var12;
                           if (!var11.method_17777().equals(var7.I()) || var11.method_17780() != var7.l().method_17780()) {
                              break label121;
                           }
                        }

                        var10000 = true;
                        break label122;
                     }

                     var10000 = false;
                  }

                  boolean var10 = var10000;
                  if (var10) {
                     this.llI.IIllII();
                     boolean var16 = IllllIlI.llIll(var1, this, var13, () -> this.lll(var1, var7));
                     this.llII(var1, var8, var16);
                  } else {
                     this.IIlI = var1.field_1724.field_6012;
                  }

                  return;
               }
            }

            this.lIll();
         } else {
            this.IIlI = var1.field_1724.field_6012 + 1;
         }
      }
   }

   public void lIlI(class_1297 var1) {
      class_310 var2 = class_310.method_1551();
      if (var1 instanceof class_1657 var3) {
         if (var2 != null && var2.field_1724 != null && var2.field_1687 != null && var3.method_5805() && !IllllIlI.ll(var3) && !this.lII(var3) && !this.lI && this.IIII()) {
            this.IIl = var3.method_5628();
            this.IIlI = var2.field_1724.field_6012;
            this.IIII = var2.field_1724.field_6012 + IIllI(156024255, -939930794);
            this.IlI = var2.field_1724.method_36454();
            this.II = class_243.field_1353;
            this.I = IIllI(156024254, 1750323658);
            this.IIIII(var2);
            return;
         }
      }

   }

   private boolean IIIll(class_310 var1, class_2338 var2) {
      class_2680 var3 = var1.field_1687.method_8320(var2);
      return var3.method_26215() || var3.method_45474() || var3.method_27852(class_2246.field_10382) || var3.method_27852(class_2246.field_10164);
   }

   private List<class_2338> IIlII(class_310 var1, class_1309 var2) {
      class_238 var3 = var2.method_5829();
      int var4 = (int)Math.floor(var3.field_1322 + 1.0E-4);
      class_243 var5 = this.llI(var1, var2);
      class_243 var6 = this.IIll(var1, var2);
      if (var5.method_1027() < 1.0E-6 && var6.method_1027() < 1.0E-6) {
         return List.of(var2.method_24515());
      } else {
         boolean var7 = this.I != IIllI(156024253, -1584619736) && var1.field_1724.field_6012 - this.I <= 3;
         double var8 = var1.field_1724.method_5624() ? 0.28 : (double)0.0F;
         class_243 var10 = var7 ? var6.method_1021(1.8) : var6.method_1021(1.2).method_1019(var5.method_1021(0.65 + var8));
         double var11 = var10.method_1033();
         if (var11 > 2.2) {
            var10 = var10.method_1021(2.2 / var11);
         }

         class_238 var13 = var3.method_989(var10.field_1352 * (double)0.5F, (double)0.0F, var10.field_1350 * (double)0.5F);
         class_238 var14 = var3.method_989(var10.field_1352, (double)0.0F, var10.field_1350);
         class_243 var15 = (new class_243(var2.method_23317(), (double)var4 + (double)0.5F, var2.method_23321())).method_1019(var10);
         int var16 = (int)Math.floor(Math.min(Math.min(var3.field_1323, var13.field_1323), var14.field_1323)) - 1;
         int var17 = (int)Math.floor(Math.max(Math.max(var3.field_1320, var13.field_1320), var14.field_1320) - 1.0E-7) + 1;
         int var18 = (int)Math.floor(Math.min(Math.min(var3.field_1321, var13.field_1321), var14.field_1321)) - 1;
         int var19 = (int)Math.floor(Math.max(Math.max(var3.field_1324, var13.field_1324), var14.field_1324) - 1.0E-7) + 1;
         ArrayList var20 = new ArrayList();
         int[] var21 = var2.method_24828() && !(Math.abs(var2.method_18798().field_1351) > 0.08) ? new int[]{var4} : new int[]{var4, var4 - 1, var4 + 1};

         for(int var25 : var21) {
            for(int var26 = var16; var26 <= var17; ++var26) {
               for(int var27 = var18; var27 <= var19; ++var27) {
                  class_2338 var28 = new class_2338(var26, var25, var27);
                  double var29 = Math.max(this.IlI(var14, var28), Math.max(this.IlI(var13, var28) * 0.95, this.IlI(var3, var28) * 0.85));
                  if (var25 != var4) {
                     var29 *= 0.8;
                  }

                  var20.add(new Record(var28, var29, class_243.method_24953(var28).method_1025(var15)) {
                     private final class_2338 I;
                     private final double l;
                     private final double II;

                     private {
                        this.I = var1;
                        this.II = var2;
                        this.l = var4;
                     }

                     public double I() {
                        return this.l;
                     }

                     public class_2338 l() {
                        return this.I;
                     }

                     public double II() {
                        return this.II;
                     }
                  });
               }
            }
         }

         var20.sort(Comparator.comparingDouble(<undefinedtype>::II).reversed().thenComparingDouble(<undefinedtype>::I));
         return var20.stream().map(<undefinedtype>::l).toList();
      }
   }

   private boolean IIlIl(class_310 var1, class_2338 var2) {
      class_2680 var3 = var1.field_1687.method_8320(var2);
      return !var3.method_26215() && var3.method_26227().method_15769() && !var3.method_26220(var1.field_1687, var2).method_1110();
   }

   private static int IIllI(int var0, int var1) {
      return IIll[var0 ^ 156024243] ^ var1 ^ var0;
   }

   static {
      short var6 = 2842;
      String var7 = "粼糄籃籄ﵺﵙ\ufdc9ﶾﴴﶆﴃﷳ醊醫酢酛釙酴釱鄒鄼鄟醪釽鄨采釠釺鄓釮醱鄰釼鄶鄼釈鄍鄂鄽釜鄹醚鄹醃量釖鄕鄀釤酇醨酜鄒鄄釰釛酘釸醘醗鄕釕釣酊量酿鄶釘酩酯酥醞配醠酕釙释醵酯酯剷刭劋劢別劝刀勽㷕㶭㴪㴭䲪䲈䱰䱿䳺䱮䳫䰢䰋䰿䳮䳜䰉䲵䲿䲅䇈䇓䄼䄎䆛䄟䇺䅰䅣䅧䆗䆿䅣䇪䆢䆾䅕䆅䆬䄬䊉䊼䈼䉐䊃䉈䋾䈘䈨䈈䋳䋶";
      char[] var8 = "ଞ\u0b12\u0b5e\u0b12ଞଊ\u0b0eଖ".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IlII = var9;
            IlIl = new Object[var9.length];
            int var2 = 652474388;
            byte[] var0 = ">SðïA®³E6\"Ò\u0096oùé,ÍXUX£K\u001ajê\u008d\n\u0094m\u008ez\u0018Ø\u001dj\u0087\u0002\u0081Î8oN\u009cÐµ\u0015\u009c¶èV\u008eõÇü\u0094`\u000e#Ú\u0081".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IIll = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IIll[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 65;
                     break;
                  case 1:
                     var10000 = 1;
                     break;
                  case 2:
                     var10000 = 25;
                     break;
                  case 3:
                     var10000 = 94;
                     break;
                  case 4:
                     var10000 = 65;
                     break;
                  case 5:
                     var10000 = 50;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static String IIlll(int var0, int var1) {
      int var3 = var0 ^ -80788999;
      char[] var4 = IlII[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IlIl[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IlIl[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 552949680;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 212;
               break;
            case 1:
               var9 = 142;
               break;
            case 2:
               var9 = 125;
               break;
            case 3:
               var9 = 61;
               break;
            case 4:
               var9 = 152;
               break;
            case 5:
               var9 = 80;
               break;
            case 6:
               var9 = 166;
               break;
            case 7:
               var9 = 56;
               break;
            case 8:
               var9 = 14;
               break;
            case 9:
               var9 = 109;
               break;
            case 10:
               var9 = 182;
               break;
            case 11:
               var9 = 249;
               break;
            case 12:
               var9 = 68;
               break;
            case 13:
               var9 = 157;
               break;
            case 14:
               var9 = 213;
               break;
            case 15:
               var9 = 168;
               break;
            case 16:
               var9 = 123;
               break;
            case 17:
               var9 = 252;
               break;
            case 18:
               var9 = 252;
               break;
            case 19:
               var9 = 60;
               break;
            case 20:
               var9 = 184;
               break;
            case 21:
               var9 = 105;
               break;
            case 22:
               var9 = 33;
               break;
            case 23:
               var9 = 245;
               break;
            case 24:
               var9 = 119;
               break;
            case 25:
               var9 = 39;
               break;
            case 26:
               var9 = 33;
               break;
            case 27:
               var9 = 160;
               break;
            case 28:
               var9 = 80;
               break;
            case 29:
               var9 = 246;
               break;
            case 30:
               var9 = 87;
               break;
            case 31:
               var9 = 189;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
