package x;

import com.google.gson.JsonObject;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_4969;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_239.class_240;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;

@Environment(EnvType.CLIENT)
public final class lIllIIII extends IIIIIIIlI {
   private int I;
   private final lIIIIl l;
   private final lIIIIl II;
   private class_2338 Il;
   private int lI;
   private boolean ll;
   private long III;
   private final IIIllIIII IIl;
   private long IlI;
   private int Ill;
   private final IlIIIlIlI<<undefinedtype>> lII;
   private int lIl;
   private int llI;
   private final lIIIIl lll;
   private final IIIllIIII IIII;
   private final IIIllIIII IIIl;
   private static final <undefinedtype> IIlI;
   private static final int IIll = 8;
   private boolean IlII;
   private final IIIllIIII IlIl;
   private long IllI;
   private <undefinedtype> Illl;
   private final IlIIIlIlI<<undefinedtype>> lIII;
   private int lIIl;
   private final IIIllIIII lIlI;
   private final lIIIIl lIll = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IllIlI(-1441527391, -97123132)), true));
   private int llII;
   private final lIIIIl llIl;
   private static final int lllI = 2;
   private class_2338 llll;
   private static final <undefinedtype> IIIII;
   private final lIIIIl IIIIl;
   private boolean IIIlI;
   private int IIIll;
   private final llllIlIl IIlII;
   private class_2338 IIlIl;
   private <undefinedtype> IIllI;
   private static final long IIlll = 175L;
   private boolean IlIII;
   private static final class_2350[] IlIIl;
   private final IlIlIll IlIlI;
   private int IlIll;
   private class_2338 IllII;
   private static final int IllIl = 9;
   private final Set<Long> IlllI;
   private boolean Illll;
   private static final int lIIII = 2;
   private static final int[] lIIIl;
   private static final String[] lIIlI;
   private static final Object[] lIIll;

   public String I() {
      return this.Il();
   }

   private boolean l(class_310 var1, class_2338 var2, class_243 var3) {
      if (var1 != null && var1.field_1724 != null) {
         class_238 var4 = new class_238((double)var2.method_10263(), (double)var2.method_10264(), (double)var2.method_10260(), (double)var2.method_10263() + (double)1.0F, (double)var2.method_10264() + (double)1.0F, (double)var2.method_10260() + (double)1.0F);
         class_238 var5 = var1.field_1724.method_5829();
         if (var4.method_994(var5)) {
            return true;
         } else {
            if (var3 != null) {
               class_243 var6 = var1.field_1724.method_73189();
               class_243 var7 = var3.method_1020(var6);
               if (var7.method_1027() > 0.0025) {
                  class_238 var8 = var5.method_997(var7);
                  if (var4.method_994(var8)) {
                     return true;
                  }
               }
            }

            return false;
         }
      } else {
         return true;
      }
   }

   private boolean II(class_310 var1, class_2338 var2) {
      if (var1 != null && var1.field_1687 != null && var2 != null) {
         class_2680 var3 = var1.field_1687.method_8320(var2);
         return !var3.method_26215() && !var3.method_45474() && !var3.method_26220(var1.field_1687, var2).method_1110();
      } else {
         return false;
      }
   }

   private void ll(class_310 var1) {
      if ((Boolean)this.lIll.III() && this.IIlI()) {
         class_1657 var2 = this.IIllII(var1);
         if (var2 == null) {
            this.IIllIl(var1, IllIIl(-1693007999, -547887531), (class_2338)null);
            this.III = System.currentTimeMillis() - 175L + 25L;
         } else {
            class_2338 var3 = this.IIlIlI(var1, var2);
            if (var3 != null) {
               this.IlIl(var1, var3);
               this.III = System.currentTimeMillis();
               if (this.IIIll(this.IIlII) <= 0L) {
                  this.IlII();
               }

            } else {
               int var4 = this.IIlllI(var1);
               int var5 = this.lllll(var1);
               if (var4 >= 0 && var5 >= 0) {
                  <undefinedtype> var6 = this.IlIIlI(var1, var2);
                  if (var6 == null) {
                     this.IIllIl(var1, IllIIl(-1693007997, -1110779880), var2.method_24515());
                     this.III = System.currentTimeMillis() - 175L + 25L;
                  } else {
                     this.III = System.currentTimeMillis();
                     if (this.lIII.III() == null.Il) {
                        this.Illl = var6;
                        this.lI = var4;
                        this.IlII = true;
                        this.IlI = System.currentTimeMillis();
                     } else {
                        this.IIlII(var1, var6, var4);
                        this.IIllIl(var1, IllIIl(-1693007998, 1103238486), var6.I());
                     }
                  }
               } else {
                  this.IIllIl(var1, IllIIl(-1693008000, -818516573), var2.method_24515());
                  this.III = System.currentTimeMillis() - 175L + 25L;
               }
            }
         }
      }
   }

   public void lIl() {
      this.IlIlI.IIlIIII();
      this.IllIII(class_310.method_1551(), false);
   }

   private void III(class_310 var1) {
      IllllIlI.IIIIllI(var1.field_1690.field_1904);
      var1.field_1690.field_1904.method_23481(false);
      IllllIlI.lIllll(var1);
   }

   public void IIl(JsonObject var1) {
      super.IIl(var1);
      this.llIlIl(var1, IIlI.lIlI(), new llllIlIl[]{this.IIlII});
      this.llIlIl(var1, lIlIII.Il(IllIlI(-1441527386, 632958627)), new llllIlIl[]{this.IIlII});
      this.llIlIl(var1, lIlIII.Il(IllIlI(-1441527385, 1502884711)), new llllIlIl[]{this.IIlII});
      this.llIlIl(var1, lIlIII.Il(IllIlI(-1441527388, -255437326)), new llllIlIl[]{this.IIlII});
   }

   public void IlI(class_310 var1, class_1268 var2, class_3965 var3) {
      if (!this.ll) {
         this.lIllI();
         if (this.IIIIIlI() && this.llllI(var1) && var2 == class_1268.field_5808 && var3 != null && var3.method_17783() == class_240.field_1332 && var1.field_1724.method_6047().method_31574(class_1802.field_23141)) {
            lIllIIl var4 = lIllIIl.Il();
            if (var4 != null) {
               IIIlIlI var5 = var4.IIl().IIlll();
               if (var5 != null && var5.IIIIIlI()) {
                  if (var5.lIIII()) {
                     return;
                  }

                  class_2680 var6 = var1.field_1687.method_8320(var3.method_17777());
                  if (var6.method_27852(class_2246.field_23152)) {
                     return;
                  }
               }
            }

            class_2680 var7 = var1.field_1687.method_8320(var3.method_17777());
            if (!var7.method_27852(class_2246.field_23152)) {
               class_2338 var8 = var7.method_45474() ? var3.method_17777() : var3.method_17777().method_10093(var3.method_17780());
               if (var1.field_1687.method_8320(var8).method_45474()) {
                  this.IlIll = var1.field_1724.field_6012;
                  this.IIlIl = var8.method_10062();
                  this.IIllIl(var1, IllIIl(-1693007995, 1181028658), this.IIlIl);
               }
            }
         }
      }
   }

   private void lII(class_310 var1) {
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null && this.IIlIl != null) {
         int var2 = var1.field_1724.field_6012 - this.IlIll;
         if (var2 >= 0 && var2 <= IllIIl(-1693007996, 1771269202)) {
            if (var1.field_1687.method_8320(this.IIlIl).method_27852(class_2246.field_23152)) {
               class_2338 var3 = this.IIlIl.method_10062();
               this.lIllI();
               this.IIllIl(var1, IllIIl(-1693007993, -869151615), var3);
               if (this.IIlI()) {
                  this.IlIl(var1, var3);
               }

            }
         } else {
            this.lIllI();
         }
      } else {
         this.lIllI();
      }
   }

   private boolean IIII(class_310 var1, class_1657 var2) {
      if (var2 != null && var1.field_1724 != null && var2 != var1.field_1724) {
         if (var2.method_5805() && !var2.method_7325() && !var2.method_68878()) {
            lIllIIl var3 = lIllIIl.Il();
            if (var3 != null && var3.IIl() != null) {
               lI var4 = var3.IIl().IIIIIll();
               if (var4 != null && var4.IIIIIlI() && var4.IlI(var2)) {
                  return false;
               }

               lIIIlIll var5 = var3.IIl().IIIIIl();
               if (var5 != null && var5.IIIIIlI() && var5.Il(var2)) {
                  return false;
               }

               llIIIIlI var6 = var3.IIl().IlllI();
               if (var6 != null && var6.IIIIIlI() && var6.ll(var2)) {
                  return false;
               }
            }

            return true;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private void IIIl(class_310 var1) {
      <undefinedtype> var2 = this.lllIl(var1);
      if (var2 == null) {
         if (this.llIII(var1)) {
            this.IIllIl(var1, IllIIl(-1693007994, 349218190), this.Il);
         } else {
            this.IIllIl(var1, IllIIl(-1693007991, -1842396964), this.Il);
            if ((Boolean)this.l.III() && (Boolean)this.IIIIl.III() && this.Il != null && !this.IlIII) {
               this.IIlll(var1);
            } else {
               this.llII(var1);
            }
         }
      } else {
         int var3 = this.lIIl;
         if (var3 >= 0 && var3 < IllIIl(-1693007992, 1594616728)) {
            boolean var4 = this.Illll;
            boolean var5 = this.IlIII;
            if (var1.field_1724 != null) {
               this.lIl = var1.field_1724.field_6012 + 2;
            }

            <undefinedtype> var6 = () -> {
               if (!var4 && !var5 && this.IIllI(var1, var2.I())) {
                  this.IlII = false;
                  this.IllI = System.currentTimeMillis() + 15L;
                  return false;
               } else {
                  boolean var6 = IllllIlI.llIll(var1, this, var3, () -> {
                     this.ll = true;

                     boolean var4;
                     try {
                        boolean var3 = IllllIlI.IIlIIII(var1, var2.II());
                        if (var3) {
                           var1.field_1724.method_6104(class_1268.field_5808);
                        }

                        var4 = var3;
                     } finally {
                        this.ll = false;
                     }

                     return var4;
                  });
                  if (!var6) {
                     this.IIllIl(var1, IllIIl(-1693007970, -1875031687), this.Il);
                     this.IlII = false;
                     this.IllI = System.currentTimeMillis() + 15L;
                     return false;
                  } else if (var4) {
                     this.IIllIl(var1, IllIIl(-1693007967, -508775960), this.Il);
                     this.IIIlI = true;
                     --this.Ill;
                     this.IlII = false;
                     long var7 = this.IIIll(this.IIlII);
                     if (this.Ill > 0) {
                        this.IllI = System.currentTimeMillis() + var7;
                        if (var7 <= 0L) {
                           this.IIIl(var1);
                        }

                        return true;
                     } else {
                        <undefinedtype> var9 = this.IlIll(var1, this.Il);
                        if (var9 != null) {
                           this.Illll = false;
                           this.IIllI = var9;
                           this.IllII = var9.II().method_17777().method_10093(var9.II().method_17780()).method_10062();
                           this.IllI = System.currentTimeMillis() + var7;
                           if (var7 <= 0L) {
                              this.IIIl(var1);
                           }

                           return true;
                        } else if ((Boolean)this.IIIIl.III()) {
                           this.IIlll(var1);
                           if (var7 <= 0L) {
                              this.IIIl(var1);
                           }

                           return true;
                        } else {
                           this.llII(var1);
                           return true;
                        }
                     }
                  } else if (!var5) {
                     this.IIllIl(var1, IllIIl(-1693007968, 1099119874), this.Il);
                     this.IlII = false;
                     if ((Boolean)this.IIIIl.III()) {
                        this.IIlll(var1);
                        if (this.IIIll(this.IIlII) <= 0L) {
                           this.IIIl(var1);
                        }

                        return true;
                     } else {
                        this.llII(var1);
                        return true;
                     }
                  } else {
                     this.IlII = false;
                     this.IIllIl(var1, IllIIl(-1693007965, -272480987), this.Il);
                     this.llII(var1);
                     return var6;
                  }
               }
            };
            if (this.lIII.III() == null.II) {
               if (!IlIlIl.IIlIII(var1, IllIIl(-1693007989, 1470324317), var2.l(), var6)) {
                  this.IIllIl(var1, IllIIl(-1693007990, 828259594), this.Il);
               }
            } else {
               var6.run();
            }

         } else if ((Boolean)this.l.III() && (Boolean)this.IIIIl.III() && this.Il != null && !this.IlIII) {
            this.IIlll(var1);
         } else {
            this.llII(var1);
         }
      }
   }

   private boolean IIlI() {
      double var1 = Math.max((double)0.0F, Math.min((double)100.0F, (Double)this.lIlI.III()));
      return var1 >= (double)100.0F || var1 > (double)0.0F && ThreadLocalRandom.current().nextDouble((double)100.0F) < var1;
   }

   private class_2338 IIll(class_310 var1, class_2338 var2) {
      class_243 var3 = class_243.method_24953(var2);
      class_243 var4 = this.lIlll(var1);
      double var5 = var4.field_1352 - var3.field_1352;
      double var7 = var4.field_1350 - var3.field_1350;
      class_2338 var9 = var2.method_10093(this.lIII(var1, var2));
      if (Math.abs(var5) > (double)0.5F && Math.abs(var7) > (double)0.5F) {
         var9 = var2.method_10069((int)Math.signum(var5), 0, (int)Math.signum(var7));
      }

      return var9;
   }

   private void IlII() {
      class_310 var1 = class_310.method_1551();
      if (this.IIIIIlI() && this.llllI(var1)) {
         lIllIIl var2 = lIllIIl.Il();
         if (var2 != null) {
            IIIlIlI var3 = var2.IIl().IIlll();
            if (var3 != null && var3.IIIIIlI() && var3.lIIII()) {
               this.IlIIIl();
               return;
            }
         }

         if (System.currentTimeMillis() >= this.IllI) {
            if (!this.IlIII && !this.IIlIll(var1, this.lIIl)) {
               if ((Boolean)this.l.III() && (Boolean)this.IIIIl.III() && this.Il != null) {
                  this.IIlll(var1);
               } else {
                  this.IlIIIl();
               }
            } else if (this.lIII.III() == null.Il && !this.IlII) {
               this.IlII = true;
               this.IlI = System.currentTimeMillis();
            } else if (!this.IlII) {
               this.IIIl(var1);
            } else {
               <undefinedtype> var5 = this.lllIl(var1);
               if (var5 == null) {
                  if (!this.llIII(var1)) {
                     if ((Boolean)this.l.III() && (Boolean)this.IIIIl.III() && this.Il != null && !this.IlIII) {
                        this.IlII = false;
                        this.IIlll(var1);
                     } else {
                        this.IlIIIl();
                     }
                  }
               } else {
                  boolean var4 = this.llIll(var1, var5);
                  if (var4) {
                     this.IlII = false;
                     this.IIIl(var1);
                  } else {
                     this.IlIlI.IlIl(var1, var5.l(), ((Double)this.IIII.III()).floatValue());
                     if (System.currentTimeMillis() - this.IlI >= 1500L) {
                        this.IlII = false;
                        if ((Boolean)this.l.III() && (Boolean)this.IIIIl.III() && this.Il != null && !this.IlIII) {
                           this.IIlll(var1);
                        } else {
                           this.IlIIIl();
                        }
                     }

                  }
               }
            }
         }
      } else {
         this.IlIIIl();
      }
   }

   private void IlIl(class_310 var1, class_2338 var2) {
      if (this.IllII == null) {
         int var3 = this.lllll(var1);
         if (var3 < 0) {
            this.IIllIl(var1, IllIIl(-1693007987, 1508405028), var2);
            if ((Boolean)this.l.III() && (Boolean)this.IIIIl.III()) {
               int var9 = this.lIIII(var1, var2);
               if (var9 > 0) {
                  this.I = IllllIlI.lIIlI(var1.field_1724.method_31548());
                  this.Il = var2.method_10062();
                  this.IIlll(var1);
               }
            }

         } else {
            int var4 = Math.max(1, Math.min(4, (int)(Double)this.IlIl.III()));
            int var5 = this.lIIII(var1, var2);
            int var6 = Math.max(0, var4 - Math.max(0, var5));
            boolean var7 = (Boolean)this.llIl.III() && var6 > 0 && this.IlllI(var1, var2);
            this.Il = var2.method_10062();
            this.llII = var1.field_1724.field_6012 + IllIIl(-1693007988, 61711641);
            <undefinedtype> var8 = this.IlIll(var1, var2);
            if (var8 == null && !var7) {
               if ((Boolean)this.l.III() && (Boolean)this.IIIIl.III()) {
                  this.I = IllllIlI.lIIlI(var1.field_1724.method_31548());
                  this.IIlll(var1);
               } else {
                  this.Il = null;
               }
            } else {
               this.I = IllllIlI.lIIlI(var1.field_1724.method_31548());
               this.IllII = var7 ? var2.method_10062() : (var8 != null ? var8.II().method_17777().method_10093(var8.II().method_17780()).method_10062() : var2.method_10062());
               this.Illll = var7;
               this.Ill = var7 ? var6 : 0;
               this.IIllI = var7 ? this.IlIIll(var2) : var8;
               this.lIIl = var3;
               this.IlIII = false;
               this.IllI = System.currentTimeMillis() + this.IIIll(this.IIlII);
               this.lIl = var1.field_1724.field_6012 + this.lllII() + 2;
               this.IIllIl(var1, var7 ? IllIIl(-1693007985, -178831933) : IllIIl(-1693007986, 2042825562), var2);
            }
         }
      }
   }

   public void IllI(class_310 var1) {
      if (this.lIIl(var1)) {
         this.III(var1);
      }

      if (this.IIIIIlI() && this.llllI(var1)) {
         if (this.Illl != null) {
            this.llIIl(var1);
         } else if (this.IllII != null && System.currentTimeMillis() >= this.IllI) {
            this.IlII();
         }

      }
   }

   private boolean Illl(Object var1, Object var2) {
      if (var2 == null) {
         return true;
      } else {
         boolean var10000;
         switch (((<undefinedtype>)this.lII.III()).ordinal()) {
            case 0 -> var10000 = IIIII(var1.Il(), var1.I(), (double)var1.II(), var2.Il(), var2.I(), (double)var2.II());
            case 1 -> var10000 = IIIII((double)var1.II(), var1.I(), var1.Il(), (double)var2.II(), var2.I(), var2.Il());
            case 2 -> var10000 = IIIII(var1.I(), var1.Il(), (double)var1.II(), var2.I(), var2.Il(), (double)var2.II());
            default -> throw new MatchException((String)null, (Throwable)null);
         }

         return var10000;
      }
   }

   private class_2350 lIII(class_310 var1, class_2338 var2) {
      class_243 var3 = class_243.method_24953(var2);
      class_243 var4 = this.lIlll(var1);
      double var5 = var4.field_1352 - var3.field_1352;
      double var7 = var4.field_1350 - var3.field_1350;
      if (Math.abs(var5) >= Math.abs(var7)) {
         return var5 >= (double)0.0F ? class_2350.field_11034 : class_2350.field_11039;
      } else {
         return var7 >= (double)0.0F ? class_2350.field_11035 : class_2350.field_11043;
      }
   }

   private boolean lIIl(class_310 var1) {
      if (var1 != null && var1.field_1724 != null && var1.field_1690 != null && var1.field_1690.field_1904 != null && var1.field_1724.method_6047().method_31574(class_1802.field_8801)) {
         return this.IllII != null || var1.field_1724.field_6012 <= this.lIl;
      } else {
         return false;
      }
   }

   public void lIll(class_310 var1, class_1268 var2, class_3965 var3, class_1269 var4) {
      if (this.IlIll != IllIIl(-1693007983, -1007272213) && !this.ll) {
         lIllIIl var5 = lIllIIl.Il();
         if (var5 != null) {
            IIIlIlI var6 = var5.IIl().IIlll();
            if (var6 != null && var6.IIIIIlI() && var6.lIIII()) {
               this.lIllI();
               return;
            }
         }

         int var8 = var1.field_1724.field_6012 - this.IlIll;
         if (this.IIIIIlI() && this.llllI(var1) && var2 == class_1268.field_5808 && var8 >= 0 && var8 <= IllIIl(-1693007984, -1693073155) && this.IIlIl != null) {
            if (var4 != null && var4.method_23665()) {
               class_2338 var7 = this.IIlIl.method_10062();
               this.lIllI();
               this.IIllIl(var1, IllIIl(-1693007982, -1901993084), var7);
               if (this.IIlI()) {
                  this.IlIl(var1, var7);
               }

            } else {
               this.IIllIl(var1, IllIIl(-1693007981, -877880426), this.IIlIl);
            }
         } else {
            this.lIllI();
         }
      }
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (this.IIIIIlI() && this.llllI(var1)) {
         this.IllIII(var1, true);
         if (this.Illl != null) {
            this.llIIl(var1);
         } else if (this.IllII != null) {
            this.IlII();
         } else if (this.IIlIl != null) {
            this.lII(var1);
         } else {
            lIllIIl var2 = lIllIIl.Il();
            if (var2 != null) {
               IIIlIlI var3 = var2.IIl().IIlll();
               if (var3 != null && var3.IIIIIlI() && var3.lIIII()) {
                  return;
               }
            }

            if ((Boolean)this.lIll.III() && System.currentTimeMillis() - this.III >= Math.max(175L, this.IIIll(this.IIlII))) {
               this.ll(var1);
            }

         }
      }
   }

   private void llII(class_310 var1) {
      if ((Boolean)this.lIll.III()) {
         this.III = System.currentTimeMillis();
      }

      this.IlIIIl();
   }

   public boolean lllI() {
      return this.IIIIIlI() && this.IIlIl != null;
   }

   public String llll() {
      return super.llll();
   }

   private static boolean IIIII(double var0, double var2, double var4, double var6, double var8, double var10) {
      if (Math.abs(var0 - var6) > 1.0E-4) {
         return var0 < var6;
      } else if (Math.abs(var2 - var8) > 1.0E-4) {
         return var2 < var8;
      } else {
         return var4 < var10;
      }
   }

   private class_3965 IIIIl(class_310 var1) {
      if (var1 != null) {
         class_239 var3 = var1.field_1765;
         if (var3 instanceof class_3965) {
            class_3965 var2 = (class_3965)var3;
            return var2.method_17783() == class_240.field_1332 ? var2 : null;
         }
      }

      return null;
   }

   private long IIIll(llllIlIl var1) {
      double var2 = Math.max((double)0.0F, Math.min(var1.IlII(), var1.IlI()));
      double var4 = Math.max(var2, Math.max(var1.IlII(), var1.IlI()));
      return var2 == var4 ? Math.round(var2) : Math.round(ThreadLocalRandom.current().nextDouble(var2, var4));
   }

   private void IIlII(class_310 var1, Object var2, int var3) {
      this.Illl = null;
      this.lI = -1;
      this.IlII = false;
      if (var3 >= 0 && var3 < IllIIl(-1693007979, 629315201) && this.Illll(var1, var2)) {
         <undefinedtype> var4 = () -> {
            if (!this.Illll(var1, var2)) {
               return false;
            } else {
               boolean var4 = IllllIlI.llIll(var1, this, var3, () -> {
                  this.ll = true;

                  boolean var4;
                  try {
                     boolean var3 = IllllIlI.IIlIIII(var1, var2.II());
                     if (var3) {
                        var1.field_1724.method_6104(class_1268.field_5808);
                     }

                     var4 = var3;
                  } finally {
                     this.ll = false;
                  }

                  return var4;
               });
               if (var4) {
                  this.IlIl(var1, var2.I());
                  this.III = System.currentTimeMillis();
                  if (this.IIIll(this.IIlII) <= 0L) {
                     this.IlII();
                  }
               } else {
                  this.Illl = var2;
                  this.lI = var3;
                  this.III = System.currentTimeMillis() - 175L + 25L;
               }

               return var4;
            }
         };
         if (this.lIII.III() == null.II) {
            if (!IlIlIl.IIlIII(var1, IllIIl(-1693007980, -1046610752), var2.l(), var4)) {
               this.Illl = var2;
               this.lI = var3;
            }
         } else {
            var4.run();
         }

      }
   }

   private class_2338 IIlIl(class_310 var1, class_2338 var2) {
      class_243 var3 = class_243.method_24953(var2);
      class_243 var4 = this.lIlll(var1);
      double var5 = var4.field_1352 - var3.field_1352;
      double var7 = var4.field_1350 - var3.field_1350;
      return Math.abs(var5) > (double)0.5F && Math.abs(var7) > (double)0.5F ? new class_2338((int)Math.signum(var5), 0, (int)Math.signum(var7)) : var2.method_10093(this.lIII(var1, var2)).method_10059(var2);
   }

   private boolean IIllI(class_310 var1, class_2338 var2) {
      if (var1 != null && var1.field_1687 != null && var2 != null) {
         class_238 var3 = new class_238(var2);
         return !var1.field_1687.method_8333((class_1297)null, var3, (var0) -> !var0.method_7325() && !var0.method_31481() && (var0 instanceof class_1309 || var0.method_5863())).isEmpty();
      } else {
         return true;
      }
   }

   private void IIlll(class_310 var1) {
      if (this.Il != null && var1 != null && var1.field_1724 != null) {
         int var2 = IllllIlI.lIIlI(var1.field_1724.method_31548());
         int var3 = this.IlIlll(var1.field_1724, var2);
         if (var3 < 0) {
            this.llII(var1);
         } else {
            this.IlII = false;
            this.IllII = this.Il.method_10062();
            this.IIllI = this.IlIIll(this.Il);
            this.Illll = false;
            this.IlIII = true;
            this.lIIl = var3;
            this.IllI = System.currentTimeMillis() + this.IIIll(this.IIlII);
            this.lIl = var1.field_1724.field_6012 + this.lllII() + 2;
         }
      } else {
         this.llII(var1);
      }
   }

   private int IlIII(llllIlIl var1) {
      double var2 = Math.max((double)0.0F, Math.max(var1.IlII(), var1.IlI()));
      return Math.max(0, (int)Math.ceil(var2 / (double)50.0F));
   }

   private <undefinedtype> IlIIl(class_310 var1, class_2338 var2) {
      if (var1 != null && var1.field_1687 != null && var2 != null) {
         if (!var1.field_1687.method_8320(var2).method_45474()) {
            return null;
         } else if (this.IIllI(var1, var2)) {
            return null;
         } else {
            class_2338 var3 = var2.method_10074();
            if (this.II(var1, var3)) {
               <undefinedtype> var4 = this.IlIIII(var1, var2, var3, class_2350.field_11036);
               if (var4 != null) {
                  return var4;
               }
            }

            class_2350 var11 = this.lIII(var1, var2);
            class_2350[] var5 = new class_2350[]{var11, var11.method_10153(), var11.method_10170(), var11.method_10160(), class_2350.field_11033};

            for(class_2350 var9 : var5) {
               class_2338 var10 = var2.method_10093(var9.method_10153());
               if (this.II(var1, var10)) {
                  return this.IlIIII(var1, var2, var10, var9);
               }
            }

            return null;
         }
      } else {
         return null;
      }
   }

   private <undefinedtype> IlIlI(class_310 var1, class_2338 var2) {
      if (var1 != null && var1.field_1687 != null && var2 != null) {
         if (!var1.field_1687.method_8320(var2).method_45474()) {
            return null;
         } else if (this.IIllI(var1, var2)) {
            return null;
         } else {
            class_2338 var3 = var2.method_10074();
            if (this.II(var1, var3) && (this.Il == null || !var3.equals(this.Il))) {
               <undefinedtype> var4 = this.IlIIII(var1, var2, var3, class_2350.field_11036);
               if (var4 != null) {
                  return var4;
               }
            }

            class_2350 var11 = this.lIII(var1, var2);
            class_2350[] var5 = new class_2350[]{var11, var11.method_10153(), var11.method_10170(), var11.method_10160()};

            for(class_2350 var9 : var5) {
               class_2338 var10 = var2.method_10093(var9.method_10153());
               if (this.II(var1, var10) && (this.Il == null || !var10.equals(this.Il))) {
                  return this.IlIIII(var1, var2, var10, var9);
               }
            }

            return null;
         }
      } else {
         return null;
      }
   }

   private <undefinedtype> IlIll(class_310 var1, class_2338 var2) {
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null && var2 != null) {
         class_243 var3 = this.lIlll(var1);
         class_243 var4 = class_243.method_24953(var2);
         double var5 = var3.field_1352 - var4.field_1352;
         double var7 = var3.field_1350 - var4.field_1350;
         double var9 = Math.sqrt(var5 * var5 + var7 * var7);
         double var11 = var9 > 1.0E-4 ? var5 / var9 : (double)0.0F;
         double var13 = var9 > 1.0E-4 ? var7 / var9 : (double)0.0F;
         class_2350 var15 = var9 > 1.0E-4 ? (Math.abs(var5) >= Math.abs(var7) ? (var5 > (double)0.0F ? class_2350.field_11034 : class_2350.field_11039) : (var7 > (double)0.0F ? class_2350.field_11035 : class_2350.field_11043)) : class_2350.field_11043;
         class_2350 var16 = var9 > 1.0E-4 ? (Math.abs(var5) >= Math.abs(var7) ? (var7 > (double)0.0F ? class_2350.field_11035 : class_2350.field_11043) : (var5 > (double)0.0F ? class_2350.field_11034 : class_2350.field_11039)) : class_2350.field_11034;
         boolean var17 = var9 > 1.0E-4 && Math.min(Math.abs(var5), Math.abs(var7)) / var9 > 0.3;
         ArrayList var18 = new ArrayList();
         var18.add(var2.method_10079(var15, 2));
         if (var17) {
            var18.add(var2.method_10079(var15, 1).method_10079(var16, 1));
            var18.add(var2.method_10079(var15, 2).method_10079(var16, 1));
            var18.add(var2.method_10079(var15, 1).method_10079(var16, 2));
            var18.add(var2.method_10079(var16, 2));
         } else {
            var18.add(var2.method_10079(var15, 1).method_10079(var16, 1));
            var18.add(var2.method_10079(var15, 1).method_10079(var16.method_10153(), 1));
            var18.add(var2.method_10079(var16, 2));
         }

         for(class_2350 var22 : IlIIl) {
            class_2338 var23 = var2.method_10079(var22, 2);
            if (!var18.contains(var23)) {
               var18.add(var23);
            }
         }

         <undefinedtype> var26 = this.IllII(var1, var2, var18, var3, var11, var13, var9);
         if (var26 != null) {
            return var26;
         } else {
            ArrayList var27 = new ArrayList();
            var27.add(var2.method_10079(var15, 1));
            if (var17) {
               var27.add(var2.method_10079(var15, 1).method_10079(var16, 1));
               var27.add(var2.method_10079(var16, 1));
            } else {
               var27.add(var2.method_10079(var15, 1).method_10079(var16, 1));
               var27.add(var2.method_10079(var15, 1).method_10079(var16.method_10153(), 1));
               var27.add(var2.method_10079(var16, 1));
            }

            for(class_2350 var24 : IlIIl) {
               class_2338 var25 = var2.method_10079(var24, 1);
               if (!var27.contains(var25)) {
                  var27.add(var25);
               }
            }

            return this.IllII(var1, var2, var27, var3, var11, var13, var9);
         }
      } else {
         return null;
      }
   }

   private <undefinedtype> IllII(class_310 var1, class_2338 var2, List<class_2338> var3, class_243 var4, double var5, double var7, double var9) {
      <undefinedtype> var11 = null;
      float var12 = Float.POSITIVE_INFINITY;
      double var13 = Double.POSITIVE_INFINITY;
      double var15 = Double.POSITIVE_INFINITY;
      class_243 var17 = class_243.method_24953(var2);
      float var18 = llIlllll.l(var1.field_1724, var2, (class_2338)null, var4);

      for(class_2338 var20 : var3) {
         if (var9 > 1.0E-4) {
            class_243 var21 = class_243.method_24953(var20).method_1020(var17);
            double var22 = Math.sqrt(var21.field_1352 * var21.field_1352 + var21.field_1350 * var21.field_1350);
            double var24 = (var21.field_1352 * var5 + var21.field_1350 * var7) / Math.max(0.1, var22);
            if (var24 < 0.2) {
               continue;
            }
         }

         <undefinedtype> var27 = this.IlIlI(var1, var20);
         if (var27 != null && this.IIlIII(var1, var27) && !this.l(var1, var20, var4)) {
            float var28 = llIlllll.l(var1.field_1724, var2, var20, var4);
            if (!(var28 > var18 - 0.05F) || !(var18 > 1.0F)) {
               double var23 = IIllll(class_243.method_24953(var20), var17, var4);
               double var25 = var1.field_1724.method_33571().method_1025(var27.l());
               if (this.lIIll(var28, var23, var25, var12, var13, var15)) {
                  var11 = var27;
                  var12 = var28;
                  var13 = var23;
                  var15 = var25;
               }
            }
         }
      }

      return var11;
   }

   private <undefinedtype> IllIl(class_310 var1, class_2338 var2) {
      class_3965 var3 = this.IIIIl(var1);
      if (var3 != null && var2 != null && var2.equals(var3.method_17777())) {
         Record var4 = new Record(var2.method_10062(), var3.method_17784(), var3) {
            private final class_2338 I;
            private final class_3965 l;
            private final class_243 II;

            public class_2338 I() {
               return this.I;
            }

            private {
               this.I = var1;
               this.II = var2;
               this.l = var3;
            }

            public class_243 l() {
               return this.II;
            }

            public class_3965 II() {
               return this.l;
            }
         };
         return this.IIlIII(var1, var4) ? var4 : null;
      } else {
         return null;
      }
   }

   private boolean IlllI(class_310 var1, class_2338 var2) {
      if (var1 != null && var1.field_1687 != null && var2 != null) {
         class_2680 var3 = var1.field_1687.method_8320(var2);
         if (var3.method_27852(class_2246.field_23152)) {
            return (Integer)var3.method_11654(class_4969.field_23153) < 4;
         } else {
            return var3.method_26215() || var3.method_45474();
         }
      } else {
         return false;
      }
   }

   private boolean Illll(class_310 var1, Object var2) {
      if (var1 != null && var1.field_1687 != null && var2 != null && var2.II() != null) {
         class_3965 var3 = var2.II();
         return var1.field_1687.method_8320(var2.I()).method_45474() && !this.IIllI(var1, var2.I()) && var2.I().equals(var3.method_17777().method_10093(var3.method_17780())) && this.II(var1, var3.method_17777()) && this.IIlIII(var1, var2);
      } else {
         return false;
      }
   }

   private int lIIII(class_310 var1, class_2338 var2) {
      if (var1 != null && var1.field_1687 != null && var2 != null) {
         class_2680 var3 = var1.field_1687.method_8320(var2);
         return var3.method_27852(class_2246.field_23152) ? (Integer)var3.method_11654(class_4969.field_23153) : 0;
      } else {
         return 0;
      }
   }

   public boolean lIIIl() {
      return this.ll;
   }

   private boolean lIIll(float var1, double var2, double var4, float var6, double var7, double var9) {
      if (var1 < var6 - 0.001F) {
         return true;
      } else if (Math.abs(var1 - var6) > 0.001F) {
         return false;
      } else if (var2 < var7 - 1.0E-6) {
         return true;
      } else {
         return Math.abs(var2 - var7) <= 1.0E-6 && var4 < var9;
      }
   }

   public void lIlII(class_310 var1) {
      this.lIllI();
      this.IlIIIl();
   }

   private double lIlIl(class_310 var1, class_1297 var2) {
      if (var1 != null && var1.field_1724 != null && var2 != null) {
         class_243 var3 = var2.method_5829().method_1005();
         float[] var4 = IlIlIl.llIlI(var1, var3);
         if (var4 == null) {
            return (double)180.0F;
         } else {
            float var5 = class_3532.method_15393(var4[0] - var1.field_1724.method_36454());
            float var6 = var4[1] - var1.field_1724.method_36455();
            return Math.hypot((double)var5, (double)var6);
         }
      } else {
         return (double)180.0F;
      }
   }

   public void lIllI() {
      this.IlIll = IllIIl(-1693007977, 1085086372);
      this.IIlIl = null;
   }

   private class_243 lIlll(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         double var2 = (this.IIlII.IlII() + this.IIlII.IlI()) / (double)2.0F;
         double var6 = Math.max((double)1.0F, Math.min((double)10.0F, var2 / (double)50.0F));
         class_243 var8 = var1.field_1724.method_18798();
         class_243 var9 = new class_243(var1.field_1724.method_23317(), var1.field_1724.method_23318(), var1.field_1724.method_23321());
         return var9.method_1019(var8.method_1021(var6));
      } else {
         return class_243.field_1353;
      }
   }

   private boolean llIII(class_310 var1) {
      return var1 != null && var1.field_1724 != null && var1.field_1687 != null && this.Il != null && (this.Illll || this.IlIII) && !var1.field_1687.method_8320(this.Il).method_27852(class_2246.field_23152) && var1.field_1724.field_6012 <= this.llII;
   }

   private void llIIl(class_310 var1) {
      if (this.IIIIIlI() && this.llllI(var1) && this.Illl != null) {
         if (this.lIII.III() == null.Il) {
            <undefinedtype> var2 = this.IlIlIl(var1, this.Illl.I());
            if (var2 != null) {
               this.IlII = false;
               this.IIlII(var1, var2, this.lI);
            } else {
               this.IlIlI.IlIl(var1, this.Illl.l(), ((Double)this.IIII.III()).floatValue());
               if (System.currentTimeMillis() - this.IlI >= 1500L) {
                  this.Illl = null;
                  this.lI = -1;
                  this.IlII = false;
               }

            }
         } else {
            this.IIlII(var1, this.Illl, this.lI);
         }
      } else {
         this.Illl = null;
         this.lI = -1;
         this.IlII = false;
      }
   }

   private boolean llIlI(class_1799 var1) {
      return var1 == null || var1.method_7960() || !var1.method_31574(class_1802.field_8801);
   }

   private boolean llIll(class_310 var1, Object var2) {
      if (var2 == null) {
         return false;
      } else if (!this.Illll && !this.IlIII) {
         return this.IIlIIl(var1, this.IllII) != null;
      } else {
         class_3965 var3 = this.IIIIl(var1);
         return var3 != null && this.Il != null && this.Il.equals(var3.method_17777());
      }
   }

   private int lllII() {
      return Math.max(1, this.IlIII(this.IIlII) + 1);
   }

   private <undefinedtype> lllIl(class_310 var1) {
      Object var2;
      if (this.Illll) {
         <undefinedtype> var3 = this.IllIl(var1, this.Il);
         var2 = var3 != null ? var3 : this.IlIIll(this.Il);
      } else if (this.IlIII) {
         class_3965 var4 = this.IIIIl(var1);
         if (var4 != null && this.Il != null && this.Il.equals(var4.method_17777())) {
            var2 = new Record(this.Il.method_10062(), var4.method_17784(), var4) {
               private final class_2338 I;
               private final class_3965 l;
               private final class_243 II;

               public class_2338 I() {
                  return this.I;
               }

               private {
                  this.I = var1;
                  this.II = var2;
                  this.l = var3;
               }

               public class_243 l() {
                  return this.II;
               }

               public class_3965 II() {
                  return this.l;
               }
            };
         } else {
            var2 = this.IlIIll(this.Il);
         }
      } else {
         if (this.IIllI(var1, this.IllII)) {
            return null;
         }

         <undefinedtype> var5 = this.IIlIIl(var1, this.IllII);
         var2 = var5 != null ? var5 : this.IIllI;
      }

      return (<undefinedtype>)(this.IIlIII(var1, (<undefinedtype>)var2) ? var2 : null);
   }

   private boolean llllI(class_310 var1) {
      return var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var1.field_1755 == null && var1.field_1724.method_5805() && !lIlIllll.lIIl(var1);
   }

   private int lllll(class_310 var1) {
      for(int var2 = 0; var2 < IllIIl(-1693007978, 719553199); ++var2) {
         class_1799 var3 = var1.field_1724.method_31548().method_5438(var2);
         if (var3 != null && var3.method_31574(class_1802.field_8801)) {
            return var2;
         }
      }

      return -1;
   }

   private int IIIIIl(class_1657 var1, class_1792 var2) {
      for(int var3 = 0; var3 < IllIIl(-1693007975, -473654517); ++var3) {
         if (var1.method_31548().method_5438(var3).method_31574(var2)) {
            return var3;
         }
      }

      return -1;
   }

   static {
      short var6 = 21342;
      String var7 = "䮭䮣䮵䯤䯖䮄䬨䯱䬽䬃䬨䭧䬋䭨䬇䯐㞇㞌㞭㟸㟻㞀㝃㟪㜓㜭㜆㝉㜥㝆㜩㟾黑麡黯麪麭黂鹓麳鹠鹹鹐鸪鹶鸇鸗黐ⴾⵚⴈⵖⵄⴃⶕⵚⶪⶔ\u2dbfⷰ\u2d9cⷿⶐⵇ试识诩计讷诘譸讦譏證譍謋譤謝謤讹讙讣謓诤謿謣诧讏诙謁讋讓謻譯謏譸讋讆诨讷讁诱譏设濜澻濈澴澡濊潝澵潛潚潙潳潾漧漿澶澊澲漁澬\ued23\ued53\ued1d\ued58\ued5f\ued30\uedae\ued5c\uedb3\ued8b\uedba\uedd8\ued85\ued98\uedd4\ued54\ued77\ued3d\uedc5\ued3b\uedd7\uedb8\ued54\ued34\ued31\ueded\ued2c\ued67\ueddc\uedf3\uedf8\ued9b\ued39\ued48\ued26\ued5f\ued67\ued20\uede4\ued4d\uedc5\ued83\uedba\uedf6\ueda9\uedfa\uedff\ued45\ued67\ued52\uede6\ued3b\uedff\uedf1\ued74\ued30\ued0d\ueda9\ued19\ued79\uedf3\uedfb\uede5\ued9e\ued3f\ued2c\ued33\ued5f\ued02\ued0a\uedbe\ued43\ueda3\uedb1\ued9c\uede3\ued80\uedd8\uedf1\ued45\ued77\ued3d\uedc5\ued20\uedd4\uedb5\ued4c\ued07\ued20\uedd0\ued3c\ued7b\uedd1\uedaa\uedef\uedb5\ued3f\ued6e\ued18\ued49\ued69\ued0a\uede4\ued7d\uf87a\uf81d\uf86e\uf812\uf807\uf824\uf8e7\uf82e\uf8fe\uf8c5\uf8a4\uf8b6\uf8de\uf8a8\uf892\uf87fኣዐአዊዟኳርዞሰሎላበሀብቐኡꟈꞻ\ua7cbꞡꞴꟘꝆꞵꝛꝢ꜑꜅ꝭꜴꜼꞔ罨缞缞罥斛旔斾旘ⵘⴷⵗⴾ맅릏맧릩릹맿뤁릚륈륗륥뤄륫뤐뤘릝릕릅륤릱왕왛왁옿옪왬웄옾웒웽웨웱\uec6d\uec66\uec47\uec12\uec10\uec6a\uecec\uec00殓殺殺毁쒍쒆쒧쓲쓱쒊쑉쓠쐙쐧쐐쑲쐯쐲쑾쓾쓝쒗쑯쒑쑽쑜쒪쓁쯟쯔쯵쮠쮣쯘쬛쮲쭟쭆쬊쭿肶胑肢胞胋胨耫胱耴耙耧聉耔耈聙胭稆穢稯穩穸稨窮穯窂窽窔竛窧竡竦穤穑穂竄穵귭귣귵궖궕귀굴궭굮굕굂괣굌괳굏귬桗栩桿桚ꏺꏴꏢꎳꎁꏓꍿꎦꍪꍔꌠꌴꍝꍀꌴꏻ\ud8de\ud8a9\ud8be\ud8a2\ud8a6\ud8ca\ud848\ud8ba\ud85d\ud844\ud85c\ud825\ud87e\ud862\ud831\ud8d8験騺騺驁\ude0b\ude3b\ude4c\ude07\ude30\ude13\udeec\ude4f";
      char[] var8 = "华华华华卶半匶华华华博博博半卒卖博卆卒华半华博华华博卖".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            lIIlI = var9;
            lIIll = new Object[var9.length];
            int var2 = 522110532;
            byte[] var0 = "[_\u009e¼K>\u0015J9Â ñÅÊm¦Âmh\u0097í\u009b\u0015\u0098H9µ:\u0090ØÜ\u0090\u0016'9ÌÛ\u0003\u0092]Ó«'=µVD\"Ýà\u0016%\u0087¥ÜÙq_DÚýËrCÇþG>\u001f\u001d¹#O¤â$\n©\u009a<¡\u008aïYE\u0095\u0085¿D¥cw®ëûtgÌâß\u0088õ1¡>\u009aGl\\·FD²ÌõçW\u0084F\u0092\t\u0098\u0090\u0094\u001450Se¤ÈüÅ\u008bD\u0014kÊ<1Gá®\u001b\u009b¸\u0012\u0082AUÐ \u0019ûí\"Æ\u0080-q\u0019r%Ë¬¬xK?|\u001b6i,\u0088þ\u0013Æ\b£S\u0012K\u0087\u009c\n\u008db\u0084=\u0096h=\u009d\u009a\u0095".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lIIIl = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lIIIl[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            IlIIl = new class_2350[]{class_2350.field_11043, class_2350.field_11035, class_2350.field_11039, class_2350.field_11034};
            IIlI = lIlIII.l(IllIlI(-1441527387, -818260237));
            IIIII = lIlIII.l(IllIlI(-1441527390, 1774919120));
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private int IIIlII(llllIlIl var1) {
      return Math.max(0, (int)Math.ceil((double)this.IIIll(var1) / (double)50.0F));
   }

   public lIllIIII() {
      super((Object)lIlIII.l(IllIlI(-1441527389, 1838157396)), lIllII.I, (Object)lIlIII.l(IllIlI(-1441527392, -278182327)));
      IlIIIlIlI var10002 = new IlIIIlIlI(lIlIII.l(IllIlI(-1441527378, 283645493)), <undefinedtype>.class, null.II);
      lIIIIl var10003 = this.lIll;
      Objects.requireNonNull(var10003);
      this.lII = (IlIIIlIlI)this.IIIlIll((IlIIIlIlI)var10002.lIII(var10003::III));
      IIIllIIII var5 = (new IIIllIIII(lIlIII.l(IllIlI(-1441527377, -1518126281)), (double)8.0F, (double)2.0F, (double)15.0F, (double)0.5F)).IIIl(lIlIII.l(IllIlI(-1441527380, 2101164528)));
      var10003 = this.lIll;
      Objects.requireNonNull(var10003);
      this.IIIl = (IIIllIIII)this.IIIlIll((IIIllIIII)var5.lIII(var10003::III));
      this.IIl = (IIIllIIII)this.IIIlIll((IIIllIIII)(new IIIllIIII(lIlIII.l(IllIlI(-1441527379, 1741964492)), (double)180.0F, (double)10.0F, (double)180.0F, (double)5.0F)).IIIl(lIlIII.l(IllIlI(-1441527382, 789542761))).lIII(() -> false));
      this.lIII = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IllIlI(-1441527381, -1148364802)), <undefinedtype>.class, null.II));
      this.IIII = (IIIllIIII)this.IIIlIll((IIIllIIII)(new IIIllIIII(lIlIII.l(IllIlI(-1441527384, -1004728269)), (double)50.0F, (double)1.0F, (double)100.0F, (double)1.0F)).lIII(() -> this.lIII.III() == null.Il));
      this.IlIlI = new IlIlIll();
      this.lI = -1;
      this.lIlI = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IllIlI(-1441527383, -299797463)), (double)100.0F, (double)0.0F, (double)100.0F, (double)1.0F)).IIIl(lIlIII.l(IllIlI(-1441527370, 1771650486))));
      this.llIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IllIlI(-1441527369, -960398229)), true));
      this.IlIl = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(IllIlI(-1441527372, -913100094)), (double)1.0F, (double)1.0F, (double)4.0F, (double)1.0F));
      this.IIIIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IllIlI(-1441527371, -2097526485)), true));
      this.l = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IllIlI(-1441527374, 2018064060)), true));
      this.IIlII = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(IllIlI(-1441527373, -1348123474)), (double)0.0F, (double)0.0F, (double)0.0F, (double)300.0F, (double)5.0F)).Ill(lIlIII.l(IllIlI(-1441527376, 1778539952))));
      this.II = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IllIlI(-1441527375, -1582167218)), true));
      this.lll = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IllIlI(-1441527362, -628013037)), false));
      this.IlIll = IllIIl(-1693007976, -1929557891);
      this.lIIl = -1;
      this.I = -1;
      this.IllI = Long.MIN_VALUE;
      this.llII = IllIIl(-1693007973, 982662835);
      this.lIl = IllIIl(-1693007974, 1488928666);
      this.IlllI = new HashSet();
      this.llI = IllIIl(-1693007971, -1228633026);
      this.IIIll = IllIIl(-1693007972, 1401700170);
      IIIllIIII var10000 = this.IlIl;
      lIIIIl var10001 = this.llIl;
      Objects.requireNonNull(var10001);
      var10000.lIII(var10001::III);
      lIIIIl var1 = this.IIIIl;
      var10001 = this.llIl;
      Objects.requireNonNull(var10001);
      var1.lIII(var10001::III);
      var1 = this.l;
      var10001 = this.IIIIl;
      Objects.requireNonNull(var10001);
      var1.lIII(var10001::III);
   }

   public boolean IIIlIl() {
      return this.ll;
   }

   private int IIIllI(class_1657 var1) {
      for(int var2 = 0; var2 < IllIIl(-1693007969, -1919882938); ++var2) {
         if (this.llIlI(var1.method_31548().method_5438(var2))) {
            return var2;
         }
      }

      return -1;
   }

   public String Il() {
      long var10000 = Math.round((Double)this.lIlI.III());
      String var3 = lIlIII.Il(IllIlI(-1441527361, -196645521));
      long var1 = var10000;
      return var1 + var3;
   }

   private boolean IIlIII(class_310 var1, Object var2) {
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null && var2 != null) {
         double var3 = Math.max((double)0.0F, var1.field_1724.method_55754() - 0.1);
         class_243 var5 = var1.field_1724.method_33571();
         if (var5.method_1025(var2.l()) > var3 * var3) {
            return false;
         } else {
            class_243 var6 = class_243.method_24954(var2.II().method_17780().method_62675());
            class_243 var7 = var2.l().method_1020(var6.method_1021((double)0.03125F));
            class_3965 var8 = var1.field_1687.method_17742(new class_3959(var5, var7, class_3960.field_17559, class_242.field_1348, var1.field_1724));
            return var8 != null && var8.method_17783() == class_240.field_1332 && var8.method_17777().equals(var2.II().method_17777()) && var8.method_17780() == var2.II().method_17780();
         }
      } else {
         return false;
      }
   }

   private <undefinedtype> IIlIIl(class_310 var1, class_2338 var2) {
      class_3965 var3 = this.IIIIl(var1);
      if (var3 != null && var2 != null && var1 != null && var1.field_1687 != null) {
         if (!var1.field_1687.method_8320(var2).method_45474()) {
            return null;
         } else {
            class_2338 var4 = var3.method_17777();
            if (this.Il != null && var4.equals(this.Il)) {
               return null;
            } else {
               class_2338 var5 = var4.method_10093(var3.method_17780());
               if (var2.equals(var5) && this.II(var1, var4)) {
                  Record var6 = new Record(var2.method_10062(), var3.method_17784(), var3) {
                     private final class_2338 I;
                     private final class_3965 l;
                     private final class_243 II;

                     public class_2338 I() {
                        return this.I;
                     }

                     private {
                        this.I = var1;
                        this.II = var2;
                        this.l = var3;
                     }

                     public class_243 l() {
                        return this.II;
                     }

                     public class_3965 II() {
                        return this.l;
                     }
                  };
                  return this.IIlIII(var1, var6) ? var6 : null;
               } else {
                  return null;
               }
            }
         }
      } else {
         return null;
      }
   }

   private class_2338 IIlIlI(class_310 var1, class_1657 var2) {
      if (var1 != null && var1.field_1687 != null && var1.field_1724 != null && var2 != null) {
         double var3 = Math.max((double)0.0F, var1.field_1724.method_55754() - 0.1);
         double var5 = var3 * var3;
         class_243 var7 = var1.field_1724.method_33571();
         class_2338 var8 = var1.field_1724.method_24515();
         class_2338 var9 = null;
         float var10 = 0.0F;
         int var11 = (int)Math.ceil(var3);

         for(int var12 = -var11; var12 <= var11; ++var12) {
            for(int var13 = -var11; var13 <= var11; ++var13) {
               for(int var14 = -var11; var14 <= var11; ++var14) {
                  class_2338 var15 = var8.method_10069(var12, var13, var14);
                  if (!(var7.method_1025(class_243.method_24953(var15)) > var5)) {
                     class_2680 var16 = var1.field_1687.method_8320(var15);
                     if (var16.method_27852(class_2246.field_23152)) {
                        int var17 = (Integer)var16.method_11654(class_4969.field_23153);
                        if (var17 != 0 || (Boolean)this.llIl.III() && this.lllll(var1) >= 0) {
                           float var18 = llIlllll.l(var2, var15, (class_2338)null, var2.method_73189());
                           if (!(var18 <= 0.0F)) {
                              <undefinedtype> var19 = this.IlIll(var1, var15);
                              float var20 = var19 != null ? llIlllll.l(var1.field_1724, var15, var19.I(), this.lIlll(var1)) : llIlllll.l(var1.field_1724, var15, (class_2338)null, this.lIlll(var1));
                              if ((var19 != null || (Boolean)this.l.III()) && (!(var20 >= var18) || (Boolean)this.l.III()) && var18 > var10) {
                                 var10 = var18;
                                 var9 = var15;
                              }
                           }
                        }
                     }
                  }
               }
            }
         }

         return var9;
      } else {
         return null;
      }
   }

   private boolean IIlIll(class_310 var1, int var2) {
      return var1 != null && var1.field_1724 != null && var2 >= 0 && var2 < IllIIl(-1693007966, -1008085004) && var1.field_1724.method_31548().method_5438(var2).method_31574(class_1802.field_8801);
   }

   private class_1657 IIllII(class_310 var1) {
      if (var1 != null && var1.field_1687 != null && var1.field_1724 != null) {
         class_1657 var2 = null;
         Record var3 = null;
         double var4 = (Double)this.IIIl.III() * (Double)this.IIIl.III();

         for(class_1657 var7 : var1.field_1687.method_18456()) {
            if (this.IIII(var1, var7)) {
               double var8 = var1.field_1724.method_5858(var7);
               if (!(var8 > var4)) {
                  double var10 = Math.sqrt(var8);
                  double var12 = this.lIlIl(var1, var7);
                  if (!((Double)this.IIl.III() < (double)180.0F) || !(var12 > (Double)this.IIl.III() * (double)0.5F)) {
                     float var14 = var7.method_6032() + var7.method_6067();
                     Record var15 = new Record(var7, var10, var12, var14) {
                        private final double I;
                        private final double l;
                        private final float II;
                        private final class_1657 Il;

                        public double I() {
                           return this.l;
                        }

                        public class_1657 l() {
                           return this.Il;
                        }

                        private {
                           this.Il = var1;
                           this.l = var2;
                           this.I = var4;
                           this.II = var6;
                        }

                        public float II() {
                           return this.II;
                        }

                        public double Il() {
                           return this.I;
                        }
                     };
                     if (this.Illl(var15, var3)) {
                        var3 = var15;
                        var2 = var7;
                     }
                  }
               }
            }
         }

         return var2;
      } else {
         return null;
      }
   }

   private void IIllIl(class_310 var1, int var2, class_2338 var3) {
      if ((Boolean)this.lll.III() && var1 != null && var1.field_1724 != null) {
         int var4 = var1.field_1724.field_6012;
         if (this.IIIll == IllIIl(-1693007963, -1615828125) || var4 - this.IIIll >= IllIIl(-1693007964, -983717400)) {
            this.IIIll = var4;
            String var10000;
            if (var3 == null) {
               var10000 = "";
            } else {
               var10000 = lIlIII.Il(IllIlI(-1441527364, 815212799));
               String var7 = var3.method_23854();
               String var6 = var10000;
               var10000 = var6 + var7;
            }

            String var5 = var10000;
            PrintStream var12 = System.out;
            String var10 = IIIII.lIlI();
            var12.println(var10 + var2 + var5);
         }
      }
   }

   private int IIlllI(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         class_1799 var2 = var1.field_1724.method_6047();
         if (var2 != null && var2.method_31574(class_1802.field_23141)) {
            return IllllIlI.lIIlI(var1.field_1724.method_31548());
         } else {
            for(int var3 = 0; var3 < IllIIl(-1693007961, -1644981048); ++var3) {
               class_1799 var4 = var1.field_1724.method_31548().method_5438(var3);
               if (var4 != null && var4.method_31574(class_1802.field_23141)) {
                  return var3;
               }
            }

            return -1;
         }
      } else {
         return -1;
      }
   }

   private static double IIllll(class_243 var0, class_243 var1, class_243 var2) {
      double var3 = var2.field_1352 - var1.field_1352;
      double var5 = var2.field_1350 - var1.field_1350;
      double var7 = var3 * var3 + var5 * var5;
      if (var7 <= 1.0E-9) {
         double var20 = var0.field_1352 - var1.field_1352;
         double var21 = var0.field_1350 - var1.field_1350;
         return var20 * var20 + var21 * var21;
      } else {
         double var9 = ((var0.field_1352 - var1.field_1352) * var3 + (var0.field_1350 - var1.field_1350) * var5) / var7;
         var9 = Math.max((double)0.0F, Math.min((double)1.0F, var9));
         double var11 = var1.field_1352 + var3 * var9;
         double var13 = var1.field_1350 + var5 * var9;
         double var15 = var0.field_1352 - var11;
         double var17 = var0.field_1350 - var13;
         return var15 * var15 + var17 * var17;
      }
   }

   private <undefinedtype> IlIIII(class_310 var1, class_2338 var2, class_2338 var3, class_2350 var4) {
      if (var1 != null && var1.field_1687 != null && var1.field_1724 != null) {
         class_243 var5 = var1.field_1724.method_33571();
         class_243 var6 = class_243.method_24953(var3);
         class_243 var7 = var6.method_1019(class_243.method_24954(var4.method_62675()).method_1021((double)0.5F));
         class_243 var8 = var7.method_1020(class_243.method_24954(var4.method_62675()).method_1021(0.01));
         class_3965 var9 = var1.field_1687.method_17742(new class_3959(var5, var8, class_3960.field_17559, class_242.field_1348, var1.field_1724));
         if (var9 != null && var9.method_17783() == class_240.field_1332 && var9.method_17777().equals(var3) && var9.method_17780() == var4 && var2.equals(var3.method_10093(var9.method_17780()))) {
            return new Record(var2.method_10062(), var9.method_17784(), var9) {
               private final class_2338 I;
               private final class_3965 l;
               private final class_243 II;

               public class_2338 I() {
                  return this.I;
               }

               private {
                  this.I = var1;
                  this.II = var2;
                  this.l = var3;
               }

               public class_243 l() {
                  return this.II;
               }

               public class_3965 II() {
                  return this.l;
               }
            };
         } else {
            class_243 var10 = class_243.method_24954(var4.method_62675());
            class_243 var11;
            class_243 var12;
            if (var4.method_10166() == class_2351.field_11052) {
               var11 = new class_243((double)1.0F, (double)0.0F, (double)0.0F);
               var12 = new class_243((double)0.0F, (double)0.0F, (double)1.0F);
            } else if (var4.method_10166() == class_2351.field_11048) {
               var11 = new class_243((double)0.0F, (double)1.0F, (double)0.0F);
               var12 = new class_243((double)0.0F, (double)0.0F, (double)1.0F);
            } else {
               var11 = new class_243((double)1.0F, (double)0.0F, (double)0.0F);
               var12 = new class_243((double)0.0F, (double)1.0F, (double)0.0F);
            }

            class_243 var13 = var5.method_1020(var7);
            double var14 = class_3532.method_15350(var13.method_1026(var11) * (double)0.5F, -0.3, 0.3);
            double var16 = class_3532.method_15350(var13.method_1026(var12) * (double)0.5F, -0.3, 0.3);
            class_243[] var18 = new class_243[]{var11.method_1021(var14).method_1019(var12.method_1021(var16)), var11.method_1021((double)0.25F).method_1019(var12.method_1021((double)0.25F)), var11.method_1021((double)-0.25F).method_1019(var12.method_1021((double)0.25F)), var11.method_1021((double)0.25F).method_1019(var12.method_1021((double)-0.25F)), var11.method_1021((double)-0.25F).method_1019(var12.method_1021((double)-0.25F))};

            for(class_243 var22 : var18) {
               class_243 var23 = var7.method_1019(var22);
               class_243 var24 = var23.method_1020(var10.method_1021(0.01));
               class_3965 var25 = var1.field_1687.method_17742(new class_3959(var5, var24, class_3960.field_17559, class_242.field_1348, var1.field_1724));
               if (var25 != null && var25.method_17783() == class_240.field_1332 && var25.method_17777().equals(var3) && var25.method_17780() == var4 && var2.equals(var3.method_10093(var25.method_17780()))) {
                  return new Record(var2.method_10062(), var25.method_17784(), var25) {
                     private final class_2338 I;
                     private final class_3965 l;
                     private final class_243 II;

                     public class_2338 I() {
                        return this.I;
                     }

                     private {
                        this.I = var1;
                        this.II = var2;
                        this.l = var3;
                     }

                     public class_243 l() {
                        return this.II;
                     }

                     public class_3965 II() {
                        return this.l;
                     }
                  };
               }
            }

            return null;
         }
      } else {
         return null;
      }
   }

   public void lI() {
      this.lIllI();
      this.IlIIIl();
      this.ll = false;
      this.lIl = IllIIl(-1693007962, -1031252845);
      this.III = 0L;
      this.IlllI.clear();
      this.llll = null;
      this.llI = IllIIl(-1693007959, 494558246);
      this.Illl = null;
      this.lI = -1;
      this.IlIlI.IIIlIll();
   }

   public void IlIIIl() {
      class_310 var1 = class_310.method_1551();
      if (this.I >= 0 && this.I < IllIIl(-1693007960, 681836974) && var1 != null && var1.field_1724 != null) {
         if ((Boolean)this.II.III()) {
            IllllIlI.llIIlI(var1, this, this.I);
         } else {
            IllllIlI.IlII(var1, this, null.Il);
         }
      }

      this.Il = null;
      this.IllII = null;
      this.lIIl = -1;
      this.I = -1;
      this.IllI = Long.MIN_VALUE;
      this.llII = IllIIl(-1693007957, 997483225);
      this.Illll = false;
      this.Ill = 0;
      this.IlIII = false;
      this.IIllI = null;
      this.IIIlI = false;
      this.lIl = IllIIl(-1693007958, 1831137552);
      this.Illl = null;
      this.lI = -1;
      this.IlII = false;
   }

   private <undefinedtype> IlIIlI(class_310 var1, class_1657 var2) {
      if (var1 != null && var1.field_1687 != null && var1.field_1724 != null && var2 != null) {
         double var3 = Math.max((double)0.0F, var1.field_1724.method_55754() - 0.1);
         double var5 = var3 * var3;
         class_243 var7 = var1.field_1724.method_33571();
         class_2338 var8 = var2.method_24515();
         <undefinedtype> var9 = null;
         float var10 = Float.NEGATIVE_INFINITY;

         for(int var11 = IllIIl(-1693007955, 1748078263); var11 <= 3; ++var11) {
            for(int var12 = IllIIl(-1693007956, 686149009); var12 <= 2; ++var12) {
               for(int var13 = IllIIl(-1693007953, -402846860); var13 <= 3; ++var13) {
                  class_2338 var14 = var8.method_10069(var11, var12, var13);
                  if (!(var7.method_1025(class_243.method_24953(var14)) > var5) && var1.field_1687.method_8320(var14).method_45474() && !this.IIllI(var1, var14) && !this.l(var1, var14, var1.field_1724.method_73189())) {
                     <undefinedtype> var15 = this.IlIIl(var1, var14);
                     if (var15 != null && this.IIlIII(var1, var15)) {
                        float var16 = llIlllll.l(var2, var14, (class_2338)null, var2.method_73189());
                        <undefinedtype> var17 = this.IlIll(var1, var14);
                        float var18 = var17 != null ? llIlllll.l(var1.field_1724, var14, var17.I(), this.lIlll(var1)) : llIlllll.l(var1.field_1724, var14, (class_2338)null, this.lIlll(var1));
                        if ((var17 != null || (Boolean)this.l.III()) && (!(var18 >= var16) || (Boolean)this.l.III())) {
                           float var19 = var16 * 2.0F - var18;
                           if (var19 > var10) {
                              var10 = var19;
                              var9 = var15;
                           }
                        }
                     }
                  }
               }
            }
         }

         return var9;
      } else {
         return null;
      }
   }

   private <undefinedtype> IlIIll(class_2338 var1) {
      if (var1 == null) {
         return null;
      } else {
         class_310 var2 = class_310.method_1551();
         if (var2 != null && var2.field_1687 != null && var2.field_1724 != null) {
            class_3965 var3 = this.IIIIl(var2);
            if (var3 != null && var3.method_17777().equals(var1)) {
               Record var4 = new Record(var1.method_10062(), var3.method_17784(), var3) {
                  private final class_2338 I;
                  private final class_3965 l;
                  private final class_243 II;

                  public class_2338 I() {
                     return this.I;
                  }

                  private {
                     this.I = var1;
                     this.II = var2;
                     this.l = var3;
                  }

                  public class_243 l() {
                     return this.II;
                  }

                  public class_3965 II() {
                     return this.l;
                  }
               };
               if (this.IIlIII(var2, var4)) {
                  return var4;
               }
            }

            class_243 var14 = var2.field_1724.method_33571();
            class_243 var5 = class_243.method_24953(var1);

            for(class_2350 var9 : class_2350.values()) {
               class_243 var10 = var5.method_1019(class_243.method_24954(var9.method_62675()).method_1021((double)0.5F));
               class_243 var11 = var10.method_1020(class_243.method_24954(var9.method_62675()).method_1021(0.01));
               class_3965 var12 = var2.field_1687.method_17742(new class_3959(var14, var11, class_3960.field_17559, class_242.field_1348, var2.field_1724));
               if (var12 != null && var12.method_17783() == class_240.field_1332 && var12.method_17777().equals(var1)) {
                  Record var13 = new Record(var1.method_10062(), var12.method_17784(), var12) {
                     private final class_2338 I;
                     private final class_3965 l;
                     private final class_243 II;

                     public class_2338 I() {
                        return this.I;
                     }

                     private {
                        this.I = var1;
                        this.II = var2;
                        this.l = var3;
                     }

                     public class_243 l() {
                        return this.II;
                     }

                     public class_3965 II() {
                        return this.l;
                     }
                  };
                  if (this.IIlIII(var2, var13)) {
                     return var13;
                  }
               }
            }

            return null;
         } else {
            return null;
         }
      }
   }

   private <undefinedtype> IlIlIl(class_310 var1, class_2338 var2) {
      class_3965 var3 = this.IIIIl(var1);
      if (var3 != null && var2 != null && var1 != null && var1.field_1687 != null) {
         if (!var1.field_1687.method_8320(var2).method_45474()) {
            return null;
         } else {
            class_2338 var4 = var3.method_17777();
            class_2338 var5 = var4.method_10093(var3.method_17780());
            if (var2.equals(var5) && this.II(var1, var4)) {
               Record var6 = new Record(var2.method_10062(), var3.method_17784(), var3) {
                  private final class_2338 I;
                  private final class_3965 l;
                  private final class_243 II;

                  public class_2338 I() {
                     return this.I;
                  }

                  private {
                     this.I = var1;
                     this.II = var2;
                     this.l = var3;
                  }

                  public class_243 l() {
                     return this.II;
                  }

                  public class_3965 II() {
                     return this.l;
                  }
               };
               return this.IIlIII(var1, var6) ? var6 : null;
            } else {
               return null;
            }
         }
      } else {
         return null;
      }
   }

   private boolean IlIllI(class_310 var1, class_2338 var2) {
      return this.IlIlI(var1, var2) != null;
   }

   private int IlIlll(class_1657 var1, int var2) {
      int var3 = this.IIIIIl(var1, class_1802.field_8288);
      if (var3 != -1) {
         return var3;
      } else {
         class_1799 var4 = var1.method_31548().method_5438(var2);
         if (this.llIlI(var4)) {
            return var2;
         } else {
            int var5 = this.IIIIIl(var1, class_1802.field_23141);
            if (var5 != -1) {
               return var5;
            } else {
               int var6 = this.IIIllI(var1);
               return var6 != -1 ? var6 : var2;
            }
         }
      }
   }

   private void IllIII(class_310 var1, boolean var2) {
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null) {
         double var3 = Math.max((double)0.0F, var1.field_1724.method_55754() + (double)0.75F);
         double var5 = var3 * var3;
         int var7 = (int)Math.ceil(var3);
         class_243 var8 = var1.field_1724.method_33571();
         class_2338 var9 = var1.field_1724.method_24515();
         HashSet var10 = new HashSet();
         class_2338 var11 = null;
         double var12 = Double.POSITIVE_INFINITY;

         for(int var14 = -var7; var14 <= var7; ++var14) {
            for(int var15 = -var7; var15 <= var7; ++var15) {
               for(int var16 = -var7; var16 <= var7; ++var16) {
                  class_2338 var17 = var9.method_10069(var14, var15, var16);
                  double var18 = var8.method_1025(class_243.method_24953(var17));
                  if (!(var18 > var5) && var1.field_1687.method_8320(var17).method_27852(class_2246.field_23152)) {
                     long var20 = var17.method_10063();
                     var10.add(var20);
                     if (var2 && !this.IlllI.contains(var20) && var18 < var12) {
                        var11 = var17.method_10062();
                        var12 = var18;
                     }
                  }
               }
            }
         }

         this.IlllI.clear();
         this.IlllI.addAll(var10);
         boolean var22 = var11 != null && (this.llll == null || !this.llll.equals(var11) || this.llI == IllIIl(-1693007954, -2143948926) || var1.field_1724.field_6012 - this.llI >= IllIIl(-1693007951, -1181359256));
         if (var2 && var22 && this.IllII == null && this.Illl == null && this.IIlI()) {
            this.llll = var11.method_10062();
            this.llI = var1.field_1724.field_6012;
            this.lIllI();
            this.IlIl(var1, var11);
         }

      } else {
         this.IlllI.clear();
      }
   }

   private static int IllIIl(int var0, int var1) {
      return lIIIl[var0 ^ -1693007999] ^ var1 ^ var0;
   }

   private static String IllIlI(int var0, int var1) {
      int var3 = var0 ^ -1441527386;
      char[] var4 = lIIlI[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])lIIll[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         lIIll[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -286809139;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 20;
               break;
            case 1:
               var9 = 95;
               break;
            case 2:
               var9 = 51;
               break;
            case 3:
               var9 = 72;
               break;
            case 4:
               var9 = 119;
               break;
            case 5:
               var9 = 14;
               break;
            case 6:
               var9 = 144;
               break;
            case 7:
               var9 = 95;
               break;
            case 8:
               var9 = 176;
               break;
            case 9:
               var9 = 143;
               break;
            case 10:
               var9 = 137;
               break;
            case 11:
               var9 = 252;
               break;
            case 12:
               var9 = 129;
               break;
            case 13:
               var9 = 234;
               break;
            case 14:
               var9 = 250;
               break;
            case 15:
               var9 = 89;
               break;
            case 16:
               var9 = 118;
               break;
            case 17:
               var9 = 66;
               break;
            case 18:
               var9 = 249;
               break;
            case 19:
               var9 = 44;
               break;
            case 20:
               var9 = 252;
               break;
            case 21:
               var9 = 199;
               break;
            case 22:
               var9 = 123;
               break;
            case 23:
               var9 = 16;
               break;
            case 24:
               var9 = 32;
               break;
            case 25:
               var9 = 223;
               break;
            case 26:
               var9 = 29;
               break;
            case 27:
               var9 = 111;
               break;
            case 28:
               var9 = 194;
               break;
            case 29:
               var9 = 132;
               break;
            case 30:
               var9 = 232;
               break;
            case 31:
               var9 = 190;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
