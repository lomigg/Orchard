package x;

import com.sun.jna.platform.win32.BaseTSD;
import com.sun.jna.platform.win32.User32;
import com.sun.jna.platform.win32.WinDef;
import com.sun.jna.platform.win32.WinUser;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_3675.class_307;

@Environment(EnvType.CLIENT)
public final class IIllIlI {
   private static final boolean I;
   private static final int l = 2;
   private static final int II = 2;
   private static final int Il = 16;
   private static final int lI = 1;
   private static final int ll = 128;
   private static final int III = 8;
   private static final int IIl = 32;
   private static final int IlI = 4;
   private static final int Ill = 256;
   private static final int lII = 64;
   private static final int lIl = 0;
   private static final int[] llI;
   private static final String[] lll;
   private static final Object[] IIII;

   public static boolean I() {
      return I;
   }

   private static boolean l(int var0) {
      boolean var10000;
      switch (var0) {
         case 260:
         case 261:
         case 262:
         case 263:
         case 264:
         case 265:
         case 266:
         case 267:
         case 268:
         case 269:
         case 282:
         case 283:
         case 331:
         case 335:
         case 343:
         case 345:
         case 346:
         case 347:
         case 348:
            var10000 = true;
            break;
         default:
            var10000 = false;
      }

      return var10000;
   }

   private static <undefinedtype> II(int var0) {
      Record var10000;
      switch (var0) {
         case 0 -> var10000 = new Record(2, 4, 0) {
   private final int I;
   private final int l;
   private final int II;

   public int I() {
      return this.II;
   }

   public int l() {
      return this.l;
   }

   public int II() {
      return this.I;
   }

   private {
      this.l = var1;
      this.I = var2;
      this.II = var3;
   }
};
         case 1 -> var10000 = new Record(lIl(1234945533, 1539273736), lIl(1234945532, 1904493799), 0) {
   private final int I;
   private final int l;
   private final int II;

   public int I() {
      return this.II;
   }

   public int l() {
      return this.l;
   }

   public int II() {
      return this.I;
   }

   private {
      this.l = var1;
      this.I = var2;
      this.II = var3;
   }
};
         case 2 -> var10000 = new Record(lIl(1234945535, -1552176336), lIl(1234945534, 900176939), 0) {
   private final int I;
   private final int l;
   private final int II;

   public int I() {
      return this.II;
   }

   public int l() {
      return this.l;
   }

   public int II() {
      return this.I;
   }

   private {
      this.l = var1;
      this.I = var2;
      this.II = var3;
   }
};
         case 3 -> var10000 = new Record(lIl(1234945529, 1329149148), lIl(1234945528, 1891885489), 1) {
   private final int I;
   private final int l;
   private final int II;

   public int I() {
      return this.II;
   }

   public int l() {
      return this.l;
   }

   public int II() {
      return this.I;
   }

   private {
      this.l = var1;
      this.I = var2;
      this.II = var3;
   }
};
         case 4 -> var10000 = new Record(lIl(1234945531, 1141954686), lIl(1234945530, 406413265), 2) {
   private final int I;
   private final int l;
   private final int II;

   public int I() {
      return this.II;
   }

   public int l() {
      return this.l;
   }

   public int II() {
      return this.I;
   }

   private {
      this.l = var1;
      this.I = var2;
      this.II = var3;
   }
};
         default -> var10000 = null;
      }

      return var10000;
   }

   static {
      short var6 = 26601;
      String var7 = "먪몂멓멑먫멖멖멑먤먡몝몝ᬫᮂᮎ᭞ᬪᬳᬻᬾᬮ᭄ᮚᮚ";
      char[] var8 = "查查".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            lll = var9;
            IIII = new Object[var9.length];
            int var2 = -795964437;
            byte[] var0 = "Âª:\u0016è\u0091\nà:nå\u0004¬²Ò~Ö,zNéÖ®¢Ý\u0005\u0096î\u0081,\u0010ÀøJè`¤ò¶Õ\u008dç\nÙ\u0015¯I\u0083ëíÚ\u0018³¦Qê\u0018[Áè:\t9\u0086V\u00954\u009cXê]æN\u000bn%\u0080¢\u0014\u000e÷I\u001bV\u00ad\u0089[wÏû\u0084E\u001dú\u009e9Î\u007feÐ\u001et\u001ao¹\u001a\"öï'\u0011aF+[IÛ/3¤N\u0088Ê5\u0003j\u0082²§6îóÏ÷t1Ó8®\u0093Jw\u001b\u0085·9\"±-¥\u009dïUÅÈá¬Q`.h¨K¹í!Æ0c\u001d\r\u0010¿ò¦¹Ò,g'F\u0012\u0004b\u0081æk«¬ÜËÉÍ°\u0096ÿ}.\u001d|Õ\u0089¬Ù±¹\u001a\u009cü)}ò6eã<ª÷·v\u0086[å¤Å\u0003\u0092ó¾\rn\u0098\u008aK\u0007îÌ,^<ÃâÚ,ÎWùê¯\u0097Ô\u007f²@\u0015.êº*.\u0083\u0082ªÝ8é\u000f-ÿ|I\u0084".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            llI = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               llI[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            I = System.getProperty(lIlIII.Il(llI(-1612960803, 41811, '꾝')), "").toLowerCase().contains(lIlIII.Il(llI(27752792, 41810, '탧')));
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private IIllIlI() {
   }

   private static <undefinedtype> Il(class_3675.class_306 var0) {
      if (var0 != null && var0.method_1442() != class_307.field_1672) {
         int var1 = Ill(var0.method_1444());
         if (var1 < 0) {
            return null;
         } else {
            int var2 = User32.INSTANCE.MapVirtualKeyEx(var1, 0, User32.INSTANCE.GetKeyboardLayout(0));
            return var2 == 0 ? null : new Record(var2, l(var0.method_1444())) {
               private final int I;
               private final boolean l;

               private {
                  this.I = var1;
                  this.l = var2;
               }

               public int I() {
                  return this.I;
               }

               public boolean l() {
                  return this.l;
               }
            };
         }
      } else {
         return null;
      }
   }

   private static boolean lI(int var0, int var1) {
      WinUser.INPUT[] var2 = (WinUser.INPUT[])(new WinUser.INPUT()).toArray(1);
      IIl(var2[0], var0, var1);
      return User32.INSTANCE.SendInput(new WinDef.DWORD(1L), var2, var2[0].size()).intValue() == 1;
   }

   private static void ll(WinUser.INPUT var0, Object var1, boolean var2) {
      int var3 = lIl(1234945525, 1633658486);
      if (var1.l()) {
         var3 |= 1;
      }

      if (var2) {
         var3 |= 2;
      }

      var0.type = new WinDef.DWORD(1L);
      var0.input.setType(WinUser.KEYBDINPUT.class);
      var0.input.ki = new WinUser.KEYBDINPUT();
      var0.input.ki.wVk = new WinDef.WORD(0L);
      var0.input.ki.wScan = new WinDef.WORD((long)var1.I());
      var0.input.ki.dwFlags = new WinDef.DWORD((long)var3);
      var0.input.ki.time = new WinDef.DWORD(0L);
      var0.input.ki.dwExtraInfo = new BaseTSD.ULONG_PTR(0L);
      var0.write();
   }

   public static boolean III(class_310 var0, class_3675.class_306 var1, boolean var2, boolean var3) {
      if (I && var1 != null && (!var2 && var3 || IlI(var0))) {
         try {
            if (var1.method_1442() == class_307.field_1672) {
               <undefinedtype> var6 = II(var1.method_1444());
               return var6 == null ? false : lI(var2 ? var6.l() : var6.II(), var6.I());
            } else {
               <undefinedtype> var4 = Il(var1);
               return var4 != null && lII(var4, !var2);
            }
         } catch (Throwable var5) {
            return false;
         }
      } else {
         return false;
      }
   }

   private static void IIl(WinUser.INPUT var0, int var1, int var2) {
      var0.type = new WinDef.DWORD(0L);
      var0.input.setType(WinUser.MOUSEINPUT.class);
      var0.input.mi = new WinUser.MOUSEINPUT();
      var0.input.mi.dx = new WinDef.LONG(0L);
      var0.input.mi.dy = new WinDef.LONG(0L);
      var0.input.mi.mouseData = new WinDef.DWORD((long)var2);
      var0.input.mi.dwFlags = new WinDef.DWORD((long)var1);
      var0.input.mi.time = new WinDef.DWORD(0L);
      var0.input.mi.dwExtraInfo = new BaseTSD.ULONG_PTR(0L);
      var0.write();
   }

   private static boolean IlI(class_310 var0) {
      return I && var0 != null && var0.field_1755 == null && var0.method_1569() && var0.method_22683() != null;
   }

   private static int Ill(int var0) {
      if ((var0 < lIl(1234945524, 1038612730) || var0 > lIl(1234945527, 351421692)) && (var0 < lIl(1234945526, -1933965345) || var0 > lIl(1234945521, 1928893528))) {
         if (var0 >= lIl(1234945520, 716381907) && var0 <= lIl(1234945523, -2125558070)) {
            return lIl(1234945522, -1558415377) + var0 - lIl(1234945517, -813663304);
         } else if (var0 >= lIl(1234945516, -1040248159) && var0 <= lIl(1234945519, -685891224)) {
            return lIl(1234945518, 431446635) + var0 - lIl(1234945513, 1851544596);
         } else {
            int var10000;
            switch (var0) {
               case 32 -> var10000 = lIl(1234945512, 882644308);
               case 39 -> var10000 = lIl(1234945515, 1458490011);
               case 44 -> var10000 = lIl(1234945514, -2064658300);
               case 45 -> var10000 = lIl(1234945509, 1466575715);
               case 46 -> var10000 = lIl(1234945508, -2023664418);
               case 47 -> var10000 = lIl(1234945511, 537881669);
               case 59 -> var10000 = lIl(1234945510, 1983012822);
               case 61 -> var10000 = lIl(1234945505, -549579272);
               case 91 -> var10000 = lIl(1234945504, 1111129460);
               case 92 -> var10000 = lIl(1234945507, -677542687);
               case 93 -> var10000 = lIl(1234945506, -1702900634);
               case 96 -> var10000 = lIl(1234945501, 1042522117);
               case 256 -> var10000 = lIl(1234945500, 1457666589);
               case 257 -> var10000 = lIl(1234945503, 1244520618);
               case 258 -> var10000 = lIl(1234945502, -748530247);
               case 259 -> var10000 = lIl(1234945497, 774663307);
               case 260 -> var10000 = lIl(1234945496, -1263479823);
               case 261 -> var10000 = lIl(1234945499, -858749185);
               case 262 -> var10000 = lIl(1234945498, 893660728);
               case 263 -> var10000 = lIl(1234945493, -239270494);
               case 264 -> var10000 = lIl(1234945492, 1949599783);
               case 265 -> var10000 = lIl(1234945495, -100121846);
               case 266 -> var10000 = lIl(1234945494, 652732581);
               case 267 -> var10000 = lIl(1234945489, 1262037311);
               case 268 -> var10000 = lIl(1234945488, -553170307);
               case 269 -> var10000 = lIl(1234945491, 418588080);
               case 280 -> var10000 = lIl(1234945490, 902399460);
               case 281 -> var10000 = lIl(1234945485, 1420154952);
               case 282 -> var10000 = lIl(1234945484, -465873973);
               case 283 -> var10000 = lIl(1234945487, 1285350097);
               case 284 -> var10000 = lIl(1234945486, 682382506);
               case 330 -> var10000 = lIl(1234945481, 1698444222);
               case 331 -> var10000 = lIl(1234945480, -1351570064);
               case 332 -> var10000 = lIl(1234945483, 870512956);
               case 333 -> var10000 = lIl(1234945482, 525249512);
               case 334 -> var10000 = lIl(1234945477, 1545002166);
               case 335 -> var10000 = lIl(1234945476, 655892666);
               case 336 -> var10000 = lIl(1234945479, 324946297);
               case 340 -> var10000 = lIl(1234945478, 1429803185);
               case 341 -> var10000 = lIl(1234945473, 1526174884);
               case 342 -> var10000 = lIl(1234945472, 1463990117);
               case 343 -> var10000 = lIl(1234945475, 914528780);
               case 344 -> var10000 = lIl(1234945474, 727014310);
               case 345 -> var10000 = lIl(1234945469, 1940874459);
               case 346 -> var10000 = lIl(1234945468, 446161967);
               case 347 -> var10000 = lIl(1234945471, -1577303771);
               case 348 -> var10000 = lIl(1234945470, 1718159244);
               default -> var10000 = -1;
            }

            return var10000;
         }
      } else {
         return var0;
      }
   }

   private static boolean lII(Object var0, boolean var1) {
      WinUser.INPUT[] var2 = (WinUser.INPUT[])(new WinUser.INPUT()).toArray(1);
      ll(var2[0], var0, var1);
      return User32.INSTANCE.SendInput(new WinDef.DWORD(1L), var2, var2[0].size()).intValue() == 1;
   }

   private static int lIl(int var0, int var1) {
      return llI[var0 ^ 1234945533] ^ var1 ^ var0;
   }

   private static String llI(int var0, int var1, char var2) {
      int var3 = var1 ^ 'ꍓ';
      char[] var4 = lll[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])IIII[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         IIII[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 10881;
      int var9 = 0;

      do {
         int var10 = var4[var9] ^ 22249;
         var10 -= 59216;
         var10 -= 12767;
         var10 -= 13578;
         var10 += 46546;
         var4[var9] = (char)(var10 ^ var8 ^ var2 ^ var0 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
