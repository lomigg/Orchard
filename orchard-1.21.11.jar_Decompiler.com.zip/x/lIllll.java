package x;

import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_12125;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3966;
import net.minecraft.class_6880;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

@Environment(EnvType.CLIENT)
public final class lIllll extends IIIIIIIlI {
   private long I;
   private final lIIIIl l;
   private long II;
   private int Il;
   private <undefinedtype> lI;
   private final llllIlIl ll;
   private int III;
   private static final int IIl = 9;
   private static final class_1792[] IlI;
   private int Ill;
   private long lII;
   private <undefinedtype> lIl;
   private static String[] llI;
   private final llllIlIl lll;
   private final IIIllIIII IIII;
   private final lIIIIl IIIl;
   private static final long IIlI = 900L;
   private static final int[] IIll;
   private static final String[] IlII;
   private static final Object[] IlIl;

   private int ll(llllIlIl var1) {
      return Math.max(0, (int)Math.ceil((double)this.lII(var1) / (double)50.0F));
   }

   private void IlI() {
      this.lIl = null.l;
      this.lII = 0L;
      this.I = 0L;
      this.III = -1;
      this.Ill = -1;
      this.Il = -1;
      this.lI = null;
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (var1 != null && var1.field_1724 != null) {
         this.lll(var1);
      }

   }

   public void IllI(class_310 var1) {
      this.lll(var1);
   }

   private long lII(llllIlIl var1) {
      double var2 = var1.IlII();
      double var4 = var1.IlI();
      return var2 == var4 ? Math.max(0L, Math.round(var2)) : Math.max(0L, Math.round(ThreadLocalRandom.current().nextDouble(var2, var4)));
   }

   private class_1309 llI(class_310 var1) {
      if (var1 != null && var1.field_1687 != null && this.III >= 0) {
         class_1297 var2 = var1.field_1687.method_8469(this.III);
         if (var2 instanceof class_1309) {
            class_1309 var3 = (class_1309)var2;
            if (var3.method_5805() && var3 != var1.field_1724) {
               if (var1.field_1724.method_33571().method_1025(this.llII(var1.field_1724.method_33571(), var3.method_5829())) > this.IIllI() + 1.0E-4) {
                  return null;
               }

               return var3;
            }
         }

         return null;
      } else {
         return null;
      }
   }

   private void lll(class_310 var1) {
      long var2 = System.currentTimeMillis();
      if (this.lIl == null.l) {
         if ((Boolean)this.IIIl.III() && this.IIII(var1) && var2 - this.II >= this.lII(this.ll)) {
            class_1309 var5 = this.IIIll(var1);
            if (var5 != null && !IllllIlI.lllllI(var5) && !lIlIllll.lIIl(var1)) {
               this.lllI(var1, var5);
            }
         }

      } else if (!this.IIlll(var1)) {
         this.IlIl(true);
      } else {
         class_1309 var4 = this.llI(var1);
         if (var4 != null && !IllllIlI.lllllI(var4) && !lIlIllll.lIIl(var1)) {
            if (var2 - this.lII > 900L) {
               this.IlIl(true);
            } else if (this.lIl == null.II) {
               this.IlIII(var1, var4, var2);
            } else {
               if (this.lIl == null.lI) {
                  this.IIIII(var1, var4, var2);
               }

            }
         } else {
            this.IlIl(true);
         }
      }
   }

   private boolean IIII(class_310 var1) {
      return this.IIlllll() && IllllIlI.IlIII(var1, this.IIIlIII());
   }

   private int IIll(class_1661 var1) {
      if (var1 == null) {
         return -1;
      } else {
         int var2 = IllllIlI.lIIlI(var1);
         int var3 = -1;
         int var4 = IlIll(2133552781, -1917723925);

         for(class_1792 var8 : IlI) {
            for(int var9 = 0; var9 < IlIll(2133552780, 611766039); ++var9) {
               class_1799 var12 = var1.method_5438(var9);
               int var10;
               if (var12 != null && var12.method_31574(var8) && (var10 = this.lIIl(var12) * IlIll(2133552783, 628104019) + (var9 == var2 ? 1 : 0)) > var4) {
                  var4 = var10;
                  var3 = var9;
               }
            }
         }

         return var3;
      }
   }

   public boolean IlII() {
      return this.lIl != null.l;
   }

   public void lIlI(class_1297 var1) {
      class_310 var2 = class_310.method_1551();
      if (this.IlIIl(var2, var1)) {
         this.lllI(var2, (class_1309)var1);
      }
   }

   private void IlIl(boolean var1) {
      class_310 var2 = class_310.method_1551();
      boolean var3 = var1 && var2 != null && var2.field_1724 != null && ((Boolean)this.IIIl.III() || (Boolean)this.l.III()) && this.Il >= 0 && this.Il < IlIll(2133552782, 990854209) && this.Il != IllllIlI.lIIlI(var2.field_1724.method_31548());
      if (var3) {
         IllllIlI.llIIlI(var2, this, this.Il);
      } else {
         IllllIlI.IlII(var2, this, null.Il);
      }

      this.IlI();
   }

   public void lI() {
      this.IlIl(true);
   }

   public boolean IIlI(class_310 var1) {
      return this.IlII();
   }

   private static double lIII(double var0, double var2, double var4) {
      return Math.max(var2, Math.min(var4, var0));
   }

   private int lIIl(class_1799 var1) {
      if (var1 != null && !var1.method_7960()) {
         class_9304 var2 = (class_9304)var1.method_58695(class_9334.field_49633, class_9304.field_49385);

         for(class_6880 var4 : var2.method_57534()) {
            String var5 = (String)var4.method_40230().map((var0) -> var0.method_29177().method_12832()).orElse(llI[IlIll(2133552777, -1155657102)]);
            if (lIlIII.Il(llI[IlIll(2133552776, 2048604363)]).equals(var5)) {
               return var2.method_57536(var4);
            }
         }

         return 0;
      } else {
         return 0;
      }
   }

   private class_243 llII(class_243 var1, class_238 var2) {
      return new class_243(lIII(var1.field_1352, var2.field_1323, var2.field_1320), lIII(var1.field_1351, var2.field_1322, var2.field_1325), lIII(var1.field_1350, var2.field_1321, var2.field_1324));
   }

   private void lllI(class_310 var1, class_1309 var2) {
      int var3 = this.IIll(var1.field_1724.method_31548());
      if (var3 >= 0) {
         long var4 = System.currentTimeMillis();
         this.Il = IllllIlI.IIlIl(var1);
         this.Ill = var3;
         this.III = var2.method_5628();
         boolean var6 = IllllIlI.IIlIl(var1) != this.Ill;
         int var7 = var6 ? this.ll(this.lll) : 0;
         this.lI = IllllIlI.lIll(var1, this, this.Ill, var7, true);
         if (this.lI != null && this.lI.III()) {
            this.lIl = null.II;
            this.lII = var4;
            this.I = var4 + this.lII(this.lll);
         } else {
            this.IlIl(false);
         }
      }
   }

   private void IIIII(class_310 var1, class_1309 var2, long var3) {
      if (var3 >= this.I) {
         class_1799 var5 = var1.field_1724.method_31548().method_5438(this.Ill);
         if (var5.method_7960()) {
            this.IlIl(true);
         } else {
            class_12125 var6 = (class_12125)var5.method_58694(class_9334.field_63631);
            if (var6 == null) {
               this.IlIl(true);
            } else if (!var1.field_1724.method_75202(var5, 5)) {
               var1.field_1761.method_75407(var6);
               var1.field_1724.method_6104(class_1268.field_5808);
               this.II = var3;
               boolean var7 = ((Boolean)this.IIIl.III() || (Boolean)this.l.III()) && this.Il >= 0 && this.Il < IlIll(2133552779, -963751751) && this.Il != this.Ill;
               if (var7) {
                  IllllIlI.llIIlI(var1, this, this.Il);
                  this.IlI();
               } else {
                  this.IlIl(true);
               }

            }
         }
      }
   }

   private static void IIIIl() {
      llI[0] = IIlIl(IllII(-26367975, 439515703).toCharArray(), 1524L, IlIll(2133552778, -1831124273));
      llI[1] = IIlIl(IllII(-26367976, -201955401).toCharArray(), 40245L, IlIll(2133552773, -519789286));
      llI[2] = IIlIl(IllII(-26367973, 407514675).toCharArray(), 42581L, IlIll(2133552772, 1739876570));
      llI[3] = IIlIl(IllII(-26367974, -426420337).toCharArray(), 44526L, IlIll(2133552775, 1861451693));
      llI[4] = IIlIl(IllII(-26367971, -1475267986).toCharArray(), 67116L, IlIll(2133552774, -267153813));
      llI[5] = IIlIl(IllII(-26367972, 1968859470).toCharArray(), 14912L, IlIll(2133552769, 697540410));
      llI[IlIll(2133552768, 172702240)] = IIlIl(IllII(-26367969, 608398870).toCharArray(), 34996L, IlIll(2133552771, 366425074));
      llI[IlIll(2133552770, -495116207)] = IIlIl(IllII(-26367970, -458994269).toCharArray(), 11797L, IlIll(2133552797, 280424195));
      llI[IlIll(2133552796, 731327309)] = IIlIl(IllII(-26367983, -171348819).toCharArray(), 26888L, IlIll(2133552799, 280255071));
      llI[IlIll(2133552798, -702296126)] = IIlIl("".toCharArray(), 60548L, IlIll(2133552793, 1784376132));
      llI[IlIll(2133552792, -1097503081)] = IIlIl(IllII(-26367984, 157098298).toCharArray(), 76410L, IlIll(2133552795, 1926886518));
   }

   private class_1309 IIIll(class_310 var1) {
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null) {
         class_239 var2 = var1.field_1765;
         if (var2 instanceof class_3966) {
            class_3966 var3 = (class_3966)var2;
            class_1297 var5 = var3.method_17782();
            if (var5 instanceof class_1309) {
               class_1309 var4 = (class_1309)var5;
               if (var4.method_5805() && var4 != var1.field_1724 && var1.field_1724.method_33571().method_1025(var3.method_17784()) <= this.IIllI() + 1.0E-4) {
                  return var4;
               }
            }
         }

         return null;
      } else {
         return null;
      }
   }

   static {
      short var6 = 22299;
      String var7 = "鬁⚷揵伝㽶仄혀냾뵝મ逖숰㍬\ue971씰胖騷禓\udc57罁豤᮵텻\uda4f\ue249唄⍠᪷\ue0bd\uda40\uf5f3勚遫㧇ģ煮ꫭ聈䮋䑚Ü껈鑪\uef16岵䏮놰铞䨂㾬嚻⟱\u181f⦥횮㢅崞﹛\ue7d8櫍⧠섗⫕丸茀풚伱㝲ኣ\uefa0숕꘠뇽ᇇ䃇\uec63䦆鳢ගꎋ\ue59d櫊ﾥ봞ꍚ냹擈犦푒샌䅏攛㒞\uebb5\uddda命햌葸닫\ueb23Ṇ鰓㞮\uf44aꤔ\u0a12魟苫\ue970榥㶘庶喇몕覘ꍖ葻ꢇ瑳먧姟Ḯऍꅆ뿇䋭\udbd9\uf7fb꒥뾅凳ꑄ\ue911쳊餲宏⚏ṑᅧ㜷슆\udcb0㚬\ue07b榐\ue7da킰ሶ蠴\udd94歋\ued68废㢘⢿癶\ud8e4﨔侏덼";
      char[] var8 = "土圗土國圗圗圓坟國圓".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IlII = var9;
            IlIl = new Object[var9.length];
            int var2 = -917844479;
            byte[] var0 = "»Ðzg\u0092\u0017o\u0093\u0093\u0011»¹\u008dn\u009cÇ\r\u007f²óÌz\u0098Hpïð:\u0090¢ÛÖ4ÖF\u000bæCëÈ«\u001bBvYwødk\u008co´¼*\u009a§\r[Æ-T\u001c\u0080Õ,î®u\u009dö\u008bØÂ\u008bòÃ`BoT¾5\u00ad6\bôÎ\u0004ò\u0000ëc7\u001d\u008d÷\u0094?¬ÛêýÊ\u0019\u0080}/b\u001aþ?ÞTÅLZe¹W\u0096Ë\u0093 Ù".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IIll = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IIll[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            llI = new String[IlIll(2133552794, -2122568345)];
            IIIIl();
            class_1792[] var10000 = new class_1792[IlIll(2133552789, 576588872)];
            var10000[0] = class_1802.field_63390;
            var10000[1] = class_1802.field_63389;
            var10000[2] = class_1802.field_63387;
            var10000[3] = class_1802.field_63386;
            var10000[4] = class_1802.field_63388;
            var10000[5] = class_1802.field_63385;
            var10000[IlIll(2133552788, 1553754762)] = class_1802.field_63384;
            IlI = var10000;
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public boolean IIIIIIl() {
      return true;
   }

   private static String IIlIl(char[] var0, long var1, int var3) {
      int var4 = IlIll(2133552791, -1484260482) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IlIll(2133552790, -1398825034);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private double IIllI() {
      double var1 = Math.max((double)1.0F, (Double)this.IIII.III());
      return var1 * var1;
   }

   private boolean IIlll(class_310 var1) {
      return var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var1.field_1690 != null && var1.field_1755 == null && var1.field_1724.method_5805();
   }

   public void lIl() {
      this.IlIl(false);
   }

   private void IlIII(class_310 var1, class_1309 var2, long var3) {
      if (!IllllIlI.IIII(var1, this.lI)) {
         this.IlIl(true);
      } else if (IllllIlI.IlIllII(var1, this.lI) && IllllIlI.IIlIIlI(var1, this.Ill) && var3 >= this.I) {
         this.lIl = null.lI;
         this.lII = var3;
         this.I = var3 + this.lII(this.ll);
         this.IIIII(var1, var2, var3);
      }
   }

   private boolean IlIIl(class_310 var1, class_1297 var2) {
      if (this.IIIIIlI() && var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var1.field_1755 == null && var2 != null && var2 != var1.field_1724 && var2 instanceof class_1309 var3) {
         if (var3.method_5805() && !IllllIlI.lllllI(var3) && this.lIl == null.l && !lIlIllll.lIIl(var1)) {
            return this.IIll(var1.field_1724.method_31548()) >= 0;
         }
      }

      return false;
   }

   public lIllll() {
      super((Object)lIlIII.l(llI[1]), lIllII.I, (Object)lIlIII.l(llI[IlIll(2133552785, -492507955)]), false);
      this.IIIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(llI[4]), false));
      this.lll = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(llI[IlIll(2133552784, -740755697)]), (double)55.0F, (double)60.0F, (double)0.0F, (double)300.0F, (double)5.0F)).IIII(lIlIII.Il(llI[0])));
      this.ll = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(llI[5]), (double)0.0F, (double)0.0F, (double)0.0F, (double)300.0F, (double)5.0F)).IIII(lIlIII.Il(llI[0])));
      this.IIII = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(llI[IlIll(2133552787, 2113011789)]), (double)4.0F, (double)1.0F, (double)6.0F, 0.05)).IIl(lIlIII.Il(llI[2])));
      this.l = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(llI[3]), true));
      this.lIl = null.l;
      this.III = -1;
      this.Ill = -1;
      this.Il = -1;
      this.lI = null;
      this.II = 0L;
      this.l.lIII(() -> !(Boolean)this.IIIl.III());
   }

   private static int IlIll(int var0, int var1) {
      return IIll[var0 ^ 2133552781] ^ var1 ^ var0;
   }

   private static String IllII(int var0, int var1) {
      int var3 = var0 ^ -26367975;
      char[] var4 = IlII[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IlIl[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IlIl[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -1681691829;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 50;
               break;
            case 1:
               var9 = 82;
               break;
            case 2:
               var9 = 173;
               break;
            case 3:
               var9 = 202;
               break;
            case 4:
               var9 = 10;
               break;
            case 5:
               var9 = 213;
               break;
            case 6:
               var9 = 96;
               break;
            case 7:
               var9 = 224;
               break;
            case 8:
               var9 = 23;
               break;
            case 9:
               var9 = 205;
               break;
            case 10:
               var9 = 253;
               break;
            case 11:
               var9 = 96;
               break;
            case 12:
               var9 = 35;
               break;
            case 13:
               var9 = 203;
               break;
            case 14:
               var9 = 250;
               break;
            case 15:
               var9 = 220;
               break;
            case 16:
               var9 = 165;
               break;
            case 17:
               var9 = 57;
               break;
            case 18:
               var9 = 44;
               break;
            case 19:
               var9 = 216;
               break;
            case 20:
               var9 = 137;
               break;
            case 21:
               var9 = 228;
               break;
            case 22:
               var9 = 205;
               break;
            case 23:
               var9 = 125;
               break;
            case 24:
               var9 = 181;
               break;
            case 25:
               var9 = 29;
               break;
            case 26:
               var9 = 53;
               break;
            case 27:
               var9 = 183;
               break;
            case 28:
               var9 = 141;
               break;
            case 29:
               var9 = 169;
               break;
            case 30:
               var9 = 1;
               break;
            case 31:
               var9 = 56;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
