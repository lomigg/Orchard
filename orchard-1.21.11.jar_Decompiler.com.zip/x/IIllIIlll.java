package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

@Environment(EnvType.CLIENT)
public final class IIllIIlll extends IIIIIIIlI implements llIlIIII {
   private static final <undefinedtype> I;
   private static final double l = 0.62;
   private static final double II = -0.36;
   private static final double Il = 1.8;
   private static final int lI = 1000;
   private static final double ll = (double)30.0F;
   private static final <undefinedtype> III;
   private static final <undefinedtype> IIl;
   private final IIIllIIII IlI = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(llII(-1204388767, 60518, (short)'\ue664')), (double)16.0F, (double)0.0F, (double)4000.0F, (double)1.0F)).IIIl(lIlIII.l(llII(1164252870, 60519, (short)'\ue906'))));
   private static final double Ill = 0.3;
   private static final double lII = (double)4.0F;
   private final IIIllIIII lIl = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(llII(2023370007, 60512, (short)'鮕')), (double)155.0F, (double)75.0F, (double)300.0F, (double)5.0F)).IIIl(lIlIII.l(llII(-1393351464, 60513, (short)11150))));
   private static final <undefinedtype> llI;
   private static final int lll = -1513240;
   private static final <undefinedtype> IIII;
   private final IIIllIIII IIIl = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(llII(1059605522, 60516, (short)16115)), (double)16.0F, (double)0.0F, (double)4000.0F, (double)1.0F)).IIIl(lIlIII.l(llII(-511030354, 60517, (short)1413))));
   private static final <undefinedtype> IIlI;
   private static final int[] IIll;
   private static final String[] IlII;
   private static final Object[] IlIl;

   static {
      short var6 = 14451;
      String var7 = "\udaec\udb31\uda24\udb09\udaba\udae2\udb49\udb79懰愅愱慘憺愕愋愱慕慒戫愨愫戏憽愌愫懗慆慄戦愨懌慯慒懷懶愭慔憴懯愖懅憿慀愽愔愤慟慅戦愅懊戈蝳薤蚨藧蜤蚃蚊蚾蜲蛟薬薹ᶡίẵỗ᷵ẚẩ᷽ỔọẃẒẲἳἱάẄ᷼ἵἣὫẜὂᶌ Ⅹ’₽\u206c\u200c⃦⃐驏驐驺驱騘騣騷騇驡驱驃驖騕饁騗驝쉋섛숊숋숑숪쉘쉟쉿쉽섏쉩婴墡妺娲始妕婶妦姕姒妆妅妦壥姟妍妗妜姪姩妜墦妝姜姆妐墦妳姓墏墬墹ꏱꌚꐆꑲﶣ\ufdd6ﶈＦ啪咝叹厍䚿䚊䚴䖚«ɺ\u0085\u009föú¸ɒ\u1cfbᶌ᳠Ე";
      char[] var8 = "㡻㡟㡿㡫㡻㡣㡿㡓㡷㡷㡷㡷㡻㡷".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IlII = var9;
            IlIl = new Object[var9.length];
            int var2 = 696387466;
            byte[] var0 = "àz\u0016ýö<Ìbó?\u001c(".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IIll = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IIll[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            IIlI = lIlIII.l(llII(483883227, 60524, (short)'쑍'));
            III = lIlIII.l(llII(-355857056, 60525, (short)18771));
            I = lIlIII.l(llII(-585017320, 60526, (short)20779));
            IIl = lIlIII.l(llII(-709030043, 60527, (short)'놠'));
            llI = lIlIII.l(llII(1705666392, 60520, (short)1813));
            IIII = lIlIII.l(llII(-1787155712, 60521, (short)28305));
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 96;
                     break;
                  case 1:
                     var10000 = 117;
                     break;
                  case 2:
                     var10000 = 69;
                     break;
                  case 3:
                     var10000 = 49;
                     break;
                  case 4:
                     var10000 = 55;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public void IIl(class_332 var1, int var2, int var3, float var4) {
      this.IIll(var1, false);
   }

   private static class_2960 ll(Object var0) {
      return class_2960.method_60655(IIlI.lIlI(), var0.lIlI());
   }

   public double llll() {
      return this.IIII() * this.lII();
   }

   private static double IlI(class_327 var0, String var1) {
      return lll(var0, var1, llI);
   }

   private double lII() {
      return (Double)this.lIl.III() / (double)100.0F;
   }

   private double llI() {
      return (double)38.0F;
   }

   private static double lll(class_327 var0, String var1, Object var2) {
      int var3 = lIIIlIIl.I(var2, var1);
      return var3 >= 0 ? (double)var3 : (var0 == null ? (double)48.0F : (double)var0.method_1727(var1));
   }

   private double IIII() {
      class_310 var1 = class_310.method_1551();
      class_327 var2 = var1 == null ? null : var1.field_1772;
      double var3 = lll(var2, I.lIlI(), llI) * 1.8 + Math.abs(-0.36) * (double)9.0F * 1.8;
      double var5 = lll(var2, IIl.lIlI(), IIII) * 0.62;
      return (double)40.0F + Math.max(var3, var5);
   }

   private void IIll(class_332 var1, boolean var2) {
      double var3 = this.Il();
      double var5 = this.Ill();
      double var7 = this.lII();
      double var9 = (double)30.0F;
      double var11 = (double)2.0F;
      double var13 = (double)4.0F;
      double var15 = (double)4.0F;
      double var17 = var13 + var9 + var11;
      class_310 var19 = class_310.method_1551();
      class_327 var20 = var19 == null ? null : var19.field_1772;
      String var21 = I.lIlI();
      String var22 = IIl.lIlI();
      double var23 = lll(var20, var21, llI) * 1.8;
      double var25 = lll(var20, var22, IIII) * 0.62;
      Math.max(var23, var25);
      double var33 = 16.2;
      double var35 = 5.58;
      double var37 = var33 + 0.3 + var35;
      double var39 = var15 + (var9 - var37) * (double)0.5F;
      double var41 = var39 + var33 + 0.3;
      IIIIIIllI.IIIllI(var1);
      IIIIIIllI.IlII(var1, var3, var5);
      IIIIIIllI.lllI(var1, var7, var7);
      IIIIIIllI.lIIIII(var1, ll(III), var13, var15, var9, var9, lIII(-365268249, 599941240), lIII(-365268250, 897891046));
      if (var20 != null) {
         IlIl(var1, var20, var21, var17, var39, 1.8, -0.36, llI, -1);
         IlII(var1, var20, var22, var17, var41, 0.62, IIII, lIII(-365268251, -814775889), true);
      }

      IIIIIIllI.lIIlIl(var1);
   }

   public IIllIIlll(lIIIllll var1) {
      super((Object)lIlIII.l(llII(-1679817642, 60522, (short)'롌')), lIllII.IIl, (Object)lIlIII.l(llII(-415733009, 60523, (short)'뱺')));
      this.IIIllIl(true);
   }

   public void III(class_332 var1, int var2, int var3, float var4, boolean var5) {
      this.IIll(var1, var5);
   }

   private static void IlII(class_332 var0, class_327 var1, String var2, double var3, double var5, double var7, Object var9, int var10, boolean var11) {
      boolean var12 = var11 && lIIIllll.IllIl();
      IIIIIIllI.IIIllI(var0);
      IIIIIIllI.IlII(var0, var3, var5);
      IIIIIIllI.lllI(var0, var7, var7);
      if (!lIIIlIIl.lI(var9, var0, var2, (double)0.0F, (double)0.0F, var10, false, var12)) {
         if (var12) {
            IIIIIIllI.IlIIll(true, () -> IIIIIIllI.llIl(var0, var1, var2, (double)0.0F, (double)0.0F, var10));
         } else {
            IIIIIIllI.llIl(var0, var1, var2, (double)0.0F, (double)0.0F, var10);
         }
      }

      IIIIIIllI.lIIlIl(var0);
   }

   private static void IlIl(class_332 var0, class_327 var1, String var2, double var3, double var5, double var7, double var9, Object var11, int var12) {
      IIIIIIllI.IIIllI(var0);
      IIIIIIllI.IlII(var0, var3, var5);
      IIIIIIllI.lllI(var0, var7, var7);
      if (var9 != (double)0.0F) {
         IIIIIIllI.lIIlII(var0, var9, (double)0.0F);
      }

      if (!lIIIlIIl.lI(var11, var0, var2, (double)0.0F, (double)0.0F, var12, false, false)) {
         IIIIIIllI.llIl(var0, var1, var2, (double)0.0F, (double)0.0F, var12);
      }

      IIIIIIllI.lIIlIl(var0);
   }

   public boolean IIlI(double var1, double var3) {
      return var1 >= this.Il() && var1 <= this.Il() + this.llll() && var3 >= this.Ill() && var3 <= this.Ill() + this.lIIl();
   }

   public void lIlI(double var1, double var3) {
      double var5 = Double.MAX_VALUE;
      double var7 = Double.MAX_VALUE;
      class_310 var9 = class_310.method_1551();
      if (var9 != null && var9.method_22683() != null) {
         var5 = Math.max((double)0.0F, (double)var9.method_22683().method_4486() - this.llll());
         var7 = Math.max((double)0.0F, (double)var9.method_22683().method_4502() - this.lIIl());
      }

      this.IIIl.III(Math.max((double)0.0F, Math.min(var1, var5)));
      this.IlI.III(Math.max((double)0.0F, Math.min(var3, var7)));
   }

   public double Ill() {
      return (Double)this.IlI.III();
   }

   public double lIIl() {
      return this.llI() * this.lII();
   }

   public void IIIlI(class_332 var1, int var2, int var3, float var4) {
      this.IIll(var1, false);
   }

   public double Il() {
      return (Double)this.IIIl.III();
   }

   private static int lIII(int var0, int var1) {
      return IIll[var0 ^ -365268249] ^ var1 ^ var0;
   }

   private static String llII(int var0, int var1, short var2) {
      int var3 = var1 ^ '\uec6c';
      char[] var4 = IlII[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])IlIl[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         IlIl[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 28993;
      int var9 = 0;

      do {
         int var10 = var4[var9] - '蔛';
         var10 += 8123;
         var10 -= 50424;
         var10 ^= 61280;
         var10 += 8639;
         var4[var9] = (char)(var10 ^ var8 ^ var2 ^ var0 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
