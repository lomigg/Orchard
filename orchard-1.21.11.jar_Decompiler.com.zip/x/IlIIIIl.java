package x;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1722;
import net.minecraft.class_1733;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2480;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_746;
import net.minecraft.class_9334;
import net.minecraft.class_239.class_240;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;

@Environment(EnvType.CLIENT)
public final class IlIIIIl extends IIIIIIIlI {
   private long I;
   private final lIIIIl l;
   private long II;
   private final llllIlIl Il;
   private boolean lI;
   private final Map<Integer, <undefinedtype>> ll;
   private final lIIIIl III;
   private boolean IIl;
   private class_2338 IlI;
   private long Ill;
   private final lIIIIl lII;
   private static final int lIl = 8;
   private static final long llI = 1000L;
   private static String[] lll;
   private final lIIIIl IIII;
   private static final double IIIl = (double)20.25F;
   private static final double IIlI = 1.0E-4;
   private int IIll;
   private int IlII;
   private int IlIl;
   private final Set<class_2338> IllI;
   private long Illl;
   private static final int[] lIII;
   private static final String[] lIIl;
   private static final Object[] lIlI;

   private <undefinedtype> ll(class_310 var1, class_1703 var2, int var3) {
      ArrayList var4 = new ArrayList();
      int var5 = 0;
      int var6 = Math.min(var3, var2.field_7761.size());

      for(int var7 = 0; var7 < var6; ++var7) {
         class_1735 var8 = (class_1735)var2.field_7761.get(var7);
         if (var8 != null && var8.field_7874 >= 0 && var8.method_7681() && var8.method_7674(var1.field_1724)) {
            class_1799 var9 = var8.method_7677();
            if (var9 != null && !var9.method_7960() && !this.lIII(var1, var9) && (!(Boolean)this.IIII.III() || this.IlllI(var9))) {
               ++var5;
               if (!this.ll.containsKey(var8.field_7874)) {
                  var4.add(var8.field_7874);
               }
            }
         }
      }

      return new Record(var4, var5) {
         private final List<Integer> I;
         private final int l;

         public List<Integer> I() {
            return this.I;
         }

         public int l() {
            return this.l;
         }

         boolean II() {
            return this.l > 0;
         }

         int Il() {
            return (Integer)this.I.get(ThreadLocalRandom.current().nextInt(this.I.size()));
         }

         private {
            this.I = var1;
            this.l = var2;
         }

         boolean lI() {
            return !this.I.isEmpty();
         }
      };
   }

   private boolean IlI(class_310 var1, class_2338 var2) {
      if (this.IlII(var1) && var2 != null) {
         class_2680 var3 = var1.field_1687.method_8320(var2);
         return this.IIll(var3) && this.lIIl(var1, var2) != null;
      } else {
         return false;
      }
   }

   private void llI(class_310 var1, class_1703 var2, int var3) {
      int var4 = var1.field_1724.field_6012;
      this.ll.entrySet().removeIf((var4x) -> {
         if (var4 - ((<undefinedtype>)var4x.getValue()).II >= lIIII(1215037365, 1246272608)) {
            return true;
         } else {
            class_1735 var5 = this.IIlIl(var2, var3, (Integer)var4x.getKey());
            if (var5 != null && var5.method_7681()) {
               class_1799 var6 = var5.method_7677();
               return var6 == null || var6.method_7960() || !((<undefinedtype>)var4x.getValue()).l(var6);
            } else {
               return true;
            }
         }
      });
   }

   public IlIIIIl() {
      super((Object)lIlIII.l(lll[2]), lIllII.l, (Object)lIlIII.l(lll[5]));
      this.Il = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(lll[0]), (double)85.0F, (double)165.0F, (double)0.0F, (double)1000.0F, (double)5.0F)).IIII(lIlIII.Il(lll[4])));
      this.lII = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lll[3]), true));
      this.l = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lll[lIIII(1215037348, -237114955)]), false));
      this.III = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lll[1]), false));
      this.IIII = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lll[lIIII(1215037349, 658331483)]), false));
      this.IlII = lIIII(1215037350, -1053030905);
      this.IIll = lIIII(1215037351, 1699899028);
      this.IlIl = lIIII(1215037344, 234455435);
      this.ll = new HashMap();
      this.IllI = new HashSet();
      this.IIl = false;
   }

   private static void lll() {
      lll[0] = IIlll(lIIIl('읲', 'ڼ', -1901974252).toCharArray(), 319L, lIIII(1215037345, -656306633));
      lll[1] = IIlll(lIIIl('믙', 'ڽ', 1970013030).toCharArray(), 89649L, lIIII(1215037346, -323238240));
      lll[2] = IIlll(lIIIl('푃', 'ھ', 1961587354).toCharArray(), 7942L, lIIII(1215037347, -1782053627));
      lll[3] = IIlll(lIIIl('\ue076', 'ڿ', -153803816).toCharArray(), 85072L, lIIII(1215037356, 784052626));
      lll[4] = IIlll(lIIIl('칋', 'ڸ', 915219200).toCharArray(), 25906L, lIIII(1215037357, 1648674432));
      lll[5] = IIlll(lIIIl('ᛵ', 'ڹ', 2058753355).toCharArray(), 39484L, lIIII(1215037358, -1758092352));
      lll[lIIII(1215037359, 1712843914)] = IIlll(lIIIl('怾', 'ں', 1575968662).toCharArray(), 838L, lIIII(1215037352, 946903176));
      lll[lIIII(1215037353, 1502502395)] = IIlll(lIIIl('馦', 'ڻ', 713637333).toCharArray(), 86930L, lIIII(1215037354, 426962575));
   }

   private int IIII(class_1703 var1) {
      if (var1 instanceof class_1707 var2) {
         return var2.method_17388() * lIIII(1215037355, -11561500);
      } else if ((Boolean)this.lII.III() && var1 instanceof class_1733) {
         return lIIII(1215037364, 569914667);
      } else {
         return (Boolean)this.l.III() && var1 instanceof class_1722 ? 5 : 0;
      }
   }

   private boolean IIll(class_2680 var1) {
      if (!var1.method_27852(class_2246.field_10034) && !var1.method_27852(class_2246.field_10380) && !var1.method_27852(class_2246.field_16328) && !var1.method_27852(class_2246.field_10443)) {
         if ((Boolean)this.lII.III() && var1.method_26204() instanceof class_2480) {
            return true;
         } else {
            return (Boolean)this.l.III() && var1.method_27852(class_2246.field_10312);
         }
      } else {
         return true;
      }
   }

   private boolean IlII(class_310 var1) {
      return var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var1.field_1724.method_5805();
   }

   private boolean IlIl(class_310 var1) {
      lIllIIl var2 = lIllIIl.Il();
      if (var2 != null && var2.IIl() != null) {
         lllIllI var3 = var2.IIl().llIIII();
         return var3 != null && var3.IIII(var1);
      } else {
         return false;
      }
   }

   private boolean lIII(class_310 var1, class_1799 var2) {
      lIllIIl var3 = lIllIIl.Il();
      if (var3 != null && var3.IIl() != null && var1 != null && var1.field_1724 != null) {
         llIlII var4 = var3.IIl().IllI();
         return var4 != null && var4.IIIIIlI() && var4.lIII(var1.field_1724, var2);
      } else {
         return false;
      }
   }

   private class_3965 lIIl(class_310 var1, class_2338 var2) {
      if (this.IlII(var1) && var2 != null) {
         class_239 var4 = var1.field_1765;
         if (var4 instanceof class_3965) {
            class_3965 var3 = (class_3965)var4;
            if (var3.method_17783() == class_240.field_1332 && var3.method_17777().equals(var2) && this.IIlII(var1.field_1724, var3.method_17784())) {
               return var3;
            }
         }

         ArrayList var10 = new ArrayList(Arrays.asList(class_2350.values()));
         class_243 var11 = var1.field_1724.method_33571();
         class_243 var5 = class_243.method_24953(var2);
         var10.sort(Comparator.comparingDouble((var3x) -> this.IIIII(var5, var3x).method_1025(var11)));

         for(class_2350 var7 : var10) {
            class_243 var8 = this.IIIII(var5, var7);
            if (this.IIlII(var1.field_1724, var8)) {
               class_3965 var9 = var1.field_1687.method_17742(new class_3959(var11, var8, class_3960.field_17559, class_242.field_1348, var1.field_1724));
               if (var9 != null && var9.method_17783() != class_240.field_1333 && var9.method_17777().equals(var2)) {
                  return var9;
               }
            }
         }

         return null;
      } else {
         return null;
      }
   }

   public void lIl() {
      this.II = 0L;
      this.I = this.llII();
      this.IlII = lIIII(1215037366, 1776210514);
      this.IIll = lIIII(1215037367, 2066570960);
      this.IlIl = lIIII(1215037360, -1772929499);
      this.ll.clear();
      this.IllI.clear();
      this.IlI = null;
      this.IIl = false;
      this.IIllI();
   }

   private long llII() {
      double var1 = this.Il.IlII();
      double var3 = this.Il.IlI();
      return var1 == var3 ? Math.round(var1) : Math.round(ThreadLocalRandom.current().nextDouble(var1, var3));
   }

   private void lllI(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         if (this.IlIl != this.IlII) {
            this.IlIl = this.IlII;
            var1.field_1724.method_7346();
            var1.method_1507((class_437)null);
            this.IIll = lIIII(1215037361, 1035017453);
            this.ll.clear();
            if (this.IlI != null) {
               this.IllI.add(this.IlI);
               this.IlI = null;
               this.IIl = false;
            }

         }
      }
   }

   private class_243 IIIII(class_243 var1, class_2350 var2) {
      class_2382 var3 = var2.method_62675();
      return var1.method_1031((double)var3.method_10263() * 0.4999, (double)var3.method_10264() * 0.4999, (double)var3.method_10260() * 0.4999);
   }

   private void IIIIl(class_1703 var1, int var2, int var3, int var4) {
      class_1735 var5 = this.IIlIl(var1, var2, var3);
      if (var5 != null && var5.method_7681()) {
         class_1799 var6 = var5.method_7677();
         if (var6 != null && !var6.method_7960()) {
            this.ll.put(var3, new Record(this.Illll(var6), var6.method_7947(), var4) {
               private final int I;
               private final String l;
               private final int II;

               public String I() {
                  return this.l;
               }

               boolean l(class_1799 var1) {
                  return this.I == var1.method_7947() && this.l.equals(var1.method_7909().toString());
               }

               private {
                  this.l = var1;
                  this.I = var2;
                  this.II = var3;
               }

               public int II() {
                  return this.I;
               }

               public int Il() {
                  return this.II;
               }
            });
         }
      }
   }

   public boolean IIIll(class_310 var1) {
      if (this.IIIIIlI() && this.IlII(var1)) {
         class_437 var3 = var1.field_1755;
         if (var3 instanceof class_465) {
            class_465 var2 = (class_465)var3;
            if (this.IlIl(var1)) {
               return false;
            }

            class_1703 var4 = var2.method_17577();
            return this.IIII(var4) > 0 && var4.method_34255() != null;
         }
      }

      return false;
   }

   private boolean IIlII(class_746 var1, class_243 var2) {
      return var1 != null && var2 != null && var1.method_33571().method_1025(var2) <= (double)20.25F;
   }

   private class_1735 IIlIl(class_1703 var1, int var2, int var3) {
      int var4 = Math.min(var2, var1.field_7761.size());

      for(int var5 = 0; var5 < var4; ++var5) {
         class_1735 var6 = (class_1735)var1.field_7761.get(var5);
         if (var6 != null && var6.field_7874 == var3) {
            return var6;
         }
      }

      return null;
   }

   private void IIllI() {
      this.lI = false;
      this.Illl = 0L;
      ++this.Ill;
   }

   static {
      short var6 = 968;
      String var7 = "∅ᆂ\udc9b\uf189뉷ﲍ☊옡க牺䴑㞷ꤜఘ迾궷\ude10⯬겓鲰憑趽疁弐ힺ抹\u0ad2難\ueb46済ﻎ쬇\ue89a쉒龥☾窟梾ᯠ㚽뜺ੋ뛒콪뢐ӌቔ萈쎟⸥츶\ueaf7\u0cce熳䖮䓠뎴䑋龂뫐ᇧႀ율\udee7ﵯ궪㲰練\ue956曏\uf42b盳换䵾茗\ud80a쌙嚚\uef5b\uf165ꊺ뱈䭓꿥\ue2f0ꩽぺ愉\ue4a2ࣽɽ籊甏匤㼲≛嵊㊯屙쬢ཚ턅뢞䘜踗瞚⚛ညᔾ㨲ݱ꣠긳區ꭳ\ued89瓞♏껬\ue341蚥ꏔ蝙䯋ힲ褽ᩅ㧃恠ⶊ곻撰듕덨漸⍩䁢\ufdea\ude53쥕틐攴㮾媻䖊䠘贂㮚\uedc0뎿䧎久ᯰ䴍喯ꬠ⸂ﴕ煭鹟船䐔ꋽ\ue84e鱷כּ벴으⇗芡쑴딝⸥䞴䎿仼";
      char[] var8 = "πτϘτόΔϜτ".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            lIIl = var9;
            lIlI = new Object[var9.length];
            int var2 = -1306883863;
            byte[] var0 = "\u000b¬\u009eÿÝL \u0011»MqH\u001f#\u0011Úw\u0088öÂyÀ\u009d3ÞE3Ø\u0088Ù;\u0096\u0010ÖÆ\rA2\u0093²Ú]ö\u009a\u009cf\u009bÊ\u008b@\u0085w£ÿ*¼í\u0086iH\u0005>â¯Û\u0089Bm°9ë4\u0013¯¥\r\u0001\\)\u008eì\"I|GÀkµ\u0012¨Ë(\u001aîÑ\u0017Çc´õ¬%\u008a$n~òÔ=ª¤þ\\n\u0006UÎÔ\u0090ñ3D»VúÇ8cð¦X\u008fÜÇ\u0017Ô$µ\u0083ÃÀõ\u0011]\f\u0097\u000eî9\u0094\u0085\u0000PF\"OK`r\u001a\u0094Õ\u0015¤".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lIII = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lIII[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            lll = new String[lIIII(1215037362, -388383621)];
            lll();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (this.IlII(var1)) {
         class_437 var3 = var1.field_1755;
         if (var3 instanceof class_465) {
            class_465 var2 = (class_465)var3;
            if (this.IlIl(var1)) {
               this.IllII();
               return;
            }

            class_1703 var11 = var2.method_17577();
            int var4 = this.IIII(var11);
            if (var4 > 0 && var11.method_34255() != null && var11.method_34255().method_7960()) {
               if (this.IlIl == var11.field_7763) {
                  return;
               }

               if (var11.field_7763 != this.IlII) {
                  this.IlII = var11.field_7763;
                  this.IIl = false;
                  this.II = 0L;
                  this.I = this.llII();
                  this.IIll = lIIII(1215037363, 1621075533);
                  this.IlIl = lIIII(1215037372, -1122843744);
                  this.ll.clear();
               }

               boolean var5 = false;
               int var6 = Math.min(var4, var11.field_7761.size());

               for(int var7 = 0; var7 < var6; ++var7) {
                  class_1735 var8 = (class_1735)var11.field_7761.get(var7);
                  if (var8 != null && var8.method_7681() && !var8.method_7677().method_7960()) {
                     var5 = true;
                     break;
                  }
               }

               if (var5) {
                  this.IIl = true;
               }

               this.llI(var1, var11, var4);
               <undefinedtype> var12 = this.ll(var1, var11, var4);
               if (!var12.II()) {
                  this.IlIIl(var1);
                  return;
               }

               this.IIll = lIIII(1215037373, -699073168);
               if (!var12.lI()) {
                  return;
               }

               long var13 = System.currentTimeMillis();
               if (var13 - this.II < this.I) {
                  return;
               }

               int var10 = var12.Il();
               if (!lIlIllll.IIll(var1)) {
                  return;
               }

               this.IIIIl(var11, var4, var10, var1.field_1724.field_6012);
               var1.field_1761.method_2906(var11.field_7763, var10, 0, class_1713.field_7794, var1.field_1724);
               this.II = System.currentTimeMillis();
               this.I = this.llII();
               lIlIllll.IllI(var1);
               return;
            }

            return;
         }
      }

      if (this.IIIIIlI() && this.IlII(var1) && (Boolean)this.III.III() && var1.field_1755 == null) {
         this.IlIll(var1);
      } else {
         this.IllII();
      }

   }

   private static String IIlll(char[] var0, long var1, int var3) {
      int var4 = lIIII(1215037374, -1987203197) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & lIIII(1215037375, -941894825);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private <undefinedtype> IlIII(class_310 var1) {
      class_2338 var2 = var1.field_1724.method_24515();
      Record var3 = null;
      double var4 = Double.MAX_VALUE;

      for(int var6 = lIIII(1215037368, 1507888890); var6 <= 2; ++var6) {
         for(int var7 = lIIII(1215037369, -883287971); var7 <= 4; ++var7) {
            for(int var8 = lIIII(1215037370, 919221241); var8 <= 4; ++var8) {
               class_2338 var9 = var2.method_10069(var7, var6, var8);
               if (!this.IllI.contains(var9) && this.IlI(var1, var9)) {
                  class_3965 var10 = this.lIIl(var1, var9);
                  if (var10 != null) {
                     double var11 = var1.field_1724.method_33571().method_1025(var10.method_17784());
                     if (var11 < var4) {
                        var4 = var11;
                        var3 = new Record(var9.method_10062(), var10) {
                           private final class_3965 I;
                           private final class_2338 l;

                           private {
                              this.l = var1;
                              this.I = var2;
                           }

                           public class_3965 I() {
                              return this.I;
                           }

                           public class_2338 l() {
                              return this.l;
                           }
                        };
                     }
                  }
               }
            }
         }
      }

      return var3;
   }

   public void lI() {
      this.II = 0L;
      this.I = 0L;
      this.IlII = lIIII(1215037371, -2135535823);
      this.IIll = lIIII(1215037316, -1965608990);
      this.IlIl = lIIII(1215037317, -1497997128);
      this.ll.clear();
      this.IllI.clear();
      this.IlI = null;
      this.IIl = false;
      this.IIllI();
   }

   private void IlIIl(class_310 var1) {
      if (!this.ll.isEmpty()) {
         this.IIll = lIIII(1215037318, 1589965996);
      } else if (this.IIll == lIIII(1215037319, -1165728205)) {
         this.IIll = var1.field_1724.field_6012;
      } else {
         int var2 = this.IIl ? 0 : lIIII(1215037312, -152667757);
         if (var1.field_1724.field_6012 - this.IIll >= var2) {
            this.lllI(var1);
         }

      }
   }

   private void IlIll(class_310 var1) {
      long var2 = System.currentTimeMillis();
      if (this.lI) {
         if (var2 - this.Illl <= 1000L) {
            return;
         }

         this.IIllI();
      }

      if (var2 - this.II >= this.I) {
         <undefinedtype> var4 = this.IlIII(var1);
         if (var4 != null) {
            class_243 var5 = var4.I().method_17784();
            float var6;
            float var7;
            if (IlIlIl.lIll(var1, var4.I(), false)) {
               var6 = var1.field_1724.method_36454();
               var7 = var1.field_1724.method_36455();
            } else {
               float[] var8 = IlIlIl.llIlI(var1, var5);
               if (var8 == null) {
                  return;
               }

               var6 = var8[0];
               var7 = var8[1];
            }

            long var11 = ++this.Ill;
            boolean var10 = IlIlIl.IIIIlI(var1, lIIII(1215037313, -1008340281), var6, var7, () -> {
               if (this.lI && var11 == this.Ill) {
                  boolean var5 = this.IllIl(var1, var4);
                  this.lI = false;
                  this.Illl = 0L;
                  if (var5) {
                     this.II = System.currentTimeMillis();
                     this.I = this.llII();
                  }

                  return var5;
               } else {
                  return false;
               }
            });
            if (var10) {
               this.lI = true;
               this.Illl = var2;
            }

         }
      }
   }

   private void IllII() {
      this.IlII = lIIII(1215037314, 708269348);
      this.IIll = lIIII(1215037315, 823199088);
      this.IlIl = lIIII(1215037324, -291216703);
      this.ll.clear();
      this.IIllI();
   }

   private boolean IllIl(class_310 var1, Object var2) {
      if (var2 != null && this.IlI(var1, var2.l())) {
         class_3965 var3 = this.lIIl(var1, var2.l());
         if (var3 == null) {
            var3 = var2.I();
         }

         if (!this.IIlII(var1.field_1724, var3.method_17784())) {
            return false;
         } else {
            IllllIlI.lIllll(var1);
            class_1269 var4 = var1.field_1761.method_2896(var1.field_1724, class_1268.field_5808, var3);
            if (var4 != null && var4.method_23665()) {
               this.IlI = var2.l().method_10062();
               this.IllI.add(this.IlI);
               var1.field_1724.method_6104(class_1268.field_5808);
               return true;
            } else {
               return false;
            }
         }
      } else {
         return false;
      }
   }

   private boolean IlllI(class_1799 var1) {
      if (var1 != null && !var1.method_7960()) {
         if (var1.method_7963()) {
            return true;
         } else if (var1.method_57353().method_57832(class_9334.field_50075)) {
            return true;
         } else {
            return var1.method_31574(class_2246.field_10540.method_8389()) || var1.method_31574(class_1802.field_8634) || var1.method_31574(class_1802.field_8301) || var1.method_31574(class_1802.field_8287) || var1.method_31574(class_1802.field_8288) || var1.method_31574(class_1802.field_8463) || var1.method_31574(class_1802.field_8367) || var1.method_31574(class_1802.field_8574) || var1.method_31574(class_1802.field_8436) || var1.method_31574(class_1802.field_8150) || var1.method_31574(class_2246.field_23152.method_8389()) || var1.method_31574(class_1802.field_8801) || var1.method_31574(class_1802.field_8107) || var1.method_31574(class_2246.field_10343.method_8389());
         }
      } else {
         return false;
      }
   }

   private String Illll(class_1799 var1) {
      return var1.method_7909().toString();
   }

   private static int lIIII(int var0, int var1) {
      return lIII[var0 ^ 1215037348] ^ var1 ^ var0;
   }

   private static String lIIIl(char var0, char var1, int var2) {
      int var3 = var1 ^ 1724;
      char[] var4 = lIIl[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])lIlI[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         lIlI[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 25888;
      int var9 = 0;

      do {
         int var10 = var4[var9] ^ 23370;
         var10 -= 14246;
         var10 += 19368;
         var10 += 31187;
         var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var2 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
