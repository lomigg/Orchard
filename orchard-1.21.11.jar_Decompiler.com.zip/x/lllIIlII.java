package x;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_745;

@Environment(EnvType.CLIENT)
public final class lllIIlII extends IIIIIIIlI {
   private final lIIIIl I;
   private final lIIIIl l;
   private final List<<undefinedtype>> II;
   private final lIIIIl Il;
   private final IIllIlIII lI;
   private final IIIllIIII ll;
   private final IIllIlIII III;
   private final IIIllIIII IIl;
   private final lIIIIl IlI;
   private static String[] Ill;
   private final IIIllIIII lII;
   private static final int[] lIl;
   private static final String[] llI;
   private static final Object[] lll;

   public void ll(class_1657 var1) {
      if (this.IIIIIlI()) {
         class_310 var2 = class_310.method_1551();
         if (var2.field_1687 != null && var2.field_1724 != null && var1 != null && !var1.method_31481() && var1.method_5805()) {
            if (var1 != var2.field_1724 || (Boolean)this.l.III()) {
               this.II.add(this.IlII(var1, var2));
            }
         }
      }
   }

   private static String IlI(char[] var0, long var1, int var3) {
      int var4 = llII(-286558796, -992057860) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & llII(-286558795, 1824987643);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private long lII() {
      return Math.max(50L, Math.round((Double)this.IIl.III()));
   }

   private Color llI(Object var1, float var2) {
      if (!(Boolean)this.I.III()) {
         return (Color)this.III.III();
      } else {
         Color var3 = this.lIII();
         Color var4 = IIlIIllIl.Ill(var3, null.l, (double)var1.lI() * 1.3E-4 + (double)var2);
         return IIlIIllIl.I(var4, llII(-286558794, -1288260255));
      }
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (var1.field_1687 != null && var1.field_1724 != null) {
         long var2 = System.currentTimeMillis();
         long var4 = this.lII();
         this.II.removeIf((var5) -> var5.lI() + var4 <= var2 || var5.l().method_73183() != var1.field_1687);
      } else {
         this.II.clear();
      }
   }

   public lllIIlII() {
      super((Object)lIlIII.l(Ill[0]), lIllII.ll, (Object)lIlIII.l(Ill[5]));
      this.IlI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(Ill[llII(-286558793, 324274667)]), true));
      this.I = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(Ill[llII(-286558800, -2107060272)]), true));
      this.lI = (IIllIlIII)this.IIIlIll(new IIllIlIII(lIlIII.l(Ill[2]), new Color(llII(-286558799, 2048882110), llII(-286558798, 1409386683), llII(-286558797, 211991954), llII(-286558788, -476058077))));
      this.Il = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(Ill[llII(-286558787, -258817962)]), true));
      this.III = (IIllIlIII)this.IIIlIll(new IIllIlIII(lIlIII.l(Ill[llII(-286558786, 1496766493)]), new Color(llII(-286558785, 1838572825), llII(-286558792, -1288452850), llII(-286558791, -103606082), llII(-286558790, -1662760629))));
      this.lII = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(Ill[llII(-286558789, -1057438943)]), (double)1.5F, (double)0.5F, (double)6.0F, 0.1));
      this.IIl = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(Ill[1]), (double)1500.0F, (double)100.0F, (double)5000.0F, (double)50.0F)).IIl(lIlIII.Il(Ill[4])));
      this.ll = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(Ill[llII(-286558812, 950899271)]), (double)0.0F, (double)-2.0F, (double)2.0F, 0.05)).IIl(lIlIII.Il(Ill[3])));
      this.l = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(Ill[llII(-286558811, -1988266404)]), false));
      this.II = new ArrayList();
      this.lI.lIII(() -> (Boolean)this.IlI.III() && !(Boolean)this.I.III());
      this.III.lIII(() -> (Boolean)this.Il.III() && !(Boolean)this.I.III());
      IIIllIIII var10000 = this.lII;
      lIIIIl var10001 = this.Il;
      Objects.requireNonNull(var10001);
      var10000.lIII(var10001::III);
   }

   public void llIl(llIIllI var1) {
      if (this.IIIIIlI() && ((Boolean)this.IlI.III() || (Boolean)this.Il.III()) && IIlIIIIl.IlIII(var1)) {
         class_310 var2 = class_310.method_1551();
         if (var2.field_1687 != null && var2.field_1724 != null && var1.ll() != null) {
            long var3 = System.currentTimeMillis();
            long var5 = this.lII();
            Iterator var7 = this.II.iterator();

            while(var7.hasNext()) {
               <undefinedtype> var8 = (<undefinedtype>)var7.next();
               if (var8.lI() + var5 > var3 && var8.l().method_73183() == var2.field_1687) {
                  this.lIIl(var1, var8, var3, var5);
               } else {
                  var7.remove();
               }
            }

         } else {
            this.II.clear();
         }
      }
   }

   public void lI() {
      this.II.clear();
   }

   private Color IIll(Object var1, float var2) {
      if (!(Boolean)this.I.III()) {
         return (Color)this.lI.III();
      } else {
         Color var3 = this.lIII();
         Color var4 = IIlIIllIl.Ill(var3, null.ll, (double)var1.lI() * 1.1E-4 + (double)var2);
         return IIlIIllIl.I(var4, llII(-286558810, 1229585647));
      }
   }

   private <undefinedtype> IlII(class_1657 var1, class_310 var2) {
      class_745 var3 = new class_745(var2.field_1687, var1.method_7334());
      double var4 = var1.method_23318() - (var1.method_5715() ? (double)0.125F : (double)0.0F);
      var3.method_5808(var1.method_23317(), var4, var1.method_23321(), var1.method_36454(), var1.method_36455());
      var3.method_5847(var1.method_5791());
      var3.method_36457(var1.method_36455());
      var3.method_18380(var1.method_18376());
      var3.method_5660(var1.method_5715());
      var3.method_5875(var1.method_5740());
      var3.method_5648(var1.method_5767());
      var3.field_6252 = var1.field_6252;
      return new Record(var3, System.currentTimeMillis(), var1.method_23317(), var4, var1.method_23321(), IllllIlI.IIlllll(var1, 1.0F)) {
         private final long I;
         private final double l;
         private final class_745 II;
         private final double Il;
         private final float lI;
         private final double ll;

         private {
            this.II = var1;
            this.I = var2;
            this.Il = var4;
            this.l = var6;
            this.ll = var8;
            this.lI = var10;
         }

         public double I() {
            return this.ll;
         }

         public class_745 l() {
            return this.II;
         }

         public double II() {
            return this.Il;
         }

         public double Il() {
            return this.l;
         }

         public long lI() {
            return this.I;
         }

         public float ll() {
            return this.lI;
         }
      };
   }

   private static void IlIl() {
      Ill[0] = IlI(lllI(1229274707, 'ꐞ', '뉡').toCharArray(), 61627L, llII(-286558809, 1444207563));
      Ill[1] = IlI(lllI(2079477996, '㴘', '뉠').toCharArray(), 56124L, llII(-286558816, -1268346091));
      Ill[2] = IlI(lllI(-329877023, '㙘', '뉣').toCharArray(), 98757L, llII(-286558815, -43097916));
      Ill[3] = IlI(lllI(97730330, '昑', '뉢').toCharArray(), 59058L, llII(-286558814, -1731541540));
      Ill[4] = IlI(lllI(1844650532, '捪', '뉥').toCharArray(), 27463L, llII(-286558813, 739558194));
      Ill[5] = IlI(lllI(-355525185, '涝', '뉤').toCharArray(), 5452L, llII(-286558804, -933573453));
      Ill[llII(-286558803, 1613103744)] = IlI(lllI(1963222827, '嗴', '뉧').toCharArray(), 9642L, llII(-286558802, 626447257));
      Ill[llII(-286558801, -1637003663)] = IlI(lllI(9061367, '℈', '뉦').toCharArray(), 90644L, llII(-286558808, -216008571));
      Ill[llII(-286558807, -1034675471)] = IlI(lllI(513827345, '䧘', '뉩').toCharArray(), 76800L, llII(-286558806, -1943647914));
      Ill[llII(-286558805, 775471085)] = IlI(lllI(445339791, '닃', '뉨').toCharArray(), 76810L, llII(-286558828, -1866935303));
      Ill[llII(-286558827, -378042464)] = IlI(lllI(1454326161, '榓', '뉫').toCharArray(), 7827L, llII(-286558826, -1828448782));
      Ill[llII(-286558825, -1788659200)] = IlI(lllI(-2032576615, '\ued67', '뉪').toCharArray(), 15748L, llII(-286558832, 1990313474));
      Ill[llII(-286558831, -1414644695)] = IlI(lllI(1635795498, '塩', '뉭').toCharArray(), 31709L, llII(-286558830, 1248946314));
      Ill[llII(-286558829, 1716409307)] = IlI("".toCharArray(), 28606L, llII(-286558820, -198848804));
   }

   private Color lIII() {
      lIllIIl var1 = lIllIIl.Il();
      lIIIllll var2 = var1 != null && var1.IIl() != null ? var1.IIl().IIII() : null;
      return var2 == null ? new Color(llII(-286558819, -1405968964), llII(-286558818, 1525665288), llII(-286558817, -422476713), llII(-286558824, -1926489341)) : var2.lllI();
   }

   static {
      short var6 = 24771;
      String var7 = "㥧庿劽擆\uf881蜩쑗ᾲ泒ኩ㚷푇ᦵΠ植䑚牼꽢˓쏩습릀ໝ䣔ᔗ靰믄ꮇᕮ匳岉椹䤘ꍹ흣贈頌㤭ﺆ팥\ueb86䱲鉭\ue6f4瑽뮎⧗ྵ톅㉦謱姈啝〭韢혿\ue0ee宦䦕\ue679䖃嶁㵳䪕⡅爀Ⳇ뭷뽸跞톢ᮮ餝\uea60뻺\uf32fꭻ餡躈朹⋁\ua62f啷᪬⃥ꊸ蟶豭\udb30쇌殚푙ធ䧗\uf307袕⁃頾콍䯱툥脠Ụ瞅ܜ朷ʤ\ufb45࿎⍒襓⪩汗၅ੜ艖噟狍꡴鑒蛺\uf57c፱譱哃蕒\ue433穭鿅䨓囗ｉ免\uecd9픿༫ಗ\ue0f3戆\ue384䚉\uef9f診쏖菜ୋ㛠ꙣꮧ\udbad豛⇹⹈消袕ƨ␢\uef9d關垹餖钐형襃쐱懴\ue9a1蜆蒢ຉ\ue15c턻\ue28b畠哬뤋煺\uef12쾻㥥檓៦Έ螤\udd09৹苸君☡ߴ컎葓\ued1a໐䁽䉪듕ꘐ⭿\ue5b4ﯥ\ue639铞\u1739ꈧ䗕铘㵿뜹ᄄ覆\uea25鴻\ueef5僮虩\u2efb㱃Ꜣሸ▙찹О悴\ue887ﲲ\udabc嶄ኴ왠\uee80筸";
      char[] var8 = "惓惏惋惇惇悛惓惏惏惓惗惋惓".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            llI = var9;
            lll = new Object[var9.length];
            int var2 = -1527954908;
            byte[] var0 = "m6=$&Á.\u0095ù0\u0082\fYR>sÈnøB0\u0019BÔ\u001e\u0007¿\u0000F¤\u008a(©\u0099Ùëº\u0094÷Ç\u00130ï\u008d'\u0090R}ù5ò¿³Õ/\u000eÖâ~*\u008aþô·r«¥ËÃ{AÚ\u0003OË=Ú¹\u001fOZ»\u0013æÙjÿ\u009c^\u008cõIIÄ\u009d¨¤0Ìd* 5\u000fy9\u009d\u000fÔkyý{¤z°\u0088R-tÛ`\u0004)d>\u0088k kY{£q°\u001b^?4#ße\r¸éy\u009fºá¨\u000b\u0090\n\u001f\u0004\u0096,Hda\u001e\u0011\u001f\u0090æ4ªú\u0010éù\u009f¬×³ÁÇ*,@+4ÕÍ \u0081%d".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lIl = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lIl[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            Ill = new String[llII(-286558823, 1630724734)];
            IlIl();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public String Il() {
      return Ill[llII(-286558822, -360246569)];
   }

   private void lIIl(llIIllI var1, Object var2, long var3, long var5) {
      float var7 = Math.min(1.0F, (float)(var3 - var2.lI()) / (float)var5);
      float var8 = 1.0F - var7;
      if (!(var8 <= 0.0F)) {
         double var9 = (Double)this.ll.III() * (double)var7;
         float var11 = var2.l().method_17681() * 0.5F;
         float var12 = var2.l().method_17682();
         if (!(var11 <= 0.0F) && !(var12 <= 0.0F)) {
            class_243 var13 = new class_243(var2.II(), var2.Il() + var9 + (double)var12 * (double)0.5F, var2.I());
            if ((Boolean)this.IlI.III()) {
               Color var14 = this.IIll(var2, var7);
               IIlIIIIl.IIIIl(var1, var13, var11, var12, var2.ll(), var14, (double)((int)((float)var14.getAlpha() * var8)));
            }

            if ((Boolean)this.Il.III()) {
               Color var15 = this.llI(var2, var7);
               IIlIIIIl.llllI(var1, var13, var11, var12, var2.ll(), var15, (double)((int)((float)var15.getAlpha() * var8)), ((Double)this.lII.III()).floatValue());
            }

         }
      }
   }

   private static int llII(int var0, int var1) {
      return lIl[var0 ^ -286558796] ^ var1 ^ var0;
   }

   private static String lllI(int var0, char var1, char var2) {
      int var3 = var2 ^ '뉡';
      char[] var4 = llI[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])lll[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         lll[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 5562;
      int var9 = 0;

      do {
         int var10 = var4[var9] ^ '숞';
         var10 += 50167;
         var10 += 47679;
         var10 += 11290;
         var10 += 42699;
         var10 ^= 42225;
         var10 -= 9157;
         var10 += 43945;
         var10 ^= 47166;
         var10 += 15326;
         var4[var9] = (char)(var10 ^ var8 ^ var1 ^ var0 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
