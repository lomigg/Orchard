package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public enum IlIIllll {
   l,
   II;

   private final <undefinedtype> Il;
   private static String[] lI;
   ll;

   private static final int[] III;
   private static final String[] IIl;
   private static final Object[] IlI;

   public String toString() {
      return this.Il.lIlI();
   }

   static {
      short var6 = 4144;
      String var7 = "\uec98繳\ue423䞱←Ṧ\u0cf9讼\uf774ﮱ鸹ꄴꯢ꫞\u0991膅ዂ뜑ඖࣼ燊淬ݥ畛ඖ慽뾠沜覣\ud8e4\uda9f笲蒹\ud8b1₸셨췌܅鸍鰃笚豪\ue93c쬴蘯듨뛒";
      char[] var8 = "းံ္းဴြ".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IIl = var9;
            IlI = new Object[var9.length];
            int var2 = -567953360;
            byte[] var0 = "\u0085(,\u009fG\u0082Ç;h\u008fiu¨X\u00050À£/£*4ÓËD\u009c¦$+õ\u008b080)\u008d".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            III = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               III[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            lI = new String[lI(854673278, 1778176983)];
            Il();
            ll = new IlIIllll(lI[1], 0, lIlIII.Il(lI[0]));
            II = new IlIIllll(lI[2], 1, lIlIII.Il(lI[5]));
            l = new IlIIllll(lI[4], 2, lIlIII.Il(lI[3]));
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   // $FF: synthetic method
   private static IlIIllll[] I() {
      return new IlIIllll[]{ll, II, l};
   }

   public static IlIIllll l(String var0) {
      return (IlIIllll)Enum.valueOf(IlIIllll.class, var0);
   }

   private static String II(char[] var0, long var1, int var3) {
      int var4 = lI(854673279, 80934690) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & lI(854673276, -2074372410);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private static void Il() {
      lI[0] = II(ll(-817156752, '䃢', (short)15353).toCharArray(), 8248L, lI(854673277, 2087227789));
      lI[1] = II(ll(194124317, '䃣', (short)30706).toCharArray(), 13992L, lI(854673274, 1285019433));
      lI[2] = II(ll(741344958, '䃠', (short)'촶').toCharArray(), 80397L, lI(854673275, 1732811680));
      lI[3] = II(ll(1780222198, '䃡', (short)29140).toCharArray(), 76929L, lI(854673272, -1247223890));
      lI[4] = II(ll(-1487310240, '䃦', (short)17564).toCharArray(), 7174L, lI(854673273, -2050698248));
      lI[5] = II(ll(1097753566, '䃧', (short)'趤').toCharArray(), 77585L, lI(854673270, -1528877176));
   }

   private IlIIllll(String var3) {
      this.Il = lIlIII.III(var3);
   }

   private static int lI(int var0, int var1) {
      return III[var0 ^ 854673278] ^ var1 ^ var0;
   }

   private static String ll(int var0, char var1, short var2) {
      int var3 = var1 ^ 16610;
      char[] var4 = IIl[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])IlI[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         IlI[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 17160;
      int var9 = 0;

      do {
         int var10 = var4[var9] ^ '쭒';
         var10 -= 37943;
         var10 += 62072;
         var10 ^= 29334;
         var10 += 30567;
         var10 += 16216;
         var10 += 32116;
         var10 ^= 20980;
         var10 -= 31773;
         var4[var9] = (char)(var10 ^ var8 ^ var2 ^ var0 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
