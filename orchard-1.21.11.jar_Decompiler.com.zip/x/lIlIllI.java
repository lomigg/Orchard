package x;

import java.awt.Color;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_310;
import net.minecraft.class_7923;

@Environment(EnvType.CLIENT)
public final class lIlIllI extends IIIIIIIlI {
   private final IIllIlIII I;
   private final IlIIIlIlI<<undefinedtype>> l;
   private final lIIIIl II;
   private int Il;
   private final Map<Long, List<<undefinedtype>>> lI;
   private static final int ll = 2;
   private final IIllIlIII III;
   private final lIIIIl IIl;
   private final lIIIIl IlI;
   private final IIllIlIII Ill;
   private static final int lII = 8;
   private final lIIIIl lIl;
   private int llI;
   private final lIIIIl lll;
   private final lIIIIl IIII;
   private final lIIIIl IIIl;
   private static String[] IIlI;
   private final IIllIlIII IIll;
   private final IIllIlIII IlII;
   private final IIIllIIII IlIl;
   private final lIIIIl IllI;
   private static volatile lIlIllI Illl;
   private final IIllIlIII lIII;
   private final IIllIlIII lIIl;
   private final IIllIlIII lIlI;
   private final lIIIIl lIll;
   private final ArrayDeque<<undefinedtype>> llII;
   private final lIIIIl llIl;
   private Object lllI;
   private final IIllIlIII llll;
   private final lIIIlll IIIII;
   private int IIIIl;
   private static final int IIIlI = 64;
   private static final int IIIll = 20;
   private final lIIIIl IIlII;
   private final lIIIIl IIlIl;
   private final IIllIlIII IIllI;
   private final IIllIlIII IIlll;
   private final lIIIIl IlIII;
   private static final int[] IlIIl;
   private static final String[] IlIlI;
   private static final Object[] IlIll;

   public static lIlIllI ll() {
      return Illl;
   }

   private void IlI(class_310 var1, class_2338 var2, Object var3, class_2818 var4) {
      int var5 = (Integer)var1.field_1690.method_42503().method_41753();
      int var6 = Math.max(1, Math.min(var5, IlIII(1547909010, 1896269304)));
      int var7 = var6 * IlIII(1547909011, -265613046);
      int var8 = var7 * var7;
      int var9 = Math.max(var1.field_1687.method_31607(), var2.method_10264() - IlIII(1547909008, 2008947526));
      int var10 = Math.min(var1.field_1687.method_31600(), var2.method_10264() + IlIII(1547909009, -1142129597));
      int var11 = var3.l() << 4;
      int var12 = var3.I() << 4;
      class_2338.class_2339 var13 = new class_2338.class_2339();
      ArrayList var14 = new ArrayList();

      for(int var15 = 0; var15 < IlIII(1547909014, 617073522); ++var15) {
         int var16 = var11 + var15;
         int var17 = var16 - var2.method_10263();

         for(int var18 = 0; var18 < IlIII(1547909015, 53251432); ++var18) {
            int var19 = var12 + var18;
            int var20 = var19 - var2.method_10260();
            if (var17 * var17 + var20 * var20 <= var8) {
               for(int var21 = var9; var21 <= var10; ++var21) {
                  var13.method_10103(var16, var21, var19);
                  class_2680 var22 = var4.method_8320(var13);
                  if (this.lll(var22)) {
                     var14.add(new Record(new class_2338(var16, var21, var19), var22.method_26204()) {
                        private final class_2338 I;
                        private final class_2248 l;

                        public class_2338 I() {
                           return this.I;
                        }

                        private {
                           this.I = var1;
                           this.l = var2;
                        }

                        public class_2248 l() {
                           return this.l;
                        }
                     });
                  }
               }
            }
         }
      }

      this.lI.put(lIII(var3.l(), var3.I()), List.copyOf(var14));
   }

   private Color lII(Color var1, double var2) {
      Color var10000;
      switch (((<undefinedtype>)this.l.III()).ordinal()) {
         case 0 -> var10000 = var1;
         case 1 -> var10000 = IIlIIllIl.Ill(var1, null.l, var2);
         case 2 -> var10000 = IIlIIllIl.Ill(var1, null.ll, var2);
         case 3 -> var10000 = IIlIIllIl.Ill(var1, null.II, var2);
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   static {
      short var6 = 31081;
      String var7 = "㠁㕬䔓覠呔\udfee龧嬪Ἢ䬴\uec16뤸씙㞈꣄䙛ꔜ켷쭉磬攂ꚼ誟밄ឹᾡ\uf1c5娭\uaaf7퍌辝㨓㬻摇쏕\ueb38\uf826멬ᳲ⾦陗廆\ue638\uf6bb㌭阶曁\ue9c1䯘谣߾삼螅\ue253\u0ce5̙餺\uf8fb쿻ꉚⷌᴨ顩㕺᧥뷍\u007fї쨞\ue777唂䉰퓗孇ꉺ䤑ⷾ㒾ᔈ⩸㰆컓\ued86븏裄\ue9d3\ue5e5忳菤\ue977Ꙏẕἆ䃚\uedff\ufdc8⿆ঘኽ亚籣慰洈ﳆ⥜뤄څ䱶帋纱\uf063핧曍鋂⧞䩹⡼笣ꓚۉ綿⢼裥㜫ꅵ\ue666\uef12\ue44a\udfd1䩭省읁\ue21b\uf253柑Ḩ䁥㝓㋕敘\uf410捞不쿰Ü驛☲굠采≙㘆⢻ࣷ\udcb5\ufb0c䮹訊堕ࣥ뼂쮛晜ᜣ\u0b54⣗ᷦ䙍뷹橋㉑쒠▻촦㋵\ue7c1䨘㢟鏠䂘㶈䊤㸍俽樵耿㙪睱굜烂鰬滜\udf0eꍸ攥\uf828牷\ue299隓\ue98a彣\uf265妯焩쁹\uf2cb勇ෛ\u200f酧롙Ⱳ砅\uf197쳮\uf78c醗□䤎ᣎﴞꪑ\udaf6㦧⦑偧쓃眼矯ﳌ鎑쎖㓼㗣狶숋఼⾅\uf85a踖鄈ຸ夂ࡏ侘丏\ue1e2鏥뼢\udbe1礽읃㴫뒵贩\uef52㰥⦃앺딐鑶ꎉ߲䇀≢硗ƅ\ud84b⛻熇艪걷霯糦簄㧫\uef19临ꍖ☌⮭怖Ȿۓ쒒瞹ꊯ円녝疄\uf087壆ࠥ亨쓀潷诡놁葕죪埱\ue3c5ᵄꇇ\ude36櫚瀻ଟ\ue37c뽊ң\ufaed䫡ﳶשּ憡\uf25a嗐訉쭼囫\uf5e5痭ꌻฟ㮼垑ቯ↡鬚纥\ue740⡑䭔닑묈Ώ﵎ⶾ㊬\uf374Ⳃ≙ਜ਼ᝧ锇\u0e5d傺ꍠ僭撙纁⨿뻟鑶ꠣ⧦◳ꝭ\uffc0ﺠ嬙牖ꖔᾰ㟫⏍៌\uf262걀\udf8e◓재倭䒊펳㝔硎处찙惻췡᬴\uf697䩣ڲ皑棉钀䆇\ue90eЖ瑉儹粓䷭득嘲銒仃⢄⁵蛜窖蕳谩鈋붂\uf04f㩍\ue0de\udac0㟼뇰ꒁ줯ꦜ쏓᳘聯췡ᐨ㐈捸郈盅慦ꦭ\uf59e럍帞眬ౘⶖ샥镬쐱ṉ뗷譒䕀ꅄ憭⼖풟龪㧨✹\uf462꒒ꦆﺥ돠䦈\udc89✰襟썢ᡙ⋵臡ꀄ吆奥䜲∲輞焄\ue461歖旅\uef4eఝ\ue220쉫敶\ude85ᧁ칽횞\uf063\udfdf⦾ྒྷ숁\ue551ỳᮽ\ue419䫪䑺\uf629⊚삨\ue604∰裖{扸鴴錄";
      char[] var8 = "祭祱祹祱祥祽祥祡祡祡祥祹祹祡祡祹祡祹祽祥祹祡祽祡祽祕祡祭祹祹祥祹祽祡".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IlIlI = var9;
            IlIll = new Object[var9.length];
            int var2 = -1788031690;
            byte[] var0 = "¸)?T9\u0004ë¿¾\u0091á rÃ\u0086¤íè1ÂÊ\u0003wÙü²ÇÃøûë¥§]yç\r²XÌeáà¯ä%ÎÛÏ\u0010R;\u000eïO\u0012\u009a,Ú4\u008af:\nÝn,`6UÅ\u0010¨\u0017\tq\b\u0013z\u0081ÞÌ*ÛÊÑ\\\u0080¾ô\u0012,ÎÂkz(\"òu:kn#æ\u0096ºµm¼(Æ¶\u0000×ó`ÀÓ\n[Ö\u0001gø\u0001æÒò/\u001eÒ\u001e\u0087\u008b\u0082ü\u0018Ø\u000eº\u0088£\u009c'¨÷/S¹\u0011FzÃ\u0090±¾Ê-F&¬/j F\u0093N\u008fÄÏ¦\u0013`¼\nÄ\u0099Å/p¸¿\u0095$-©ÀçÈ¼¸!mi\u001d\u001cPm¾(\\k·õâÌ7\u0001\u00145\u0094Ù<\u009blÅ\u0095\u0099^\u008c_Þeé\u001c3\u0004Äs\u0096\u0096\u0096î°õ\u0007É;\u0081:f\u000b\u0013.\u008c>öj\u0018Ñ\u008bôÈ\b½â\u001c\u0006·t\u009e\t-}¾¥\u000b.©gr\u008e\u0014pÙ´Xj2\u0085ãpy5a\u0091)\nðYT\u001cc\u0006Ì%ºxiÅA»á\u0000\u0002\u0081+\u0001^\u0010\u009adÇVq\u0084\u0019Jz{Gv~[\u008e\u0093F<Sy¾8£È}ík\rPpxÈ ð\u0004|lì_m!\u0083¿[\u009b\u0011±¦à6õØSN\u0097\fY#¯É{Íõ\u001bî\u0013õ\u001e \u00161>Ó¿Îq\u001d\u009c\fz]sPÊ\u0084Öø\u0089v\u009d\u0099yn¿\u0099Ç|\u000e\u0000iÃ\u001d¼.[¬ËÙÇ¶\u001b\u009c\u0098<0ßN>\u0080\tN\u001e{f»\u0088¤}<âh³ñ\u008bO½\u0001ª±ø÷Ò&\u009dÉ\u0090\u0015©\u008aí%\u0094ØÔ\u0080S\u0004<\u001ddË\\\u0006\u008d[ª\u008b\u009d\u0015ÿ\u001d\u0089\u001e)ðmN+.Kà(×éßkÐ\u0097\f¶\u000e4·z\u000egÇ´]\u001cFÂ~Ð\u008bé\u0003\u0010\u001a[R\u008eÂSj»L\u0083j°Ó%&5?·2-¶\u001f àeÎP\u0006/Q\u0002c\u0094+V<égÔ\u000bñ\u0085Ù\u009dëÛ¡\u0001k\u0010ñä\u0004[÷\u0092eÓ4.£\u0084cKk&C\ff\u0094S\u009bÑ\u0087R]\u0091ò\u0006lÛW\u0098r\u001cø\u0010ÅOß»\u0080\u0088\u009b»ë\u009cyÐzO\u001b/uµ\u008eÄU\u0089Ý¡fª".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IlIIl = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IlIIl[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            IIlI = new String[IlIII(1547909012, 899497282)];
            IIII();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public void lIl() {
      Illl = this;
      this.IlIl();
      this.llII();
   }

   public boolean lll(class_2680 var1) {
      return var1 != null && !var1.method_26215() ? this.IIlII(var1.method_26204()) : false;
   }

   private static void IIII() {
      IIlI[0] = IIIIl(IlIIl('\ue453', '䐽', 678838612).toCharArray(), 34744L, IlIII(1547909013, -1860775204));
      IIlI[1] = IIIIl("".toCharArray(), 17830L, IlIII(1547909018, 1716937461));
      IIlI[2] = IIIIl(IlIIl('ẑ', '䐼', -1270394711).toCharArray(), 26199L, IlIII(1547909019, -2031128637));
      IIlI[3] = IIIIl(IlIIl('蓰', '䐿', -1882435179).toCharArray(), 64601L, IlIII(1547909016, -2061646812));
      IIlI[4] = IIIIl(IlIIl('낽', '䐾', 1901400787).toCharArray(), 83635L, IlIII(1547909017, 1518284444));
      IIlI[5] = IIIIl(IlIIl('蛤', '䐹', -1495191869).toCharArray(), 97769L, IlIII(1547909022, 1474800749));
      IIlI[IlIII(1547909023, -943671875)] = IIIIl(IlIIl('졣', '䐸', -599236767).toCharArray(), 84259L, IlIII(1547909020, 1274558968));
      IIlI[IlIII(1547909021, 1128906918)] = IIIIl(IlIIl('盛', '䐻', -1132788761).toCharArray(), 76331L, IlIII(1547908994, 192454372));
      IIlI[IlIII(1547908995, -8765523)] = IIIIl(IlIIl('\ude2c', '䐺', -1333911087).toCharArray(), 74495L, IlIII(1547908992, 1542769588));
      IIlI[IlIII(1547908993, -1052999617)] = IIIIl(IlIIl('鞤', '䐵', 1934055275).toCharArray(), 68547L, IlIII(1547908998, -363210118));
      IIlI[IlIII(1547908999, 67020347)] = IIIIl(IlIIl('頗', '䐴', -901905960).toCharArray(), 97157L, IlIII(1547908996, -1595200194));
      IIlI[IlIII(1547908997, 133009858)] = IIIIl(IlIIl('듛', '䐷', 1941333067).toCharArray(), 90607L, IlIII(1547909002, 2110854310));
      IIlI[IlIII(1547909003, -213609326)] = IIIIl(IlIIl('支', '䐶', -1496689794).toCharArray(), 64172L, IlIII(1547909000, 486423973));
      IIlI[IlIII(1547909001, -1533816204)] = IIIIl(IlIIl('ቭ', '䐱', -622048855).toCharArray(), 30459L, IlIII(1547909006, -1607573825));
      IIlI[IlIII(1547909007, -1443944003)] = IIIIl(IlIIl('礩', '䐰', -1821428541).toCharArray(), 28291L, IlIII(1547909004, -435823646));
      IIlI[IlIII(1547909005, 825105510)] = IIIIl(IlIIl('묄', '䐳', -1547954161).toCharArray(), 49804L, IlIII(1547909042, -768278402));
      IIlI[IlIII(1547909043, -676826857)] = IIIIl(IlIIl('탡', '䐲', 1106670611).toCharArray(), 69450L, IlIII(1547909040, -127518018));
      IIlI[IlIII(1547909041, 1940347146)] = IIIIl(IlIIl('碭', '䐭', -1465239773).toCharArray(), 36425L, IlIII(1547909046, -1168312388));
      IIlI[IlIII(1547909047, -1701385259)] = IIIIl(IlIIl('鳟', '䐬', -793629468).toCharArray(), 14135L, IlIII(1547909044, 1925482279));
      IIlI[IlIII(1547909045, 2011551702)] = IIIIl(IlIIl('ヲ', '䐯', -767290400).toCharArray(), 53131L, IlIII(1547909050, -440411201));
      IIlI[IlIII(1547909051, -378967593)] = IIIIl(IlIIl('黭', '䐮', -1427019164).toCharArray(), 63037L, IlIII(1547909048, -1193972366));
      IIlI[IlIII(1547909049, -632338800)] = IIIIl(IlIIl('뛑', '䐩', -243596296).toCharArray(), 45842L, IlIII(1547909054, -205490355));
      IIlI[IlIII(1547909055, -1181268726)] = IIIIl(IlIIl('蓩', '䐨', 1480001383).toCharArray(), 14527L, IlIII(1547909052, 55011051));
      IIlI[IlIII(1547909053, 786908708)] = IIIIl(IlIIl('賲', '䐫', -564912124).toCharArray(), 77915L, IlIII(1547909026, -731651504));
      IIlI[IlIII(1547909027, -713058509)] = IIIIl(IlIIl('料', '䐪', -1053144879).toCharArray(), 96424L, IlIII(1547909024, -1810973297));
      IIlI[IlIII(1547909025, 1020081849)] = IIIIl(IlIIl('\u2da7', '䐥', 575306827).toCharArray(), 67705L, IlIII(1547909030, 586259682));
      IIlI[IlIII(1547909031, 269705703)] = IIIIl(IlIIl('揷', '䐤', -339337376).toCharArray(), 16716L, IlIII(1547909028, -1971706413));
      IIlI[IlIII(1547909029, 1164977389)] = IIIIl(IlIIl('ꦼ', '䐧', -710646097).toCharArray(), 98111L, IlIII(1547909034, -1936828323));
      IIlI[IlIII(1547909035, 224160791)] = IIIIl(IlIIl('禷', '䐦', 932865716).toCharArray(), 55971L, IlIII(1547909032, -1231358933));
      IIlI[IlIII(1547909033, -823738109)] = IIIIl(IlIIl('慗', '䐡', -1481092941).toCharArray(), 41159L, IlIII(1547909038, 573101976));
      IIlI[IlIII(1547909039, -408697743)] = IIIIl(IlIIl('联', '䐠', 89986669).toCharArray(), 93925L, IlIII(1547909036, -90244351));
      IIlI[IlIII(1547909037, 1038611001)] = IIIIl(IlIIl('摟', '䐣', 159856883).toCharArray(), 71368L, IlIII(1547909074, -1489173474));
      IIlI[IlIII(1547909075, -1112411160)] = IIIIl(IlIIl('ᕣ', '䐢', -960666074).toCharArray(), 50056L, IlIII(1547909072, 221079452));
      IIlI[IlIII(1547909073, -410608204)] = IIIIl(IlIIl('뗠', '䐝', -991736523).toCharArray(), 60404L, IlIII(1547909078, -2008821056));
      IIlI[IlIII(1547909079, 2104987889)] = IIIIl(IlIIl('┎', '䐜', -219479725).toCharArray(), 91505L, IlIII(1547909076, 17544092));
   }

   private boolean IIll(class_2248 var1) {
      String var2 = class_7923.field_41175.method_10221(var1).toString().toLowerCase(Locale.ROOT);
      String var3 = class_7923.field_41175.method_10221(var1).method_12832().toLowerCase(Locale.ROOT);
      Iterator var4 = ((List)this.IIIII.III()).iterator();

      while(true) {
         if (!var4.hasNext()) {
            return false;
         }

         String var5 = (String)var4.next();
         String var6 = var5 == null ? IIlI[1] : var5.trim().toLowerCase(Locale.ROOT);
         if (!var6.isEmpty()) {
            if (var2.equals(var6) || var3.equals(var6)) {
               break;
            }

            String var7 = lIlIII.Il(IIlI[0]);
            if (var2.endsWith(var7 + var6)) {
               break;
            }
         }
      }

      return true;
   }

   public lIlIllI() {
      super((Object)lIlIII.l(IIlI[IlIII(1547909077, -61969454)]), lIllII.ll, (Object)lIlIII.l(IIlI[IlIII(1547909082, -1008753758)]));
      this.IIII = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIlI[IlIII(1547909083, -716374999)]), false));
      this.IIlII = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIlI[5]), true));
      this.IlIl = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IIlI[IlIII(1547909080, -325746024)]), (double)35.0F, (double)0.0F, (double)100.0F, (double)1.0F)).IIl(lIlIII.Il(IIlI[IlIII(1547909081, 208552193)])));
      this.l = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IIlI[IlIII(1547909086, -919766071)]), <undefinedtype>.class, null.l));
      this.IIIII = (lIIIlll)this.IIIlIll(new lIIIlll(lIlIII.l(IIlI[IlIII(1547909087, -932058525)]), List.of(), lIlIII.Il(IIlI[IlIII(1547909084, -1377260409)])));
      this.lIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIlI[IlIII(1547909085, 1295429784)]), true));
      this.III = (IIllIlIII)this.IIIlIll(new IIllIlIII(lIlIII.l(IIlI[IlIII(1547909058, -1301771112)]), new Color(IlIII(1547909059, -1834915354), IlIII(1547909056, -176389356), IlIII(1547909057, -242470170), IlIII(1547909062, 608499551))));
      this.IIlIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIlI[IlIII(1547909063, -1185467809)]), true));
      this.IlII = (IIllIlIII)this.IIIlIll(new IIllIlIII(lIlIII.l(IIlI[IlIII(1547909060, 959153792)]), new Color(IlIII(1547909061, 628135725), IlIII(1547909066, 1250992630), IlIII(1547909067, -660710334), IlIII(1547909064, -2481582))));
      this.IIIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIlI[IlIII(1547909065, -2017921375)]), true));
      this.lIlI = (IIllIlIII)this.IIIlIll(new IIllIlIII(lIlIII.l(IIlI[IlIII(1547909070, -360696944)]), new Color(IlIII(1547909071, 81453399), IlIII(1547909068, -623188815), IlIII(1547909069, -551631657), IlIII(1547909106, 1994492710))));
      this.IIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIlI[IlIII(1547909107, 1428390028)]), true));
      this.lIII = (IIllIlIII)this.IIIlIll(new IIllIlIII(lIlIII.l(IIlI[IlIII(1547909104, -1166069692)]), new Color(IlIII(1547909105, 534213617), IlIII(1547909110, 1421247313), IlIII(1547909111, 1991654857), IlIII(1547909108, -953183234))));
      this.llIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIlI[IlIII(1547909109, -728509298)]), true));
      this.IIll = (IIllIlIII)this.IIIlIll(new IIllIlIII(lIlIII.l(IIlI[IlIII(1547909114, 1709450027)]), new Color(IlIII(1547909115, 2134140586), IlIII(1547909112, -182508202), IlIII(1547909113, -139463737), IlIII(1547909118, -682320756))));
      this.lll = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIlI[IlIII(1547909119, 1099663332)]), true));
      this.IIlll = (IIllIlIII)this.IIIlIll(new IIllIlIII(lIlIII.l(IIlI[IlIII(1547909116, 726092086)]), new Color(IlIII(1547909117, 1113605910), IlIII(1547909090, 1671299741), IlIII(1547909091, 453601162), IlIII(1547909088, 1496994723))));
      this.lIll = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIlI[IlIII(1547909089, 604663316)]), true));
      this.IIllI = (IIllIlIII)this.IIIlIll(new IIllIlIII(lIlIII.l(IIlI[3]), new Color(IlIII(1547909094, 498051474), IlIII(1547909095, -181232022), IlIII(1547909092, -1792444554), IlIII(1547909093, 1671718713))));
      this.IlI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIlI[IlIII(1547909098, 909276105)]), true));
      this.llll = (IIllIlIII)this.IIIlIll(new IIllIlIII(lIlIII.l(IIlI[IlIII(1547909099, -522217596)]), new Color(IlIII(1547909096, -503205439), IlIII(1547909097, -503835842), IlIII(1547909102, -1560318574), IlIII(1547909103, 2132922001))));
      this.IlIII = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIlI[IlIII(1547909100, -1289642748)]), true));
      this.I = (IIllIlIII)this.IIIlIll(new IIllIlIII(lIlIII.l(IIlI[IlIII(1547909101, 2104682120)]), new Color(IlIII(1547908882, 189868554), IlIII(1547908883, 539814509), IlIII(1547908880, -1837271899), IlIII(1547908881, -1706737260))));
      this.IllI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIlI[IlIII(1547908886, 1246055167)]), true));
      this.lIIl = (IIllIlIII)this.IIIlIll(new IIllIlIII(lIlIII.l(IIlI[2]), new Color(IlIII(1547908887, -334901256), IlIII(1547908884, 2115884862), IlIII(1547908885, -703653323), IlIII(1547908890, 125828348))));
      this.II = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIlI[IlIII(1547908891, -1741842012)]), true));
      this.Ill = (IIllIlIII)this.IIIlIll(new IIllIlIII(lIlIII.l(IIlI[4]), new Color(IlIII(1547908888, -495335880), IlIII(1547908889, -1359220447), IlIII(1547908894, 1291216700), IlIII(1547908895, 311360445))));
      this.llII = new ArrayDeque();
      this.lI = new HashMap();
      this.llI = IlIII(1547908892, 1507728942);
      this.IIIIl = IlIII(1547908893, 316172366);
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (this.IIIIIlI()) {
         boolean var2 = this.lllI != var1.field_1687;
         if (var2) {
            this.IlIl();
            this.lllI = var1.field_1687;
         }

         if (var1.field_1724 != null && var1.field_1687 != null) {
            class_2338 var3 = var1.field_1724.method_24515();
            int var4 = var3.method_10263() >> 4;
            int var5 = var3.method_10260() >> 4;
            boolean var6 = var4 != this.llI || var5 != this.IIIIl;
            if (!var2 && !var6) {
               if (this.llII.isEmpty()) {
                  if (this.Il++ < IlIII(1547908866, 438031491)) {
                     return;
                  }

                  this.lIIl(var1, var4, var5);
               }
            } else {
               this.lIIl(var1, var4, var5);
            }

            this.IlII(var1, var3);
         }
      }
   }

   private void IlII(class_310 var1, class_2338 var2) {
      boolean var3 = !this.llII.isEmpty();
      int var4 = 0;

      while(var4 < 2 && !this.llII.isEmpty()) {
         <undefinedtype> var5 = (<undefinedtype>)this.llII.removeFirst();
         long var6 = lIII(var5.l(), var5.I());
         class_2818 var8 = var1.field_1687.method_2935().method_21730(var5.l(), var5.I());
         if (var8 == null) {
            this.lI.remove(var6);
         } else {
            this.IlI(var1, var2, var5, var8);
            ++var4;
         }
      }

      if (var3 && this.llII.isEmpty()) {
         this.Il = 1;
      }

   }

   private void IlIl() {
      this.llII.clear();
      this.lI.clear();
      this.lllI = null;
      this.llI = IlIII(1547908867, -850611874);
      this.IIIIl = IlIII(1547908864, 1869411920);
      this.Il = 0;
   }

   private Color Illl(class_2248 var1) {
      if ((var1 == class_2246.field_10442 || var1 == class_2246.field_29029) && (Boolean)this.IIIl.III()) {
         return (Color)this.lIlI.III();
      } else if ((var1 == class_2246.field_10013 || var1 == class_2246.field_29220) && (Boolean)this.IIl.III()) {
         return (Color)this.lIII.III();
      } else if ((var1 == class_2246.field_10571 || var1 == class_2246.field_29026 || var1 == class_2246.field_23077) && (Boolean)this.llIl.III()) {
         return (Color)this.IIll.III();
      } else if ((var1 == class_2246.field_10212 || var1 == class_2246.field_29027) && (Boolean)this.lll.III()) {
         return (Color)this.IIlll.III();
      } else if ((var1 == class_2246.field_10080 || var1 == class_2246.field_29030) && (Boolean)this.IlI.III()) {
         return (Color)this.llll.III();
      } else if ((var1 == class_2246.field_10090 || var1 == class_2246.field_29028) && (Boolean)this.lIll.III()) {
         return (Color)this.IIllI.III();
      } else if ((var1 == class_2246.field_10418 || var1 == class_2246.field_29219) && (Boolean)this.lIl.III()) {
         return (Color)this.III.III();
      } else if ((var1 == class_2246.field_27120 || var1 == class_2246.field_29221) && (Boolean)this.IIlIl.III()) {
         return (Color)this.IlII.III();
      } else if (var1 == class_2246.field_22109 && (Boolean)this.IlIII.III()) {
         return (Color)this.I.III();
      } else {
         return (var1 == class_2246.field_33509 || var1 == class_2246.field_33508 || var1 == class_2246.field_33510) && (Boolean)this.IllI.III() ? (Color)this.lIIl.III() : (Color)this.Ill.III();
      }
   }

   private static long lIII(int var0, int var1) {
      return (long)var0 & 4294967295L | (long)var1 << IlIII(1547908865, 1568432582);
   }

   public void lI() {
      if (Illl == this) {
         Illl = null;
      }

      this.IlIl();
      this.llII();
   }

   private void lIIl(class_310 var1, int var2, int var3) {
      this.llII.clear();
      this.llI = var2;
      this.IIIIl = var3;
      this.Il = 0;
      int var4 = (Integer)var1.field_1690.method_42503().method_41753();
      int var5 = Math.max(1, Math.min(var4, IlIII(1547908870, 1316857769)));
      int var6 = var5 * 2 + 1;
      ArrayList var7 = new ArrayList(var6 * var6);

      for(int var8 = var2 - var5; var8 <= var2 + var5; ++var8) {
         for(int var9 = var3 - var5; var9 <= var3 + var5; ++var9) {
            int var10 = var8 - var2;
            int var11 = var9 - var3;
            var7.add(new Record(var8, var9, var10 * var10 + var11 * var11) {
               private final int I;
               private final int l;
               private final int II;

               public int I() {
                  return this.I;
               }

               public int l() {
                  return this.l;
               }

               public int II() {
                  return this.II;
               }

               private {
                  this.l = var1;
                  this.I = var2;
                  this.II = var3;
               }
            });
         }
      }

      var7.sort(Comparator.comparingInt(<undefinedtype>::II));
      this.llII.addAll(var7);
      this.lI.keySet().removeIf((var3x) -> {
         long var4 = (long)IIlll(var3x) - (long)var2;
         long var6 = (long)IIllI(var3x) - (long)var3;
         return var4 < (long)(-var5) || var4 > (long)var5 || var6 < (long)(-var5) || var6 > (long)var5;
      });
   }

   public void llIl(llIIllI var1) {
      this.lllI(var1);
   }

   private void llII() {
      class_310 var1 = class_310.method_1551();
      if (var1 != null && var1.field_1769 != null) {
         var1.field_1769.method_3279();
      }

   }

   public void lllI(Object var1) {
      if (this.IIIIIlI() && ((Boolean)this.IIII.III() || (Boolean)this.IIlII.III()) && IIlIIIIl.IlIII(var1)) {
         class_310 var2 = class_310.method_1551();
         if (var2.field_1724 != null && var2.field_1687 != null) {
            if (this.lllI != var2.field_1687) {
               this.IlIl();
            } else {
               class_2338 var3 = var2.field_1724.method_24515();
               double var4 = (Double)this.IlIl.III() / (double)100.0F * (double)255.0F;
               int var6 = (Integer)var2.field_1690.method_42503().method_41753();
               int var7 = Math.max(1, Math.min(var6, IlIII(1547908871, 992581346)));
               int var8 = var7 * IlIII(1547908868, -1632139202);
               int var9 = var8 * var8;
               int var10 = Math.max(var2.field_1687.method_31607(), var3.method_10264() - IlIII(1547908869, 826228540));
               int var11 = Math.min(var2.field_1687.method_31600(), var3.method_10264() + IlIII(1547908874, 378829556));

               for(Map.Entry var13 : this.lI.entrySet()) {
                  int var14 = IIlll((Long)var13.getKey());
                  int var15 = IIllI((Long)var13.getKey());
                  int var16 = var14 << 4;
                  int var17 = var15 << 4;
                  class_238 var18 = new class_238((double)var16, (double)var10, (double)var17, (double)var16 + (double)16.0F, (double)var11 + (double)1.0F, (double)var17 + (double)16.0F);
                  if (IIlIIIIl.IIIl(var1, var18)) {
                     for(<undefinedtype> var20 : (List)var13.getValue()) {
                        class_2338 var21 = var20.I();
                        int var22 = var21.method_10263() - var3.method_10263();
                        int var23 = var21.method_10260() - var3.method_10260();
                        if (var22 * var22 + var23 * var23 <= var9 && var21.method_10264() >= var10 && var21.method_10264() <= var11 && this.IIlII(var20.l())) {
                           class_238 var24 = new class_238(var21);
                           if (IIlIIIIl.IIIl(var1, var24)) {
                              Color var25 = this.lII(this.Illl(var20.l()), this.IIIII(var21));
                              this.IIlIl(var1, var24, var25, var4);
                           }
                        }
                     }
                  }
               }

            }
         }
      }
   }

   private double IIIII(class_2338 var1) {
      return (double)var1.method_10263() * 0.061 + (double)var1.method_10264() * 0.021 + (double)var1.method_10260() * 0.043;
   }

   private static String IIIIl(char[] var0, long var1, int var3) {
      int var4 = IlIII(1547908875, -1306909639) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IlIII(1547908872, -1325432690);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private boolean IIIll(class_2248 var1) {
      if ((var1 == class_2246.field_10442 || var1 == class_2246.field_29029) && (Boolean)this.IIIl.III()) {
         return true;
      } else if ((var1 == class_2246.field_10013 || var1 == class_2246.field_29220) && (Boolean)this.IIl.III()) {
         return true;
      } else if ((var1 == class_2246.field_10571 || var1 == class_2246.field_29026 || var1 == class_2246.field_23077) && (Boolean)this.llIl.III()) {
         return true;
      } else if ((var1 == class_2246.field_10212 || var1 == class_2246.field_29027) && (Boolean)this.lll.III()) {
         return true;
      } else if ((var1 == class_2246.field_10080 || var1 == class_2246.field_29030) && (Boolean)this.IlI.III()) {
         return true;
      } else if ((var1 == class_2246.field_10090 || var1 == class_2246.field_29028) && (Boolean)this.lIll.III()) {
         return true;
      } else if ((var1 == class_2246.field_10418 || var1 == class_2246.field_29219) && (Boolean)this.lIl.III()) {
         return true;
      } else if ((var1 == class_2246.field_27120 || var1 == class_2246.field_29221) && (Boolean)this.IIlIl.III()) {
         return true;
      } else if (var1 == class_2246.field_22109 && (Boolean)this.IlIII.III()) {
         return true;
      } else if ((var1 == class_2246.field_33509 || var1 == class_2246.field_33508 || var1 == class_2246.field_33510) && (Boolean)this.IllI.III()) {
         return true;
      } else {
         String var2 = class_7923.field_41175.method_10221(var1).method_12832().toLowerCase(Locale.ROOT);
         return (Boolean)this.II.III() && (var2.endsWith(lIlIII.Il(IIlI[IlIII(1547908873, -771715160)])) || var2.equals(lIlIII.Il(IIlI[IlIII(1547908878, 1206628240)])));
      }
   }

   private boolean IIlII(class_2248 var1) {
      if (var1 != null && !var1.method_9564().method_26215()) {
         return this.IIll(var1) || this.IIIll(var1);
      } else {
         return false;
      }
   }

   private void IIlIl(Object var1, class_238 var2, Color var3, double var4) {
      if ((Boolean)this.IIII.III()) {
         if (this.l.III() == null.lI) {
            IIlIIIIl.IIll(var1, var2.method_1014(0.035), IIlIIllIl.IlI(var3, 0.78), var4 * 0.78);
         }

         IIlIIIIl.IIll(var1, var2, var3, var4);
      }

      if ((Boolean)this.IIlII.III()) {
         if (this.l.III() == null.lI) {
            IIlIIIIl.I(var1, var2.method_1014(0.035), IIlIIllIl.IlI(var3, 0.72), (double)165.0F, 3.0F);
         }

         IIlIIIIl.I(var1, var2, var3, (double)255.0F, this.l.III() == null.lI ? 2.4F : 2.0F);
      }

   }

   private static int IIllI(long var0) {
      return (int)(var0 >> IlIII(1547908879, 344890547));
   }

   private static int IIlll(long var0) {
      return (int)var0;
   }

   private static int IlIII(int var0, int var1) {
      return IlIIl[var0 ^ 1547909010] ^ var1 ^ var0;
   }

   private static String IlIIl(char var0, char var1, int var2) {
      int var3 = var1 ^ 17469;
      char[] var4 = IlIlI[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])IlIll[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         IlIll[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 5179;
      int var9 = 0;

      do {
         int var10 = var4[var9] - '\uece5';
         var10 -= 19819;
         var10 -= 28238;
         var10 += 62673;
         var10 -= 52150;
         var10 -= 35428;
         var10 ^= 32270;
         var10 -= 63733;
         var10 -= 25119;
         var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var2 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
