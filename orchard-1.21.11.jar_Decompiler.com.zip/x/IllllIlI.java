package x;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.awt.image.BufferedImage;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Locale;
import java.util.Objects;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1011;
import net.minecraft.class_10590;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1661;
import net.minecraft.class_1675;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2680;
import net.minecraft.class_276;
import net.minecraft.class_2777;
import net.minecraft.class_2824;
import net.minecraft.class_2828;
import net.minecraft.class_2846;
import net.minecraft.class_2868;
import net.minecraft.class_2885;
import net.minecraft.class_2886;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_636;
import net.minecraft.class_744;
import net.minecraft.class_746;
import net.minecraft.class_7923;
import net.minecraft.class_9331;
import net.minecraft.class_9334;
import net.minecraft.class_9779;
import net.minecraft.class_239.class_240;
import net.minecraft.class_2846.class_2847;
import net.minecraft.class_3675.class_307;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;
import org.lwjgl.glfw.GLFW;
import y.lllIllIl;

@Environment(EnvType.CLIENT)
public final class IllllIlI {
   private static final Method I;
   private static long l;
   private static final Method II;
   private static <undefinedtype> Il;
   private static long ll;
   private static int III;
   private static final Method IIl;
   private static int IlI;
   private static final Field Ill;
   private static final Field lII;
   private static boolean lIl;
   private static long llI;
   private static int lll;
   private static long IIII;
   private static int IIIl;
   private static int IIlI;
   private static final Field IIll;
   private static int IlII;
   private static boolean IlIl;
   private static final IlIlIII IllI;
   private static final boolean[] Illl;
   private static final ConcurrentLinkedQueue<<undefinedtype>> lIII;
   private static boolean lIIl;
   private static volatile class_9331<?> lIlI;
   private static final Method lIll;
   private static boolean llII;
   private static boolean llIl;
   public static final double lllI = 0.9;
   private static final Method llll;
   private static final <undefinedtype> IIIII;
   private static int IIIIl;
   private static final Field IIIlI;
   private static final Method IIIll;
   private static final Method IIlII;
   private static boolean IIlIl;
   private static final Field IIllI;
   private static final Field IIlll;
   private static final boolean[] IlIII;
   private static boolean IlIIl;
   private static final Method IlIlI;
   private static int IlIll;
   private static final Method IllII;
   private static final Field IllIl;
   private static boolean IlllI;
   private static int Illll;
   private static long lIIII;
   private static final Method lIIIl;
   private static final Field lIIlI;
   private static final Field lIIll;
   private static final int[] lI;
   private static final String[] lIlII;
   private static final Object[] lIlIl;

   private static boolean I(class_310 var0) {
      ++IIIl;

      boolean var1;
      try {
         if (var0 != null && var0.field_1724 != null && var0.field_1761 != null) {
            class_1297 var6 = llIII(var0);
            if (llI(var0, var6)) {
               boolean var7 = false;
               return var7;
            }

            boolean var2 = IllIll(var0);
            return var2;
         }

         var1 = false;
      } finally {
         IIIl = Math.max(0, IIIl - 1);
      }

      return var1;
   }

   public static boolean l(class_1309 var0, class_746 var1) {
      if (var0 != null && var1 != null && lllllI(var0)) {
         double var2 = var1.method_23317() - var0.method_23317();
         double var4 = var1.method_23321() - var0.method_23321();
         double var6 = var2 * var2 + var4 * var4;
         if (var6 < 1.0E-5) {
            return true;
         } else {
            double var8 = (double)1.0F / Math.sqrt(var6);
            double var10 = var2 * var8;
            double var12 = var4 * var8;
            float var14 = var0.method_5705(1.0F);
            float var15 = -var14 * ((float)Math.PI / 180F);
            double var16 = Math.sin((double)var15);
            double var18 = Math.cos((double)var15);
            return var16 * var10 + var18 * var12 > (double)0.0F;
         }
      } else {
         return false;
      }
   }

   public static boolean II() {
      return IlIIl;
   }

   public static void Il() {
      IIIIl = Math.max(0, IIIIl - 1);
   }

   public static <undefinedtype> lI(class_310 var0, Object var1, int var2, Object var3, int var4, boolean var5, Runnable var6) {
      // $FF: Couldn't be decompiled
   }

   public static boolean ll(class_1297 var0) {
      if (var0 != null && var0.method_73183() != null) {
         class_238 var1 = var0.method_5829();
         class_2338 var2 = class_2338.method_49637(var1.field_1323, var1.field_1322, var1.field_1321);
         class_2338 var3 = class_2338.method_49637(var1.field_1320 - 1.0E-7, var1.field_1325 - 1.0E-7, var1.field_1324 - 1.0E-7);

         for(class_2338 var5 : class_2338.method_10097(var2, var3)) {
            if (var0.method_73183().method_8320(var5).method_27852(class_2246.field_10343)) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public static void III() {
      llII = false;
      lIII.clear();
      IllI.IllI();
      Illll = -1;
      lll = IllIllI(516732909, -580389838);
      ll = Long.MIN_VALUE;
      IIllIlll.IIlI();
      III = 0;
      IlII = 0;
      IIIIl = 0;
      lIl = false;
      llIl = false;
      Il = null;
      IlllI = false;
      IlIll = -1;
      IIlIl = false;
      lIIl = false;
   }

   public static boolean IIl(class_310 var0) {
      if (var0 != null && var0.field_1724 != null && var0.method_1562() != null) {
         var0.method_1562().method_52787(new class_2846(class_2847.field_12974, class_2338.field_10980, class_2350.field_11033));
         return true;
      } else {
         return false;
      }
   }

   public static void IlI(class_310 var0, int var1) {
      if (var0 != null && var0.field_1724 != null && var1 > 0) {
         IlI = Math.max(IlI, var0.field_1724.field_6012 + var1);
      }

   }

   public static <undefinedtype> Ill(class_310 var0, Object var1, int var2) {
      return lIll(var0, var1, var2, 0, true);
   }

   private static Field lII(Class<?> var0, String var1) {
      for(Class var2 = var0; var2 != null; var2 = var2.getSuperclass()) {
         try {
            Field var3 = var2.getDeclaredField(var1);
            var3.setAccessible(true);
            return var3;
         }
      }

      return null;
   }

   public static boolean lIl(class_1799 var0) {
      if (var0 != null && !var0.method_7960()) {
         class_9331 var1 = IIIIl();
         if (var1 == null) {
            return false;
         } else {
            class_10590 var3 = (class_10590)var0.method_58694(var1);
            return var3 != null && var3.comp_3602() > 0.0F;
         }
      } else {
         return false;
      }
   }

   public static boolean llI(class_310 var0, class_1297 var1) {
      lIllIIl var2 = lIllIIl.Il();
      return var2 != null && var2.IIl() != null && var2.IIl().IIIlIII() != null && var2.IIl().IIIlIII().lllll(var0, var1);
   }

   public static void lll(class_310 var0, double var1, double var3, double var5, boolean var7) {
      if (var0 != null && var0.method_1562() != null) {
         try {
            Class var8 = class_2828.class_2829.class;

            try {
               Constructor var12 = var8.getConstructor(Double.TYPE, Double.TYPE, Double.TYPE, Boolean.TYPE, Boolean.TYPE);
               var0.method_1562().method_52787((class_2596)var12.newInstance(var1, var3, var5, var7, false));
               return;
            } catch (NoSuchMethodException var10) {
               Constructor var9 = var8.getConstructor(Double.TYPE, Double.TYPE, Double.TYPE, Boolean.TYPE);
               var0.method_1562().method_52787((class_2596)var9.newInstance(var1, var3, var5, var7));
            }
         } catch (Exception var11) {
         }

      }
   }

   public static boolean IIII(class_310 var0, Object var1) {
      if (var0 != null && var0.field_1724 != null && var1 != null && var1.III()) {
         <undefinedtype> var2 = var1.IIl();
         if (var2 == null) {
            return lIIlI(var0.field_1724.method_31548()) == var1.ll();
         } else {
            return var2.II() < 0L ? (var0.new null(var0) {
               private final class_310 I;
               private static final int[] l;

               public int I() {
                  return IIlllllI.IIIl(this.I.field_1724.method_31548());
               }

               public int l() {
                  return IllllIlI.Illll >= 0 && IllllIlI.Illll < ll(2051093048, -579120194) ? IllllIlI.Illll : this.I();
               }

               public void II(Object var1, int var2) {
                  switch (var1) {
                     case II:
                        IllllIlI.IIlIlI(this.I, var2, true);
                        break;
                     case lI:
                        IllllIlI.IlIllll(this.I, var2);
                        IllllIlI.IIlIlI(this.I, var2, false);
                        break;
                     case I:
                        int var3 = IIllIlll.lII();
                        if (var3 != var2 && (var3 >= 0 || this.l() != var2)) {
                           IIllIlll.Ill(var2);
                           ++IllllIlI.IlII;

                           try {
                              this.I.method_1562().method_52787(new class_2868(var2));
                           } finally {
                              IllllIlI.IlII = Math.max(0, IllllIlI.IlII - 1);
                           }
                        } else {
                           IIllIlll.Ill(var2);
                        }

                        lIllIIl var4 = lIllIIl.Il();
                        if (var4 != null && var4.IIl() != null && var4.IIl().IllllI() != null && var4.IIl().IllllI().IIIIIlI()) {
                           var4.IIl().IllllI().llI(var2);
                        }
                  }

               }

               public int Il() {
                  return this.I != null && this.I.field_1724 != null ? this.I.field_1724.field_6012 : 0;
               }

               private {
                  this.I = var1;
               }

               public boolean lI(Object var1, int var2) {
                  if (var1 == null.I) {
                     if (this.l() != var2 && IIllIlll.lII() != var2) {
                        if (IIllIlll.lII() != var2) {
                           this.II(var1, var2);
                        }

                        return false;
                     } else {
                        return true;
                     }
                  } else {
                     return this.I() == var2;
                  }
               }

               private static int ll(int var0, int var1) {
                  return l[var0 ^ 2051093048] ^ var1 ^ var0;
               }

               static {
                  int var2 = -658501509;
                  byte[] var0 = "\u007fúqô".getBytes("ISO-8859-1");
                  int var1 = var0.length / 4;
                  l = new int[var1];
                  int var3 = 0;
                  int var4 = 0;

                  do {
                     int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
                     var5 ^= var2;
                     l[var4] = var5;
                     var3 += 4;
                     ++var4;
                  } while(var4 < var1);

               }
            }).lI(null.I, var1.ll()) : IllI.lIl(var2);
         }
      } else {
         return false;
      }
   }

   private static void IIIl() {
      llII |= IllI.Ill();
      Il = null;
      IlllI = false;
      III = 0;
      IIIIl = 0;
      lIl = false;
      IllI.IllI();
      IlIlIl.IlIIl();
   }

   private static void IIlI(class_310 var0) {
      lIllIIl var1 = lIllIIl.Il();
      if (var1 != null && var1.IIl() != null) {
         IlllIllI var2 = var1.IIl().IlIlIl();
         if (var2 != null && var2.IIIIIlI() && var2.IIIIIII()) {
            var2.IlI(var0);
         }

      }
   }

   public static void IIll(class_310 var0) {
      if (llII) {
         llII = false;
         if (var0 != null && var0.field_1724 != null && var0.method_1562() != null) {
            int var1 = IIlllllI.IIIl(var0.field_1724.method_31548());
            if (var1 >= 0 && var1 <= IllIllI(516732908, -1174323437)) {
               (var0.new null(var0) {
                  private final class_310 I;
                  private static final int[] l;

                  public int I() {
                     return IIlllllI.IIIl(this.I.field_1724.method_31548());
                  }

                  public int l() {
                     return IllllIlI.Illll >= 0 && IllllIlI.Illll < ll(2051093048, -579120194) ? IllllIlI.Illll : this.I();
                  }

                  public void II(Object var1, int var2) {
                     switch (var1) {
                        case II:
                           IllllIlI.IIlIlI(this.I, var2, true);
                           break;
                        case lI:
                           IllllIlI.IlIllll(this.I, var2);
                           IllllIlI.IIlIlI(this.I, var2, false);
                           break;
                        case I:
                           int var3 = IIllIlll.lII();
                           if (var3 != var2 && (var3 >= 0 || this.l() != var2)) {
                              IIllIlll.Ill(var2);
                              ++IllllIlI.IlII;

                              try {
                                 this.I.method_1562().method_52787(new class_2868(var2));
                              } finally {
                                 IllllIlI.IlII = Math.max(0, IllllIlI.IlII - 1);
                              }
                           } else {
                              IIllIlll.Ill(var2);
                           }

                           lIllIIl var4 = lIllIIl.Il();
                           if (var4 != null && var4.IIl() != null && var4.IIl().IllllI() != null && var4.IIl().IllllI().IIIIIlI()) {
                              var4.IIl().IllllI().llI(var2);
                           }
                     }

                  }

                  public int Il() {
                     return this.I != null && this.I.field_1724 != null ? this.I.field_1724.field_6012 : 0;
                  }

                  private {
                     this.I = var1;
                  }

                  public boolean lI(Object var1, int var2) {
                     if (var1 == null.I) {
                        if (this.l() != var2 && IIllIlll.lII() != var2) {
                           if (IIllIlll.lII() != var2) {
                              this.II(var1, var2);
                           }

                           return false;
                        } else {
                           return true;
                        }
                     } else {
                        return this.I() == var2;
                     }
                  }

                  private static int ll(int var0, int var1) {
                     return l[var0 ^ 2051093048] ^ var1 ^ var0;
                  }

                  static {
                     int var2 = -658501509;
                     byte[] var0 = "\u007fúqô".getBytes("ISO-8859-1");
                     int var1 = var0.length / 4;
                     l = new int[var1];
                     int var3 = 0;
                     int var4 = 0;

                     do {
                        int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
                        var5 ^= var2;
                        l[var4] = var5;
                        var3 += 4;
                        ++var4;
                     } while(var4 < var1);

                  }
               }).II(null.I, var1);
            }
         }
      }
   }

   public static void IlII(class_310 var0, Object var1, Object var2) {
      if (var0 != null && var0.field_1724 != null && var1 != null) {
         <undefinedtype> var3 = var2 == null ? null.II : var2;
         <undefinedtype> var4 = Il;
         if (var4 != null && var4.I().l() == var1) {
            if (var3 == null.II) {
               return;
            }

            Il = null;
            IlllI = false;
         }

         int var5 = var3 == null.Il && IllI.llII(var1) == null.I ? IllI.lIlI(var1) : -1;
         IllI.IIII(var0.new null(var0) {
            private final class_310 I;
            private static final int[] l;

            public int I() {
               return IIlllllI.IIIl(this.I.field_1724.method_31548());
            }

            public int l() {
               return IllllIlI.Illll >= 0 && IllllIlI.Illll < ll(2051093048, -579120194) ? IllllIlI.Illll : this.I();
            }

            public void II(Object var1, int var2) {
               switch (var1) {
                  case II:
                     IllllIlI.IIlIlI(this.I, var2, true);
                     break;
                  case lI:
                     IllllIlI.IlIllll(this.I, var2);
                     IllllIlI.IIlIlI(this.I, var2, false);
                     break;
                  case I:
                     int var3 = IIllIlll.lII();
                     if (var3 != var2 && (var3 >= 0 || this.l() != var2)) {
                        IIllIlll.Ill(var2);
                        ++IllllIlI.IlII;

                        try {
                           this.I.method_1562().method_52787(new class_2868(var2));
                        } finally {
                           IllllIlI.IlII = Math.max(0, IllllIlI.IlII - 1);
                        }
                     } else {
                        IIllIlll.Ill(var2);
                     }

                     lIllIIl var4 = lIllIIl.Il();
                     if (var4 != null && var4.IIl() != null && var4.IIl().IllllI() != null && var4.IIl().IllllI().IIIIIlI()) {
                        var4.IIl().IllllI().llI(var2);
                     }
               }

            }

            public int Il() {
               return this.I != null && this.I.field_1724 != null ? this.I.field_1724.field_6012 : 0;
            }

            private {
               this.I = var1;
            }

            public boolean lI(Object var1, int var2) {
               if (var1 == null.I) {
                  if (this.l() != var2 && IIllIlll.lII() != var2) {
                     if (IIllIlll.lII() != var2) {
                        this.II(var1, var2);
                     }

                     return false;
                  } else {
                     return true;
                  }
               } else {
                  return this.I() == var2;
               }
            }

            private static int ll(int var0, int var1) {
               return l[var0 ^ 2051093048] ^ var1 ^ var0;
            }

            static {
               int var2 = -658501509;
               byte[] var0 = "\u007fúqô".getBytes("ISO-8859-1");
               int var1 = var0.length / 4;
               l = new int[var1];
               int var3 = 0;
               int var4 = 0;

               do {
                  int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
                  var5 ^= var2;
                  l[var4] = var5;
                  var3 += 4;
                  ++var4;
               } while(var4 < var1);

            }
         }, var1, var3);
         if (var5 >= 0 && var5 < IllIllI(516732911, 1311967473)) {
            IIlllllI.llII(var0.field_1724.method_31548(), var5);
            if (var0.field_1761 != null) {
               IIlllllI.lIll(var0.field_1761, var5);
            }
         }
      }

   }

   public static boolean IlIl() {
      return lIIl && IIllIlll.lll(lIIII);
   }

   private static Double IllI(Object var0, String var1, String var2) {
      try {
         return ((Number)var0.getClass().getMethod(var1).invoke(var0)).doubleValue();
      } catch (ReflectiveOperationException var6) {
         try {
            return ((Number)var0.getClass().getMethod(var2).invoke(var0)).doubleValue();
         } catch (ReflectiveOperationException var5) {
            try {
               Field var3 = var0.getClass().getDeclaredField(var2);
               var3.setAccessible(true);
               return ((Number)var3.get(var0)).doubleValue();
            } catch (ReflectiveOperationException var4) {
               return null;
            }
         }
      }
   }

   public static float Illl(class_2596<?> var0) {
      Float var1 = lIIlll(var0, lIlIII.Il(IllIlll(-338508948, 1948732918)), lIlIII.Il(IllIlll(-338508947, -176872525)));
      return var1 != null ? var1 : Float.NaN;
   }

   public static boolean lIII(class_2680 var0) {
      return var0 == null || var0.method_26215() || var0.method_27852(class_2246.field_10036) || var0.method_27852(class_2246.field_22089);
   }

   static {
      short var26 = 4803;
      String var27 = "圹圐圳垨坹坨坓坁坽圵垍垱홬혽혖훺혷혀혆홪窺竕突稫章竂窠窽竾窜稉稱ꘕ\ua63cꘟꚄꙕ꙾ꙅꙋꙒ\ua633ꛛꛤꚣꘅ꘦ꛁꘈꘛꙣꙪĲĜĿƼŪŴŭōŲēƹǫƅĵİǞ荮荀荣菠茶茨茱茑茮荏菥获菙荩荬莂䶟䷛䶥䴎䷂䷜䷧䷲䷔䶎䴑䵐䴭䷣䷫䵷䶅䷙䷙䷈\udabd\udaf9\uda87\uda2c\udae0\udafe\udac5\udad0\udaf6\udaac\uda33\uda61\uda0c\udaaf\uda8c\uda79\udaa4\udac6\udaff\udac3\uda06\udab4\udaea\udaa8ޜߘަ܍߁ߟߤ߱ߗލܒ݃ܨގޡݵރߤߗޗ쮊쯎쮰쬛쯗쯉쯲쯧쯁쮛쬄쭕쬾쮘쮷쭣쮕쯲쯁쮁䁙䀵䀤䃛䀀䀈䁀䀊䀉䀝䃤䂤䃳䁂䀣䃁\udb8e\udba1\udbf4\udb38\udbd5\udbe3\udbd1\udbe6\udbc0\udbbf\udb01\udb69\udb33\udb89\udbbe\udb48\udb85\udbf0\udbaa\udbef\udb33\udbb4\udbdc\udb9e\uf48f\uf4a4\uf4b1\uf472\uf4d2\uf4cf\uf4e7\uf4df\uf4cd\uf491\uf405\uf47d\uf438\uf4f2\uf4ba\uf44c쌴쌚쌹쎢썵썘썣썀썻쌆쏠쏕쎆썍쌌쏵쌬썳쌂쌺挃挭挎掕捀捯捄捙捃挡揗揦掺挔挅揯挚捀据捸➇➮➍✖⟃⟬⟇⟚⟀➢❔❥✹➗➆❬➙⟃⟭⟻㵂㴭㵹㷀㴛㴁㴫㴪㴂㵂㶙㷉۟ڍێٚڃڡڄڽڟۭ٪ؘ٩ۋ۸ـ\uee27\uee75\uee36\ueea2\uee7b\uee59\uee4e\uee4f\uee64\uee06\ueeac\ueee0\uee91\uee33\uee00\ueeb8뀺끮뀢날끣끯끖끗끼뀞내냸낉뀫뀘날\u2e68⸆\u2e60\u2efb\u2e68⸑⸐⸳⸣\u2e76⻢⺊⻟⹐⸘⺩\u2e71\u2e68⹕⸺⻒⹀⹅⸒⺘\u2e6f⻌⻇⺰⺪⺺⻧\u2e65\u2e76\u2e7b⺧\u2e61⸝⹁⸽⸧⹅⻀⺣⻊⸈⸶⺊⹍⹐⹂\u2e64⻰⸴\u2e6b\u2e63⻌\u2e67⻧⺞蚊蛘蚔蘸蛑蛎蛖蛧蛎蚒蘆虨蘾蚫蚱虹蚓蛴蛡蚇㤶㥤㤨㦄㥭㥲㥪㥛㥲㤮㦺㧔㦂㤗㤍㧅㤯㥈㥝㤻뢬룾뢲렞룷루룰룁루뢴렠롎렘뢍뢗롟뢵룒룇뢡\uef9c\uefdc\uefb1\uef66\uefc6\uefdb\ueff3\uefcb\uefd9\uef85\uef11\uef69\uef2c\uefe6\uefae\uef58俓俹俨佅侊侐侔侉侒俦佘伇佥侭侢伹俏侩侙俙䚴䛰䚬䘀䛩䛶䛲䛯䛴䚀䘾䙡䘏䚥䛀䙟䚮䛲䛕䚿໌\u0ee6\u0ef7๚ຕຏ\u0e8bຖຍ\u0ef9็ธ\u0e7aາຽจ໐ີຆໆ妸妒妃央姡姻姿姢姹妍夳奬夎姆姉奼妤姁姲妲\ufaf1齃\ufafb褐蝹漢廙絛視\ufaf2諸勇梅頋\ufade喝\ue64e\ue61f\ue637\ue6df\ue615\ue608\ue65f\ue64b팡팋팚펣퍽퍠팷팣伷企何価佷佩佤佐佼伞侞俄侒伨佞俔似佅佴佗侑伸伭佣俟佷俖侼俲侲係侧伧佖伮俰伢併佂佩伮但俷俦侁佚佳俢伂住伡伣侴伈佄伢俐佽侇侦俾侉俐侧伟会你俉伭位伲伓伃佀侪侐俊佯佂俧佭佴估伏侦伙使伱镸锍镇閄锧锊锁锴锐镭閴閼闁镥锑闰镵锛键镪乲丄乐仙丷个乽乩୮ତ\u0b7e\u0bddଷଡର\u0b7eଃ\u0b79\u0bfcபொ୯\u0b0e௬鎀鏱鏢錵鏙鏏鎇鏻鏨鎿錵鍃錢鏢鎷錇쌳썗썔쎎썮썾썗썬썽쌙쎋쎨쎋쌂쌖쎴肀胤肢耢胚胳胅胾\ueaa0\uea96\ueab7\uea19\ueabc\ueaef\ueaa8\ueabc홷혴홿횟骈髎骴騙髖髊骑髻髼骮騊騀뒸뒑뒲됩듿듹듴듀듾뒝됴둂됃뒨뒌될ǘǶǫūƀƞơƷꉉꉠꉃꋘꈋꈈꈉꈴ梏检梜栒ⱭⰼⰔ⳼ⰶⰫⱼⱨ\uf56e\uf544\uf555\uf5ec\uf532\uf52f\uf578\uf56c汢氳氛泳氹氤汳汧羞羴羥缜翂翟羈羜⁒›⁌⃟\u200d‗  \uf0f7\uf0dd\uf0c0\uf072\uf0ad\uf08f\uf0e9\uf09bஞ\u0bcf\u0ba1ଁே\u0bdb\u0b80ீௐகଵ\u0b11⧈⦙⧷⥗⩞⨈⩔⫗⨅⨏⨑⩟㍛㍵㍖㏍㌘㌧㌮㌴㌞㍻㏮㎾㏦㍡㌦㏄ꖛꖲꖑꔊꗙꗉꖎꖚ욆웒웾왢餞餷餔馏饜饜餋餟뗅떁떽딡ଛଲ\u0b11ஊ\u0b59୯\u0b0eଚṪḘḒẎ鸰鹘鸮麽鹯鹵鹤鹍嵑嵻嵦巔崋崩嵏崽㳺㲫㳅㱥㲣㲿㳤㲤㲴㳱㱑㱵\ue79b\ue7ca\ue7a4\ue704１ｇ；ﾘｊ｀～０췕춄췶쵔춈춓춂춨춦췴쵼촯쵨췁췦쵊垫埇垓圼埰埀埫埑埬垞坳圣\ue4aa\ue4c5\ue4b3\ue421\ue4f7\ue4cd\ue4b4\ue4c2\ue4e9\ue4b5\ue42b\ue421ᕟᔋᕗᗞᔆᔏᕈᕜ锥镎镟閦镼镰锺锣\ue530\ue562\ue521\ue5b5\ue56f\ue553\ue56f\ue56e\ue57e\ue52b\ue5a7\ue5fa\ue587\ue549\ue541\ue5dd\ue52f\ue573\ue573\ue562貫賹貺谮賴賈賴賵賥貰谼谨谝貼貓豚ꧢꦰ꧳ꥧꦽꦁꦽꦼꦬ꧹ꥵꥧ꥓꧵\ua9ceꤎ哷咥哦呲咨咔咨咩咹哬呠吩呃哠哟吇哫咰品哹ȚɚȷʶɃɞɡɁɪȃʹ˥ʬȏȞ˟褧襧褊覈襻襳襈襊襤褄覌视븶빰븊뺧빨빴븯빅빂븐뺴뺾倶借值傧偱偷偺偎偰倓傺僌傍倦倂傮൛അൿිഝഁ൚രഋ൵෩ඳ\u0df0\u0d50൰භ൞ഺർഃ\u0df8ബൊറ\u0dbc\u0d11ඹ\u0d80ඒෙඇ\u0dfe൏മഁන짊짤짇쥜즉즶즿즥즏짪쥿줯쥷짰즷쥕";
      char[] var28 = "\f\b\f\u0014\u0010\u0010\u0014\u0018\u0014\u0014\u0010\u0018\u0010\u0014\u0014\u0014\f\u0010\u0010\u0010<\u0014\u0014\u0014\u0010\u0014\u0014\u0014\u0014\u0010\b\bX\u0014\b\u0010\u0010\u0010\b\b\u0004\f\u0010\b\b\u0004\b\b\b\b\b\b\f\u0004\b\u0010\b\u0004\b\u0004\b\u0004\b\b\f\u0004\b\u0010\f\f\b\b\u0014\u0010\u0010\u0014\u0010\f\f\u0010$\u0010".toCharArray();
      String[] var29 = new String[var28.length];
      byte var33 = -1;

      while(true) {
         int var30 = 0;
         int var31 = 0;
         char var32 = '\u0000';
         if (var33 == 0) {
            lIlII = var29;
            lIlIl = new Object[var29.length];
            int var22 = -1250144405;
            byte[] var20 = "ö×\f´\u0011±Ç\u009cå\u0083ð|¹\u0001\u0013I!Æ\u0007ù\u0004\u001ad±\u0017'+P\u0003\u0090qNh\u008fÕ!\u0003J\u0093¡¹\u000fT»ÔÇ(±+ÚýÚG\u0090>µH\u001a\b8\u0001\u0087\u0093^]'\u0083\u0003¹d%\t¥c\u0019¼\u0082N\u001b\u0012oÃ\u0099y\u0085¡\\Ð¸£#ÞyEå\u0088ùmÔ»o:\u008d\u001cÉÿFÌòW+\u009e\u009f\u0090°\u0093àÇüo¼âÅ,\nø1Qü\u0011øv1ÃG\u0095½3\\üÆ'jL".getBytes("ISO-8859-1");
            int var21 = var20.length / 4;
            lI = new int[var21];
            int var23 = 0;
            int var24 = 0;

            do {
               int var25 = (var20[var23] & 255) << 24 | (var20[var23 + 1] & 255) << 16 | (var20[var23 + 2] & 255) << 8 | var20[var23 + 3] & 255;
               var25 ^= var22;
               lI[var24] = var25;
               var23 += 4;
               ++var24;
            } while(var24 < var21);

            IlIIl = false;
            lIII = new ConcurrentLinkedQueue();
            lIIl = false;
            IIlIl = false;
            IlIll = -1;
            IIIl = 0;
            IIlI = IllIllI(516732910, -1833833524);
            IlI = IllIllI(516732905, 175570811);
            IllI = new IlIlIII();
            IlIII = new boolean[IllIllI(516732904, -1347773326)];
            Illl = new boolean[IllIllI(516732907, -1130900592)];
            IIIII = null.I;
            Illll = -1;
            lll = IllIllI(516732906, 673221071);
            ll = Long.MIN_VALUE;
            III = 0;
            IlII = 0;
            IIIIl = 0;
            Field var0 = null;

            try {
               var0 = class_304.class.getDeclaredField(lIlIII.Il(IllIlll(-338508946, -711757154)));
               var0.setAccessible(true);
            } catch (ReflectiveOperationException var53) {
            }

            Ill = var0;
            Field var1 = null;
            Method var2 = null;

            try {
               var2 = class_1661.class.getMethod(lIlIII.Il(IllIlll(-338508945, 155139221)));
            } catch (NoSuchMethodException var52) {
            }

            try {
               var1 = class_1661.class.getField(lIlIII.Il(IllIlll(-338508952, -1373672698)));
            } catch (NoSuchFieldException var51) {
               try {
                  var1 = class_1661.class.getDeclaredField(lIlIII.Il(IllIlll(-338508951, 742611639)));
                  var1.setAccessible(true);
               } catch (NoSuchFieldException var50) {
               }
            }

            lIIll = var1;
            IlIlI = var2;
            Field var3 = null;
            Field var4 = null;
            Field var5 = null;

            try {
               var3 = class_744.class.getField(lIlIII.Il(IllIlll(-338508950, -491308026)));
               var4 = class_744.class.getField(lIlIII.Il(IllIlll(-338508949, 1972705027)));
            } catch (NoSuchFieldException var49) {
               try {
                  var5 = class_744.class.getDeclaredField(lIlIII.Il(IllIlll(-338508956, -1464596469)));
                  var5.setAccessible(true);
               } catch (NoSuchFieldException var48) {
                  try {
                     var5 = class_744.class.getDeclaredField(lIlIII.Il(IllIlll(-338508955, 1688359325)));
                     var5.setAccessible(true);
                  } catch (NoSuchFieldException var47) {
                     try {
                        var5 = class_744.class.getDeclaredField(lIlIII.Il(IllIlll(-338508954, -277646710)));
                        var5.setAccessible(true);
                     } catch (NoSuchFieldException var46) {
                     }
                  }
               }
            }

            IIll = var3;
            IIIlI = var4;
            IIlll = var5;
            Method var6 = null;

            try {
               var6 = class_636.class.getDeclaredMethod(lIlIII.Il(IllIlll(-338508953, 1956847395)));
               var6.setAccessible(true);
            } catch (ReflectiveOperationException var45) {
            }

            IIIll = var6;
            Method var7 = null;
            Method var8 = null;

            try {
               var7 = class_304.class.getMethod(lIlIII.Il(IllIlll(-338508960, 1537682624)), class_3675.class_306.class);
            } catch (ReflectiveOperationException var44) {
            }

            try {
               var8 = class_304.class.getMethod(lIlIII.Il(IllIlll(-338508959, 1813590945)), class_3675.class_306.class, Boolean.TYPE);
            } catch (ReflectiveOperationException var43) {
            }

            II = var7;
            IllII = var8;
            Method var9 = null;
            Method var10 = null;

            try {
               var9 = class_310.class.getMethod(lIlIII.Il(IllIlll(-338508958, -869374024)), class_1297.class);
            } catch (ReflectiveOperationException var42) {
            }

            try {
               var10 = class_310.class.getMethod(lIlIII.Il(IllIlll(-338508957, -2001925315)));
            } catch (ReflectiveOperationException var41) {
            }

            lIll = var9;
            llll = var10;
            lIIlI = lII(class_1309.class, lIlIII.Il(IllIlll(-338508932, -1838477035)));
            IllIl = lII(class_1309.class, lIlIII.Il(IllIlll(-338508931, -1443757896)));
            IIllI = lII(class_1309.class, lIlIII.Il(IllIlll(-338508930, 1091182129)));
            lII = lII(class_1309.class, lIlIII.Il(IllIlll(-338508929, 521282231)));
            Method var11 = null;
            Method var12 = null;
            Method var13 = null;

            try {
               Class var14 = Class.forName(lIlIII.Il(IllIlll(-338508936, -2126502453)));

               try {
                  var11 = var14.getMethod(lIlIII.Il(IllIlll(-338508935, 698618198)), class_276.class);
               } catch (ReflectiveOperationException var39) {
               }

               try {
                  var12 = var14.getMethod(lIlIII.Il(IllIlll(-338508934, -1776804143)), class_276.class, Consumer.class);
               } catch (ReflectiveOperationException var38) {
               }

               try {
                  var13 = var14.getMethod(lIlIII.Il(IllIlll(-338508933, 394418852)), class_276.class, Integer.TYPE, Consumer.class);
               } catch (ReflectiveOperationException var37) {
               }
            } catch (ClassNotFoundException var40) {
            }

            I = var11;
            IIl = var12;
            lIIIl = var13;
            Method var54 = null;

            for(Method var18 : class_3675.class.getMethods()) {
               Class[] var19 = var18.getParameterTypes();
               if (var18.getName().equals(lIlIII.Il(IllIlll(-338508940, 1085497557))) && var19.length == 2 && var19[1] == Integer.TYPE && (var19[0] == Long.TYPE || !var19[0].isPrimitive())) {
                  var54 = var18;
                  break;
               }
            }

            IIlII = var54;
            return;
         }

         do {
            var32 = var28[var30];
            char[] var34 = var27.substring(var31, var31 + var32).toCharArray();
            int var35 = 0;

            do {
               byte var10000;
               switch (var35 % 5) {
                  case 0:
                  default:
                     var10000 = 42;
                     break;
                  case 1:
                     var10000 = 116;
                     break;
                  case 2:
                     var10000 = 38;
                     break;
                  case 3:
                     var10000 = 68;
                     break;
                  case 4:
                     var10000 = 26;
               }

               byte var36 = var10000;
               var34[var35] = (char)(var34[var35] ^ var36 ^ var26);
               ++var35;
            } while(var35 < var34.length);

            var29[var30] = (new String(var34)).intern();
            var31 += var32;
            ++var30;
         } while(var30 < var28.length);

         var33 = 0;
      }
   }

   public static void lIIl(class_310 var0) {
      IlIl = var0 != null && var0.field_1690 != null && var0.field_1690.field_1886 != null && var0.field_1690.field_1904 != null && IIIll(var0, var0.field_1690.field_1886) && IIIll(var0, var0.field_1690.field_1904);
   }

   private static BufferedImage lIlI(class_1011 var0) {
      BufferedImage var1 = new BufferedImage(var0.method_4307(), var0.method_4323(), 2);
      int[] var2 = lllI(var0);
      if (var2 != null && var2.length >= var0.method_4307() * var0.method_4323()) {
         var1.setRGB(0, 0, var0.method_4307(), var0.method_4323(), var2, 0, var0.method_4307());
         return var1;
      } else {
         return var1;
      }
   }

   public static <undefinedtype> lIll(class_310 var0, Object var1, int var2, int var3, boolean var4) {
      if (var0 != null && var0.field_1724 != null && var1 != null && var2 >= 0 && var2 <= IllIllI(516732901, -1019269721) && Il == null && !llIl) {
         int var5 = var0.field_1724.field_6012;
         int var6 = IllI.Il(var0.new null(var0) {
            private final class_310 I;
            private static final int[] l;

            public int I() {
               return IIlllllI.IIIl(this.I.field_1724.method_31548());
            }

            public int l() {
               return IllllIlI.Illll >= 0 && IllllIlI.Illll < ll(2051093048, -579120194) ? IllllIlI.Illll : this.I();
            }

            public void II(Object var1, int var2) {
               switch (var1) {
                  case II:
                     IllllIlI.IIlIlI(this.I, var2, true);
                     break;
                  case lI:
                     IllllIlI.IlIllll(this.I, var2);
                     IllllIlI.IIlIlI(this.I, var2, false);
                     break;
                  case I:
                     int var3 = IIllIlll.lII();
                     if (var3 != var2 && (var3 >= 0 || this.l() != var2)) {
                        IIllIlll.Ill(var2);
                        ++IllllIlI.IlII;

                        try {
                           this.I.method_1562().method_52787(new class_2868(var2));
                        } finally {
                           IllllIlI.IlII = Math.max(0, IllllIlI.IlII - 1);
                        }
                     } else {
                        IIllIlll.Ill(var2);
                     }

                     lIllIIl var4 = lIllIIl.Il();
                     if (var4 != null && var4.IIl() != null && var4.IIl().IllllI() != null && var4.IIl().IllllI().IIIIIlI()) {
                        var4.IIl().IllllI().llI(var2);
                     }
               }

            }

            public int Il() {
               return this.I != null && this.I.field_1724 != null ? this.I.field_1724.field_6012 : 0;
            }

            private {
               this.I = var1;
            }

            public boolean lI(Object var1, int var2) {
               if (var1 == null.I) {
                  if (this.l() != var2 && IIllIlll.lII() != var2) {
                     if (IIllIlll.lII() != var2) {
                        this.II(var1, var2);
                     }

                     return false;
                  } else {
                     return true;
                  }
               } else {
                  return this.I() == var2;
               }
            }

            private static int ll(int var0, int var1) {
               return l[var0 ^ 2051093048] ^ var1 ^ var0;
            }

            static {
               int var2 = -658501509;
               byte[] var0 = "\u007fúqô".getBytes("ISO-8859-1");
               int var1 = var0.length / 4;
               l = new int[var1];
               int var3 = 0;
               int var4 = 0;

               do {
                  int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
                  var5 ^= var2;
                  l[var4] = var5;
                  var3 += 4;
                  ++var4;
               } while(var4 < var1);

            }
         });
         boolean var7 = var6 != var2;
         <undefinedtype> var8 = IIIII;
         <undefinedtype> var9 = IllI.I(var0.new null(var0) {
            private final class_310 I;
            private static final int[] l;

            public int I() {
               return IIlllllI.IIIl(this.I.field_1724.method_31548());
            }

            public int l() {
               return IllllIlI.Illll >= 0 && IllllIlI.Illll < ll(2051093048, -579120194) ? IllllIlI.Illll : this.I();
            }

            public void II(Object var1, int var2) {
               switch (var1) {
                  case II:
                     IllllIlI.IIlIlI(this.I, var2, true);
                     break;
                  case lI:
                     IllllIlI.IlIllll(this.I, var2);
                     IllllIlI.IIlIlI(this.I, var2, false);
                     break;
                  case I:
                     int var3 = IIllIlll.lII();
                     if (var3 != var2 && (var3 >= 0 || this.l() != var2)) {
                        IIllIlll.Ill(var2);
                        ++IllllIlI.IlII;

                        try {
                           this.I.method_1562().method_52787(new class_2868(var2));
                        } finally {
                           IllllIlI.IlII = Math.max(0, IllllIlI.IlII - 1);
                        }
                     } else {
                        IIllIlll.Ill(var2);
                     }

                     lIllIIl var4 = lIllIIl.Il();
                     if (var4 != null && var4.IIl() != null && var4.IIl().IllllI() != null && var4.IIl().IllllI().IIIIIlI()) {
                        var4.IIl().IllllI().llI(var2);
                     }
               }

            }

            public int Il() {
               return this.I != null && this.I.field_1724 != null ? this.I.field_1724.field_6012 : 0;
            }

            private {
               this.I = var1;
            }

            public boolean lI(Object var1, int var2) {
               if (var1 == null.I) {
                  if (this.l() != var2 && IIllIlll.lII() != var2) {
                     if (IIllIlll.lII() != var2) {
                        this.II(var1, var2);
                     }

                     return false;
                  } else {
                     return true;
                  }
               } else {
                  return this.I() == var2;
               }
            }

            private static int ll(int var0, int var1) {
               return l[var0 ^ 2051093048] ^ var1 ^ var0;
            }

            static {
               int var2 = -658501509;
               byte[] var0 = "\u007fúqô".getBytes("ISO-8859-1");
               int var1 = var0.length / 4;
               l = new int[var1];
               int var3 = 0;
               int var4 = 0;

               do {
                  int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
                  var5 ^= var2;
                  l[var4] = var5;
                  var3 += 4;
                  ++var4;
               } while(var4 < var1);

            }
         }, var1, var2, var8, -1, true, (Runnable)null);
         if (var9.II() == 0L) {
            return null.l(var2);
         } else {
            if (var4 && var3 <= 0 && var8 == null.I) {
               IlllI(var0);
            }

            int var10 = var7 ? var5 + Math.max(0, var3) : var5;
            return new Record(var6, var2, var5, var10, var7, true, var9) {
               private final int I;
               private final <undefinedtype> l;
               private final boolean II;
               private final int Il;
               private final int lI;
               private final int ll;
               private final boolean III;
               private static final int[] IIl;

               public int I() {
                  return this.Il;
               }

               static <undefinedtype> l(int var0) {
                  return new <anonymous constructor>(-1, var0, IlI(-547170428, -701882891), IlI(-547170427, -1807212102), false, false, null);
               }

               public int II() {
                  return this.ll;
               }

               public int Il() {
                  return this.I;
               }

               public boolean lI() {
                  return this.III;
               }

               public int ll() {
                  return this.lI;
               }

               public {
                  this.Il = var1;
                  this.lI = var2;
                  this.I = var3;
                  this.ll = var4;
                  this.III = var5;
                  this.II = var6;
                  this.l = var7;
               }

               public boolean III() {
                  return this.II;
               }

               public <undefinedtype> IIl() {
                  return this.l;
               }

               private static int IlI(int var0, int var1) {
                  return IIl[var0 ^ -547170428] ^ var1 ^ var0;
               }

               static {
                  int var2 = 1840724202;
                  byte[] var0 = "äÿò\u009bYb1*".getBytes("ISO-8859-1");
                  int var1 = var0.length / 4;
                  IIl = new int[var1];
                  int var3 = 0;
                  int var4 = 0;

                  do {
                     int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
                     var5 ^= var2;
                     IIl[var4] = var5;
                     var3 += 4;
                     ++var4;
                  } while(var4 < var1);

               }
            };
         }
      } else {
         return null.l(var2);
      }
   }

   private static void llII(class_304 var0, class_3675.class_306 var1) {
      if (var0 != null && !IllllI(var1)) {
         try {
            var0.method_23481(true);
            if (IllII != null) {
               IllII.invoke((Object)null, var1, true);
            }

            if (II != null) {
               II.invoke((Object)null, var1);
            }
         } catch (ReflectiveOperationException var11) {
         } finally {
            var0.method_23481(false);
            if (IllII != null) {
               try {
                  IllII.invoke((Object)null, var1, false);
               } catch (ReflectiveOperationException var10) {
               }
            }

         }

      }
   }

   public static class_1799 llIl(class_746 var0) {
      if (var0 == null) {
         return class_1799.field_8037;
      } else {
         class_1661 var1 = var0.method_31548();
         class_310 var2 = class_310.method_1551();
         int var3 = var2 != null && var0 == var2.field_1724 ? IIIllIl(var1) : IIlllllI.IIIl(var1);
         return var3 >= 0 && var3 < IllIllI(516732900, -1459983577) ? var1.method_5438(var3) : class_1799.field_8037;
      }
   }

   private static int[] lllI(class_1011 var0) {
      for(String var4 : new String[]{lIlIII.Il(IllIlll(-338508939, 1826497952)), lIlIII.Il(IllIlll(-338508938, 1706581304)), lIlIII.Il(IllIlll(-338508937, 767636962))}) {
         try {
            Method var5 = var0.getClass().getDeclaredMethod(var4);
            var5.setAccessible(true);
            int[] var6 = (int[])var5.invoke(var0);
            if (lIlIII.Il(IllIlll(-338508944, 2058714333)).equals(var4)) {
               IIllIll(var6);
            }

            return var6;
         } catch (ReflectiveOperationException var8) {
         }
      }

      try {
         Method var9 = var0.getClass().getDeclaredMethod(lIlIII.Il(IllIlll(-338508943, -637576887)), Integer.TYPE, Integer.TYPE);
         var9.setAccessible(true);
         int[] var10 = new int[var0.method_4307() * var0.method_4323()];

         for(int var11 = 0; var11 < var0.method_4323(); ++var11) {
            for(int var12 = 0; var12 < var0.method_4307(); ++var12) {
               var10[var11 * var0.method_4307() + var12] = (Integer)var9.invoke(var0, var12, var11);
            }
         }

         return var10;
      } catch (ReflectiveOperationException var7) {
         return null;
      }
   }

   public static void llll(class_310 var0, Object var1, int var2, int var3) {
      if (var0 != null && var0.field_1724 != null && var1 != null) {
         if (!IllI.IlII(var1, var0.field_1724.field_6012, var3, null)) {
            IlII(var0, var1, null.II);
         }

      }
   }

   private static class_9331<?> IIIIl() {
      try {
         return class_9334.field_55878;
      } catch (Throwable var1) {
         return null;
      }
   }

   public static boolean IIIlI() {
      return IIIl > 0;
   }

   public static boolean IIIll(class_310 var0, class_304 var1) {
      if (var0 != null && var1 != null && var0.method_22683() != null) {
         class_3675.class_306 var2 = IIlllllI.IIIlI(var1);
         return var2 == null ? var1.method_1434() : IlIII(var0, var2);
      } else {
         return false;
      }
   }

   public static void IIlII(class_310 var0) {
      if (var0 != null && var0.field_1761 != null) {
         IIlllllI.IIII(var0.field_1761, 0);
         IIlllllI.II(var0, 0);
      }
   }

   public static int IIlIl(class_310 var0) {
      return var0 != null && var0.field_1724 != null ? IllI.Il(var0.new null(var0) {
         private final class_310 I;
         private static final int[] l;

         public int I() {
            return IIlllllI.IIIl(this.I.field_1724.method_31548());
         }

         public int l() {
            return IllllIlI.Illll >= 0 && IllllIlI.Illll < ll(2051093048, -579120194) ? IllllIlI.Illll : this.I();
         }

         public void II(Object var1, int var2) {
            switch (var1) {
               case II:
                  IllllIlI.IIlIlI(this.I, var2, true);
                  break;
               case lI:
                  IllllIlI.IlIllll(this.I, var2);
                  IllllIlI.IIlIlI(this.I, var2, false);
                  break;
               case I:
                  int var3 = IIllIlll.lII();
                  if (var3 != var2 && (var3 >= 0 || this.l() != var2)) {
                     IIllIlll.Ill(var2);
                     ++IllllIlI.IlII;

                     try {
                        this.I.method_1562().method_52787(new class_2868(var2));
                     } finally {
                        IllllIlI.IlII = Math.max(0, IllllIlI.IlII - 1);
                     }
                  } else {
                     IIllIlll.Ill(var2);
                  }

                  lIllIIl var4 = lIllIIl.Il();
                  if (var4 != null && var4.IIl() != null && var4.IIl().IllllI() != null && var4.IIl().IllllI().IIIIIlI()) {
                     var4.IIl().IllllI().llI(var2);
                  }
            }

         }

         public int Il() {
            return this.I != null && this.I.field_1724 != null ? this.I.field_1724.field_6012 : 0;
         }

         private {
            this.I = var1;
         }

         public boolean lI(Object var1, int var2) {
            if (var1 == null.I) {
               if (this.l() != var2 && IIllIlll.lII() != var2) {
                  if (IIllIlll.lII() != var2) {
                     this.II(var1, var2);
                  }

                  return false;
               } else {
                  return true;
               }
            } else {
               return this.I() == var2;
            }
         }

         private static int ll(int var0, int var1) {
            return l[var0 ^ 2051093048] ^ var1 ^ var0;
         }

         static {
            int var2 = -658501509;
            byte[] var0 = "\u007fúqô".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            l = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               l[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

         }
      }) : 0;
   }

   public static class_1269 IIllI(class_310 var0, class_1268 var1) {
      if (var0 != null && var0.field_1724 != null && var0.field_1761 != null && var1 != null) {
         IIlI(var0);
         return var0.field_1761.method_2919(var0.field_1724, var1);
      } else {
         return class_1269.field_5814;
      }
   }

   public static void IIlll(class_310 var0) {
      if (var0 != null && var0.field_1724 != null) {
         while(true) {
            <undefinedtype> var1 = (<undefinedtype>)lIII.peek();
            if (var1 == null || var0.field_1724.field_6012 < var1.II()) {
               return;
            }

            lIII.poll();
            if (var1.l() == var0.field_1724) {
               int var2 = lIIlI(var0.field_1724.method_31548());
               if (var2 != var1.Il()) {
                  if (IlIlIIl(var1, var2)) {
                     lIII.offer(var1);
                     return;
                  }
               } else if (var2 != var1.I()) {
                  IIlIlI(var0, var1.I(), false);
               }
            }
         }
      } else {
         III();
      }
   }

   public static boolean IlIII(class_310 var0, class_3675.class_306 var1) {
      if (var0 != null && var0.method_22683() != null && !IllllI(var1)) {
         long var2 = var0.method_22683().method_4490();
         boolean var10000;
         switch (var1.method_1442()) {
            case field_1672:
               var10000 = GLFW.glfwGetMouseButton(var2, var1.method_1444()) == 1;
               break;
            case field_1668:
            case field_1671:
               var10000 = lIllII(var0, var1.method_1444());
               break;
            default:
               throw new MatchException((String)null, (Throwable)null);
         }

         return var10000;
      } else {
         return false;
      }
   }

   public static int IlIIl(class_1661 var0) {
      if (IllI.Ill() && var0 != null && (IIIIl > 0 || lIl)) {
         class_310 var1 = class_310.method_1551();
         return var1 != null && var1.field_1724 != null && var1.field_1724.method_31548() == var0 ? IllI.Il(var1.new null(var1) {
            private final class_310 I;
            private static final int[] l;

            public int I() {
               return IIlllllI.IIIl(this.I.field_1724.method_31548());
            }

            public int l() {
               return IllllIlI.Illll >= 0 && IllllIlI.Illll < ll(2051093048, -579120194) ? IllllIlI.Illll : this.I();
            }

            public void II(Object var1, int var2) {
               switch (var1) {
                  case II:
                     IllllIlI.IIlIlI(this.I, var2, true);
                     break;
                  case lI:
                     IllllIlI.IlIllll(this.I, var2);
                     IllllIlI.IIlIlI(this.I, var2, false);
                     break;
                  case I:
                     int var3 = IIllIlll.lII();
                     if (var3 != var2 && (var3 >= 0 || this.l() != var2)) {
                        IIllIlll.Ill(var2);
                        ++IllllIlI.IlII;

                        try {
                           this.I.method_1562().method_52787(new class_2868(var2));
                        } finally {
                           IllllIlI.IlII = Math.max(0, IllllIlI.IlII - 1);
                        }
                     } else {
                        IIllIlll.Ill(var2);
                     }

                     lIllIIl var4 = lIllIIl.Il();
                     if (var4 != null && var4.IIl() != null && var4.IIl().IllllI() != null && var4.IIl().IllllI().IIIIIlI()) {
                        var4.IIl().IllllI().llI(var2);
                     }
               }

            }

            public int Il() {
               return this.I != null && this.I.field_1724 != null ? this.I.field_1724.field_6012 : 0;
            }

            private {
               this.I = var1;
            }

            public boolean lI(Object var1, int var2) {
               if (var1 == null.I) {
                  if (this.l() != var2 && IIllIlll.lII() != var2) {
                     if (IIllIlll.lII() != var2) {
                        this.II(var1, var2);
                     }

                     return false;
                  } else {
                     return true;
                  }
               } else {
                  return this.I() == var2;
               }
            }

            private static int ll(int var0, int var1) {
               return l[var0 ^ 2051093048] ^ var1 ^ var0;
            }

            static {
               int var2 = -658501509;
               byte[] var0 = "\u007fúqô".getBytes("ISO-8859-1");
               int var1 = var0.length / 4;
               l = new int[var1];
               int var3 = 0;
               int var4 = 0;

               do {
                  int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
                  var5 ^= var2;
                  l[var4] = var5;
                  var3 += 4;
                  ++var4;
               } while(var4 < var1);

            }
         }) : -1;
      } else {
         return -1;
      }
   }

   private static float IlIlI(Field var0, Object var1, float var2) {
      if (var0 != null && var1 != null) {
         try {
            return var0.getFloat(var1);
         } catch (ReflectiveOperationException var4) {
            return var2;
         }
      } else {
         return var2;
      }
   }

   public static boolean IlIll(class_310 var0, class_1268 var1) {
      if (var0 != null && var0.field_1724 != null && var0.field_1761 != null && var1 != null && lIllI(var0) <= 0) {
         if (!llIIll(var0)) {
            return false;
         } else {
            class_1269 var2 = lllIlI(var0, var1);
            boolean var3 = var2 != null && var2.method_23665();
            if (var3) {
               lllIII(var0);
            }

            return var3;
         }
      } else {
         return false;
      }
   }

   public static class_3675.class_306 IllII(int var0) {
      return var0 < 0 ? class_3675.field_16237 : class_307.field_1672.method_1447(var0);
   }

   public static boolean IllIl(class_310 var0) {
      if (var0 != null && var0.field_1724 != null && var0.field_1761 != null && var0.field_1690 != null && var0.field_1690.field_1886 != null) {
         if (IllllI(IIIlIIl(var0.field_1690.field_1886))) {
            return false;
         } else {
            IlIIIll(var0);
            return IIlIlII(var0);
         }
      } else {
         return false;
      }
   }

   public static void IlllI(class_310 var0) {
      if (var0 != null && var0.field_1724 != null && var0.field_1761 != null) {
         if (lIIl && (IlIll >= 0 || IIlIl)) {
            if (IIlllllI.lIl(var0.field_1761) <= 0) {
               IIlllllI.III(var0.field_1761);
               IlIll = -1;
               IIlIl = false;
            }
         }
      } else {
         IlIll = -1;
         IIlIl = false;
      }
   }

   public static int Illll(class_310 var0) {
      if (var0 != null && var0.field_1724 != null) {
         if (var0.field_1690 != null) {
            if (var0.field_1690.field_1886 != null) {
               IIIIllI(var0.field_1690.field_1886);
               var0.field_1690.field_1886.method_23481(false);
            }

            if (var0.field_1690.field_1904 != null) {
               IIIIllI(var0.field_1690.field_1904);
               var0.field_1690.field_1904.method_23481(false);
            }
         }

         boolean var1 = false;
         if (var0.field_1761 != null) {
            if (IIlllllI.IIlII(var0.field_1761)) {
               var0.field_1761.method_2925();
               var1 = true;
            }

            if (var0.field_1724.method_6115()) {
               var0.field_1761.method_2897(var0.field_1724);
               var1 = true;
            }
         }

         return var1 ? var0.field_1724.field_6012 + 1 : var0.field_1724.field_6012;
      } else {
         return IllIllI(516732903, 1832932296);
      }
   }

   public static class_1309 lIIII(class_310 var0, class_239 var1) {
      if (var1 instanceof class_3966 var2) {
         class_1297 var4 = var2.method_17782();
         if (var4 instanceof class_1309 var3) {
            if (x.IlIII.l(var3)) {
               return null;
            }

            return var3;
         }
      }

      return null;
   }

   public static boolean lIIIl() {
      return IlIl;
   }

   public static int lIIlI(class_1661 var0) {
      if (var0 == null) {
         return 0;
      } else {
         class_310 var1 = class_310.method_1551();
         return var1 != null && var1.field_1724 != null && var1.field_1724.method_31548() == var0 && IllI.llIl() ? IllI.Il(var1.new null(var1) {
            private final class_310 I;
            private static final int[] l;

            public int I() {
               return IIlllllI.IIIl(this.I.field_1724.method_31548());
            }

            public int l() {
               return IllllIlI.Illll >= 0 && IllllIlI.Illll < ll(2051093048, -579120194) ? IllllIlI.Illll : this.I();
            }

            public void II(Object var1, int var2) {
               switch (var1) {
                  case II:
                     IllllIlI.IIlIlI(this.I, var2, true);
                     break;
                  case lI:
                     IllllIlI.IlIllll(this.I, var2);
                     IllllIlI.IIlIlI(this.I, var2, false);
                     break;
                  case I:
                     int var3 = IIllIlll.lII();
                     if (var3 != var2 && (var3 >= 0 || this.l() != var2)) {
                        IIllIlll.Ill(var2);
                        ++IllllIlI.IlII;

                        try {
                           this.I.method_1562().method_52787(new class_2868(var2));
                        } finally {
                           IllllIlI.IlII = Math.max(0, IllllIlI.IlII - 1);
                        }
                     } else {
                        IIllIlll.Ill(var2);
                     }

                     lIllIIl var4 = lIllIIl.Il();
                     if (var4 != null && var4.IIl() != null && var4.IIl().IllllI() != null && var4.IIl().IllllI().IIIIIlI()) {
                        var4.IIl().IllllI().llI(var2);
                     }
               }

            }

            public int Il() {
               return this.I != null && this.I.field_1724 != null ? this.I.field_1724.field_6012 : 0;
            }

            private {
               this.I = var1;
            }

            public boolean lI(Object var1, int var2) {
               if (var1 == null.I) {
                  if (this.l() != var2 && IIllIlll.lII() != var2) {
                     if (IIllIlll.lII() != var2) {
                        this.II(var1, var2);
                     }

                     return false;
                  } else {
                     return true;
                  }
               } else {
                  return this.I() == var2;
               }
            }

            private static int ll(int var0, int var1) {
               return l[var0 ^ 2051093048] ^ var1 ^ var0;
            }

            static {
               int var2 = -658501509;
               byte[] var0 = "\u007fúqô".getBytes("ISO-8859-1");
               int var1 = var0.length / 4;
               l = new int[var1];
               int var3 = 0;
               int var4 = 0;

               do {
                  int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
                  var5 ^= var2;
                  l[var4] = var5;
                  var3 += 4;
                  ++var4;
               } while(var4 < var1);

            }
         }) : IIlllllI.IIIl(var0);
      }
   }

   public static boolean lIIll(class_310 var0, class_3966 var1) {
      IIIIIIl(var0);
      return I(var0);
   }

   public static class_1269 lIlII(class_310 var0, class_1268 var1, class_3965 var2) {
      if (var0 != null && var0.field_1724 != null && var0.field_1761 != null && var1 != null && var2 != null) {
         if (!llIIll(var0)) {
            return class_1269.field_5814;
         } else {
            IIlI(var0);
            class_1269 var3 = var0.field_1761.method_2896(var0.field_1724, var1, var2);
            if (var3 != null && var3.method_23665()) {
               lllIII(var0);
            }

            return var3;
         }
      } else {
         return class_1269.field_5814;
      }
   }

   private IllllIlI() {
   }

   public static boolean lIlIl() {
      IIIllll();
      return true;
   }

   public static int lIllI(class_310 var0) {
      return var0 == null ? 0 : IIlllllI.lIlI(var0);
   }

   public static boolean lIlll(class_310 var0, int var1) {
      if (var0 != null && var0.field_1724 != null && var1 >= 0 && var1 <= IllIllI(516732902, 2138558516)) {
         class_1661 var2 = var0.field_1724.method_31548();
         IIlIlI(var0, var1, true);
         if (!lIIl) {
            return false;
         } else {
            IlllI(var0);
            return lIIlI(var2) == var1 && IlIll < 0 && !IIlIl;
         }
      } else {
         return false;
      }
   }

   public static class_1297 llIII(class_310 var0) {
      if (var0 != null) {
         class_239 var2 = var0.field_1765;
         if (var2 instanceof class_3966) {
            class_3966 var1 = (class_3966)var2;
            return var1.method_17782();
         }
      }

      return null;
   }

   public static JsonElement llIIl(class_3675.class_306 var0) {
      if (IllllI(var0)) {
         return null;
      } else {
         JsonObject var1 = new JsonObject();
         var1.addProperty(lIlIII.Il(IllIlll(-338508942, -1018035182)), var0.method_1442() == class_307.field_1672 ? 1 : 0);
         var1.addProperty(lIlIII.Il(IllIlll(-338508941, -163965072)), var0.method_1444());
         return var1;
      }
   }

   public static void llIlI(class_2596<?> var0) {
      if (var0 instanceof class_2868 var1) {
         int var2 = var1.method_12442();
         Illll = var2;
         class_310 var3 = class_310.method_1551();
         if (var3 != null && var3.field_1724 != null) {
            lll = var3.field_1724.field_6012;
            ll = System.nanoTime();
            lIllIIl var4 = lIllIIl.Il();
            if (var4 != null && var4.IIl() != null && var4.IIl().IllllI() != null && var4.IIl().IllllI().IIIIIlI()) {
               int var5 = IIlllllI.IIIl(var3.field_1724.method_31548());
               if (var2 != var5) {
                  var4.IIl().IllllI().llI(var2);
               }
            }
         }
      }

   }

   public static boolean llIll(class_310 var0, Object var1, int var2, BooleanSupplier var3) {
      if (var0 != null && var0.field_1724 != null && var0.method_1562() != null && var1 != null && var3 != null && var2 >= 0 && var2 <= IllIllI(516732897, -2140535464) && !llIl) {
         if (!var0.method_18854()) {
            throw new IllegalStateException(lIlIII.Il(IllIlll(-338508980, 1781549348)));
         } else {
            <undefinedtype> var4 = Il;
            if (var4 != null) {
               if (var4.l() != var0.field_1724 || var4.I().l() != var1 || !IllI.IIlI(var1)) {
                  return false;
               }

               Il = null;
               IlllI = false;
            }

            <undefinedtype> var5 = var0.new null(var0) {
               private final class_310 I;
               private static final int[] l;

               public int I() {
                  return IIlllllI.IIIl(this.I.field_1724.method_31548());
               }

               public int l() {
                  return IllllIlI.Illll >= 0 && IllllIlI.Illll < ll(2051093048, -579120194) ? IllllIlI.Illll : this.I();
               }

               public void II(Object var1, int var2) {
                  switch (var1) {
                     case II:
                        IllllIlI.IIlIlI(this.I, var2, true);
                        break;
                     case lI:
                        IllllIlI.IlIllll(this.I, var2);
                        IllllIlI.IIlIlI(this.I, var2, false);
                        break;
                     case I:
                        int var3 = IIllIlll.lII();
                        if (var3 != var2 && (var3 >= 0 || this.l() != var2)) {
                           IIllIlll.Ill(var2);
                           ++IllllIlI.IlII;

                           try {
                              this.I.method_1562().method_52787(new class_2868(var2));
                           } finally {
                              IllllIlI.IlII = Math.max(0, IllllIlI.IlII - 1);
                           }
                        } else {
                           IIllIlll.Ill(var2);
                        }

                        lIllIIl var4 = lIllIIl.Il();
                        if (var4 != null && var4.IIl() != null && var4.IIl().IllllI() != null && var4.IIl().IllllI().IIIIIlI()) {
                           var4.IIl().IllllI().llI(var2);
                        }
                  }

               }

               public int Il() {
                  return this.I != null && this.I.field_1724 != null ? this.I.field_1724.field_6012 : 0;
               }

               private {
                  this.I = var1;
               }

               public boolean lI(Object var1, int var2) {
                  if (var1 == null.I) {
                     if (this.l() != var2 && IIllIlll.lII() != var2) {
                        if (IIllIlll.lII() != var2) {
                           this.II(var1, var2);
                        }

                        return false;
                     } else {
                        return true;
                     }
                  } else {
                     return this.I() == var2;
                  }
               }

               private static int ll(int var0, int var1) {
                  return l[var0 ^ 2051093048] ^ var1 ^ var0;
               }

               static {
                  int var2 = -658501509;
                  byte[] var0 = "\u007fúqô".getBytes("ISO-8859-1");
                  int var1 = var0.length / 4;
                  l = new int[var1];
                  int var3 = 0;
                  int var4 = 0;

                  do {
                     int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
                     var5 ^= var2;
                     l[var4] = var5;
                     var3 += 4;
                     ++var4;
                  } while(var4 < var1);

               }
            };
            <undefinedtype> var6 = IllI.I(var5, var1, var2, null.I, -1, true, (Runnable)null);
            if (var6.II() == 0L) {
               return false;
            } else {
               ++III;
               ++IIIIl;

               boolean var7;
               try {
                  var7 = var3.getAsBoolean();
               } finally {
                  IIIIl = Math.max(0, IIIIl - 1);
                  III = Math.max(0, III - 1);
                  if (var6.I()) {
                     Il = new Record(var0.field_1724, var6) {
                        private final <undefinedtype> I;
                        private final class_746 l;

                        private {
                           this.l = var1;
                           this.I = var2;
                        }

                        public <undefinedtype> I() {
                           return this.I;
                        }

                        public class_746 l() {
                           return this.l;
                        }
                     };
                     IlllI = false;
                  }

               }

               return var7;
            }
         }
      } else {
         return false;
      }
   }

   public static boolean lllII(class_310 var0, class_3966 var1) {
      if (var0 != null && var0.field_1724 != null && var1 != null) {
         IIIIIIl(var0);
         class_239 var2 = var0.field_1765;
         var0.field_1765 = var1;

         boolean var3;
         try {
            var3 = I(var0);
         } finally {
            var0.field_1765 = var2;
         }

         return var3;
      } else {
         return false;
      }
   }

   public static void lllIl(class_1661 var0, int var1) {
      if (var0 != null) {
         IIlllllI.llII(var0, var1);
      }
   }

   public static class_243 llllI(class_2596<?> var0) {
      return IIIIlIl(var0);
   }

   public static class_3675.class_306 lllll(int var0) {
      return var0 == -1 ? class_3675.field_16237 : class_307.field_1668.method_1447(var0);
   }

   public static BufferedImage IIIIII(class_310 var0) {
      if (var0 == null) {
         return null;
      } else {
         class_276 var1 = var0.method_1522();
         if (var1 == null) {
            return null;
         } else {
            class_1011 var2 = null;

            Object var11;
            try {
               if (I != null) {
                  var11 = I.invoke((Object)null, var1);
                  if (var11 instanceof class_1011) {
                     class_1011 var13 = (class_1011)var11;
                     var2 = var13;
                  }
               } else {
                  AtomicReference var10 = new AtomicReference();
                  Objects.requireNonNull(var10);
                  Consumer var14 = var10::set;
                  if (IIl != null) {
                     IIl.invoke((Object)null, var1, var14);
                  } else if (lIIIl != null) {
                     lIIIl.invoke((Object)null, var1, 1, var14);
                  }

                  var2 = (class_1011)var10.get();
               }

               if (var2 != null) {
                  BufferedImage var12 = lIlI(var2);
                  return var12;
               }

               var11 = null;
            } catch (ReflectiveOperationException var8) {
               Object var4 = null;
               return (BufferedImage)var4;
            } finally {
               if (var2 != null) {
                  var2.close();
               }

            }

            return (BufferedImage)var11;
         }
      }
   }

   public static boolean IIIIIl(class_310 var0, Object var1) {
      return IlIllII(var0, var1) && IIllIlI(var0);
   }

   public static void IIIIlI(class_310 var0, int var1) {
      IIIlllI(var0, var1, 1);
   }

   private static class_9331<?> IIIIll() {
      class_9331 var0 = lIlI;
      if (var0 != null) {
         return var0;
      } else {
         try {
            Field var1 = class_9334.class.getField(lIlIII.Il(IllIlll(-338508979, 921121368)));
            var0 = (class_9331)var1.get((Object)null);
         } catch (Throwable var2) {
            var0 = null;
         }

         lIlI = var0;
         return var0;
      }
   }

   public static void IIIlII() {
      lIIl = false;
   }

   public static String IIIlIl(class_3675.class_306 var0) {
      if (IllllI(var0)) {
         return lIlIII.Il(IllIlll(-338508978, -303202550));
      } else {
         String var1 = var0.method_27445().getString();
         if (var1 != null && !var1.isBlank()) {
            return var1.toUpperCase(Locale.ROOT);
         } else if (var0.method_1442() == class_307.field_1672) {
            String var8;
            switch (var0.method_1444()) {
               case 0:
                  var8 = lIlIII.Il(IllIlll(-338508977, -1460587918));
                  break;
               case 1:
                  var8 = lIlIII.Il(IllIlll(-338508984, 807032141));
                  break;
               case 2:
                  var8 = lIlIII.Il(IllIlll(-338508983, 1621907584));
                  break;
               default:
                  var8 = lIlIII.Il(IllIlll(-338508982, 589258719));
                  int var6 = var0.method_1444() + 1;
                  String var3 = var8;
                  var8 = var3 + var6;
            }

            return var8;
         } else {
            String var2 = GLFW.glfwGetKeyName(var0.method_1444(), 0);
            String var10000;
            if (var2 != null) {
               var10000 = var2.toUpperCase(Locale.ROOT);
            } else {
               var10000 = lIlIII.Il(IllIlll(-338508981, 1228422899));
               int var5 = var0.method_1444();
               String var4 = var10000;
               var10000 = var4 + var5;
            }

            return var10000;
         }
      }
   }

   public static boolean IIIllI() {
      return III > 0 || Il != null;
   }

   public static class_1269 IIIlll(class_310 var0, class_1268 var1, class_3965 var2) {
      if (var0 != null && var0.field_1724 != null && var0.field_1761 != null && var1 != null && var2 != null) {
         IIlI(var0);
         return var0.field_1761.method_2896(var0.field_1724, var1, var2);
      } else {
         return class_1269.field_5814;
      }
   }

   public static void IIlIII(class_304 var0) {
      class_3675.class_306 var1 = IIIlIIl(var0);
      if (var0 != null && !IllllI(var1)) {
         try {
            if (II != null) {
               II.invoke((Object)null, var1);
               return;
            }
         } catch (ReflectiveOperationException var3) {
         }

         class_304.method_1420(var1);
      }
   }

   public static void IIlIIl(class_310 var0, int var1) {
      IIlIlI(var0, var1, false);
   }

   public static void IIlIlI(class_310 var0, int var1, boolean var2) {
      if (var0 != null && var0.field_1724 != null && var1 >= 0 && var1 <= IllIllI(516732896, -333396426)) {
         class_1661 var3 = var0.field_1724.method_31548();
         int var4 = lIIlI(var3);
         boolean var5 = var4 != var1;
         if (!var5) {
            if (var2 && IIlIl) {
               IIllllI(var0, var1);
            }

         } else {
            lllIl(var3, var1);
            if (var2) {
               IIllllI(var0, var1);
            } else {
               IlIll = -1;
               IIlIl = true;
            }

         }
      }
   }

   public static boolean IIlIll(class_310 var0) {
      IIIIIIl(var0);
      return I(var0);
   }

   public static void IIllII(class_310 var0, Object var1) {
      if (var0 != null && var0.field_1724 != null) {
         IllI.Illl(var0.new null(var0) {
            private final class_310 I;
            private static final int[] l;

            public int I() {
               return IIlllllI.IIIl(this.I.field_1724.method_31548());
            }

            public int l() {
               return IllllIlI.Illll >= 0 && IllllIlI.Illll < ll(2051093048, -579120194) ? IllllIlI.Illll : this.I();
            }

            public void II(Object var1, int var2) {
               switch (var1) {
                  case II:
                     IllllIlI.IIlIlI(this.I, var2, true);
                     break;
                  case lI:
                     IllllIlI.IlIllll(this.I, var2);
                     IllllIlI.IIlIlI(this.I, var2, false);
                     break;
                  case I:
                     int var3 = IIllIlll.lII();
                     if (var3 != var2 && (var3 >= 0 || this.l() != var2)) {
                        IIllIlll.Ill(var2);
                        ++IllllIlI.IlII;

                        try {
                           this.I.method_1562().method_52787(new class_2868(var2));
                        } finally {
                           IllllIlI.IlII = Math.max(0, IllllIlI.IlII - 1);
                        }
                     } else {
                        IIllIlll.Ill(var2);
                     }

                     lIllIIl var4 = lIllIIl.Il();
                     if (var4 != null && var4.IIl() != null && var4.IIl().IllllI() != null && var4.IIl().IllllI().IIIIIlI()) {
                        var4.IIl().IllllI().llI(var2);
                     }
               }

            }

            public int Il() {
               return this.I != null && this.I.field_1724 != null ? this.I.field_1724.field_6012 : 0;
            }

            private {
               this.I = var1;
            }

            public boolean lI(Object var1, int var2) {
               if (var1 == null.I) {
                  if (this.l() != var2 && IIllIlll.lII() != var2) {
                     if (IIllIlll.lII() != var2) {
                        this.II(var1, var2);
                     }

                     return false;
                  } else {
                     return true;
                  }
               } else {
                  return this.I() == var2;
               }
            }

            private static int ll(int var0, int var1) {
               return l[var0 ^ 2051093048] ^ var1 ^ var0;
            }

            static {
               int var2 = -658501509;
               byte[] var0 = "\u007fúqô".getBytes("ISO-8859-1");
               int var1 = var0.length / 4;
               l = new int[var1];
               int var3 = 0;
               int var4 = 0;

               do {
                  int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
                  var5 ^= var2;
                  l[var4] = var5;
                  var3 += 4;
                  ++var4;
               } while(var4 < var1);

            }
         }, var1);
      }

   }

   public static float IIllIl(class_9779 var0, boolean var1) {
      return var0 == null ? 0.0F : var0.method_60637(var1);
   }

   public static void IIlllI() {
      Il();
   }

   public static void IIllll(Object var0) {
      if (var0 != null) {
         <undefinedtype> var1 = Il;
         if (var1 != null && var1.I().l() == var0) {
            Il = null;
            IlllI = false;
         }

         IllI.lIIl(var0);
      }
   }

   public static void IlIIII(class_310 var0, int var1) {
      if (var0 != null && var0.field_1690 != null && var1 >= 0 && var1 <= IllIllI(516732899, -475336520)) {
         class_304[] var2 = var0.field_1690.field_1852;
         if (var2 != null && var1 < var2.length && var2[var1] != null) {
            class_3675.class_306 var3 = IIIlIIl(var2[var1]);
            if (!IllllI(var3)) {
               IIlIII(var2[var1]);
               return;
            }
         }

         IIlIlI(var0, var1, true);
      }
   }

   public static boolean IlIIIl(class_310 var0, int var1) {
      return IIlIIlI(var0, var1) || var0 != null && var0.field_1724 != null && IIllIlll.lII() == var1;
   }

   public static void IlIIlI(boolean var0) {
      IlIIl = var0;
   }

   public static class_3966 IlIIll(class_310 var0, class_1309 var1, double var2, boolean var4) {
      if (var0 != null && var0.field_1724 != null && var1 != null) {
         class_3966 var5 = IlIIllI(var0, var2);
         if (var5 != null && var5.method_17782() == var1) {
            return var5;
         } else {
            class_239 var7 = var0.field_1765;
            if (var7 instanceof class_3966) {
               class_3966 var6 = (class_3966)var7;
               if (var6.method_17782() == var1) {
                  double var9 = var2 * var2;
                  if (var0.field_1724.method_33571().method_1025(var6.method_17784()) <= var9) {
                     return var6;
                  }
               }
            }

            return null;
         }
      } else {
         return null;
      }
   }

   public static boolean IlIlII(class_310 var0) {
      if (var0 != null && var0.field_1690 != null && var0.field_1690.field_1886 != null) {
         IIIIllI(var0.field_1690.field_1886);
         class_304 var1 = var0.field_1690.field_1886;
         IIlllllI.lll(var1, IIlllllI.IIIIl(var1) + 1);
         return true;
      } else {
         return false;
      }
   }

   public static <undefinedtype> IlIlIl(class_310 var0, int var1, int var2, boolean var3) {
      if (var0 != null && var0.field_1724 != null && var1 >= 0 && var1 <= IllIllI(516732898, -1439208481)) {
         int var4 = var0.field_1724.field_6012;
         class_1661 var5 = var0.field_1724.method_31548();
         int var6 = lIIlI(var5);
         boolean var7 = var6 != var1;
         IIlIlI(var0, var1, var3);
         if (var3 && var2 <= 0) {
            IlllI(var0);
         }

         int var8 = lIIlI(var5);
         if (var8 != var1) {
            return null.l(var1);
         } else {
            int var9 = var7 ? var4 + Math.max(0, var2) : var4;
            return new Record(var6, var1, var4, var9, var7, true, null) {
               private final int I;
               private final <undefinedtype> l;
               private final boolean II;
               private final int Il;
               private final int lI;
               private final int ll;
               private final boolean III;
               private static final int[] IIl;

               public int I() {
                  return this.Il;
               }

               static <undefinedtype> l(int var0) {
                  return new <anonymous constructor>(-1, var0, IlI(-547170428, -701882891), IlI(-547170427, -1807212102), false, false, null);
               }

               public int II() {
                  return this.ll;
               }

               public int Il() {
                  return this.I;
               }

               public boolean lI() {
                  return this.III;
               }

               public int ll() {
                  return this.lI;
               }

               public {
                  this.Il = var1;
                  this.lI = var2;
                  this.I = var3;
                  this.ll = var4;
                  this.III = var5;
                  this.II = var6;
                  this.l = var7;
               }

               public boolean III() {
                  return this.II;
               }

               public <undefinedtype> IIl() {
                  return this.l;
               }

               private static int IlI(int var0, int var1) {
                  return IIl[var0 ^ -547170428] ^ var1 ^ var0;
               }

               static {
                  int var2 = 1840724202;
                  byte[] var0 = "äÿò\u009bYb1*".getBytes("ISO-8859-1");
                  int var1 = var0.length / 4;
                  IIl = new int[var1];
                  int var3 = 0;
                  int var4 = 0;

                  do {
                     int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
                     var5 ^= var2;
                     IIl[var4] = var5;
                     var3 += 4;
                     ++var4;
                  } while(var4 < var1);

               }
            };
         }
      } else {
         return null.l(var1);
      }
   }

   public static class_1297 IlIllI(class_310 var0) {
      if (var0 != null && llll != null) {
         try {
            return (class_1297)llll.invoke(var0);
         } catch (ReflectiveOperationException var2) {
            return null;
         }
      } else {
         return null;
      }
   }

   public static boolean IlIlll(class_310 var0, Object var1) {
      return IlIllII(var0, var1) && IllIl(var0);
   }

   public static int IllIII(class_2596<?> var0) {
      try {
         return (Integer)var0.getClass().getMethod(lIlIII.Il(IllIlll(-338508988, 2012954040))).invoke(var0);
      } catch (Exception var4) {
         try {
            return (Integer)var0.getClass().getMethod(lIlIII.Il(IllIlll(-338508987, 989925442))).invoke(var0);
         } catch (Exception var3) {
            try {
               return (Integer)var0.getClass().getMethod(lIlIII.Il(IllIlll(-338508986, 355532903))).invoke(var0);
            } catch (Exception var2) {
               return -1;
            }
         }
      }
   }

   public static boolean IllIIl(class_310 var0, class_1268 var1) {
      if (var0 != null && var0.field_1724 != null && var0.field_1761 != null && var1 != null) {
         if (!llIIll(var0)) {
            return false;
         } else {
            if (lIllI(var0) > 0) {
               lIllll(var0);
            }

            boolean var4;
            try {
               class_1269 var2 = lllIlI(var0, var1);
               boolean var3 = var2 != null && var2.method_23665();
               if (var3) {
                  lllIII(var0);
               }

               var4 = var3;
            } finally {
               lIllll(var0);
            }

            return var4;
         }
      } else {
         return false;
      }
   }

   public static int IllIlI(class_304 var0) {
      return var0 == null ? 0 : Math.max(0, IIlllllI.IIIIl(var0));
   }

   private static boolean IllIll(class_310 var0) {
      long var1 = IIII;
      boolean var3 = IIlllllI.lllI(var0);
      return var3 || IIII != var1;
   }

   public static boolean IlllII(class_1799 var0) {
      if (var0 != null && !var0.method_7960()) {
         class_9331 var1 = IIIIll();
         if (var1 != null && var0.method_57826(var1)) {
            return true;
         } else {
            String var2 = class_7923.field_41178.method_10221(var0.method_7909()).method_12832();
            return var2.equals(lIlIII.Il(IllIlll(-338508985, -1605030653)));
         }
      } else {
         return false;
      }
   }

   public static boolean IlllIl() {
      return IlIll >= 0 || IIlIl || IllI.llIl() || Il != null || III > 0 || IIIIl > 0;
   }

   public static boolean IllllI(class_3675.class_306 var0) {
      return var0 == null || var0.equals(class_3675.field_16237) || var0.method_1444() < 0;
   }

   public static class_243 Illlll(class_2777 var0) {
      return IIIIlIl(var0);
   }

   public static float lIIIII(class_2596<?> var0) {
      Float var1 = lIIlll(var0, lIlIII.Il(IllIlll(-338508992, 1023896367)), lIlIII.Il(IllIlll(-338508991, -137864596)));
      return var1 != null ? var1 : Float.NaN;
   }

   public static class_3675.class_306 lIIIIl(JsonElement var0) {
      if (var0 != null && !var0.isJsonNull()) {
         try {
            if (var0.isJsonPrimitive()) {
               return lllll(var0.getAsInt());
            } else {
               JsonObject var1 = var0.getAsJsonObject();
               if (var1.has(lIlIII.Il(IllIlll(-338508990, -1289277630))) && var1.has(lIlIII.Il(IllIlll(-338508989, 1780691398)))) {
                  JsonElement var2 = var1.get(lIlIII.Il(IllIlll(-338508964, -215463459)));
                  class_3675.class_307 var3;
                  if (var2.isJsonPrimitive() && var2.getAsJsonPrimitive().isNumber()) {
                     var3 = var2.getAsInt() == 1 ? class_307.field_1672 : class_307.field_1668;
                  } else {
                     var3 = class_307.valueOf(var2.getAsString());
                  }

                  return var3.method_1447(var1.get(lIlIII.Il(IllIlll(-338508963, -523034052))).getAsInt());
               } else {
                  return class_3675.field_16237;
               }
            }
         } catch (Exception var4) {
            return class_3675.field_16237;
         }
      } else {
         return class_3675.field_16237;
      }
   }

   public static boolean lIIIlI(class_310 var0, class_239 var1) {
      if (var0 != null && var0.field_1724 != null && var0.field_1761 != null) {
         IIlI(var0);
         class_239 var2 = var0.field_1765;
         var0.field_1765 = var1;

         boolean var3;
         try {
            IIlllllI.ll(var0);
            var3 = true;
         } finally {
            var0.field_1765 = var2;
         }

         return var3;
      } else {
         return false;
      }
   }

   public static boolean lIIIll(class_310 var0) {
      return var0 != null && var0.field_1724 != null && var0.field_1724.field_6012 <= IlI;
   }

   public static void lIIlII(class_2596<?> var0) {
      if (var0 instanceof class_2885) {
         ++l;
      } else if (var0 instanceof class_2886) {
         ++llI;
      } else if (var0 instanceof class_2824) {
         class_2824 var1 = (class_2824)var0;
         var1.method_34209(new class_2824.class_5908() {
            public void method_34220(class_1268 var1, class_243 var2) {
            }

            public void method_34219(class_1268 var1) {
            }

            public void method_34218() {
               ++IllllIlI.IIII;
            }
         });
      }

   }

   public static boolean lIIlIl(class_310 var0, int var1) {
      <undefinedtype> var2 = IlIlIl(var0, var1, 0, true);
      return IlIlll(var0, var2);
   }

   public static boolean lIIllI(class_310 var0, Object var1, int var2) {
      if (var0 != null && var0.field_1724 != null && var1 != null && var2 >= 0 && var2 <= IllIllI(516732925, -157844579) && Il == null && !llIl) {
         <undefinedtype> var3 = var0.new null(var0) {
            private final class_310 I;
            private static final int[] l;

            public int I() {
               return IIlllllI.IIIl(this.I.field_1724.method_31548());
            }

            public int l() {
               return IllllIlI.Illll >= 0 && IllllIlI.Illll < ll(2051093048, -579120194) ? IllllIlI.Illll : this.I();
            }

            public void II(Object var1, int var2) {
               switch (var1) {
                  case II:
                     IllllIlI.IIlIlI(this.I, var2, true);
                     break;
                  case lI:
                     IllllIlI.IlIllll(this.I, var2);
                     IllllIlI.IIlIlI(this.I, var2, false);
                     break;
                  case I:
                     int var3 = IIllIlll.lII();
                     if (var3 != var2 && (var3 >= 0 || this.l() != var2)) {
                        IIllIlll.Ill(var2);
                        ++IllllIlI.IlII;

                        try {
                           this.I.method_1562().method_52787(new class_2868(var2));
                        } finally {
                           IllllIlI.IlII = Math.max(0, IllllIlI.IlII - 1);
                        }
                     } else {
                        IIllIlll.Ill(var2);
                     }

                     lIllIIl var4 = lIllIIl.Il();
                     if (var4 != null && var4.IIl() != null && var4.IIl().IllllI() != null && var4.IIl().IllllI().IIIIIlI()) {
                        var4.IIl().IllllI().llI(var2);
                     }
               }

            }

            public int Il() {
               return this.I != null && this.I.field_1724 != null ? this.I.field_1724.field_6012 : 0;
            }

            private {
               this.I = var1;
            }

            public boolean lI(Object var1, int var2) {
               if (var1 == null.I) {
                  if (this.l() != var2 && IIllIlll.lII() != var2) {
                     if (IIllIlll.lII() != var2) {
                        this.II(var1, var2);
                     }

                     return false;
                  } else {
                     return true;
                  }
               } else {
                  return this.I() == var2;
               }
            }

            private static int ll(int var0, int var1) {
               return l[var0 ^ 2051093048] ^ var1 ^ var0;
            }

            static {
               int var2 = -658501509;
               byte[] var0 = "\u007fúqô".getBytes("ISO-8859-1");
               int var1 = var0.length / 4;
               l = new int[var1];
               int var3 = 0;
               int var4 = 0;

               do {
                  int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
                  var5 ^= var2;
                  l[var4] = var5;
                  var3 += 4;
                  ++var4;
               } while(var4 < var1);

            }
         };
         <undefinedtype> var4 = IIIII;
         <undefinedtype> var5 = IllI.I(var3, var1, var2, var4, -1, true, (Runnable)null);
         if (var5.II() == 0L) {
            return false;
         } else {
            if (var4 == null.I) {
               IlllI(var0);
            }

            boolean var6 = var5.II() < 0L ? ((<undefinedtype>)var3).lI(var4, var2) : IllI.lll(var3, var5, var0.field_1724.field_6012);
            if (var6 && lIIl && var4 == null.I) {
               lIl = true;
            }

            return var6;
         }
      } else {
         return false;
      }
   }

   private static Float lIIlll(Object var0, String var1, String var2) {
      if (var0 == null) {
         return null;
      } else {
         Float var3 = llllIl(var0, var1, var2);
         if (var3 != null) {
            return var3;
         } else {
            for(String var7 : new String[]{lIlIII.Il(IllIlll(-338508962, -1088918984)), lIlIII.Il(IllIlll(-338508961, 1874466949)), lIlIII.Il(IllIlll(-338508968, -1797832463)), lIlIII.Il(IllIlll(-338508967, -1233043615)), lIlIII.Il(IllIlll(-338508966, -1257216244))}) {
               try {
                  Object var8 = var0.getClass().getMethod(var7).invoke(var0);
                  Float var9 = llllIl(var8, var1, var2);
                  if (var9 != null) {
                     return var9;
                  }
               } catch (ReflectiveOperationException var10) {
               }
            }

            return null;
         }
      }
   }

   public static void lIlIII(class_310 var0, class_1297 var1) {
      if (var0 != null && lIll != null) {
         try {
            lIll.invoke(var0, var1);
         } catch (ReflectiveOperationException var3) {
         }

      }
   }

   public static void lIlIIl(class_310 var0) {
      <undefinedtype> var1 = Il;
      if (var1 != null && IlllI && var0 != null && var0.field_1724 != null) {
         Il = null;
         IlllI = false;
         if (var1.l() == var0.field_1724) {
            IllI.llll(var0.new null(var0) {
               private final class_310 I;
               private static final int[] l;

               public int I() {
                  return IIlllllI.IIIl(this.I.field_1724.method_31548());
               }

               public int l() {
                  return IllllIlI.Illll >= 0 && IllllIlI.Illll < ll(2051093048, -579120194) ? IllllIlI.Illll : this.I();
               }

               public void II(Object var1, int var2) {
                  switch (var1) {
                     case II:
                        IllllIlI.IIlIlI(this.I, var2, true);
                        break;
                     case lI:
                        IllllIlI.IlIllll(this.I, var2);
                        IllllIlI.IIlIlI(this.I, var2, false);
                        break;
                     case I:
                        int var3 = IIllIlll.lII();
                        if (var3 != var2 && (var3 >= 0 || this.l() != var2)) {
                           IIllIlll.Ill(var2);
                           ++IllllIlI.IlII;

                           try {
                              this.I.method_1562().method_52787(new class_2868(var2));
                           } finally {
                              IllllIlI.IlII = Math.max(0, IllllIlI.IlII - 1);
                           }
                        } else {
                           IIllIlll.Ill(var2);
                        }

                        lIllIIl var4 = lIllIIl.Il();
                        if (var4 != null && var4.IIl() != null && var4.IIl().IllllI() != null && var4.IIl().IllllI().IIIIIlI()) {
                           var4.IIl().IllllI().llI(var2);
                        }
                  }

               }

               public int Il() {
                  return this.I != null && this.I.field_1724 != null ? this.I.field_1724.field_6012 : 0;
               }

               private {
                  this.I = var1;
               }

               public boolean lI(Object var1, int var2) {
                  if (var1 == null.I) {
                     if (this.l() != var2 && IIllIlll.lII() != var2) {
                        if (IIllIlll.lII() != var2) {
                           this.II(var1, var2);
                        }

                        return false;
                     } else {
                        return true;
                     }
                  } else {
                     return this.I() == var2;
                  }
               }

               private static int ll(int var0, int var1) {
                  return l[var0 ^ 2051093048] ^ var1 ^ var0;
               }

               static {
                  int var2 = -658501509;
                  byte[] var0 = "\u007fúqô".getBytes("ISO-8859-1");
                  int var1 = var0.length / 4;
                  l = new int[var1];
                  int var3 = 0;
                  int var4 = 0;

                  do {
                     int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
                     var5 ^= var2;
                     l[var4] = var5;
                     var3 += 4;
                     ++var4;
                  } while(var4 < var1);

               }
            }, var1.I(), null.II);
         }
      }
   }

   public static class_3966 lIlIlI(class_310 var0, class_1309 var1, double var2) {
      return IlIIll(var0, var1, var2, true);
   }

   public static void lIlIll(class_2596<?> var0) {
      if (var0 instanceof class_2868 var1) {
         IIllIlll.Ill(var1.method_12442());
         if (IlII == 0) {
            IIIl();
         }
      }

   }

   private static boolean lIllII(class_310 var0, int var1) {
      if (var0 != null && var0.method_22683() != null) {
         if (IIlII != null) {
            try {
               Class var2 = IIlII.getParameterTypes()[0];
               Object var3 = var2 == Long.TYPE ? var0.method_22683().method_4490() : var0.method_22683();
               return (Boolean)IIlII.invoke((Object)null, var3, var1);
            } catch (ReflectiveOperationException var4) {
            }
         }

         return GLFW.glfwGetKey(var0.method_22683().method_4490(), var1) == 1;
      } else {
         return false;
      }
   }

   public static void lIllIl(long var0, int var2, int var3) {
      if (var2 >= 0 && var2 < IlIII.length) {
         if (var3 == 1) {
            IlIII[var2] = true;
            Illl[var2] = true;
         } else if (var3 == 0) {
            IlIII[var2] = false;
         }

      }
   }

   public static boolean lIlllI(int var0) {
      return var0 >= 0 && var0 < IlIII.length && IlIII[var0];
   }

   public static void lIllll(class_310 var0) {
      IIlllllI.IlIl(var0, 0);
   }

   public static boolean llIIII(Object var0) {
      return IllI.IIlI(var0);
   }

   public static void llIIIl(class_744 var0, float var1, float var2) {
      try {
         if (IIll != null && IIIlI != null) {
            IIll.setFloat(var0, var1);
            IIIlI.setFloat(var0, var2);
         } else if (IIlll != null) {
            IIlll.set(var0, new class_241(var2, var1));
         }
      } catch (ReflectiveOperationException var4) {
      }

   }

   public static void llIIlI(class_310 var0, Object var1, int var2) {
      llll(var0, var1, var2, 1);
   }

   private static boolean llIIll(class_310 var0) {
      return var0 == null || var0.field_1724 == null || var0.field_1724.field_6012 != IIlI;
   }

   public static long llIlII() {
      return llI;
   }

   public static void llIlIl(class_310 var0, float var1) {
      if (var0 != null && var0.field_1724 != null) {
         var0.field_1724.method_5847(var1);
         IllIIII(IIllI, var0.field_1724, var1);
         IllIIII(lII, var0.field_1724, var1);

         try {
            var0.field_1724.getClass().getMethod(lIlIII.Il(IllIlll(-338508965, -1375706208)), Float.TYPE).invoke(var0.field_1724, var1);
         } catch (ReflectiveOperationException var3) {
            IllIIII(lIIlI, var0.field_1724, var1);
         }

         IllIIII(IllIl, var0.field_1724, var1);
      }
   }

   public static boolean llIllI(class_310 var0) {
      return var0 != null && var0.field_1724 != null && var0.field_1761 != null ? lIIIlI(var0, var0.field_1765) : false;
   }

   public static void llIlll() {
      ++IIII;
   }

   private static void lllIII(class_310 var0) {
      if (var0 != null && var0.field_1724 != null) {
         IIlI = var0.field_1724.field_6012;
      }

   }

   private static class_243 lllIIl(Object var0) {
      if (var0 == null) {
         return null;
      } else if (var0 instanceof class_243) {
         class_243 var4 = (class_243)var0;
         return var4;
      } else {
         Double var1 = IllI(var0, lIlIII.Il(IllIlll(-338508972, 952636141)), lIlIII.Il(IllIlll(-338508971, 1541175808)));
         Double var2 = IllI(var0, lIlIII.Il(IllIlll(-338508970, 72186577)), lIlIII.Il(IllIlll(-338508969, 681532927)));
         Double var3 = IllI(var0, lIlIII.Il(IllIlll(-338508976, -1773652859)), lIlIII.Il(IllIlll(-338508975, -2093989950)));
         return var1 != null && var2 != null && var3 != null ? new class_243(var1, var2, var3) : null;
      }
   }

   public static class_1269 lllIlI(class_310 var0, class_1268 var1) {
      if (var0 != null && var0.field_1724 != null && var0.field_1761 != null && var1 != null) {
         if (!llIIll(var0)) {
            return class_1269.field_5814;
         } else {
            IIlI(var0);
            class_1269 var2 = var0.field_1761.method_2919(var0.field_1724, var1);
            if (var2 != null && var2.method_23665()) {
               lllIII(var0);
            }

            return var2;
         }
      } else {
         return class_1269.field_5814;
      }
   }

   public static boolean lllIll(class_310 var0) {
      if (var0 != null && var0.field_1761 != null) {
         IIlllllI.III(var0.field_1761);
         return true;
      } else {
         return false;
      }
   }

   public static boolean llllII() {
      return lIIl;
   }

   private static Float llllIl(Object var0, String var1, String var2) {
      if (var0 == null) {
         return null;
      } else {
         try {
            return ((Number)var0.getClass().getMethod(var1).invoke(var0)).floatValue();
         } catch (ReflectiveOperationException var6) {
            try {
               return ((Number)var0.getClass().getMethod(var2).invoke(var0)).floatValue();
            } catch (ReflectiveOperationException var5) {
               try {
                  Field var3 = var0.getClass().getDeclaredField(var2);
                  var3.setAccessible(true);
                  return ((Number)var3.get(var0)).floatValue();
               } catch (ReflectiveOperationException var4) {
                  return null;
               }
            }
         }
      }
   }

   public static boolean lllllI(class_1309 var0) {
      if (var0 == null) {
         return false;
      } else if (var0.method_6039()) {
         return true;
      } else {
         return var0.method_6115() && IlllII(var0.method_6030());
      }
   }

   public static void llllll(class_310 var0, int var1) {
      IIlllllI.II(var0, Math.max(0, var1));
   }

   public static <undefinedtype> IIIIIII(class_310 var0, int var1) {
      return IlIlIl(var0, var1, 0, true);
   }

   public static void IIIIIIl(class_310 var0) {
      lIllIIl var1 = lIllIIl.Il();
      if (var1 != null && var1.IIl() != null) {
         IlllIllI var2 = var1.IIl().IlIlIl();
         if (var2 != null && var2.IIIIIlI() && var2.IIIIIII()) {
            var2.IIIIl(var0);
         }

      }
   }

   public static void IIIIIlI() {
      if (Il != null) {
         IlllI = true;
      }

   }

   public static void IIIIIll(class_2596<?> var0) {
      if (var0 instanceof class_2868 var1) {
         IIllIlll.II(var1.method_12442());
      }

   }

   public static int IIIIlII(class_310 var0) {
      return var0 == null ? 0 : IIlllllI.Ill(var0);
   }

   private static class_243 IIIIlIl(Object var0) {
      if (var0 == null) {
         return null;
      } else {
         class_243 var1 = lllIIl(var0);
         if (var1 != null) {
            return var1;
         } else {
            for(String var5 : new String[]{lIlIII.Il(IllIlll(-338508974, 728242751)), lIlIII.Il(IllIlll(-338508973, -401704332)), lIlIII.Il(IllIlll(-338509012, -1985913244)), lIlIII.Il(IllIlll(-338509011, 1388336109)), lIlIII.Il(IllIlll(-338509010, 1246583155))}) {
               try {
                  Object var6 = var0.getClass().getMethod(var5).invoke(var0);
                  class_243 var7 = lllIIl(var6);
                  if (var7 != null) {
                     return var7;
                  }
               } catch (ReflectiveOperationException var8) {
               }
            }

            return null;
         }
      }
   }

   public static void IIIIllI(class_304 var0) {
      if (var0 != null) {
         IIlllllI.lll(var0, 0);
      }

   }

   public static boolean IIIIlll(class_310 var0, int var1) {
      <undefinedtype> var2 = IlIlIl(var0, var1, 0, true);
      return IIIIIl(var0, var2);
   }

   public static void IIIlIII(class_310 var0, float var1, float var2) {
      if (var0 != null && var0.field_1724 != null) {
         float[] var3 = IlIlIl.lIlII(var0, var1, var2);
         if (var3 != null) {
            var0.field_1724.method_36456(var3[0]);
            var0.field_1724.method_36457(var3[1]);
            llIlIl(var0, var3[0]);
         }
      }
   }

   public static class_3675.class_306 IIIlIIl(class_304 var0) {
      if (var0 == null) {
         return class_3675.field_16237;
      } else {
         if (Ill != null) {
            try {
               Object var1 = Ill.get(var0);
               if (var1 instanceof class_3675.class_306) {
                  class_3675.class_306 var2 = (class_3675.class_306)var1;
                  if (!IllllI(var2)) {
                     return var2;
                  }
               }
            } catch (ReflectiveOperationException var4) {
            }
         }

         try {
            String var5 = var0.method_1428();
            if (var5 != null && !var5.isBlank()) {
               class_3675.class_306 var6 = class_3675.method_15981(var5);
               if (!IllllI(var6)) {
                  return var6;
               }
            }
         } catch (Throwable var3) {
         }

         return class_3675.field_16237;
      }
   }

   public static void IIIlIlI(class_310 var0, int var1, boolean var2) {
      if (var0 != null && var0.field_1724 != null && var0.field_1690 != null && var1 >= 0 && var1 <= IllIllI(516732924, 315940246)) {
         class_304[] var3 = var0.field_1690.field_1852;
         class_304 var4 = null;
         if (var3 != null && var1 < var3.length) {
            var4 = var3[var1];
         }

         if (var4 != null) {
            class_3675.class_306 var5 = IIIlIIl(var4);
            if (!IllllI(var5)) {
               llII(var4, var5);
            }
         }

         IIlIlI(var0, var1, var2);
      }
   }

   public static class_3965 IIIlIll(class_310 var0, class_1297 var1, class_243 var2, class_243 var3) {
      if (var0 != null && var0.field_1687 != null && var1 != null) {
         class_243 var4 = var2;
         int var5 = IllIllI(516732927, 248766752);

         while(var5-- > 0) {
            class_3965 var6 = var0.field_1687.method_17742(new class_3959(var4, var3, class_3960.field_17558, class_242.field_1348, var1));
            if (var6 != null && var6.method_17783() != class_240.field_1333) {
               class_2680 var7 = var0.field_1687.method_8320(var6.method_17777());
               if (!var7.method_27852(class_2246.field_10343) && !var7.method_27852(class_2246.field_10382) && !var7.method_26215() && !var7.method_45474() && !var7.method_26220(var0.field_1687, var6.method_17777()).method_1110()) {
                  return var6;
               }

               class_243 var8 = var3.method_1020(var4).method_1029();
               var4 = var6.method_17784().method_1019(var8.method_1021(0.01));
               if (!(var4.method_1025(var2) >= var3.method_1025(var2))) {
                  continue;
               }
               break;
            }

            return var6;
         }

         return null;
      } else {
         return null;
      }
   }

   public static boolean IIIllII(class_3675.class_306 var0) {
      return var0 != null && var0.method_1442() == class_307.field_1672 && !IllllI(var0);
   }

   public static int IIIllIl(class_1661 var0) {
      if (var0 == null) {
         return 0;
      } else {
         class_310 var1 = class_310.method_1551();
         if (var1 != null && var1.field_1724 != null && var1.field_1724.method_31548() == var0) {
            lIllIIl var2 = lIllIIl.Il();
            if (var2 != null && var2.IIl() != null && var2.IIl().IllllI() != null && var2.IIl().IllllI().IIIIIlI()) {
               if (IllI.llIl()) {
                  return IllI.Il(var1.new null(var1) {
                     private final class_310 I;
                     private static final int[] l;

                     public int I() {
                        return IIlllllI.IIIl(this.I.field_1724.method_31548());
                     }

                     public int l() {
                        return IllllIlI.Illll >= 0 && IllllIlI.Illll < ll(2051093048, -579120194) ? IllllIlI.Illll : this.I();
                     }

                     public void II(Object var1, int var2) {
                        switch (var1) {
                           case II:
                              IllllIlI.IIlIlI(this.I, var2, true);
                              break;
                           case lI:
                              IllllIlI.IlIllll(this.I, var2);
                              IllllIlI.IIlIlI(this.I, var2, false);
                              break;
                           case I:
                              int var3 = IIllIlll.lII();
                              if (var3 != var2 && (var3 >= 0 || this.l() != var2)) {
                                 IIllIlll.Ill(var2);
                                 ++IllllIlI.IlII;

                                 try {
                                    this.I.method_1562().method_52787(new class_2868(var2));
                                 } finally {
                                    IllllIlI.IlII = Math.max(0, IllllIlI.IlII - 1);
                                 }
                              } else {
                                 IIllIlll.Ill(var2);
                              }

                              lIllIIl var4 = lIllIIl.Il();
                              if (var4 != null && var4.IIl() != null && var4.IIl().IllllI() != null && var4.IIl().IllllI().IIIIIlI()) {
                                 var4.IIl().IllllI().llI(var2);
                              }
                        }

                     }

                     public int Il() {
                        return this.I != null && this.I.field_1724 != null ? this.I.field_1724.field_6012 : 0;
                     }

                     private {
                        this.I = var1;
                     }

                     public boolean lI(Object var1, int var2) {
                        if (var1 == null.I) {
                           if (this.l() != var2 && IIllIlll.lII() != var2) {
                              if (IIllIlll.lII() != var2) {
                                 this.II(var1, var2);
                              }

                              return false;
                           } else {
                              return true;
                           }
                        } else {
                           return this.I() == var2;
                        }
                     }

                     private static int ll(int var0, int var1) {
                        return l[var0 ^ 2051093048] ^ var1 ^ var0;
                     }

                     static {
                        int var2 = -658501509;
                        byte[] var0 = "\u007fúqô".getBytes("ISO-8859-1");
                        int var1 = var0.length / 4;
                        l = new int[var1];
                        int var3 = 0;
                        int var4 = 0;

                        do {
                           int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
                           var5 ^= var2;
                           l[var4] = var5;
                           var3 += 4;
                           ++var4;
                        } while(var4 < var1);

                     }
                  });
               }

               int var3 = var2.IIl().IllllI().ll(var1.field_1724.field_6012);
               if (var3 >= 0 && var3 < IllIllI(516732926, 704570254)) {
                  return var3;
               }
            }
         }

         return IIlllllI.IIIl(var0);
      }
   }

   public static void IIIlllI(class_310 var0, int var1, int var2) {
      if (var0 != null && var0.field_1724 != null && var1 >= 0 && var1 <= IllIllI(516732921, -999071261)) {
         int var3 = lIIlI(var0.field_1724.method_31548());
         if (var3 != var1) {
            lIII.add(new Record(var0.field_1724, var1, var3, var0.field_1724.field_6012 + Math.max(1, var2)) {
               private final class_746 I;
               private final int l;
               private final int II;
               private final int Il;

               private {
                  this.I = var1;
                  this.II = var2;
                  this.Il = var3;
                  this.l = var4;
               }

               public int I() {
                  return this.II;
               }

               public class_746 l() {
                  return this.I;
               }

               public int II() {
                  return this.l;
               }

               public int Il() {
                  return this.Il;
               }
            });
         }
      }
   }

   public static void IIIllll() {
      ++IIIIl;
   }

   public static boolean IIlIIII(class_310 var0, class_3965 var1) {
      if (var0 != null && var0.field_1724 != null && var0.field_1761 != null && var1 != null) {
         if (!llIIll(var0)) {
            return false;
         } else {
            if (lIllI(var0) > 0) {
               lIllll(var0);
            }

            boolean var4;
            try {
               class_1269 var2 = lIlII(var0, class_1268.field_5808, var1);
               boolean var3 = var2 != null && var2.method_23665();
               if (var3) {
                  lllIII(var0);
               }

               var4 = var3;
            } finally {
               lIllll(var0);
            }

            return var4;
         }
      } else {
         return false;
      }
   }

   public static long IIlIIIl() {
      return l;
   }

   public static boolean IIlIIlI(class_310 var0, int var1) {
      if (var0 != null && var0.field_1724 != null && var1 >= 0 && var1 < IllIllI(516732920, 772908106)) {
         if (Illll >= 0) {
            return Illll == var1;
         } else {
            return IIllIlll.lII() < 0 && IIlllllI.IIIl(var0.field_1724.method_31548()) == var1 && IlIll < 0 && !IIlIl;
         }
      } else {
         return false;
      }
   }

   public static boolean IIlIIll(class_310 var0) {
      if (var0.field_1724 != null && var0.field_1724.field_3913 != null) {
         try {
            Field var1 = var0.field_1724.field_3913.getClass().getField(lIlIII.Il(IllIlll(-338509009, 1990344066)));
            Object var2 = var1.get(var0.field_1724.field_3913);
            return (Boolean)var2.getClass().getMethod(lIlIII.Il(IllIlll(-338509016, -321186708))).invoke(var2) || (Boolean)var2.getClass().getMethod(lIlIII.Il(IllIlll(-338509015, 1608086187))).invoke(var2) || (Boolean)var2.getClass().getMethod(lIlIII.Il(IllIlll(-338509014, -1372776029))).invoke(var2) || (Boolean)var2.getClass().getMethod(lIlIII.Il(IllIlll(-338509013, 777147726))).invoke(var2);
         } catch (Exception var4) {
            try {
               return var0.field_1724.field_3913.getClass().getField(lIlIII.Il(IllIlll(-338509020, 1581729562))).getBoolean(var0.field_1724.field_3913) || var0.field_1724.field_3913.getClass().getField(lIlIII.Il(IllIlll(-338509019, 937166368))).getBoolean(var0.field_1724.field_3913) || var0.field_1724.field_3913.getClass().getField(lIlIII.Il(IllIlll(-338509018, 311780740))).getBoolean(var0.field_1724.field_3913) || var0.field_1724.field_3913.getClass().getField(lIlIII.Il(IllIlll(-338509017, -276803844))).getBoolean(var0.field_1724.field_3913);
            } catch (Exception var3) {
               return false;
            }
         }
      } else {
         return false;
      }
   }

   public static boolean IIlIlII(class_310 var0) {
      if (var0 != null && var0.field_1724 != null && var0.field_1761 != null) {
         IIIIIIl(var0);
         class_1297 var1 = llIII(var0);
         return llI(var0, var1) ? false : IllIll(var0);
      } else {
         return false;
      }
   }

   public static float IIlIlIl(class_1309 var0, float var1) {
      if (var0 == null) {
         return 0.0F;
      } else {
         float var2 = IlIlI(lII, var0, var0.method_36454());
         float var3 = IlIlI(IIllI, var0, var2);
         return class_3532.method_17821(var1, var3, var2);
      }
   }

   public static boolean IIlIllI(class_310 var0, class_3675.class_306 var1) {
      if (var0 != null && var0.field_1690 != null && !IllllI(var1) && var0.field_1690.field_1852 != null) {
         for(class_304 var5 : var0.field_1690.field_1852) {
            if (var5 != null && var1.equals(IIIlIIl(var5))) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public static void IIlIlll() {
      lIIl = false;
      lIl = false;
      llIl = false;
      IlIl = false;
   }

   public static boolean IIllIII(class_1309 var0) {
      if (var0 == null) {
         return false;
      } else {
         try {
            return (Boolean)var0.getClass().getMethod(lIlIII.Il(IllIlll(-338509024, -1182835927))).invoke(var0);
         } catch (ReflectiveOperationException var3) {
            try {
               return (Boolean)var0.getClass().getMethod(lIlIII.Il(IllIlll(-338509023, 843187707))).invoke(var0);
            } catch (ReflectiveOperationException var2) {
               return false;
            }
         }
      }
   }

   public static boolean IIllIIl(class_310 var0, Object var1, int var2, Object var3, int var4, boolean var5, Runnable var6) {
      if (var0 != null && var0.field_1724 != null) {
         <undefinedtype> var7 = IllI.I(var0.new null(var0) {
            private final class_310 I;
            private static final int[] l;

            public int I() {
               return IIlllllI.IIIl(this.I.field_1724.method_31548());
            }

            public int l() {
               return IllllIlI.Illll >= 0 && IllllIlI.Illll < ll(2051093048, -579120194) ? IllllIlI.Illll : this.I();
            }

            public void II(Object var1, int var2) {
               switch (var1) {
                  case II:
                     IllllIlI.IIlIlI(this.I, var2, true);
                     break;
                  case lI:
                     IllllIlI.IlIllll(this.I, var2);
                     IllllIlI.IIlIlI(this.I, var2, false);
                     break;
                  case I:
                     int var3 = IIllIlll.lII();
                     if (var3 != var2 && (var3 >= 0 || this.l() != var2)) {
                        IIllIlll.Ill(var2);
                        ++IllllIlI.IlII;

                        try {
                           this.I.method_1562().method_52787(new class_2868(var2));
                        } finally {
                           IllllIlI.IlII = Math.max(0, IllllIlI.IlII - 1);
                        }
                     } else {
                        IIllIlll.Ill(var2);
                     }

                     lIllIIl var4 = lIllIIl.Il();
                     if (var4 != null && var4.IIl() != null && var4.IIl().IllllI() != null && var4.IIl().IllllI().IIIIIlI()) {
                        var4.IIl().IllllI().llI(var2);
                     }
               }

            }

            public int Il() {
               return this.I != null && this.I.field_1724 != null ? this.I.field_1724.field_6012 : 0;
            }

            private {
               this.I = var1;
            }

            public boolean lI(Object var1, int var2) {
               if (var1 == null.I) {
                  if (this.l() != var2 && IIllIlll.lII() != var2) {
                     if (IIllIlll.lII() != var2) {
                        this.II(var1, var2);
                     }

                     return false;
                  } else {
                     return true;
                  }
               } else {
                  return this.I() == var2;
               }
            }

            private static int ll(int var0, int var1) {
               return l[var0 ^ 2051093048] ^ var1 ^ var0;
            }

            static {
               int var2 = -658501509;
               byte[] var0 = "\u007fúqô".getBytes("ISO-8859-1");
               int var1 = var0.length / 4;
               l = new int[var1];
               int var3 = 0;
               int var4 = 0;

               do {
                  int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
                  var5 ^= var2;
                  l[var4] = var5;
                  var3 += 4;
                  ++var4;
               } while(var4 < var1);

            }
         }, var1, var2, var3, var4, var5, var6);
         return var7.II() != 0L;
      } else {
         return false;
      }
   }

   public static boolean IIllIlI(class_310 var0) {
      if (var0 != null && var0.field_1724 != null && var0.field_1761 != null && var0.field_1690 != null && var0.field_1690.field_1904 != null) {
         if (IllllI(IIIlIIl(var0.field_1690.field_1904))) {
            return false;
         } else {
            lIllll(var0);
            llIllI(var0);
            return true;
         }
      } else {
         return false;
      }
   }

   private static void IIllIll(int[] var0) {
      if (var0 != null) {
         for(int var1 = 0; var1 < var0.length; ++var1) {
            int var2 = var0[var1];
            int var3 = var2 >> IllIllI(516732923, 320068438) & IllIllI(516732922, -755687962);
            int var4 = var2 >> IllIllI(516732917, 1390226485) & IllIllI(516732916, -997558916);
            int var5 = var2 >> IllIllI(516732919, 1649393240) & IllIllI(516732918, 1508365308);
            int var6 = var2 & IllIllI(516732913, 874531062);
            var0[var1] = var3 << IllIllI(516732912, 1266091244) | var6 << IllIllI(516732915, 391265700) | var5 << IllIllI(516732914, -1589065280) | var4;
         }

      }
   }

   public static boolean IIlllII(class_310 var0, class_1297 var1) {
      if (var0 != null && var0.field_1724 != null) {
         class_3966 var2 = var1 == null ? null : new class_3966(var1);
         IIIIIIl(var0);
         class_239 var3 = var0.field_1765;
         if (var1 != null) {
            var0.field_1765 = var2;
         }

         boolean var4;
         try {
            var4 = I(var0);
         } finally {
            var0.field_1765 = var3;
         }

         return var4;
      } else {
         return false;
      }
   }

   public static void IIlllIl(class_310 var0, class_1297 var1) {
      if (var0 != null && var0.field_1724 != null && var0.field_1761 != null && var1 != null) {
         IIlllII(var0, var1);
      }
   }

   private static void IIllllI(class_310 var0, int var1) {
      if (var0 != null && var0.field_1724 != null && var0.field_1761 != null && var1 >= 0 && var1 <= IllIllI(516732877, 1470169304)) {
         if (lIIl && IIlllllI.lIl(var0.field_1761) <= 0) {
            IIlllllI.III(var0.field_1761);
            IlIll = -1;
            IIlIl = false;
         } else {
            IlIll = var1;
            IIlIl = true;
         }
      }
   }

   public static float IIlllll(class_1309 var0, float var1) {
      if (var0 == null) {
         return 0.0F;
      } else {
         float var2 = IlIlI(lIIlI, var0, var0.method_36454());
         float var3 = IlIlI(IllIl, var0, var2);
         return class_3532.method_17821(var1, var3, var2);
      }
   }

   public static void IlIIIII(class_310 var0, int var1) {
      IIIlIlI(var0, var1, false);
   }

   public static boolean IlIIIIl() {
      return (IIIIl > 0 || lIl) && IllI.Ill();
   }

   public static float IlIIIlI(class_310 var0) {
      return IIllIl(var0.method_61966(), true);
   }

   public static void IlIIIll(class_310 var0) {
      IIlllllI.II(var0, 0);
   }

   public static boolean IlIIlII(class_310 var0, double var1, boolean var3) {
      if (var0 != null && var0.field_1724 != null) {
         float var4 = var0.field_1724.method_7261(0.0F);
         if (var3 && var4 < 1.0F) {
            return false;
         } else {
            return var4 >= (float)var1;
         }
      } else {
         return false;
      }
   }

   public static boolean IlIIlIl(int var0) {
      return var0 >= 0 && var0 < Illl.length && Illl[var0];
   }

   public static class_3966 IlIIllI(class_310 var0, double var1) {
      if (var0 != null && var0.field_1724 != null && var0.field_1687 != null) {
         Object var3 = var0.method_1560() != null ? var0.method_1560() : var0.field_1724;
         class_243 var4 = ((class_1297)var3).method_5836(1.0F);
         class_243 var5 = ((class_1297)var3).method_5828(1.0F);
         class_243 var6 = var4.method_1019(var5.method_1021(var1));
         class_238 var7 = ((class_1297)var3).method_5829().method_18804(var5.method_1021(var1)).method_1009((double)1.0F, (double)1.0F, (double)1.0F);
         class_3966 var8 = class_1675.method_18075((class_1297)var3, var4, var6, var7, (var0x) -> !var0x.method_7325() && var0x instanceof class_1309 && !x.IlIII.II(var0x), var1 * var1);
         if (var8 != null) {
            class_239 var9 = ((class_1297)var3).method_5745(var1, 1.0F, false);
            if (var9 != null && var9.method_17783() != class_240.field_1333 && var4.method_1025(var9.method_17784()) < var4.method_1025(var8.method_17784())) {
               var8 = null;
            }
         }

         return var8;
      } else {
         return null;
      }
   }

   public static void IlIIlll() {
      III();
      Illll = -1;
      lll = IllIllI(516732876, 443793202);
      ll = Long.MIN_VALUE;
   }

   public static boolean IlIlIII(class_310 var0, class_3966 var1) {
      if (var0 != null && var0.field_1724 != null && var0.field_1761 != null && var1 != null) {
         class_1297 var2 = var1.method_17782();
         if (var2 == null) {
            return false;
         } else {
            IIIIIIl(var0);
            if (llI(var0, var2)) {
               return false;
            } else {
               ++IIIl;

               boolean var3;
               try {
                  IIlII(var0);
                  var0.field_1724.method_6104(class_1268.field_5808);
                  var0.field_1761.method_2918(var0.field_1724, var2);
                  var3 = true;
               } finally {
                  IIIl = Math.max(0, IIIl - 1);
               }

               return var3;
            }
         }
      } else {
         return false;
      }
   }

   private static boolean IlIlIIl(Object var0, int var1) {
      for(<undefinedtype> var3 : lIII) {
         if (var3.l() == var0.l() && var3.Il() == var1 && var3.I() == var0.Il()) {
            return true;
         }
      }

      return false;
   }

   public static int IlIlIlI(class_2777 var0) {
      try {
         return (Integer)var0.getClass().getMethod(lIlIII.Il(IllIlll(-338509022, 1327694601))).invoke(var0);
      } catch (Exception var4) {
         try {
            return (Integer)var0.getClass().getMethod(lIlIII.Il(IllIlll(-338509021, -1591537141))).invoke(var0);
         } catch (Exception var3) {
            return 0;
         }
      }
   }

   public static boolean IlIlIll(class_310 var0) {
      if (var0 != null && var0.field_1724 != null && var0.field_1761 != null) {
         if (var0.field_1724.method_6115()) {
            return true;
         } else {
            return IIlllllI.lIlI(var0) > 0;
         }
      } else {
         return false;
      }
   }

   public static boolean IlIllII(class_310 var0, Object var1) {
      if (var0 != null && var0.field_1724 != null && var1 != null && var1.III()) {
         if (var1.IIl() != null && var1.IIl().II() != 0L) {
            <undefinedtype> var2 = var0.new null(var0) {
               private final class_310 I;
               private static final int[] l;

               public int I() {
                  return IIlllllI.IIIl(this.I.field_1724.method_31548());
               }

               public int l() {
                  return IllllIlI.Illll >= 0 && IllllIlI.Illll < ll(2051093048, -579120194) ? IllllIlI.Illll : this.I();
               }

               public void II(Object var1, int var2) {
                  switch (var1) {
                     case II:
                        IllllIlI.IIlIlI(this.I, var2, true);
                        break;
                     case lI:
                        IllllIlI.IlIllll(this.I, var2);
                        IllllIlI.IIlIlI(this.I, var2, false);
                        break;
                     case I:
                        int var3 = IIllIlll.lII();
                        if (var3 != var2 && (var3 >= 0 || this.l() != var2)) {
                           IIllIlll.Ill(var2);
                           ++IllllIlI.IlII;

                           try {
                              this.I.method_1562().method_52787(new class_2868(var2));
                           } finally {
                              IllllIlI.IlII = Math.max(0, IllllIlI.IlII - 1);
                           }
                        } else {
                           IIllIlll.Ill(var2);
                        }

                        lIllIIl var4 = lIllIIl.Il();
                        if (var4 != null && var4.IIl() != null && var4.IIl().IllllI() != null && var4.IIl().IllllI().IIIIIlI()) {
                           var4.IIl().IllllI().llI(var2);
                        }
                  }

               }

               public int Il() {
                  return this.I != null && this.I.field_1724 != null ? this.I.field_1724.field_6012 : 0;
               }

               private {
                  this.I = var1;
               }

               public boolean lI(Object var1, int var2) {
                  if (var1 == null.I) {
                     if (this.l() != var2 && IIllIlll.lII() != var2) {
                        if (IIllIlll.lII() != var2) {
                           this.II(var1, var2);
                        }

                        return false;
                     } else {
                        return true;
                     }
                  } else {
                     return this.I() == var2;
                  }
               }

               private static int ll(int var0, int var1) {
                  return l[var0 ^ 2051093048] ^ var1 ^ var0;
               }

               static {
                  int var2 = -658501509;
                  byte[] var0 = "\u007fúqô".getBytes("ISO-8859-1");
                  int var1 = var0.length / 4;
                  l = new int[var1];
                  int var3 = 0;
                  int var4 = 0;

                  do {
                     int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
                     var5 ^= var2;
                     l[var4] = var5;
                     var3 += 4;
                     ++var4;
                  } while(var4 < var1);

               }
            };
            <undefinedtype> var3 = IllI.llII(var1.IIl().l());
            if (var3 == null) {
               var3 = IIIII;
            }

            if (var3 != null.lI && var3 != null.II) {
               if (!IllI.llI(var2, var1.IIl(), var1.ll(), null.I, var1.II())) {
                  return false;
               } else if (!var1.IIl().I()) {
                  return true;
               } else {
                  int var4 = Math.max(0, var1.II() - var1.Il());
                  boolean var5 = Illll == var1.ll();
                  boolean var6 = IIllIlll.lII() == var1.ll();
                  if (var5 || var4 == 0 && var6) {
                     long var7 = var5 ? (long)lll : (long)var1.Il();
                     long var9 = var7 + (long)var4;
                     return (long)var0.field_1724.field_6012 >= Math.max((long)var1.II(), var9);
                  } else {
                     return false;
                  }
               }
            } else if (!IllI.llI(var2, var1.IIl(), var1.ll(), var3, var1.II())) {
               return false;
            } else {
               return var0.field_1724.field_6012 >= var1.II() && lIIlI(var0.field_1724.method_31548()) == var1.ll();
            }
         } else if (IIIII == null.lI || IlIll < 0 && !IIlIl) {
            return var0.field_1724.field_6012 >= var1.II() && lIIlI(var0.field_1724.method_31548()) == var1.ll();
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public static boolean IlIllIl(class_310 var0, class_1297 var1) {
      return llI(var0, var1);
   }

   public static boolean IlIlllI(class_2596<?> var0) {
      return var0.getClass().getName().contains(lIlIII.Il(IllIlll(-338508996, -61453190)));
   }

   public static boolean IlIllll(class_310 var0, int var1) {
      if (var0 != null && var0.field_1690 != null && var1 >= 0 && var1 <= IllIllI(516732879, 377726032)) {
         class_304[] var2 = var0.field_1690.field_1852;
         if (var2 != null && var1 < var2.length) {
            class_304 var3 = var2[var1];
            if (var3 == null) {
               return false;
            } else {
               class_3675.class_306 var4 = IIIlIIl(var3);
               if (IllllI(var4)) {
                  return false;
               } else {
                  IIlIII(var3);
                  return true;
               }
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private static void IllIIII(Field var0, Object var1, float var2) {
      if (var0 != null && var1 != null) {
         try {
            var0.setFloat(var1, var2);
         } catch (ReflectiveOperationException var4) {
         }

      }
   }

   public static <undefinedtype> IllIIIl(class_310 var0, Object var1, int var2, Object var3, int var4, boolean var5) {
      if (var0 != null && var0.field_1724 != null && var1 != null && var2 >= 0 && var2 <= IllIllI(516732878, 1838650081) && Il == null && !llIl) {
         int var6 = var0.field_1724.field_6012;
         int var7 = IllI.Il(var0.new null(var0) {
            private final class_310 I;
            private static final int[] l;

            public int I() {
               return IIlllllI.IIIl(this.I.field_1724.method_31548());
            }

            public int l() {
               return IllllIlI.Illll >= 0 && IllllIlI.Illll < ll(2051093048, -579120194) ? IllllIlI.Illll : this.I();
            }

            public void II(Object var1, int var2) {
               switch (var1) {
                  case II:
                     IllllIlI.IIlIlI(this.I, var2, true);
                     break;
                  case lI:
                     IllllIlI.IlIllll(this.I, var2);
                     IllllIlI.IIlIlI(this.I, var2, false);
                     break;
                  case I:
                     int var3 = IIllIlll.lII();
                     if (var3 != var2 && (var3 >= 0 || this.l() != var2)) {
                        IIllIlll.Ill(var2);
                        ++IllllIlI.IlII;

                        try {
                           this.I.method_1562().method_52787(new class_2868(var2));
                        } finally {
                           IllllIlI.IlII = Math.max(0, IllllIlI.IlII - 1);
                        }
                     } else {
                        IIllIlll.Ill(var2);
                     }

                     lIllIIl var4 = lIllIIl.Il();
                     if (var4 != null && var4.IIl() != null && var4.IIl().IllllI() != null && var4.IIl().IllllI().IIIIIlI()) {
                        var4.IIl().IllllI().llI(var2);
                     }
               }

            }

            public int Il() {
               return this.I != null && this.I.field_1724 != null ? this.I.field_1724.field_6012 : 0;
            }

            private {
               this.I = var1;
            }

            public boolean lI(Object var1, int var2) {
               if (var1 == null.I) {
                  if (this.l() != var2 && IIllIlll.lII() != var2) {
                     if (IIllIlll.lII() != var2) {
                        this.II(var1, var2);
                     }

                     return false;
                  } else {
                     return true;
                  }
               } else {
                  return this.I() == var2;
               }
            }

            private static int ll(int var0, int var1) {
               return l[var0 ^ 2051093048] ^ var1 ^ var0;
            }

            static {
               int var2 = -658501509;
               byte[] var0 = "\u007fúqô".getBytes("ISO-8859-1");
               int var1 = var0.length / 4;
               l = new int[var1];
               int var3 = 0;
               int var4 = 0;

               do {
                  int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
                  var5 ^= var2;
                  l[var4] = var5;
                  var3 += 4;
                  ++var4;
               } while(var4 < var1);

            }
         });
         boolean var8 = var7 != var2;
         <undefinedtype> var9 = IllI.lIll(var0.new null(var0) {
            private final class_310 I;
            private static final int[] l;

            public int I() {
               return IIlllllI.IIIl(this.I.field_1724.method_31548());
            }

            public int l() {
               return IllllIlI.Illll >= 0 && IllllIlI.Illll < ll(2051093048, -579120194) ? IllllIlI.Illll : this.I();
            }

            public void II(Object var1, int var2) {
               switch (var1) {
                  case II:
                     IllllIlI.IIlIlI(this.I, var2, true);
                     break;
                  case lI:
                     IllllIlI.IlIllll(this.I, var2);
                     IllllIlI.IIlIlI(this.I, var2, false);
                     break;
                  case I:
                     int var3 = IIllIlll.lII();
                     if (var3 != var2 && (var3 >= 0 || this.l() != var2)) {
                        IIllIlll.Ill(var2);
                        ++IllllIlI.IlII;

                        try {
                           this.I.method_1562().method_52787(new class_2868(var2));
                        } finally {
                           IllllIlI.IlII = Math.max(0, IllllIlI.IlII - 1);
                        }
                     } else {
                        IIllIlll.Ill(var2);
                     }

                     lIllIIl var4 = lIllIIl.Il();
                     if (var4 != null && var4.IIl() != null && var4.IIl().IllllI() != null && var4.IIl().IllllI().IIIIIlI()) {
                        var4.IIl().IllllI().llI(var2);
                     }
               }

            }

            public int Il() {
               return this.I != null && this.I.field_1724 != null ? this.I.field_1724.field_6012 : 0;
            }

            private {
               this.I = var1;
            }

            public boolean lI(Object var1, int var2) {
               if (var1 == null.I) {
                  if (this.l() != var2 && IIllIlll.lII() != var2) {
                     if (IIllIlll.lII() != var2) {
                        this.II(var1, var2);
                     }

                     return false;
                  } else {
                     return true;
                  }
               } else {
                  return this.I() == var2;
               }
            }

            private static int ll(int var0, int var1) {
               return l[var0 ^ 2051093048] ^ var1 ^ var0;
            }

            static {
               int var2 = -658501509;
               byte[] var0 = "\u007fúqô".getBytes("ISO-8859-1");
               int var1 = var0.length / 4;
               l = new int[var1];
               int var3 = 0;
               int var4 = 0;

               do {
                  int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
                  var5 ^= var2;
                  l[var4] = var5;
                  var3 += 4;
                  ++var4;
               } while(var4 < var1);

            }
         }, var1, var2, var3, -1, true, (Runnable)null);
         if (var9.II() == 0L) {
            return null.l(var2);
         } else {
            if (var5 && var4 <= 0) {
               IlllI(var0);
            }

            int var10 = var8 ? var6 + Math.max(0, var4) : var6;
            return new Record(var7, var2, var6, var10, var8, true, var9) {
               private final int I;
               private final <undefinedtype> l;
               private final boolean II;
               private final int Il;
               private final int lI;
               private final int ll;
               private final boolean III;
               private static final int[] IIl;

               public int I() {
                  return this.Il;
               }

               static <undefinedtype> l(int var0) {
                  return new <anonymous constructor>(-1, var0, IlI(-547170428, -701882891), IlI(-547170427, -1807212102), false, false, null);
               }

               public int II() {
                  return this.ll;
               }

               public int Il() {
                  return this.I;
               }

               public boolean lI() {
                  return this.III;
               }

               public int ll() {
                  return this.lI;
               }

               public {
                  this.Il = var1;
                  this.lI = var2;
                  this.I = var3;
                  this.ll = var4;
                  this.III = var5;
                  this.II = var6;
                  this.l = var7;
               }

               public boolean III() {
                  return this.II;
               }

               public <undefinedtype> IIl() {
                  return this.l;
               }

               private static int IlI(int var0, int var1) {
                  return IIl[var0 ^ -547170428] ^ var1 ^ var0;
               }

               static {
                  int var2 = 1840724202;
                  byte[] var0 = "äÿò\u009bYb1*".getBytes("ISO-8859-1");
                  int var1 = var0.length / 4;
                  IIl = new int[var1];
                  int var3 = 0;
                  int var4 = 0;

                  do {
                     int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
                     var5 ^= var2;
                     IIl[var4] = var5;
                     var3 += 4;
                     ++var4;
                  } while(var4 < var1);

               }
            };
         }
      } else {
         return null.l(var2);
      }
   }

   public static void IllIIlI(class_310 var0) {
      ++lIIII;
      llIl = IllIIll(var0);
      if (llIl) {
         IIIl();
      }

      IIllII(var0, null.Il);
      lIIl = true;
      IlllI(var0);
   }

   private static boolean IllIIll(class_310 var0) {
      if (var0 != null && var0.field_1690 != null && var0.field_1690.field_1852 != null) {
         class_304[] var1 = var0.field_1690.field_1852;
         int var2 = var1.length;
         int var3 = 0;

         while(true) {
            if (var3 >= var2) {
               return false;
            }

            class_304 var4 = var1[var3];
            if (var4 != null) {
               if (var4.method_1434()) {
                  break;
               }

               if (var4 instanceof lllIllIl) {
                  lllIllIl var5 = (lllIllIl)var4;
                  if (var5.virel$getTimesPressed() > 0) {
                     break;
                  }
               }
            }

            ++var3;
         }

         return true;
      } else {
         return false;
      }
   }

   public static void IllIlII(class_310 var0, float var1, float var2) {
      if (var0 != null && var0.field_1724 != null) {
         float[] var3 = IlIlIl.lIlII(var0, var1, var2);
         if (var3 != null) {
            var1 = var3[0];
            var0.field_1724.method_36456(var1);
            var0.field_1724.method_36457(var3[1]);
            var0.field_1724.method_5847(var1);

            try {
               var0.field_1724.getClass().getMethod(lIlIII.Il(IllIlll(-338508995, 1056337217)), Float.TYPE).invoke(var0.field_1724, var1);
            } catch (ReflectiveOperationException var5) {
               IllIIII(lIIlI, var0.field_1724, var1);
            }

         }
      }
   }

   public static boolean IllIlIl(class_310 var0) {
      if (var0 != null && var0.field_1724 != null) {
         IIIIIIl(var0);
         class_239 var1 = var0.field_1765;
         class_243 var2 = var0.field_1724.method_33571();
         class_243 var3 = var0.field_1724.method_5828(1.0F);
         class_243 var4 = var2.method_1019(var3.method_1021((double)3.0F));
         var0.field_1765 = class_3965.method_17778(var4, class_2350.field_11036, class_2338.field_10980);

         boolean var5;
         try {
            var5 = I(var0);
         } finally {
            var0.field_1765 = var1;
         }

         return var5;
      } else {
         return false;
      }
   }

   private static int IllIllI(int var0, int var1) {
      return lI[var0 ^ 516732909] ^ var1 ^ var0;
   }

   private static String IllIlll(int var0, int var1) {
      int var3 = var0 ^ -338508948;
      char[] var4 = lIlII[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])lIlIl[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         lIlIl[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -16128897;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 187;
               break;
            case 1:
               var9 = 151;
               break;
            case 2:
               var9 = 149;
               break;
            case 3:
               var9 = 107;
               break;
            case 4:
               var9 = 215;
               break;
            case 5:
               var9 = 198;
               break;
            case 6:
               var9 = 163;
               break;
            case 7:
               var9 = 229;
               break;
            case 8:
               var9 = 170;
               break;
            case 9:
               var9 = 145;
               break;
            case 10:
               var9 = 48;
               break;
            case 11:
               var9 = 62;
               break;
            case 12:
               var9 = 43;
               break;
            case 13:
               var9 = 241;
               break;
            case 14:
               var9 = 162;
               break;
            case 15:
               var9 = 112;
               break;
            case 16:
               var9 = 215;
               break;
            case 17:
               var9 = 238;
               break;
            case 18:
               var9 = 183;
               break;
            case 19:
               var9 = 209;
               break;
            case 20:
               var9 = 6;
               break;
            case 21:
               var9 = 209;
               break;
            case 22:
               var9 = 177;
               break;
            case 23:
               var9 = 145;
               break;
            case 24:
               var9 = 64;
               break;
            case 25:
               var9 = 191;
               break;
            case 26:
               var9 = 69;
               break;
            case 27:
               var9 = 44;
               break;
            case 28:
               var9 = 48;
               break;
            case 29:
               var9 = 78;
               break;
            case 30:
               var9 = 84;
               break;
            case 31:
               var9 = 80;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
