package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class lllIIIIl extends lIIlIIII {
   private static String[] I;
   private static final int[] lIIl;
   private static final String[] lIll;
   private static final Object[] llII;

   public lllIIIIl() {
      super(lIlIII.l(I[0]), lIlIII.l(I[1]), null.II, true);
   }

   static {
      short var6 = 24402;
      String var7 = "㹮⻎ꍟߞ\ud999\ue2f6䠴Ⴄ鍢㌮䔐煺䘅\u192e鷓㘊\udde8䞑醯瞚㗈῍⮢뚯뾥\uf1b4⯼ǻ᠖쀙຺뫟ᩞ쎆챎뭾壨늕ᅩ⤺윴쟾ᢍ搿鴸⾑❑\udfad\ueb66垄顡䷫Ჵ핂\udec1几⻠쵛卙\udafa䕙杓먻⦶渢贁뙈\udfba\ud9b6\ue791Ⲿ뽘";
      char[] var8 = "彂彪".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            lIll = var9;
            llII = new Object[var9.length];
            int var2 = -1256429260;
            byte[] var0 = "Á\u001bQ¿\u0005Â\u009a6\u0092$Ý%\u0019ÏÞh".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lIIl = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lIIl[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            I = new String[2];
            II();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static String l(char[] var0, long var1, int var3) {
      int var4 = lIlIl(1283120224, -621173758) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & lIlIl(1283120225, -56348772);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private static void II() {
      I[0] = l(lIllI(1785208896, (short)13642, 'ꡱ').toCharArray(), 96988L, lIlIl(1283120226, 940422013));
      I[1] = l(lIllI(-626713821, (short)2598, 'ꡰ').toCharArray(), 57249L, lIlIl(1283120227, 216296524));
   }

   private static int lIlIl(int var0, int var1) {
      return lIIl[var0 ^ 1283120224] ^ var1 ^ var0;
   }

   private static String lIllI(int var0, short var1, char var2) {
      int var3 = var2 ^ 'ꡱ';
      char[] var4 = lIll[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])llII[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         llII[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 20892;
      int var9 = 0;

      do {
         int var10 = var4[var9] ^ '耰';
         var10 ^= 3309;
         var10 -= 46215;
         var10 ^= 2999;
         var10 += 7079;
         var10 -= 42962;
         var4[var9] = (char)(var10 ^ var8 ^ var1 ^ var0 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
