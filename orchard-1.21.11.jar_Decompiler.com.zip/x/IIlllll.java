package x;

import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_746;
import net.minecraft.class_2350.class_2351;

@Environment(EnvType.CLIENT)
public final class IIlllll extends IIIIIIIlI {
   private int I;
   private static final double l = 2.9;
   private <undefinedtype> II;
   private class_2338 Il;
   private boolean lI;
   private int ll;
   private long III;
   private static final int IIl = 2;
   private boolean IlI;
   private static final int Ill = 1;
   private static final int lII = 80;
   private static final int lIl = 1;
   private static final int llI = 2;
   private long lll;
   private <undefinedtype> IIII;
   private int IIIl;
   private <undefinedtype> IIlI;
   private static final float IIll = 0.5F;
   private static final int IlII = 40;
   private int IlIl;
   private <undefinedtype> IllI;
   private final IlIlIll Illl;
   private static final double lIII = 2.9;
   private class_243 lIIl;
   private static final double lIlI = (double)3.0F;
   private static final double lIll = (double)20.25F;
   private static final int llII = 1;
   private final IlIIIlIlI<<undefinedtype>> llIl;
   private final IIIllIIII lllI;
   private float llll;
   private int IIIII;
   private float IIIIl;
   private final IIIllIIII IIIlI;
   private static final double IIIll = (double)1.5F;
   private static final int IIlII = 8;
   private static final int IIlIl = 9;
   private <undefinedtype> IIllI;
   private static final double IIlll = (double)4.5F;
   private final IlIIIlIlI<<undefinedtype>> IlIII;
   private final llllIlIl IlIIl;
   private static final int[] IlIlI;
   private static final String[] IlIll;
   private static final Object[] IllII;

   private void ll() {
      ++this.lll;
      this.IIlI = null;
      this.II = null;
      this.IIllI = null.lI;
      this.IIIII = 0;
      this.I = -1;
      this.IlIl = -1;
      this.IllI = null.I;
      this.Il = null;
      this.lI = false;
      this.IlI = false;
      this.IIII = null;
      this.III = 0L;
      this.ll = 0;
      this.IIIl = 0;
   }

   private void IlI(class_310 var1) {
      if (this.IlI) {
         lllI var2 = this.lIIlI();
         if (var2 != null) {
            var2.IIl(this, var1);
         } else if (var1 != null && var1.field_1690 != null && var1.field_1690.field_1832 != null) {
            var1.field_1690.field_1832.method_23481(IllllIlI.IIIll(var1, var1.field_1690.field_1832));
         }

         this.IlI = false;
         this.IIII = null;
      }
   }

   private boolean lII(class_310 var1) {
      if (this.lllI(var1) && IllllIlI.lIllI(var1) <= 0) {
         class_1269 var2 = IllllIlI.lllIlI(var1, class_1268.field_5808);
         return var2 != null && var2.method_23665();
      } else {
         return false;
      }
   }

   private boolean llI(class_310 var1, long var2, Object var4) {
      <undefinedtype> var5 = this.IIlI;
      if (var5 != null && var5.I() == var2) {
         this.IIlI = null;
         this.II = null;
         boolean var6 = var4.l() == null.I ? this.lIlII(var1) : this.lII(var1);
         int var7 = var1.field_1724.field_6012;
         if (!var6) {
            if (var4.l() == null.I) {
               this.Illll(var1);
            } else {
               this.IIllI = null.Il;
               this.IIIII = var7;
            }

            return false;
         } else {
            this.IIllI = var4.l() == null.I ? null.III : null.IlI;
            this.IIIII = var7;
            return true;
         }
      } else {
         return false;
      }
   }

   private void lll(class_310 var1, int var2) {
      Record var3 = new Record(null.I, true, 0) {
         private final boolean I;
         private final <undefinedtype> l;
         private final int II;

         private {
            this.l = var1;
            this.I = var2;
            this.II = var3;
         }

         private <undefinedtype> I(int var1) {
            return new <anonymous constructor>(this.l, this.I, var1);
         }

         public <undefinedtype> l() {
            return this.l;
         }

         public boolean II() {
            return this.I;
         }

         public int Il() {
            return this.II;
         }
      };
      if (!this.IllIl(var1, var3)) {
         this.II = var3;
      }

   }

   private void IIII(class_310 var1) {
      if (this.lI) {
         if (var1 != null && var1.field_1724 != null) {
            IlIlIl.IllI(var1, this.llll, this.IIIIl);
            this.lI = false;
         }
      }
   }

   public void lI() {
      class_310 var1 = class_310.method_1551();
      this.IIII(var1);
      this.IlI(var1);
      IllllIlI.IlII(var1, this, null.II);
      this.Illl.IIIlIll();
      this.ll();
   }

   private long IlII(llllIlIl var1) {
      double var2 = var1.IlII();
      double var4 = var1.IlI();
      return var2 == var4 ? Math.max(0L, Math.round(var2)) : Math.max(0L, Math.round(ThreadLocalRandom.current().nextDouble(var2, var4)));
   }

   public void lIl() {
      this.ll();
      this.Illl.IIlIIII();
   }

   private void IlIl(class_310 var1) {
      <undefinedtype> var2 = this.II;
      if (var2 != null) {
         if (var2.l() == null.I && !this.IlIIl(var1)) {
            this.Illll(var1);
         } else if (var2.l() == null.II && !this.lllI(var1)) {
            this.II = null;
            this.IIllI = null.Il;
            this.IIIII = var1.field_1724.field_6012;
         } else {
            boolean var3 = var2.l() == null.I ? (var2.II() ? this.IllIl(var1, var2) : this.IIIIl(var1, var2)) : this.llIlI(var1, var2);
            if (var3) {
               this.II = null;
            }

         }
      }
   }

   private boolean Illl(class_310 var1, int var2) {
      <undefinedtype> var3 = this.IIlI;
      if (var3 == null) {
         return false;
      } else if (var2 < var3.II()) {
         return true;
      } else {
         this.IIlI = null;
         ++this.lll;
         <undefinedtype> var4 = var3.l();
         if (var4.Il() >= 2) {
            if (var4.l() == null.I) {
               this.Illll(var1);
            } else {
               this.IIllI = null.Il;
               this.IIIII = var2;
            }

            return true;
         } else {
            this.II = var4.I(var4.Il() + 1);
            return false;
         }
      }
   }

   private boolean lIIl(class_310 var1) {
      return var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var1.field_1690 != null && var1.field_1755 == null && var1.field_1724.method_5805();
   }

   private boolean lllI(class_310 var1) {
      return var1 != null && var1.field_1724 != null && this.IllI == null.I && this.I >= 0 && this.I < llIll(836911899, -1901719278) && IllllIlI.lIIlI(var1.field_1724.method_31548()) == this.I && var1.field_1724.method_31548().method_5438(this.I).method_31574(class_1802.field_8550);
   }

   private boolean IIIII(Object var1, Object var2) {
      return var1 == null.lI || var1 == var2;
   }

   public IIlllll() {
      super(lIlIII.Il(lllII(23121, 5613, -1135118598)), lIllII.III, lIlIII.Il(lllII(45302, 5612, -1146591060)));
      this.IlIII = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.Il(lllII(64895, 5615, -839755465)), <undefinedtype>.class, null.lI));
      this.llIl = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.Il(lllII(56845, 5614, -1992140208)), <undefinedtype>.class, null.I));
      this.lllI = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.Il(lllII(47758, 5609, 640057227)), (double)8.0F, (double)4.0F, (double)64.0F, (double)1.0F)).IIl(lIlIII.Il(lllII(16523, 5608, 1219052289))));
      this.IIIlI = (IIIllIIII)this.IIIlIll((IIIllIIII)(new IIIllIIII(lIlIII.Il(lllII(30646, 5611, -1276896110)), (double)50.0F, (double)1.0F, (double)100.0F, (double)1.0F)).lIII(() -> this.llIl.III() == null.Il));
      this.IlIIl = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(lllII(16361, 5610, -445047946)), (double)0.0F, (double)0.0F, (double)0.0F, (double)300.0F, (double)5.0F)).IIII(lIlIII.Il(lllII(57157, 5605, 172890876))));
      this.Illl = new IlIlIll();
      this.IIllI = null.lI;
      this.I = -1;
      this.IlIl = -1;
      this.IllI = null.I;
      this.IIII = null;
   }

   private boolean IIIIl(class_310 var1, Object var2) {
      if (var2 != null && this.IlIIl(var1)) {
         class_746 var3 = var1.field_1724;
         class_1799 var4 = var3.method_31548().method_5438(this.I);
         if (this.IllI != null.I || var4 != null && var4.method_31574(class_1802.field_8705)) {
            if (this.IllI != null.II || var4 != null && var4.method_31574(class_1802.field_8786) && this.Il != null) {
               if (this.IllI != null.Il || var4 != null && var4.method_31574(class_1802.field_16482) && this.Il != null) {
                  if ((this.IllI == null.II || this.IllI == null.Il) && !this.IIllI(var1, this.Il)) {
                     return false;
                  } else if (IllllIlI.lIllI(var1) > 0) {
                     return false;
                  } else if (this.llIl.III() == null.I) {
                     if (this.IllI == null.Il) {
                        this.lIllI(var1);
                     }

                     float var5 = var3.method_36454();
                     float var6 = 90.0F;
                     if (this.IllI == null.II || this.IllI == null.Il) {
                        class_243 var7 = class_243.method_24953(this.Il).method_1031((double)0.0F, (double)0.5F, (double)0.0F);
                        float[] var8 = IlIlIl.llIlI(var1, var7);
                        if (var8 == null) {
                           return false;
                        }

                        var5 = var8[0];
                        var6 = var8[1];
                     }

                     return this.lIIll(var1, var2, var5, var6);
                  } else {
                     return this.IllI != null.II && this.IllI != null.Il ? false : false;
                  }
               } else {
                  return false;
               }
            } else {
               return false;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private int IIIll(class_746 var1, class_1792 var2) {
      for(int var3 = 0; var3 < llIll(836911898, -1103299806); ++var3) {
         class_1799 var4 = var1.method_31548().method_5438(var3);
         if (var4 != null && var4.method_31574(var2)) {
            return var3;
         }
      }

      return -1;
   }

   private void IIlII(class_310 var1, int var2) {
      if (this.llIl.III() == null.Il) {
         this.lI = true;
         this.lIIl = this.IlllI(var1);
         this.IIIl = 0;
         this.IIllI = null.l;
         this.IIIII = var2;
      } else {
         Record var3 = new Record(null.I, false, 0) {
            private final boolean I;
            private final <undefinedtype> l;
            private final int II;

            private {
               this.l = var1;
               this.I = var2;
               this.II = var3;
            }

            private <undefinedtype> I(int var1) {
               return new <anonymous constructor>(this.l, this.I, var1);
            }

            public <undefinedtype> l() {
               return this.l;
            }

            public boolean II() {
               return this.I;
            }

            public int Il() {
               return this.II;
            }
         };
         if (!this.IIIIl(var1, var3)) {
            this.II = var3;
         }

      }
   }

   private void IIlIl(class_310 var1, Object var2, int var3) {
      class_746 var4 = var1.field_1724;
      this.IlIl = IllllIlI.lIIlI(var4.method_31548());
      this.I = var2.l();
      this.IllI = var2.I();
      this.Il = var2.II();
      this.IIIIl = var4.method_36455();
      this.llll = var4.method_36454();
      boolean var5 = IllllIlI.IIlIl(var1) != this.I;
      int var6 = var5 ? this.IIlll(this.IlIIl) : 0;
      this.IIII = IllllIlI.lIll(var1, this, this.I, var6, true);
      if (this.IIII != null && this.IIII.III()) {
         this.III = Long.MAX_VALUE;
         this.ll = var3 + var6 + this.IlIII(this.IlIIl) + llIll(836911897, 251570031);
         this.IIllI = null.II;
         this.IIIII = var3;
      } else {
         this.Illll(var1);
      }
   }

   private boolean IIllI(class_310 var1, class_2338 var2) {
      if (var1 != null && var1.field_1724 != null && var2 != null) {
         class_243 var3 = class_243.method_24953(var2).method_1031((double)0.0F, (double)0.5F, (double)0.0F);
         return var1.field_1724.method_33571().method_1025(var3) <= 20.2501;
      } else {
         return false;
      }
   }

   private int IIlll(llllIlIl var1) {
      return Math.max(0, (int)Math.ceil((double)this.IlII(var1) / (double)50.0F));
   }

   private int IlIII(llllIlIl var1) {
      double var2 = Math.max((double)0.0F, Math.max(var1.IlII(), var1.IlI()));
      return Math.max(0, (int)Math.ceil(var2 / (double)50.0F));
   }

   public void IllI(class_310 var1) {
      this.llIIl(var1);
   }

   private boolean IlIIl(class_310 var1) {
      if (var1 != null && var1.field_1724 != null && this.I >= 0 && this.I < llIll(836911896, 1996982248) && IllllIlI.lIIlI(var1.field_1724.method_31548()) == this.I && IllllIlI.lIllI(var1) <= 0) {
         class_1799 var2 = var1.field_1724.method_31548().method_5438(this.I);
         if (var2 == null) {
            return false;
         } else {
            boolean var10000;
            switch (this.IllI.ordinal()) {
               case 0 -> var10000 = var2.method_31574(class_1802.field_8705);
               case 1 -> var10000 = var2.method_31574(class_1802.field_8786) && this.Il != null && this.IIllI(var1, this.Il);
               case 2 -> var10000 = var2.method_31574(class_1802.field_16482) && this.Il != null && this.IIllI(var1, this.Il);
               default -> throw new MatchException((String)null, (Throwable)null);
            }

            return var10000;
         }
      } else {
         return false;
      }
   }

   private boolean IlIll(class_310 var1, class_2338 var2) {
      return var2 != null && IllllIlI.lIII(var1.field_1687.method_8320(var2)) && !var1.field_1687.method_8320(var2.method_10074()).method_26220(var1.field_1687, var2.method_10074()).method_1110();
   }

   private <undefinedtype> IllII(class_310 var1) {
      class_746 var2 = var1.field_1724;
      double var3 = var2.method_5829().field_1322;
      int var5 = (int)Math.floor(var3 - 1.0E-4);
      int var6 = Math.max(var1.field_1687.method_31607(), var5 - llIll(836911903, -1425415039));
      double var7 = var2.method_23317();
      double var9 = var2.method_23321();

      for(int var11 = var5; var11 >= var6; --var11) {
         class_2338 var12 = class_2338.method_49637(var7, (double)var11, var9);
         class_2680 var13 = var1.field_1687.method_8320(var12);
         if (!IllllIlI.lIII(var13)) {
            class_265 var14 = var13.method_26220(var1.field_1687, var12);
            if (!var14.method_1110()) {
               double var15 = (double)var12.method_10264() + var14.method_1105(class_2351.field_11052);
               return new Record(var12.method_10062(), Math.max((double)0.0F, var3 - var15)) {
                  private final class_2338 I;
                  private final double l;

                  private {
                     this.I = var1;
                     this.l = var2;
                  }

                  public double I() {
                     return this.l;
                  }

                  public class_2338 l() {
                     return this.I;
                  }
               };
            }
         }
      }

      return new Record((class_2338)null, Double.POSITIVE_INFINITY) {
         private final class_2338 I;
         private final double l;

         private {
            this.I = var1;
            this.l = var2;
         }

         public double I() {
            return this.l;
         }

         public class_2338 l() {
            return this.I;
         }
      };
   }

   private boolean IllIl(class_310 var1, Object var2) {
      if (var2 != null && this.IlIIl(var1)) {
         class_746 var3 = var1.field_1724;
         class_1799 var4 = var3.method_31548().method_5438(this.I);
         if (this.IllI != null.I || var4 != null && var4.method_31574(class_1802.field_8705)) {
            if (this.IllI != null.II || var4 != null && var4.method_31574(class_1802.field_8786) && this.Il != null) {
               if (this.IllI != null.Il || var4 != null && var4.method_31574(class_1802.field_16482) && this.Il != null) {
                  if ((this.IllI == null.II || this.IllI == null.Il) && !this.IIllI(var1, this.Il)) {
                     return false;
                  } else if (IllllIlI.lIllI(var1) > 0) {
                     return false;
                  } else {
                     float var5 = var3.method_36454();
                     float var6 = class_3532.method_15363(var3.method_36455(), -90.0F, 90.0F);
                     if (this.IllI != null.II && this.IllI != null.Il) {
                        var6 = 90.0F;
                     } else {
                        class_243 var7 = class_243.method_24953(this.Il).method_1031((double)0.0F, (double)0.5F, (double)0.0F);
                        float[] var8 = IlIlIl.llIlI(var1, var7);
                        if (var8 == null) {
                           return false;
                        }

                        var5 = var8[0];
                        var6 = var8[1];
                     }

                     return this.lIIll(var1, var2, var5, var6);
                  }
               } else {
                  return false;
               }
            } else {
               return false;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private class_243 IlllI(class_310 var1) {
      if (this.IllI != null.II && this.IllI != null.Il) {
         return var1.field_1724.method_33571().method_1031((double)0.0F, (double)-1.0F, (double)0.0F);
      } else {
         return this.Il == null ? var1.field_1724.method_33571().method_1031((double)0.0F, (double)-1.0F, (double)0.0F) : class_243.method_24953(this.Il).method_1031((double)0.0F, (double)0.5F, (double)0.0F);
      }
   }

   private void Illll(class_310 var1) {
      this.IIII(var1);
      this.IlI(var1);
      IllllIlI.IlII(var1, this, null.II);
      this.ll();
   }

   private void lIIII(class_310 var1, boolean var2) {
      lllI var3 = this.lIIlI();
      if (var3 != null) {
         var3.IlI(this, var1, var1.field_1690.field_1832, var2);
      } else if (var1 != null && var1.field_1690 != null && var1.field_1690.field_1832 != null) {
         var1.field_1690.field_1832.method_23481(var2);
      }

   }

   private class_1269 lIIIl(class_310 var1) {
      if (var1 != null && var1.field_1724 != null && var1.field_1761 != null && this.Il != null) {
         class_243 var2 = class_243.method_24953(this.Il).method_1031((double)0.0F, (double)0.5F, (double)0.0F);
         class_3965 var3 = new class_3965(var2, class_2350.field_11036, this.Il, false);
         return IllllIlI.lIlII(var1, class_1268.field_5808, var3);
      } else {
         return class_1269.field_5814;
      }
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      this.llIIl(var1);
   }

   private lllI lIIlI() {
      return x.lllI.lll();
   }

   private boolean lIIll(class_310 var1, Object var2, float var3, float var4) {
      long var5 = ++this.lll;
      boolean var7 = IlIlIl.IIIIlI(var1, llIll(836911902, -300223472), var3, var4, () -> this.llI(var1, var5, var2));
      if (!var7) {
         ++this.lll;
         return false;
      } else {
         this.IIlI = new Record(var5, var2, var1.field_1724.field_6012 + 2) {
            private final int I;
            private final long l;
            private final <undefinedtype> II;

            public long I() {
               return this.l;
            }

            private {
               this.l = var1;
               this.II = var3;
               this.I = var4;
            }

            public <undefinedtype> l() {
               return this.II;
            }

            public int II() {
               return this.I;
            }
         };
         return true;
      }
   }

   private boolean lIlII(class_310 var1) {
      if (!this.IlIIl(var1)) {
         return false;
      } else {
         if (this.IllI == null.Il) {
            this.lIllI(var1);
         }

         class_1269 var2 = this.IllI == null.I ? IllllIlI.lllIlI(var1, class_1268.field_5808) : this.lIIIl(var1);
         return var2 != null && var2.method_23665();
      }
   }

   private void lIlIl(class_310 var1, int var2) {
      class_746 var3 = var1.field_1724;
      if (!this.Illl(var1, var2)) {
         if (this.II != null) {
            this.IlIl(var1);
         } else {
            if (this.lI && this.IIllI != null.Il && this.IIllI != null.l) {
               var3.method_36457(90.0F);
            }

            if (this.IllI == null.Il && this.IIllI != null.Il) {
               this.lIllI(var1);
            }

            switch (this.IIllI.ordinal()) {
               case 1:
                  if (var2 >= this.ll) {
                     this.Illll(var1);
                     return;
                  }

                  if (!IllllIlI.IlIllII(var1, this.IIII)) {
                     return;
                  }

                  this.IIlII(var1, var2);
                  break;
               case 2:
                  if (var2 - this.IIIII >= llIll(836911901, -311437877)) {
                     this.lll(var1, var2);
                     return;
                  }

                  if (this.lIIl == null) {
                     this.lll(var1, var2);
                     return;
                  }

                  float var6 = this.Illl.IlIl(var1, this.lIIl, ((Double)this.IIIlI.III()).floatValue());
                  ++this.IIIl;
                  if (var6 <= 0.5F || this.IIIl >= llIll(836911900, 1555525026)) {
                     this.lll(var1, var2);
                  }
                  break;
               case 3:
                  if (var2 - this.IIIII >= 1) {
                     if (this.IllI == null.I) {
                        this.IIllI = null.ll;
                     } else if (this.IllI == null.Il) {
                        this.llIII(var1);
                        this.IIllI = null.ll;
                     } else {
                        this.IIllI = null.Il;
                     }

                     this.IIIII = var2;
                  }
                  break;
               case 4:
                  if (this.IllI == null.Il) {
                     this.llIII(var1);
                  }

                  if (var3.method_24828()) {
                     if (this.IllI == null.Il) {
                        this.IlI(var1);
                        this.IIllI = null.Il;
                        this.IIIII = var2;
                        return;
                     }

                     this.IIllI = null.IIl;
                     this.IIIII = var2;
                     return;
                  }

                  if (var2 - this.IIIII >= llIll(836911891, 2019259454)) {
                     this.IlI(var1);
                     this.IIllI = null.Il;
                     this.IIIII = var2;
                  }
                  break;
               case 5:
                  if (var2 - this.IIIII < 1) {
                     break;
                  }

                  class_1799 var4 = var3.method_6047();
                  if (this.IllI == null.I && var4 != null && var4.method_31574(class_1802.field_8550)) {
                     Record var5 = new Record(null.II, this.llIl.III() == null.Il, 0) {
                        private final boolean I;
                        private final <undefinedtype> l;
                        private final int II;

                        private {
                           this.l = var1;
                           this.I = var2;
                           this.II = var3;
                        }

                        private <undefinedtype> I(int var1) {
                           return new <anonymous constructor>(this.l, this.I, var1);
                        }

                        public <undefinedtype> l() {
                           return this.l;
                        }

                        public boolean II() {
                           return this.I;
                        }

                        public int Il() {
                           return this.II;
                        }
                     };
                     if (!this.llIlI(var1, var5)) {
                        this.II = var5;
                     }
                     break;
                  }

                  this.IIllI = null.Il;
                  this.IIIII = var2;
                  return;
               case 6:
                  if (var2 - this.IIIII >= 1) {
                     this.IIllI = null.Il;
                     this.IIIII = var2;
                  }
                  break;
               case 7:
                  this.IIII(var1);
                  if (this.IlIl >= 0 && this.IlIl < llIll(836911890, -2124202366)) {
                     IllllIlI.llIIlI(var1, this, this.IlIl);
                  } else {
                     IllllIlI.IlII(var1, this, null.II);
                  }

                  if (var2 - this.IIIII >= 1) {
                     this.ll();
                  }
            }

         }
      }
   }

   private void lIllI(class_310 var1) {
      if (var1 != null && var1.field_1690 != null) {
         lllI var2 = this.lIIlI();
         if (var2 != null) {
            var2.IlI(this, var1, var1.field_1690.field_1894, false);
            var2.IlI(this, var1, var1.field_1690.field_1881, false);
            var2.IlI(this, var1, var1.field_1690.field_1913, false);
            var2.IlI(this, var1, var1.field_1690.field_1849, false);
            var2.IlI(this, var1, var1.field_1690.field_1867, false);
            var2.IlI(this, var1, var1.field_1690.field_1903, false);
            var2.IlI(this, var1, var1.field_1690.field_1832, true);
         } else {
            if (var1.field_1690.field_1894 != null) {
               var1.field_1690.field_1894.method_23481(false);
            }

            if (var1.field_1690.field_1881 != null) {
               var1.field_1690.field_1881.method_23481(false);
            }

            if (var1.field_1690.field_1913 != null) {
               var1.field_1690.field_1913.method_23481(false);
            }

            if (var1.field_1690.field_1849 != null) {
               var1.field_1690.field_1849.method_23481(false);
            }

            if (var1.field_1690.field_1867 != null) {
               var1.field_1690.field_1867.method_23481(false);
            }

            if (var1.field_1690.field_1903 != null) {
               var1.field_1690.field_1903.method_23481(false);
            }

            if (var1.field_1690.field_1832 != null) {
               var1.field_1690.field_1832.method_23481(true);
            }
         }

      }
   }

   private <undefinedtype> lIlll(class_310 var1) {
      class_746 var2 = var1.field_1724;
      if (!var2.method_24828() && !var2.method_6101() && !var2.method_5799() && !var2.method_5771()) {
         if (var2.method_18798().field_1351 >= -0.08) {
            return null;
         } else if (var2.field_6017 < (double)((Double)this.lllI.III()).floatValue()) {
            return null;
         } else {
            <undefinedtype> var3 = this.IllII(var1);
            if (var3 != null && Double.isFinite(var3.I())) {
               <undefinedtype> var4 = (<undefinedtype>)this.IlIII.III();
               int var5 = this.IIIII(var4, null.Il) ? this.IIIll(var2, class_1802.field_8705) : -1;
               if (var5 >= 0 && var3.I() <= (double)1.5F) {
                  return new Record(null.I, var5, (class_2338)null) {
                     private final int I;
                     private final <undefinedtype> l;
                     private final class_2338 II;

                     public <undefinedtype> I() {
                        return this.l;
                     }

                     public int l() {
                        return this.I;
                     }

                     private {
                        this.l = var1;
                        this.I = var2;
                        this.II = var3;
                     }

                     public class_2338 II() {
                        return this.II;
                     }
                  };
               } else {
                  int var6 = this.IIIII(var4, null.l) ? this.IIIll(var2, class_1802.field_8786) : -1;
                  if (var6 >= 0 && var3.I() <= 2.9 && this.IlIll(var1, var3.l().method_10084()) && this.IIllI(var1, var3.l())) {
                     return new Record(null.II, var6, var3.l()) {
                        private final int I;
                        private final <undefinedtype> l;
                        private final class_2338 II;

                        public <undefinedtype> I() {
                           return this.l;
                        }

                        public int l() {
                           return this.I;
                        }

                        private {
                           this.l = var1;
                           this.I = var2;
                           this.II = var3;
                        }

                        public class_2338 II() {
                           return this.II;
                        }
                     };
                  } else {
                     int var7 = this.IIIII(var4, null.ll) ? this.IIIll(var2, class_1802.field_16482) : -1;
                     return var7 >= 0 && var3.I() <= 2.9 && this.IlIll(var1, var3.l().method_10084()) && this.IIllI(var1, var3.l()) ? new Record(null.Il, var7, var3.l()) {
                        private final int I;
                        private final <undefinedtype> l;
                        private final class_2338 II;

                        public <undefinedtype> I() {
                           return this.l;
                        }

                        public int l() {
                           return this.I;
                        }

                        private {
                           this.l = var1;
                           this.I = var2;
                           this.II = var3;
                        }

                        public class_2338 II() {
                           return this.II;
                        }
                     } : null;
                  }
               }
            } else {
               return null;
            }
         }
      } else {
         return null;
      }
   }

   private void llIII(class_310 var1) {
      if (var1 != null && var1.field_1690 != null && var1.field_1690.field_1832 != null) {
         this.lIllI(var1);
         this.IlI = true;
      }
   }

   private void llIIl(class_310 var1) {
      if (!this.lIIl(var1)) {
         this.Illll(var1);
      } else if (lIlIllll.lIIl(var1)) {
         this.Illll(var1);
      } else {
         int var2 = var1.field_1724.field_6012;
         if (this.IIllI != null.lI) {
            this.lIlIl(var1, var2);
         } else {
            <undefinedtype> var3 = this.lIlll(var1);
            if (var3 != null) {
               this.IIlIl(var1, var3, var2);
            }
         }
      }
   }

   private boolean llIlI(class_310 var1, Object var2) {
      if (var2 != null && this.lllI(var1) && IllllIlI.lIllI(var1) <= 0) {
         long var3 = ++this.lll;
         boolean var5 = IlIlIl.IIIlIl(var1, llIll(836911889, 649156080), var1.field_1724.method_36454(), 90.0F, () -> this.llI(var1, var3, var2));
         if (!var5) {
            ++this.lll;
            return false;
         } else {
            this.IIlI = new Record(var3, var2, var1.field_1724.field_6012 + 1) {
               private final int I;
               private final long l;
               private final <undefinedtype> II;

               public long I() {
                  return this.l;
               }

               private {
                  this.l = var1;
                  this.II = var3;
                  this.I = var4;
               }

               public <undefinedtype> l() {
                  return this.II;
               }

               public int II() {
                  return this.I;
               }
            };
            return true;
         }
      } else {
         return false;
      }
   }

   private static int llIll(int var0, int var1) {
      return IlIlI[var0 ^ 836911899] ^ var1 ^ var0;
   }

   static {
      short var6 = 15823;
      String var7 = "▆╺╡╢█┕╭╔▃▔╎╎ꡊ\ua82dꡏ꠩ꡑ\ua83f\ua83f\ua82e\ua82e꠵ꢅꠝ\ua83b꠱ꢂ\ua82d꠵ꡋ\ua83b꠩ꡍ\ua7dbꡒ꠵ꠥ꠱ꡌꠢ꠹ꢇꟘ\ua7db\ua7dcꡌꢅ꠱\ua83c꠪ꢈ\ua83cꢈꠝ꠬\ua7db\ua7dc꠵꠨꠬\ua83b\ua82eꠥ\ua82eꠟ\ua82dꠞ꠱ꡆ꠩ꠢ\ua7dbꢊꡇꢉꠢꡆꠝꡏꠢꢈ꠵꠵\ua7da꠪꠵ꢅꠞ\ua82f꠱\ua82e꡶놜뇲놜뇵눁뇵뇑뇑受叚呎吧呄吷吗吵含吞吩启吞吠呁咓㷷㷹㶗㸔㷖㸇㷝㷳㶚㶜㶖㸅㷾㸓㸇㷬㷾㷪㶰㶰꭪ꭠꬺꬺܶݿܱܰۚܡݏܖܡܱܖފ\uf804\uf7bd\uf7f7\uf80d\uf79c\uf7f3\uf801\uf80f\uf7f0\uf7ed\uf79c\uf7d6\uf7f3\uf7fb\uf7c0\uf7f4횂홳횉홏";
      char[] var8 = "㷃㶟㷇㷟㷛㷋㷃㷟㷋".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IlIll = var9;
            IllII = new Object[var9.length];
            int var2 = 795587456;
            byte[] var0 = "\u0090/á\u0080 µ\u000b±\u0010wWâi\u008ewyµ\u0080\u0014\u0016ð\u0093\u0004tóæ%~B>\u009d\u0016fÒ\u0084ý\u009fêÎ\u001988¥\u009b".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IlIlI = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IlIlI[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static String lllII(int var0, int var1, int var2) {
      int var3 = var1 ^ 5613;
      char[] var4 = IlIll[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])IllII[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         IllII[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 16374;
      int var9 = 0;

      do {
         int var10 = var4[var9] + '롫';
         var10 ^= 31283;
         var10 ^= 28426;
         var10 -= 40193;
         var10 += 1160;
         var10 ^= 18291;
         var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var2 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
