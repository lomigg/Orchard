package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_746;

@Environment(EnvType.CLIENT)
public final class lIlIllll {
   private static int I;
   private static int l;
   private static int II;
   private static int Il;
   private static final double lI = 0.01;
   private static int ll;
   private static int III;
   private static int IIl;
   private static final int IlI = 4;
   private static int Ill;
   private static final int[] lII;

   public static boolean I(class_310 var0) {
      if (!lIll(var0)) {
         return false;
      } else {
         int var1 = var0.field_1724.field_6012;
         return IIl != var1;
      }
   }

   static {
      int var2 = -1509063631;
      byte[] var0 = "\u0007\u0002\u0091 olL[NK\u008b\u0080B\u001c[Ò¸\u008d\u0094Ä×EQ»òh\\CãåÎg«\f0\u000fQí\b\u0098Ë\u0095g;\n\u0000Ù\u000bÞ\"Ôb\u0016vÖ-uÒó\u001e=cÐ\u000e± 3Êl©\u0098Ó>CU½\u0006:\u0003õ9õè!\u008dçÏùèªK¼ú\u0001\u007f1®Æ\u0007Ç\"\u009be²".getBytes("ISO-8859-1");
      int var1 = var0.length / 4;
      lII = new int[var1];
      int var3 = 0;
      int var4 = 0;

      do {
         int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
         var5 ^= var2;
         lII[var4] = var5;
         var3 += 4;
         ++var4;
      } while(var4 < var1);

      IIl = IIIIl(-1425323587, -1979425748);
      l = IIIIl(-1425323588, -496336426);
      I = IIIIl(-1425323585, -1018345970);
      III = IIIIl(-1425323586, -820341155);
      II = IIIIl(-1425323591, 898324812);
      ll = IIIIl(-1425323592, 1514380338);
      Il = IIIIl(-1425323589, 2137952713);
      Ill = 0;
   }

   public static boolean l(class_310 var0, int var1) {
      if (!lIll(var0)) {
         return false;
      } else if (!IIlI(var0)) {
         return false;
      } else {
         int var2 = var0.field_1724.field_6012;
         if (IIl == var2) {
            return false;
         } else {
            IIl = var2;
            Il(var0, var1);
            return true;
         }
      }
   }

   public static void II(class_310 var0) {
   }

   public static void Il(class_310 var0, int var1) {
      if (lIll(var0)) {
         int var2 = Math.max(1, var1);
         ll = Math.max(ll, var0.field_1724.field_6012 + var2);
      }
   }

   public static boolean lI(class_310 var0) {
      lIllIIl var1 = lIllIIl.Il();
      boolean var2 = var1 != null && var1.IIl() != null && var1.IIl().IlIIll() != null && var1.IIl().IlIIll().IlIl();
      boolean var3 = var1 != null && var1.IIl() != null && var1.IIl().Ill() != null && var1.IIl().Ill().llI();
      return lIll(var0) && (Il != IIIIl(-1425323590, 1860371436) && var0.field_1724.field_6012 <= Il || var2 || var3);
   }

   public static boolean ll(class_310 var0) {
      return lIll(var0) && III != IIIIl(-1425323595, 638254475) && var0.field_1724.field_6012 <= III;
   }

   public static boolean III(class_310 var0) {
      if (!lIll(var0)) {
         return false;
      } else if (!IIlI(var0)) {
         return false;
      } else {
         int var1 = var0.field_1724.field_6012;
         if (IIl != var1 && !lIIl(var0)) {
            IIl = var1;
            return true;
         } else {
            return false;
         }
      }
   }

   public static boolean IIl(class_310 var0) {
      if (!lIll(var0)) {
         return false;
      } else {
         return !lIIl(var0);
      }
   }

   public static void IlI(class_310 var0) {
      if (lIll(var0)) {
         int var1 = var0.field_1724.field_6012 + 1;
         l = Math.max(l, var1);
         if (III == IIIIl(-1425323596, -588528355) || III < var1) {
            II = Math.max(II, var1);
         }

      }
   }

   public static boolean Ill(class_310 var0, int var1) {
      if (!lIll(var0)) {
         return false;
      } else {
         int var2 = var0.field_1724.field_6012;
         if (IIl == var2) {
            return false;
         } else {
            IIl = var2;
            Il(var0, var1);
            return true;
         }
      }
   }

   public static boolean lII(class_310 var0) {
      if (!lIll(var0)) {
         return false;
      } else if (l == IIIIl(-1425323593, 1184082621)) {
         return false;
      } else if (var0.field_1724.field_6012 < l) {
         return false;
      } else if (var0.field_1724.field_6012 >= l) {
         boolean var1 = II == var0.field_1724.field_6012;
         l = IIIIl(-1425323594, -2029644660);
         I = var0.field_1724.field_6012;
         if (!var1 || III != IIIIl(-1425323599, 1394874850) && III >= var0.field_1724.field_6012) {
            III = Math.max(III, var0.field_1724.field_6012 + 4);
         } else {
            III = IIIIl(-1425323600, -1687151700);
         }

         II = IIIIl(-1425323597, -120308068);
         return true;
      } else {
         return false;
      }
   }

   public static boolean lIl(class_310 var0) {
      return llll(var0);
   }

   public static void llI(class_310 var0) {
   }

   public static void lll(class_310 var0) {
      if (lIll(var0)) {
         class_746 var1 = var0.field_1724;
         l = Math.max(l, var1.field_6012 + 1);
         III = Math.max(III, var1.field_6012 + 4);
         II = IIIIl(-1425323598, -1335550579);
      }
   }

   public static boolean IIII(class_310 var0) {
      if (lIll(var0) && III != IIIIl(-1425323603, 1009188438)) {
         if (var0.field_1724.field_6012 <= III) {
            return false;
         } else {
            III = IIIIl(-1425323604, -508603058);
            return true;
         }
      } else {
         return false;
      }
   }

   public static boolean IIIl(class_310 var0) {
      if (!lIll(var0)) {
         return false;
      } else if (I == var0.field_1724.field_6012) {
         return true;
      } else {
         lll(var0);
         return false;
      }
   }

   private static boolean IIlI(class_310 var0) {
      if (!lIll(var0)) {
         return false;
      } else if (!Illl(var0)) {
         return true;
      } else if (I == var0.field_1724.field_6012) {
         return true;
      } else {
         lll(var0);
         return false;
      }
   }

   private lIlIllll() {
   }

   public static boolean IIll(class_310 var0) {
      if (!lIll(var0)) {
         return false;
      } else if (!IIlI(var0)) {
         return false;
      } else {
         return !lIIl(var0);
      }
   }

   public static boolean IlII(class_310 var0) {
      return IIIl(var0);
   }

   public static boolean IlIl(class_310 var0) {
      if (!lIll(var0)) {
         return false;
      } else if (I == var0.field_1724.field_6012) {
         return true;
      } else {
         lll(var0);
         return false;
      }
   }

   public static void IllI(class_310 var0) {
      if (lIll(var0)) {
         Il = Math.max(Il, var0.field_1724.field_6012);
      }
   }

   private static boolean Illl(class_310 var0) {
      if (var0 != null && var0.field_1724 != null && var0.field_1690 != null) {
         return !var0.field_1690.field_1894.method_1434() && !var0.field_1690.field_1881.method_1434() && !var0.field_1690.field_1913.method_1434() && !var0.field_1690.field_1849.method_1434() && !var0.field_1690.field_1903.method_1434() && !var0.field_1690.field_1832.method_1434() ? IllllIlI.IIlIIll(var0) : true;
      } else {
         return false;
      }
   }

   private static void lIII() {
      IIl = IIIIl(-1425323601, -1287284701);
      l = IIIIl(-1425323602, -1958949270);
      I = IIIIl(-1425323607, -1259133511);
      III = IIIIl(-1425323608, 14746208);
      II = IIIIl(-1425323605, 1705805350);
      ll = IIIIl(-1425323606, 1996993194);
      Il = IIIIl(-1425323611, 599837267);
   }

   public static boolean lIIl(class_310 var0) {
      return lIll(var0) && ll != IIIIl(-1425323612, -1348622297) && var0.field_1724.field_6012 <= ll;
   }

   public static boolean lIlI(class_310 var0, int var1) {
      if (!lIll(var0)) {
         return false;
      } else if (!IIlI(var0)) {
         return false;
      } else {
         int var2 = var0.field_1724.field_6012;
         if (IIl == var2) {
            return false;
         } else {
            IIl = var2;
            Il(var0, var1);
            return true;
         }
      }
   }

   private static boolean lIll(class_310 var0) {
      if (var0 != null && var0.field_1724 != null && var0.field_1724.method_5805()) {
         int var1 = System.identityHashCode(var0.field_1724);
         if (Ill != var1) {
            Ill = var1;
            lIII();
         }

         return true;
      } else {
         lIII();
         Ill = 0;
         return false;
      }
   }

   public static boolean llII(class_310 var0) {
      if (!lIll(var0)) {
         return false;
      } else {
         return !lIIl(var0);
      }
   }

   public static void llIl(class_310 var0) {
   }

   public static boolean lllI(class_310 var0) {
      return lIll(var0) && I == var0.field_1724.field_6012;
   }

   private static boolean llll(class_310 var0) {
      if (!lIll(var0)) {
         return false;
      } else {
         class_746 var1 = var0.field_1724;
         double var2 = var1.method_18798().field_1352;
         double var4 = var1.method_18798().field_1350;
         double var6 = Math.sqrt(var2 * var2 + var4 * var4);
         if (var6 > 0.01) {
            return false;
         } else if (var0.field_1690 == null) {
            return true;
         } else {
            return !var0.field_1690.field_1894.method_1434() && !var0.field_1690.field_1881.method_1434() && !var0.field_1690.field_1913.method_1434() && !var0.field_1690.field_1849.method_1434();
         }
      }
   }

   public static boolean IIIII(class_310 var0) {
      if (!lIll(var0)) {
         return false;
      } else if (I == var0.field_1724.field_6012) {
         return true;
      } else {
         IlI(var0);
         return false;
      }
   }

   private static int IIIIl(int var0, int var1) {
      return lII[var0 ^ -1425323587] ^ var1 ^ var0;
   }
}
