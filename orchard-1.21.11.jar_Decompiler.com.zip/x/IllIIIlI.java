package x;

import java.util.Objects;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_304;
import net.minecraft.class_310;

@Environment(EnvType.CLIENT)
public final class IllIIIlI extends IIIIIIIlI {
   private final lIIIIl I = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lll(-2058541550, -1316612510)), false));
   private long l;
   private boolean II = true;
   private final IIIllIIII Il = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(lll(-2058541549, -102209608)), 0.8, 0.1, (double)5.0F, 0.1)).IIIl(lIlIII.l(lll(-2058541548, 717624011))));
   private static final String[] lI;
   private static final Object[] ll;

   public void lllIl(class_310 var1) {
      this.lII(var1);
   }

   public void lIl() {
      this.II = true;
      this.l = 0L;
   }

   private void ll(class_310 var1) {
      if (var1 != null && var1.field_1690 != null) {
         lllI var2 = lllI.lll();
         this.llI(var1, var2, var1.field_1690.field_1894);
         this.llI(var1, var2, var1.field_1690.field_1913);
         this.llI(var1, var2, var1.field_1690.field_1849);
      }
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      this.lII(var1);
   }

   public void lI() {
      class_310 var1 = class_310.method_1551();
      this.ll(var1);
   }

   private void IlI(class_310 var1, lllI var2, class_304 var3, boolean var4) {
      if (var3 != null) {
         if (var2 != null) {
            var2.IlI(this, var1, var3, var4);
         } else {
            var3.method_23481(var4);
         }

      }
   }

   private void lII(class_310 var1) {
      if (var1 != null) {
         if (var1.field_1724 != null && var1.field_1690 != null) {
            if (var1.field_1755 != null) {
               this.ll(var1);
            } else {
               lllI var2 = lllI.lll();
               this.IlI(var1, var2, var1.field_1690.field_1894, true);
               if (!(Boolean)this.I.III()) {
                  this.IlI(var1, var2, var1.field_1690.field_1913, false);
                  this.IlI(var1, var2, var1.field_1690.field_1849, false);
               } else {
                  long var3 = System.currentTimeMillis();
                  if (var3 >= this.l) {
                     this.II = !this.II;
                     this.l = var3 + Math.max(100L, Math.round((Double)this.Il.III() * (double)1000.0F));
                  }

                  this.IlI(var1, var2, var1.field_1690.field_1913, this.II);
                  this.IlI(var1, var2, var1.field_1690.field_1849, !this.II);
               }
            }
         }
      }
   }

   private void llI(class_310 var1, lllI var2, class_304 var3) {
      if (var3 != null) {
         if (var2 != null) {
            var2.IIIl(this, var1, var3);
         } else {
            var3.method_23481(false);
         }

      }
   }

   public IllIIIlI() {
      super((Object)lIlIII.l(lll(-2058541552, 927139664)), lIllII.III, (Object)lIlIII.l(lll(-2058541551, -402564867)));
      IIIllIIII var10000 = this.Il;
      lIIIIl var10001 = this.I;
      Objects.requireNonNull(var10001);
      var10000.lIII(var10001::III);
   }

   static {
      short var0 = 26384;
      String var1 = "\ufdceﵜﴲﵫ﵎ﴺﵨﵒ﵇ﴃﴖ\ufddf⊌∞≰∩∌∱∔∠∂≑≀⊫⋬⋧⋊≾≤⊇⊆⋞≬⊛⊷⊳⋌≝∧∺⋵⊒⊭≄⊕∯≇∊∠∛∴∓∩≣≲⊫⊞⋸⋇≼≪⊛⊔⋷≅⋴⊪⊜⋵∢≨∖⋉⋮⊣≅⋋∍≣∽∌∛∾∭∂≅≮⊛⋨⊄⊽≿≪⋎⊴⋅≯⊛⊞⊴笋箙篷箮箋篿箭箛箅篕箦笮筬筊筬箒㍡㎚㎝㏆㏠㏲㎖㏍㏼㎹㏕㍄㌅㍡㌯㎙㎈㌦㍾㍀\ue057\ue0f7\ue0cc\ue092";
      char[] var2 = "朜杈最朄朔".toCharArray();
      String[] var3 = new String[var2.length];
      byte var7 = -1;

      while(true) {
         int var4 = 0;
         int var5 = 0;
         int var6 = 0;
         if (var7 == 0) {
            lI = var3;
            ll = new Object[var3.length];
            return;
         }

         do {
            var6 = var2[var4] ^ var0;
            var3[var4] = var1.substring(var5, var5 + var6);
            var5 += var6;
            ++var4;
         } while(var4 < var2.length);

         var7 = 0;
      }
   }

   private static String lll(int var0, int var1) {
      int var3 = var0 ^ -2058541552;
      char[] var4 = lI[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])ll[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         ll[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -2029881968;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 180;
               break;
            case 1:
               var9 = 10;
               break;
            case 2:
               var9 = 123;
               break;
            case 3:
               var9 = 37;
               break;
            case 4:
               var9 = 42;
               break;
            case 5:
               var9 = 4;
               break;
            case 6:
               var9 = 11;
               break;
            case 7:
               var9 = 58;
               break;
            case 8:
               var9 = 29;
               break;
            case 9:
               var9 = 94;
               break;
            case 10:
               var9 = 90;
               break;
            case 11:
               var9 = 179;
               break;
            case 12:
               var9 = 226;
               break;
            case 13:
               var9 = 240;
               break;
            case 14:
               var9 = 201;
               break;
            case 15:
               var9 = 101;
               break;
            case 16:
               var9 = 111;
               break;
            case 17:
               var9 = 186;
               break;
            case 18:
               var9 = 155;
               break;
            case 19:
               var9 = 217;
               break;
            case 20:
               var9 = 79;
               break;
            case 21:
               var9 = 227;
               break;
            case 22:
               var9 = 169;
               break;
            case 23:
               var9 = 152;
               break;
            case 24:
               var9 = 211;
               break;
            case 25:
               var9 = 41;
               break;
            case 26:
               var9 = 29;
               break;
            case 27:
               var9 = 17;
               break;
            case 28:
               var9 = 239;
               break;
            case 29:
               var9 = 154;
               break;
            case 30:
               var9 = 169;
               break;
            case 31:
               var9 = 69;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
