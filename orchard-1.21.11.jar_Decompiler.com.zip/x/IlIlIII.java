package x;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.concurrent.atomic.AtomicLong;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class IlIlIII {
   private static final long I = Long.MAX_VALUE;
   private final AtomicLong l = new AtomicLong();
   private final Deque<<undefinedtype>> II = new ArrayDeque();
   private static final int[] Il;

   public synchronized <undefinedtype> I(Object var1, Object var2, int var3, Object var4, int var5, boolean var6, Runnable var7) {
      if (!ll(var1, var2, var3, var4)) {
         return new Record(0L, var2) {
            private final long I;
            private final Object l;

            public boolean I() {
               return this.I > 0L && this.l != null;
            }

            public Object l() {
               return this.l;
            }

            public {
               this.I = var1;
               this.l = var3;
            }

            public long II() {
               return this.I;
            }
         };
      } else {
         <undefinedtype> var8 = this.IIIl(var2);
         int var9 = this.II.isEmpty() && var4 == null.I ? var1.l() : this.Il(var1);
         return (<undefinedtype>)(var8 == null && var9 == var3 && (var4 != null.I || var1.I() == var3) ? new Record(-1L, var2) {
            private final long I;
            private final Object l;

            public boolean I() {
               return this.I > 0L && this.l != null;
            }

            public Object l() {
               return this.l;
            }

            public {
               this.I = var1;
               this.l = var3;
            }

            public long II() {
               return this.I;
            }
         } : this.lIll(var1, var2, var3, var4, var5, var6, var7));
      }
   }

   private static void l(Object var0) {
      Runnable var1 = var0.Il;
      var0.Il = null;
      if (var1 != null) {
         try {
            var1.run();
         } catch (Throwable var3) {
            var3.printStackTrace();
         }
      }

   }

   public synchronized boolean II(Object var1, int var2) {
      <undefinedtype> var3 = (<undefinedtype>)this.II.peekFirst();
      if (var1 != null && var2 >= 0 && var2 <= IIIll(-24060538, -401986012) && var3 != null && var3.I.l() == var1 && !var3.IlI) {
         var3.lI = var2;
         return true;
      } else {
         return false;
      }
   }

   public synchronized int Il(Object var1) {
      <undefinedtype> var2 = (<undefinedtype>)this.II.peekFirst();
      return var2 == null ? var1.I() : var2.lI;
   }

   private static void lI(Object var0, int var1, int var2) {
      int var3 = var0.III == null.I && var2 >= 0 ? Math.max(1, var2) : var2;
      var0.Ill = var3 < 0 ? Long.MAX_VALUE : (long)var1 + (long)var3;
      var0.l = var0.III == null.I ? null.Il : IlI(var3);
   }

   private static boolean ll(Object var0, Object var1, int var2, Object var3) {
      return var0 != null && var1 != null && var3 != null && var2 >= 0 && var2 <= IIIll(-24060537, 1932018984);
   }

   private <undefinedtype> III(Object var1) {
      if (var1 != null && var1.I()) {
         for(<undefinedtype> var3 : this.II) {
            if (var3.I.II() == var1.II() && var3.I.l() == var1.l()) {
               return var3;
            }
         }

         return null;
      } else {
         return null;
      }
   }

   private void IIl(Object var1) {
      while(!this.II.isEmpty()) {
         <undefinedtype> var2 = (<undefinedtype>)this.II.peekFirst();
         if (var2 == var1) {
            return;
         }

         this.II.removeFirst();
         l(var2);
      }

   }

   private static <undefinedtype> IlI(int var0) {
      return var0 > 0 ? null.Il : null.II;
   }

   public synchronized boolean Ill() {
      <undefinedtype> var1 = (<undefinedtype>)this.II.peekFirst();
      return var1 != null && var1.III == null.I;
   }

   private <undefinedtype> lII(Object var1) {
      boolean var2 = false;

      for(<undefinedtype> var4 : this.II) {
         if (var2) {
            return var4;
         }

         var2 = var4 == var1;
      }

      return null;
   }

   public synchronized boolean lIl(Object var1) {
      return this.III(var1) != null;
   }

   public synchronized boolean llI(Object var1, Object var2, int var3, Object var4, int var5) {
      if (ll(var1, var2 == null ? null : var2.l(), var3, var4) && var2.II() != 0L && var1.Il() >= var5) {
         return var2.II() < 0L ? var1.lI(var4, var3) : this.lll(var1, var2, var5);
      } else {
         return false;
      }
   }

   public synchronized boolean lll(Object var1, Object var2, int var3) {
      <undefinedtype> var4 = this.III(var2);
      return var4 != null && var4 == this.II.peekFirst() && !var4.IlI && var1.Il() >= var3 && var1.lI(var4.III, var4.lI);
   }

   public synchronized void IIII(Object var1, Object var2, Object var3) {
      <undefinedtype> var4 = this.IIIl(var2);
      if (var4 != null) {
         if (var4 != this.II.peekFirst()) {
            this.II.remove(var4);
            l(var4);
         } else {
            l(var4);
            if (var3 == null.II) {
               this.lIII(var1, var4);
            } else {
               this.II.removeFirst();
            }

            if (var3 != null.II && !this.II.isEmpty()) {
               <undefinedtype> var5 = (<undefinedtype>)this.II.peekFirst();
               var1.II(var5.III, var5.lI);
            }

         }
      }
   }

   private <undefinedtype> IIIl(Object var1) {
      if (var1 == null) {
         return null;
      } else {
         for(<undefinedtype> var3 : this.II) {
            if (var3.I.l() == var1) {
               return var3;
            }
         }

         return null;
      }
   }

   public synchronized boolean IIlI(Object var1) {
      <undefinedtype> var2 = (<undefinedtype>)this.II.peekFirst();
      return var1 != null && var2 != null && var2.I.l() == var1;
   }

   public synchronized int IIll() {
      return this.II.size();
   }

   public synchronized boolean IlII(Object var1, int var2, int var3, Object var4) {
      <undefinedtype> var5 = this.IIIl(var1);
      return var5 != null && this.IIIlI(var5.I, var2, var3, var4);
   }

   public synchronized boolean IlIl() {
      <undefinedtype> var1 = (<undefinedtype>)this.II.peekFirst();
      return var1 != null && var1.IlI;
   }

   public synchronized void IllI() {
      this.II.clear();
   }

   public synchronized void Illl(Object var1, Object var2) {
      while(true) {
         <undefinedtype> var3 = (<undefinedtype>)this.II.peekFirst();
         if (var3 == null) {
            return;
         }

         if (var3.IlI) {
            if (!this.IIIII(var1, var3)) {
               return;
            }
         } else {
            if (!var3.I(var1.Il(), var2)) {
               return;
            }

            boolean var4 = var3.IIl;
            l(var3);
            if (var4) {
               this.lIII(var1, var3);
               if (var3.IlI) {
                  return;
               }
            } else {
               this.II.removeFirst();
            }

            if (!var4 && !this.II.isEmpty()) {
               <undefinedtype> var5 = (<undefinedtype>)this.II.peekFirst();
               var1.II(var5.III, var5.lI);
            }
         }
      }
   }

   private void lIII(Object var1, Object var2) {
      <undefinedtype> var3 = this.lII(var2);
      int var4 = var3 != null ? var3.lI : var2.ll;
      <undefinedtype> var5 = var2.III == null.I ? null.I : (var3 != null ? var3.III : var2.lII);
      var2.IlI = true;
      var2.lI = var4;
      var2.III = var5;
      var1.II(var5, var4);
      if (var5 != null.I || var1.lI(var5, var4)) {
         this.II.remove(var2);
         var2.IlI = false;
      }

   }

   public synchronized boolean lIIl(Object var1) {
      <undefinedtype> var2 = this.IIIl(var1);
      if (var2 == null) {
         return false;
      } else {
         var2.Il = null;
         return this.II.remove(var2);
      }
   }

   public synchronized int lIlI(Object var1) {
      <undefinedtype> var2 = (<undefinedtype>)this.II.peekFirst();
      return var1 != null && var2 != null && var2.I.l() == var1 ? var2.lI : -1;
   }

   public synchronized <undefinedtype> lIll(Object var1, Object var2, int var3, Object var4, int var5, boolean var6, Runnable var7) {
      if (!ll(var1, var2, var3, var4)) {
         return new Record(0L, var2) {
            private final long I;
            private final Object l;

            public boolean I() {
               return this.I > 0L && this.l != null;
            }

            public Object l() {
               return this.l;
            }

            public {
               this.I = var1;
               this.l = var3;
            }

            public long II() {
               return this.I;
            }
         };
      } else {
         <undefinedtype> var8 = this.IIIl(var2);
         <undefinedtype> var9 = (<undefinedtype>)this.II.peekFirst();
         if (var8 != null) {
            if (var8 == var9 && !var8.IlI) {
               boolean var15 = var9.lI != var3 || var9.III != var4;
               var9.lI = var3;
               var9.III = var4;
               var9.IIl = var6;
               var9.Il = var7;
               lI(var9, var1.Il(), var5);
               if (var15) {
                  var1.II(var4, var3);
               }

               return var9.I;
            } else {
               return new Record(0L, var2) {
                  private final long I;
                  private final Object l;

                  public boolean I() {
                     return this.I > 0L && this.l != null;
                  }

                  public Object l() {
                     return this.l;
                  }

                  public {
                     this.I = var1;
                     this.l = var3;
                  }

                  public long II() {
                     return this.I;
                  }
               };
            }
         } else {
            int var10 = this.II.isEmpty() && var4 == null.I ? var1.l() : this.Il(var1);
            if (var10 != var3 || var4 == null.I && var1.I() != var3) {
               <undefinedtype> var11 = (<undefinedtype>)this.II.peekLast();
               int var12 = var11 == null ? var1.I() : var11.ll;
               <undefinedtype> var13 = var11 == null ? lllI(var4) : var11.lII;
               Object var14 = new Object(new Record(this.l.incrementAndGet(), var2) {
                  private final long I;
                  private final Object l;

                  public boolean I() {
                     return this.I > 0L && this.l != null;
                  }

                  public Object l() {
                     return this.l;
                  }

                  public {
                     this.I = var1;
                     this.l = var3;
                  }

                  public long II() {
                     return this.I;
                  }
               }, var12, var13, var10, var9 == null ? lllI(var4) : var9.III, var3, var4, var6, var7) {
                  private final <undefinedtype> I;
                  private <undefinedtype> l;
                  private final int II;
                  private Runnable Il;
                  private int lI;
                  private final int ll;
                  private <undefinedtype> III;
                  private boolean IIl;
                  private boolean IlI;
                  private long Ill;
                  private final <undefinedtype> lII;
                  private final <undefinedtype> lIl;

                  private {
                     this.I = var1;
                     this.ll = var2;
                     this.lII = var3;
                     this.II = var4;
                     this.lIl = var5;
                     this.lI = var6;
                     this.III = var7;
                     this.IIl = var8;
                     this.Il = var9;
                  }

                  private boolean I(int var1, Object var2) {
                     return this.Ill != Long.MAX_VALUE && (long)var1 >= this.Ill && (this.III != null.I || var2 == null.Il) && var2.ordinal() >= this.l.ordinal();
                  }
               };
               lI((<undefinedtype>)var14, var1.Il(), var5);
               this.II.addFirst(var14);
               if (var10 != var3 || var4 != null.I) {
                  var1.II(var4, var3);
               }

               return ((<undefinedtype>)var14).I;
            } else {
               return new Record(0L, var2) {
                  private final long I;
                  private final Object l;

                  public boolean I() {
                     return this.I > 0L && this.l != null;
                  }

                  public Object l() {
                     return this.l;
                  }

                  public {
                     this.I = var1;
                     this.l = var3;
                  }

                  public long II() {
                     return this.I;
                  }
               };
            }
         }
      }
   }

   public synchronized <undefinedtype> llII(Object var1) {
      <undefinedtype> var2 = (<undefinedtype>)this.II.peekFirst();
      return var1 != null && var2 != null && var2.I.l() == var1 ? var2.III : null;
   }

   public synchronized boolean llIl() {
      return !this.II.isEmpty();
   }

   private static <undefinedtype> lllI(Object var0) {
      return var0 == null.I ? null.I : var0;
   }

   public synchronized void llll(Object var1, Object var2, Object var3) {
      <undefinedtype> var4 = this.III(var2);
      if (var4 != null) {
         this.IIl(var4);
         l(var4);
         if (var3 == null.II) {
            this.lIII(var1, var4);
         } else {
            this.II.removeFirst();
         }

         if (var3 != null.II && !this.II.isEmpty()) {
            <undefinedtype> var5 = (<undefinedtype>)this.II.peekFirst();
            var1.II(var5.III, var5.lI);
         }

      }
   }

   private boolean IIIII(Object var1, Object var2) {
      if (!var1.lI(var2.III, var2.lI)) {
         return false;
      } else {
         var2.IlI = false;
         return this.II.remove(var2);
      }
   }

   public synchronized boolean IIIIl(Object var1) {
      return this.IIIl(var1) != null;
   }

   public synchronized boolean IIIlI(Object var1, int var2, int var3, Object var4) {
      <undefinedtype> var5 = this.III(var1);
      if (var5 != null && !var5.IlI) {
         int var6 = var5.III == null.I && var3 >= 0 ? Math.max(1, var3) : var3;
         var5.IIl = true;
         var5.Ill = var6 < 0 ? Long.MAX_VALUE : (long)var2 + (long)var6;
         var5.l = var4 == null ? (var5.III == null.I ? null.Il : IlI(var6)) : var4;
         return true;
      } else {
         return false;
      }
   }

   private static int IIIll(int var0, int var1) {
      return Il[var0 ^ -24060538] ^ var1 ^ var0;
   }

   static {
      int var2 = 547590691;
      byte[] var0 = "69a\u0089\u00ad\u001b\n\u0084".getBytes("ISO-8859-1");
      int var1 = var0.length / 4;
      Il = new int[var1];
      int var3 = 0;
      int var4 = 0;

      do {
         int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
         var5 ^= var2;
         Il[var4] = var5;
         var3 += 4;
         ++var4;
      } while(var4 < var1);

   }
}
