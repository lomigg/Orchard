package x;

import com.mojang.authlib.GameProfile;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1060;
import net.minecraft.class_12079;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3298;
import net.minecraft.class_7920;
import net.minecraft.class_8685;

@Environment(EnvType.CLIENT)
public final class IIIllI extends IIIIIIIlI {
   private static String[] I;
   private class_8685 l;
   private static final int II = 22;
   private static final Map<<undefinedtype>, class_12079.class_12081> Il;
   private static final int lI = 64;
   private class_8685 ll;
   private <undefinedtype> III;
   private boolean IIl;
   private static final int IlI = 17;
   private static final int Ill = 32;
   private String lII;
   private final IlIIIlIlI<<undefinedtype>> lIl;
   private static final int[] llI;
   private static final String[] lll;
   private static final Object[] IIII;

   private static String ll(char[] var0, long var1, int var3) {
      int var4 = lllI(1254024016, 495973592) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & lllI(1254024017, -510494093);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private static class_1011 IlI(class_1011 var0) {
      int var1 = var0.method_4307();
      int var2 = var0.method_4323();
      int var3 = (int)Math.max(64L, IlIl((long)var1 * 64L, 22L));
      int var4 = (int)Math.max(32L, IlIl((long)var2 * 32L, 17L));
      int var5 = Math.max(var1, (int)Math.ceil((double)var3 * (double)0.34375F));
      int var6 = Math.max(var2, (int)Math.ceil((double)var4 * (double)0.53125F));
      if (var3 < var5) {
         var3 = var5;
      }

      if (var4 < var6) {
         var4 = var6;
      }

      class_1011 var7 = new class_1011(var3, var4, true);
      int var8 = Math.max(0, (var5 - var1) / 2);
      int var9 = Math.max(0, (var6 - var2) / 2);

      for(int var10 = 0; var10 < var1; ++var10) {
         for(int var11 = 0; var11 < var2; ++var11) {
            var7.method_61941(var8 + var10, var9 + var11, var0.method_61940(var10, var11));
         }
      }

      var0.close();
      return var7;
   }

   private static class_12079.class_12081 lII(Object var0) {
      String var10000 = lIlIII.Il(I[2]);
      String var10001 = lIlIII.Il(I[0]);
      String var10002 = var0.Il();
      String var12 = lIlIII.Il(I[3]);
      String var11 = var10002;
      String var10 = var10001;
      class_2960 var1 = class_2960.method_60655(var10000, var10 + var11 + var12);
      var10000 = lIlIII.Il(I[2]);
      var10001 = lIlIII.Il(I[4]);
      var12 = var0.Il();
      var11 = var10001;
      class_2960 var2 = class_2960.method_60655(var10000, var11 + var12);
      class_310 var3 = class_310.method_1551();
      if (var3 == null) {
         return new class_12079.class_10726(var2, var1);
      } else {
         class_1060 var4 = var3.method_1531();
         if (var4 != null && var3.method_1478() != null) {
            var10000 = lIlIII.Il(I[2]);
            var10001 = lIlIII.Il(I[1]);
            String var13 = var0.Il();
            var12 = var10001;
            class_2960 var5 = class_2960.method_60655(var10000, var12 + var13);
            Optional var6 = var3.method_1478().method_14486(var1);
            if (var6.isEmpty()) {
               return new class_12079.class_10726(var2, var1);
            } else {
               try {
                  InputStream var7 = ((class_3298)var6.get()).method_14482();

                  class_12079.class_10726 var9;
                  try {
                     class_1011 var8 = class_1011.method_4309(var7);
                     var8 = IlI(var8);
                     Objects.requireNonNull(var5);
                     var4.method_4616(var5, new class_1043(var5::toString, var8));
                     var9 = new class_12079.class_10726(var5, var5);
                  } catch (Throwable var15) {
                     if (var7 != null) {
                        try {
                           var7.close();
                        } catch (Throwable var14) {
                           var15.addSuppressed(var14);
                        }
                     }

                     throw var15;
                  }

                  if (var7 != null) {
                     var7.close();
                  }

                  return var9;
               } catch (IOException var16) {
                  return new class_12079.class_10726(var2, var1);
               }
            }
         } else {
            return new class_12079.class_10726(var2, var1);
         }
      }
   }

   public void lIl() {
      this.lIll();
   }

   private static void llI() {
      I[0] = ll(IIIII(1242601793, 390801586).toCharArray(), 42621L, lllI(1254024018, 1769110926));
      I[1] = ll(IIIII(1242601792, 1510559812).toCharArray(), 38146L, lllI(1254024019, -1812539197));
      I[2] = ll(IIIII(1242601795, -2107363707).toCharArray(), 64048L, lllI(1254024020, 2077852189));
      I[3] = ll(IIIII(1242601794, 661742770).toCharArray(), 8893L, lllI(1254024021, -323662580));
      I[4] = ll(IIIII(1242601797, 1301225485).toCharArray(), 25291L, lllI(1254024022, 878613743));
      I[5] = ll(IIIII(1242601796, -1333196864).toCharArray(), 29201L, lllI(1254024023, -1798833066));
      I[lllI(1254024024, 1266412784)] = ll("".toCharArray(), 90111L, lllI(1254024025, 12523507));
      I[lllI(1254024026, -1222671147)] = ll(IIIII(1242601799, 627854019).toCharArray(), 17497L, lllI(1254024027, 1240645930));
      I[lllI(1254024028, -1434000198)] = ll(IIIII(1242601798, 1686785903).toCharArray(), 75661L, lllI(1254024029, -118446286));
   }

   static {
      short var6 = 15742;
      String var7 = "ᨶඁ\uf6e1\uf28c类䏾ѿ✜串鳭㏁빽\ue267៤⮰糕첃麪性ꗳ븃ᮄ璩⥓읭墮縛쐾褤ꗱꇆ禊릔貛ᨤ林㜫蝷㈉꾠줎뿹挾һ\udab4ᾷ⹌Ⲡ\udcb0楄ꄆ\u1a9e\ue1c5鴲펁↭拺䑎觩\ud8a4엉邷钊⣃\u206dᬢῲ虚\uf525⺼䅹\uefe5繛坽ɢ䟿쓴酊⏂\ue39e䗓퐪鶤메똴⚺Ꚛ\udb35眿噲Ἀ螟췿侂൴㳑솣絜柏\ue698\udefeꂮ䣛翣쒞\ue72f徖靳\uebd1ႆ㊢\ued2a䥫∂紭꩙\uf47e紛\uef87\uee31ﲐ陱厭\ue0c8﨨ᆵ후깤䌚옃꼖ᎄ\uf157棁䊿껜퓠⌼ᨗ偯鉳\udbfd呤\uec90";
      char[] var8 = "㵦㵮㵶㵶㵶㵶㵂㵲".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            lll = var9;
            IIII = new Object[var9.length];
            int var2 = -934931771;
            byte[] var0 = "\u0017E{¸cj\u008b\u0018ê¡jÇþí^3-R\u0083\têm\"}ÏÑA\u0083\u0086>âlÉ\u0083\u001dk¨#9ß5çuM\u0096A»Ó(~\u0015+Ûä*\u0013ÜL¨vN%`öCëùdD&®\u008d\u008d4f`".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            llI = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               llI[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            I = new String[lllI(1254024030, 1588877796)];
            llI();
            Il = new ConcurrentHashMap();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 28;
                     break;
                  case 1:
                     var10000 = 51;
                     break;
                  case 2:
                     var10000 = 42;
                     break;
                  case 3:
                     var10000 = 11;
                     break;
                  case 4:
                     var10000 = 91;
                     break;
                  case 5:
                     var10000 = 76;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public String Il() {
      return ((<undefinedtype>)this.lIl.III()).l();
   }

   public Object IIII(GameProfile var1, Object var2) {
      if (!this.IIll(var1)) {
         return var2;
      } else if (this.lIl.III() == null.II) {
         return var2;
      } else {
         class_8685 var10000;
         if (var2 instanceof class_8685) {
            class_8685 var4 = (class_8685)var2;
            var10000 = var4;
         } else {
            var10000 = this.l;
         }

         class_8685 var3 = var10000;
         if (var3 == null) {
            this.lIll();
            return var2;
         } else {
            <undefinedtype> var5 = (<undefinedtype>)this.lIl.III();
            if (this.ll == null || this.III != var5 || this.l != var3) {
               this.l = var3;
               this.III = var5;
               this.ll = lIIl(var3, var5);
            }

            return this.ll;
         }
      }
   }

   public void lI() {
      this.ll = null;
      this.IIl = false;
   }

   private boolean IIll(GameProfile var1) {
      class_310 var2 = class_310.method_1551();
      return this.IIIIIlI() && var1 != null && var2.field_1724 != null && var2.field_1724.method_7334() != null && IIIIlII.I(var2.field_1724.method_7334()) != null && IIIIlII.I(var2.field_1724.method_7334()).equals(IIIIlII.I(var1));
   }

   public void IlII(String var1) {
   }

   public void Ill() {
      this.lIll();
   }

   private static long IlIl(long var0, long var2) {
      return (var0 + var2 - 1L) / var2;
   }

   private static class_12079.class_12081 Illl(Object var0) {
      return (class_12079.class_12081)Il.computeIfAbsent(var0, IIIllI::lII);
   }

   public void lIII() {
   }

   private static class_8685 lIIl(class_8685 var0, Object var1) {
      if (var0 != null && var1 != null.II) {
         class_12079.class_12081 var2 = Illl(var1);
         return new class_8685(var0.comp_1626(), var2, var0.comp_1628(), var0.comp_1629() == null ? class_7920.field_41123 : var0.comp_1629(), var0.comp_1630());
      } else {
         return var0;
      }
   }

   private void lIll() {
      class_310 var1 = class_310.method_1551();
      if (var1.field_1724 != null && var1.method_1582() != null) {
         if (this.lIl.III() == null.II) {
            this.ll = null;
            this.IIl = false;
         } else {
            GameProfile var2 = var1.field_1724.method_7334();
            String var3 = IIIIlII.I(var2) == null ? IIIIlII.II(var2) : IIIIlII.I(var2).toString();
            boolean var4 = !var3.equals(this.lII);
            boolean var5 = this.lIl.III() != this.III;
            if (var4) {
               this.lII = var3;
               this.l = null;
               this.ll = null;
            }

            if (var5 && this.l != null) {
               this.III = (<undefinedtype>)this.lIl.III();
               this.ll = lIIl(this.l, this.III);
            }

            if ((this.l == null || var4) && !this.IIl) {
               this.IIl = true;
               var1.method_1582().method_52863(var2).whenComplete((var2x, var3x) -> var1.execute(() -> {
                     this.IIl = false;
                     if (var3x == null) {
                        Object var3 = var2x instanceof Optional ? var2x.orElse((Object)null) : var2x;
                        if (var3 instanceof class_8685) {
                           class_8685 var4 = (class_8685)var3;
                           this.l = var4;
                           this.III = (<undefinedtype>)this.lIl.III();
                           this.ll = lIIl(var4, this.III);
                        }
                     }
                  }));
            }

         }
      } else {
         this.l = null;
         this.ll = null;
         this.IIl = false;
         this.lII = I[lllI(1254024031, -857894550)];
      }
   }

   public IIIllI() {
      super((Object)lIlIII.l(I[lllI(1254024000, -1055717143)]), lIllII.ll, (Object)lIlIII.l(I[lllI(1254024001, -958505202)]));
      this.lIl = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(I[5]), <undefinedtype>.class, null.II));
      this.III = null.II;
      this.lII = I[lllI(1254024002, 265066465)];
   }

   private static int lllI(int var0, int var1) {
      return llI[var0 ^ 1254024016] ^ var1 ^ var0;
   }

   private static String IIIII(int var0, int var1) {
      int var3 = var0 ^ 1242601793;
      char[] var4 = lll[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IIII[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IIII[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -1194237282;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 254;
               break;
            case 1:
               var9 = 255;
               break;
            case 2:
               var9 = 151;
               break;
            case 3:
               var9 = 185;
               break;
            case 4:
               var9 = 189;
               break;
            case 5:
               var9 = 86;
               break;
            case 6:
               var9 = 236;
               break;
            case 7:
               var9 = 222;
               break;
            case 8:
               var9 = 161;
               break;
            case 9:
               var9 = 174;
               break;
            case 10:
               var9 = 250;
               break;
            case 11:
               var9 = 71;
               break;
            case 12:
               var9 = 128;
               break;
            case 13:
               var9 = 203;
               break;
            case 14:
               var9 = 0;
               break;
            case 15:
               var9 = 33;
               break;
            case 16:
               var9 = 161;
               break;
            case 17:
               var9 = 242;
               break;
            case 18:
               var9 = 202;
               break;
            case 19:
               var9 = 238;
               break;
            case 20:
               var9 = 31;
               break;
            case 21:
               var9 = 89;
               break;
            case 22:
               var9 = 169;
               break;
            case 23:
               var9 = 229;
               break;
            case 24:
               var9 = 118;
               break;
            case 25:
               var9 = 79;
               break;
            case 26:
               var9 = 85;
               break;
            case 27:
               var9 = 226;
               break;
            case 28:
               var9 = 60;
               break;
            case 29:
               var9 = 219;
               break;
            case 30:
               var9 = 216;
               break;
            case 31:
               var9 = 155;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
