package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public enum IIllI {
   I,
   l;

   private static String[] Il;
   private final <undefinedtype> lI;
   private static final int[] ll;
   private static final String[] III;
   private static final Object[] IIl;

   private static String I(char[] var0, long var1, int var3) {
      int var4 = lI(652822757, -773723724) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & lI(652822756, -1928592733);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   public String toString() {
      return this.lI.lIlI();
   }

   public static IIllI l(String var0) {
      return (IIllI)Enum.valueOf(IIllI.class, var0);
   }

   // $FF: synthetic method
   private static IIllI[] II() {
      return new IIllI[]{I, l};
   }

   private static void Il() {
      Il[0] = I(ll(-529054260, 6653, '䱪').toCharArray(), 95394L, lI(652822759, 1831399697));
      Il[1] = I(ll(121269178, 63156, '䱫').toCharArray(), 60200L, lI(652822758, 1906083523));
      Il[2] = I(ll(-1812196748, 13911, '䱨').toCharArray(), 45512L, lI(652822753, 1887384238));
      Il[3] = I(ll(1601443291, 12483, '䱩').toCharArray(), 75497L, lI(652822752, -1282441917));
   }

   private IIllI(String var3) {
      this.lI = lIlIII.III(var3);
   }

   static {
      short var6 = 7179;
      String var7 = "\u19af쪛్ନ觎噃恖\ud804\ua95d릝鉢\ue0df︧ᳺ┐퀀糧乸\ue36b着\uda33賣朏䄹Ⱔ誕儶걏䗤칉磏빺芕恸쌉䏧徸⨒챡꙾";
      char[] var8 = "ᰛᰍᰁᰃ".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            III = var9;
            IIl = new Object[var9.length];
            int var2 = -142733146;
            byte[] var0 = "¼Ü\u00ad\u008f\\\u009bZ\u001epZ\u0011¹°´çô\u0012\u0089÷\u009d\u0091I©b".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            ll = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               ll[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            Il = new String[4];
            Il();
            I = new IIllI(Il[2], 0, lIlIII.Il(Il[0]));
            l = new IIllI(Il[1], 1, lIlIII.Il(Il[3]));
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 26;
                     break;
                  case 1:
                     var10000 = 126;
                     break;
                  case 2:
                     var10000 = 43;
                     break;
                  case 3:
                     var10000 = 78;
                     break;
                  case 4:
                     var10000 = 22;
                     break;
                  case 5:
                     var10000 = 50;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static int lI(int var0, int var1) {
      return ll[var0 ^ 652822757] ^ var1 ^ var0;
   }

   private static String ll(int var0, int var1, char var2) {
      int var3 = var2 ^ 19562;
      char[] var4 = III[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])IIl[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         IIl[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 18041;
      int var9 = 0;

      do {
         int var10 = var4[var9] ^ 15386;
         var10 -= 7942;
         var10 += 58621;
         var10 ^= 56331;
         var10 += 32660;
         var10 ^= 29762;
         var10 += 20059;
         var10 += 25826;
         var4[var9] = (char)(var10 ^ var8 ^ var1 ^ var0 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
