package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
record IIIlIIII(Object owner, <undefinedtype> listener) {
   private final <undefinedtype> I;
   private final Object l;

   public Object I() {
      return this.l;
   }

   private boolean l(Object var1) {
      return this.l == var1;
   }

   public <undefinedtype> II() {
      return this.I;
   }

   private IIIlIIII(Object var1, Object var2) {
      this.l = var1;
      this.I = var2;
   }
}
