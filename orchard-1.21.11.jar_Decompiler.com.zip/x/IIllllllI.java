package x;

import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_746;

@Environment(EnvType.CLIENT)
public final class IIllllllI extends IIIIIIIlI {
   private final lIIIIl I;
   private final lIIIIl l;
   private boolean II;
   private long Il;
   private boolean lI;
   private boolean ll;
   private boolean III;
   private final lIIIIl IIl;
   private boolean IlI;
   private int Ill;
   private boolean lII;
   private boolean lIl;
   private static final int llI = 7;
   private long lll;
   private static final long IIII = 220000000L;
   private final IIIllIIII IIIl;
   private int IIlI;
   private double IIll;
   private final IIIllIIII IlII;
   private static final long IlIl = 55L;
   private final lIIIIl IllI;
   private final lIIIIl Illl;
   private final IIIllIIII lIII = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(lIllI(-1606782868, (short)'\ueac6', 45043)), (double)72.0F, (double)4.0F, (double)128.0F, (double)1.0F)).IIIl(lIlIII.l(lIllI(-199809538, (short)28715, 45042))));
   private final lIIIIl lIIl;
   private boolean lIlI;
   private int lIll;
   private long llII;
   private final IlIIIlIlI<<undefinedtype>> llIl;
   private final IIIllIIII lllI = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(lIllI(-287437120, (short)2215, 45045)), (double)5.0F, (double)0.0F, (double)15.0F, (double)0.5F)).IIIl(lIlIII.l(lIllI(-577632114, (short)25310, 45044))));
   private int llll;
   private final lIIIIl IIIII;
   private final IIIllIIII IIIIl;
   private final IIIllIIII IIIlI;
   private final IIIllIIII IIIll;
   private final lIIIIl IIlII;
   private boolean IIlIl;
   private long IIllI;
   private final IIIllIIII IIlll = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(lIllI(-2107342947, (short)'\ue94b', 45041)), 2.35, (double)1.0F, (double)6.0F, 0.05)).IIIl(lIlIII.l(lIllI(-254077605, (short)'\uded1', 45040))));
   private boolean IlIII;
   private double IlIIl;
   private static final double IlIlI = 0.42;
   private class_1657 IlIll;
   private static final int[] IllII;
   private static final String[] IllIl;
   private static final Object[] IlllI;

   public IIllllllI() {
      super((Object)lIlIII.l(lIllI(-1021348520, (short)'릦', 45047)), lIllII.III, (Object)lIlIII.l(lIllI(807561719, (short)29410, 45046)));
      this.llIl = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(lIllI(654918421, (short)'롑', 45055)), <undefinedtype>.class, null.I));
      this.IIIl = (IIIllIIII)this.IIIlIll((IIIllIIII)(new IIIllIIII(lIlIII.l(lIllI(-1787091584, (short)18055, 45054)), (double)3.0F, (double)1.0F, (double)12.0F, 0.1)).IIIl(lIlIII.l(lIllI(128526343, (short)'\udda2', 45053))).lIII(() -> this.llIl.III() != null.lI));
      this.IIIlI = (IIIllIIII)this.IIIlIll((IIIllIIII)(new IIIllIIII(lIlIII.l(lIllI(-680773719, (short)14598, 45052)), (double)4.5F, (double)1.0F, (double)16.0F, 0.1)).IIIl(lIlIII.l(lIllI(1111299140, (short)'鯧', 45051))).lIII(() -> this.llIl.III() == null.I));
      this.IllI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lIllI(-1185056311, (short)3576, 45050)), true));
      this.IIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lIllI(2026441936, (short)'蹲', 45049)), true));
      this.l = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lIllI(-1593881564, (short)9995, 45048)), true));
      IIIllIIII var10002 = (new IIIllIIII(lIlIII.l(lIllI(1187851232, (short)26508, 45031)), (double)2.0F, (double)0.5F, (double)3.0F, 0.05)).IIIl(lIlIII.l(lIllI(-1384026616, (short)'ꇱ', 45030)));
      lIIIIl var10003 = this.l;
      Objects.requireNonNull(var10003);
      this.IIIll = (IIIllIIII)this.IIIlIll((IIIllIIII)var10002.lIII(var10003::III));
      this.IIIII = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lIllI(1156000197, (short)28080, 45029)), false));
      this.I = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lIllI(2104522682, (short)20324, 45028)), true));
      this.Illl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lIllI(-1851164720, (short)15554, 45027)), true));
      this.lIIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lIllI(-1508549151, (short)12676, 45026)), true));
      this.IIIIl = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(lIllI(981620189, (short)'蹨', 45025)), (double)100.0F, (double)20.0F, (double)200.0F, (double)5.0F)).IIIl(lIlIII.l(lIllI(-1975815066, (short)16950, 45024))));
      this.IIlII = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lIllI(258243584, (short)791, 45039)), true));
      this.IlII = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(lIllI(1868201754, (short)13045, 45038)), (double)6.0F, (double)0.0F, (double)20.0F, (double)1.0F));
      this.lIll = 1;
      this.IIlI = -1;
   }

   private void IlI(class_746 var1, boolean var2) {
      double var3 = var1.method_23317();
      double var5 = var1.method_23321();
      if (this.IlIII && var2 && var1.method_24828()) {
         double var7 = var3 - this.IlIIl;
         double var9 = var5 - this.IIll;
         this.llll = var7 * var7 + var9 * var9 < 4.0E-4 ? this.llll + 1 : Math.max(0, this.llll - 2);
      } else if (!var2) {
         this.llll = 0;
      }

      this.IlIIl = var3;
      this.IIll = var5;
      this.IlIII = true;
   }

   private void llI(class_310 var1, class_1657 var2) {
      class_746 var3 = var1.field_1724;
      double var4 = Math.sqrt(var3.method_5858(var2));
      boolean var6 = this.IlIIl(var2);
      boolean var7 = var6 && var4 <= Math.min((double)3.0F, (Double)this.IIIll.III()) && var3.method_6057(var2);
      boolean var8 = !(Boolean)this.I.III() || this.IlII(var1, (double)1.0F, (double)0.0F);
      <undefinedtype> var9 = (<undefinedtype>)this.llIl.III();
      boolean var10 = var9 != null.lI && this.IIlIl(var3) && var8;
      boolean var11 = var9 == null.I && var10;
      <undefinedtype> var12 = x.IlIll.Il(var4, var7, var3.method_24828(), var10, var11, (Double)this.IIlll.III(), (Double)this.IIIl.III(), (Double)this.IIIlI.III(), (Boolean)this.l.III());
      this.lII = var12.l();
      this.lIl = var12.II();
      this.IIlIl = var12.I();
      this.III = false;
      this.ll = false;
      boolean var13 = (Boolean)this.IllI.III() && this.lII && var3.method_24828() && var3.field_5976 && var8;
      if (var13) {
         this.lIl = false;
         this.IIlIl = true;
      }

      this.IlI(var3, this.lII);
      if ((Boolean)this.IIl.III() && (!var13 && var3.field_5976 && this.Ill <= 0 || this.llll >= lIlIl(-1802114443, 96671959))) {
         this.lIIIl(var1);
      }

      if ((Boolean)this.I.III() && this.lII && var3.method_24828() && !this.IlII(var1, (double)1.0F, (double)0.0F)) {
         this.lIII(var1);
      } else if ((Boolean)this.IIl.III() && this.Ill > 0 && !var7) {
         this.III = this.lIll > 0;
         this.ll = this.lIll < 0;
         --this.Ill;
      } else if (!(Boolean)this.IIl.III()) {
         this.Ill = 0;
      }

   }

   private class_1657 lll(class_310 var1) {
      class_1657 var2 = null;
      double var3 = Double.POSITIVE_INFINITY;

      for(class_1657 var6 : var1.field_1687.method_18456()) {
         double var7;
         if (this.lIIlI(var1, var6, (Double)this.lIII.III()) && !((var7 = var1.field_1724.method_5858(var6)) >= var3)) {
            var2 = var6;
            var3 = var7;
         }
      }

      return var2;
   }

   private void IIII(class_310 var1) {
      if (var1 != null && var1.field_1690 != null) {
         this.II = true;
         this.IIllI(var1, var1.field_1690.field_1894, this.lII);
         this.IIllI(var1, var1.field_1690.field_1881, false);
         this.IIllI(var1, var1.field_1690.field_1913, this.III);
         this.IIllI(var1, var1.field_1690.field_1849, this.ll);
         this.IIllI(var1, var1.field_1690.field_1867, this.lIl);
         this.IIllI(var1, var1.field_1690.field_1903, this.IIlIl);
         if (var1.field_1724 != null) {
            var1.field_1724.method_5728(this.lIl);
         }

      }
   }

   public String l() {
      return lIlIII.Il(lIllI(-1966597745, (short)'왼', 45037));
   }

   private boolean IIll(class_310 var1) {
      int var2 = this.IIlII(var1);
      boolean var3 = var2 >= 0;
      if (!var3 && !this.lI) {
         this.lIlI = false;
      }

      if (!x.IlIll.I(var3, this.lIlI, this.lI)) {
         return this.lI;
      } else if (IllllIlI.IlllIl()) {
         return false;
      } else {
         this.lIlI = true;
         this.lI = true;
         this.IIlI = var2;
         IllllIlI.IIlIlI(var1, var2, true);
         long var4 = this.lll;
         class_746 var6 = var1.field_1724;
         CompletableFuture.runAsync(() -> var1.execute(() -> this.Illl(var1, var6, var2, var4)), CompletableFuture.delayedExecutor(55L, TimeUnit.MILLISECONDS));
         return true;
      }
   }

   private boolean IlII(class_310 var1, double var2, double var4) {
      class_746 var6 = var1.field_1724;
      if (!var6.method_24828()) {
         return true;
      } else {
         double var7 = Math.toRadians((double)var6.method_36454());
         double var9 = -Math.sin(var7) * var2 - Math.cos(var7) * var4;
         double var11 = Math.cos(var7) * var2 - Math.sin(var7) * var4;
         double var13 = Math.hypot(var9, var11);
         return var13 < 1.0E-4 || lIlIll.l(var1.field_1687, var6, var9 / var13 * 0.42, var11 / var13 * 0.42);
      }
   }

   private void Illl(class_310 var1, class_1657 var2, int var3, long var4) {
      if (var4 == this.lll && this.IIIIIlI() && this.IlI && this.lllI(var1) && var1.field_1724 == var2 && var1.field_1755 == null && var1.field_1724.method_31548().method_5438(var3).method_31574(class_1802.field_8407)) {
         IllllIlI.IIlIlI(var1, var3, true);
         IllllIlI.lllIll(var1);
         IllllIlI.IllIIl(var1, class_1268.field_5808);
         this.IIlI = var3;
         this.lI = false;
      } else {
         this.lI = false;
      }
   }

   private void lIII(class_310 var1) {
      this.lII = false;
      this.lIl = false;
      this.IIlIl = false;
      boolean var2 = this.IlII(var1, (double)0.0F, (double)1.0F);
      boolean var3 = this.IlII(var1, (double)0.0F, (double)-1.0F);
      if (!var2 && !var3) {
         this.III = false;
         this.ll = false;
      } else {
         if (var2 != var3) {
            this.lIll = var2 ? 1 : -1;
         }

         this.III = this.lIll > 0 && var2;
         this.ll = this.lIll < 0 && var3;
         this.Ill = Math.max(this.Ill, lIlIl(-1802114444, -429449964));
      }
   }

   private void lIIl(class_310 var1, class_243 var2, double var3, boolean var5) {
      class_243 var6 = var1.field_1724.method_33571();
      double var7 = var2.field_1352 - var6.field_1352;
      double var9 = var2.field_1351 - var6.field_1351;
      double var11 = var2.field_1350 - var6.field_1350;
      double var13 = Math.hypot(var7, var11);
      if (var13 < 1.0E-4) {
         this.llII = 0L;
      } else {
         long var15 = System.nanoTime();
         float var17 = this.llII == 0L ? 0.008333334F : class_3532.method_15363((float)(var15 - this.llII) / 1.0E9F, 0.004166667F, 0.05F);
         this.llII = var15;
         float var18 = (float)(Math.toDegrees(Math.atan2(var11, var7)) - (double)90.0F);
         float var19 = (float)(-Math.toDegrees(Math.atan2(var9, var13)));
         float var20 = var1.field_1724.method_36454();
         float var21 = var1.field_1724.method_36455();
         float var22 = class_3532.method_15393(var18 - var20);
         float var23 = var19 - var21;
         float var24 = ((Double)this.IIIIl.III()).floatValue() / 100.0F;
         float var25 = (var5 ? 9.0F : (var3 > (double)12.0F ? 6.0F : 7.5F)) * var24;
         float var26 = (var5 ? 8.0F : 6.0F) * var24;
         float var27 = (var5 ? 150.0F : (var3 > (double)18.0F ? 100.0F : (var3 > (double)8.0F ? 125.0F : 145.0F))) * var24 * var17;
         float var28 = (var5 ? 110.0F : 85.0F) * var24 * var17;
         float var29 = class_3532.method_15363(var22 * (float)((double)1.0F - Math.exp((double)(-var25 * var17))), -var27, var27);
         float var30 = class_3532.method_15363(var23 * (float)((double)1.0F - Math.exp((double)(-var26 * var17))), -var28, var28);
         IllllIlI.IIIlIII(var1, var20 + (Math.abs(var22) < 0.03F ? var22 : var29), class_3532.method_15363(var21 + (Math.abs(var23) < 0.03F ? var23 : var30), -90.0F, 90.0F));
      }
   }

   public void lllIl(class_310 var1) {
      if (this.IlI && this.lllI(var1) && var1.field_1755 == null) {
         this.IIII(var1);
      }

   }

   private void llII() {
      this.lII = false;
      this.III = false;
      this.ll = false;
      this.lIl = false;
      this.IIlIl = false;
   }

   private boolean lllI(class_310 var1) {
      return var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1690 != null && var1.field_1761 != null;
   }

   private boolean IIIII(class_310 var1, class_1657 var2) {
      lIllIIl var3 = lIllIIl.Il();
      IIIllIlII var4 = var3 != null && var3.IIl() != null ? var3.IIl().llIlII() : null;
      return var4 != null && var4.IllllI(var1, var2);
   }

   private void IIIIl(class_310 var1, class_304 var2) {
      if (var2 != null) {
         var2.method_23481(IllllIlI.IIIll(var1, var2));
      }
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (!this.lllI(var1)) {
         this.llII();
         this.IIlll(var1);
         this.IlIll = null;
      } else {
         long var2 = System.nanoTime();
         if (!this.IlI) {
            if (var2 < this.IIllI) {
               return;
            }

            this.IlI = true;
            this.Il = var2 + 220000000L;
            this.IIlI = this.IlIII(var1);
         }

         if (var2 >= this.Il && this.IlIll(var1)) {
            this.IIIllIl(false);
         } else {
            int var4 = this.IlIII(var1);
            if (this.IIlI >= 0 && var4 != this.IIlI && !this.lI && !IllllIlI.IlllIl()) {
               this.IIIllIl(false);
            } else {
               this.IIlI = var4;
               if (var1.field_1755 == null && !var1.field_1724.method_29504()) {
                  if ((Boolean)this.IIlII.III() && this.IIll(var1)) {
                     this.llII();
                     this.IIII(var1);
                  } else if ((Boolean)this.Illl.III() && var1.field_1724.method_6115()) {
                     this.llII();
                     this.IIII(var1);
                  } else {
                     this.IlIll = this.lll(var1);
                     if (this.IlIll == null) {
                        this.llII();
                        this.IIII(var1);
                        this.Illll();
                     } else {
                        this.llI(var1, this.IlIll);
                        this.IIII(var1);
                     }
                  }
               } else {
                  this.llII();
                  this.IIlll(var1);
               }
            }
         }
      }
   }

   public int IlIlI() {
      return lIlIl(-1802114441, 480173986);
   }

   private boolean IIIll(class_310 var1, class_304 var2) {
      return var2 != null && IllllIlI.IIIll(var1, var2);
   }

   private int IIlII(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         for(int var2 = 0; var2 < lIlIl(-1802114442, -1961045522); ++var2) {
            if (var1.field_1724.method_31548().method_5438(var2).method_31574(class_1802.field_8407)) {
               return var2;
            }
         }

         return -1;
      } else {
         return -1;
      }
   }

   public void IIIlI(class_332 var1, int var2, int var3, float var4) {
      class_310 var5 = class_310.method_1551();
      if (var5 != null && var5.method_22683() != null) {
         this.lIlII(var5);
         double var6 = (double)var5.method_22683().method_4486() * (double)0.5F;
         double var8 = (double)var5.method_22683().method_4502() * (double)0.5F + (double)16.0F;
         IIIIIIllI.IIIllI(var1);

         try {
            IIIIIIllI.IlII(var1, var6, var8);
            IIIIIIllI.lllI(var1, 1.7, 1.7);
            IIIIIIllI.IlIIll(true, () -> IIIIIIllI.IIIlII(var1, var5.field_1772, this.llll(), (double)0.0F, (double)0.0F, -1));
         } finally {
            IIIIIIllI.lIIlIl(var1);
         }

      }
   }

   private boolean IIlIl(class_746 var1) {
      return var1.method_5805() && !var1.method_6115() && !var1.method_5715() && !var1.method_5799() && !var1.method_5869() && !var1.method_5771() && !var1.method_6101() && !var1.method_5765() && !var1.method_31549().field_7479 && (double)var1.method_7344().method_7586() >= (Double)this.IlII.III();
   }

   public void lI() {
      ++this.lll;
      this.IlI = false;
      this.IIllI = 0L;
      this.IlIll = null;
      this.lI = false;
      this.lIlI = false;
      this.llII();
      this.IIlll(class_310.method_1551());
      this.Illll();
   }

   private void IIllI(class_310 var1, class_304 var2, boolean var3) {
      if (var2 != null) {
         var2.method_23481(var3);
      }
   }

   private void IIlll(class_310 var1) {
      if (this.II && var1 != null && var1.field_1690 != null) {
         this.IIIIl(var1, var1.field_1690.field_1894);
         this.IIIIl(var1, var1.field_1690.field_1881);
         this.IIIIl(var1, var1.field_1690.field_1913);
         this.IIIIl(var1, var1.field_1690.field_1849);
         this.IIIIl(var1, var1.field_1690.field_1867);
         this.IIIIl(var1, var1.field_1690.field_1903);
         if (var1.field_1724 != null && !this.IIIll(var1, var1.field_1690.field_1867)) {
            var1.field_1724.method_5728(false);
         }

         this.II = false;
      }
   }

   private int IlIII(class_310 var1) {
      return var1 != null && var1.field_1724 != null ? IllllIlI.lIIlI(var1.field_1724.method_31548()) : -1;
   }

   private boolean IlIIl(class_1657 var1) {
      lIllIIl var2 = lIllIIl.Il();
      if (var2 != null && var2.IIl() != null) {
         for(IIIIIIIlI var4 : var2.IIl().IIIIlII()) {
            if (var4.IIIIIlI() && var4 instanceof IllIl) {
               IllIl var5 = (IllIl)var4;
               if (var5.II(var1)) {
                  return true;
               }
            }
         }

         return false;
      } else {
         return false;
      }
   }

   private boolean IlIll(class_310 var1) {
      if (var1 != null && var1.field_1690 != null) {
         if (!this.IIIll(var1, var1.field_1690.field_1894) && !this.IIIll(var1, var1.field_1690.field_1881) && !this.IIIll(var1, var1.field_1690.field_1913) && !this.IIIll(var1, var1.field_1690.field_1849) && !this.IIIll(var1, var1.field_1690.field_1903) && !this.IIIll(var1, var1.field_1690.field_1832) && !this.IIIll(var1, var1.field_1690.field_1867) && !this.IIIll(var1, var1.field_1690.field_1886) && !this.IIIll(var1, var1.field_1690.field_1904)) {
            if (var1.field_1690.field_1852 != null) {
               for(class_304 var5 : var1.field_1690.field_1852) {
                  if (this.IIIll(var1, var5)) {
                     return true;
                  }
               }
            }

            return false;
         } else {
            return true;
         }
      } else {
         return false;
      }
   }

   private class_243 IlllI(class_1657 var1, double var2, boolean var4) {
      class_243 var5 = var1.method_5829().method_1005();
      class_243 var6 = new class_243(var5.field_1352, var1.method_5829().field_1322 + (double)var1.method_17682() * 0.62, var5.field_1350);
      if (!var4 && (Boolean)this.lIIl.III()) {
         class_243 var7 = var1.method_18798();
         double var8 = Math.hypot(var7.field_1352, var7.field_1350);
         if (Double.isFinite(var8) && !(var8 > 1.4)) {
            double var10 = class_3532.method_15350(var2 / (double)6.0F, 0.6, 3.2);
            return var6.method_1031(var7.field_1352 * var10, (double)0.0F, var7.field_1350 * var10);
         } else {
            return var6;
         }
      } else {
         return var6;
      }
   }

   private void Illll() {
      this.IlIII = false;
      this.llll = 0;
      this.Ill = 0;
      this.IlIIl = (double)0.0F;
      this.IIll = (double)0.0F;
      this.llII = 0L;
   }

   public void lIl() {
      ++this.lll;
      this.IlI = false;
      this.Il = 0L;
      this.IIllI = System.nanoTime() + Math.max(0L, Math.round((Double)this.lllI.III() * (double)1.0E9F));
      this.IlIll = null;
      this.Illll();
      this.lIlI = false;
      this.lI = false;
      this.IIlI = this.IlIII(class_310.method_1551());
      this.llII();
      this.II = false;
   }

   public void lIIII(double var1, double var3) {
      if (this.IIIIIlI() && !(Math.abs(var1) + Math.abs(var3) < 0.01) && this.IlI) {
         class_310 var5 = class_310.method_1551();
         if (this.lllI(var5) && var5.field_1755 == null && System.nanoTime() >= this.Il) {
            this.IIIllIl(false);
         }

      }
   }

   private void lIIIl(class_310 var1) {
      this.llll = 0;
      this.Ill = lIlIl(-1802114447, 338282568);
      boolean var2 = this.IlII(var1, 0.35, (double)1.0F);
      boolean var3 = this.IlII(var1, 0.35, (double)-1.0F);
      this.lIll = var2 != var3 ? (var2 ? 1 : -1) : -this.lIll;
   }

   private boolean lIIlI(class_310 var1, class_1657 var2, double var3) {
      return IIlIIIIl.llIIl(var1, var2) && !var2.method_31549().field_7477 && !var2.method_31481() && var1.field_1687.method_8469(var2.method_5628()) == var2 && (!(Boolean)this.IIIII.III() || var1.field_1724.method_6057(var2)) && var1.field_1724.method_5858(var2) <= var3 * var3;
   }

   public class_1657 lIIll(class_310 var1) {
      return this.IIIIIlI() && this.IlI && this.lllI(var1) ? this.lll(var1) : null;
   }

   private void lIlII(class_310 var1) {
      if (this.IlI && this.lllI(var1) && var1.field_1755 == null && this.IlIll != null && this.lIIlI(var1, this.IlIll, (Double)this.lIII.III()) && !this.IIIII(var1, this.IlIll)) {
         double var2 = Math.sqrt(var1.field_1724.method_5858(this.IlIll));
         boolean var4 = this.IlIIl(this.IlIll);
         boolean var5 = (Boolean)this.l.III() && var4 && var2 <= Math.min((double)3.0F, (Double)this.IIIll.III()) && var1.field_1724.method_6057(this.IlIll);
         this.lIIl(var1, this.IlllI(this.IlIll, var2, var4), var2, var5);
      } else {
         this.llII = 0L;
      }
   }

   private static int lIlIl(int var0, int var1) {
      return IllII[var0 ^ -1802114443] ^ var1 ^ var0;
   }

   static {
      short var6 = 26243;
      String var7 = "衤蠘蠈衘蠼觜衣衭蠒衙觧衢\uf05e\uf048\uf002\uf007\uf00d\uf1d3\uf045\uf1a0\uf1a7\uf1e2\uf1ff\uf1c5\uf1b9\uf1b2\uf1b3\uf001\uf1ea\uf025\uf1a0\uf05a\uf05f\uf1ff\uf014\uf1df\uf1bf\uf048\uf005\uf1f6\uf1f6\uf038\uf1ba\uf059\uf05d\uf015\uf1ff\uf1cf\uf1bf\uf1bf\uf047\uf1e2\uf007\uf020\uf01e\uf1a2\uf05d\uf1db\uf1ff\uf1d9\uf1ae\uf054\uf1af\uf1f4\uf1e8\uf1de\uf1a7\uf05a\uf004\uf050\uf003\uf1d9\uf01f\uf05c\uf05e\uf1f1\uf00b\uf030\uf1ba\uf1ae\uf05c\uf008\uf05e\uf1cc\uf1bd\uf1ba\uf007\uf1fa\uf1ea\uf1db\uf05d\uf1a2\uf1b1\uf1ee\uf014\uf1c0\uf046\uf1b2\uf056\uf1e7\uf1e8\uf1db\uf04d\uf1ad\uf1b3\uf051\uf01f\uf1c2\uf04b\uf04d\uf1a1\uf006\uf1f5\uf1d6\uf05a\uf1ba\uf004\uf05f\uf1e9\uf067ᔤᗙᔦᖘᕥᖼᗨᗖᗜᖙᖀᖴᗑᔻᗵᖠᖔᕗᗾᔥᔢᕮᖪᖐ䰳䳁䲂䳗簾\uf84e\uf85f\uf819粒類怜\uf840\uf84a\uf81d\uf824\uf83d\uf856領說什돸뎛댲덧飶頡颖颣颕飻飩飳颍飞顪飽预颓颚颮飂颜頺頪\udd8e\udde1\uddc0\udd95곋갿갿걳겜겤갪갵갶검걢걔갺갺갯겜걷격곳곣悫彰彛弙惾强悰彀彊弝弤弽彖悴悡惽榍槢槃榖ᴱᷦ᷍ᶃᵨᶬᴦᷖᷘᶎᵧᶻ᷀᷉ᷧᶐᶔᵚ᷎᷁ᴰᶐᶴᶁ敞暱攐故䉾䉲䈔䉝䈣䉵䉧䎯䈅䈢䏠䉳䈎䈅䉦䉑䉈䈂䈌䎠ѢֵЊќХѻ֪АЋѝњѷДֵѸтѓѿּѧѢъרג뒭뒡덇댎듰댦뒰뒴뒮듼댗댮던덖덂댎댗댗덐덇뒪댎댨댿덎뒹덺댯컝컖츬캁캁캻컗측츱칛캎칖츩츠캊칹칹칏츫츨컙칹컙컨㬴㯟㯶㮣훎훝혢홷횐홯혣혯혲홧횀훴혾혻혢횔홯훺훋혶횑횆회횥혪횚혳홿솏쇻쇫쇖쇖솒쇌쇴솅솦쇝솯쇸쇻솔솏娲嫟嫆媏婩婅娴嫉嫂婱媖婚嫇嫟娱媗媊婌嫅嫉娵媇媿媂ꌌꍱꍕꌩꌌꌆꌛꍭꍰꌡꍖꍠꍺ꒣ꍮꌠꌾꌉꍏꍔ䎵䉈䉬䈐䈱䈻䎲䉚䉉䈘䏫䈪矖矤矅瞐㬪㯇㬮㮖㭰㮶㬨㯑㬥㮇㮶㮡㯚㯗㯂㮉\ue971\ue913\ueaab\ue92e\ue92f\ue967\ue91b\ue914\ue900\ue95f\ue938\uead4\ue90d\ue913\ue91a\ue92a\ue942\ue908\ue902\ueaaa쾰치쾧쿮쿮츍쾮쾱칇쿲쿯츻칀치쾎츐츇쿊칎칚칪쿺츩츬칑친쾦츉츝츹칔쾷쾳츙쿫츬칔쾫쾭츒쿪쿎칋칋칬츍쿣츪칄칔칔츙츀츉칉쾱쾴츜쿽쿚쾻치칓쿭쿨츉쾲칉쾷츜쿨츻칑쾪쾱츒츇츤쾯칈칙쿾쿾츲칷쾢쾮쿩츝츊쾶칈칌츌쿭쿚쾫칢쾴츃츒쿖쾱칅쾥츀쿲츥쾯칔쾨츜츂츍칁쾵";
      char[] var8 = "暏曯暛暇暓暇暗暇暗暓暇暛暇暗暛暟暛暇暟暓暛暗暏暇暓暗曷".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IllIl = var9;
            IlllI = new Object[var9.length];
            int var2 = 1866959865;
            byte[] var0 = "þ\u0011y\\\u001dµ|\u009e\u0018³B4pÎ°hïû©Î".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IllII = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IllII[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 88;
                     break;
                  case 1:
                     var10000 = 72;
                     break;
                  case 2:
                     var10000 = 69;
                     break;
                  case 3:
                     var10000 = 16;
                     break;
                  case 4:
                     var10000 = 30;
                     break;
                  case 5:
                     var10000 = 36;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static String lIllI(int var0, short var1, int var2) {
      int var3 = var2 ^ '꿷';
      char[] var4 = IllIl[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])IlllI[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         IlllI[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 971;
      int var9 = 0;

      do {
         int var10 = var4[var9] ^ '뼔';
         var10 += 26485;
         var10 += 34550;
         var10 -= 12648;
         var10 += 5797;
         var10 += 2553;
         var10 ^= 42784;
         var4[var9] = (char)(var10 ^ var8 ^ var1 ^ var0 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
