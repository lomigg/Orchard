package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_3966;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_9304;
import net.minecraft.class_9334;
import net.minecraft.class_9362;

@Environment(EnvType.CLIENT)
public final class llIIIllI extends IIIIIIIlI {
   private int I = -1;
   private int l = IIlll(-1599611642, -443602265);
   private boolean II;
   private static final double Il = (double)6.0F;
   private static final int lI = 9;
   private long ll;
   private final IIIllIIII III = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IlIII('Ნ', -1821623513, 'ꭢ')), (double)0.0F, (double)0.0F, (double)500.0F, (double)5.0F)).IIIl(lIlIII.l(IlIII('틊', 148061844, 'ꭣ'))));
   private static final float IIl = 4.0F;
   private static final int IlI = 2;
   private class_1309 Ill;
   private static final int[] lII;
   private static final String[] lIl;
   private static final Object[] llI;

   public void IIllIll(class_1297 var1, int var2) {
      if (var2 == 0 || var2 == 3) {
         class_310 var3 = class_310.method_1551();
         if (this.IIlIl(var3) && this.IIII(var3, var1)) {
            if (this.llII(var3, var1)) {
               this.IIIll(var3, var1);
            }
         }
      }
   }

   private boolean IlI(class_310 var1, class_3966 var2) {
      return var1 != null && var1.field_1724 != null && this.Ill != null && var2 != null && var2.method_17782() == this.Ill && var2.method_17784() != null && var1.field_1724.method_33571().method_1022(var2.method_17784()) <= 3.0001;
   }

   public boolean llI() {
      return this.Ill != null;
   }

   private boolean lll(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         class_1799 var2 = var1.field_1724.method_6047();
         return var2 != null && !var2.method_7960() ? class_7923.field_41178.method_10221(var2.method_7909()).method_12832().endsWith(lIlIII.Il(IlIII('낔', -328186414, 'ꭦ'))) : false;
      } else {
         return false;
      }
   }

   private boolean IIII(class_310 var1, class_1297 var2) {
      boolean var10000;
      if (var1 != null && var2 != null) {
         class_239 var4 = var1.field_1765;
         if (var4 instanceof class_3966) {
            class_3966 var3 = (class_3966)var4;
            if (var3.method_17782() == var2) {
               var10000 = true;
               return var10000;
            }
         }
      }

      var10000 = false;
      return var10000;
   }

   private boolean IIll(class_1799 var1) {
      if (var1 != null && !var1.method_7960()) {
         class_9304 var2 = (class_9304)var1.method_58695(class_9334.field_49633, class_9304.field_49385);

         for(class_6880 var4 : var2.method_57534()) {
            if (var4 != null) {
               String var5 = (String)var4.method_40230().map((var0) -> var0.method_29177().method_12832()).orElse("");
               if (lIlIII.Il(IlIII('帤', 1470710809, 'ꭧ')).equals(var5) && var2.method_57536(var4) > 0) {
                  return true;
               }
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public llIIIllI() {
      super((Object)lIlIII.l(IlIII('꺈', -1042725330, 'ꭤ')), lIllII.I, (Object)lIlIII.l(IlIII('\udaa4', -1817484084, 'ꭥ')));
   }

   private class_3966 IlII(class_310 var1) {
      if (var1 != null && var1.field_1724 != null && this.Ill != null) {
         class_239 var4 = var1.field_1765;
         class_3966 var10000;
         if (var4 instanceof class_3966) {
            class_3966 var3 = (class_3966)var4;
            var10000 = var3;
         } else {
            var10000 = null;
         }

         class_3966 var2 = var10000;
         if (this.IlI(var1, var2)) {
            return var2;
         } else {
            class_3966 var5 = IllllIlI.IlIIllI(var1, (double)3.0F);
            if (this.IlI(var1, var5)) {
               return var5;
            } else {
               return IlIlIl.IIIlI(var1, this.Ill, (double)3.0F) ? new class_3966(this.Ill) : null;
            }
         }
      } else {
         return null;
      }
   }

   public boolean IlIl(class_310 var1, class_1309 var2) {
      if (this.IIIIIlI() && var2 != null) {
         if (this.Ill != null) {
            return this.Ill == var2;
         } else {
            return !this.llII(var1, var2) ? false : this.IIIll(var1, var2);
         }
      } else {
         return false;
      }
   }

   public boolean Illl(class_310 var1, class_1309 var2) {
      if (this.Ill != null) {
         return this.Ill == var2;
      } else {
         return !this.llII(var1, var2) ? false : this.IIIll(var1, var2);
      }
   }

   private boolean lIII(class_310 var1) {
      class_3966 var2 = this.IlII(var1);
      if (this.IIIIIlI() && this.Ill != null && var2 != null && var2.method_17782() == this.Ill) {
         if (IllllIlI.llI(var1, this.Ill)) {
            this.II = false;
            this.l = IIlll(-1599611641, 559070821);
            return false;
         } else {
            int var3 = this.I;
            boolean var4 = false;
            IllllIlI.IlIIlI(true);

            try {
               var4 = IllllIlI.llIll(var1, this, var3, () -> {
                  IllllIlI.lIlIl();

                  boolean var2x;
                  try {
                     IllllIlI.IlIIIll(var1);
                     var2x = IllllIlI.lllII(var1, var2);
                  } finally {
                     IllllIlI.IIlllI();
                  }

                  return var2x;
               });
            } finally {
               IllllIlI.IlIIlI(false);
               this.IIIIl(var1);
            }

            return var4;
         }
      } else {
         this.IIIIl(var1);
         return false;
      }
   }

   private boolean lIIl(class_1799 var1) {
      return var1 != null && !var1.method_7960() && var1.method_7909() instanceof class_9362 && this.IIll(var1);
   }

   private boolean llII(class_310 var1, class_1297 var2) {
      boolean var10000;
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var1.field_1755 == null && var1.field_1724.method_5805() && !var1.field_1724.method_6115() && var1.field_1724.field_6017 <= (double)4.0F && this.lll(var1) && !lIlIllll.lIIl(var1) && var2 instanceof class_1309 var3) {
         if (var3 != var1.field_1724 && var3.method_5805() && var3.method_5858(var1.field_1724) <= (double)36.0F) {
            var10000 = true;
            return var10000;
         }
      }

      var10000 = false;
      return var10000;
   }

   public void lI() {
      this.IIIIl(class_310.method_1551());
   }

   public int IlIlI() {
      return IIlll(-1599611644, 1426459984);
   }

   public void IllI(class_310 var1) {
      this.IIllI(var1);
   }

   public boolean IIIII(class_1309 var1) {
      return this.Ill != null && var1 != null && this.Ill == var1;
   }

   private void IIIIl(class_310 var1) {
      IllllIlI.IlII(var1, this, null.II);
      this.Ill = null;
      this.I = -1;
      this.II = false;
      this.l = IIlll(-1599611643, -1917742038);
      this.ll = 0L;
   }

   private boolean IIIll(class_310 var1, class_1297 var2) {
      if (this.Ill != null) {
         return this.Ill == var2;
      } else {
         int var3 = this.IIlII(var1);
         if (var3 < 0) {
            return false;
         } else {
            this.I = var3;
            this.Ill = (class_1309)var2;
            this.II = false;
            this.l = IIlll(-1599611646, -501471177);
            this.ll = System.currentTimeMillis() + Math.round(Math.max((double)0.0F, (Double)this.III.III()));
            return true;
         }
      }
   }

   private int IIlII(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         int var2 = IllllIlI.lIIlI(var1.field_1724.method_31548());
         if (var2 >= 0 && var2 < IIlll(-1599611645, 477597317) && this.lIIl(var1.field_1724.method_31548().method_5438(var2))) {
            return var2;
         } else {
            for(int var3 = 0; var3 < IIlll(-1599611648, 421363793); ++var3) {
               class_1799 var4 = var1.field_1724.method_31548().method_5438(var3);
               if (this.lIIl(var4)) {
                  return var3;
               }
            }

            return -1;
         }
      } else {
         return -1;
      }
   }

   private boolean IIlIl(class_310 var1) {
      return var1 != null && var1.field_1690 != null && var1.field_1690.field_1886 != null && (var1.field_1690.field_1886.method_1434() || IllllIlI.IllIlI(var1.field_1690.field_1886) > 0);
   }

   private void IIllI(class_310 var1) {
      if (this.Ill != null) {
         if (this.II) {
            if (var1 != null && var1.field_1724 != null && var1.field_1724.field_6012 <= this.l) {
               return;
            }

            this.II = false;
            this.l = IIlll(-1599611647, 300675660);
         }

         if (var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var1.field_1755 == null && this.Ill.method_5805() && var1.field_1687.method_8469(this.Ill.method_5628()) == this.Ill) {
            class_3966 var2 = this.IlII(var1);
            if (var2 == null) {
               this.IIIIl(var1);
            } else if (System.currentTimeMillis() >= this.ll) {
               float[] var3 = IlIlIl.llIlI(var1, var2.method_17784());
               if (var3 == null) {
                  this.IIIIl(var1);
               } else {
                  this.II = IlIlIl.IIIlll(var1, IIlll(-1599611634, 1463116348), var3[0], var3[1], () -> this.lIII(var1));
                  this.l = this.II ? var1.field_1724.field_6012 + 2 : IIlll(-1599611633, 424498582);
               }
            }
         } else {
            this.IIIIl(var1);
         }
      }
   }

   private static int IIlll(int var0, int var1) {
      return lII[var0 ^ -1599611642] ^ var1 ^ var0;
   }

   static {
      short var6 = 18932;
      String var7 = "얃엿얯칏츨얼얿칟룬룮롣뢛룯뢛룹롧謔謎譃譻謏譻謙謇譀謖謔譶諦諨诜诜䷒䶦䴁䴾䷔䷇䴭䴰䴭䴽䴰䴲䴼䶥䴹䴱䴁䷏䴯䴹䷖䶥䷚䴂䴭䴆䷐䴹䴰䴽䴾䶣䴎䷆䷎䴹䶧䴾䴐䴮䴎䷓䴑䴱䷛䴱䶢䶥䴰䴱䴹䴁䴃䷏䴓䴀䷚䴽䷔䷜䷇䴹䴀䴺䷙䴹䴭䴱䷖䴾䴎䴰䴲䷇䶢䴂䴭䴹䴆䴹䴽䴆䷝䴮䴌䷘䷒䴃䶧䶦䶠䷞䶧䴎䴲䴯䴎䷐䷎䶢䴰䶠䴬䶣櫶檒檆橡櫮檙檉檽\u20c5‸⃒—";
      char[] var8 = "䧼䧼䧤䦜䧼䧰".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            lIl = var9;
            llI = new Object[var9.length];
            int var2 = -216448958;
            byte[] var0 = "61·ãòì# \u0006¸\u009b\u008b^\u000f\tm1¢µwOÉ\u0013ÍJ£\u001d\u001aÂUo\u000f\u0004\u008bÿ\u008aÊóÈÛ".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lII = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lII[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static String IlIII(char var0, int var1, char var2) {
      int var3 = var2 ^ 'ꭦ';
      char[] var4 = lIl[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])llI[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         llI[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 6589;
      int var9 = 0;

      do {
         int var10 = var4[var9] ^ 24034;
         var10 += 11539;
         var10 -= 2790;
         var10 += 18167;
         var10 += 21712;
         var10 ^= 19395;
         var10 ^= 16772;
         var10 -= 44059;
         var10 += 57027;
         var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
