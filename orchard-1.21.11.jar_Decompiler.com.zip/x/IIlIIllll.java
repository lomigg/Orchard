package x;

import com.mojang.authlib.GameProfile;
import java.lang.reflect.Field;
import java.util.UUID;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_640;

@Environment(EnvType.CLIENT)
public final class IIlIIllll {
   private static final <undefinedtype> I;
   private static Field l;
   private static final String[] II;
   private static final Object[] Il;

   public static class_2561 I(GameProfile var0, class_2561 var1) {
      return var1;
   }

   public static boolean l(Object var0) {
      if (var0 == null) {
         return false;
      } else {
         try {
            if (l == null || l.getDeclaringClass() != var0.getClass()) {
               l = var0.getClass().getDeclaredField(lIlIII.Il(lll(-596384710, -1702154784)));
               l.setAccessible(true);
            }

            Object var1 = l.get(var0);
            boolean var10000;
            if (var1 instanceof class_1657) {
               class_1657 var2 = (class_1657)var1;
               if (lII(var2.method_7334())) {
                  var10000 = true;
                  return var10000;
               }
            }

            var10000 = false;
            return var10000;
         } catch (Exception var3) {
            return false;
         }
      }
   }

   static void II() {
      l = null;
   }

   private static boolean Il() {
      lIllIIl var0 = lIllIIl.Il();
      if (var0 == null) {
         return false;
      } else {
         IIIIIl var1 = var0.IIl().IIlIlII();
         return var1 != null && var1.IIIIIlI();
      }
   }

   static {
      short var0 = 24771;
      String var1 = "\ue2f8\ue20b\ue2dd\ue2bb\ue2e3\ue22a\ue239\ue2fb诘謹讽讂诅謢譍识謸识诫许\udd1e\udded\udd3b\udd5d\udd05\uddcc\udddf\udd1d";
      char[] var2 = "惋惏惋".toCharArray();
      String[] var3 = new String[var2.length];
      byte var7 = -1;

      while(true) {
         int var4 = 0;
         int var5 = 0;
         int var6 = 0;
         if (var7 == 0) {
            II = var3;
            Il = new Object[var3.length];
            I = lIlIII.l(lll(-596384709, 2143058100));
            return;
         }

         do {
            var6 = var2[var4] ^ var0;
            char[] var8 = var1.substring(var5, var5 + var6).toCharArray();
            int var9 = 0;

            do {
               byte var10000;
               switch (var9 % 6) {
                  case 0:
                  default:
                     var10000 = 5;
                     break;
                  case 1:
                     var10000 = 58;
                     break;
                  case 2:
                     var10000 = 120;
                     break;
                  case 3:
                     var10000 = 107;
                     break;
                  case 4:
                     var10000 = 33;
                     break;
                  case 5:
                     var10000 = 107;
               }

               byte var10 = var10000;
               var8[var9] = (char)(var8[var9] ^ var10);
               ++var9;
            } while(var9 < var8.length);

            var3[var4] = (new String(var8)).intern();
            var5 += var6;
            ++var4;
         } while(var4 < var2.length);

         var7 = 0;
      }
   }

   private static boolean lI(UUID var0, class_1657 var1) {
      if (var1 == null) {
         return false;
      } else if (var0.equals(var1.method_5667())) {
         return true;
      } else {
         UUID var2 = IIIIlII.I(var1.method_7334());
         return var2 != null && var0.equals(var2);
      }
   }

   public static boolean ll(UUID var0) {
      if (var0 == null) {
         return false;
      } else {
         class_310 var1 = class_310.method_1551();
         if (var1.field_1724 != null && lI(var0, var1.field_1724) && lII(var1.field_1724.method_7334())) {
            return true;
         } else {
            if (var1.method_1562() != null) {
               class_640 var2 = var1.method_1562().method_2871(var0);
               if (var2 != null && lII(var2.method_2966())) {
                  return true;
               }
            }

            if (var1.field_1687 == null) {
               return false;
            } else {
               for(class_1657 var3 : var1.field_1687.method_18456()) {
                  if (lI(var0, var3) && lII(var3.method_7334())) {
                     return true;
                  }
               }

               return false;
            }
         }
      }
   }

   public static class_2561 III(class_1657 var0, class_2561 var1) {
      if (var0 == null) {
         return var1;
      } else {
         return lIl(var0) ? var1 : I(var0.method_7334(), var1);
      }
   }

   public static class_2561 IIl(Object var0, class_2561 var1) {
      if (var0 == null) {
         return var1;
      } else {
         try {
            if (l == null || l.getDeclaringClass() != var0.getClass()) {
               l = var0.getClass().getDeclaredField(lIlIII.Il(lll(-596384712, -1519643520)));
               l.setAccessible(true);
            }

            Object var2 = l.get(var0);
            if (var2 instanceof class_1657) {
               class_1657 var3 = (class_1657)var2;
               return lIl(var3) ? var1 : I(var3.method_7334(), var1);
            } else {
               return var1;
            }
         } catch (Exception var4) {
            return var1;
         }
      }
   }

   private static boolean IlI(GameProfile var0) {
      if (var0 != null && Il()) {
         class_310 var1 = class_310.method_1551();
         if (var1.field_1724 == null) {
            return false;
         } else {
            UUID var2 = IIIIlII.I(var0);
            return var2 != null && lI(var2, var1.field_1724);
         }
      } else {
         return false;
      }
   }

   private static boolean Ill(class_1657 var0) {
      class_310 var1 = class_310.method_1551();
      return var1.field_1724 != null && lI(var0.method_5667(), var1.field_1724);
   }

   private static boolean lII(GameProfile var0) {
      if (var0 == null) {
         return false;
      } else {
         String var1 = IIIIlII.II(var0);
         return I.lllI(var1);
      }
   }

   private IIlIIllll() {
   }

   private static boolean lIl(class_1657 var0) {
      return var0 != null && Il() && lI(var0.method_5667(), var0) && Ill(var0);
   }

   public static class_2561 llI(class_640 var0, class_2561 var1) {
      if (var0 == null) {
         return var1;
      } else {
         return IlI(var0.method_2966()) ? var1 : I(var0.method_2966(), var1);
      }
   }

   private static String lll(int var0, int var1) {
      int var3 = var0 ^ -596384710;
      char[] var4 = II[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])Il[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         Il[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 1345786219;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 122;
               break;
            case 1:
               var9 = 130;
               break;
            case 2:
               var9 = 60;
               break;
            case 3:
               var9 = 120;
               break;
            case 4:
               var9 = 71;
               break;
            case 5:
               var9 = 249;
               break;
            case 6:
               var9 = 228;
               break;
            case 7:
               var9 = 103;
               break;
            case 8:
               var9 = 234;
               break;
            case 9:
               var9 = 18;
               break;
            case 10:
               var9 = 63;
               break;
            case 11:
               var9 = 38;
               break;
            case 12:
               var9 = 108;
               break;
            case 13:
               var9 = 56;
               break;
            case 14:
               var9 = 235;
               break;
            case 15:
               var9 = 93;
               break;
            case 16:
               var9 = 140;
               break;
            case 17:
               var9 = 66;
               break;
            case 18:
               var9 = 186;
               break;
            case 19:
               var9 = 86;
               break;
            case 20:
               var9 = 24;
               break;
            case 21:
               var9 = 243;
               break;
            case 22:
               var9 = 136;
               break;
            case 23:
               var9 = 30;
               break;
            case 24:
               var9 = 226;
               break;
            case 25:
               var9 = 138;
               break;
            case 26:
               var9 = 205;
               break;
            case 27:
               var9 = 16;
               break;
            case 28:
               var9 = 30;
               break;
            case 29:
               var9 = 18;
               break;
            case 30:
               var9 = 117;
               break;
            case 31:
               var9 = 76;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
