package x;

import java.util.Locale;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class Ill {
   private static final <undefinedtype> I;
   private static final String[] l;
   private static final Object[] II;

   static {
      short var0 = 8459;
      String var1 = "훳휻휆휈훮훯훯휈훙훘휤휤뚃뗦뗪똚\uda55\uda8b\uda6f\uda89\udeec\udf08\udee4\udef3\udee5\uded6\udef0\udef8\ued7e\ued7f\ued38\ued1d팛팏틐팼酃郮鄧郣";
      char[] var2 = "ℇℏℏ℃ℏℏℏ".toCharArray();
      String[] var3 = new String[var2.length];
      byte var7 = -1;

      while(true) {
         int var4 = 0;
         int var5 = 0;
         int var6 = 0;
         if (var7 == 0) {
            l = var3;
            II = new Object[var3.length];
            I = l(System.getProperty(lIlIII.Il(ll(-1966584164, 35348, (short)32757)), ""));
            return;
         }

         do {
            var6 = var2[var4] ^ var0;
            var3[var4] = var1.substring(var5, var5 + var6);
            var5 += var6;
            ++var4;
         } while(var4 < var2.length);

         var7 = 0;
      }
   }

   private Ill() {
   }

   public static boolean I() {
      return I == null.Il;
   }

   private static <undefinedtype> l(String var0) {
      String var1 = var0 == null ? "" : var0.toLowerCase(Locale.ROOT);
      if (var1.contains(lIlIII.Il(ll(-2038475977, 35349, (short)'鰢')))) {
         return null.lI;
      } else if (!var1.contains(lIlIII.Il(ll(-569936227, 35350, (short)'뢒'))) && !var1.contains(lIlIII.Il(ll(-617150156, 35351, (short)10807)))) {
         return !var1.contains(lIlIII.Il(ll(-65648511, 35344, (short)2890))) && !var1.contains(lIlIII.Il(ll(1634225431, 35345, (short)3131))) && !var1.contains(lIlIII.Il(ll(-2040653238, 35346, (short)9540))) ? null.l : null.II;
      } else {
         return null.Il;
      }
   }

   public static boolean II() {
      return I == null.II;
   }

   public static <undefinedtype> Il() {
      return I;
   }

   public static boolean lI() {
      return I == null.lI;
   }

   private static String ll(int var0, int var1, short var2) {
      int var3 = var1 ^ '訔';
      char[] var4 = l[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])II[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         II[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 21243;
      int var9 = 0;

      do {
         int var10 = var4[var9] + 'ꉳ';
         var10 ^= 11651;
         var10 ^= 5296;
         var10 -= 23994;
         var10 -= 46478;
         var4[var9] = (char)(var10 ^ var8 ^ var2 ^ var0 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
