package x;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3966;

@Environment(EnvType.CLIENT)
public final class lIIlllll extends IIIIIIIlI {
   private final IIIllIIII I;
   private boolean l;
   private final lIIIIl II;
   private static final int Il = 12;
   private final IIIllIIII lI;
   private final lIIIIl ll;
   private int III;
   private final lIIIIl IIl;
   private final IlIIIlIlI<<undefinedtype>> IlI;
   private static final double Ill = (double)0.5F;
   private static String[] lII;
   private final IIIllIIII lIl;
   private final IIIllIIII llI;
   private int lll;
   private int IIII;
   private final IIIllIIII IIIl;
   private static final int IIlI = 4;
   private final lIIIIl IIll;
   private static final int[] IlII;
   private static final String[] IlIl;
   private static final Object[] IllI;

   public boolean ll() {
      return false;
   }

   private void IlI() {
      this.l = false;
      this.III = -1;
      this.IIII = IIIll(1044213061, -1330844300);
   }

   public void lI() {
      this.lll = 0;
      this.IlI();
   }

   private <undefinedtype> lII(class_310 var1, class_1297 var2, double var3, double var5) {
      int var7 = Math.max(1, (int)Math.floor((Double)this.llI.III() / (double)0.5F));
      int var8 = 0;
      double var9 = Double.POSITIVE_INFINITY;

      for(int var11 = 1; var11 <= var7; ++var11) {
         double var12 = (double)var11 * (double)0.5F;
         double var14 = var3 * var12;
         double var16 = var5 * var12;
         double var18 = var2.method_23317() + var14;
         double var20 = var2.method_23321() + var16;
         class_238 var22 = var2.method_5829().method_989(var14, (double)0.0F, var16);
         if (!var1.field_1687.method_8587(var2, var22)) {
            break;
         }

         if (this.lIIl(var1, var18, var2.method_23318(), var20)) {
            ++var8;
            var9 = Math.min(var9, var12);
         }
      }

      return var8 == 0 ? null : new Record(var8, var9) {
         private final double I;
         private final int l;

         public int I() {
            return this.l;
         }

         private {
            this.l = var1;
            this.I = var2;
         }

         private boolean l(Object var1) {
            return var1 == null || this.l > var1.l || this.l == var1.l && this.I < var1.I;
         }

         public double II() {
            return this.I;
         }
      };
   }

   private static String llI(char[] var0, long var1, int var3) {
      int var4 = IIIll(1044213060, -130212315) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IIIll(1044213063, -2078039095);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   public boolean lll(class_310 var1) {
      if (this.IIIIIlI() && var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var1.field_1755 == null) {
         if (this.l) {
            return true;
         } else {
            if (this.lll <= 0) {
               class_239 var3 = var1.field_1765;
               if (var3 instanceof class_3966) {
                  class_3966 var2 = (class_3966)var3;
                  class_1297 var7 = var2.method_17782();
                  if (var7 != null && var7.method_5805()) {
                     if (IllllIlI.IlIllIl(var1, var7)) {
                        IllllIlI.IlIlII(var1);
                        return true;
                     }

                     Float var4 = (Boolean)this.IIll.III() ? this.IIll(var1, var7) : null;
                     if ((Boolean)this.IIll.III() && var4 == null) {
                        return false;
                     }

                     <undefinedtype> var5 = this.IlIl(var1, var7, var4);
                     if (var5 == null) {
                        return false;
                     }

                     boolean var6 = IlIlIl.IIIlll(var1, IIIll(1044213062, -1944881422), var5.l(), var5.I(), () -> this.IIII(var1, var7));
                     if (!var6) {
                        return false;
                     }

                     this.l = true;
                     this.III = var7.method_5628();
                     this.IIII = var1.field_1724.field_6012 + 4;
                     return true;
                  }

                  return false;
               }
            }

            return false;
         }
      } else {
         return false;
      }
   }

   static {
      short var6 = 26253;
      String var7 = "\udb3f₀鴒觟˷뜴壽뉵缙㣶齮㊘密ჴ㍴ཌ寰ⲋ蠎짔롻랏솉\uecf5㎳汯⠏屮癶‿狜뻴⣴톭꯫ે甔踎娓翂䏽㗅쩃츮늛⡎ᲈ\ue699盡ऱ鳹怜㢣Ẉ\uf4d1阮\udb61龘紥㲒蛚燄鄣쫎◗\udeb7뻗ꂑ\uf482핏⁌鍶毦騦\u088fၖ짍딖由퀴ȋ芢ᣤ郷ꘄᜓ芪劉⥙⊗뢋㚤뉣줷\uf7d2쮓뷼ꚁ爔ﲋ嬩ꊗ䕰짶Ԫ籐휟鈺쟟뾙\ua8de翑毗㷖㸭\ue3db썊꿸팎\uef42니\uf843\ud9c2㫇\uf638础䚨䃛舾᷍\ueaaf泀\uef37圔먵ꢰ㰅쏤渘歕㤛䳞̇\ue88bꒈ枓鸋큹ጯ噙᭾蘄뼊왂㗌옾簄惡\ue1de砿\uf06a\ue644Ⰻ졏\ue3bcﶙꐅၼ\ue0a3灢氊ⶶﻨ\ue411䍠ﻵ\udb32⮏翈쯍\ud99cꜳ阏䌸ဵᎷ\ue6a9伥\ud829흣\ud8eb뚠떩Ô㉡淮⺜ᅖ\uddb4ऌꯌ斐倸ꥏ⸲\uf06e\uec91뼼狠ڪ⿲䕾Ԁ刼嫯ၻഽ靱뭐ﰕ㔑\uec44锾꽝붭⽳꽂퇲쓼锗\uf7da\uecca昙\udf81㬞떦\uf718⌢攨奡鉱\udd5aᖷ\uf1fa䨴쵵㕭홊ᝪ犡\uf728꽗ﳡ\ue90f\uf7e0\u1aae糵羊衵\uec80ⱸ箚䑳㈢\ueecd\ueded齇즴ﰖ㦎걆湏닷獌䷂飯橡싮劏⊓闒팗뽃喳糷䆎హ색ꅨ듣䠿学껯씰溄턈㻯쩃Ʀ\u2dd7䗸륂\uf503\u2fe8无뀤拱㧥\uf5a3\udfe9枪犻";
      char[] var8 = "暝暝曍暝暝暭暝暉暙暙暁暝暝暁暅暝暁".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IlIl = var9;
            IllI = new Object[var9.length];
            int var2 = -1561821454;
            byte[] var0 = "¬yþÃ/,@Å\u0018ö°\u0083\u0010ÆdÖ\u0084\u009eÑt\t|;ýi<#ÈKLÿ\b>¬K#äQ\u0084ô0ùI:\u0096\u008b\u0002\u0013«À©1\u001f±\u0089\u0018\u0083Ï2Ø,wFdad>\u001c¬µ\u008a?áÝ·\u0082vcè\r\u009dfõê\u0019É\u0092¾\u008eåG\u0081ôÑhJùOv\u0095=h Ù_Ø\\\u0099\u0098(v\u00136\u0096\u0084X\u0014\u0004ý²?iG^<5\u0091\u0087\r\u00021W\u001a·û9þ\u0097|])ß¯¾Ä}O\u0003Pbçú0?6ôá\u0014²oë&_\u0011vc=æ§¿Ëö¨\u0082\u008b ÝÐdöÂ¤ù\u001a".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IlII = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IlII[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            lII = new String[IIIll(1044213057, 407618262)];
            lIII();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private boolean IIII(class_310 var1, class_1297 var2) {
      if (this.IIIIIlI() && this.l && var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var2 != null && var2.method_5628() == this.III && var2.method_5805() && var1.field_1687.method_8469(var2.method_5628()) == var2) {
         if (IllllIlI.IlIllIl(var1, var2)) {
            this.IlI();
            IllllIlI.IlIlII(var1);
            return false;
         } else {
            var1.field_1761.method_2918(var1.field_1724, var2);
            var1.field_1724.method_6104(class_1268.field_5808);
            this.lll = ((Double)this.lIl.III()).intValue();
            this.IlI();
            return true;
         }
      } else {
         this.IlI();
         return false;
      }
   }

   public lIIlllll() {
      super((Object)lIlIII.l(lII[5]), lIllII.I, (Object)lIlIII.l(lII[2]));
      this.IlI = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(lII[IIIll(1044213056, -1784076218)]), <undefinedtype>.class, null.Il));
      this.IIIl = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(lII[IIIll(1044213059, -169267083)]), (double)0.0F, (double)-180.0F, (double)180.0F, (double)1.0F));
      this.lI = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(lII[3]), (double)0.0F, (double)-90.0F, (double)90.0F, (double)1.0F));
      this.lIl = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(lII[IIIll(1044213058, -677778254)]), (double)15.0F, (double)0.0F, (double)40.0F, (double)1.0F)).IIl(lIlIII.Il(lII[IIIll(1044213069, -1569105765)])));
      this.IIll = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lII[IIIll(1044213068, 2021955404)]), false));
      this.llI = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(lII[IIIll(1044213071, -1406379380)]), (double)5.0F, (double)1.0F, (double)8.0F, (double)0.25F));
      this.I = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(lII[0]), (double)4.0F, (double)2.0F, (double)12.0F, (double)1.0F));
      this.II = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lII[4]), true));
      this.IIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lII[1]), true));
      this.ll = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lII[IIIll(1044213070, 173937063)]), true));
      this.III = -1;
      this.IIII = IIIll(1044213065, -1223312758);
      this.IIIl.lIII(() -> this.IlI.III() == null.II);
      this.lI.lIII(() -> this.IlI.III() == null.II);
      IIIllIIII var10000 = this.llI;
      lIIIIl var10001 = this.IIll;
      Objects.requireNonNull(var10001);
      var10000.lIII(var10001::III);
      var10000 = this.I;
      var10001 = this.IIll;
      Objects.requireNonNull(var10001);
      var10000.lIII(var10001::III);
      lIIIIl var2 = this.II;
      var10001 = this.IIll;
      Objects.requireNonNull(var10001);
      var2.lIII(var10001::III);
      var2 = this.IIl;
      var10001 = this.IIll;
      Objects.requireNonNull(var10001);
      var2.lIII(var10001::III);
      var2 = this.ll;
      var10001 = this.IIll;
      Objects.requireNonNull(var10001);
      var2.lIII(var10001::III);
   }

   private Float IIll(class_310 var1, class_1297 var2) {
      <undefinedtype> var3 = null;
      double var4 = (double)0.0F;
      double var6 = (double)0.0F;

      for(int var8 = 0; var8 < IIIll(1044213064, -2090558802); ++var8) {
         double var9 = (Math.PI * 2D) * (double)var8 / (double)12.0F;
         double var11 = Math.cos(var9);
         double var13 = Math.sin(var9);
         <undefinedtype> var15 = this.lII(var1, var2, var11, var13);
         if (var15 != null && var15.l(var3)) {
            var3 = var15;
            var4 = var11;
            var6 = var13;
         }
      }

      if (var3 == null) {
         return null;
      } else {
         return (float)Math.toDegrees(Math.atan2(-var4, var6));
      }
   }

   private <undefinedtype> IlIl(class_310 var1, class_1297 var2, Float var3) {
      double var4 = var2.method_23317() - var1.field_1724.method_23317();
      double var6 = var2.method_23321() - var1.field_1724.method_23321();
      float var8 = (float)(Math.toDegrees(Math.atan2(var6, var4)) - (double)90.0F);
      float var9;
      float var10;
      switch (((<undefinedtype>)this.IlI.III()).ordinal()) {
         case 0:
            var9 = var8 - 90.0F;
            var10 = var1.field_1724.method_36455();
            break;
         case 1:
            var9 = var8 + 90.0F;
            var10 = var1.field_1724.method_36455();
            break;
         case 2:
            var9 = var8;
            var10 = -70.0F;
            break;
         case 3:
            var9 = var8;
            var10 = var1.field_1724.method_36455();
            break;
         case 4:
            var9 = var8 + 180.0F;
            var10 = var1.field_1724.method_36455();
            break;
         case 5:
            var9 = var1.field_1724.method_36454() + ((Double)this.IIIl.III()).floatValue();
            var10 = var1.field_1724.method_36455() + ((Double)this.lI.III()).floatValue();
            break;
         default:
            return null;
      }

      if (var3 != null) {
         var9 = var3;
         var10 = var1.field_1724.method_36455();
      }

      float var11 = this.IIIIl(var1);
      var9 = (float)Math.round(var9 / var11) * var11;
      var10 = (float)Math.round(var10 / var11) * var11;
      return new Record(class_3532.method_15393(var9), class_3532.method_15363(var10, -90.0F, 90.0F)) {
         private final float I;
         private final float l;

         private {
            this.I = var1;
            this.l = var2;
         }

         public float I() {
            return this.l;
         }

         public float l() {
            return this.I;
         }
      };
   }

   private static void lIII() {
      lII[0] = llI(IIlII('\ue072', 237974171, 40984).toCharArray(), 31803L, IIIll(1044213067, 72224596));
      lII[1] = llI(IIlII('\ue073', -160926079, 61776).toCharArray(), 32257L, IIIll(1044213066, -1221563254));
      lII[2] = llI(IIlII('\ue070', 1850959015, 59680).toCharArray(), 67231L, IIIll(1044213077, 1905313351));
      lII[3] = llI(IIlII('\ue071', 346438056, 2132).toCharArray(), 52432L, IIIll(1044213076, 1240449354));
      lII[4] = llI(IIlII('\ue076', 2070370645, 32028).toCharArray(), 62937L, IIIll(1044213079, 1924090172));
      lII[5] = llI(IIlII('\ue077', 1275010481, 31800).toCharArray(), 44534L, IIIll(1044213078, -1986112359));
      lII[IIIll(1044213073, 28567119)] = llI(IIlII('\ue074', 429221484, 15852).toCharArray(), 73762L, IIIll(1044213072, 1520750278));
      lII[IIIll(1044213075, 305157159)] = llI(IIlII('\ue075', -238520496, 17665).toCharArray(), 29020L, IIIll(1044213074, 1398699923));
      lII[IIIll(1044213085, 1704617266)] = llI(IIlII('\ue07a', 163870987, 37084).toCharArray(), 69427L, IIIll(1044213084, 1440424341));
      lII[IIIll(1044213087, -1022537923)] = llI(IIlII('\ue07b', -2094324718, 36826).toCharArray(), 81534L, IIIll(1044213086, -1223988142));
      lII[IIIll(1044213081, -1438410759)] = llI(IIlII('\ue078', -1824041163, 59577).toCharArray(), 86253L, IIIll(1044213080, -1580287701));
      lII[IIIll(1044213083, -1547938564)] = llI(IIlII('\ue079', 1747745866, 17448).toCharArray(), 19385L, IIIll(1044213082, -1038535224));
      lII[IIIll(1044213093, -1848171828)] = llI(IIlII('\ue07e', 2137223438, 24721).toCharArray(), 79448L, IIIll(1044213092, -1362039218));
      lII[IIIll(1044213095, 1648521157)] = llI(IIlII('\ue07f', 1860059343, 23773).toCharArray(), 88356L, IIIll(1044213094, 1608023301));
      lII[IIIll(1044213089, 1487428766)] = llI(IIlII('\ue07c', 96931910, 37764).toCharArray(), 92041L, IIIll(1044213088, -267580524));
      lII[IIIll(1044213091, -1393941142)] = llI(IIlII('\ue07d', -663812769, 24608).toCharArray(), 996L, IIIll(1044213090, -1153781412));
      lII[IIIll(1044213101, 2012433566)] = llI(IIlII('\ue062', 574697765, 51262).toCharArray(), 91260L, IIIll(1044213100, 665623421));
   }

   private boolean lIIl(class_310 var1, double var2, double var4, double var6) {
      if ((Boolean)this.II.III() && this.lllI(var1.field_1687, var2, var4, var6)) {
         return true;
      } else {
         int var8 = class_3532.method_15357(var2);
         int var9 = class_3532.method_15357(var6);
         int var10 = class_3532.method_15357(var4 + (double)1.0F);
         int var11 = Math.max(var1.field_1687.method_31607(), class_3532.method_15357(var4) - 1);
         class_2338.class_2339 var12 = new class_2338.class_2339();

         for(int var13 = var10; var13 >= var11; --var13) {
            var12.method_10103(var8, var13, var9);
            class_2680 var14 = var1.field_1687.method_8320(var12);
            if ((Boolean)this.IIl.III() && var14.method_27852(class_2246.field_10164)) {
               return true;
            }

            if ((Boolean)this.ll.III() && var14.method_27852(class_2246.field_10343)) {
               return true;
            }

            if (!var14.method_26220(var1.field_1687, var12).method_1110()) {
               return false;
            }
         }

         return false;
      }
   }

   public Map<String, Object> llII() {
      LinkedHashMap var1 = new LinkedHashMap();
      var1.put(lIlIII.Il(lII[IIIll(1044213103, 996857979)]), this.IIIIIlI());
      var1.put(lIlIII.Il(lII[IIIll(1044213102, 878155826)]), ((<undefinedtype>)this.IlI.III()).toString());
      var1.put(lIlIII.Il(lII[IIIll(1044213097, 1090877282)]), this.IIll.III());
      var1.put(lIlIII.Il(lII[IIIll(1044213096, 1584523917)]), this.lll);
      return var1;
   }

   private boolean lllI(class_1937 var1, double var2, double var4, double var6) {
      int var8 = class_3532.method_15357(var2);
      int var9 = class_3532.method_15357(var6);
      int var10 = class_3532.method_15357(var4) - 1;
      int var11 = ((Double)this.I.III()).intValue();
      class_2338.class_2339 var12 = new class_2338.class_2339();

      for(int var13 = 0; var13 < var11; ++var13) {
         int var14 = var10 - var13;
         if (var14 >= var1.method_31607()) {
            var12.method_10103(var8, var14, var9);
            class_2680 var15 = var1.method_8320(var12);
            if (!var15.method_26220(var1, var12).method_1110()) {
               return false;
            }
         }
      }

      return true;
   }

   private float IIIIl(class_310 var1) {
      double var2 = (Double)var1.field_1690.method_42495().method_41753();
      double var4 = var2 * 0.6 + 0.2;
      float var6 = (float)(var4 * var4 * var4 * 1.2);
      return var6 < 0.001F ? 0.15F : var6;
   }

   public void Ill() {
      if (this.lll > 0) {
         --this.lll;
      }

      class_310 var1 = class_310.method_1551();
      if (this.l && (var1.field_1724 == null || var1.field_1724.field_6012 > this.IIII)) {
         this.IlI();
      }

   }

   private static int IIIll(int var0, int var1) {
      return IlII[var0 ^ 1044213061] ^ var1 ^ var0;
   }

   private static String IIlII(char var0, int var1, int var2) {
      int var3 = var0 ^ '\ue072';
      char[] var4 = IlIl[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])IllI[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         IllI[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 2065;
      int var9 = 0;

      do {
         int var10 = var4[var9] - 7395;
         var10 += 36275;
         var10 ^= 39795;
         var10 ^= 21351;
         var10 ^= 16886;
         var10 += 56480;
         var10 -= 33512;
         var10 -= 6712;
         var10 += 32417;
         var10 -= 47195;
         var4[var9] = (char)(var10 ^ var8 ^ var2 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
