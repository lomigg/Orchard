package x;

import java.awt.Color;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;

@Environment(EnvType.CLIENT)
public final class lIIIllII extends IIIIIIIlI {
   private static final double I = 0.9;
   private static final float l = 1000.0F;
   private static final class_2960 II;
   private final IlIIIlIlI<<undefinedtype>> Il;
   private final lIIIIl lI;
   private static String[] ll;
   private static final <undefinedtype> III;
   private final lIIIIl IIl;
   private final IIIllIIII IlI;
   private final lIIIIl Ill;
   private final Map<Long, Double> lII;
   private static final class_2960 lIl;
   private static final class_2960 llI;
   private static final double lll = 1.14;
   private static final double IIII = 0.28;
   private long IIIl;
   private static final int[] IIlI;
   private static final String[] IIll;
   private static final Object[] IlII;

   private void II(class_332 var1, class_327 var2, String var3, double var4, double var6, int var8, double var9) {
      if (var3 != null && !var3.isBlank()) {
         if (Math.abs(var9 - (double)1.0F) < 0.001) {
            IIIIIIllI.llIl(var1, var2, var3, var4, var6, var8);
         } else {
            IIIIIIllI.IIIllI(var1);
            IIIIIIllI.IlII(var1, var4, var6);
            IIIIIIllI.lllI(var1, var9, var9);
            IIIIIIllI.llIl(var1, var2, var3, (double)0.0F, (double)0.0F, var8);
            IIIIIIllI.lIIlIl(var1);
         }
      }
   }

   public <undefinedtype> IlI() {
      return (<undefinedtype>)this.Il.III();
   }

   private double lII(double var1) {
      return IIIIlI.IIl(var1);
   }

   private double llI(Object var1, long var2, long var4) {
      return this.lII((double)(var1.IIl() - var2) / (double)var4);
   }

   private double lll(double var1) {
      return Math.max((double)0.0F, Math.min((double)1.0F, var1));
   }

   private double IIII(class_327 var1, String var2, double var3) {
      return (double)IIIIIIllI.IlIl(var1, var2 == null ? ll[0] : var2) * var3;
   }

   private double IIll(Object var1, long var2) {
      return this.lll((double)(var1.IIl() - var2) / (double)Math.max(1L, var1.I()));
   }

   private static String IlII(char[] var0, long var1, int var3) {
      int var4 = llIIl(-2063039286, -1768552450) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & llIIl(-2063039285, -54769794);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   public long IlIl() {
      return Math.max(250L, Math.round((Double)this.IlI.III() * (double)1000.0F));
   }

   static {
      short var6 = 2722;
      String var7 = "嫄鬯㫱桱ᬳ䌧䖀嫹䡴᧟\uead6布윆ꇩ烠\ue5fc\ud9d8㞝嗺☙㈤ꭔ嘒ゴᦏ′㞛굨뜂騻蹗젟夈⸵碬篗㵃᭕⍂ᓲ⦙ಚ깺\ue2be䍘˽슷䮩빃泌䥷뻵訾榢ᣗ\udd56ﭏ䂂갛趶\ueba2ꤖ㷳醡磩\ue7f2᭦㔁㿨穏\ufbca纆┐樉넵覾ᶲ됟ﬗට씩ਃ\uf5acଜ◰䔐丅煣肣뼹ರ궆呈₅ꭩ║占핛⭗⍊ņ嚉㞡ྪ篼퍚\ue7e9\udd59섑䂷韀白碝긼鵮颓紑ཌᔳ䟱Ǵ풐ଢ଼ꈒ瀶妷밂縎良ﬀᾑ㼾榽\uddec瀩\ueec9뫵䓐方耍賎辊栲扴㞒翀獃뮀ㄻዿ䰑⡱䬚♅퀀햌耞\ue5a2⭽\ud9c4\u0a7c\ue02d繼鸹㰳籅⁺斮䨲⺒ūƀ⌶곧⎒\uef19ⷢ⼛ޓ嶱⤝\uab2f邦ᕚ鬤銿𢡊䨔眚ᬭ熋\uf560䩷\udeff璞䚲됉\ueca0㕘窦줧劲뱛ת㛸ﰱ瀲쬨䔃崊쀐띷䝟\ue798㒇隠縡檻\udc6cជΉ魛\ud8ffᕞ⤪닱誧덱㸅銎瑱쵼侄䵵狯\u0ee5㑙\ue6f2晷яඉ敲傸䦌괔諸ឋ\ueccd儔ꌏ尤䴪뢅\ue28f㕻\uf38d棔㶶稭ᨖ㑫னᦤ᥄䮥ყ䑐颐鎅듄\ue505䔿钢灂국첨\udecb\ud880䣶兣칭ꦛ磝訨\ud909팬\ude0a娍堆똛㈻둀䷻娒⟉몗\ue3a4ꋈ唫쬀醰쵛ꕌ\udae7⣨틁偺⮲寊勑磊ᬩ궣坤療 \udc24畕钿\udceb쵄푰ਜ錧ﾱ谘缩鑤";
      char[] var8 = "દદદદ\u0abaલદલચશપલશપઊ\u0a8eઊ".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IIll = var9;
            IlII = new Object[var9.length];
            int var2 = -473177029;
            byte[] var0 = "\u008f(a\f\u009a\u007f'qóbËïî\u009f\r½¤\u0086³!Øä\u009e¥|\u0011Ó\u008cr\u008eJ=ìñÃ/è\u0001]¾\u0082|@\u00adâ ôBºd\u000b<T»\u0007W¥¸\u0090\u000e¦\u0089\u0093H\u001dá\t\u007f¯\u008dYznM\u001fù\u0091Æ¨$ó> *Å¸W^®4\u0096ÅïÒs>\u009a\u0003\u0005óÁ\u0006¾XÈc\u0017\u007fQF6ÇàÅò?|\u000e_7Z\u0083\u0000¡T úÑ\u0015á\u009bä\tÕ/×\u001aÃ¡\u0088PU¼k\u0096Óª®²Dl\f\u0092®\u0089_\u0095¾«\u0082é\u0019ÔÏ\u00076¸õÚ)Ñ4g\fçV\\Lg\u008aâ\u0011 \t\u0017Y\u0001`\u0013'[ý\u0001\u0010Ó\u0098\u0018\u009a=\u001eò\b\u0000?[wÈ\u0016<e\u001aÇ".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IIlI = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IIlI[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            ll = new String[llIIl(-2063039288, -1784567026)];
            llII();
            III = null.III;
            lIl = class_2960.method_60655(lIlIII.Il(ll[llIIl(-2063039287, -2007208639)]), lIlIII.Il(ll[llIIl(-2063039282, -1035611195)]));
            II = class_2960.method_60655(lIlIII.Il(ll[llIIl(-2063039281, -1104675233)]), lIlIII.Il(ll[llIIl(-2063039284, 450016116)]));
            llI = class_2960.method_60655(lIlIII.Il(ll[llIIl(-2063039283, 340601541)]), lIlIII.Il(ll[llIIl(-2063039294, -1976392762)]));
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private double Illl(long var1, double var3, double var5, double var7) {
      Double var9 = (Double)this.lII.get(var1);
      if (var9 == null) {
         double var10 = (double)18.0F * ((double)1.0F - var5);
         var9 = var3 + var10;
      }

      double var12 = class_3532.method_16436(class_3532.method_15350(var7, (double)0.0F, (double)1.0F), var9, var3);
      this.lII.put(var1, var12);
      return var12;
   }

   private double lIII(Object var1, long var2, long var4) {
      double var6 = this.IllIl(var1, var2, var4);
      double var8 = this.llI(var1, var2, var4);
      return (0.9 + 0.1 * var6) * (0.96 + 0.04 * var8);
   }

   private double lIIl(class_327 var1, double var2) {
      Objects.requireNonNull(var1);
      return (double)9.0F * var2;
   }

   private void lIll(class_332 var1, class_327 var2, Object var3, Object var4, double var5, double var7, double var9) {
      double var11 = var4.I() * var9 <= (double)6.0F ? (double)0.0F : var4.I() * var9;
      if (!(var11 <= (double)0.0F)) {
         double var13 = var7 + var4.I() - var11;
         int var15 = IIIlllIII.lI(llIIl(-2063039293, -1908555079), (int)Math.round((double)255.0F * Math.max((double)0.0F, var9 - (double)0.5F)));
         this.IlIIl(var1, var5, var13, var4.l(), var11, var9);
         if ((var15 >>> llIIl(-2063039296, -457236402) & llIIl(-2063039295, -2065460153)) > 0) {
            IIIIIIllI.lIl(var1, var2, this.IIlIl(var3), var5, var13, var4.l(), var11, var15);
         }

      }
   }

   private static void llII() {
      ll[0] = IlII("".toCharArray(), 79822L, llIIl(-2063039290, 994010995));
      ll[1] = IlII(llIlI(1456490298, (short)'텀', '䞭').toCharArray(), 61533L, llIIl(-2063039289, -1846496807));
      ll[2] = IlII(llIlI(1894600521, (short)29849, '䞬').toCharArray(), 14522L, llIIl(-2063039292, -1169422918));
      ll[3] = IlII(llIlI(1589400123, (short)2750, '䞯').toCharArray(), 4768L, llIIl(-2063039291, 673413549));
      ll[4] = IlII(llIlI(-1882566935, (short)'쾓', '䞮').toCharArray(), 14071L, llIIl(-2063039270, -1514445993));
      ll[5] = IlII(llIlI(433856124, (short)'讯', '䞩').toCharArray(), 90499L, llIIl(-2063039269, -2008144320));
      ll[llIIl(-2063039272, 143556380)] = IlII(llIlI(-2050982949, (short)'돗', '䞨').toCharArray(), 80635L, llIIl(-2063039271, -1159552313));
      ll[llIIl(-2063039266, -1778532152)] = IlII(llIlI(-983359377, (short)'\ud950', '䞫').toCharArray(), 17758L, llIIl(-2063039265, 1934685679));
      ll[llIIl(-2063039268, -923273686)] = IlII(llIlI(-1700454337, (short)18218, '䞪').toCharArray(), 1681L, llIIl(-2063039267, 1807562389));
      ll[llIIl(-2063039278, -54500077)] = IlII(llIlI(-431944561, (short)'먾', '䞥').toCharArray(), 66000L, llIIl(-2063039277, -387357876));
      ll[llIIl(-2063039280, -1365215330)] = IlII(llIlI(-869715488, (short)25485, '䞤').toCharArray(), 72473L, llIIl(-2063039279, 2144021503));
      ll[llIIl(-2063039274, -2046389543)] = IlII(llIlI(-1954131976, (short)'腳', '䞧').toCharArray(), 31206L, llIIl(-2063039273, 1694262819));
      ll[llIIl(-2063039276, 1010851906)] = IlII(llIlI(-1365751987, (short)'뒙', '䞦').toCharArray(), 8594L, llIIl(-2063039275, -1961085203));
      ll[llIIl(-2063039254, 1931672376)] = IlII(llIlI(-1757924267, (short)11015, '䞡').toCharArray(), 80666L, llIIl(-2063039253, 873857965));
      ll[llIIl(-2063039256, 2080424277)] = IlII(llIlI(-844151350, (short)24012, '䞠').toCharArray(), 9198L, llIIl(-2063039255, -1848434233));
      ll[llIIl(-2063039250, -267335052)] = IlII(llIlI(938880215, (short)26419, '䞣').toCharArray(), 78960L, llIIl(-2063039249, 873637697));
      ll[llIIl(-2063039252, -194123368)] = IlII(llIlI(-600163063, (short)'\uf69a', '䞢').toCharArray(), 90515L, llIIl(-2063039251, -1416396207));
      ll[llIIl(-2063039262, -1881492473)] = IlII(llIlI(-1175647440, (short)'불', '䞽').toCharArray(), 96959L, llIIl(-2063039261, -791164177));
   }

   public void lI() {
      IIlllIlI.II().lI();
      this.lII.clear();
      this.IIIl = 0L;
   }

   private void IIIII(class_332 var1, class_310 var2, List<<undefinedtype>> var3) {
      IIIlIlIIl.lIlII(var1);
      IIIlIlIIl.I(var1, (double)0.0F, (double)0.0F, (double)1000.0F);
      <undefinedtype> var4 = (<undefinedtype>)this.Il.III();
      if (var4 != null.l) {
         long var5 = System.currentTimeMillis();
         double var7 = this.llIII(var5);
         double var9 = (double)0.0F;
         int var11 = var2.method_22683().method_4486();
         int var12 = var2.method_22683().method_4502();
         HashSet var13 = new HashSet();

         try {
            for(<undefinedtype> var15 : var3) {
               double var16 = this.IIlll(var15, var5, var4.II());
               if (!(var16 <= 0.01)) {
                  long var18 = this.lIlII(var15);
                  var13.add(var18);
                  <undefinedtype> var20 = this.lIllI(var2.field_1772, var15, var4, var11);
                  double var21 = this.IllIl(var15, var5, var4.II());
                  double var23 = (double)var12 - (var9 + (double)18.0F + var20.I());
                  double var25 = this.Illl(var18, var23, var16, var7);
                  double var29 = this.lIII(var15, var5, var4.II());
                  switch (var4.ordinal()) {
                     case 0:
                        double var36 = (double)var11 - var20.l() - (double)5.0F + ((double)1.0F - var21) * (double)34.0F;
                        this.lIIII(var1, var36, var25, var20, var29, () -> IIIIIIllI.IlIIll(true, () -> this.IlIll(var1, var2.field_1772, var15, var20, var36, var25, var16)));
                        break;
                     case 1:
                        double var27 = (double)var11 - var20.l() - (double)5.0F + ((double)1.0F - var21) * (double)20.0F;
                        this.lIIII(var1, var27, var25, var20, var29, () -> IIIIIIllI.IlIIll(true, () -> this.lIll(var1, var2.field_1772, var15, var20, var27, var25, var16)));
                        break;
                     default:
                        String var10002 = lIlIII.Il(ll[5]);
                        String var33 = String.valueOf(var4);
                        String var32 = var10002;
                        throw new IllegalStateException(var32 + var33);
                  }

                  var9 += var20.I() + var4.l();
               }
            }

            this.lII.keySet().removeIf((var1x) -> !var13.contains(var1x));
         } finally {
            IIIlIlIIl.IlIlI(var1);
         }

      }
   }

   private double IIIIl(double var1) {
      return IIIIlI.l(var1);
   }

   public boolean IIIll() {
      return (Boolean)this.Ill.III();
   }

   private void IIlII(class_332 var1, class_327 var2, Object var3, Object var4, double var5, double var7, long var9, boolean var11) {
      Color var12 = this.lIlIl(var3);
      int var13 = var12.getRGB();
      double var14 = (double)12.0F;
      double var16 = var5 + (double)3.0F;
      double var18 = var7 + (var4.I() - var14) / (double)2.0F;
      double var20 = var5 + (double)18.0F;
      double var22 = var4.l() * this.IIll(var3, var9);
      double var24 = var5 + var4.l() - var22;
      lllIIlI.lI(var1, III, var5, var7, var4.l(), var4.I(), false);
      this.IlllI(var1, var2, var3, var16, var18, var14, (double)1.0F);
      double var26 = var7 + (double)3.0F;
      double var28 = var7 + var4.I() - (double)3.0F - this.lIIl(var2, 0.9);
      this.II(var1, var2, var3.Il(), var20, var26, -1, 1.14);
      this.II(var1, var2, var3.III(), var20, var28, -1, 0.9);
      if (var11) {
         IIIIIIllI.IllIll(var1, var24, var7 + var4.I() - (double)1.0F, var22, (double)1.0F, (double)1.0F, var13);
      } else {
         IIIIIIllI.IIIIll(var1, var24, var7 + var4.I() - (double)1.0F, var5 + var4.l(), var7 + var4.I(), var13);
      }

   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (var1.field_1724 == null || var1.field_1687 == null) {
         IIlllIlI.II().lI();
      }

   }

   private String IIlIl(Object var1) {
      String var2 = var1.Il();
      String var3 = var1.III();
      if (var3 != null && !var3.isBlank()) {
         if (var2 != null && !var2.isBlank()) {
            String var5 = !var2.endsWith(lIlIII.Il(ll[3])) && !var2.endsWith(lIlIII.Il(ll[1])) ? lIlIII.Il(ll[4]) : lIlIII.Il(ll[2]);
            return var2 + var5 + var3;
         } else {
            return var3;
         }
      } else {
         return var2 == null ? ll[0] : var2;
      }
   }

   private void IIllI(class_332 var1, class_327 var2, String var3, double var4, double var6, double var8, int var10) {
      if (var3 != null && !var3.isBlank() && !(var8 <= (double)0.0F)) {
         IIIIIIllI.llIl(var1, var2, IIIIIIllI.lIlIlI(var2, var3, var8), var4, var6, var10);
      }
   }

   private double IIlll(Object var1, long var2, long var4) {
      double var6 = this.IllIl(var1, var2, var4);
      double var8 = this.llI(var1, var2, var4);
      return Math.min(var6, var8);
   }

   private void IlIIl(class_332 var1, double var2, double var4, double var6, double var8, double var10) {
      lllIIlI.II(var1, III, var2, var4, var6, var8, false, var10);
   }

   private void IlIll(class_332 var1, class_327 var2, Object var3, Object var4, double var5, double var7, double var9) {
      int var11 = lIlIIIIl.IIlI(lllIIlI.Illl(llIIl(-2063039264, -1125469931)), var9);
      int var12 = lIlIIIIl.IIlI(lllIIlI.IlII(llIIl(-2063039263, 30377822)), var9);
      int var13 = lIlIIIIl.IIlI(lllIIlI.Illl(llIIl(-2063039258, 982452141)), var9);
      double var14 = var5 + (double)29.0F;
      lllIIlI.II(var1, III, var5, var7, var4.l(), var4.I(), false, var9);
      IIIIIIllI.IllllI(var1, llI, var5 + (double)10.0F, var7 + (var4.I() - (double)12.0F) * (double)0.5F, (double)12.0F, (double)12.0F, var13);
      String var16 = var3.III();
      if (!(Boolean)this.IIl.III() && var16 != null && !var16.isBlank()) {
         this.IIllI(var1, var2, var3.Il(), var14, var7 + (double)4.0F, var4.l() - (double)37.0F, var11);
         this.IIllI(var1, var2, var3.III(), var14, var7 + (double)17.0F, var4.l() - (double)37.0F, var12);
      } else {
         double var17 = this.lIIl(var2, 1.14);
         double var19 = this.IIII(var2, var3.Il(), 1.14);
         double var21 = Math.max((double)0.0F, var4.l() - (double)37.0F);
         double var23 = var14 + Math.max((double)0.0F, (var21 - var19) * (double)0.5F);
         double var25 = var7 + (var4.I() - var17) / (double)2.0F;
         if (var19 > var21) {
            this.IIllI(var1, var2, var3.Il(), var14, var25, var21, var11);
         } else {
            this.II(var1, var2, var3.Il(), var23, var25, var11, 1.14);
         }
      }
   }

   public void IIIlI(class_332 var1, int var2, int var3, float var4) {
      class_310 var5 = class_310.method_1551();
      if (var5.method_22683() != null && var5.field_1772 != null) {
         lIllIIl var6 = lIllIIl.Il();
         List var7 = IIlllIlI.II().l();
         if (!var7.isEmpty()) {
            this.IIIII(var1, var5, var7);
         }
      }
   }

   public boolean IllII() {
      return (Boolean)this.lI.III();
   }

   private double IllIl(Object var1, long var2, long var4) {
      return this.IIIIl((double)(var2 - var1.Ill()) / (double)var4);
   }

   private void IlllI(class_332 var1, class_327 var2, Object var3, double var4, double var6, double var8, double var10) {
      class_2960 var12 = this.lIlll(var3);
      int var13 = IIIlllIII.lI(this.lIlIl(var3).getRGB(), (int)Math.round((double)255.0F * var10));
      if (var12 != null) {
         IIIIIIllI.IIIlIl(var1, var12, var4, var6, var8, var8, var13);
      } else {
         IIIIIIllI.lIl(var1, var2, var3.ll().II(), var4 - (double)1.0F, var6 - (double)1.0F, var8 + (double)2.0F, var8 + (double)2.0F, var13);
      }
   }

   public lIIIllII(lIlllII var1) {
      super((Object)lIlIII.l(ll[llIIl(-2063039257, -2066595617)]), lIllII.IIl, (Object)lIlIII.l(ll[llIIl(-2063039260, 1905942966)]));
      this.Il = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(ll[llIIl(-2063039259, 1977891624)]), <undefinedtype>.class, null.ll));
      this.IIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(ll[llIIl(-2063039238, 1741927263)]), false));
      this.IlI = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(ll[llIIl(-2063039237, 2119785939)]), (double)2.0F, (double)1.0F, (double)10.0F, (double)0.5F)).IIl(lIlIII.Il(ll[llIIl(-2063039240, -1798610693)])));
      this.Ill = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(ll[llIIl(-2063039239, 1035249884)]), true));
      this.lI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(ll[llIIl(-2063039234, 1520859662)]), true));
      this.lII = new HashMap();
      this.IIl.lIII(() -> this.Il.III() == null.ll);
      this.Ill.lIII(() -> this.Il.III() != null.l);
      this.IIIllIl(true);
   }

   private void lIIII(class_332 var1, double var2, double var4, Object var6, double var7, Runnable var9) {
      double var10 = var2 + var6.l() * (double)0.5F;
      double var12 = var4 + var6.I() * (double)0.5F;
      IIIlIlIIl.lIlII(var1);

      try {
         IIIlIlIIl.IllIl(var1, var10, var12);
         IIIlIlIIl.Illl(var1, var7, var7);
         IIIlIlIIl.IllIl(var1, -var10, -var12);
         var9.run();
      } finally {
         IIIlIlIIl.IlIlI(var1);
      }

   }

   private long lIlII(Object var1) {
      return var1.lII();
   }

   private Color lIlIl(Object var1) {
      return var1.ll().Il();
   }

   private <undefinedtype> lIllI(class_327 var1, Object var2, Object var3, int var4) {
      double var5 = this.IIII(var1, var2.Il(), 1.14);
      double var7 = (double)IIIIIIllI.IlIl(var1, var2.Il() == null ? ll[0] : var2.Il());
      double var9 = (double)IIIIIIllI.IlIl(var1, var2.III() == null ? ll[0] : var2.III());
      double var11 = Math.max((double)136.0F, (double)var4 - (double)12.0F);
      Record var10000;
      switch (var3.ordinal()) {
         case 0 -> var10000 = (Boolean)this.IIl.III() ? new Record(Math.max((double)118.0F, Math.min(var11, var5 + (double)37.0F)), (double)30.0F) {
   private final double I;
   private final double l;

   public double I() {
      return this.l;
   }

   public double l() {
      return this.I;
   }

   private {
      this.I = var1;
      this.l = var3;
   }
} : new Record(Math.max((double)136.0F, Math.min(var11, Math.max(var7, var9) + (double)37.0F)), (double)30.0F) {
   private final double I;
   private final double l;

   public double I() {
      return this.l;
   }

   public double l() {
      return this.I;
   }

   private {
      this.I = var1;
      this.l = var3;
   }
};
         case 1 -> var10000 = new Record(Math.min(var11, (double)IIIIIIllI.IlIl(var1, this.IIlIl(var2)) + (double)8.0F), (double)16.0F) {
   private final double I;
   private final double l;

   public double I() {
      return this.l;
   }

   public double l() {
      return this.I;
   }

   private {
      this.I = var1;
      this.l = var3;
   }
};
         case 2 -> var10000 = new Record((double)0.0F, (double)0.0F) {
   private final double I;
   private final double l;

   public double I() {
      return this.l;
   }

   public double l() {
      return this.I;
   }

   private {
      this.I = var1;
      this.l = var3;
   }
};
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   private class_2960 lIlll(Object var1) {
      class_2960 var10000;
      switch (var1.ll()) {
         case ll -> var10000 = lIl;
         case II -> var10000 = II;
         default -> var10000 = null;
      }

      return var10000;
   }

   private double llIII(long var1) {
      if (this.IIIl == 0L) {
         this.IIIl = var1;
         return (double)1.0F;
      } else {
         long var3 = Math.max(1L, Math.min(80L, var1 - this.IIIl));
         this.IIIl = var1;
         return IIIIlI.ll(0.28, (double)var3 / (double)1000.0F);
      }
   }

   private static int llIIl(int var0, int var1) {
      return IIlI[var0 ^ -2063039286] ^ var1 ^ var0;
   }

   private static String llIlI(int var0, short var1, char var2) {
      int var3 = var2 ^ 18349;
      char[] var4 = IIll[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])IlII[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         IlII[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 30447;
      int var9 = 0;

      do {
         int var10 = var4[var9] + '헦';
         var10 ^= 17893;
         var10 -= 25730;
         var10 -= 53176;
         var4[var9] = (char)(var10 ^ var8 ^ var1 ^ var0 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
