package x;

import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1747;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_746;

@Environment(EnvType.CLIENT)
public final class IIlIll extends IIIIIIIlI {
   private final lIIIIl I;
   private int l;
   private boolean II;
   private static String[] Il;
   private final lIIIIl lI;
   private final llllIlIl ll;
   private boolean III;
   private final lIIIIl IIl;
   private final IIIllIIII IlI;
   private int Ill;
   private static final int[] lII;
   private static final String[] lIl;
   private static final Object[] llI;

   public boolean I(class_310 var1) {
      this.III = false;
      if (this.IIIIIlI() && var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1690 != null && var1.field_1724.method_5805()) {
         class_746 var2 = var1.field_1724;
         if ((Boolean)this.lI.III() && !this.lII(var2)) {
            this.II = false;
            this.l = 0;
            return false;
         } else {
            class_2338 var3 = class_2338.method_49637(var2.method_23317(), var2.method_23318() - (double)1.0F, var2.method_23321());
            boolean var4 = (Boolean)this.IIl.III() && !var2.method_24828();
            boolean var5 = (Boolean)this.I.III() && var1.field_1690.field_1894.method_1434();
            this.II = !var4 && !var5 && var1.field_1687.method_8320(var3).method_26215();
            if (this.II) {
               this.Ill = this.ll();
               ++this.l;
            } else {
               this.l = 0;
            }

            boolean var6 = this.Ill > 0;
            --this.Ill;
            this.III = this.Ill > 0 && this.l <= 2;
            return var6;
         }
      } else {
         this.III();
         return false;
      }
   }

   public boolean l(class_310 var1) {
      return false;
   }

   public boolean II(class_310 var1) {
      return this.IIIIIlI() && this.II;
   }

   private static void Il() {
      Il[0] = IlI(lll('ᚗ', -1870776466, 'Ɏ').toCharArray(), 19558L, llI(2086244351, -1191890009));
      Il[1] = IlI(lll('ּ', 1361911536, 'ɏ').toCharArray(), 18068L, llI(2086244350, -681364513));
      Il[2] = IlI(lll('掌', -607425267, 'Ɍ').toCharArray(), 57146L, llI(2086244349, 1536272336));
      Il[3] = IlI(lll('싄', 1924755634, 'ɍ').toCharArray(), 67864L, llI(2086244348, 1454394549));
      Il[4] = IlI(lll('⺴', -2104400643, 'Ɋ').toCharArray(), 56023L, llI(2086244347, -629340776));
      Il[5] = IlI(lll('Ξ', -753252495, 'ɋ').toCharArray(), 17931L, llI(2086244346, -63596763));
      Il[llI(2086244345, 1542050514)] = IlI(lll('䧜', -1521929324, 'Ɉ').toCharArray(), 64583L, llI(2086244344, -307474755));
      Il[llI(2086244343, 700066753)] = IlI(lll('喑', 2109410095, 'ɉ').toCharArray(), 2143L, llI(2086244342, 502099911));
   }

   private int ll() {
      int var1 = Math.max(1, (int)Math.round(this.ll.IlII()));
      int var2 = Math.max(var1, (int)Math.round(this.ll.IlI()));
      return ThreadLocalRandom.current().nextInt(var1, var2 + 1);
   }

   private void III() {
      this.II = false;
      this.l = 0;
      this.Ill = 0;
      this.III = false;
   }

   static {
      short var6 = 7488;
      String var7 = "\ua9ce⧃裱攊ჼ皞鶷箅ﱶ緼縧ꕬ\uea11紿공䡦⳼噦能\uf3ee鰚\uf548腶㡦풬餙ꗪ\ufdcb⑊忆˘롵葦ʩ쐴㶻ᬃ谨퐲廥芻\uefdbᓡ\ue1e5띏긬潥趣릀拄\u086c卦毿ꎼާ䅳抬埢ຓ홱劽蓄用뿎竉\uda1cᙱ⺓\ueb69ࠂ铄誋䀹뀊\ue71a栅㋷\ued7e⪮观鑨Ƨ⯈糧眛嚫\udef5젹턄彎꾱櫧⧸ᑬ˴Ⲓ䣛ⱐ‑黇풽秊\ufb07\ue374㗬Ҥ吞\uf751흫ꦖ퓬㿛\ue651히䔚沜ﱐ菌ᢺꏌ\ue3af邽饴䟬䇨̺ﬦ㏓ɿ泂\uf231౿㜜렿粶뱅鈒\udd11身Ⴜ\ue5bf僮䆕滷ꢚ莟嘠왶玗ₔ띴㡜쀘\ue47f罈ﮟ쩹⚊豢ӊᅞ描胧跻猌⿺羧ၡ굎\uf1ea\uee4d盃ᇍ⯓⇱罱뷎嗲㟓⺖\u0b98꺋④膮瀔툩窾鐈絕诱ⴈ娢ᶛ쉓㬴뷞";
      char[] var8 = "ᵨᵤᵈᵠᵔᵈᵠᵔ".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            lIl = var9;
            llI = new Object[var9.length];
            int var2 = -119870204;
            byte[] var0 = "ò\u0096\u0085Ö\"\u009c\u009bâ\u0080g0M¤¸gn\u009e\u0019\u0012pæG2\u0013ßj°)Â\u000b\fU\u00ad9I5\u0014`\u001b·p\u0093è3\u009c\u0090i¦^\u009cC¬àüö\u0003~hX3".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lII = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lII[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            Il = new String[llI(2086244341, -200242486)];
            Il();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public double IIl(class_310 var1) {
      return this.IIIIIlI() && this.III ? (Double)this.IlI.III() : (double)1.0F;
   }

   public IIlIll() {
      super((Object)lIlIII.l(Il[4]), lIllII.l, (Object)lIlIII.l(Il[0]));
      this.ll = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(Il[5]), (double)1.0F, (double)1.0F, (double)1.0F, (double)4.0F, (double)1.0F)).IIII(lIlIII.Il(Il[2])));
      this.IlI = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(Il[llI(2086244340, 403901264)]), 0.3, 0.2, (double)1.0F, 0.05));
      this.IIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(Il[llI(2086244339, -635494052)]), false));
      this.lI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(Il[3]), false));
      this.I = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(Il[1]), false));
   }

   public void lI() {
      this.III();
   }

   private static String IlI(char[] var0, long var1, int var3) {
      int var4 = llI(2086244338, -1851097750) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & llI(2086244337, -85247431);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private boolean lII(class_746 var1) {
      return var1.method_6047().method_7909() instanceof class_1747 || var1.method_6079().method_7909() instanceof class_1747;
   }

   private static int llI(int var0, int var1) {
      return lII[var0 ^ 2086244351] ^ var1 ^ var0;
   }

   private static String lll(char var0, int var1, char var2) {
      int var3 = var2 ^ 590;
      char[] var4 = lIl[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])llI[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         llI[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 22920;
      int var9 = 0;

      do {
         int var10 = var4[var9] - '\ue925';
         var10 ^= 45537;
         var10 ^= 44637;
         var10 += 57303;
         var10 ^= 21132;
         var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
