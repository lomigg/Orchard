package x;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_310;
import net.minecraft.class_342;
import net.minecraft.class_364;
import net.minecraft.class_3675;
import net.minecraft.class_408;
import net.minecraft.class_437;
import net.minecraft.class_473;
import net.minecraft.class_7743;

@Environment(EnvType.CLIENT)
public final class lIllIIl implements ClientModInitializer {
   private long I;
   private final IIllIlII l;
   private Thread II;
   private long Il;
   private final llllIIll lI;
   private static final long ll = 350L;
   private boolean III;
   private static final long IIl = 5000L;
   private static lIllIIl IlI;
   private volatile boolean Ill;
   private final IIllIIl lII;
   private final lIlllII lIl = new lIlllII();
   private boolean llI;

   public void I() {
      this.III(IIIlIlIII.IIl);
   }

   public void l() {
      this.IIIl();
   }

   public llllIIll II() {
      return this.lI;
   }

   public static lIllIIl Il() {
      return IlI;
   }

   public IIllIIl lI() {
      return this.lII;
   }

   public lIllIIl() {
      this.l = new IIllIlII(this.lIl);
      this.lII = new IIllIIl();
      this.lI = new llllIIll();
   }

   private void III(IIIlIlIII var1) {
      class_310 var2 = class_310.method_1551();
      if (var2 != null) {
         class_437 var4 = var2.field_1755;
         if (var4 instanceof lIIIllIl) {
            lIIIllIl var3 = (lIIIllIl)var4;
            var3.llIl(var1);
            if (var1 == IIIlIlIII.IIl) {
               var3.method_25419();
            }

         } else if (var2.field_1724 != null && var2.field_1687 != null) {
            this.IIIl();
            var2.method_1507(new lIIIllIl(this, var1));
         }
      }
   }

   public IIllIlII IIl() {
      return this.l;
   }

   private void IlI(class_310 var1) {
      if (!IlIllIII.l()) {
         boolean var2 = var1.field_1724 != null && var1.field_1687 != null;
         boolean var3 = this.llI && !var2;
         if (var3) {
            this.lll();
         }

         this.llI = var2;
         this.lIl.lIl(var1);
         this.l.IIIIll();
         this.l.IIlIll(var1);
         boolean var4 = false;
         if (var1.field_1755 != null) {
            if (!(var1.field_1755 instanceof class_408) && !(var1.field_1755 instanceof class_7743) && !(var1.field_1755 instanceof class_473)) {
               label75: {
                  class_437 var6 = var1.field_1755;
                  if (var6 instanceof lIIIllIl) {
                     lIIIllIl var5 = (lIIIllIl)var6;
                     if (!var5.IllIlIl()) {
                        var4 = true;
                        break label75;
                     }
                  }

                  class_364 var8 = var1.field_1755.method_25399();
                  if (var8 instanceof class_342) {
                     var4 = true;
                  }
               }
            } else {
               var4 = true;
            }
         }

         class_3675.class_306 var7 = this.lII.lIlIl();
         boolean var9 = !var4 && !this.l.IlIIII(var7) && IllllIlI.IlIII(var1, var7);
         if (var9 && !this.III) {
            this.I();
         }

         this.III = var9;
         this.IIII();
      }
   }

   public void Ill() {
      this.III(IIIlIlIII.l);
   }

   public void lIl() {
      this.lIl.IlIl();
      this.Ill = false;
      Thread var1 = this.II;
      this.II = null;
      if (var1 != null) {
         try {
            Runtime.getRuntime().removeShutdownHook(var1);
         } catch (IllegalStateException var3) {
         }
      }

      if (IlI == this) {
         IlI = null;
      }

   }

   public void llI() {
      this.III(IIIlIlIII.I);
   }

   public void lll() {
      if (!IlIllIII.l()) {
         this.lII.IlI(this.l);
         this.Il = System.nanoTime() / 1000000L;
         this.Ill = false;
         this.I = 0L;
      }
   }

   private void IIII() {
      long var1 = System.nanoTime() / 1000000L;
      if (this.Ill && var1 - this.I >= 350L) {
         this.lll();
      } else if (this.Ill && var1 - this.Il >= 5000L) {
         this.lll();
      }
   }

   public void IIIl() {
      this.III = true;
   }

   public void IIlI() {
      if (!IlIllIII.l()) {
         this.Ill = true;
         this.I = System.nanoTime() / 1000000L;
      }
   }

   public void IIll() {
      this.III(IIIlIlIII.II);
   }

   public lIlllII IlII() {
      return this.lIl;
   }

   public void onInitializeClient() {
      IlI = this;
      x.Il.I();
      this.lII.IlIIl(this.l);
      this.lll();
      ClientTickEvents.START_CLIENT_TICK.register(this::IlI);
      HudRenderCallback.EVENT.register((HudRenderCallback)(var1, var2) -> {
         if (!IlIllIII.l()) {
            this.l.IIIIlIl(var1, 0, 0, IllllIlI.IIllIl(var2, true));
         }
      });
      IIIIIIIII.I.lI(this::IlIl);
      this.II = new Thread(() -> {
         if (!IlIllIII.l()) {
            this.lll();
         }

      });
      Runtime.getRuntime().addShutdownHook(this.II);
   }

   private void IlIl(llIIllI var1) {
      if (!IlIllIII.l()) {
         this.l.IIll(var1);
      }
   }
}
