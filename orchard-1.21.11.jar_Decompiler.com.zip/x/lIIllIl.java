package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_243;

@Environment(EnvType.CLIENT)
final class lIIllIl {
   private long I;
   private long l;
   private long II;
   private boolean Il;
   private static final double lI = (double)4096.0F;

   private static boolean I(class_243 var0) {
      return var0 != null && Double.isFinite(var0.field_1352) && Double.isFinite(var0.field_1351) && Double.isFinite(var0.field_1350);
   }

   public class_243 l() {
      return !this.Il ? null : new class_243((double)this.l / (double)4096.0F, (double)this.I / (double)4096.0F, (double)this.II / (double)4096.0F);
   }

   public void II(class_243 var1) {
      if (!I(var1)) {
         this.III();
      } else {
         this.l = Math.round(var1.field_1352 * (double)4096.0F);
         this.I = Math.round(var1.field_1351 * (double)4096.0F);
         this.II = Math.round(var1.field_1350 * (double)4096.0F);
         this.Il = true;
      }
   }

   public class_243 Il(long var1, long var3, long var5) {
      if (!this.Il) {
         return null;
      } else {
         this.l += var1;
         this.I += var3;
         this.II += var5;
         return this.l();
      }
   }

   public boolean lI() {
      return this.Il;
   }

   public class_243 ll(class_243 var1) {
      this.II(var1);
      return this.l();
   }

   public void III() {
      this.l = 0L;
      this.I = 0L;
      this.II = 0L;
      this.Il = false;
   }
}
