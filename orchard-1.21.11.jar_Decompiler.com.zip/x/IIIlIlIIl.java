package x;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat.class_5596;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1044;
import net.minecraft.class_10799;
import net.minecraft.class_11231;
import net.minecraft.class_11244;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4588;
import net.minecraft.class_8030;
import org.joml.Matrix3x2f;
import org.joml.Matrix3x2fc;
import org.jspecify.annotations.Nullable;

@Environment(EnvType.CLIENT)
final class IIIlIlIIl {
   private static final <undefinedtype> I;
   private static final <undefinedtype> l;
   private static final <undefinedtype> II;
   private static final RenderPipeline Il;
   private static final RenderPipeline lI;
   private static final float ll = 12.0F;
   private static final <undefinedtype> III;
   private static final RenderPipeline IIl;
   private static final float IlI = 8.0F;
   private static final int Ill = 0;
   private static final int lII = 8;
   private static final int lIl = 5;
   private static final RenderPipeline llI;
   private static final int lll = 6;
   private static final RenderPipeline IIII;
   private static final <undefinedtype> IIIl;
   private static final int IIlI = 18;
   private static final class_11231 IIll;
   private static final int IlII = 6;
   private static final float IlIl = 8.0F;
   private static final <undefinedtype> IllI;
   private static final <undefinedtype> Illl;
   private static final <undefinedtype> lIII;
   private static final int lIIl = 3;
   private static final int lIlI = 2;
   private static final <undefinedtype> lIll;
   private static final int llII = 1;
   private static final <undefinedtype> llIl;
   private static final int lllI = 4;
   private static final float llll = 2.0F;
   private static final RenderPipeline IIIII;
   private static final <undefinedtype> IIIIl;
   private static final float IIIlI = 1.25F;
   private static final <undefinedtype> IIIll;
   private static final int IIlII = 7;
   private static final int[] IIlIl;
   private static final String[] IIllI;
   private static final Object[] IIlll;

   static void I(class_332 var0, double var1, double var3, double var5) {
      var0.method_51448().translate((float)var1, (float)var3);
   }

   static boolean l(class_332 var0, double var1, double var3, double var5, double var7, double var9, int var11) {
      if (!(var5 <= (double)0.0F) && !(var7 <= (double)0.0F) && (var11 >>> llIll(4761709, 649261639) & llIll(4761708, 741778343)) > 0) {
         double var12 = lIIl(var5, var7, var9);
         var0.field_59826.method_70919(new class_11244(new Matrix3x2f(var0.method_51448()), (float)var1, (float)var3, (float)var5, (float)var7, (float)var12, 0.0F, 0, var11, var11, var11, var11, var0.field_44659.method_70863()) {
            private final int I;
            private final float l;
            private final int II;
            private final float Il;
            private final float lI;
            private final float ll;
            private final float III;
            private final Matrix3x2fc IIl;
            private final int IlI;
            private final float Ill;
            private final @Nullable class_8030 lII;
            private final int lIl;
            private final int llI;
            private final @Nullable class_8030 lll;

            public int I() {
               return this.II;
            }

            public void method_70917(class_4588 var1) {
               IIIlIlIIl.IlIll(var1, this.IIl, this.Ill, this.ll, this.III, this.lI, this.Il, this.l, this.lIl, this.I, this.IlI, this.llI, this.II);
            }

            public float l() {
               return this.l;
            }

            public class_11231 comp_4056() {
               return IIIlIlIIl.IIll;
            }

            public RenderPipeline comp_4055() {
               return IIIlIlIIl.Il;
            }

            public Matrix3x2fc II() {
               return this.IIl;
            }

            public @Nullable class_8030 comp_4274() {
               return this.lll;
            }

            public int Il() {
               return this.IlI;
            }

            private {
               this.IIl = var1;
               this.Ill = var2;
               this.ll = var3;
               this.III = var4;
               this.lI = var5;
               this.Il = var6;
               this.l = var7;
               this.lIl = var8;
               this.I = var9;
               this.IlI = var10;
               this.llI = var11;
               this.II = var12;
               this.lII = var13;
               this.lll = var14;
            }

            public @Nullable class_8030 comp_4069() {
               return this.lII;
            }

            public float lI() {
               return this.Il;
            }

            public float ll() {
               return this.III;
            }

            public float III() {
               return this.lI;
            }

            public float IIl() {
               return this.ll;
            }

            public int IlI() {
               return this.lIl;
            }

            public int Ill() {
               return this.llI;
            }

            public int lII() {
               return this.I;
            }

            public float lIl() {
               return this.Ill;
            }
         });
         return true;
      } else {
         return true;
      }
   }

   private static int II(float var0) {
      return Math.max(1, Math.min(llIll(4761711, -990312167), Math.round(var0 * 8.0F)));
   }

   private static @Nullable class_8030 Il(float var0, float var1, float var2, float var3, Matrix3x2fc var4, @Nullable class_8030 var5) {
      int var6 = (int)Math.floor((double)var0);
      int var7 = (int)Math.floor((double)var1);
      int var8 = (int)Math.ceil((double)(var0 + var2));
      int var9 = (int)Math.ceil((double)(var1 + var3));
      class_8030 var10 = (new class_8030(var6, var7, Math.max(1, var8 - var6), Math.max(1, var9 - var7))).method_65185(var4);
      return var5 != null ? var5.method_49701(var10) : var10;
   }

   private static int lI(float[] var0, float[] var1, float var2, float var3, float var4, float var5, float var6, int var7) {
      float var8 = Math.min(Math.min(var4, var5) * 0.5F, Math.max(0.0F, var6));
      int var9 = 0;
      var9 = IlIIl(var0, var1, var9, var2 + var4 - var8, var3 + var8, var8, -90.0F, 0.0F, var7);
      var9 = IlIIl(var0, var1, var9, var2 + var4 - var8, var3 + var5 - var8, var8, 0.0F, 90.0F, var7);
      var9 = IlIIl(var0, var1, var9, var2 + var8, var3 + var5 - var8, var8, 90.0F, 180.0F, var7);
      return IlIIl(var0, var1, var9, var2 + var8, var3 + var8, var8, 180.0F, 270.0F, var7);
   }

   static boolean ll(class_332 var0, double var1, double var3, double var5, double var7, double var9, double var11, int var13) {
      if (!(var5 <= (double)0.0F) && !(var7 <= (double)0.0F) && (var13 >>> llIll(4761710, 1983196770) & llIll(4761705, 483384464)) > 0) {
         double var14 = lIIl(var5, var7, var9);
         double var16 = Math.max((double)0.25F, Math.min(var11, Math.min(var5, var7) * (double)0.5F));
         var0.field_59826.method_70919(new class_11244(new Matrix3x2f(var0.method_51448()), (float)var1, (float)var3, (float)var5, (float)var7, (float)var14, (float)var16, 3, var13, var13, var13, var13, var0.field_44659.method_70863()) {
            private final int I;
            private final float l;
            private final int II;
            private final float Il;
            private final float lI;
            private final float ll;
            private final float III;
            private final Matrix3x2fc IIl;
            private final int IlI;
            private final float Ill;
            private final @Nullable class_8030 lII;
            private final int lIl;
            private final int llI;
            private final @Nullable class_8030 lll;

            public int I() {
               return this.II;
            }

            public void method_70917(class_4588 var1) {
               IIIlIlIIl.IlIll(var1, this.IIl, this.Ill, this.ll, this.III, this.lI, this.Il, this.l, this.lIl, this.I, this.IlI, this.llI, this.II);
            }

            public float l() {
               return this.l;
            }

            public class_11231 comp_4056() {
               return IIIlIlIIl.IIll;
            }

            public RenderPipeline comp_4055() {
               return IIIlIlIIl.Il;
            }

            public Matrix3x2fc II() {
               return this.IIl;
            }

            public @Nullable class_8030 comp_4274() {
               return this.lll;
            }

            public int Il() {
               return this.IlI;
            }

            private {
               this.IIl = var1;
               this.Ill = var2;
               this.ll = var3;
               this.III = var4;
               this.lI = var5;
               this.Il = var6;
               this.l = var7;
               this.lIl = var8;
               this.I = var9;
               this.IlI = var10;
               this.llI = var11;
               this.II = var12;
               this.lII = var13;
               this.lll = var14;
            }

            public @Nullable class_8030 comp_4069() {
               return this.lII;
            }

            public float lI() {
               return this.Il;
            }

            public float ll() {
               return this.III;
            }

            public float III() {
               return this.lI;
            }

            public float IIl() {
               return this.ll;
            }

            public int IlI() {
               return this.lIl;
            }

            public int Ill() {
               return this.llI;
            }

            public int lII() {
               return this.I;
            }

            public float lIl() {
               return this.Ill;
            }
         });
         return true;
      } else {
         return true;
      }
   }

   private static void III(class_4588 var0, Matrix3x2fc var1, float var2, float var3, float var4, float var5, int var6, int var7, float var8, float var9, float var10, int var11) {
      var0.method_70815(var1, var2, var3).method_39415(var11).method_22913(var4, var5).method_22921(var6, var7).method_22914(var8, var9, var10);
   }

   static boolean IIl(class_332 var0, class_2960 var1, double var2, double var4, double var6, double var8, float var10, float var11, float var12, float var13, int var14) {
      return IlllI(var0, var1, var2, var4, var6, var8, var10, var11, var12, var13, var14, 12.0F);
   }

   private static RenderPipeline IlI() {
      return class_10799.method_67887(RenderPipeline.builder(new RenderPipeline.Snippet[]{class_10799.field_60125}).withLocation(llI(III)).withVertexShader(llI(lIll)).withFragmentShader(llI(lIII)).withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).withCull(false).withVertexFormat(class_290.field_1590, class_5596.field_27382).build());
   }

   static void Ill(class_332 var0, double var1, double var3) {
      var0.method_51448().mul(new Matrix3x2f(1.0F, (float)var3, (float)var1, 1.0F, 0.0F, 0.0F));
   }

   private static void lII(class_4588 var0, Matrix3x2fc var1, float var2, float var3, float var4, float var5, float var6, int var7) {
      int var8 = llIII(var6);
      float[] var9 = new float[llIll(4761704, -888673895)];
      float[] var10 = new float[llIll(4761707, 562402462)];
      int var11 = lI(var9, var10, var2, var3, var4, var5, var6, var8);
      float var12 = var2 + var4 * 0.5F;
      float var13 = var3 + var5 * 0.5F;

      for(int var14 = 0; var14 < var11; ++var14) {
         int var15 = (var14 + 1) % var11;
         IIIll(var0, var1, var12, var13, var7);
         IIIll(var0, var1, var9[var14], var10[var14], var7);
         IIIll(var0, var1, var9[var15], var10[var15], var7);
      }

   }

   private static float lIl(float var0) {
      return Math.max(0.0F, Math.min(1.0F, var0));
   }

   private static class_2960 llI(Object var0) {
      return class_2960.method_60655(IllI.lIlI(), var0.lIlI());
   }

   static boolean lll(class_332 var0, double var1, double var3, double var5, double var7, double var9, int var11) {
      return ll(var0, var1, var3, var5, var7, var9, (double)1.0F, var11);
   }

   static boolean IIII(class_332 var0, double var1, double var3, double var5, int var7) {
      if (!(var5 <= (double)0.0F) && (var7 >>> llIll(4761706, -457337567) & llIll(4761701, 755940735)) > 0) {
         float var8 = (float)Math.max((double)0.0F, var5);
         float var9 = var8 + 2.0F;
         var0.field_59826.method_70919(new class_11244(new Matrix3x2f(var0.method_51448()), (float)var1, (float)var3, var9, var8, 0.0F, 5, var7, var0.field_44659.method_70863()) {
            private final float I;
            private final float l;
            private final float II;
            private final int Il;
            private final @Nullable class_8030 lI;
            private final int ll;
            private final float III;
            private final float IIl;
            private final Matrix3x2fc IlI;
            private final @Nullable class_8030 Ill;

            public int I() {
               return this.Il;
            }

            public class_11231 comp_4056() {
               return IIIlIlIIl.IIll;
            }

            public float l() {
               return this.II;
            }

            public float II() {
               return this.I;
            }

            public float Il() {
               return this.IIl;
            }

            public @Nullable class_8030 comp_4069() {
               return this.Ill;
            }

            public RenderPipeline comp_4055() {
               return IIIlIlIIl.Il;
            }

            public float lI() {
               return this.III;
            }

            public void method_70917(class_4588 var1) {
               float var2 = this.I * 2.0F;
               IIIlIlIIl.IlIll(var1, this.IlI, this.IIl - this.I, this.II - this.I, var2, var2, this.l, this.III, this.ll, this.Il, this.Il, this.Il, this.Il);
            }

            private {
               this.IlI = var1;
               this.IIl = var2;
               this.II = var3;
               this.I = var4;
               this.l = var5;
               this.III = var6;
               this.ll = var7;
               this.Il = var8;
               this.Ill = var9;
               this.lI = var10;
            }

            public Matrix3x2fc ll() {
               return this.IlI;
            }

            public @Nullable class_8030 comp_4274() {
               return this.lI;
            }

            public float III() {
               return this.l;
            }

            public int IIl() {
               return this.ll;
            }
         });
         return true;
      } else {
         return true;
      }
   }

   static boolean IIIl(class_332 var0, double var1, double var3, double var5, double var7, int var9) {
      if (!(var5 <= (double)0.0F) && !(var7 <= (double)0.0F) && (var9 >>> llIll(4761700, -427312696) & llIll(4761703, -1808100899)) > 0) {
         float var10 = (float)Math.max((double)0.0F, var5);
         float var11 = (float)Math.max((double)0.25F, var7);
         float var12 = var10 + var11 * 0.5F + 2.0F;
         var0.field_59826.method_70919(new class_11244(new Matrix3x2f(var0.method_51448()), (float)var1, (float)var3, var12, var10, var11, llIll(4761702, 1244643785), var9, var0.field_44659.method_70863()) {
            private final float I;
            private final float l;
            private final float II;
            private final int Il;
            private final @Nullable class_8030 lI;
            private final int ll;
            private final float III;
            private final float IIl;
            private final Matrix3x2fc IlI;
            private final @Nullable class_8030 Ill;

            public int I() {
               return this.Il;
            }

            public class_11231 comp_4056() {
               return IIIlIlIIl.IIll;
            }

            public float l() {
               return this.II;
            }

            public float II() {
               return this.I;
            }

            public float Il() {
               return this.IIl;
            }

            public @Nullable class_8030 comp_4069() {
               return this.Ill;
            }

            public RenderPipeline comp_4055() {
               return IIIlIlIIl.Il;
            }

            public float lI() {
               return this.III;
            }

            public void method_70917(class_4588 var1) {
               float var2 = this.I * 2.0F;
               IIIlIlIIl.IlIll(var1, this.IlI, this.IIl - this.I, this.II - this.I, var2, var2, this.l, this.III, this.ll, this.Il, this.Il, this.Il, this.Il);
            }

            private {
               this.IlI = var1;
               this.IIl = var2;
               this.II = var3;
               this.I = var4;
               this.l = var5;
               this.III = var6;
               this.ll = var7;
               this.Il = var8;
               this.Ill = var9;
               this.lI = var10;
            }

            public Matrix3x2fc ll() {
               return this.IlI;
            }

            public @Nullable class_8030 comp_4274() {
               return this.lI;
            }

            public float III() {
               return this.l;
            }

            public int IIl() {
               return this.ll;
            }
         });
         return true;
      } else {
         return true;
      }
   }

   static void IIlI(class_332 var0, double var1) {
      var0.method_51448().rotate((float)Math.toRadians(var1));
   }

   static void IIll(class_332 var0, class_2960 var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      if ((var8 >>> llIll(4761697, 1268423821) & llIll(4761696, 1408292201)) > 0 && var4 > 0 && var5 > 0 && var6 > 0 && var7 > 0) {
         var0.method_25293(class_10799.field_56883, var1, var2, var3, 0.0F, 0.0F, var4, var5, var6, var7, var6, var7, var8);
      }
   }

   private static float IlII(int var0) {
      return Math.max(-1.0F, Math.min(1.0F, -1.0F + (float)var0 * 0.25F));
   }

   static boolean IlIl(class_332 var0, double var1, double var3, double var5, double var7, double var9, int var11, int var12, boolean var13, boolean var14) {
      int var15 = var11 >>> llIll(4761699, -2129069586) & llIll(4761698, 181811354);
      int var16 = var12 >>> llIll(4761725, 424338246) & llIll(4761724, -518483896);
      if ((var15 > 0 || var16 > 0) && !(var5 <= (double)0.0F) && !(var7 <= (double)0.0F)) {
         double var17 = lIIl(var5, var7, var9);
         if (!(var17 <= 0.01) && (var13 || var14)) {
            var0.field_59826.method_70919(new class_11244(new Matrix3x2f(var0.method_51448()), (float)var1, (float)var3, (float)var5, (float)var7, (float)var17, 0.0F, var13 && var14 ? 0 : (var13 ? 1 : 2), var11, var11, var12, var12, var0.field_44659.method_70863()) {
               private final int I;
               private final float l;
               private final int II;
               private final float Il;
               private final float lI;
               private final float ll;
               private final float III;
               private final Matrix3x2fc IIl;
               private final int IlI;
               private final float Ill;
               private final @Nullable class_8030 lII;
               private final int lIl;
               private final int llI;
               private final @Nullable class_8030 lll;

               public int I() {
                  return this.II;
               }

               public void method_70917(class_4588 var1) {
                  IIIlIlIIl.IlIll(var1, this.IIl, this.Ill, this.ll, this.III, this.lI, this.Il, this.l, this.lIl, this.I, this.IlI, this.llI, this.II);
               }

               public float l() {
                  return this.l;
               }

               public class_11231 comp_4056() {
                  return IIIlIlIIl.IIll;
               }

               public RenderPipeline comp_4055() {
                  return IIIlIlIIl.Il;
               }

               public Matrix3x2fc II() {
                  return this.IIl;
               }

               public @Nullable class_8030 comp_4274() {
                  return this.lll;
               }

               public int Il() {
                  return this.IlI;
               }

               private {
                  this.IIl = var1;
                  this.Ill = var2;
                  this.ll = var3;
                  this.III = var4;
                  this.lI = var5;
                  this.Il = var6;
                  this.l = var7;
                  this.lIl = var8;
                  this.I = var9;
                  this.IlI = var10;
                  this.llI = var11;
                  this.II = var12;
                  this.lII = var13;
                  this.lll = var14;
               }

               public @Nullable class_8030 comp_4069() {
                  return this.lII;
               }

               public float lI() {
                  return this.Il;
               }

               public float ll() {
                  return this.III;
               }

               public float III() {
                  return this.lI;
               }

               public float IIl() {
                  return this.ll;
               }

               public int IlI() {
                  return this.lIl;
               }

               public int Ill() {
                  return this.llI;
               }

               public int lII() {
                  return this.I;
               }

               public float lIl() {
                  return this.Ill;
               }
            });
            return true;
         } else {
            var0.method_25296((int)Math.floor(var1), (int)Math.floor(var3), (int)Math.ceil(var1 + var5), (int)Math.ceil(var3 + var7), var11, var12);
            return true;
         }
      } else {
         return true;
      }
   }

   private static void IllI(class_4588 var0, Matrix3x2fc var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8, int var9) {
      if (!(var4 <= 0.0F) && !(var5 <= 0.0F)) {
         int var10 = II(var4);
         int var11 = II(var5);
         float var12 = Math.max(1.0E-4F, Math.min(var4, var5));
         float var13 = llll(lIl(var6 / var12));
         float var14 = llll(lIl(var7 / var12));
         float var15 = lIl(var8);
         III(var0, var1, var2, var3, 0.0F, 0.0F, var10, var11, var13, var14, var15, var9);
         III(var0, var1, var2, var3 + var5, 0.0F, 1.0F, var10, var11, var13, var14, var15, var9);
         III(var0, var1, var2 + var4, var3 + var5, 1.0F, 1.0F, var10, var11, var13, var14, var15, var9);
         III(var0, var1, var2 + var4, var3, 1.0F, 0.0F, var10, var11, var13, var14, var15, var9);
      }
   }

   static void Illl(class_332 var0, double var1, double var3) {
      var0.method_51448().scale((float)var1, (float)var3);
   }

   private static int lIII(float var0) {
      return Math.max(llIll(4761727, -1436503365), Math.min(llIll(4761726, 628456252), (int)Math.ceil((double)(var0 * 0.75F))));
   }

   private static double lIIl(double var0, double var2, double var4) {
      return Math.min(Math.min(var0, var2) * (double)0.5F, Math.max((double)0.0F, var4));
   }

   private static RenderPipeline lIlI() {
      return class_10799.method_67887(RenderPipeline.builder(new RenderPipeline.Snippet[]{class_10799.field_60125}).withLocation(llI(II)).withVertexShader(llI(llIl)).withFragmentShader(llI(llIl)).withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).withCull(false).withVertexFormat(class_290.field_1575, class_5596.field_27382).build());
   }

   static boolean lIll(class_332 var0, double var1, double var3, double var5, double var7, double var9, double var11, int var13) {
      if (!(var5 <= (double)0.0F) && !(var7 <= (double)0.0F) && !(var11 <= (double)0.0F) && (var13 >>> llIll(4761721, 16412964) & llIll(4761720, -1189511077)) > 0) {
         double var14 = lIIl(var5, var7, var9);
         float var16 = (float)Math.max((double)0.25F, var11);
         float var17 = (float)(var1 - (double)var16);
         float var18 = (float)(var3 - (double)var16);
         float var19 = (float)(var5 + (double)(var16 * 2.0F));
         float var20 = (float)(var7 + (double)(var16 * 2.0F));
         float var21 = (float)(var14 + (double)var16);
         var0.field_59826.method_70919(new class_11244(new Matrix3x2f(var0.method_51448()), var17, var18, var19, var20, var21, var16, llIll(4761723, 1242214675), var13, var13, var13, var13, var0.field_44659.method_70863()) {
            private final int I;
            private final float l;
            private final int II;
            private final float Il;
            private final float lI;
            private final float ll;
            private final float III;
            private final Matrix3x2fc IIl;
            private final int IlI;
            private final float Ill;
            private final @Nullable class_8030 lII;
            private final int lIl;
            private final int llI;
            private final @Nullable class_8030 lll;

            public int I() {
               return this.II;
            }

            public void method_70917(class_4588 var1) {
               IIIlIlIIl.IlIll(var1, this.IIl, this.Ill, this.ll, this.III, this.lI, this.Il, this.l, this.lIl, this.I, this.IlI, this.llI, this.II);
            }

            public float l() {
               return this.l;
            }

            public class_11231 comp_4056() {
               return IIIlIlIIl.IIll;
            }

            public RenderPipeline comp_4055() {
               return IIIlIlIIl.Il;
            }

            public Matrix3x2fc II() {
               return this.IIl;
            }

            public @Nullable class_8030 comp_4274() {
               return this.lll;
            }

            public int Il() {
               return this.IlI;
            }

            private {
               this.IIl = var1;
               this.Ill = var2;
               this.ll = var3;
               this.III = var4;
               this.lI = var5;
               this.Il = var6;
               this.l = var7;
               this.lIl = var8;
               this.I = var9;
               this.IlI = var10;
               this.llI = var11;
               this.II = var12;
               this.lII = var13;
               this.lll = var14;
            }

            public @Nullable class_8030 comp_4069() {
               return this.lII;
            }

            public float lI() {
               return this.Il;
            }

            public float ll() {
               return this.III;
            }

            public float III() {
               return this.lI;
            }

            public float IIl() {
               return this.ll;
            }

            public int IlI() {
               return this.lIl;
            }

            public int Ill() {
               return this.llI;
            }

            public int lII() {
               return this.I;
            }

            public float lIl() {
               return this.Ill;
            }
         });
         return true;
      } else {
         return true;
      }
   }

   private static float llII(float var0, float var1, float var2, float var3, float var4) {
      float var5 = Math.min(var1, var3);
      float var6 = Math.max(var1, var3);
      if (!(var4 < var5 - 0.001F) && !(var4 > var6 + 0.001F)) {
         if (Math.abs(var3 - var1) < 1.0E-4F) {
            return Float.NaN;
         } else {
            float var7 = (var4 - var1) / (var3 - var1);
            return var0 + var7 * (var2 - var0);
         }
      } else {
         return Float.NaN;
      }
   }

   private static void llIl(class_4588 var0, Matrix3x2fc var1, float var2, float var3, float var4, float var5, float var6, float var7, int var8) {
      float var9 = Math.min(var7, Math.min(var4, var5) * 0.5F);
      float var10 = var4 - var9 * 2.0F;
      float var11 = var5 - var9 * 2.0F;
      if (!(var10 <= 0.0F) && !(var11 <= 0.0F)) {
         int var12 = llIII(var6);
         float[] var13 = new float[llIll(4761722, 423944318)];
         float[] var14 = new float[llIll(4761717, -1208258179)];
         float[] var15 = new float[llIll(4761716, -2084491814)];
         float[] var16 = new float[llIll(4761719, -1079275784)];
         int var17 = lI(var13, var14, var2, var3, var4, var5, var6, var12);
         int var18 = lI(var15, var16, var2 + var9, var3 + var9, var10, var11, Math.max(0.0F, var6 - var9), var12);
         int var19 = Math.min(var17, var18);

         for(int var20 = 0; var20 < var19; ++var20) {
            int var21 = (var20 + 1) % var19;
            IIIll(var0, var1, var13[var20], var14[var20], var8);
            IIIll(var0, var1, var13[var21], var14[var21], var8);
            IIIll(var0, var1, var15[var21], var16[var21], var8);
            IIIll(var0, var1, var13[var20], var14[var20], var8);
            IIIll(var0, var1, var15[var21], var16[var21], var8);
            IIIll(var0, var1, var15[var20], var16[var20], var8);
         }

      } else {
         lII(var0, var1, var2, var3, var4, var5, var6, var8);
      }
   }

   private static RenderPipeline lllI() {
      return class_10799.method_67887(RenderPipeline.builder(new RenderPipeline.Snippet[]{class_10799.field_60125}).withLocation(llI(IIIIl)).withVertexShader(llI(lIll)).withFragmentShader(llI(IIIl)).withSampler(I.lIlI()).withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).withCull(false).withVertexFormat(class_290.field_1590, class_5596.field_27382).build());
   }

   private static float llll(float var0) {
      return lIl(var0) * 2.0F - 1.0F;
   }

   static void IIIII(class_332 var0, class_2960 var1, int var2, int var3, int var4, int var5, int var6) {
      if ((var6 >>> llIll(4761718, -498486780) & llIll(4761713, -2007964317)) > 0 && var4 > 0 && var5 > 0) {
         var0.method_25291(class_10799.field_56883, var1, var2, var3, 0.0F, 0.0F, var4, var5, var4, var5, var6);
      }
   }

   private static RenderPipeline IIIIl() {
      return class_10799.method_67887(RenderPipeline.builder(new RenderPipeline.Snippet[]{class_10799.field_56864}).withLocation(llI(l)).withSampler(I.lIlI()).withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).withCull(false).withVertexFormat(class_290.field_1575, class_5596.field_27379).build());
   }

   static boolean IIIlI(class_332 var0, double var1, double var3, double var5, double var7, double var9, int var11) {
      if (!(var5 <= (double)0.0F) && !(var7 <= (double)0.0F) && (var11 >>> llIll(4761712, -12606358) & llIll(4761715, -1084933422)) > 0) {
         float var12 = (float)Math.max((double)0.0F, var9);
         var0.field_59826.method_70919(new class_11244(new Matrix3x2f(var0.method_51448()), (float)var1, (float)var3, (float)var5, (float)var7, var12, var11, var0.field_44659.method_70863()) {
            private final float I;
            private final @Nullable class_8030 l;
            private final @Nullable class_8030 II;
            private final Matrix3x2fc Il;
            private final int lI;
            private final float ll;
            private final float III;
            private final float IIl;
            private final float IlI;

            public float I() {
               return this.IIl;
            }

            public float l() {
               return this.III;
            }

            public RenderPipeline comp_4055() {
               return IIIlIlIIl.IIl;
            }

            public void method_70917(class_4588 var1) {
               var1.method_70815(this.Il, this.ll, this.IlI).method_22913(0.0F, 0.0F).method_39415(this.lI);
               var1.method_70815(this.Il, this.ll, this.IlI + this.I).method_22913(0.0F, 1.0F).method_39415(this.lI);
               var1.method_70815(this.Il, this.ll + this.IIl, this.IlI + this.I).method_22913(1.0F, 1.0F).method_39415(this.lI);
               var1.method_70815(this.Il, this.ll + this.IIl, this.IlI).method_22913(1.0F, 0.0F).method_39415(this.lI);
            }

            public float II() {
               return this.IlI;
            }

            private {
               this.Il = var1;
               this.ll = var2;
               this.IlI = var3;
               this.IIl = var4;
               this.I = var5;
               this.III = var6;
               this.lI = var7;
               this.l = var8;
               this.II = var9;
            }

            public @Nullable class_8030 comp_4069() {
               return this.l;
            }

            public int Il() {
               return this.lI;
            }

            public class_11231 comp_4056() {
               return IIIlIlIIl.IIll;
            }

            public float lI() {
               return this.I;
            }

            public float ll() {
               return this.ll;
            }

            public Matrix3x2fc III() {
               return this.Il;
            }

            public @Nullable class_8030 comp_4274() {
               return this.II;
            }
         });
         return true;
      } else {
         return true;
      }
   }

   private static void IIIll(class_4588 var0, Matrix3x2fc var1, float var2, float var3, int var4) {
      var0.method_70815(var1, var2, var3).method_39415(var4);
   }

   static boolean IIlII(class_332 var0, double var1, double var3, double var5, double var7, double var9, int var11) {
      if (!(var5 <= (double)0.0F) && !(var7 <= (double)0.0F) && (var11 >>> llIll(4761714, 1083487092) & llIll(4761677, -1839298060)) > 0) {
         var0.field_59826.method_70919(new class_11244(new Matrix3x2f(var0.method_51448()), (float)var1, (float)var3, (float)var5, (float)var7, (float)lIIl(var5, var7, var9), 0.0F, var11, false, var0.field_44659.method_70863()) {
            private final boolean I;
            private final @Nullable class_8030 l;
            private final Matrix3x2fc II;
            private final float Il;
            private final int lI;
            private final float ll;
            private final float III;
            private final @Nullable class_8030 IIl;
            private final float IlI;
            private final float Ill;
            private final float lII;

            public float I() {
               return this.Il;
            }

            public float l() {
               return this.lII;
            }

            public boolean II() {
               return this.I;
            }

            public @Nullable class_8030 comp_4274() {
               return this.l;
            }

            public float Il() {
               return this.Ill;
            }

            public Matrix3x2fc lI() {
               return this.II;
            }

            private {
               this.II = var1;
               this.IlI = var2;
               this.Ill = var3;
               this.lII = var4;
               this.III = var5;
               this.Il = var6;
               this.ll = var7;
               this.lI = var8;
               this.I = var9;
               this.IIl = var10;
               this.l = var11;
            }

            public class_11231 comp_4056() {
               return IIIlIlIIl.IIll;
            }

            public float ll() {
               return this.ll;
            }

            public float III() {
               return this.IlI;
            }

            public float IIl() {
               return this.III;
            }

            public void method_70917(class_4588 var1) {
               if (this.I) {
                  IIIlIlIIl.llIl(var1, this.II, this.IlI, this.Ill, this.lII, this.III, this.Il, this.ll, this.lI);
               } else {
                  IIIlIlIIl.lII(var1, this.II, this.IlI, this.Ill, this.lII, this.III, this.Il, this.lI);
               }
            }

            public @Nullable class_8030 comp_4069() {
               return this.IIl;
            }

            public int IlI() {
               return this.lI;
            }

            public RenderPipeline comp_4055() {
               return IIIlIlIIl.llI;
            }
         });
         return true;
      } else {
         return true;
      }
   }

   private static void IIlIl(class_4588 var0, Matrix3x2fc var1, float var2, float var3, float var4, int var5) {
      int var6 = lIII(var4);

      for(int var7 = 0; var7 < var6; ++var7) {
         double var8 = (Math.PI * 2D) * (double)var7 / (double)var6;
         double var10 = (Math.PI * 2D) * (double)(var7 + 1) / (double)var6;
         IIIll(var0, var1, var2, var3, var5);
         IIIll(var0, var1, var2 + (float)Math.cos(var8) * var4, var3 + (float)Math.sin(var8) * var4, var5);
         IIIll(var0, var1, var2 + (float)Math.cos(var10) * var4, var3 + (float)Math.sin(var10) * var4, var5);
      }

   }

   static boolean IIllI(class_332 var0, double var1, double var3, double var5, double var7, double var9, int var11, int var12) {
      int var13 = var11 >>> llIll(4761676, -622855078) & llIll(4761679, -1710599594);
      int var14 = var12 >>> llIll(4761678, -2005779890) & llIll(4761673, -474747947);
      if ((var13 > 0 || var14 > 0) && !(var5 <= (double)0.0F) && !(var7 <= (double)0.0F)) {
         double var15 = lIIl(var5, var7, var9);
         var0.field_59826.method_70919(new class_11244(new Matrix3x2f(var0.method_51448()), (float)var1, (float)var3, (float)var5, (float)var7, (float)var15, 0.0F, 0, var11, var12, var12, var11, var0.field_44659.method_70863()) {
            private final int I;
            private final float l;
            private final int II;
            private final float Il;
            private final float lI;
            private final float ll;
            private final float III;
            private final Matrix3x2fc IIl;
            private final int IlI;
            private final float Ill;
            private final @Nullable class_8030 lII;
            private final int lIl;
            private final int llI;
            private final @Nullable class_8030 lll;

            public int I() {
               return this.II;
            }

            public void method_70917(class_4588 var1) {
               IIIlIlIIl.IlIll(var1, this.IIl, this.Ill, this.ll, this.III, this.lI, this.Il, this.l, this.lIl, this.I, this.IlI, this.llI, this.II);
            }

            public float l() {
               return this.l;
            }

            public class_11231 comp_4056() {
               return IIIlIlIIl.IIll;
            }

            public RenderPipeline comp_4055() {
               return IIIlIlIIl.Il;
            }

            public Matrix3x2fc II() {
               return this.IIl;
            }

            public @Nullable class_8030 comp_4274() {
               return this.lll;
            }

            public int Il() {
               return this.IlI;
            }

            private {
               this.IIl = var1;
               this.Ill = var2;
               this.ll = var3;
               this.III = var4;
               this.lI = var5;
               this.Il = var6;
               this.l = var7;
               this.lIl = var8;
               this.I = var9;
               this.IlI = var10;
               this.llI = var11;
               this.II = var12;
               this.lII = var13;
               this.lll = var14;
            }

            public @Nullable class_8030 comp_4069() {
               return this.lII;
            }

            public float lI() {
               return this.Il;
            }

            public float ll() {
               return this.III;
            }

            public float III() {
               return this.lI;
            }

            public float IIl() {
               return this.ll;
            }

            public int IlI() {
               return this.lIl;
            }

            public int Ill() {
               return this.llI;
            }

            public int lII() {
               return this.I;
            }

            public float lIl() {
               return this.Ill;
            }
         });
         return true;
      } else {
         return true;
      }
   }

   static boolean IIlll(class_332 var0, double var1, double var3, double var5, double var7, double var9, int var11, int var12, int var13, int var14) {
      int var15 = var11 >>> llIll(4761672, 394103582) & llIll(4761675, -2063034545);
      int var16 = var12 >>> llIll(4761674, -600884731) & llIll(4761669, -2050136287);
      int var17 = var13 >>> llIll(4761668, 2114541995) & llIll(4761671, 1972013231);
      int var18 = var14 >>> llIll(4761670, -560850958) & llIll(4761665, 830121402);
      if ((var15 > 0 || var16 > 0 || var17 > 0 || var18 > 0) && !(var5 <= (double)0.0F) && !(var7 <= (double)0.0F)) {
         double var19 = lIIl(var5, var7, var9);
         var0.field_59826.method_70919(new class_11244(new Matrix3x2f(var0.method_51448()), (float)var1, (float)var3, (float)var5, (float)var7, (float)var19, 0.0F, 0, var11, var12, var13, var14, var0.field_44659.method_70863()) {
            private final int I;
            private final float l;
            private final int II;
            private final float Il;
            private final float lI;
            private final float ll;
            private final float III;
            private final Matrix3x2fc IIl;
            private final int IlI;
            private final float Ill;
            private final @Nullable class_8030 lII;
            private final int lIl;
            private final int llI;
            private final @Nullable class_8030 lll;

            public int I() {
               return this.II;
            }

            public void method_70917(class_4588 var1) {
               IIIlIlIIl.IlIll(var1, this.IIl, this.Ill, this.ll, this.III, this.lI, this.Il, this.l, this.lIl, this.I, this.IlI, this.llI, this.II);
            }

            public float l() {
               return this.l;
            }

            public class_11231 comp_4056() {
               return IIIlIlIIl.IIll;
            }

            public RenderPipeline comp_4055() {
               return IIIlIlIIl.Il;
            }

            public Matrix3x2fc II() {
               return this.IIl;
            }

            public @Nullable class_8030 comp_4274() {
               return this.lll;
            }

            public int Il() {
               return this.IlI;
            }

            private {
               this.IIl = var1;
               this.Ill = var2;
               this.ll = var3;
               this.III = var4;
               this.lI = var5;
               this.Il = var6;
               this.l = var7;
               this.lIl = var8;
               this.I = var9;
               this.IlI = var10;
               this.llI = var11;
               this.II = var12;
               this.lII = var13;
               this.lll = var14;
            }

            public @Nullable class_8030 comp_4069() {
               return this.lII;
            }

            public float lI() {
               return this.Il;
            }

            public float ll() {
               return this.III;
            }

            public float III() {
               return this.lI;
            }

            public float IIl() {
               return this.ll;
            }

            public int IlI() {
               return this.lIl;
            }

            public int Ill() {
               return this.llI;
            }

            public int lII() {
               return this.I;
            }

            public float lIl() {
               return this.Ill;
            }
         });
         return true;
      } else {
         return true;
      }
   }

   private static RenderPipeline IlIII() {
      return class_10799.method_67887(RenderPipeline.builder(new RenderPipeline.Snippet[]{class_10799.field_60125}).withLocation(llI(Illl)).withVertexShader(llI(lIll)).withFragmentShader(llI(lIll)).withBlend(BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).withCull(false).withVertexFormat(class_290.field_1590, class_5596.field_27382).build());
   }

   private static int IlIIl(float[] var0, float[] var1, int var2, float var3, float var4, float var5, float var6, float var7, int var8) {
      for(int var9 = 0; var9 <= var8; ++var9) {
         float var10 = (float)var9 / (float)var8;
         double var11 = Math.toRadians((double)(var6 + (var7 - var6) * var10));
         var0[var2] = var3 + (float)Math.cos(var11) * var5;
         var1[var2] = var4 + (float)Math.sin(var11) * var5;
         ++var2;
      }

      return var2;
   }

   static void IlIlI(class_332 var0) {
      var0.method_51448().popMatrix();
   }

   private static void IlIll(class_4588 var0, Matrix3x2fc var1, float var2, float var3, float var4, float var5, float var6, float var7, int var8, int var9, int var10, int var11, int var12) {
      if (!(var4 <= 0.0F) && !(var5 <= 0.0F)) {
         int var13 = II(var4);
         int var14 = II(var5);
         float var15 = Math.max(1.0E-4F, Math.min(var4, var5));
         float var16 = lIl(var6 / var15);
         float var17 = lIl(var7 / var15);
         float var18 = llll(var16);
         float var19 = llll(var17);
         float var20 = IlII(var8);
         III(var0, var1, var2, var3, 0.0F, 0.0F, var13, var14, var18, var19, var20, var9);
         III(var0, var1, var2, var3 + var5, 0.0F, 1.0F, var13, var14, var18, var19, var20, var12);
         III(var0, var1, var2 + var4, var3 + var5, 1.0F, 1.0F, var13, var14, var18, var19, var20, var11);
         III(var0, var1, var2 + var4, var3, 1.0F, 0.0F, var13, var14, var18, var19, var20, var10);
      }
   }

   private static RenderPipeline IllII() {
      return class_10799.method_67887(RenderPipeline.builder(new RenderPipeline.Snippet[]{class_10799.field_56863}).withLocation(llI(IIIll)).withCull(false).withVertexFormat(class_290.field_1576, class_5596.field_27379).build());
   }

   static void IllIl(class_332 var0, double var1, double var3) {
      var0.method_51448().translate((float)var1, (float)var3);
   }

   private IIIlIlIIl() {
   }

   static boolean IlllI(class_332 var0, class_2960 var1, double var2, double var4, double var6, double var8, float var10, float var11, float var12, float var13, int var14, float var15) {
      if (var0 != null && var1 != null && !(var6 <= (double)0.0F) && !(var8 <= (double)0.0F) && (var14 >>> llIll(4761664, 134470003) & llIll(4761667, 1145237634)) > 0) {
         class_1044 var16 = class_310.method_1551().method_1531().method_4619(var1);
         var0.field_59826.method_70919(new class_11244(new Matrix3x2f(var0.method_51448()), (float)var2, (float)var4, (float)var6, (float)var8, var10, var11, var12, var13, var14, var15, class_11231.method_70900(var16.method_71659(), var16.method_75484()), var0.field_44659.method_70863()) {
            private final float I;
            private final float l;
            private final float II;
            private final float Il;
            private final Matrix3x2fc lI;
            private final @Nullable class_8030 ll;
            private final float III;
            private final float IIl;
            private final int IlI;
            private final float Ill;
            private final class_11231 lII;
            private final @Nullable class_8030 lIl;
            private final float llI;
            private final float lll;

            private {
               this.lI = var1;
               this.II = var2;
               this.III = var3;
               this.I = var4;
               this.llI = var5;
               this.IIl = var6;
               this.Ill = var7;
               this.lll = var8;
               this.Il = var9;
               this.IlI = var10;
               this.l = var11;
               this.lII = var12;
               this.lIl = var13;
               this.ll = var14;
            }

            public float I() {
               return this.III;
            }

            public float l() {
               return this.I;
            }

            public void method_70917(class_4588 var1) {
               IIIlIlIIl.lIIII(var1, this.lI, this.II, this.III, this.I, this.llI, this.IIl, this.Ill, this.lll, this.Il, this.IlI, this.l);
            }

            public float II() {
               return this.II;
            }

            public @Nullable class_8030 comp_4069() {
               return this.lIl;
            }

            public float Il() {
               return this.l;
            }

            public int lI() {
               return this.IlI;
            }

            public float ll() {
               return this.Il;
            }

            public float III() {
               return this.IIl;
            }

            public float IIl() {
               return this.llI;
            }

            public Matrix3x2fc IlI() {
               return this.lI;
            }

            public RenderPipeline comp_4055() {
               return IIIlIlIIl.IIII;
            }

            public class_11231 comp_4056() {
               return this.lII;
            }

            public float Ill() {
               return this.Ill;
            }

            public class_11231 lII() {
               return this.lII;
            }

            public @Nullable class_8030 comp_4274() {
               return this.ll;
            }

            public float lIl() {
               return this.lll;
            }
         });
         return true;
      } else {
         return true;
      }
   }

   static boolean Illll(class_332 var0, double var1, double var3, double var5, double var7, double var9, int var11) {
      if (!(var5 <= (double)0.0F) && !(var7 <= (double)0.0F) && !(var9 <= (double)0.0F) && (var11 >>> llIll(4761666, 106262798) & llIll(4761693, -124157007)) > 0) {
         float var12 = (float)Math.max((double)0.0F, var5);
         float var13 = (float)Math.max((double)0.25F, var7);
         float var14 = var12 + var13 * 0.5F + 2.0F;
         var0.field_59826.method_70919(new class_11244(new Matrix3x2f(var0.method_51448()), (float)var1, (float)var3, var14, var12, var13, lIl((float)var9), var11, var0.field_44659.method_70863()) {
            private final float I;
            private final Matrix3x2fc l;
            private final @Nullable class_8030 II;
            private final float Il;
            private final float lI;
            private final float ll;
            private final float III;
            private final float IIl;
            private final @Nullable class_8030 IlI;
            private final int Ill;

            public class_11231 comp_4056() {
               return IIIlIlIIl.IIll;
            }

            public float I() {
               return this.Il;
            }

            public int l() {
               return this.Ill;
            }

            public Matrix3x2fc II() {
               return this.l;
            }

            public @Nullable class_8030 comp_4274() {
               return this.IlI;
            }

            public float Il() {
               return this.lI;
            }

            private {
               this.l = var1;
               this.lI = var2;
               this.I = var3;
               this.ll = var4;
               this.III = var5;
               this.Il = var6;
               this.IIl = var7;
               this.Ill = var8;
               this.II = var9;
               this.IlI = var10;
            }

            public float lI() {
               return this.IIl;
            }

            public float ll() {
               return this.III;
            }

            public void method_70917(class_4588 var1) {
               float var2 = this.ll * 2.0F;
               IIIlIlIIl.IllI(var1, this.l, this.lI - this.ll, this.I - this.ll, var2, var2, this.III, this.Il, this.IIl, this.Ill);
            }

            public float III() {
               return this.ll;
            }

            public @Nullable class_8030 comp_4069() {
               return this.II;
            }

            public RenderPipeline comp_4055() {
               return IIIlIlIIl.IIIII;
            }

            public float IIl() {
               return this.I;
            }
         });
         return true;
      } else {
         return true;
      }
   }

   private static void lIIII(class_4588 var0, Matrix3x2fc var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8, float var9, int var10, float var11) {
      if (!(var4 <= 0.0F) && !(var5 <= 0.0F)) {
         int var12 = II(var4);
         int var13 = II(var5);
         float var14 = IlII(llIll(4761692, 1937284173));
         III(var0, var1, var2, var3, var6, var7, var12, var13, 0.0F, var11, var14, var10);
         III(var0, var1, var2, var3 + var5, var6, var9, var12, var13, 0.0F, var11, var14, var10);
         III(var0, var1, var2 + var4, var3 + var5, var8, var9, var12, var13, 0.0F, var11, var14, var10);
         III(var0, var1, var2 + var4, var3, var8, var7, var12, var13, 0.0F, var11, var14, var10);
      }
   }

   static boolean lIIIl(class_332 var0, double var1, double var3, double var5, double var7, double var9, double var11, int var13) {
      if (!(var5 <= (double)0.0F) && !(var7 <= (double)0.0F) && !(var11 <= (double)0.0F) && (var13 >>> llIll(4761695, -1456096644) & llIll(4761694, 2132223518)) > 0) {
         float var14 = (float)Math.min(Math.max((double)0.5F, var11), Math.min(var5, var7) * (double)0.5F);
         var0.field_59826.method_70919(new class_11244(new Matrix3x2f(var0.method_51448()), (float)var1, (float)var3, (float)var5, (float)var7, (float)lIIl(var5, var7, var9), var14, var13, true, var0.field_44659.method_70863()) {
            private final boolean I;
            private final @Nullable class_8030 l;
            private final Matrix3x2fc II;
            private final float Il;
            private final int lI;
            private final float ll;
            private final float III;
            private final @Nullable class_8030 IIl;
            private final float IlI;
            private final float Ill;
            private final float lII;

            public float I() {
               return this.Il;
            }

            public float l() {
               return this.lII;
            }

            public boolean II() {
               return this.I;
            }

            public @Nullable class_8030 comp_4274() {
               return this.l;
            }

            public float Il() {
               return this.Ill;
            }

            public Matrix3x2fc lI() {
               return this.II;
            }

            private {
               this.II = var1;
               this.IlI = var2;
               this.Ill = var3;
               this.lII = var4;
               this.III = var5;
               this.Il = var6;
               this.ll = var7;
               this.lI = var8;
               this.I = var9;
               this.IIl = var10;
               this.l = var11;
            }

            public class_11231 comp_4056() {
               return IIIlIlIIl.IIll;
            }

            public float ll() {
               return this.ll;
            }

            public float III() {
               return this.IlI;
            }

            public float IIl() {
               return this.III;
            }

            public void method_70917(class_4588 var1) {
               if (this.I) {
                  IIIlIlIIl.llIl(var1, this.II, this.IlI, this.Ill, this.lII, this.III, this.Il, this.ll, this.lI);
               } else {
                  IIIlIlIIl.lII(var1, this.II, this.IlI, this.Ill, this.lII, this.III, this.Il, this.lI);
               }
            }

            public @Nullable class_8030 comp_4069() {
               return this.IIl;
            }

            public int IlI() {
               return this.lI;
            }

            public RenderPipeline comp_4055() {
               return IIIlIlIIl.llI;
            }
         });
         return true;
      } else {
         return true;
      }
   }

   static void lIIlI(class_332 var0, class_2960 var1, double var2, double var4, double var6, double var8, double var10, int var12) {
      if ((var12 >>> llIll(4761689, -1743002101) & llIll(4761688, -2041146578)) > 0 && !(var6 <= (double)0.0F) && !(var8 <= (double)0.0F)) {
         double var13 = lIIl(var6, var8, var10);
         if (var13 <= 0.01) {
            IIIII(var0, var1, (int)Math.round(var2), (int)Math.round(var4), (int)Math.round(var6), (int)Math.round(var8), var12);
         } else {
            class_1044 var15 = class_310.method_1551().method_1531().method_4619(var1);
            if (var15 != null) {
               class_11231 var16 = class_11231.method_70900(var15.method_71659(), var15.method_75484());
               var0.field_59826.method_70919(new class_11244(var16, new Matrix3x2f(var0.method_51448()), (float)var2, (float)var4, (float)var6, (float)var8, (float)var13, var12, var0.field_44659.method_70863()) {
                  private final float I;
                  private final float l;
                  private final float II;
                  private final @Nullable class_8030 Il;
                  private final @Nullable class_8030 lI;
                  private final Matrix3x2fc ll;
                  private final int III;
                  private final class_11231 IIl;
                  private final float IlI;
                  private final float Ill;

                  public class_11231 I() {
                     return this.IIl;
                  }

                  public float l() {
                     return this.l;
                  }

                  public float II() {
                     return this.IlI;
                  }

                  public float Il() {
                     return this.II;
                  }

                  public RenderPipeline comp_4055() {
                     return IIIlIlIIl.lI;
                  }

                  private {
                     this.IIl = var1;
                     this.ll = var2;
                     this.IlI = var3;
                     this.l = var4;
                     this.II = var5;
                     this.Ill = var6;
                     this.I = var7;
                     this.III = var8;
                     this.lI = var9;
                     this.Il = var10;
                  }

                  public Matrix3x2fc lI() {
                     return this.ll;
                  }

                  public int ll() {
                     return this.III;
                  }

                  public void method_70917(class_4588 var1) {
                     IIIlIlIIl.llIlI(var1, this.ll, this.IlI, this.l, this.II, this.Ill, this.I, this.III);
                  }

                  public @Nullable class_8030 comp_4069() {
                     return this.lI;
                  }

                  public class_11231 comp_4056() {
                     return this.IIl;
                  }

                  public float III() {
                     return this.I;
                  }

                  public float IIl() {
                     return this.Ill;
                  }

                  public @Nullable class_8030 comp_4274() {
                     return this.Il;
                  }
               });
            }
         }
      }
   }

   private static void lIIll(class_4588 var0, Matrix3x2fc var1, float var2, float var3, float var4, float var5, int var6) {
      float var7 = var4 + var5 * 0.5F;
      float var8 = Math.max(0.0F, var4 - var5 * 0.5F);
      if (var8 <= 0.0F) {
         IIlIl(var0, var1, var2, var3, var7, var6);
      } else {
         int var9 = lIII(var7);

         for(int var10 = 0; var10 < var9; ++var10) {
            double var11 = (Math.PI * 2D) * (double)var10 / (double)var9;
            double var13 = (Math.PI * 2D) * (double)(var10 + 1) / (double)var9;
            float var15 = var2 + (float)Math.cos(var11) * var7;
            float var16 = var3 + (float)Math.sin(var11) * var7;
            float var17 = var2 + (float)Math.cos(var13) * var7;
            float var18 = var3 + (float)Math.sin(var13) * var7;
            float var19 = var2 + (float)Math.cos(var11) * var8;
            float var20 = var3 + (float)Math.sin(var11) * var8;
            float var21 = var2 + (float)Math.cos(var13) * var8;
            float var22 = var3 + (float)Math.sin(var13) * var8;
            IIIll(var0, var1, var15, var16, var6);
            IIIll(var0, var1, var17, var18, var6);
            IIIll(var0, var1, var21, var22, var6);
            IIIll(var0, var1, var15, var16, var6);
            IIIll(var0, var1, var21, var22, var6);
            IIIll(var0, var1, var19, var20, var6);
         }

      }
   }

   static void lIlII(class_332 var0) {
      var0.method_51448().pushMatrix();
   }

   static {
      short var6 = 16330;
      String var7 = "ࠔࣸ\u085dࠆ࣋ࠖࢁࡪ\ud9ce\ud959\ud9e4\ud9dc\ud912\ud9ed\ud934\ud9ec\ud936\ud9a6\ud9a6\ud925\ud977\ud95e\ud966\ud9b7\ud99f\ud93c\ud9df\ud9bc\ud984\ud995\ud959\ud943閭索吝漣丹殮若漣怒淋類亮ꋦꈎꊿꋢꈸꋠꈾꋄꈞꊎꊕꈻꉟꈊꈋꊮꊹꈔꋷꊤꊯꋑꉣꈇ敧斋攌敳斿敄斕敲斂攄敖斞綀紗綪綒絜綣絺綢絸編編絫紺紑紬緎緑絲綑緲緊緛紗納緲緈紓綘綄索緈緐綅紺緺綎絧綠絞綆䎡䍏䏻䎕䍸䎠䍾䎸䍔䏴䏫䍀䌜䍙䌎䏔䏽䌠䎝䏁䏬䎧䍢䌽䏔䏥䍯䏮묋뮜묡묙믗묨믱묩믳뭣뭣믠뮷믷뮯뭰뭔믑묨뭠뭅뭑뮾뮖뭽뭀믋묝붫뵇뷀붿뵳불뵙붽뵍뷭뷡뵍菉荛菦菝茔華茢菟茎莴莿茜荱茰荨莘莝茾菑莠莅菨茌荆莽菫荓莄쐣쓏쑈쐷쓻쐀쓑쐴쓅쑀쐖쓐逐郠遅逅郓逻郲逜郹遣遹邇";
      char[] var8 = "㿂㿒㿆㿒㿆㿢㿖㿖㿆㿖㿆㿆".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IIllI = var9;
            IIlll = new Object[var9.length];
            int var2 = -1341354681;
            byte[] var0 = "\u0096ö×u\u009cr\u0086st½SÎÆq\u000bS¬\u008bùA{CÌú\u0091Á±þTù°\u0014\u009dJ\u0098¢VÃ\u009có$~´\u0002úkäîûÞ¹³ã´ð±1\\ÜÒº\u0092\u001d@©\u000eÆdQ\\µ\u008c\u001a$\u0097\u009b\u00951^e°¾T\u0002\t]¥\u009búN\u0094(©\u0000Å\u000f\u0007¿T\u00033\u0085\b¥\u000fï«\u0084R\r\u0097-8\u0014ÀªO{\u0081E\u000f\u0011\u001f\u0019ðÐ\u0096Y\"\u001a¬\u0001j\u009bÙI*Nw¡86\u001f_S÷Î$§9®\t5L²¼lk\u001f\u00105\u0089BÜÎM|°ÅÎ\u00adPnÖ2ë\u0081>\u0080C¸Gülô\u0006Õy¶\u0011T\u0013HÝ¦TÃ<¹^\u0019q\u009f|ÏS\u0003ø(_Ã\r6\u0012¶Îú\u00ad mìM\u0087\\$w#&\\ü@\u0003å\u0080æèµaf{[®[øÜ¹\u001a\u0089".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IIlIl = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IIlIl[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            IllI = lIlIII.l(lllII(509068734, 1098203689));
            Illl = lIlIII.l(lllII(509068735, -1867814069));
            lIll = lIlIII.l(lllII(509068732, -1327033898));
            III = lIlIII.l(lllII(509068733, -343734139));
            lIII = lIlIII.l(lllII(509068730, 738592447));
            IIIll = lIlIII.l(lllII(509068731, 887440646));
            l = lIlIII.l(lllII(509068728, 180568990));
            IIIIl = lIlIII.l(lllII(509068729, -227669357));
            IIIl = lIlIII.l(lllII(509068726, -188087698));
            II = lIlIII.l(lllII(509068727, -894872391));
            llIl = lIlIII.l(lllII(509068724, -1925044212));
            I = lIlIII.l(lllII(509068725, -647141228));
            llI = IllII();
            lI = IIIIl();
            Il = IlIII();
            IIIII = IlI();
            IIII = lllI();
            IIl = lIlI();
            IIll = class_11231.method_70899();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static void lIlIl(class_4588 var0, Matrix3x2fc var1, float var2, float var3, float var4, float var5, int var6) {
      var0.method_70815(var1, var2, var3).method_22913(var4, var5).method_39415(var6);
   }

   static void lIllI(class_332 var0, class_2960 var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10, int var11, int var12) {
      if ((var12 >>> llIll(4761691, 1256785257) & llIll(4761690, 1544135358)) > 0 && var4 > 0 && var5 > 0 && var8 > 0 && var9 > 0 && var10 > 0 && var11 > 0) {
         var0.method_25293(class_10799.field_56883, var1, var2, var3, (float)var6, (float)var7, var4, var5, var8, var9, var10, var11, var12);
      }
   }

   static boolean lIlll(class_332 var0, double var1, double var3, double var5, double var7, double var9, double var11, int var13) {
      if (!(var5 <= (double)0.0F) && !(var7 <= (double)0.0F) && !(var11 <= (double)0.0F) && (var13 >>> llIll(4761685, -1808595412) & llIll(4761684, -323459601)) > 0) {
         double var14 = lIIl(var5, var7, var9);
         float var16 = (float)Math.max((double)0.25F, var11);
         float var17 = (float)(var1 - (double)var16);
         float var18 = (float)(var3 - (double)var16);
         float var19 = (float)(var5 + (double)(var16 * 2.0F));
         float var20 = (float)(var7 + (double)(var16 * 2.0F));
         float var21 = (float)(var14 + (double)var16);
         var0.field_59826.method_70919(new class_11244(new Matrix3x2f(var0.method_51448()), var17, var18, var19, var20, var21, var16, 4, var13, var13, var13, var13, var0.field_44659.method_70863()) {
            private final int I;
            private final float l;
            private final int II;
            private final float Il;
            private final float lI;
            private final float ll;
            private final float III;
            private final Matrix3x2fc IIl;
            private final int IlI;
            private final float Ill;
            private final @Nullable class_8030 lII;
            private final int lIl;
            private final int llI;
            private final @Nullable class_8030 lll;

            public int I() {
               return this.II;
            }

            public void method_70917(class_4588 var1) {
               IIIlIlIIl.IlIll(var1, this.IIl, this.Ill, this.ll, this.III, this.lI, this.Il, this.l, this.lIl, this.I, this.IlI, this.llI, this.II);
            }

            public float l() {
               return this.l;
            }

            public class_11231 comp_4056() {
               return IIIlIlIIl.IIll;
            }

            public RenderPipeline comp_4055() {
               return IIIlIlIIl.Il;
            }

            public Matrix3x2fc II() {
               return this.IIl;
            }

            public @Nullable class_8030 comp_4274() {
               return this.lll;
            }

            public int Il() {
               return this.IlI;
            }

            private {
               this.IIl = var1;
               this.Ill = var2;
               this.ll = var3;
               this.III = var4;
               this.lI = var5;
               this.Il = var6;
               this.l = var7;
               this.lIl = var8;
               this.I = var9;
               this.IlI = var10;
               this.llI = var11;
               this.II = var12;
               this.lII = var13;
               this.lll = var14;
            }

            public @Nullable class_8030 comp_4069() {
               return this.lII;
            }

            public float lI() {
               return this.Il;
            }

            public float ll() {
               return this.III;
            }

            public float III() {
               return this.lI;
            }

            public float IIl() {
               return this.ll;
            }

            public int IlI() {
               return this.lIl;
            }

            public int Ill() {
               return this.llI;
            }

            public int lII() {
               return this.I;
            }

            public float lIl() {
               return this.Ill;
            }
         });
         return true;
      } else {
         return true;
      }
   }

   private static int llIII(float var0) {
      return Math.max(llIll(4761687, 1438958590), Math.min(llIll(4761686, 86328184), (int)Math.ceil((double)var0)));
   }

   static boolean llIIl(class_332 var0, class_2960 var1, double var2, double var4, double var6, double var8, int var10) {
      return IIl(var0, var1, var2, var4, var6, var8, 0.0F, 0.0F, 1.0F, 1.0F, var10);
   }

   private static void llIlI(class_4588 var0, Matrix3x2fc var1, float var2, float var3, float var4, float var5, float var6, int var7) {
      int var8 = llIII(var6);
      float[] var9 = new float[llIll(4761681, -336953694)];
      float[] var10 = new float[llIll(4761680, 1828536274)];
      int var11 = lI(var9, var10, var2, var3, var4, var5, var6, var8);
      if (var11 >= 3) {
         float[] var12 = new float[var11];
         int var13 = 0;

         for(int var14 = 0; var14 < var11; ++var14) {
            boolean var15 = false;

            for(int var16 = 0; var16 < var13; ++var16) {
               if (Math.abs(var12[var16] - var10[var14]) < 0.001F) {
                  var15 = true;
                  break;
               }
            }

            if (!var15) {
               var12[var13++] = var10[var14];
            }
         }

         for(int var29 = 0; var29 < var13 - 1; ++var29) {
            for(int var31 = var29 + 1; var31 < var13; ++var31) {
               if (var12[var31] < var12[var29]) {
                  float var33 = var12[var29];
                  var12[var29] = var12[var31];
                  var12[var31] = var33;
               }
            }
         }

         for(int var30 = 0; var30 < var13 - 1; ++var30) {
            float var32 = var12[var30];
            float var34 = var12[var30 + 1];
            float var17 = var2 + var4;
            float var18 = var2;
            float var19 = var2 + var4;
            float var20 = var2;

            for(int var21 = 0; var21 < var11; ++var21) {
               int var22 = (var21 + 1) % var11;
               float var23 = var10[var21];
               float var24 = var10[var22];
               float var25 = var9[var21];
               float var26 = var9[var22];
               float var27 = llII(var25, var23, var26, var24, var32);
               if (!Float.isNaN(var27)) {
                  var17 = Math.min(var17, var27);
                  var18 = Math.max(var18, var27);
               }

               var27 = llII(var25, var23, var26, var24, var34);
               if (!Float.isNaN(var27)) {
                  var19 = Math.min(var19, var27);
                  var20 = Math.max(var20, var27);
               }
            }

            for(int var35 = 0; var35 < var11; ++var35) {
               if (Math.abs(var10[var35] - var32) < 0.001F) {
                  var17 = Math.min(var17, var9[var35]);
                  var18 = Math.max(var18, var9[var35]);
               }

               if (Math.abs(var10[var35] - var34) < 0.001F) {
                  var19 = Math.min(var19, var9[var35]);
                  var20 = Math.max(var20, var9[var35]);
               }
            }

            float var36 = 1.0F / var4;
            float var37 = 1.0F / var5;
            float var38 = (var17 - var2) * var36;
            float var39 = (var32 - var3) * var37;
            float var40 = (var18 - var2) * var36;
            float var41 = (var19 - var2) * var36;
            float var43 = (var34 - var3) * var37;
            float var28 = (var20 - var2) * var36;
            lIlIl(var0, var1, var17, var32, var38, var39, var7);
            lIlIl(var0, var1, var18, var32, var40, var39, var7);
            lIlIl(var0, var1, var20, var34, var28, var43, var7);
            lIlIl(var0, var1, var17, var32, var38, var39, var7);
            lIlIl(var0, var1, var20, var34, var28, var43, var7);
            lIlIl(var0, var1, var19, var34, var41, var43, var7);
         }

      }
   }

   private static int llIll(int var0, int var1) {
      return IIlIl[var0 ^ 4761709] ^ var1 ^ var0;
   }

   private static String lllII(int var0, int var1) {
      int var3 = var0 ^ 509068734;
      char[] var4 = IIllI[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IIlll[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IIlll[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 803581174;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 164;
               break;
            case 1:
               var9 = 16;
               break;
            case 2:
               var9 = 214;
               break;
            case 3:
               var9 = 154;
               break;
            case 4:
               var9 = 124;
               break;
            case 5:
               var9 = 188;
               break;
            case 6:
               var9 = 97;
               break;
            case 7:
               var9 = 138;
               break;
            case 8:
               var9 = 109;
               break;
            case 9:
               var9 = 205;
               break;
            case 10:
               var9 = 203;
               break;
            case 11:
               var9 = 127;
               break;
            case 12:
               var9 = 51;
               break;
            case 13:
               var9 = 104;
               break;
            case 14:
               var9 = 17;
               break;
            case 15:
               var9 = 210;
               break;
            case 16:
               var9 = 209;
               break;
            case 17:
               var9 = 114;
               break;
            case 18:
               var9 = 148;
               break;
            case 19:
               var9 = 237;
               break;
            case 20:
               var9 = 238;
               break;
            case 21:
               var9 = 163;
               break;
            case 22:
               var9 = 59;
               break;
            case 23:
               var9 = 17;
               break;
            case 24:
               var9 = 234;
               break;
            case 25:
               var9 = 223;
               break;
            case 26:
               var9 = 57;
               break;
            case 27:
               var9 = 184;
               break;
            case 28:
               var9 = 152;
               break;
            case 29:
               var9 = 95;
               break;
            case 30:
               var9 = 204;
               break;
            case 31:
               var9 = 203;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
