package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;

@Environment(EnvType.CLIENT)
public final class IIlllI extends IIIIIIIlI {
   private static final float I = 0.01F;
   private final IlIIIlIlI<<undefinedtype>> l;
   private static String[] II;
   private final IIIllIIII Il;
   private final IIIllIIII lI;
   private final lIIIIl ll;
   private final IIIllIIII III;
   private volatile float IIl;
   private final IIIllIIII IlI;
   private final IIIllIIII Ill;
   private static final double lII = (double)8.0F;
   private final IIIllIIII lIl;
   private final IIIllIIII llI;
   private static final int[] lll;
   private static final String[] IIII;
   private static final Object[] IIIl;

   private void ll(float var1) {
      float var2 = class_3532.method_15363(((Double)this.llI.III()).floatValue(), 0.01F, 1.0F);
      this.IIl = class_3532.method_16439(var2, this.IIl, var1);
      if (Math.abs(this.IIl - var1) < 0.001F) {
         this.IIl = var1;
      }

   }

   static {
      short var6 = 19657;
      String var7 = "혉ㄈ試Ұ謒땤믷䛺ą⤰㡬柹\ue9bf男浫뼿ੀ栯옺콥鷑Л㒛漂땻軧鿻欆\uda61咝ዟ쉓\u0001ྼ﹟灡앹㋜뎈顕큍쭷枆牴\ue1b1〚﹏峹稥⃑즁ᰤ쩿퍌혜\ue8cc젂퓳⩬祈ᗧ윷⋑﹑\ude5e뺭爿낧忩飊\uea30燏ۊ⨇缐\uf444\udef8\uf815⤹䂖㗙䧛듫Ꮇᴃ봔䠟\uf6d1嶣頋ẫ糞䞄녩罱쉉혫\ue694룟㻓倴\u16ffїꬎ⋸\ued13갹㲵冲鏿䉹ऩ\u0c65⚿\ue2bd㛹ዲ抈箒衣밁⿑䓰楶\uef79볆፵\u13f6ლᮘ螏瘇툑掆㲅橺饁㦸\u0a58㔉\u0b52\u0fdcⅠ趩⥅䂄푦\ufddd鮖ꓪ뫖ꎚ璅䃼Ⱊ\uda4d턣⿃踽犌풵愃桓莖䝻丟㷲ឬ᪄㧆䅎\uf0b5䇩葏혂褎᭳\uf4f0ᷡꬓ\uf03f鱁轺Ꭶ㈼緳䌧ꯂಹ쵐磰쾠ᡄ蛳Ⲹ潤枡挬꒖㖏ᴻ䈖\udacc쐨샖\uf450厚磵\ue55d\ude1c\uda47玩憠ತᶮ簪㜒瓽\u2efeឱ漰건盹唲⤣鄔뤅亊♟愰쵧蟫\ue5c4\ue968ഈ兠٫楾轂ꠎ塞\ueb03旙諒뚊꿬繠跧潱뫅薢䣓仵꿹ᬢ켽㌕ 퉆\ueeb8蚑⪑奮쓷蓴\uf6f9䘫厫顯䡨\uec86磥蕠䒙뷀ᾢ⾬鑯ƍꠢ〇舽碓ბ㟔⊛\ud854荇㏈Ὦ啶챱쾺\ue4d1ᙖ歊";
      char[] var8 = "䳝䳁䳍䳝䳑䳕䳑䳙䳙䲑䳍䳝䳑".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IIII = var9;
            IIIl = new Object[var9.length];
            int var2 = 287887206;
            byte[] var0 = "óÚ\"\u0083»ü<\u0015\u0019æ\"ÂXS\u0098Zo¤è8L1v²F³Ë\u0018Ùöö\u001c¤Ö©\u0083¨+Ã\u009bd[\u0082þ\u0006:\u009cUU\u0012\u0019ÐJ¥yk\bÔ.ü\u0090S\u0011+\u0089g®\n©>pb\u0094\u009eu\u0001f¿Ê\u001d\u0006âN\u009fý_DOcp}ÚLå\n+È·N8«@mß7ù\u007f\u0089²åÊ\u008c\u0001\bi_\u008a\u0090à¡".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lll = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lll[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            II = new String[lIIl(416873157, -97904851)];
            IlII();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static String IlI(char[] var0, long var1, int var3) {
      int var4 = lIIl(416873156, -176609673) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & lIIl(416873159, 269883292);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   public IIlllI() {
      super((Object)lIlIII.l(II[0]), lIllII.I, (Object)lIlIII.l(II[lIIl(416873158, 1369681395)]));
      this.l = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(II[lIIl(416873153, 1716837784)]), <undefinedtype>.class, null.lI));
      this.IlI = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(II[1]), (double)8.0F, (double)2.0F, (double)12.0F, (double)0.25F)).IIl(lIlIII.Il(II[2])));
      this.lI = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(II[lIIl(416873152, 1170293528)]), (double)9.0F, (double)1.0F, (double)35.0F, (double)0.5F)).IIl(lIlIII.Il(II[lIIl(416873155, 1329856183)])));
      this.lIl = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(II[3]), 0.55, 0.1, (double)1.0F, 0.05));
      this.Il = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(II[5]), 1.08, (double)0.5F, (double)1.5F, 0.05));
      this.III = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(II[lIIl(416873154, -804863056)]), (double)1.0F, (double)0.5F, (double)1.5F, 0.05));
      this.Ill = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(II[lIIl(416873165, -1389978589)]), 0.05, (double)0.0F, (double)0.5F, 0.01)).IIl(lIlIII.Il(II[2])));
      this.llI = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(II[lIIl(416873164, -1579420105)]), 0.22, 0.05, 0.6, 0.01));
      this.ll = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(II[4]), true));
      this.IIl = 1.0F;
   }

   public void lI() {
      this.IIl = 1.0F;
   }

   private boolean lII(class_310 var1) {
      if (!(Boolean)this.ll.III()) {
         return true;
      } else {
         return var1.field_1690 != null && var1.field_1690.field_1886 != null && var1.field_1690.field_1886.method_1434();
      }
   }

   private double llI(class_243 var1, class_243 var2, class_238 var3) {
      class_243 var4 = var3.method_1005();
      class_243 var5 = new class_243(var4.field_1352, var3.field_1322 + (var3.field_1325 - var3.field_1322) * 0.72, var4.field_1350);
      class_243 var6 = new class_243(var4.field_1352, var3.field_1322 + (var3.field_1325 - var3.field_1322) * 0.38, var4.field_1350);
      return Math.min(this.Illl(var2, var4.method_1020(var1)), Math.min(this.Illl(var2, var5.method_1020(var1)), this.Illl(var2, var6.method_1020(var1))));
   }

   public boolean lll() {
      return this.IIIIIlI() && Math.abs(this.IIl - 1.0F) > 0.01F;
   }

   public void lIl() {
      this.IIl = ((Double)this.III.III()).floatValue();
   }

   public float IIII() {
      return this.IIIIIlI() ? this.IIl : 1.0F;
   }

   private double IIll(double var1) {
      double var3 = class_3532.method_15350(var1, (double)0.0F, (double)1.0F);
      return var3 * var3 * ((double)3.0F - (double)2.0F * var3);
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null) {
         this.ll(this.IlIl(var1));
      } else {
         this.ll(1.0F);
      }
   }

   private static void IlII() {
      II[0] = IlI(llII((short)24111, -124760841, '踐').toCharArray(), 69738L, lIIl(416873167, 882445430));
      II[1] = IlI(llII((short)'\ue84d', 1032015777, '踑').toCharArray(), 28317L, lIIl(416873166, -1982378456));
      II[2] = IlI(llII((short)'鏓', 716579845, '踒').toCharArray(), 58905L, lIIl(416873161, -1742490873));
      II[3] = IlI(llII((short)'鎷', 2027110901, '踓').toCharArray(), 12333L, lIIl(416873160, -1955626193));
      II[4] = IlI(llII((short)15917, 1190742501, '踔').toCharArray(), 58220L, lIIl(416873163, 333911454));
      II[5] = IlI(llII((short)'蒋', 1357602484, '踕').toCharArray(), 85147L, lIIl(416873162, 1747293161));
      II[lIIl(416873173, -2137547841)] = IlI(llII((short)14002, -1753460771, '踖').toCharArray(), 36767L, lIIl(416873172, -779175717));
      II[lIIl(416873175, -1653718857)] = IlI(llII((short)23753, -1280674743, '踗').toCharArray(), 57512L, lIIl(416873174, -1549722348));
      II[lIIl(416873169, 252869408)] = IlI(llII((short)'ꃛ', -373553477, '踘').toCharArray(), 74178L, lIIl(416873168, -210867976));
      II[lIIl(416873171, 1786792038)] = IlI(llII((short)'ퟑ', 730337474, '踙').toCharArray(), 85880L, lIIl(416873170, -1153550102));
      II[lIIl(416873181, -1052279927)] = IlI(llII((short)'푮', 516585456, '踚').toCharArray(), 53280L, lIIl(416873180, 232514918));
      II[lIIl(416873183, 1040796219)] = IlI(llII((short)'\ufde5', 2112443143, '踛').toCharArray(), 96930L, lIIl(416873182, -84653407));
      II[lIIl(416873177, 150494444)] = IlI(llII((short)'벖', -1493930462, '踜').toCharArray(), 22688L, lIIl(416873176, 1549671403));
   }

   private float IlIl(class_310 var1) {
      if (!this.lII(var1)) {
         return ((Double)this.III.III()).floatValue();
      } else {
         class_243 var2 = var1.field_1724.method_33571();
         class_243 var3 = var1.field_1724.method_5828(1.0F).method_1029();
         double var4 = Math.max(0.1, (Double)this.IlI.III());
         class_243 var6 = var2.method_1019(var3.method_1021(var4));
         <undefinedtype> var7 = (<undefinedtype>)this.l.III();
         double var8 = Math.max((double)0.0F, (Double)this.Ill.III());
         double var10 = Math.max(0.1, (Double)this.lI.III());
         double var12 = (double)0.0F;

         for(class_1297 var15 : var1.field_1687.method_18112()) {
            if (var15 instanceof class_1309) {
               class_1309 var16 = (class_1309)var15;
               if (var16 != var1.field_1724 && var16.method_5805() && !var16.method_31481() && this.lIII(var16, var7) && !(var1.field_1724.method_5858(var16) > var4 * var4)) {
                  class_238 var17 = var16.method_5829().method_1014(var8);
                  if (var17.method_992(var2, var6).isPresent()) {
                     return ((Double)this.Il.III()).floatValue();
                  }

                  double var18 = this.llI(var2, var3, var17);
                  if (var18 <= var10) {
                     double var20 = (double)1.0F - var18 / var10;
                     var12 = Math.max(var12, this.IIll(var20));
                  }
               }
            }
         }

         float var22 = ((Double)this.III.III()).floatValue();
         if (var12 <= (double)0.0F) {
            return var22;
         } else {
            float var23 = ((Double)this.lIl.III()).floatValue();
            return (float)class_3532.method_16436(var12, (double)var22, (double)var23);
         }
      }
   }

   private double Illl(class_243 var1, class_243 var2) {
      double var3 = var2.method_1033();
      if (var3 <= 1.0E-6) {
         return (double)0.0F;
      } else {
         double var5 = class_3532.method_15350(var1.method_1026(var2.method_1021((double)1.0F / var3)), (double)-1.0F, (double)1.0F);
         return Math.toDegrees(Math.acos(var5));
      }
   }

   private boolean lIII(class_1309 var1, Object var2) {
      boolean var3 = var1 instanceof class_1657;
      return var2 == null.I || var2 == null.lI && var3 || var2 == null.II && !var3;
   }

   private static int lIIl(int var0, int var1) {
      return lll[var0 ^ 416873157] ^ var1 ^ var0;
   }

   private static String llII(short var0, int var1, char var2) {
      int var3 = var2 ^ '踐';
      char[] var4 = IIII[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])IIIl[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         IIIl[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 15570;
      int var9 = 0;

      do {
         int var10 = var4[var9] + 26711;
         var10 ^= 32247;
         var10 += 9844;
         var10 ^= 155;
         var10 -= 12952;
         var10 -= 41566;
         var10 ^= 41503;
         var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
