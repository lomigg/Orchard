package x;

import com.mojang.authlib.GameProfile;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1294;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_640;

@Environment(EnvType.CLIENT)
public final class llIIIIlI extends IIIIIIIlI {
   private final lIIIIl I;
   private <undefinedtype> l;
   private static String[] II;
   private final lIIIIl Il;
   private static final double lI = (double)144.0F;
   private final IIIllIIII ll;
   private final IlIIIlIlI<<undefinedtype>> III;
   private final Map<Integer, <undefinedtype>> IIl;
   private final lIIIIl IlI;
   private final lIIIIl Ill;
   private final lIIIIl lII;
   private final lIIIIl lIl;
   private final lIIIIl llI;
   private static final double lll = 0.005;
   private static final int IIII = 200;
   private final lIIIIl IIIl;
   private Object IIlI;
   private UUID IIll;
   private static final int[] IlII;
   private static final String[] IlIl;
   private static final Object[] IllI;

   public llIIIIlI() {
      super((Object)lIlIII.l(II[3]), lIllII.I, (Object)lIlIII.l(II[llII(-66078453, -516185738)]));
      this.III = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(II[llII(-66078454, 1673965662)]), <undefinedtype>.class, null.lI));
      this.llI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(II[0]), true));
      this.Il = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(II[2]), true));
      this.IIIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(II[4]), true));
      this.lII = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(II[llII(-66078455, 727312569)]), true));
      this.I = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(II[1]), true));
      this.IlI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(II[llII(-66078456, 1494628802)]), true));
      this.lIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(II[5]), true));
      this.Ill = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(II[llII(-66078449, -806764040)]), true));
      this.ll = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(II[llII(-66078450, 1100276127)]), (double)40.0F, (double)0.0F, (double)200.0F, (double)10.0F)).IIl(lIlIII.Il(II[llII(-66078451, 775098060)])));
      this.IIl = new HashMap();
   }

   public boolean ll(class_1657 var1) {
      if (this.IIIIIlI() && var1 != null && !var1.method_31481() && var1.method_5805()) {
         class_310 var2 = class_310.method_1551();
         if (this.IlI(var2) && var1 != var2.field_1724) {
            long var3 = var2.field_1687.method_75260();
            <undefinedtype> var5 = this.lIII(var2, var1, var3);
            boolean var6 = var5 != null && var3 - var5.I >= ((Double)this.ll.III()).longValue();
            if (var6 && (Boolean)this.llI.III() && var2.method_1562() != null) {
               class_640 var7 = var2.method_1562().method_2871(var1.method_5667());
               if (var7 == null) {
                  return true;
               }

               GameProfile var8 = var7.method_2966();
               GameProfile var9 = var1.method_7334();
               String var10 = var8 == null ? null : IIIIlII.II(var8);
               String var11 = var9 == null ? null : IIIIlII.II(var9);
               if (var10 == null || var11 == null || !var10.equalsIgnoreCase(var11)) {
                  return true;
               }
            }

            if ((Boolean)this.IIIl.III()) {
               GameProfile var12 = var1.method_7334();
               String var14 = var12 == null ? null : IIIIlII.II(var12);
               UUID var16 = var12 == null ? null : IIIIlII.I(var12);
               if (var14 == null || var14.isEmpty() || var14.length() < 2 || var14.length() > llII(-66078452, -1899036698) || var14.contains(lIlIII.Il(II[llII(-66078461, -611524654)])) || var14.contains(lIlIII.Il(II[llII(-66078462, -1562875876)])) || var14.contains(lIlIII.Il(II[llII(-66078463, -1485078084)])) || var14.contains(lIlIII.Il(II[llII(-66078464, 771527618)]))) {
                  return true;
               }

               if (var16 != null && var16.version() == 2) {
                  return true;
               }
            }

            if ((Boolean)this.lII.III() && var1.method_5767() && !var1.method_6059(class_1294.field_5905)) {
               return true;
            } else if (var6 && (Boolean)this.IlI.III() && this.IIII(var2, var1)) {
               return true;
            } else {
               if ((Boolean)this.lIl.III()) {
                  GameProfile var13 = var1.method_7334();
                  String var15 = var13 == null ? null : IIIIlII.II(var13);
                  if (this.IlII(var2, var1, var15)) {
                     return true;
                  }
               }

               if (!(Boolean)this.Ill.III() || var1.method_5628() >= 0 && var1.method_5628() < llII(-66078457, -1884965240)) {
                  return var5 != null && var5.lI.Ill((<undefinedtype>)this.III.III()).l();
               } else {
                  return true;
               }
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private boolean IlI(class_310 var1) {
      if (var1 != null && var1.field_1687 != null && var1.field_1724 != null) {
         UUID var2 = var1.field_1724.method_5667();
         if (this.IIlI != var1.field_1687 || !var2.equals(this.IIll)) {
            this.IIl.clear();
            this.IIlI = var1.field_1687;
            this.IIll = var2;
         }

         this.Illl();
         return true;
      } else {
         this.IlIl();
         return false;
      }
   }

   public void lIl() {
      this.IlIl();
   }

   private static void lII() {
      II[0] = lll(lllI(2145352027, '㎭', '⿏').toCharArray(), 53623L, llII(-66078458, 47383233));
      II[1] = lll(lllI(-115066440, '㨘', '⿎').toCharArray(), 18311L, llII(-66078459, 1887881398));
      II[2] = lll(lllI(-1891084069, '谹', '⿍').toCharArray(), 58615L, llII(-66078460, 1581421323));
      II[3] = lll(lllI(721450093, '쿊', '⿌').toCharArray(), 18101L, llII(-66078437, 1283909672));
      II[4] = lll(lllI(633371488, '邀', '⿋').toCharArray(), 48409L, llII(-66078438, 1902625754));
      II[5] = lll(lllI(-641713856, '᧹', '⿊').toCharArray(), 11761L, llII(-66078439, -743697182));
      II[llII(-66078440, -959742581)] = lll(lllI(2117148613, '箅', '⿉').toCharArray(), 20631L, llII(-66078433, 1174550959));
      II[llII(-66078434, -566091633)] = lll(lllI(863505828, '펷', '⿈').toCharArray(), 79182L, llII(-66078435, 137989481));
      II[llII(-66078436, 1096490950)] = lll(lllI(236198586, '嘿', '⿇').toCharArray(), 95954L, llII(-66078445, 179548842));
      II[llII(-66078446, 804604020)] = lll(lllI(-1105298929, '菬', '⿆').toCharArray(), 23876L, llII(-66078447, -1060891510));
      II[llII(-66078448, 1295927211)] = lll(lllI(-1447803486, 'ꐦ', '⿅').toCharArray(), 40390L, llII(-66078441, 514330621));
      II[llII(-66078442, 231336116)] = lll(lllI(-1951661087, '袔', '⿄').toCharArray(), 39165L, llII(-66078443, 262089039));
      II[llII(-66078444, -2116470632)] = lll(lllI(1106322979, 'ㅓ', '⿃').toCharArray(), 92153L, llII(-66078421, 543672627));
      II[llII(-66078422, 32231024)] = lll(lllI(1912219136, '㣉', '⿂').toCharArray(), 72407L, llII(-66078423, 1939130043));
      II[llII(-66078424, -1504504289)] = lll(lllI(-245862418, '叏', '⿁').toCharArray(), 76608L, llII(-66078417, 1461600652));
      II[llII(-66078418, 1032601189)] = lll(lllI(-1961745356, '涎', '⿀').toCharArray(), 64485L, llII(-66078419, -1002029384));
      II[llII(-66078420, 109393216)] = lll(lllI(590023292, '\ue993', '\u2fdf').toCharArray(), 51668L, llII(-66078429, -2052647421));
   }

   private boolean llI(class_1657 var1) {
      return var1.method_6128() || var1.method_5765() || var1.method_7325() || var1.method_31549().field_7477 && var1.method_31549().field_7479 || var1.method_31549().field_7479 || var1.method_5799() || var1.method_5869() || var1.method_5771() || var1.method_6101() || var1.method_6059(class_1294.field_5902) || var1.method_6059(class_1294.field_5906) || var1.method_6123();
   }

   private static String lll(char[] var0, long var1, int var3) {
      int var4 = llII(-66078430, -1760358409) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & llII(-66078431, -861332015);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private boolean IIII(class_310 var1, class_1657 var2) {
      if (var1.field_1724 != null && var2 != var1.field_1724) {
         double var3 = var2.method_5858(var1.field_1724);
         if (var3 > (double)144.0F) {
            return false;
         } else if (this.llI(var2)) {
            return false;
         } else {
            return !var2.method_24828() && Math.abs(var2.method_18798().field_1351) <= 0.005 && var2.field_6017 <= (double)0.0F;
         }
      } else {
         return false;
      }
   }

   public void lI() {
      this.IlIl();
   }

   private boolean IIll(class_1657 var1) {
      return !var1.method_24828() && !this.llI(var1) && Math.abs(var1.method_18798().field_1351) <= 0.005 && var1.field_6017 <= (double)0.0F;
   }

   private boolean IlII(class_310 var1, class_1657 var2, String var3) {
      GameProfile var4 = var2.method_7334();
      UUID var5 = var4 == null ? null : IIIIlII.I(var4);

      for(class_1657 var7 : var1.field_1687.method_18456()) {
         if (var7 != var2 && !var7.method_31481() && var7.method_5805()) {
            GameProfile var8 = var7.method_7334();
            String var9 = var8 == null ? null : IIIIlII.II(var8);
            UUID var10 = var8 == null ? null : IIIIlII.I(var8);
            boolean var11 = var3 != null && var9 != null && var3.equalsIgnoreCase(var9);
            boolean var12 = var5 != null && var5.equals(var10);
            if (var11 || var12) {
               return true;
            }
         }
      }

      return false;
   }

   private void IlIl() {
      this.IIl.clear();
      this.IIlI = null;
      this.IIll = null;
      this.l = null;
   }

   static {
      short var6 = 8765;
      String var7 = "ꢿ亏ď훃\ue58aꛨ㈢\uf74c뻛㞠䂯ຣ寷ｳⷧ쿕ᮝ\uee33\ueee5₴⽀獷\udede\ue1d2塧뼡뼎왊봛ƾⶌ\ueee3⁔\ue60e⬆痴絹戧ꉙ茞雬\ue416閰涏냙곺澀ꐬ녟Ｈ絫\uf0f4Ӆ䁣曪撇뙸췁뻘녇뙂\ud948\ue482쓏枘끹봰֩⺣駼撉令ꚭ㈷羒쨨\uea8b쥣ꘜ떯\uddce\ued3a您겡䲝⥰Ɒ毇볇刜ᯧ푼剕덟\ue19c٣쿓\ue721죢̔ꗠᦓ豕㮾圏\ue705䨭ࢃ묯䶦\u001c༥䄢ꎛ㖏쪁엺ꟲر⯆饆㓄瑲㍉脳揿鐷ꚓἢ鈁ㄚ뉊ⰶ◠ꭠ\uf029䝵砺愂\udab5\udcf2㲜䡗䊰雼\u2d77∽궼탣迨逗堟ꖅ䞏흅\udb45䜰ᷜ淤볢낏껿꣸猟賧\uf422갞ᵹᖜ\ue9bcᅟ㦞햩첀嘗傫煗䈵曋鯷\uf5c2조न쓕添葤ऻ\udc7f\ue96f뽩ꈎ셤\ue1c8୭㖧ꏔ壆눿\uf0bd☘瘲ꜷᅪᑑ✙룙衭᷐슽摀뙎㑡鏅寒ᑌ귑\ue5fb\ue1c7ဝ踠鉠뇥枼氄鰋轱楨\ud8bbခﰽ혈甔젮堬켬쨆叝႖틺풩䚥幪ꪹᖃ葆苕괊홨ⰶ硷갵ब莥煡Ҡ鿹맼竅孵Î⨧兮ﺼꖫ沨筆錧ई죡栋ꋩ݄䣵챳ꩱ엄澋\udf42\ue661\uf3ff咴ꁦ觹ㇵ헏칰굇鋔\udacc봹⌅싋Ṣ⨶씸崿ᜏ薸玈\ue66d씧䭸봁\uf77b\ue576璊\u202c⢘攘ɤ\udc99栩無썋ഥ뵀옥릗猔聬镗\uf4dcꥮ욏ஐ폕뺟镯";
      char[] var8 = "\u0014\u0018\u0014\f\u0018\u0018\b\bT\u001c\u0014\u0010\u0018\u0004\u0004\u0004\u0004".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            IlIl = var9;
            IllI = new Object[var9.length];
            int var2 = 697363738;
            byte[] var0 = "4¤õo¶YäHþÆ¼£\u008c\u0089mÜ\u001av\u0095ç\u0094\u000bµ\u0080û¬ZÜ[Q«à\u000e\u0013\u008bÛwG<\träÕ¨øcÇÖa (\u0095KõLÃç\u0087n\n\u0012 \u0003\u000b\u0081.%¶çØ¨\u0089[Zm×\u0013T)\u008f\u000fo'r\u000bÝt\u008c\u0088ç(B\u0094ÄKÈùLUÃúj\u001cu\u0017\u0005Ô¦\u0098¡\u0013«\u00ad\u0014-¢ØV¼³\u0004<ÆJTFl\u009a\u0080\u0087\u0099ÁÔt\u009aM@0}isÌB#\u0092¸÷xè\u0013j^Á,Ù\u0094Ó\u001aaf©d\u0084ºY\u0085\u009de\u00196I\u0015Õ¼1²".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IlII = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IlII[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            II = new String[llII(-66078432, 2319769)];
            lII();
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 3;
                     break;
                  case 1:
                     var10000 = 60;
                     break;
                  case 2:
                     var10000 = 28;
                     break;
                  case 3:
                     var10000 = 1;
                     break;
                  case 4:
                     var10000 = 91;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (this.IlI(var1)) {
         long var2 = var1.field_1687.method_75260();

         for(class_1657 var5 : var1.field_1687.method_18456()) {
            this.lIII(var1, var5, var2);
         }

         this.IIl.entrySet().removeIf((var2x) -> IIllIllI.IlI(var2, ((<undefinedtype>)var2x.getValue()).l, 200L));
      }
   }

   private void Illl() {
      Record var1 = new Record((<undefinedtype>)this.III.III(), (Boolean)this.llI.III(), (Boolean)this.Il.III(), (Boolean)this.IIIl.III(), (Boolean)this.lII.III(), (Boolean)this.I.III(), (Boolean)this.IlI.III(), (Boolean)this.lIl.III(), (Boolean)this.Ill.III(), Double.doubleToLongBits((Double)this.ll.III())) {
         private final long I;
         private final boolean l;
         private final boolean II;
         private final boolean Il;
         private final boolean lI;
         private final boolean ll;
         private final boolean III;
         private final boolean IIl;
         private final <undefinedtype> IlI;
         private final boolean Ill;

         public boolean I() {
            return this.III;
         }

         public boolean l() {
            return this.Ill;
         }

         public boolean II() {
            return this.l;
         }

         public boolean Il() {
            return this.II;
         }

         public boolean lI() {
            return this.lI;
         }

         public boolean ll() {
            return this.ll;
         }

         public boolean III() {
            return this.IIl;
         }

         public <undefinedtype> IIl() {
            return this.IlI;
         }

         public long IlI() {
            return this.I;
         }

         private {
            this.IlI = var1;
            this.l = var2;
            this.IIl = var3;
            this.Il = var4;
            this.III = var5;
            this.II = var6;
            this.ll = var7;
            this.lI = var8;
            this.Ill = var9;
            this.I = var10;
         }

         public boolean Ill() {
            return this.Il;
         }
      };
      if (!((<undefinedtype>)var1).equals(this.l)) {
         this.IIl.clear();
         this.l = var1;
      }

   }

   private <undefinedtype> lIII(class_310 var1, class_1657 var2, long var3) {
      if (var2 != null && var2 != var1.field_1724) {
         int var5 = var2.method_5628();
         Object var6 = (<undefinedtype>)this.IIl.get(var5);
         if (var6 == null || ((<undefinedtype>)var6).II != var2) {
            var6 = new Object(var2, var3) {
               private final long I;
               private long l;
               private final class_1657 II;
               private long Il = Long.MIN_VALUE;
               private final IIllIllI lI = new IIllIllI();

               private {
                  this.II = var1;
                  this.I = var2;
                  this.l = var2;
               }
            };
            this.IIl.put(var5, var6);
         }

         ((<undefinedtype>)var6).l = var3;
         if (((<undefinedtype>)var6).Il == var3) {
            return (<undefinedtype>)var6;
         } else {
            ((<undefinedtype>)var6).Il = var3;
            boolean var7 = var3 - ((<undefinedtype>)var6).I >= ((Double)this.ll.III()).longValue();
            boolean var8 = !(Boolean)this.llI.III() || var1.method_1562() == null || var1.method_1562().method_2871(var2.method_5667()) != null;
            GameProfile var9 = var2.method_7334();
            String var10 = var9 == null ? null : IIIIlII.II(var9);
            boolean var11 = !(Boolean)this.IIIl.III() || IIllIllI.III(var10);
            boolean var12 = (Boolean)this.lIl.III() && this.IlII(var1, var2, var10);
            boolean var13 = var2.method_5858(var1.field_1724) <= (double)144.0F;
            boolean var14 = !(Boolean)this.I.III() || this.llI(var2);
            boolean var15 = (Boolean)this.IlI.III() && var13 && this.IIll(var2);
            double var16 = Math.hypot(var2.method_18798().field_1352, var2.method_18798().field_1350);
            ((<undefinedtype>)var6).lI.Il(new Record(var3, var7, var8, var11, (Boolean)this.lII.III() && var13 && var2.method_5767() && !var2.method_6059(class_1294.field_5905), var12, var15, var14, var13, var2.method_23317(), var2.method_23318(), var2.method_23321(), var16) {
               private final boolean I;
               private final double l;
               private final boolean Il;
               private final boolean lI;
               private final boolean ll;
               private final double III;
               private final boolean IIl;
               private final boolean IlI;
               private final double Ill;
               private final long lII;
               private final boolean lIl;
               private final boolean llI;
               private final double lll;

               public {
                  this.lII = var1;
                  this.I = var3;
                  this.lI = var4;
                  this.IIl = var5;
                  this.IlI = var6;
                  this.lIl = var7;
                  this.Il = var8;
                  this.llI = var9;
                  this.ll = var10;
                  this.III = var11;
                  this.lll = var13;
                  this.l = var15;
                  this.Ill = var17;
               }

               public double I() {
                  return this.Ill;
               }

               public boolean l() {
                  return this.IlI;
               }

               public long II() {
                  return this.lII;
               }

               public boolean Il() {
                  return this.ll;
               }

               public double lI() {
                  return this.lll;
               }

               public double ll() {
                  return this.l;
               }

               public boolean III() {
                  return this.IIl;
               }

               public boolean IIl() {
                  return this.llI;
               }

               public boolean IlI() {
                  return this.lI;
               }

               public boolean Ill() {
                  return this.I;
               }

               public double lII() {
                  return this.III;
               }

               public boolean lIl() {
                  return this.Il;
               }

               public boolean llI() {
                  return this.lIl;
               }
            }, (<undefinedtype>)this.III.III());
            return (<undefinedtype>)var6;
         }
      } else {
         return null;
      }
   }

   private static int llII(int var0, int var1) {
      return IlII[var0 ^ -66078453] ^ var1 ^ var0;
   }

   private static String lllI(int var0, char var1, char var2) {
      int var3 = var2 ^ 12239;
      char[] var4 = IlIl[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])IllI[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         IllI[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 9428;
      int var9 = 0;

      do {
         int var10 = var4[var9] + 32347;
         var10 -= 10804;
         var10 += 48468;
         var10 -= 60536;
         var10 ^= 4463;
         var10 ^= 47810;
         var10 -= 64450;
         var10 -= 3367;
         var4[var9] = (char)(var10 ^ var8 ^ var1 ^ var0 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
