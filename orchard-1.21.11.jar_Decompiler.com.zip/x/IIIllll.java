package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_5250;
import net.minecraft.class_5251;

@Environment(EnvType.CLIENT)
public final class IIIllll {
   private static final int[] I;

   private IIIllll() {
   }

   private static class_124 I(char var0) {
      var0 = Character.toLowerCase(var0);
      class_124 var10000;
      switch (var0) {
         case '0':
            var10000 = class_124.field_1074;
            break;
         case '1':
            var10000 = class_124.field_1058;
            break;
         case '2':
            var10000 = class_124.field_1077;
            break;
         case '3':
            var10000 = class_124.field_1062;
            break;
         case '4':
            var10000 = class_124.field_1079;
            break;
         case '5':
            var10000 = class_124.field_1064;
            break;
         case '6':
            var10000 = class_124.field_1065;
            break;
         case '7':
            var10000 = class_124.field_1080;
            break;
         case '8':
            var10000 = class_124.field_1063;
            break;
         case '9':
            var10000 = class_124.field_1078;
            break;
         case ':':
         case ';':
         case '<':
         case '=':
         case '>':
         case '?':
         case '@':
         case 'A':
         case 'B':
         case 'C':
         case 'D':
         case 'E':
         case 'F':
         case 'G':
         case 'H':
         case 'I':
         case 'J':
         case 'K':
         case 'L':
         case 'M':
         case 'N':
         case 'O':
         case 'P':
         case 'Q':
         case 'R':
         case 'S':
         case 'T':
         case 'U':
         case 'V':
         case 'W':
         case 'X':
         case 'Y':
         case 'Z':
         case '[':
         case '\\':
         case ']':
         case '^':
         case '_':
         case '`':
         case 'g':
         case 'h':
         case 'i':
         case 'j':
         case 'p':
         case 'q':
         default:
            var10000 = null;
            break;
         case 'a':
            var10000 = class_124.field_1060;
            break;
         case 'b':
            var10000 = class_124.field_1075;
            break;
         case 'c':
            var10000 = class_124.field_1061;
            break;
         case 'd':
            var10000 = class_124.field_1076;
            break;
         case 'e':
            var10000 = class_124.field_1054;
            break;
         case 'f':
            var10000 = class_124.field_1068;
            break;
         case 'k':
            var10000 = class_124.field_1051;
            break;
         case 'l':
            var10000 = class_124.field_1067;
            break;
         case 'm':
            var10000 = class_124.field_1055;
            break;
         case 'n':
            var10000 = class_124.field_1073;
            break;
         case 'o':
            var10000 = class_124.field_1056;
            break;
         case 'r':
            var10000 = class_124.field_1070;
      }

      return var10000;
   }

   public static class_2561 l(String var0) {
      class_5250 var1 = class_2561.method_43473();
      StringBuilder var2 = new StringBuilder();
      class_2583 var3 = class_2583.field_24360;
      int var4 = 0;

      while(var4 < var0.length()) {
         char var5 = var0.charAt(var4);
         if (var5 == lI(561630524, -685123813) && var4 + 1 < var0.length()) {
            if (!var2.isEmpty()) {
               var1.method_10852(class_2561.method_43470(var2.toString()).method_10862(var3));
               var2.setLength(0);
            }

            String var6;
            char var7;
            if ((var7 = var0.charAt(var4 + 1)) == lI(561630525, -1321467136) && var4 + lI(561630526, -138330196) < var0.length() && II(var6 = var0.substring(var4 + 2, var4 + lI(561630527, 33247066)))) {
               int var10 = Integer.parseInt(var6, lI(561630520, 1727632287));
               var3 = var3.method_27703(class_5251.method_27717(var10));
               var4 += 8;
               continue;
            }

            class_124 var8 = I(var7);
            if (var8 != null) {
               if (var8 == class_124.field_1070) {
                  var3 = class_2583.field_24360;
               } else if (var8.method_543()) {
                  var3 = var3.method_27703(class_5251.method_27718(var8));
                  var3 = var3.method_10982(false).method_10978(false).method_30938(false).method_36140(false).method_36141(false);
               } else {
                  var3 = Il(var3, var8);
               }

               var4 += 2;
               continue;
            }
         }

         var2.append(var5);
         ++var4;
      }

      if (!var2.isEmpty()) {
         var1.method_10852(class_2561.method_43470(var2.toString()).method_10862(var3));
      }

      return var1;
   }

   private static boolean II(String var0) {
      if (var0.length() != lI(561630521, 715515156)) {
         return false;
      } else {
         for(int var1 = 0; var1 < lI(561630522, 306450262); ++var1) {
            char var2 = var0.charAt(var1);
            boolean var3 = var2 >= lI(561630523, -620118496) && var2 <= lI(561630516, 806994272) || var2 >= lI(561630517, -1693422361) && var2 <= lI(561630518, -872733227) || var2 >= lI(561630519, -1717720887) && var2 <= lI(561630512, -2091796989);
            if (!var3) {
               return false;
            }
         }

         return true;
      }
   }

   private static class_2583 Il(class_2583 var0, class_124 var1) {
      class_2583 var10000;
      switch (var1) {
         case field_1067 -> var10000 = var0.method_10982(true);
         case field_1056 -> var10000 = var0.method_10978(true);
         case field_1073 -> var10000 = var0.method_30938(true);
         case field_1055 -> var10000 = var0.method_36140(true);
         case field_1051 -> var10000 = var0.method_36141(true);
         default -> var10000 = var0;
      }

      return var10000;
   }

   private static int lI(int var0, int var1) {
      return I[var0 ^ 561630524] ^ var1 ^ var0;
   }

   static {
      int var2 = 1978198616;
      byte[] var0 = "\u0083¸ðYå\u00ad$F£P\u0018ÍUjh52h´ï~4ÂsFÕ(2\u008f\u0098\u0099sd\u0088æ5Ï\u0081Kë\u009fj\u0002ÝÍ\f\u008fç×À\u0091-".getBytes("ISO-8859-1");
      int var1 = var0.length / 4;
      I = new int[var1];
      int var3 = 0;
      int var4 = 0;

      do {
         int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
         var5 ^= var2;
         I[var4] = var5;
         var3 += 4;
         ++var4;
      } while(var4 < var1);

   }
}
