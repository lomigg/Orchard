package x;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_156;

@Environment(EnvType.CLIENT)
public final class IIllIIIIl {
   private static final long I;
   private static final Gson l;
   private static final long II;
   private final IIllIIl Il;
   private static final long lI;
   private static final long ll;
   private static final long III;
   private static final long IIl;
   private static final long IlI;
   private static final long Ill;
   private static final long lII;
   private static final long lIl;
   private static final long llI;
   private static final long lll;
   private static final int IIII = 524288;
   private static final <undefinedtype> IIIl;
   private static final long IIlI;
   private static final long IIll;
   private static final long IlII;
   private static final long IlIl;
   private static final long IllI;
   private static final Gson Illl;
   private static final long lIII;
   private static final <undefinedtype> lIIl;
   private static final long lIlI;
   private static final <undefinedtype> lIll;
   private static final <undefinedtype> llII;
   private static final long llIl;
   private static final long lllI;
   private static final int[] llll;
   private static final String[] IIIII;
   private static final Object[] IIIIl;

   public boolean l(String var1) {
      Path var2 = this.lI();
      if (var2 == null) {
         return false;
      } else {
         String var6 = lIlIII.Il(llII('ඪ', -1330894386, (short)18448));
         Path var3 = var2.resolve(var1 + var6);
         if (!Files.exists(var3, new LinkOption[0])) {
            return false;
         } else {
            try {
               class_156.method_668().method_60932(var3);
               return true;
            } catch (Exception var7) {
               return false;
            }
         }
      }
   }

   private static JsonObject II(JsonObject var0, JsonObject var1, boolean var2) {
      JsonObject var3 = new JsonObject();
      var3.addProperty(lIlIII.Il(llII('ඩ', -1847704991, (short)'釢')), var2 && lII(var1, lIlIII.l(llII('ඨ', 1221075190, (short)17389)).lll(), true));
      IIIl(var0, var3);
      var3.add(lIlIII.Il(llII('ද', 1188844007, (short)'\uf357')), new JsonObject());
      return var3;
   }

   private static void Il(JsonObject var0) {
      if (IIllIIl.lIlII(var0, lIl)) {
         JsonObject var1 = IIllIIl.IlIII(var0, lIl);
         if (var1 != null && var1.has(lIlIII.Il(llII('ථ', -927565775, (short)'\uf46d')))) {
            JsonObject var2 = var1.getAsJsonObject(lIlIII.Il(llII('ත', 2052419412, (short)18998)));
            long var3 = IIIl.lll();
            JsonElement var5 = IIIIIIIlI.IlIIIIl(var2, var3);
            if (var5 != null && var5.isJsonPrimitive()) {
               String var6 = var5.getAsString();
               if (lIlIII.Il(llII('ඬ', -1064760803, (short)'읳')).equalsIgnoreCase(var6)) {
                  IIIIIIIlI.IIIIIll(var2, var3, new JsonPrimitive(lIlIII.Il(llII('ඣ', -1700914798, (short)'鰇'))));
               } else {
                  if (lIlIII.Il(llII('ජ', 413943415, (short)18835)).equalsIgnoreCase(var6) || lIlIII.Il(llII('ඡ', 1883527679, (short)'葫')).equalsIgnoreCase(var6)) {
                     IIIIIIIlI.IIIIIll(var2, var3, new JsonPrimitive(lIlIII.Il(llII('ච', 289176537, (short)18108))));
                  }

               }
            }
         }
      }
   }

   private Path lI() {
      return this.Il.IIllI();
   }

   public String ll(IIllIlII var1) {
      JsonObject var2 = new JsonObject();
      JsonObject var3 = new JsonObject();

      for(IIIIIIIlI var5 : var1.IIIIlII()) {
         var3.add(IIllIIl.l(var5.IIlIllI()), var5.IlIlII());
      }

      var2.add(lIlIII.Il(llII('ට', 1632773831, (short)'\ue921')), var3);
      return Base64.getEncoder().encodeToString(Illl.toJson(var2).getBytes());
   }

   private static void III(JsonObject var0) {
      if (!IIllIIl.lIlII(var0, lIlI)) {
         JsonObject var1 = IIllIIl.IlIII(var0, lI);
         JsonObject var2 = IIllIIl.IlIII(var0, Ill);
         if (var1 != null || var2 != null) {
            JsonObject var3 = new JsonObject();
            var3.addProperty(lIlIII.Il(llII('ඦ', -1181342299, (short)23619)), lIl(var1) || lIl(var2));
            JsonElement var4 = lIII(var1, var2);
            if (var4 != null) {
               var3.add(lIlIII.Il(llII('ඥ', 1789144176, (short)'\uf1cd')), var4);
            }

            JsonObject var5 = new JsonObject();
            IIIIIIIlI.IIIIIll(var5, lIlIII.l(llII('ඤ', 418073809, (short)11427)).lll(), new JsonPrimitive(lll(var1, var2)));
            var3.add(lIlIII.Il(llII('ර', 1652766199, (short)18727)), var5);
            var3.add(lIlIII.Il(llII('ය', 467039309, (short)1831)), lIlI(var1));
            IIllIIl.IIlIlI(var0, lIlI, var3);
         }
      }
   }

   public boolean IIl(String var1, IIllIlII var2) {
      try {
         String var3 = var1 == null ? "" : var1.trim();
         if (!var3.isEmpty() && var3.length() <= lIll(-125657637, 530536133)) {
            if (var3.startsWith(lIlIII.Il(llII('ඹ', -1564518038, (short)'걱')))) {
               return this.IlII(var3, var2);
            } else {
               String var4 = new String(Base64.getDecoder().decode(var3), StandardCharsets.UTF_8);
               return var4.length() > lIll(-125657638, 224798623) ? false : this.IlII(var4, var2);
            }
         } else {
            return false;
         }
      } catch (IllegalArgumentException var5) {
         return false;
      }
   }

   private static void IlI(JsonObject var0) {
      IIllIIl.IIIlll(var0, IlII);
      if (IIllIIl.lIlII(var0, lllI)) {
         JsonObject var1 = IIllIIl.IlIII(var0, lllI);
         if (var1 == null) {
            IIllIIl.IIIlll(var0, lllI);
         } else {
            JsonObject var2 = var1.has(lIlIII.Il(llII('ම', 2111992679, (short)20936))) ? var1.getAsJsonObject(lIlIII.Il(llII('\u0dbf', 374040578, (short)4478))) : new JsonObject();
            boolean var3 = lIl(var1);
            if (!IIllIIl.lIlII(var0, IlI)) {
               IIllIIl.IIlIlI(var0, IlI, II(var1, var2, var3));
            }

            IIllIIl.IIIlll(var0, lllI);
         }
      }
   }

   private String Ill(IIllIlII var1) {
      JsonObject var2 = new JsonObject();
      JsonObject var3 = new JsonObject();

      for(IIIIIIIlI var5 : var1.IIIIlII()) {
         var3.add(IIllIIl.l(var5.IIlIllI()), var5.IlIlII());
      }

      var2.add(lIlIII.Il(llII('\u0dbe', -1571274784, (short)'谺')), var3);
      return l.toJson(var2);
   }

   private static boolean lII(JsonObject var0, long var1, boolean var3) {
      JsonElement var4 = IIIIIIIlI.IlIIIIl(var0, var1);
      if (var4 != null && var4.isJsonPrimitive()) {
         try {
            return var4.getAsBoolean();
         } catch (RuntimeException var6) {
            return var3;
         }
      } else {
         return var3;
      }
   }

   public IIllIIIIl(IIllIIl var1) {
      this.Il = var1;
   }

   private static boolean lIl(JsonObject var0) {
      return var0 != null && var0.has(lIlIII.Il(llII('ල', 374831071, (short)14007))) && var0.get(lIlIII.Il(llII('\u0dbc', 299725136, (short)201))).getAsBoolean();
   }

   private static void llI(JsonObject var0) {
      if (IIllIIl.lIlII(var0, llIl)) {
         JsonObject var1 = IIllIIl.IlIII(var0, llIl);
         if (var1 != null && var1.has(lIlIII.Il(llII('ඳ', -1843698531, (short)16512)))) {
            JsonObject var2 = var1.getAsJsonObject(lIlIII.Il(llII('\u0db2', -1085838045, (short)'ﾑ')));
            long var3 = lIIl.lll();
            JsonElement var5 = IIIIIIIlI.IlIIIIl(var2, var3);
            if (var5 != null && var5.isJsonPrimitive()) {
               String var6 = var5.getAsString();
               if (lIlIII.Il(llII('න', 1055686347, (short)7439)).equalsIgnoreCase(var6) || lIlIII.Il(llII('ධ', -1243345880, (short)12408)).equalsIgnoreCase(var6)) {
                  IIIIIIIlI.IIIIIll(var2, var3, new JsonPrimitive(lIlIII.Il(llII('භ', -142318604, (short)'酅'))));
               }

            }
         }
      }
   }

   private static String lll(JsonObject var0, JsonObject var1) {
      boolean var2 = lIl(var0);
      boolean var3 = IIII(var0);
      if (var2 && var3) {
         return lIlIII.Il(llII('බ', -1136721213, (short)798));
      } else if (var3) {
         return lIlIII.Il(llII('ඵ', 751323460, (short)28371));
      } else {
         return var2 ? lIlIII.Il(llII('ප', 2085897590, (short)21318)) : lIlIII.Il(llII('උ', -1459674924, (short)'굲'));
      }
   }

   private static boolean IIII(JsonObject var0) {
      if (var0 != null && var0.has(lIlIII.Il(llII('ඊ', 1728787626, (short)18775)))) {
         JsonObject var1 = var0.getAsJsonObject(lIlIII.Il(llII('ඉ', -53069200, (short)15782)));

         for(String var3 : var1.keySet()) {
            if (var1.get(var3).isJsonPrimitive()) {
               try {
                  String var4 = var1.get(var3).getAsString();
                  if (!var4.isBlank()) {
                     return true;
                  }
               } catch (UnsupportedOperationException var5) {
               }
            }
         }

         return false;
      } else {
         return false;
      }
   }

   private static void IIIl(JsonObject var0, JsonObject var1) {
      if (var0 != null && var0.has(lIlIII.Il(llII('ඈ', 1057956547, (short)6582)))) {
         var1.add(lIlIII.Il(llII('ඏ', 1143153394, (short)31015)), var0.get(lIlIII.Il(llII('ඎ', -1820297574, (short)16322))).deepCopy());
      }

   }

   public boolean IIlI(String var1, IIllIlII var2) {
      Path var3 = this.lI();
      if (var3 == null) {
         return false;
      } else {
         String var7 = lIlIII.Il(llII('ඍ', -930395080, (short)5522));
         Path var4 = var3.resolve(var1 + var7);
         if (!Files.exists(var4, new LinkOption[0])) {
            return false;
         } else {
            try {
               if (Files.size(var4) > 524288L) {
                  return false;
               } else {
                  String var5 = Files.readString(var4);
                  return this.IlII(var5, var2);
               }
            } catch (IOException var8) {
               return false;
            }
         }
      }
   }

   private boolean IlII(String var1, IIllIlII var2) {
      if (var1 != null && var1.length() <= lIll(-125657639, -534494230)) {
         try {
            JsonObject var3 = (JsonObject)l.fromJson(var1, JsonObject.class);
            if (var3 != null && var3.has(lIlIII.Il(llII('ඌ', 687747724, (short)'\ud8ab')))) {
               JsonObject var4 = var3.getAsJsonObject(lIlIII.Il(llII('ඃ', 1807430226, (short)25699)));
               IIllIIl.IIIll(var4, ll, II);
               IIllIIl.IIIll(var4, IlIl, lII);
               IIllIIl.IIIll(var4, IIlI, IIll);
               IIllIIl.IIIll(var4, IllI, llI);
               IIllIIl.IIIll(var4, III, lll);
               IIllIIl.IIIll(var4, I, lIII);
               III(var4);
               IlI(var4);
               Il(var4);
               IlIl(var4);
               llI(var4);

               for(IIIIIIIlI var6 : var2.IIIIlII()) {
                  JsonObject var7 = IIllIIl.IlIII(var4, var6.IIlIllI());
                  if (var7 != null) {
                     var6.IIl(var7);
                     var6.IIllIIl(var7);
                  }
               }

               return true;
            } else {
               return false;
            }
         } catch (Exception var8) {
            return false;
         }
      } else {
         return false;
      }
   }

   private static void IlIl(JsonObject var0) {
      if (IIllIIl.lIlII(var0, IIl)) {
         JsonObject var1 = IIllIIl.IlIII(var0, IIl);
         if (var1 != null && var1.has(lIlIII.Il(llII('ං', 1905463272, (short)31977)))) {
            JsonObject var2 = var1.getAsJsonObject(lIlIII.Il(llII('ඁ', -1286198980, (short)12365)));
            long var3 = lIll.lll();
            long var5 = llII.lll();
            if (IIIIIIIlI.IlIIIIl(var2, var3) != null) {
               IIIIIIIlI.IIllIII(var2, var5);
            } else {
               JsonElement var7 = IIIIIIIlI.IlIIIIl(var2, var5);
               if (var7 != null) {
                  if (var7 != null && var7.isJsonPrimitive() && var7.getAsJsonPrimitive().isNumber()) {
                     double var8 = var7.getAsDouble();
                     double var10 = Math.max((double)1.0F, Math.min((double)100.0F, (double)101.0F - var8));
                     IIIIIIIlI.IIIIIll(var2, var3, new JsonPrimitive(var10));
                  }

                  IIIIIIIlI.IIllIII(var2, var5);
               }
            }
         }
      }
   }

   public List<String> IllI() {
      Path var1 = this.lI();
      if (var1 != null && Files.isDirectory(var1, new LinkOption[0])) {
         ArrayList var2 = new ArrayList();

         try {
            Stream var3 = Files.list(var1);

            try {
               Stream var10000 = var3.filter((var0) -> var0.toString().endsWith(lIlIII.Il(llII('ණ', 1190725747, (short)11163)))).map((var0) -> {
                  String var1 = var0.getFileName().toString();
                  return var1.substring(0, var1.length() - 5);
               }).sorted(String.CASE_INSENSITIVE_ORDER);
               Objects.requireNonNull(var2);
               var10000.forEach(var2::add);
            } catch (Throwable var7) {
               if (var3 != null) {
                  try {
                     var3.close();
                  } catch (Throwable var6) {
                     var7.addSuppressed(var6);
                  }
               }

               throw var7;
            }

            if (var3 != null) {
               var3.close();
            }
         } catch (IOException var8) {
         }

         return var2;
      } else {
         return Collections.emptyList();
      }
   }

   public boolean Illl(String var1) {
      Path var2 = this.lI();
      if (var2 == null) {
         return false;
      } else {
         try {
            String var5 = lIlIII.Il(llII('\u0d80', -1667074412, (short)5022));
            return Files.deleteIfExists(var2.resolve(var1 + var5));
         } catch (IOException var6) {
            return false;
         }
      }
   }

   static {
      short var6 = 331;
      String var7 = "宫屮寧宦岁屶屹宯ヽ\u3040\u3101よで〸〯ヹ⢮⣚⣀⣦⢮⣨⣦⣟⣦⣍╹╹㧧㧐㦹㨇㦪㧚㦩㦸㧏㧗㦧㧝\uf35e\uf312\uf33d\uf346\uf35e\uf341\uf341\uf369\uf32d\uf350\uf30b\uf34a氎汢泭泶氎泱泱泹泽氠汛汚ᖆᣪᢕᢞᖆᢙᢙᢑᣅᢨᢳᢲ㸃㵀㴤㷾㷿㴢㵃㴥㷲㴡㵄㷫㴋㷳㴪㵂㴋㵥㷴㷽㸃㷭㴷㴷㹝㹣㹝㺈㹦㸽㺉㸢矁碁矕硺矀矢硾硾㒲㒭㒳㓄㒱㓐ㅲ㓪䶈䵀䴺䵖䶈䴫䴌䴍뵯삡뵷삞뵶삙삕삜삞뵸샂샂\ue316\ue402\ue318\ue3fe\ue316\ue310\ue3fe\ue3f7\ue3fe\ue325\ue361\ue361詻覭覢覚該詼覦覎覒覡觥觥璐瓐璙璝璘煳璝煽᥀᧬ᥛᥘ᥀ᥗᥗ᥏᥋\u192e᧭᧴ೲ\u0cfcొచೱఎొఛఙೱళఛఔ\u0c11\u0cf8ఙ\u0c49నఘఒ㘤㘔㙎㙎Ჾᥲ᳦᳝Ჾ᳡᳡ᴉ\u1ccdᲰᥫᲪ㶭㹹㷎㸅㶭㸊㸊㷢㷞㶻㺀㺁\u1b7fᚑᚧᚎᮆᛉᛅᚌᚎᚨᚲᚲࣿࠓࠩࡇࣿँࡇࠎࡇࠜ࠰࠰㟓㞿㟕㞻㟓㟍㞻㞺㞻㟨㞤㞤퉋툟툰툳퉋툴툴툼퉀퉝툞툗栒桞栩株栒栥栥棽棹栜桟桦℩™K⇿Kⅉ℠Ⅺ⇸∃∃ℬℤℛℯℯ썠썟썃쌘썢쎇썡쌡쌷썦쌜쌜幅庇幈庈帋帑幈帟廱帖廫幣开幉帋幍\ue5ea\ue5ae\ue5da\ue5a9\ue5e9\ue5d8\ue5da\ue5b1\ue5d1\ue5b7\ue66d\ue66d苠苤芰芣苣芲芰苛芻苍芗芗ᗕᗙᗥᖞᗞᗧᗥᗦᗆᘈᖢᖢ䍔䍒䍔䌖䍑䌭䍉䍉ᚧᛃᚔᚏᚧᚐᚐᚘᚤᮁᚺᚻ\ue793\ue7d7\ue7a8\ue86b\ue793\ue86c\ue86c\ue884\ue878\ue795\ue7e6\ue7dfṌḢḭṥṝṋḱḹḽḶḚḚ殽汫毜毤殬毂毘毐毌毗汳汳馃鳥鲚鲢鲪馄鲞鲖鳊鲙鲭鲭첆쯃첂쯋쮬쮻쮴챺핳\ud89d핻\ud89a핲\ud895\ud899\ud898\ud89a핼\ud8c6\ud8c6㔪㔜㘂㔣㗫㔤㔠㔡㔣㗽㔷㔷㯉㯝㱲㱱㯉㱶㱶㱾㲂㮟㯜㯕솬슀쇏쇔솬쇓쇓쇛쇟쇂쉹쉸떟뗢떣뗪똅뗚뗍떛铑铏铁钱铚钽铁钰钲铛锊钏钽钓锇钶铀铐铡铧铙铪铐钎᥍\u193c\u193fᥤᥗᤴᥖᥩᥦᦉ᤺᥀\u1943ᤫᥑᤷ\u1943᥍\u193dᤷ᪤\u1ae4᫅᪑\u1a8c\u1f7f᪑άὴάᬊὸὶ\u1ae4ᪧ᪒ὶ\u1ad8\u1a9f᪑᫇ᾀ\u1adc\u1adc쓯쓳쐶쐋쓷쐶쓷쐸쐐쐑쓾쐔쐠씀쑪쑪،وڅ۰ؤڅؤ؟تؐ۫ۼ۷ډ\u061cؗ܀إّّӻДӶИӶМԆшчъӯӱЍЋпп敤攫斉政斉敃教支攰攭敠敓攳攝敒攘뭦뭢뭝뭃뭦뭑뭚뭏묿무뭗뭘묶문묬묷무뭑묛묛\uf6ae\uf6ea\uf6e5\uf6cb\uf6ab\uf6d8\uf6b2\uf6b8\uf6cb\uf707\uf6cbﭳ૬\u0a12૬\u0a45૽\u0a4a\u0a0eੇਙਜਗૹਛਬਧ\u0a31❿䊿➂䊛䊩❽➁䊞❰䊤䋅䊢䊒䊣䊷䊷鶹鷖鶸鸅鶹鶶麁鶺힣\ud86c힢\ud86f힣힎\ud874\ud86f\ud884\ud884ퟤ힔\ud86d힝ퟗퟗᑇᒊᓴᔀᐤᑅᑋᐥᓶᓹᐋᐖᓿᓻᑏᑏ桠栝栻桧桋桢栤桂根栯桜梅栭栻栯桍栶桦栰栘㷵㴼㵊㴋㷶㴕㵅㴠㴕㷫㷱㴢㵊㷸㷸㴔皡盠筶筯益箁筱筼箆箁盉皍筶皩皟盕\ueee4\ueeac\ueec0\ueeaf\ueecc\ueeb4\ueede\ueeb0໘ນືຮ໑ື༉\u0ee9ເໍ໔ຬ\u0ee9ເ\u0eda\u0ea4☧☮♈♈✃♈♪☳쌻썠쌽썌쌲쎇썟쌬썗썋썀쏻쎇쏼쌹썪잭쟕쟑쟦잵쟝쟧쟡쟦쟣잺쟐쟠잼잯쟆ﰅ﮶\ufbc9﮶ﮋ﮸ﯤ﮵ﯩﯔﯧ﮵\ufbc4﮹ﮍﮍ값걖갛객갘갔걒갡煮瓧璙璘熂瓉煷璎瓉璙璎璲郖邘郧邯郗郑邫郃邷邬邠邠찌챢쳭찥찝찋쳱쳹쳽쳶챚챚\uf211\uf257\uf228\uf2f0\uf218\uf216\uf2ec\uf304\uf2f8\uf2eb\uf25f\uf25f筿盩皞皦筮简皚皒皎皕皱皱閃飆长风飩颾颱長恬忀徏徔恬従従徛徟悂徹徸嶽嶩州巕嶽巚巚巒巎嶫幰幱";
      char[] var8 = "ŃŃŇŇŇŇŇœŃŃŃŃŇŇŇŃŇşŏŇŇŇŇŇŇŇśŇśŇŇŇŃŇŇŇŇŇŃŇŇŇŇŃœşœśşśśşŇśśŃśśşśśŃśŃśśśŃŇŇŇŇŇŃŇŇ".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IIIII = var9;
            IIIIl = new Object[var9.length];
            int var2 = 2078064597;
            byte[] var0 = "\u009cÉtË\u008e0\u0005\u0090craæ6Ö)É".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            llll = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               llll[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            l = (new GsonBuilder()).setPrettyPrinting().create();
            Illl = new Gson();
            lI = lIlIII.l(llII('ඇ', 115876057, (short)7921)).lll();
            Ill = lIlIII.l(llII('ආ', 1596463702, (short)'\uf8b7')).lll();
            lIlI = lIlIII.l(llII('අ', -641070956, (short)32641)).lll();
            ll = lIlIII.l(llII('\u0d84', -1690807000, (short)'鏅')).lll();
            II = lIlIII.l(llII('ඛ', -1965348232, (short)6153)).lll();
            IlIl = lIlIII.l(llII('ක', 1887179595, (short)14488)).lll();
            lII = lIlIII.l(llII('\u0d99', -1559401427, (short)4226)).lll();
            IIlI = lIlIII.l(llII('\u0d98', -1193181479, (short)'륩')).lll();
            IIll = lIlIII.l(llII('ඟ', 543314275, (short)25170)).lll();
            llIl = lIlIII.l(llII('ඞ', -1228318053, (short)8251)).lll();
            lIIl = lIlIII.l(llII('ඝ', -1373999253, (short)8310));
            IllI = lIlIII.l(llII('ග', 245569315, (short)9605)).lll();
            llI = lIlIII.l(llII('ඓ', 857431735, (short)20055)).lll();
            III = lIlIII.l(llII('ඒ', 2085902710, (short)'\ue480')).lll();
            lll = lIlIII.l(llII('එ', -1057408509, (short)3190)).lll();
            I = lIlIII.l(llII('ඐ', -1451011986, (short)8801)).lll();
            lIII = lIlIII.l(llII('\u0d97', 2028143445, (short)'몭')).lll();
            lllI = lIlIII.l(llII('ඖ', -1440007454, (short)'逧')).lll();
            IlI = lIlIII.l(llII('ඕ', 1461848852, (short)'촡')).lll();
            lIl = lIlIII.l(llII('ඔ', -1433189230, (short)'\ud863')).lll();
            IIIl = lIlIII.l(llII('෫', 73613704, (short)3520));
            IlII = lIlIII.l(llII('෪', 1807317617, (short)1664)).lll();
            IIl = lIlIII.l(llII('෩', -1930736556, (short)'췽')).lll();
            llII = lIlIII.l(llII('෨', -2111956262, (short)29383));
            lIll = lIlIII.l(llII('෯', -318241306, (short)21885));
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static JsonElement lIII(JsonObject var0, JsonObject var1) {
      if (var0 != null && var0.has(lIlIII.Il(llII('෮', 452017229, (short)'苒')))) {
         return var0.get(lIlIII.Il(llII('෭', -2022998364, (short)23426))).deepCopy();
      } else {
         return var1 != null && var1.has(lIlIII.Il(llII('෬', -1442117075, (short)6379))) ? var1.get(lIlIII.Il(llII('\u0de3', -212000204, (short)'봋'))).deepCopy() : null;
      }
   }

   public boolean lIIl(String var1, IIllIlII var2) {
      if (var1 != null && !var1.isBlank() && var1.length() <= lIll(-125657640, -1249375280)) {
         Path var3 = this.lI();
         if (var3 == null) {
            return false;
         } else {
            try {
               Files.createDirectories(var3);
               String var6 = lIlIII.Il(llII('\u0de2', -1317054662, (short)375));
               Files.writeString(var3.resolve(var1 + var6), this.Ill(var2));
               return true;
            } catch (IOException var7) {
               return false;
            }
         }
      } else {
         return false;
      }
   }

   private static JsonObject lIlI(JsonObject var0) {
      return var0 != null && var0.has(lIlIII.Il(llII('\u0de1', 1128427729, (short)10761))) ? var0.getAsJsonObject(lIlIII.Il(llII('\u0de0', -632005748, (short)'뵂'))).deepCopy() : new JsonObject();
   }

   private static int lIll(int var0, int var1) {
      return llll[var0 ^ -125657637] ^ var1 ^ var0;
   }

   private static String llII(char var0, int var1, short var2) {
      int var3 = var0 ^ 3499;
      char[] var4 = IIIII[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])IIIIl[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         IIIIl[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 23367;
      int var9 = 0;

      do {
         int var10 = var4[var9] + 6084;
         var10 += 48757;
         var10 -= 671;
         var10 -= 20845;
         var10 -= 18232;
         var10 ^= 25286;
         var10 ^= 45223;
         var10 += 13881;
         var10 -= 59476;
         var4[var9] = (char)(var10 ^ var8 ^ var2 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
