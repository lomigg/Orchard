package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;

@Environment(EnvType.CLIENT)
public final class IIlIlII extends IIIIIIIlI {
   private final lIlIlllI I;
   private static final float l = 32.0F;
   private static final int II = 2;
   private static final float Il = 4.5F;
   private int lI;
   private static String[] ll;
   private static final float III = 8.0F;
   private int IIl;
   private final IIIllIIII IlI;
   private int Ill;
   private static final float lII = 7.5F;
   private static final float lIl = 6.0F;
   private static final int llI = 12;
   private static final float lll = 75.0F;
   private static final int[] IIII;
   private static final String[] IIIl;
   private static final Object[] IIlI;

   private void I(class_1657 var1, class_1657 var2) {
      class_243 var3 = var2.method_33571();
      class_243 var4 = var1.method_33571();
      double var5 = var4.field_1352 - var3.field_1352;
      double var7 = var4.field_1351 - var3.field_1351;
      double var9 = var4.field_1350 - var3.field_1350;
      double var11 = Math.sqrt(var5 * var5 + var9 * var9);
      float var13 = (float)(class_3532.method_15349(var9, var5) * (double)(180F / (float)Math.PI)) - 90.0F;
      float var14 = (float)(-(class_3532.method_15349(var7, var11) * (double)(180F / (float)Math.PI)));
      if (this.lI > 0) {
         --this.lI;
      } else {
         float var15 = var2.field_6283;
         float var16 = class_3532.method_15363(class_3532.method_15393(var13 - var15), -75.0F, 75.0F);
         float var17 = var15 + var16;
         float var18 = this.Il(var2.field_6241, var17, 8.0F);
         float var19 = var15;
         float var20 = class_3532.method_15393(var18 - var15);
         if (Math.abs(var20) > 32.0F) {
            var19 = this.Il(var15, var13, 4.5F);
            var20 = class_3532.method_15393(var18 - var19);
         }

         if (Math.abs(var20) > 75.0F) {
            float var21 = var18 - Math.copySign(75.0F, var20);
            var19 = this.Il(var19, var21, 7.5F);
            var20 = class_3532.method_15393(var18 - var19);
         }

         if (Math.abs(var20) > 75.0F) {
            var18 = var19 + Math.copySign(75.0F, var20);
         }

         float var22 = this.Il(var2.method_36455(), var14, 6.0F);
         var2.method_36456(var19);
         var2.field_6283 = var19;
         var2.field_6241 = var18;
         var2.method_36457(var22);
      }
   }

   static {
      short var6 = 7076;
      String var7 = "뮈랄礤踪\udf9dᶓ艭❞䬯툗꧁탆ᬁ\ue6f4殾畁ퟢ勑㖙褱\ue2e9\uea9a웾\udaebۅ笳䉷Ę樚\u0c5c앐ﴜ쉗㲮昂麳\ud9ae噳낧\ue5b7삋ﬔ䭼囨밄跲篂\u0381塾\uf1f4긗걜༣풮벛畏ユ\ue038Ꟙ㛷递☦ꪀ屍怂㯌瑷ᝠ軎\uefdeᩛ껑ァ䩹芥茖顴\ufdefᥦބ刚縌셃떜⢒另↶豈⨓黱\ueacb鄎藨ᕳ𤋮\ued70뿸␐瞛随썂\ued5a媪㢢䥾蔃霺茰錒◄⦷້ᑟ⺳㸄\uf74e";
      char[] var8 = "\b\b\u0010\bL".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            IIIl = var9;
            IIlI = new Object[var9.length];
            int var2 = -1203282563;
            byte[] var0 = "õ\u000eçÝn\u001cw±\u0005\u0013©\u0000\u0018\u001eÚª]Í7ÓÎÜ5\u0094!×À\u0090¦û°Ñ¹Õ³¥jâñc".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IIII = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IIII[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            ll = new String[IlI(1202954777, 184162495)];
            ll();
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 121;
                     break;
                  case 1:
                     var10000 = 56;
                     break;
                  case 2:
                     var10000 = 69;
                     break;
                  case 3:
                     var10000 = 78;
                     break;
                  case 4:
                     var10000 = 82;
                     break;
                  case 5:
                     var10000 = 59;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static String l(char[] var0, long var1, int var3) {
      int var4 = IlI(1202954776, -1739691469) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IlI(1202954779, -85502311);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (var1 != null && var1.field_1687 != null && var1.field_1724 != null) {
         class_1657 var2 = this.II(var1);
         if (var2 == null) {
            this.IIl = 0;
            this.Ill = -1;
            this.lI = 0;
         } else {
            if (this.Ill != var2.method_5628()) {
               this.Ill = var2.method_5628();
               this.lI = 2;
            }

            this.I(var1.field_1724, var2);
            if (++this.IIl >= IlI(1202954778, -404085311)) {
               this.IIl = 0;
               var2.method_6104(class_1268.field_5808);
            }

         }
      } else {
         this.IIl = 0;
      }
   }

   private class_1657 II(class_310 var1) {
      String var2 = ((String)this.I.III()).trim();
      if (var2.isEmpty()) {
         return null;
      } else {
         double var3 = (Double)this.IlI.III() * (Double)this.IlI.III();

         for(class_1657 var6 : var1.field_1687.method_18456()) {
            if (var6 != var1.field_1724 && var6.method_5477().getString().equalsIgnoreCase(var2) && var6.method_5858(var1.field_1724) <= var3) {
               return var6;
            }
         }

         return null;
      }
   }

   private float Il(float var1, float var2, float var3) {
      float var4 = class_3532.method_15393(var2 - var1);
      return Math.abs(var4) <= var3 ? var2 : var1 + Math.copySign(var3, var4);
   }

   public IIlIlII() {
      super((Object)lIlIII.l(ll[2]), lIllII.ll, (Object)lIlIII.l(ll[4]));
      this.I = (lIlIlllI)this.IIIlIll(new lIlIlllI(lIlIII.l(ll[3]), ll[5]));
      this.IlI = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(ll[1]), (double)8.0F, (double)1.0F, (double)64.0F, (double)0.5F)).IIl(lIlIII.Il(ll[0])));
      this.Ill = -1;
   }

   private static void ll() {
      ll[0] = l(lII(2094508212, -1689813351).toCharArray(), 37168L, IlI(1202954781, -1683902459));
      ll[1] = l(lII(2094508213, 464020838).toCharArray(), 76373L, IlI(1202954780, 623613401));
      ll[2] = l(lII(2094508214, -161996355).toCharArray(), 57301L, IlI(1202954783, -565718280));
      ll[3] = l(lII(2094508215, -1925230585).toCharArray(), 87456L, IlI(1202954782, -913772913));
      ll[4] = l(lII(2094508208, 1911884046).toCharArray(), 25637L, IlI(1202954769, 279811489));
      ll[5] = l("".toCharArray(), 48624L, IlI(1202954768, 330095812));
   }

   private static int IlI(int var0, int var1) {
      return IIII[var0 ^ 1202954777] ^ var1 ^ var0;
   }

   private static String lII(int var0, int var1) {
      int var3 = var0 ^ 2094508212;
      char[] var4 = IIIl[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IIlI[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IIlI[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 844849773;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 85;
               break;
            case 1:
               var9 = 244;
               break;
            case 2:
               var9 = 6;
               break;
            case 3:
               var9 = 92;
               break;
            case 4:
               var9 = 20;
               break;
            case 5:
               var9 = 84;
               break;
            case 6:
               var9 = 209;
               break;
            case 7:
               var9 = 149;
               break;
            case 8:
               var9 = 107;
               break;
            case 9:
               var9 = 106;
               break;
            case 10:
               var9 = 92;
               break;
            case 11:
               var9 = 41;
               break;
            case 12:
               var9 = 62;
               break;
            case 13:
               var9 = 186;
               break;
            case 14:
               var9 = 208;
               break;
            case 15:
               var9 = 38;
               break;
            case 16:
               var9 = 232;
               break;
            case 17:
               var9 = 206;
               break;
            case 18:
               var9 = 8;
               break;
            case 19:
               var9 = 88;
               break;
            case 20:
               var9 = 41;
               break;
            case 21:
               var9 = 204;
               break;
            case 22:
               var9 = 35;
               break;
            case 23:
               var9 = 204;
               break;
            case 24:
               var9 = 157;
               break;
            case 25:
               var9 = 63;
               break;
            case 26:
               var9 = 50;
               break;
            case 27:
               var9 = 228;
               break;
            case 28:
               var9 = 156;
               break;
            case 29:
               var9 = 128;
               break;
            case 30:
               var9 = 143;
               break;
            case 31:
               var9 = 233;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
