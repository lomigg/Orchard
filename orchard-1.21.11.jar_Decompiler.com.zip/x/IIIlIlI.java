package x;

import com.google.gson.JsonObject;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_4969;
import net.minecraft.class_638;
import net.minecraft.class_239.class_240;

@Environment(EnvType.CLIENT)
public final class IIIlIlI extends IIIIIIIlI {
   private final llllIlIl I;
   private final llllIlIl l;
   private final lIIIIl II;
   private final lIIIIl Il;
   private final llllIlIl lI;
   private long ll;
   private int III;
   private long IIl;
   private int IlI;
   private final lIIIIl Ill;
   private int lII;
   private final Map<class_2338, Long> lIl;
   private boolean llI;
   private class_2338 lll;
   private int IIII;
   private int IIIl;
   private <undefinedtype> IIlI;
   private long IIll;
   private class_2338 IlII;
   private Object IlIl;
   private int IllI;
   private final IlIIIlIlI<<undefinedtype>> Illl;
   private static final double lIII = 0.8;
   private final IIIllIIII lIIl;
   private boolean lIlI;
   private final IIIllIIII lIll;
   private static final int[] llII;
   private static final String[] llIl;
   private static final Object[] lllI;

   public void lllIl(class_310 var1) {
      if (this.IIIIIlI() && var1.field_1724 != null && var1.field_1724.method_5805()) {
         this.llI(var1);
         this.lII(var1);
         this.lIIl(var1);
         boolean var2 = var1.field_1690.field_1904.method_1434();
         if (this.IlIIl(var1)) {
            if (this.IIlI != null.lI) {
               this.IIllI();
               this.lIlI = true;
            }

            IllllIlI.IIIIllI(var1.field_1690.field_1904);
         } else if (this.IIlI != null.lI) {
            IllllIlI.lIllll(var1);
            this.IlII(var1);
         } else {
            if (this.lIlI || this.llI) {
               if (var2) {
                  IllllIlI.IIIIllI(var1.field_1690.field_1904);
                  return;
               }

               this.lIlI = false;
               this.llI = false;
            }

            if (this.Illl.III() == null.l) {
               class_3965 var4 = this.IlIl(var1);
               if (var4 != null && this.IllIl(var1, var4.method_17777())) {
                  this.lllI(var1, var4.method_17777(), this.IIll(var1, var4.method_17777()));
               }

            } else {
               if ((Boolean)this.Il.III() && var2 && var1.field_1724.method_6115()) {
                  class_3965 var3 = this.IlIl(var1);
                  if (var3 != null && this.IllIl(var1, var3.method_17777())) {
                     this.lllI(var1, var3.method_17777(), this.IIll(var1, var3.method_17777()));
                  }
               }

            }
         }
      } else {
         this.IllII();
      }
   }

   private boolean IlI(class_310 var1, class_2338 var2) {
      class_2338 var3 = var2.method_10062();
      if (!this.lIl.containsKey(var3)) {
         return false;
      } else if (var1.field_1687 != null && var1.field_1687.method_8320(var3).method_27852(class_2246.field_23152)) {
         return true;
      } else {
         this.lIl.remove(var3);
         return false;
      }
   }

   private void lII(class_310 var1) {
      class_638 var2 = var1 == null ? null : var1.field_1687;
      if (var2 != this.IlIl) {
         this.lIl.clear();
         this.IlII = null;
         this.IllI = lIIll(-1301302057, -1775081755);
         this.IlIl = var2;
      } else if (var1 != null && var1.field_1687 != null && !this.lIl.isEmpty()) {
         this.lIl.keySet().removeIf((var1x) -> !var1.field_1687.method_8320(var1x).method_27852(class_2246.field_23152));
      }
   }

   private void llI(class_310 var1) {
      int var2 = System.identityHashCode(var1.field_1724);
      if (this.III != var2) {
         this.III = var2;
         this.IllII();
      }
   }

   public void IIl(JsonObject var1) {
      super.IIl(var1);
      this.llIlIl(var1, lIlIII.Il(lIlII((short)6466, 2064476755, '㹘')), new llllIlIl[]{this.lI});
      this.llIlIl(var1, lIlIII.Il(lIlII((short)'꼕', -1550970314, '㹙')), new llllIlIl[]{this.lI});
      this.llIlIl(var1, lIlIII.Il(lIlII((short)'\uf1cb', 1418340781, '㹚')), new llllIlIl[]{this.lI});
      this.llIlIl(var1, lIlIII.Il(lIlII((short)'ﯵ', -840472456, '㹛')), new llllIlIl[]{this.lI});
      if (this.lI.IlII() == (double)55.0F && this.lI.IlI() == (double)60.0F) {
         this.lI.IIIl(new double[]{(double)0.0F, (double)0.0F});
      }

   }

   public boolean lll(class_310 var1, class_1268 var2, class_3965 var3) {
      if (this.IIIIIlI() && this.IIlI == null.lI && !this.IlIIl(var1) && var1 != null && var1.field_1724 != null && var1.field_1687 != null) {
         if (var2 == class_1268.field_5808 && var3 != null && var3.method_17783() == class_240.field_1332) {
            return !this.lIlI && !this.llI && this.IllIl(var1, var3.method_17777()) ? this.lllI(var1, var3.method_17777(), this.IIll(var1, var3.method_17777())) : false;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private void IIII(class_310 var1) {
      if (this.IlII == null) {
         if (var1 != null && var1.field_1724 != null && var1.field_1687 != null) {
            class_239 var3 = var1.field_1765;
            if (var3 instanceof class_3965) {
               class_3965 var2 = (class_3965)var3;
               if (var2.method_17783() == class_240.field_1332 && var1.field_1724.method_6047().method_31574(class_1802.field_23141)) {
                  class_2338 var6 = var2.method_17777();
                  class_2680 var4 = var1.field_1687.method_8320(var6);
                  if (var4.method_27852(class_2246.field_23152)) {
                     return;
                  }

                  class_2338 var5 = var4.method_45474() ? var6 : var6.method_10093(var2.method_17780());
                  if (var1.field_1687.method_8320(var5).method_45474()) {
                     this.IlII = var5.method_10062();
                     this.IllI = var1.field_1724.field_6012 + lIIll(-1301302058, 54248801);
                  }

                  return;
               }
            }
         }

      }
   }

   private int IIll(class_310 var1, class_2338 var2) {
      if (var1 != null && var1.field_1687 != null && var2 != null) {
         class_2680 var3 = var1.field_1687.method_8320(var2);
         return !var3.method_27852(class_2246.field_23152) ? 0 : (Integer)var3.method_11654(class_4969.field_23153);
      } else {
         return 0;
      }
   }

   public void lI() {
      this.IIllI();
      this.lIlI = false;
      this.llI = false;
      this.III = 0;
      this.lIl.clear();
      this.IlII = null;
      this.IllI = lIIll(-1301302059, -776751661);
      this.IlIl = null;
   }

   private void IlII(class_310 var1) {
      if (this.IIlI != null.lI) {
         if (var1 != null && var1.field_1724 != null && var1.field_1687 != null) {
            long var2 = System.currentTimeMillis();
            if (var2 - this.IIll > 3000L) {
               this.IIllI();
            } else {
               long var4 = var2 - this.ll;
               long var6 = this.IIl;
               switch (this.IIlI.ordinal()) {
                  case 1:
                     this.IIIII(var1);
                     break;
                  case 2:
                     if (var4 >= var6) {
                        this.IIlIl(var1);
                     }
                     break;
                  case 3:
                     if (var4 >= var6) {
                        this.IIlIl(var1);
                     }
                     break;
                  case 4:
                     if (var4 >= var6) {
                        this.IIlIl(var1);
                     }
                     break;
                  case 5:
                     if (var4 >= var6) {
                        this.IIlIl(var1);
                     }
                     break;
                  case 6:
                     if (var4 >= var6) {
                        this.Illll(var1);
                     }
               }

            }
         } else {
            this.IIllI();
         }
      }
   }

   private class_3965 IlIl(class_310 var1) {
      if (var1 != null) {
         class_239 var3 = var1.field_1765;
         if (var3 instanceof class_3965) {
            class_3965 var2 = (class_3965)var3;
            if (var2.method_17783() == class_240.field_1332) {
               return var2;
            }
         }
      }

      return null;
   }

   private class_3965 Illl(class_310 var1) {
      if (var1 != null && var1.field_1687 != null) {
         class_3965 var2 = this.IlIl(var1);
         if (var2 == null) {
            return null;
         } else {
            return this.lll != null && this.lll.equals(var2.method_17777()) && var1.field_1687.method_8320(var2.method_17777()).method_27852(class_2246.field_23152) ? var2 : null;
         }
      } else {
         return null;
      }
   }

   private boolean lIII(class_310 var1) {
      if (var1 != null && var1.field_1690 != null) {
         IllllIlI.IIIIllI(var1.field_1690.field_1904);
         this.lIlI = true;
         return true;
      } else {
         return false;
      }
   }

   private void lIIl(class_310 var1) {
      if (this.IlII != null && var1 != null && var1.field_1724 != null && var1.field_1687 != null) {
         if (var1.field_1687.method_8320(this.IlII).method_27852(class_2246.field_23152)) {
            this.lIl.put(this.IlII, System.currentTimeMillis());
            this.IlII = null;
            this.IllI = lIIll(-1301302060, -504735251);
         } else {
            if (var1.field_1724.field_6012 > this.IllI) {
               this.IlII = null;
               this.IllI = lIIll(-1301302061, 1363273093);
            }

         }
      }
   }

   public String Il() {
      long var1 = Math.round(this.lI.IlII() * 0.8);
      long var3 = Math.round(this.lI.IlI() * 0.8);
      String var10000;
      if (var1 == var3) {
         String var8 = lIlIII.Il(lIlII((short)6095, -1470557905, '㹜'));
         var10000 = var1 + var8;
      } else {
         String var10001 = lIlIII.Il(lIlII((short)'褏', -306177962, '㹝'));
         String var13 = lIlIII.Il(lIlII((short)28631, 690629599, '㹞'));
         String var10 = var10001;
         var10000 = var1 + var10 + var3 + var13;
      }

      String var5 = var10000;
      return var5;
   }

   private void llII(Object var1) {
      this.IIlI = var1;
      this.ll = System.currentTimeMillis();
      this.IIl = this.IIIIl(var1);
   }

   public void IllI(class_310 var1) {
      if (this.IIIIIlI() && var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1690 != null && var1.field_1690.field_1904 != null) {
         this.lIIl(var1);
         if (var1.field_1690.field_1904.method_1434() || IllllIlI.IllIlI(var1.field_1690.field_1904) > 0) {
            this.IIII(var1);
         }

      }
   }

   private boolean lllI(class_310 var1, class_2338 var2, int var3) {
      if (var1.field_1724 != null && !this.IlIIl(var1) && this.IllIl(var1, var2)) {
         int var4 = IllllIlI.lIIlI(var1.field_1724.method_31548());
         int var5 = this.lIIIl(var1.field_1724, var4);
         if (var5 == -1) {
            return false;
         } else {
            int var6 = (int)(Double)this.lIll.III();
            var6 = Math.max(1, Math.min(4, var6));
            int var7 = Math.max(0, var6 - Math.max(0, var3));
            if ((Boolean)this.II.III() && var7 <= 0) {
               return this.lIII(var1);
            } else {
               int var8 = var7 > 0 ? this.IlIll(var1.field_1724, class_1802.field_8801) : -1;
               if (var7 > 0 && var8 == -1) {
                  return false;
               } else {
                  this.lll = var2 == null ? null : var2.method_10062();
                  this.lII = var8;
                  this.IIIl = var5;
                  this.IIII = var4;
                  this.IlI = var7;
                  this.IIll = System.currentTimeMillis();
                  IllllIlI.IIIIllI(var1.field_1690.field_1904);
                  this.llI = true;
                  this.llII(null.II);
                  this.IlII(var1);
                  return true;
               }
            }
         }
      } else {
         return false;
      }
   }

   private void IIIII(class_310 var1) {
      if (this.IlI > 0) {
         this.llII(null.III);
      } else {
         this.llII(null.IIl);
      }

      this.IIlIl(var1);
   }

   public void lIl() {
      this.IIllI();
      this.lIlI = false;
      this.llI = false;
      this.lIl.clear();
      this.IlII = null;
      this.IllI = lIIll(-1301302062, 2062703993);
      this.IlIl = null;
   }

   public IIIlIlI() {
      super((Object)lIlIII.l(lIlII((short)'豋', -1445698713, '㹟')), lIllII.I, (Object)lIlIII.l(lIlII((short)22765, -1772195578, '㹐')));
      this.Illl = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(lIlII((short)'썠', -1950592891, '㹑')), <undefinedtype>.class, null.I));
      this.lIll = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(lIlII((short)'측', -1867425242, '㹒')), (double)1.0F, (double)1.0F, (double)4.0F, (double)1.0F));
      this.lI = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(lIlII((short)19383, -1212460611, '㹓')), (double)0.0F, (double)0.0F, (double)0.0F, (double)300.0F, (double)5.0F)).Ill(lIlIII.l(lIlII((short)'︊', -1122037754, '㹔'))));
      this.l = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(lIlII((short)'\udddf', 1977908788, '㹕')), (double)0.0F, (double)0.0F, (double)0.0F, (double)300.0F, (double)5.0F)).Ill(lIlIII.l(lIlII((short)'觝', -1895799832, '㹖'))));
      this.I = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(lIlII((short)'첧', -975103818, '㹗')), (double)0.0F, (double)0.0F, (double)0.0F, (double)300.0F, (double)5.0F)).Ill(lIlIII.l(lIlII((short)15886, 1648059353, '㹈'))));
      this.lIIl = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(lIlII((short)8185, -651753220, '㹉')), (double)0.0F, (double)0.0F, (double)9.0F, (double)1.0F));
      this.II = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lIlII((short)7131, -2124066479, '㹊')), false));
      this.Il = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lIlII((short)14941, -1914352052, '㹋')), false));
      this.Ill = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lIlII((short)19829, -1053349837, '㹌')), true));
      this.IIlI = null.lI;
      this.lIlI = false;
      this.llI = false;
      this.IIII = -1;
      this.lII = -1;
      this.IIIl = -1;
      this.IlI = 0;
      this.IIl = 0L;
      this.III = 0;
      this.lIl = new HashMap();
      this.IllI = lIIll(-1301302063, -650979723);
   }

   private long IIIIl(Object var1) {
      if (var1 != null.lI && var1 != null.II) {
         llllIlIl var10000;
         switch (var1.ordinal()) {
            case 0:
            case 1:
               var10000 = this.lI;
               break;
            case 2:
            case 4:
               var10000 = null;
               break;
            case 3:
            case 5:
            case 6:
               var10000 = null;
               break;
            default:
               throw new MatchException((String)null, (Throwable)null);
         }

         llllIlIl var2 = var10000;
         if (var1 == null.III) {
            return this.IIlII(this.l) + (this.IlllI(this.lII) ? this.IIlII(this.lI) : 0L);
         } else if (var1 == null.l) {
            return this.IIlII(this.l);
         } else if (var1 == null.IIl) {
            return this.IIlII(this.I) + (this.IlllI(this.IIIl) ? this.IIlII(this.lI) : 0L);
         } else {
            return var2 == null ? 0L : this.IIlII(var2);
         }
      } else {
         return 0L;
      }
   }

   private int IIIll(class_1657 var1) {
      for(int var2 = 0; var2 < lIIll(-1301302064, 471327450); ++var2) {
         if (this.IIlll(var1.method_31548().method_5438(var2))) {
            return var2;
         }
      }

      return -1;
   }

   private long IIlII(llllIlIl var1) {
      double var2 = var1.IlII();
      double var4 = var1.IlI();
      return var2 == var4 ? Math.max(0L, Math.round(var2 * 0.8)) : Math.max(0L, Math.round(ThreadLocalRandom.current().nextDouble(var2, var4) * 0.8));
   }

   private void IIlIl(class_310 var1) {
      class_3965 var2 = this.Illl(var1);
      if (var2 != null) {
         if (this.IIlI == null.II && this.IlI <= 0) {
            if (this.lIIlI(var1, var2, this.IIIl)) {
               lIllIIl var4 = lIllIIl.Il();
               if (var4 != null && var4.IIl() != null && var4.IIl().IIIIlI() != null) {
                  var4.IIl().IIIIlI().lll(var1, var2);
               }

               this.ll = System.currentTimeMillis();
               this.llII(null.Il);
            }
         } else {
            if (this.IIlI != null.II && this.IIlI != null.III && this.IIlI != null.l) {
               if (this.IIlI == null.IIl || this.IIlI == null.ll) {
                  if (!this.lIIlI(var1, var2, this.IIIl)) {
                     return;
                  }

                  lIllIIl var3 = lIllIIl.Il();
                  if (var3 != null && var3.IIl() != null && var3.IIl().IIIIlI() != null) {
                     var3.IIl().IIIIlI().lll(var1, var2);
                  }

                  this.ll = System.currentTimeMillis();
                  this.llII(null.Il);
               }
            } else {
               if (this.IlI <= 0) {
                  IllllIlI.IIIIllI(var1.field_1690.field_1904);
                  this.llII(null.IIl);
                  return;
               }

               if (!this.lIIlI(var1, var2, this.lII)) {
                  return;
               }

               this.ll = System.currentTimeMillis();
               --this.IlI;
               if (this.IlI > 0) {
                  this.llII(null.l);
               } else {
                  this.llII((Boolean)this.II.III() ? null.Il : null.IIl);
               }
            }

         }
      }
   }

   private void IIllI() {
      this.IIlI = null.lI;
      this.lIlI = false;
      this.lII = -1;
      this.IIIl = -1;
      this.IIII = -1;
      this.IlI = 0;
      this.IIl = 0L;
      this.lll = null;
   }

   private boolean IIlll(class_1799 var1) {
      return var1 == null || var1.method_7960() || !var1.method_31574(class_1802.field_8801);
   }

   private boolean IlIIl(class_310 var1) {
      return lIlIllll.lIIl(var1);
   }

   private int IlIll(class_1657 var1, class_1792 var2) {
      for(int var3 = 0; var3 < lIIll(-1301302049, 1462786932); ++var3) {
         if (var1.method_31548().method_5438(var3).method_31574(var2)) {
            return var3;
         }
      }

      return -1;
   }

   private void IllII() {
      this.IIlI = null.lI;
      this.lIlI = false;
      this.llI = false;
      this.lII = -1;
      this.IIIl = -1;
      this.IIII = -1;
      this.IlI = 0;
      this.IIl = 0L;
      this.lll = null;
   }

   private boolean IllIl(class_310 var1, class_2338 var2) {
      if (var1 != null && var1.field_1687 != null && var2 != null && var1.field_1687.method_8320(var2).method_27852(class_2246.field_23152)) {
         return !(Boolean)this.Ill.III() || this.IlI(var1, var2);
      } else {
         return false;
      }
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      this.lII(var1);
      this.lIIl(var1);
   }

   private boolean IlllI(int var1) {
      class_310 var2 = class_310.method_1551();
      return var2 != null && var2.field_1724 != null && var1 >= 0 && var1 < lIIll(-1301302050, -1711418023) && IllllIlI.IIlIl(var2) != var1;
   }

   private void Illll(class_310 var1) {
      this.IIllI();
   }

   public boolean lIIII() {
      return this.IIlI != null.lI;
   }

   public String I() {
      return "";
   }

   private int lIIIl(class_1657 var1, int var2) {
      int var3 = (int)Math.round((Double)this.lIIl.III()) - 1;
      if (var3 >= 0) {
         return this.IIlll(var1.method_31548().method_5438(var3)) ? var3 : -1;
      } else {
         int var4 = this.IlIll(var1, class_1802.field_8288);
         if (var4 != -1) {
            return var4;
         } else {
            class_1799 var5 = var1.method_31548().method_5438(var2);
            if (this.IIlll(var5)) {
               return var2;
            } else {
               int var6 = this.IlIll(var1, class_1802.field_23141);
               if (var6 != -1) {
                  return var6;
               } else {
                  int var7 = this.IIIll(var1);
                  return var7 != -1 ? var7 : var2;
               }
            }
         }
      }
   }

   public String llll() {
      return super.llll();
   }

   private boolean lIIlI(class_310 var1, class_3965 var2, int var3) {
      return var1 != null && var1.field_1724 != null && var1.field_1761 != null && var2 != null && var3 >= 0 && var3 < lIIll(-1301302051, 1590508983) ? IllllIlI.llIll(var1, this, var3, () -> {
         IllllIlI.lIllll(var1);
         class_1269 var2x = IllllIlI.lIlII(var1, class_1268.field_5808, var2);
         if (var2x != null && var2x.method_23665()) {
            var1.field_1724.method_6104(class_1268.field_5808);
            return true;
         } else {
            return false;
         }
      }) : false;
   }

   private static int lIIll(int var0, int var1) {
      return llII[var0 ^ -1301302057] ^ var1 ^ var0;
   }

   static {
      short var6 = 9912;
      String var7 = "꿱꽿꾪꼼꿌꽷꼀꽿꽍꼿꿏꽴꼈꾏꿽꼼ഡകഌഃഛ഻ദേങൣഛനൔണഩ൨\ue4e3\ue4dc\ue4b8\ue43b\ue4c4\ue48b\ue4a3\ue466\ue4bf\ue4c9\ue4c5\ue476\ue40e\ue479\ue4ef\ue436᎓ᎹᏭᏻ᎖ᎰᏇᎲ\u13ffᎊᎄᏈᏝᎸ᎗\u13ffᏡᏏᏪ᎕騶騺驯驘ꔺꋥꕲꔇ䂟䌯䃖䍵䡽䠀䧑䦾䡆䠜䡧䧮䧌䡎䦼䧻䡲䠭䡴䠁\uec94\uef1f\uef2d\uef51\uef50\uecec\uef75\uef09\uef39\uef5c\uef54\uef1b\uef6a\uef02\uef25\uef48\uef43\uecf4\uef7b\uecfa\uef3f\uecb7\uef52\uef0f\uef76\uef2b\uecca\uecb3\uef57\uef0a\uef68\uef0e\uecc0\uef4c\ueca2\uece7\uef7a\uecfc\uef16\uef43\uef78\uef0f\uec98\uecf8\uef3e\uef5c\uef55\uece7\uef76\uef0b\ueccb\uecb3\uef71\uef12\uef78\uef16\uecc0\uecba\uef50\uef01\uef5a\uecf8\uef19\uef4f\uecad\uef38\uef7d\uef2c\uef17\uecbf\uef7e\uef33改攝攄攫攃攣放敯攁数敗攚ά\u1f4eἮᲭὲἽἱ᳤᳙\u1f4eἛὖ뇩뇭녔뇉뇖녯뇺놛놼넵넽놜넝녶뇩놜櫭橡檨檛씜얣앗엀씧앤엜얝얠엖씪얍역얚얐엩뜥뜩띠띃꒪꒰ꓠꓢ꒛꒹\ua4ce꒷ꒆꓳ\ua48d꓁ꓘ꒱\ua48eꓶꓸꓚꓓ꒬ᄍᆁᅈᇻ\uf722\uf728\uf778\uf70a\uf703\uf721\uf756\uf73f\uf70e\uf77b\uf715\uf74e\uf74e\uf739\uf702\uf773킀팼탐퍎킦팍킈팣팱퍗퍼팽퍐팼탉퍢잀옦쟖잷잩옿잟옅옴완왩옌↤↛→ↂ⇇↻↠⇍↋↩⇧⇜⇑⇆⇭⇖";
      char[] var8 = "\u0010\u0010\u0010\u0014\u0004\u0004\u0004\u0010H\f\f\u0010\u0004\u0010\u0004\u0014\u0004\u0010\u0010\f\u0010".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            llIl = var9;
            lllI = new Object[var9.length];
            int var2 = -1176891562;
            byte[] var0 = "\u001d\u0087Ýd\b\u008e~õZ\u0006\u000ePj_âoÚô^\u0000ñGæýR\u0087mò\u0017¢YU\\\u0085àô\u0092HnØUx\u00865".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            llII = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               llII[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 53;
                     break;
                  case 1:
                     var10000 = 74;
                     break;
                  case 2:
                     var10000 = 121;
                     break;
                  case 3:
                     var10000 = 12;
                     break;
                  case 4:
                     var10000 = 23;
                     break;
                  case 5:
                     var10000 = 90;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static String lIlII(short var0, int var1, char var2) {
      int var3 = var2 ^ 15960;
      char[] var4 = llIl[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])lllI[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         lllI[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 21917;
      int var9 = 0;

      do {
         int var10 = var4[var9] - 14649;
         var10 -= 1242;
         var10 -= 28696;
         var10 += 7182;
         var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
