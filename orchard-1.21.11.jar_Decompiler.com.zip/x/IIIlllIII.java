package x;

import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class IIIlllIII {
   private static final int[] I;

   public static Color I(Color var0, Color var1, double var2) {
      double var4 = Math.max((double)0.0F, Math.min((double)1.0F, var2));
      int var6 = (int)Math.round((double)var0.getRed() + (double)(var1.getRed() - var0.getRed()) * var4);
      int var7 = (int)Math.round((double)var0.getGreen() + (double)(var1.getGreen() - var0.getGreen()) * var4);
      int var8 = (int)Math.round((double)var0.getBlue() + (double)(var1.getBlue() - var0.getBlue()) * var4);
      int var9 = (int)Math.round((double)var0.getAlpha() + (double)(var1.getAlpha() - var0.getAlpha()) * var4);
      return new Color(var6, var7, var8, var9);
   }

   public static Color l(Color var0, double var1) {
      return I(var0, Color.WHITE, var1);
   }

   public static Color II(double var0) {
      double var2 = Math.max((double)0.0F, Math.min((double)1.0F, var0));
      return I(new Color(IIl(-1754303971, -871869091), IIl(-1754303972, 513111733), IIl(-1754303969, 1047862919)), new Color(IIl(-1754303970, 973216064), IIl(-1754303975, 1295760587), IIl(-1754303976, 1816318115)), var2);
   }

   private IIIlllIII() {
   }

   public static Color Il(Color var0, double var1) {
      return I(var0, Color.BLACK, var1);
   }

   public static int lI(int var0, int var1) {
      return Math.max(0, Math.min(IIl(-1754303973, 399234550), var1)) << IIl(-1754303974, -2046022977) | var0 & IIl(-1754303979, -1549578597);
   }

   public static Color ll(int var0, int var1) {
      double var2 = Math.max((double)0.0F, Math.min((double)1.0F, (double)var0 / (double)Math.max(1, var1)));
      return I(new Color(IIl(-1754303980, 631107910), IIl(-1754303977, -1205750084), IIl(-1754303978, -1849179757)), new Color(IIl(-1754303983, -1073870947), IIl(-1754303984, 671296960), IIl(-1754303981, -388043596)), var2);
   }

   public static Color III(Color var0, int var1) {
      return new Color(var0.getRed(), var0.getGreen(), var0.getBlue(), Math.max(0, Math.min(IIl(-1754303982, 268813605), var1)));
   }

   private static int IIl(int var0, int var1) {
      return I[var0 ^ -1754303971] ^ var1 ^ var0;
   }

   static {
      int var2 = -1141593996;
      byte[] var0 = "à\u0093\u008fË2\u000e¬\u009d\u0012îÄ¬\u0016\u0099Ãza fz@Ù\n·;P\u000ffª\u0097ðÉ\u008fÇk\u0005\t\u0006+v\u0094ºl\u0003½\\\u001b\u0089\u0093eÝ\u0007\u0004\u0098÷äÄE6\u0093<\u009e\u001f¼".getBytes("ISO-8859-1");
      int var1 = var0.length / 4;
      I = new int[var1];
      int var3 = 0;
      int var4 = 0;

      do {
         int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
         var5 ^= var2;
         I[var4] = var5;
         var3 += 4;
         ++var4;
      } while(var4 < var1);

   }
}
