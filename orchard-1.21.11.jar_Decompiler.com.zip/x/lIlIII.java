package x;

import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;
import java.util.function.IntConsumer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class lIlIII {
   private static final byte[] I;
   private static final SecureRandom l;
   private static final int[] II;

   private static boolean I(byte var0) {
      return (var0 & IIlI(-1539983383, 1755070646)) == IIlI(-1539983384, 51251269);
   }

   public static <undefinedtype> l(String var0) {
      return var0 != null && !var0.isEmpty() ? Ill(var0) : null.l;
   }

   static {
      int var2 = -271752865;
      byte[] var0 = "#d\u0096ÀHöÞr\u0093Õ\u0016\u001d\u0094\u0094\u00adD`\u007f¤üæ¿¬Q_æ¾±½\u0098\u001fTÚ\u007f\u0017\u0098/Tä82ðx\u0093¸E¹PÑCXÎu\u0014Å0\u009f\f(XàÞ2\u008a\u009f©ú\u0098\u0005¨\u0012\u0080±·Xú Ç(\u00852èÏ^°H\u0002MB\u000bWk¯d\u009eÃ\u0091\b\u0086\u000b¼ÒC\u008do`\u0080Õgú\u001d\u0098Ô¢\u001bØáJ:x@Ì\u0095¡R\u0012X\u001e)\n\u0014âW»ûÓÞ\u0001\u0013Ò\u0000\u0089·d}Î.¯ôi\u0006Nd½X´G_ì\u0098ý#È\u0012\u0005\b\u0081Øa\u0006\n\u009b\u009b\u0013½g8JYs\u0082&>\u009b\u0085®í\u0016dþ\u009dG".getBytes("ISO-8859-1");
      int var1 = var0.length / 4;
      II = new int[var1];
      int var3 = 0;
      int var4 = 0;

      do {
         int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
         var5 ^= var2;
         II[var4] = var5;
         var3 += 4;
         ++var4;
      } while(var4 < var1);

      I = lII();
      l = new SecureRandom();
   }

   public static long II(String var0) {
      long var1 = -3750763034362895579L;
      if (var0 == null) {
         return var1;
      } else {
         int var4;
         for(int var3 = 0; var3 < var0.length(); var3 += Character.charCount(var4)) {
            var4 = var0.codePointAt(var3);
            var1 ^= (long)var4;
            var1 *= 1099511628211L;
         }

         return var1;
      }
   }

   private lIlIII() {
   }

   public static String Il(String var0) {
      return var0 != null && !var0.isEmpty() ? l(var0).lIlI() : "";
   }

   private static int lI(byte[] var0, int var1, int var2) {
      int var3 = 0;

      for(int var4 = var1; var4 < var2; ++var3) {
         var4 += ll(var0, var4, var2);
      }

      return var3;
   }

   private static int ll(byte[] var0, int var1, int var2) {
      int var3 = var0[var1] & IIlI(-1539983381, -668090282);
      if (var3 < IIlI(-1539983382, -546538639)) {
         return 1;
      } else if (var3 >= IIlI(-1539983379, 730296972) && var3 <= IIlI(-1539983380, -1387824579) && var1 + 1 < var2 && I(var0[var1 + 1])) {
         return 2;
      } else {
         if (var3 >= IIlI(-1539983377, 337537249) && var3 <= IIlI(-1539983378, -161429238) && var1 + 2 < var2 && I(var0[var1 + 1]) && I(var0[var1 + 2])) {
            int var4 = var0[var1 + 1] & IIlI(-1539983391, -1853373991);
            if ((var3 != IIlI(-1539983392, 1689006695) || var4 >= IIlI(-1539983389, 2030612111)) && (var3 != IIlI(-1539983390, -205689088) || var4 <= IIlI(-1539983387, -1698984213))) {
               return 3;
            }
         }

         if (var3 >= IIlI(-1539983388, 1055658875) && var3 <= IIlI(-1539983385, -722141676) && var1 + 3 < var2 && I(var0[var1 + 1]) && I(var0[var1 + 2]) && I(var0[var1 + 3])) {
            int var5 = var0[var1 + 1] & IIlI(-1539983386, -1423514420);
            if ((var3 != IIlI(-1539983367, -732877618) || var5 >= IIlI(-1539983368, 1313916087)) && (var3 != IIlI(-1539983365, -95449430) || var5 <= IIlI(-1539983366, 1799356079))) {
               return 4;
            }
         }

         return 1;
      }
   }

   public static <undefinedtype> III(String var0) {
      return null.lIl(var0);
   }

   private static void IIl(byte[] var0, int var1, int var2, IntConsumer var3) {
      int var5;
      for(int var4 = var1; var4 < var2; var4 += var5) {
         var5 = ll(var0, var4, var2);
         int var6 = var0[var4] & IIlI(-1539983363, 2031098115);
         int var7;
         if (var5 == 1) {
            var7 = var6 < IIlI(-1539983364, -72297362) ? var6 : IIlI(-1539983361, 166952502);
         } else if (var5 == 2) {
            var7 = (var6 & IIlI(-1539983362, -459519875)) << IIlI(-1539983375, -621784925) | var0[var4 + 1] & IIlI(-1539983376, -148204259);
         } else if (var5 == 3) {
            var7 = (var6 & IIlI(-1539983373, 613963382)) << IIlI(-1539983374, 738380601) | (var0[var4 + 1] & IIlI(-1539983371, -1621439155)) << IIlI(-1539983372, -1431114539) | var0[var4 + 2] & IIlI(-1539983369, 187974454);
         } else {
            var7 = (var6 & IIlI(-1539983370, 434802352)) << IIlI(-1539983415, 1660076646) | (var0[var4 + 1] & IIlI(-1539983416, 474164603)) << IIlI(-1539983413, -1778793142) | (var0[var4 + 2] & IIlI(-1539983414, 1265721806)) << IIlI(-1539983411, 909572155) | var0[var4 + 3] & IIlI(-1539983412, -1080962846);
         }

         var3.accept(var7);
      }

   }

   private static boolean IlI(int var0, int var1) {
      if (var0 == var1) {
         return true;
      } else {
         int var2 = Character.toUpperCase(var0);
         int var3 = Character.toUpperCase(var1);
         return var2 == var3 || Character.toLowerCase(var2) == Character.toLowerCase(var3);
      }
   }

   private static <undefinedtype> Ill(String var0) {
      byte[] var1 = Base64.getDecoder().decode(var0);

      <undefinedtype> var6;
      try {
         for(int var2 = 0; var2 < var1.length; ++var2) {
            var1[var2] ^= I[var2 & IIlI(-1539983409, 793087531)];
         }

         var6 = null.lI(var1);
      } finally {
         Arrays.fill(var1, (byte)0);
      }

      return var6;
   }

   private static byte[] lII() {
      int var0 = IIlI(-1539983410, 1453069844);
      byte[] var1 = new byte[IIlI(-1539983423, -1227153764)];

      for(int var2 = 0; var2 < var1.length; ++var2) {
         var0 = var0 * IIlI(-1539983424, 1336547698) + 1;
         var1[var2] = (byte)(var0 >> IIlI(-1539983421, 721345551));
      }

      return var1;
   }

   public static long lIl(String var0) {
      long var1 = -3750763034362895579L;
      if (var0 == null) {
         return var1;
      } else {
         int var4;
         for(int var3 = 0; var3 < var0.length(); var3 += Character.charCount(var4)) {
            var4 = var0.codePointAt(var3);
            var1 ^= (long)Character.toLowerCase(var4);
            var1 *= 1099511628211L;
         }

         return var1;
      }
   }

   public static boolean llI(String var0) {
      if (var0 != null && !var0.isEmpty()) {
         try {
            byte[] var1 = Base64.getDecoder().decode(var0);
            if (var1.length == 0) {
               return false;
            } else {
               for(int var2 = 0; var2 < var1.length; ++var2) {
                  var1[var2] ^= I[var2 & IIlI(-1539983422, -789877771)];
               }

               CharsetDecoder var7 = StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT);
               CharBuffer var3 = var7.decode(ByteBuffer.wrap(var1));
               if (var3.length() == 0) {
                  return false;
               } else {
                  for(int var4 = 0; var4 < var3.length(); ++var4) {
                     char var5 = var3.charAt(var4);
                     if (var5 == IIlI(-1539983419, 1941073940) || Character.isISOControl(var5) && var5 != IIlI(-1539983420, -908138486) && var5 != IIlI(-1539983417, -833209469) && var5 != IIlI(-1539983418, 788941783)) {
                        return false;
                     }
                  }

                  return true;
               }
            }
         } catch (Exception var6) {
            return false;
         }
      } else {
         return false;
      }
   }

   private static int lll(CharSequence var0) {
      int var1 = 0;

      for(int var2 = 0; var2 < var0.length(); ++var1) {
         int var3 = Character.codePointAt(var0, var2);
         var2 += Character.charCount(var3);
      }

      return var1;
   }

   private static int IIII(byte[] var0, int var1) {
      int var2 = 0;

      for(int var3 = var1; var2 < var0.length && var3 > 0; --var3) {
         var2 += ll(var0, var2, var0.length);
      }

      return var2;
   }

   public static <undefinedtype> IIIl(Object var0) {
      if (var0 instanceof <undefinedtype> var4) {
         return var4;
      } else if (var0 == null) {
         return null.l;
      } else {
         String var1 = var0.toString();
         if (var1.isEmpty()) {
            return null.l;
         } else {
            if (llI(var1)) {
               try {
                  return l(var1);
               } catch (Exception var3) {
               }
            }

            return null.lIl(var1);
         }
      }
   }

   private static int IIlI(int var0, int var1) {
      return II[var0 ^ -1539983383] ^ var1 ^ var0;
   }
}
