package x;

import java.util.Objects;
import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_3966;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_7923;
import net.minecraft.class_9362;

@Environment(EnvType.CLIENT)
public final class lIIIlI extends IIIIIIIlI {
   private final lIIIIl I;
   private final IIIllIIII l;
   private long II;
   private final IIIllIIII Il;
   private double lI;
   private final llllIlIl ll;
   private static final long III = 325L;
   private boolean IIl;
   private final llllIlIl IlI;
   private long Ill;
   private boolean lII;
   private final llllIlIl lIl;
   private boolean llI;
   private final lIIIIl lll;
   private final lIIIIl IIII;
   private final lIIIIl IIIl;
   private int IIlI;
   private final IlIIIlIlI<<undefinedtype>> IIll;
   private int IlII;
   private final llllIlIl IlIl;
   private final lIIIIl IllI;
   private final lIIIIl Illl;
   private final IIIllIIII lIII;
   private double lIIl;
   private Object lIlI;
   private final IlIIIlIlI<<undefinedtype>> lIll;
   private final lllIIlIl llII;
   private final lIlllII llIl;
   private final lIIIIl lllI;
   private <undefinedtype> llll;
   private final lIIIIl IIIII;
   private double IIIIl;
   private int IIIlI;
   private static final int[] IIIll;
   private static final String[] IIlII;
   private static final Object[] IIlIl;

   private void ll(class_310 var1) {
      if (this.llI) {
         this.llI = false;
      }

      if (this.lII && var1 != null && var1.field_1724 != null && this.lII(var1)) {
         this.IIIIl(var1);
      }

      this.llll = null.ll;
      this.IIlI = IIlIII(-730607845, -2014091263);
      this.Ill = 0L;
      this.lII = false;
   }

   private boolean IlI(class_1309 var1) {
      if (this.lIll.III() != null.II) {
         return true;
      } else if (this.llIl == null) {
         return true;
      } else {
         class_1309 var2 = this.llIl.Ill();
         return var2 != null && var2.method_5805() && !var2.method_31481() ? this.IllII(var1) : true;
      }
   }

   private boolean lII(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         for(class_1268 var5 : class_1268.values()) {
            class_1799 var6 = var1.field_1724.method_5998(var5);
            if (!var6.method_7960() && IllllIlI.IlllII(var6)) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   private double llI(llllIlIl var1) {
      double var2 = var1.IlII();
      double var4 = var1.IlI();
      return var2 == var4 ? var2 : ThreadLocalRandom.current().nextDouble(var2, var4);
   }

   public void lI() {
      this.llII();
   }

   private boolean lll(class_310 var1, class_1309 var2) {
      if (IllllIlI.lIllI(var1) <= 0 && IllllIlI.IIIIlII(var1) <= 0) {
         class_1799 var3 = var1.field_1724.method_6047();
         float var4 = var1.field_1724.method_7261(1.0F);
         float var5 = (float)this.IIIllI(var3);
         if (var4 < var5) {
            return false;
         } else if (this.IIlII(var3)) {
            return !this.lIIl(var1, var4);
         } else {
            return !this.llllI(var1, var2, var4);
         }
      } else {
         return false;
      }
   }

   private void IIII(class_310 var1) {
      if (var1 != null && var1.field_1690 != null && var1.field_1690.field_1904 != null) {
         var1.field_1690.field_1904.method_23481(false);
      }
   }

   private void IIll(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         IllllIlI.IlIIlI(true);

         try {
            IllllIlI.IllIlIl(var1);
         } finally {
            IllllIlI.IlIIlI(false);
         }

         this.IlllI(var1);
      }
   }

   private boolean IlII(class_310 var1) {
      return var1 != null && var1.field_1690 != null && var1.field_1690.field_1904 != null && (IllllIlI.IIIll(var1, var1.field_1690.field_1904) || var1.field_1690.field_1904.method_1434());
   }

   private boolean IlIl(class_746 var1) {
      if (var1 == null) {
         return false;
      } else {
         return !var1.method_24828() && !var1.method_5799() && !var1.method_5869() && !var1.method_5771() && !IllllIlI.ll(var1) && !var1.method_5765() && !var1.method_6101() && !var1.method_5740() && !var1.method_6115() && !IllllIlI.lllllI(var1) && !IllllIlI.IIllIII(var1) && !var1.method_31549().field_7479 && !var1.method_6059(class_1294.field_5902) && !var1.method_6059(class_1294.field_5919) && !var1.method_6059(class_1294.field_5906);
      }
   }

   private void Illl() {
      this.ll(class_310.method_1551());
   }

   private boolean lIII(class_310 var1, class_1309 var2) {
      lIllIIl var3 = lIllIIl.Il();
      if (var3 != null && var1 != null && var1.field_1724 != null && var2 != null) {
         IIllIllll var4 = var3.IIl().lI();
         return var4 != null && var4.IlIl(var1, var2);
      } else {
         return false;
      }
   }

   public String Il() {
      return "";
   }

   private boolean lIIl(class_310 var1, float var2) {
      if ((Boolean)this.IIIl.III() && var1 != null && var1.field_1724 != null) {
         class_746 var3 = var1.field_1724;
         if (!var3.method_24828() && !var3.method_6128()) {
            if (class_9362.method_58659(var3)) {
               return false;
            } else {
               return var3.field_6017 >= (double)1.5F && var3.method_18798().field_1351 < (double)0.0F;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private void llII() {
      this.lIlI = null;
      this.IIl = false;
      this.IlII = -1;
      this.IIIll();
      this.Illl();
      this.lIlII();
      this.lllll();
   }

   private boolean lllI(class_310 var1, class_1309 var2) {
      return IllllIlI.l(var2, var1.field_1724) && !(Boolean)this.I.III() ? this.IIlIl(var1, (class_3966)null, var2) : this.lIlIl(var1, var2);
   }

   private void IIIIl(class_310 var1) {
      if (var1 != null && var1.field_1724 != null && var1.field_1690 != null && var1.field_1690.field_1904 != null) {
         IllllIlI.lIllll(var1);
         IllllIlI.IIIIllI(var1.field_1690.field_1904);
         if (!IllllIlI.IIIll(var1, var1.field_1690.field_1904)) {
            var1.field_1690.field_1904.method_23481(false);
         } else {
            var1.field_1690.field_1904.method_23481(true);
            if (this.lII(var1)) {
               IllllIlI.llIllI(var1);
            }
         }
      }
   }

   private void IIIll() {
      this.IIIlI = IIlIII(-730607846, 41426509);
      this.II = 0L;
   }

   private boolean IIlII(class_1799 var1) {
      return var1 != null && !var1.method_7960() && var1.method_7909() instanceof class_9362;
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      this.lIIll(var1);
   }

   private boolean IIlIl(class_310 var1, class_3966 var2, class_1309 var3) {
      lIllIIl var4 = lIllIIl.Il();
      if (var4 != null && var1 != null && var1.field_1724 != null && var3 != null) {
         IIIIIIIIl var5 = var4.IIl().lIlll();
         if (var5 != null && var5.IIIIIlI()) {
            if (var5.IIlll(var3)) {
               return true;
            }

            if (var5.lIIII(var1, var3)) {
               return true;
            }
         }

         llIlIlI var6 = var4.IIl().IlIlll();
         if (var6 != null && var6.IIIIIlI()) {
            if (var6.IIlIIl(var3)) {
               return true;
            }

            if (var6.IIlll(var1, var3)) {
               if (var2 != null && var6.IlIIlI(var3)) {
                  this.IlIll(var1, var2, var3);
               }

               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   private boolean IIlll(class_1309 var1) {
      long var2 = Math.max(0L, Math.round((Double)this.l.III()));
      if (var2 <= 0L) {
         this.IIIlI = var1 != null ? var1.method_5628() : IIlIII(-730607847, 1365078675);
         this.II = System.currentTimeMillis();
         return true;
      } else if (var1 == null) {
         this.IIIll();
         return false;
      } else {
         long var4 = System.currentTimeMillis();
         if (this.IIIlI != var1.method_5628()) {
            this.IIIlI = var1.method_5628();
            this.II = var4;
            return false;
         } else {
            return var4 - this.II >= var2;
         }
      }
   }

   public boolean IlIII(class_310 var1, class_1309 var2) {
      return this.llll == null.lI;
   }

   private boolean IlIIl(class_746 var1, float var2) {
      return this.IlIl(var1) && var2 > 0.88F && var1.method_18798().field_1351 < (double)0.0F;
   }

   private void IlIll(class_310 var1, class_3966 var2, class_1309 var3) {
      IllllIlI.IlIIlI(true);

      label33: {
         try {
            if (IllllIlI.lllII(var1, var2)) {
               break label33;
            }
         } finally {
            IllllIlI.IlIIlI(false);
         }

         return;
      }

      this.IlllI(var1);
   }

   public void lIl() {
      this.llII();
   }

   private boolean IllII(class_1309 var1) {
      if (this.llIl != null && var1 != null) {
         class_1309 var2 = this.llIl.Ill();
         return var2 instanceof class_1657 && var2.method_5805() && !var2.method_31481() && var2.method_5667().equals(var1.method_5667());
      } else {
         return false;
      }
   }

   private boolean IllIl(class_310 var1) {
      if ((Boolean)this.lll.III() && var1 != null && var1.method_22683() != null) {
         return !this.llII.I() ? false : IllllIlI.IlIII(var1, (class_3675.class_306)this.llII.III());
      } else {
         return !(Boolean)this.lll.III();
      }
   }

   private void IlllI(class_310 var1) {
      this.lIlII();
      this.lllll();
   }

   public void lllIl(class_310 var1) {
      if (this.IIIIIlI() && this.IIIIII(var1)) {
         this.llIIl(var1);
      }
   }

   public lIIIlI(lIlllII var1) {
      super(lIlIII.Il(IIlIIl('墫', 843, 875500477)), lIllII.I, lIlIII.Il(IIlIIl('墪', 37411, -441423827)));
      this.lIll = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.Il(IIlIIl('墩', 57908, 1614624411)), <undefinedtype>.class, null.I));
      this.lllI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.Il(IIlIIl('墨', 64809, -929884877)), false));
      this.lIII = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.Il(IIlIIl('墯', 64974, 458577753)), (double)3.0F, (double)1.0F, (double)3.0F, 0.01)).IIl(lIlIII.Il(IIlIIl('墮', 16150, -211091280))));
      this.IlI = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.Il(IIlIIl('墭', 64804, -251244486)), 2.7, (double)3.0F, (double)1.0F, (double)3.0F, 0.01)).IIII(lIlIII.Il(IIlIIl('墬', 2116, -546821941))));
      this.ll = (llllIlIl)this.IIIlIll(new llllIlIl(lIlIII.Il(IIlIIl('墣', 29999, 1710499808)), 0.89, 0.93, 0.8, (double)1.0F, 0.01));
      this.IlIl = (llllIlIl)this.IIIlIll(new llllIlIl(lIlIII.Il(IIlIIl('墢', 54557, -124821138)), 0.89, 0.93, 0.8, (double)1.0F, 0.01));
      this.l = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.Il(IIlIIl('墡', 29521, 1966365824)), (double)0.0F, (double)0.0F, (double)500.0F, (double)5.0F)).IIl(lIlIII.Il(IIlIIl('墠', 11111, 1565077043))));
      this.Il = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IIlIIl('墧', 36657, -1925548999)), (double)0.0F, (double)0.0F, (double)50.0F, (double)1.0F)).IIIl(lIlIII.l(IIlIIl('墦', 10883, 713633638))));
      this.IIll = (IlIIIlIlI)this.IIIlIll((IlIIIlIlI)(new IlIIIlIlI(lIlIII.l(IIlIIl('墥', 40295, 1254057437)), <undefinedtype>.class, null.II)).lIII(() -> false));
      this.lIl = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(IIlIIl('墤', 20698, -1831528625)), (double)3.0F, (double)3.5F, (double)3.0F, (double)5.0F, 0.05)).Ill(lIlIII.l(IIlIIl('墻', 39266, -1253898842))));
      this.IIIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.Il(IIlIIl('墺', 48998, -1576711623)), true));
      this.IllI = (lIIIIl)this.IIIlIll((lIIIIl)(new lIIIIl(lIlIII.Il(IIlIIl('墹', 44567, -413854129)), true)).lIII(() -> false));
      this.I = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.Il(IIlIIl('墸', 57913, 1252735197)), false));
      this.IIII = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.Il(IIlIIl('墿', 15494, 1948724689)), true));
      this.IIIII = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.Il(IIlIIl('墾', 63026, -1128187950)), false));
      this.Illl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.Il(IIlIIl('墽', 61079, 422725623)), false));
      this.lll = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.Il(IIlIIl('墼', 22786, -478603020)), false));
      this.llII = (lllIIlIl)this.IIIlIll(new lllIIlIl(lIlIII.Il(IIlIIl('墳', 61190, 1849767121))));
      this.llll = null.ll;
      this.IIlI = IIlIII(-730607848, -1785554708);
      this.IlII = -1;
      this.IIIlI = IIlIII(-730607841, 1445865475);
      this.llIl = var1;
      this.lIII.lIII(() -> !(Boolean)this.lllI.III());
      llllIlIl var10000 = this.IlI;
      lIIIIl var10001 = this.lllI;
      Objects.requireNonNull(var10001);
      var10000.lIII(var10001::III);
      lllIIlIl var2 = this.llII;
      var10001 = this.lll;
      Objects.requireNonNull(var10001);
      var2.lIII(var10001::III);
      this.lIl.lIII(() -> (Double)this.Il.III() > (double)0.0F);
   }

   private void Illll(class_310 var1) {
      if (var1 != null && var1.field_1724 != null && var1.field_1761 != null) {
         IllllIlI.IlI(var1, 3);
         this.IIII(var1);
         if (IllllIlI.lllllI(var1.field_1724) || var1.field_1724.method_6115()) {
            var1.field_1761.method_2897(var1.field_1724);
         }

      }
   }

   public double lIIII() {
      return (Boolean)this.lllI.III() ? this.lIIl : (Double)this.lIII.III();
   }

   public void lIIIl(class_310 var1) {
      this.IllI(var1);
   }

   private boolean lIIlI(class_310 var1, class_1309 var2) {
      if (var2 != var1.field_1724 && var2.method_5805()) {
         if (!var2.method_5767() || (Boolean)this.IIIII.III() && var2 instanceof class_1657) {
            if (IlIII.l(var2)) {
               return false;
            } else if ((Boolean)this.IIII.III() && !(var2 instanceof class_1657)) {
               return false;
            } else {
               return !(Boolean)this.Illl.III() || this.lIllI(var1.field_1724.method_6047());
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private void lIIll(class_310 var1) {
      class_638 var2 = var1 != null ? var1.field_1687 : null;
      if (!this.IIl || this.lIlI != var2) {
         this.llII();
         this.lIlI = var2;
         this.IIl = true;
      }
   }

   private void lIlII() {
      if (!(Boolean)this.lllI.III()) {
         this.lIIl = (Double)this.lIII.III();
      } else {
         double var1 = this.IlI.IlII();
         double var3 = this.IlI.IlI();
         this.lIIl = var1 == var3 ? var1 : ThreadLocalRandom.current().nextDouble(var1, var3);
      }
   }

   private boolean lIlIl(class_310 var1, class_1309 var2) {
      lIllIIl var3 = lIllIIl.Il();
      if (var3 != null && var1 != null && var1.field_1724 != null && var2 != null) {
         IIIIIIIIl var4 = var3.IIl().lIlll();
         if (var4 != null && var4.IIIIIlI() && lllllI.ll(var4.IIlll(var2), () -> var4.lIIII(var1, var2))) {
            return true;
         } else {
            llIIIllI var5 = var3.IIl().IIIllll();
            if (var5 != null && var5.IIIIIlI()) {
               if (var5.llI()) {
                  return true;
               }

               if (var5.Illl(var1, var2)) {
                  return true;
               }
            }

            return false;
         }
      } else {
         return false;
      }
   }

   private boolean lIllI(class_1799 var1) {
      if (var1.method_7960()) {
         return false;
      } else if (!(var1.method_7909() instanceof class_1743) && !(var1.method_7909() instanceof class_9362)) {
         String var2 = class_7923.field_41178.method_10221(var1.method_7909()).method_12832();
         return var2.endsWith(lIlIII.Il(IIlIIl('墲', 52364, 1498035074)));
      } else {
         return true;
      }
   }

   private void llIIl(class_310 var1) {
      if (this.IIIIIlI()) {
         if (var1.field_1724 != null && var1.field_1687 != null && var1.field_1755 == null && var1.field_1761 != null) {
            if (!this.llIll(var1)) {
               boolean var2 = IllllIlI.lllllI(var1.field_1724);
               boolean var3 = (Boolean)this.IllI.III() && var2;
               if (var1.field_1724.method_6115() && !var3) {
                  this.IIIll();
               } else if ((Boolean)this.lll.III() && !this.IllIl(var1)) {
                  this.IIIll();
               } else {
                  double var4 = this.lIIII();
                  double var6 = Math.max(var4, this.lIl.IlII());
                  double var8 = Math.max(var6, this.lIl.IlI());
                  class_239 var12 = var1.field_1765;
                  class_3966 var10000;
                  if (var12 instanceof class_3966) {
                     class_3966 var11 = (class_3966)var12;
                     var10000 = var11;
                  } else {
                     var10000 = null;
                  }

                  class_3966 var10 = var10000;
                  if (var10 == null && var4 > (double)3.0F) {
                     var10 = IllllIlI.IlIIllI(var1, var4);
                  }

                  if (var10 == null) {
                     if ((Double)this.Il.III() > (double)0.0F && this.IIll.III() == null.II) {
                        class_3966 var16 = IllllIlI.IlIIllI(var1, var8);
                        if (var16 != null) {
                           class_1309 var19 = IllllIlI.lIIII(var1, var16);
                           if (var19 != null && this.lIIlI(var1, var19) && this.IlI(var19)) {
                              double var13 = var1.field_1724.method_33571().method_1022(var16.method_17784());
                              if (var13 >= var6 && var13 <= var8 && this.IIlll(var19) && this.lll(var1, var19) && ThreadLocalRandom.current().nextDouble((double)0.0F, (double)100.0F) < (Double)this.Il.III()) {
                                 this.IIll(var1);
                                 return;
                              }
                           }
                        }
                     }

                     this.IIIll();
                  } else {
                     class_1309 var15 = IllllIlI.lIIII(var1, var10);
                     if (var15 != null && this.lIIlI(var1, var15)) {
                        if (!this.IlI(var15)) {
                           this.IIIll();
                        } else if (!this.lllII(var1, var10, var15, var4)) {
                           if ((Double)this.Il.III() > (double)0.0F && this.IIll.III() == null.II) {
                              double var18 = var1.field_1724.method_33571().method_1022(var10.method_17784());
                              if (var18 >= var6 && var18 <= var8 && this.IIlll(var15) && this.lll(var1, var15) && ThreadLocalRandom.current().nextDouble((double)0.0F, (double)100.0F) < (Double)this.Il.III()) {
                                 this.IIll(var1);
                                 return;
                              }
                           }

                           this.IIIll();
                        } else {
                           boolean var17 = IllllIlI.l(var15, var1.field_1724);
                           if (this.IIlll(var15)) {
                              if (this.lll(var1, var15)) {
                                 if (!this.IIIIIl(var1, var15)) {
                                    if (var3 && var2) {
                                       this.IIIIll(var1, var15);
                                    } else if (var17 && !(Boolean)this.I.III()) {
                                       this.IIlIl(var1, var10, var15);
                                    } else if (!this.lIII(var1, var15)) {
                                       if (this.lllI(var1, var15)) {
                                          this.IlllI(var1);
                                       } else {
                                          this.IlIll(var1, var10, var15);
                                       }
                                    }
                                 }
                              }
                           }
                        }
                     } else {
                        this.IIIll();
                     }
                  }
               }
            }
         } else {
            this.Illl();
         }
      }
   }

   private boolean llIlI() {
      lIllIIl var1 = lIllIIl.Il();
      if (var1 == null) {
         return false;
      } else {
         llIlIlI var2 = var1.IIl().IlIlll();
         return var2 != null && var2.IIIIIlI();
      }
   }

   private boolean llIll(class_310 var1) {
      if (this.llll == null.ll) {
         return false;
      } else if (var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var1.field_1755 == null) {
         if ((Boolean)this.lll.III() && !this.IllIl(var1)) {
            this.Illl();
            return true;
         } else {
            long var2 = System.currentTimeMillis();
            if (var2 > this.Ill) {
               this.Illl();
               return true;
            } else {
               class_1309 var4 = this.IIIlIl(var1);
               if (var4 == null) {
                  this.ll(var1);
                  return true;
               } else {
                  switch (this.llll.ordinal()) {
                     case 1:
                        this.Illll(var1);
                        if (!IllllIlI.lllllI(var1.field_1724) && !var1.field_1724.method_6115()) {
                           this.llll = null.II;
                           this.Ill = var2 + 325L;
                        }

                        return true;
                     case 2:
                        if (!IllllIlI.lllllI(var1.field_1724) && !var1.field_1724.method_6115()) {
                           double var5 = this.lIIII();
                           class_239 var9 = var1.field_1765;
                           class_3966 var10000;
                           if (var9 instanceof class_3966) {
                              class_3966 var8 = (class_3966)var9;
                              var10000 = var8;
                           } else {
                              var10000 = null;
                           }

                           class_3966 var7 = var10000;
                           if (var7 == null && var5 > (double)3.0F) {
                              var7 = IllllIlI.IlIIllI(var1, var5);
                           }

                           if (var7 != null && var7.method_17782() == var4) {
                              if (!this.lllII(var1, var7, var4, var5)) {
                                 this.Illl();
                                 return true;
                              } else if (!this.lll(var1, var4)) {
                                 return true;
                              } else if (this.IIIIIl(var1, var4)) {
                                 return true;
                              } else {
                                 boolean var10 = IllllIlI.l(var4, var1.field_1724);
                                 if (var10 && !(Boolean)this.I.III()) {
                                    this.IIlIl(var1, var7, var4);
                                    return true;
                                 } else if (this.lIII(var1, var4)) {
                                    return true;
                                 } else if (this.lllI(var1, var4)) {
                                    this.IlllI(var1);
                                    if (this.lII && this.lII(var1)) {
                                       this.llll = null.Il;
                                       this.Ill = var2 + 325L;
                                    } else {
                                       this.ll(var1);
                                    }

                                    return true;
                                 } else {
                                    this.IlIll(var1, var7, var4);
                                    if (this.lII && this.lII(var1)) {
                                       this.llll = null.Il;
                                       this.Ill = var2 + 325L;
                                    } else {
                                       this.ll(var1);
                                    }

                                    return true;
                                 }
                              }
                           } else {
                              this.Illl();
                              return true;
                           }
                        } else {
                           this.Illll(var1);
                           return true;
                        }
                     case 3:
                        this.ll(var1);
                        return true;
                     default:
                        return true;
                  }
               }
            }
         }
      } else {
         this.Illl();
         return true;
      }
   }

   private boolean lllII(class_310 var1, class_3966 var2, class_1309 var3, double var4) {
      if (var1 != null && var1.field_1724 != null && var2 != null && var3 != null) {
         return var1.field_1724.method_33571().method_1022(var2.method_17784()) <= var4 + 1.0E-4;
      } else {
         return false;
      }
   }

   private boolean llllI(class_310 var1, class_1309 var2, float var3) {
      if ((Boolean)this.IIIl.III() && var1 != null && var1.field_1724 != null) {
         class_746 var4 = var1.field_1724;
         if (!this.IlIl(var4)) {
            return false;
         } else if (lIlllllI.ll(true, var4.method_24828(), var4.method_18798().field_1351, var4.field_6017)) {
            return true;
         } else {
            return !this.IlIIl(var4, var3);
         }
      } else {
         return false;
      }
   }

   private void lllll() {
      this.IIIIl = this.llI(this.ll);
      this.lI = this.llI(this.IlIl);
   }

   private boolean IIIIII(class_310 var1) {
      return var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var1.field_1690 != null;
   }

   private boolean IIIIIl(class_310 var1, class_1309 var2) {
      lIllIIl var3 = lIllIIl.Il();
      return var3 != null && var3.IIl() != null && var3.IIl().IIIlIII() != null ? var3.IIl().IIIlIII().lllll(var1, var2) : false;
   }

   public boolean IIIIlI() {
      return IllllIlI.II();
   }

   private void IIIIll(class_310 var1, class_1309 var2) {
      if (var1.field_1724 != null && var1.field_1761 != null && var2 != null) {
         this.llI = true;
         this.lII = this.IlII(var1) && this.lII(var1);
         IllllIlI.IlI(var1, 3);
         this.IIII(var1);
         var1.field_1761.method_2897(var1.field_1724);
         this.llll = null.lI;
         this.IIlI = var2.method_5628();
         this.Ill = System.currentTimeMillis() + 325L;
      }
   }

   public void IllI(class_310 var1) {
      if (this.IIIIIlI()) {
         this.lIIll(var1);
      }
   }

   private class_1309 IIIlIl(class_310 var1) {
      if (var1.field_1687 != null && this.IIlI != IIlIII(-730607842, 1002119156)) {
         class_1297 var2 = var1.field_1687.method_8469(this.IIlI);
         if (var2 instanceof class_1309) {
            class_1309 var3 = (class_1309)var2;
            if (this.lIIlI(var1, var3) && this.IlI(var3)) {
               return var3;
            }
         }

         return null;
      } else {
         return null;
      }
   }

   private double IIIllI(class_1799 var1) {
      return var1 != null && !var1.method_7960() && var1.method_7909() instanceof class_1743 ? this.lI : this.IIIIl;
   }

   private static int IIlIII(int var0, int var1) {
      return IIIll[var0 ^ -730607845] ^ var1 ^ var0;
   }

   static {
      short var6 = 15330;
      String var7 = "祚碩碲祔祍祘稥碻磁磂磮碹碨碱稝稝럪뢖뢡륮럼럷뢕뢐뢕뢥뢐뢊뢤뢍뢙뢑뢡럿뢟렁렆럸럶뢑뢑뤪렄뢞뢐뢑럻렄럲뢥렆뢟뢑렀뢧뢐뤿뢦럾뢓뤾뢚뤵뢋뢛뢥뢥뢤뢠럻렄뢚럼뢡뢖뢚뤵럫뢤뢍뤵뢝뢑륮ڇܟܓڂٰڅڅډڈډڂܤډܟ٪׀檗檖秨檧檛檞稉秾秴歮秌秸稇秴歃檜秼稂秡秾歯檡秳秋⣶⣷⤉⤆⣺⣿⣨⨪㑥㎨㔔㔔珯珮璀生璃甦甡璆瑼甖瑤瑰瑿瑼瑛甔瑴甚珉璆甗璉瑫瑓娔她奥奥頶難雡頽顅頏雷雟頼頿雠雞雝雥頣顈雘雡雷雪懫劗懶劔匵劚懾劗劖懶劥劊劤匪戆劖詠詡覿規詗訮笠詔覹詙覭覹见覣観规親詞笜笜\uab1e멻몉먯虳蜥藆蜟虵藆虫藇蜘蜍薽蜥蜌薲虰薺螽褧螻螻夨埞埭埤夎埭奀埢埔头奅埗䚇䜡䖲䜋䙱䖲䙿䙿䜦䜙䜐䜒䜗䜒䖎䖎咉咄员员̮К˃ˁ͍͐˯ˇ͔͠С͊ʷʶ͠В뻄뽜뺎뽖뺢뽔뽔뽥뽦뽔뺱뽳\udef5\udf8c\udf98\udecf\udefd\udef1\udeea\udf95\udf9b\udfa5\ue03d\udf00\ue06f\udf8c\udefe\udf90\udfa5\ue036\ue06f\ue023뾤뻷뾍뻻뾍뻏뾝뻫뼄뻤뾜뻡뻿뾥뻣뻴볔븽붞븎붔븻빅븭븵볧븰븺븎븭붞븱비볟븿볊볜볟볒븹븪븶붋븼㢛㟤㟿㟏㠃㟫㟳㟳㟴㟵㟶㟳㟫㟨㟸㟜\uee4c\uedc5\uedc3\uedbe\uee5a\uedbd\uedbd\uedb5\ueda9\uef16\uee5e\uef16\uedc6\uedb5\uedb9\uee53\ueda3\uef20\uee55\uedb6\uee64\uee60\uedb2\uef0aۀۉڏݒڶݕڷݺݤݡۈܯ⿸ㄼ\u2fecれ\u2feb〇\u2ffc゜";
      char[] var8 = "㯲㮦㯲㯺㯪㯦㯺㯦㯶㯲㯶㯦㯲㯦㯮㯲㯦㯲㯮㯶㯲㯾㯲㯺㯮㯪".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IIlII = var9;
            IIlIl = new Object[var9.length];
            int var2 = 974351585;
            byte[] var0 = "é\u0093Ëûl\u0018½¶?=Ñkûò;\u00158N\u008býUÛ¼\u000b".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IIIll = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IIIll[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static String IIlIIl(char var0, int var1, int var2) {
      int var3 = var0 ^ 22699;
      char[] var4 = IIlII[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])IIlIl[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         IIlIl[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 24403;
      int var9 = 0;

      do {
         int var10 = var4[var9] - '튊';
         var10 ^= 18276;
         var10 += 39706;
         var10 += 38099;
         var10 -= 9519;
         var10 ^= 12379;
         var10 -= 61668;
         var4[var9] = (char)(var10 ^ var8 ^ var1 ^ var2 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
