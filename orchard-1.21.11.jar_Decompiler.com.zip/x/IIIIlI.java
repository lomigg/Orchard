package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class IIIIlI {
   private IIIIlI() {
   }

   public static double I(double var0) {
      double var2 = (double)1.0F - Il(var0);
      return (double)1.0F - var2 * var2 * var2;
   }

   public static double l(double var0) {
      double var2 = Il(var0) - (double)1.0F;
      return (double)1.0F + var2 * var2 * (2.70158 * var2 + 1.70158);
   }

   public static double II(double var0) {
      double var2 = Il(var0);
      return var2 >= (double)1.0F ? (double)1.0F : (double)1.0F - Math.pow((double)2.0F, (double)-10.0F * var2);
   }

   public static double Il(double var0) {
      return Math.max((double)0.0F, Math.min((double)1.0F, var0));
   }

   public static double lI(double var0) {
      double var2 = Il(var0);
      return var2 < (double)0.5F ? (double)4.0F * var2 * var2 * var2 : (double)1.0F - Math.pow((double)-2.0F * var2 + (double)2.0F, (double)3.0F) * (double)0.5F;
   }

   public static double ll(double var0, double var2) {
      double var4 = Il(var0);
      double var6 = Math.max((double)0.0F, Math.min((double)8.0F, var2 * (double)60.0F));
      return (double)1.0F - Math.pow((double)1.0F - var4, var6);
   }

   public static double III(double var0, double var2, double var4, double var6) {
      return var0 + (var2 - var0) * ll(var4, var6);
   }

   public static double IIl(double var0) {
      double var2 = Il(var0);
      return var2 * var2 * var2 * (var2 * (var2 * (double)6.0F - (double)15.0F) + (double)10.0F);
   }
}
