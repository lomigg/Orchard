package x;

import io.netty.channel.ChannelDuplexHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelPromise;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.channels.ClosedChannelException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Set;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Consumer;
import java.util.function.Predicate;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2596;
import net.minecraft.class_2708;
import net.minecraft.class_2724;
import net.minecraft.class_2749;
import net.minecraft.class_2793;
import net.minecraft.class_2799;
import net.minecraft.class_2813;
import net.minecraft.class_2815;
import net.minecraft.class_2824;
import net.minecraft.class_2827;
import net.minecraft.class_2828;
import net.minecraft.class_2833;
import net.minecraft.class_2846;
import net.minecraft.class_2848;
import net.minecraft.class_2851;
import net.minecraft.class_2856;
import net.minecraft.class_2868;
import net.minecraft.class_2879;
import net.minecraft.class_2885;
import net.minecraft.class_2886;
import net.minecraft.class_2923;
import net.minecraft.class_2935;
import net.minecraft.class_310;
import net.minecraft.class_6374;
import net.minecraft.class_7640;
import net.minecraft.class_8590;
import net.minecraft.class_8591;
import net.minecraft.class_9836;
import net.minecraft.class_2799.class_2800;
import net.minecraft.class_2848.class_2849;

@Environment(EnvType.CLIENT)
public final class IIIIIlIll extends ChannelDuplexHandler {
   private static final int I = 16;
   private static volatile long l;
   private static volatile long II;
   private static final int Il = 256;
   private static volatile <undefinedtype> lI;
   private static volatile int ll;
   private static final Set<IIIIIlIll> III;
   private static volatile <undefinedtype> IIl;
   private static volatile <undefinedtype> IlI;
   private static volatile boolean Ill;
   private static final Object lII;
   private static final int lIl = 4;
   private static final ConcurrentHashMap<<undefinedtype>, Boolean> llI;
   private static volatile <undefinedtype> lll;
   private final ConcurrentLinkedQueue<<undefinedtype>> IIII = new ConcurrentLinkedQueue();
   private static final int IIIl = 1024;
   private volatile boolean IIlI;
   private volatile boolean IIll;
   private final AtomicLong IlII = new AtomicLong();
   private static final long IlIl = 60000L;
   private static final int IllI = 10;
   private final ConcurrentLinkedQueue<<undefinedtype>> Illl = new ConcurrentLinkedQueue();
   private static volatile <undefinedtype> lIII;
   private static String[] lIIl;
   private volatile long lIlI;
   private static final long lIll;
   private final ConcurrentLinkedQueue<<undefinedtype>> llII = new ConcurrentLinkedQueue();
   private volatile ChannelHandlerContext llIl;
   private final ConcurrentLinkedQueue<<undefinedtype>> lllI = new ConcurrentLinkedQueue();
   private static final long llll;
   private final Set<<undefinedtype>> IIIII = ConcurrentHashMap.newKeySet();
   private final AtomicBoolean IIIIl = new AtomicBoolean();
   private volatile long IIIlI;
   private static volatile int IIIll;
   private final AtomicBoolean IIlII = new AtomicBoolean();
   private final AtomicBoolean IIlIl = new AtomicBoolean();
   private static volatile boolean IIllI;
   private static final long IIlll = 5000L;
   private volatile boolean IlIII;
   private final AtomicBoolean IlIIl = new AtomicBoolean();
   private static final int IlIlI = 32;
   private static volatile long IlIll;
   private static final ConcurrentHashMap<<undefinedtype>, Boolean> IllII;
   private volatile long IllIl;
   private static volatile boolean IlllI;
   private static volatile boolean Illll;
   private final ConcurrentLinkedQueue<<undefinedtype>> lIIII = new ConcurrentLinkedQueue();
   private static volatile long lIIIl;
   private static volatile <undefinedtype> lIIlI;
   private static volatile boolean lIIll;
   private final ConcurrentLinkedQueue<<undefinedtype>> lIlII = new ConcurrentLinkedQueue();
   private static volatile long lIlIl;
   private static final int lIllI = 512;
   private volatile boolean lIlll;
   private static volatile boolean llIII;
   private static final long llIIl = 2500L;
   private volatile boolean llIlI;
   private final AtomicBoolean llIll = new AtomicBoolean();
   private final ConcurrentLinkedQueue<<undefinedtype>> lllII = new ConcurrentLinkedQueue();
   private static final long lllIl;
   private volatile long llllI;
   private static final int[] lllll;
   private static final String[] IIIIII;
   private static final Object[] IIIIIl;

   private void I(ChannelHandlerContext var1) {
      try {
         boolean var2 = false;
         ArrayList var3 = new ArrayList();
         this.IIIIl.set(false);

         <undefinedtype> var4;
         while((var4 = (<undefinedtype>)this.lllII.poll()) != null) {
            if (var4.Il == null.II && var4.II instanceof class_2851) {
               if (var2) {
                  var4.l.trySuccess();
                  continue;
               }

               var2 = true;
            }

            var3.add(var4);
            if (var4.Il == null.II && var4.II instanceof class_9836) {
               var2 = false;
            }
         }

         boolean var5 = false;

         for(<undefinedtype> var7 : var3) {
            var5 |= this.IlIllI(var1, var7.II, var7.l);
         }

         if (var5 && var1.channel().isOpen()) {
            var1.flush();
            this.lIlI = System.nanoTime();
         }

         this.lIlll = false;
         llII();
      } catch (Exception var8) {
         this.IIIIl.set(false);
         throw var8;
      }
   }

   public static void II(long var0) {
      long var2 = System.currentTimeMillis() - Math.max(0L, var0);

      for(IIIIIlIll var5 : III) {
         var5.IIIIIII(var2);
      }

   }

   private long Il(Object var1) {
      long var2 = this.IIlIllI(var1.II);
      if (var2 <= 0L) {
         return 0L;
      } else if (this.lIIII.size() > IlIIIll(-976353710, -930393202)) {
         return 0L;
      } else {
         if (IIIllI() == null.II && this.IIIII.contains(var1)) {
            var2 = Math.min(60000L, var2 + IlIlII());
         }

         long var4 = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - var1.lI);
         return var4 >= 60000L ? var4 : Math.min(var2, 60000L);
      }
   }

   private void lI(Object var1) {
      ChannelHandlerContext var2 = this.llIl;
      if (var2 == null) {
         if (var1.Il()) {
            this.llIlIl(this.llII, new ClosedChannelException());
         }

         if (var1.II()) {
            this.lIlII.clear();
         }

      } else {
         Runnable var3 = () -> {
            if (var1.Il()) {
               this.IlIIl(var2);
            }

            if (var1.II()) {
               this.llIll.set(false);
               this.IIllIlI(var2);
            }

         };
         if (var2.executor().inEventLoop()) {
            var3.run();
         } else {
            var2.executor().submit(var3).syncUninterruptibly();
         }
      }
   }

   private void ll(ChannelHandlerContext var1) {
      this.IllI(var1, 0L);
   }

   private void III(Object var1) {
      if (var1 != null) {
         long var2 = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - var1.Il());
         long var4 = II;
         II = var4 <= 0L ? var2 : (long)((double)var4 * 0.85 + (double)var2 * 0.15);
         lIIIl = System.currentTimeMillis();
         ll = this.lIIII.size();
      }
   }

   public static void IIl() {
      lIII = null;
   }

   public static int IlI() {
      return IIIll;
   }

   private <undefinedtype> Ill(Object var1, ChannelPromise var2) {
      return new Record(var1, var2, System.nanoTime(), this.IlII.incrementAndGet()) {
         private final Object I;
         private final long l;
         private final ChannelPromise II;
         private final long Il;

         public long I() {
            return this.l;
         }

         public long l() {
            return this.Il;
         }

         public ChannelPromise II() {
            return this.II;
         }

         public Object Il() {
            return this.I;
         }

         private {
            this.I = var1;
            this.II = var2;
            this.Il = var3;
            this.l = var5;
         }
      };
   }

   private void lII(ChannelHandlerContext var1, Object var2, ChannelPromise var3) throws Exception {
      this.llllIl(var1);
      if (this.IllIl(var2)) {
         this.lIIIl(var1, var2, var3);
      } else if (this.lllII(var2)) {
         if (!this.lIIl(this.IlIIIlI(var2, var3, null.lI))) {
            var3.tryFailure(new IllegalStateException());
         }

      } else {
         if (var2 instanceof class_2935) {
            class_2935 var4 = (class_2935)var2;
            x.IllII.IlIll().lIll(var4.method_12700());
         }

         <undefinedtype> var8 = lIl(var2);
         if (var8 != null) {
            if (!this.IIIIIIl(this.IlIIIlI(var2, var3, var8))) {
               var3.tryFailure(new IllegalStateException());
            } else if (lI != null) {
               this.llIlII();
            }

         } else {
            long var5 = this.IlIII(var2);
            if (var5 <= 0L) {
               this.IlIllI(var1, var2, var3);
            } else {
               if (var2 instanceof class_2935) {
                  class_2935 var7 = (class_2935)var2;
                  x.IllII.IlIll().IIll(var7.method_12700(), var5);
               }

               if (!this.IIllll(this.Ill(var2, var3))) {
                  var3.tryFailure(new IllegalStateException());
               } else {
                  this.lIIIlI(var1);
               }
            }
         }
      }
   }

   private static <undefinedtype> lIl(Object var0) {
      if (!Illll && lI == null) {
         return null;
      } else {
         synchronized(lII) {
            if (Illll && Illl(var0, IIl)) {
               return IIl;
            } else {
               return lI != null && Illl(var0, lll) ? lll : null;
            }
         }
      }
   }

   private static Integer lll(class_2596<?> var0) {
      String var1 = var0.getClass().getName();
      boolean var2 = var1.endsWith(lIlIII.Il(lIIl[1])) || var1.contains(lIlIII.Il(lIIl[3])) && var1.endsWith(lIlIII.Il(lIIl[4])) || var1.endsWith(lIlIII.Il(lIIl[IlIIIll(-976353709, -671493395)]));
      if (!var2) {
         return null;
      } else {
         Integer var3 = IIIIlll(var0, lIlIII.Il(lIIl[2]), lIlIII.Il(lIIl[0]), lIlIII.Il(lIIl[5]), lIlIII.Il(lIIl[IlIIIll(-976353712, -1934951873)]));
         return var3 != null && var3 < 0 && var3 == (short)var3 ? var3 : null;
      }
   }

   private void IIIl(ChannelHandlerContext var1, long var2) {
      if (this.llIll.compareAndSet(false, true)) {
         Runnable var4 = () -> this.IIlIlIl(var1);
         if (var2 > 0L) {
            var1.executor().schedule(var4, Math.max(var2, lIll), TimeUnit.NANOSECONDS);
         } else {
            if (var1.executor().inEventLoop()) {
               var4.run();
            } else {
               var1.executor().execute(var4);
            }

         }
      }
   }

   private void IIlI(int var1) {
      for(<undefinedtype> var3 : this.lIIII) {
         if (var3.l < var1) {
            this.IIIII.add(var3);
         }
      }

   }

   public static void IIll() {
      <undefinedtype> var0 = x.IllII.IlIll().llI();
      if (!var0.l()) {
         for(IIIIIlIll var2 : III) {
            var2.IlIlll(var0);
         }

      }
   }

   private static boolean IlII(Object var0) {
      if (var0 instanceof class_2596 var1) {
         Object var2 = new Object(var1) {
            private final class_2596<?> I;

            public int hashCode() {
               return System.identityHashCode(this.I);
            }

            public boolean equals(Object var1) {
               boolean var10000;
               if (var1 instanceof <undefinedtype> var2) {
                  if (this.I == var2.I) {
                     var10000 = true;
                     return var10000;
                  }
               }

               var10000 = false;
               return var10000;
            }

            private {
               this.I = var1;
            }
         };
         boolean var3 = IllII.remove(var2) != null;
         if (var3) {
            llI.remove(var2);
            if (llI.isEmpty()) {
               IIllI = false;
            }
         }

         return var3;
      } else {
         return false;
      }
   }

   public static void IlIl(Object var0) {
      <undefinedtype> var1 = var0 == null ? null.I : var0;
      if (lIIlI != var1) {
         lIIlI = var1;
         IIlllI();
      }
   }

   private void IllI(ChannelHandlerContext var1, long var2) {
      if (this.IIlII.compareAndSet(false, true)) {
         Runnable var4 = () -> this.IIIIIl(var1);
         if (var2 > 0L) {
            var1.executor().schedule(var4, Math.max(var2, lIll), TimeUnit.NANOSECONDS);
         } else {
            if (var1.executor().inEventLoop()) {
               var4.run();
            } else {
               var1.executor().execute(var4);
            }

         }
      }
   }

   private static boolean Illl(Object var0, Object var1) {
      if (var1 != null && var0 instanceof class_2596 var2) {
         if (IIIlIII(var2)) {
            return false;
         } else if (var2 instanceof class_2856) {
            return false;
         } else if (var1 == null.lI) {
            return true;
         } else if (var1 == null.l) {
            return var2 instanceof class_2828 || var2 instanceof class_2833 || var2 instanceof class_9836;
         } else if (var1 == null.II) {
            return llIl(var2);
         } else {
            String var3 = var2.getClass().getName();
            return var3.contains(lIlIII.Il(lIIl[IlIIIll(-976353711, 1110813481)])) || var3.contains(lIlIII.Il(lIIl[IlIIIll(-976353706, 1624082648)])) || var3.contains(lIlIII.Il(lIIl[IlIIIll(-976353705, 1914201399)])) || var3.contains(lIlIII.Il(lIIl[IlIIIll(-976353708, 1987115660)]));
         }
      } else {
         return false;
      }
   }

   private static boolean lIII(Object var0) {
      boolean var10000;
      if (!(var0 instanceof class_2724)) {
         label27: {
            if (var0 instanceof class_2749) {
               class_2749 var1 = (class_2749)var0;
               if (var1.method_11833() <= 0.0F) {
                  break label27;
               }
            }

            var10000 = false;
            return var10000;
         }
      }

      var10000 = true;
      return var10000;
   }

   private boolean lIIl(Object var1) {
      if (this.llII.size() >= IlIIIll(-976353707, -378626511)) {
         return false;
      } else {
         this.llII.offer(var1);
         return true;
      }
   }

   private static boolean lIlI(Object var0) {
      return var0 instanceof class_2824 || var0 instanceof class_2885 || var0 instanceof class_2886 || var0 instanceof class_2846 || var0 instanceof class_2879 || var0 instanceof class_2848 && !IIIIlIl(var0) || var0 instanceof class_2799;
   }

   private static void llII() {
      synchronized(lII) {
         if (lI != null) {
            for(IIIIIlIll var2 : III) {
               if (!var2.lllII.isEmpty()) {
                  return;
               }
            }

            lI = null;
            lll = null;
         }
      }
   }

   private static boolean llIl(class_2596<?> var0) {
      if (!(var0 instanceof class_2813) && !(var0 instanceof class_2815) && !IIIlI(var0)) {
         if (!(var0 instanceof class_2828) && !(var0 instanceof class_2833) && !(var0 instanceof class_9836) && !(var0 instanceof class_2827) && !(var0 instanceof class_6374) && !(var0 instanceof class_2824) && !(var0 instanceof class_2846) && !(var0 instanceof class_2885) && !(var0 instanceof class_2886) && !(var0 instanceof class_2879) && !(var0 instanceof class_2868) && !(var0 instanceof class_2848) && !(var0 instanceof class_2851) && !(var0 instanceof class_2799)) {
            return IlIIIl(var0) || var0.getClass().getName().endsWith(lIlIII.Il(lIIl[IlIIIll(-976353702, 1494106549)]));
         } else {
            return true;
         }
      } else {
         return false;
      }
   }

   private static String llll(char[] var0, long var1, int var3) {
      int var4 = IlIIIll(-976353701, 1649727730) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IlIIIll(-976353704, 1183301105);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   public void write(ChannelHandlerContext var1, Object var2, ChannelPromise var3) throws Exception {
      var3 = this.IIlIIIl(var1, var2, var3);
      if (IIIlIII(var2)) {
         this.lIIIl(var1, var2, var3);
      } else if (IlllI(var2)) {
         this.Illlll(new CancellationException(lIlIII.Il(lIIl[IlIIIll(-976353703, 1250625274)])));
         this.llIIIl(var1, var2, var3);
      } else if (IlII(var2)) {
         if (!this.Illl.isEmpty()) {
            this.IIIlll(var1);
         }

         this.lII(var1, var2, var3);
         if (lIlI(var2)) {
            this.IIlI = true;
         }

      } else if (!this.IllIll(var2)) {
         if (!this.Illl.isEmpty()) {
            this.IIIlll(var1);
         }

         this.lII(var1, var2, var3);
      } else if (IIlIIl(var2)) {
         this.IIlIlII(var1, var2, var3);
         this.llIlI = true;
         this.IlIII = true;
      } else if (var2 instanceof class_9836) {
         this.IIIIlII(var1, var2, var3);
      } else if ((this.llIlI || this.IlIII) && lIlI(var2)) {
         this.lIIII(var2, var3);
      } else if (!this.Illl.isEmpty() && !IIllI(var2)) {
         this.lIIII(var2, var3);
      } else if (!(var2 instanceof class_2868) || !this.IIlI && !this.llIlI && !this.IlIII) {
         this.lII(var1, var2, var3);
         if (lIlI(var2)) {
            this.IIlI = true;
         }

      } else {
         this.lIIII(var2, var3);
      }
   }

   private void IIIIl() {
      ChannelHandlerContext var1 = this.llIl;
      if (var1 == null) {
         this.lIlII.clear();
      } else {
         this.IIIl(var1, 0L);
      }
   }

   private static boolean IIIlI(Object var0) {
      if (var0 == null) {
         return false;
      } else {
         String var1 = var0.getClass().getSimpleName();
         return var1.contains(lIlIII.Il(lIIl[IlIIIll(-976353698, -900924979)])) || var1.contains(lIlIII.Il(lIIl[IlIIIll(-976353697, 1138712407)])) || var1.contains(lIlIII.Il(lIIl[IlIIIll(-976353700, 1054972182)])) || var1.contains(lIlIII.Il(lIIl[IlIIIll(-976353699, -1091804651)])) || var1.contains(lIlIII.Il(lIIl[IlIIIll(-976353726, 926706164)]));
      }
   }

   private void IIlII(ChannelHandlerContext var1, long var2, Object var4) {
      try {
         long var5 = var4 == null.II ? lllIl : llll;
         long var7 = System.nanoTime();
         long var9 = this.IIlIIll(this.lIlI, var5, var7);
         if (var9 > 0L) {
            this.IIIIl.set(false);
            this.IIIIIll(var1, var2, var4, var9);
         } else {
            int var11 = var4 == null.II ? IlIIIll(-976353725, -792024251) : IlIIIll(-976353728, 1912003127);
            boolean var12 = false;
            ArrayList var13 = new ArrayList(var11);

            <undefinedtype> var14;
            while(var13.size() < var11 && (var14 = (<undefinedtype>)this.lllII.peek()) != null && (var4 == null || var14.Il == var4) && var14.lI <= var2) {
               var14 = (<undefinedtype>)this.lllII.poll();
               if (var14 == null) {
                  break;
               }

               if (var14.Il == null.II && var14.II instanceof class_2851) {
                  if (var12) {
                     var14.l.trySuccess();
                     continue;
                  }

                  var12 = true;
               }

               var13.add(var14);
               if (var14.Il == null.II && var14.II instanceof class_9836) {
                  break;
               }
            }

            boolean var15 = false;

            for(<undefinedtype> var17 : var13) {
               var15 |= this.IlIllI(var1, var17.II, var17.l);
            }

            if (var15 && var1.channel().isOpen()) {
               var1.flush();
               this.lIlI = System.nanoTime();
            }

            this.IIIIl.set(false);
            if (lI != null && !this.lllII.isEmpty()) {
               this.lIlll = this.lllII.peek() != null && ((<undefinedtype>)this.lllII.peek()).Il == null.II;
               this.llIIl(var1, this.llIII((<undefinedtype>)this.lllII.peek()));
            } else if (this.IIlIII(var2, var4)) {
               this.IIIIIll(var1, var2, var4, var5);
            }

         }
      } catch (Exception var18) {
         this.IIIIl.set(false);
         throw var18;
      }
   }

   private static boolean IIllI(Object var0) {
      return IIIlIII(var0) || IIIIlIl(var0) || var0 instanceof class_2856 || var0 instanceof class_2935 || var0 instanceof class_2833 || var0 instanceof class_2813 || var0 instanceof class_2815;
   }

   private void IIlll(ChannelHandlerContext var1, long var2) {
      if (this.IIlIl.compareAndSet(false, true)) {
         Runnable var4 = () -> this.lIlllI(var1);
         if (var2 > 0L) {
            var1.executor().schedule(var4, Math.max(var2, lIll), TimeUnit.NANOSECONDS);
         } else {
            if (var1.executor().inEventLoop()) {
               var4.run();
            } else {
               var1.executor().execute(var4);
            }

         }
      }
   }

   private long IlIII(Object var1) {
      if (var1 instanceof class_2596 var2) {
         if (IIIlIII(var2)) {
            return 0L;
         } else if (var2 instanceof class_2856) {
            return 0L;
         } else {
            long var3 = 0L;
            IllII var5 = x.IllII.IlIll();
            if (var5.IIlll() && var5.Il() && !var2.method_55943()) {
               var3 = Math.max(var3, var5.III());
            }

            llllIll var6 = this.llIlll();
            if (var2 instanceof class_2827 && var6 != null) {
               var3 = Math.max(var3, var6.IIII());
            }

            if (var2 instanceof class_2827) {
               var3 = Math.max(var3, IIIIIlI());
            }

            return var3;
         }
      } else {
         return 0L;
      }
   }

   private void IlIIl(ChannelHandlerContext var1) {
      <undefinedtype> var2;
      boolean var3;
      for(var3 = false; (var2 = (<undefinedtype>)this.llII.poll()) != null; var3 |= this.IlIllI(var1, var2.II, var2.l)) {
      }

      if (var3 && var1.channel().isOpen()) {
         var1.flush();
      }

   }

   private void IlIll(ChannelHandlerContext var1, long var2) {
      if (this.IlIIl.compareAndSet(false, true)) {
         Runnable var4 = () -> this.lIIIll(var1);
         if (var2 > 0L) {
            var1.executor().schedule(var4, Math.max(var2, lIll), TimeUnit.NANOSECONDS);
         } else {
            if (var1.executor().inEventLoop()) {
               var4.run();
            } else {
               var1.executor().execute(var4);
            }

         }
      }
   }

   private void IllII() {
      ChannelHandlerContext var1 = this.llIl;
      if (var1 == null) {
         this.lIllIl(new ClosedChannelException());
         this.IIIIl.set(false);
         this.IIlII.set(false);
         this.IlIIl.set(false);
         this.lIlll = false;
      } else {
         Runnable var2 = () -> {
            try {
               this.IIIIl.set(false);
               this.IIlII.set(false);
               this.IlIIl.set(false);
               ArrayList var2 = new ArrayList();

               <undefinedtype> var3;
               while((var3 = (<undefinedtype>)this.lllII.poll()) != null) {
                  var2.add(new Record(var3.II, var3.l, var3.I, null) {
                     private final <undefinedtype> I;
                     private final ChannelPromise l;
                     private final long II;
                     private final Object Il;

                     public Object I() {
                        return this.Il;
                     }

                     public ChannelPromise l() {
                        return this.l;
                     }

                     public long II() {
                        return this.II;
                     }

                     private {
                        this.Il = var1;
                        this.l = var2;
                        this.II = var3;
                        this.I = var5;
                     }

                     public <undefinedtype> Il() {
                        return this.I;
                     }
                  });
               }

               while((var3 = (<undefinedtype>)this.llII.poll()) != null) {
                  var2.add(new Record(var3.II, var3.l, var3.I, null) {
                     private final <undefinedtype> I;
                     private final ChannelPromise l;
                     private final long II;
                     private final Object Il;

                     public Object I() {
                        return this.Il;
                     }

                     public ChannelPromise l() {
                        return this.l;
                     }

                     public long II() {
                        return this.II;
                     }

                     private {
                        this.Il = var1;
                        this.l = var2;
                        this.II = var3;
                        this.I = var5;
                     }

                     public <undefinedtype> Il() {
                        return this.I;
                     }
                  });
               }

               <undefinedtype> var4;
               while((var4 = (<undefinedtype>)this.lIIII.poll()) != null) {
                  this.IIIII.remove(var4);
                  var2.add(new Record(var4.II, var4.I, var4.Il, var4) {
                     private final <undefinedtype> I;
                     private final ChannelPromise l;
                     private final long II;
                     private final Object Il;

                     public Object I() {
                        return this.Il;
                     }

                     public ChannelPromise l() {
                        return this.l;
                     }

                     public long II() {
                        return this.II;
                     }

                     private {
                        this.Il = var1;
                        this.l = var2;
                        this.II = var3;
                        this.I = var5;
                     }

                     public <undefinedtype> Il() {
                        return this.I;
                     }
                  });
               }

               <undefinedtype> var5;
               while((var5 = (<undefinedtype>)this.IIII.poll()) != null) {
                  var2.add(new Record(var5.I, var5.II, var5.l, null) {
                     private final <undefinedtype> I;
                     private final ChannelPromise l;
                     private final long II;
                     private final Object Il;

                     public Object I() {
                        return this.Il;
                     }

                     public ChannelPromise l() {
                        return this.l;
                     }

                     public long II() {
                        return this.II;
                     }

                     private {
                        this.Il = var1;
                        this.l = var2;
                        this.II = var3;
                        this.I = var5;
                     }

                     public <undefinedtype> Il() {
                        return this.I;
                     }
                  });
               }

               while((var5 = (<undefinedtype>)this.Illl.poll()) != null) {
                  var2.add(new Record(var5.I, var5.II, var5.l, null) {
                     private final <undefinedtype> I;
                     private final ChannelPromise l;
                     private final long II;
                     private final Object Il;

                     public Object I() {
                        return this.Il;
                     }

                     public ChannelPromise l() {
                        return this.l;
                     }

                     public long II() {
                        return this.II;
                     }

                     private {
                        this.Il = var1;
                        this.l = var2;
                        this.II = var3;
                        this.I = var5;
                     }

                     public <undefinedtype> Il() {
                        return this.I;
                     }
                  });
               }

               var2.sort(Comparator.comparingLong(<undefinedtype>::II));

               for(<undefinedtype> var7 : var2) {
                  this.IlIllI(var1, var7.Il, var7.l);
                  if (var7.I != null) {
                     this.III(var7.I);
                  }
               }

               if (var1.channel().isOpen()) {
                  var1.flush();
               }

               this.lIlll = false;
               this.llllll();
               llII();
            } catch (Exception var8) {
            }

         };
         if (var1.executor().inEventLoop()) {
            var2.run();
         } else {
            try {
               var1.executor().submit(var2).sync();
            } catch (InterruptedException var4) {
               Thread.currentThread().interrupt();
            }
         }

      }
   }

   private boolean IllIl(Object var1) {
      return IIIlIII(var1);
   }

   private static boolean IlllI(Object var0) {
      boolean var10000;
      if (var0 instanceof class_2799 var1) {
         if (var1.method_12119() == class_2800.field_12774) {
            var10000 = true;
            return var10000;
         }
      }

      var10000 = false;
      return var10000;
   }

   private void lIIII(Object var1, ChannelPromise var2) {
      if (this.Illl.size() >= IlIIIll(-976353727, -1840729302)) {
         var2.tryFailure(new IllegalStateException(lIlIII.Il(lIIl[IlIIIll(-976353722, -198111864)])));
      } else {
         boolean var3 = this.Illl.isEmpty();
         this.Illl.offer(this.Ill(var1, var2));
         if (var3) {
            this.IIll = false;
         }

      }
   }

   private void lIIIl(ChannelHandlerContext var1, Object var2, ChannelPromise var3) {
      if (this.IlIllI(var1, var2, var3) && var1.channel().isOpen()) {
         var1.flush();
      }

   }

   private static void lIIlI(Object var0) {
      if (var0 instanceof class_2596 var1) {
         <undefinedtype> var2;
         if ((var2 = lIII) != null) {
            IIIllIl(() -> {
               if (lIII == var2) {
                  try {
                     var2.I().accept(var1);
                  } catch (Throwable var3) {
                  }

               }
            });
            return;
         }
      }

   }

   public static void lIIll() {
      for(IIIIIlIll var1 : III) {
         var1.IIllIIl();
      }

   }

   private void lIlII() {
      ChannelHandlerContext var1 = this.llIl;
      if (var1 != null) {
         Runnable var2 = () -> {
            if (!this.IIII.isEmpty()) {
               this.IlIIl.set(false);
               this.lIIIlI(var1);
            }

            if (!this.lIIII.isEmpty()) {
               this.IIlII.set(false);
               this.ll(var1);
            }

            if (!this.lllI.isEmpty()) {
               this.IIlIl.set(false);
               this.IllllI(var1);
            }

         };
         if (var1.executor().inEventLoop()) {
            var2.run();
         } else {
            var1.executor().execute(var2);
         }

      }
   }

   public static void lIlIl() {
      lIIll = true;
      IlllI = true;
   }

   static {
      short var6 = 4144;
      String var7 = "\uf179瓾辖\ue1c4藣ힿ䨪襯笹럕\udb5d░\u20ce⽧連踔ᯠﾼꟓ䁮ڎ멘䕰\ue511ᮯ흿䍨닌ﺻ鳌\u2ddf蛚Ꝛ攦퇬㤖癛\uf461敐説⬜쨉ḙ菴敔먊苘盹ↆ\u0e69콊焜됾膏穣遡릘马⺸僶摃흻톷샃ꌔאּ놏镃\uf289焒鞘ᠯ굈鸘啃䌸断遢Ј꽽▟郊\u0a3b䷀ᮓ쑶紻洌喻⻄ρ퉛ǭᩨ䖴㴾ᔳ颠迄\u1316伌‚剮ᒶ臐罹ˍ葰좎༾乶캛\u0601ᚹ仇皂\u0e75\ue400鏰茰绛蕽銴\ue3f0⋘\u1739邒䙲촽͛뢂ꖨ\ued31뜛悠拙鵈芦ﶗ抿톄\uf60dư죅騁鐭❐劣\u0b7cィ쑜픈\ue70dᱭ☊ƿ\ue1c7뫜蓮ཨ媪䠇縇췕ㄾ溜侗乶皋ꉿ囓萼\uddc3돀ϲ矰낂⚂밠斛㸐\ufde6찕視\ude15扔\u09d3\ue55c谮组ۢ즶\udc7e첂緲ણ븺죣ꣵ⸞ꮤ詢졇徳谣醐\ue640ፙ\ue63d\udefd쉬镢쥲餅⧝헝洖ꆙ８궺欜보㴉\ued18釰ତ䆟昚舟봐ꃕ鼳\uef28嚱䤰\u0abb㯬퀻ꘛ罀䂊\ue31f몯ᫍ㫎\uf20dቀ䅏ꄾ훝\ue9d8嫍굠醽\uf229隸訂墘\ue14f풅몯\ue383搬솻\uefa8膉괟㱌鰧퓿㍁솠헫់솅텯ﭭ춤Ώ兰拔\ue360\uddee迒\udf3e\udada篥䟥ﰦ輟깡㥧䤭挛쭓\udd31贾㏳㋁榿店糐\ue7e7䣳Ḡ쾧勿▕悁찁֓쾌貒碌砓괾䇈盘⇽\uec99컏䘟Ꟁ塤矙奎㰚鐾睁塀ㅚ貃\u0b98뷕ሆ櫽鴝來\ue1afཪ諤ꤘ㝨\uea8cꮼ龂飜渒쥼ᶨ뒂\udb68쭣\uf32a뙜惢旪줚勛덌ḧ炼ꕓ俾ꋱ큜㙲밾굷氢갠뵻뒭놣譶\u318f䄢탟\u1cff䝙泎㕩힑鞕Ừ쨫䤷\uf8d4겎\ueb98⣼ꭙ敼¹\uddeb跦\uecf1ᆕ洫롋㔑⇪釆\ued31쿝靳座퀙\ue44a\uf511뜡ᔀ\uf77d婳એ궩؊༈詷ڪ\uf448\uef9b쎀䙧쇕辅ᜨ\ud9fbꤓ⽋∧ᅒ鳕殽\u18ff宩哄ኺ䄜쉾\ude4f떞\ua4ce庫Ꜧ₸\u05f8捵‘\uf1c0\ued8d옠㪩ꊭ┕鄐\udcb5⚲䗝폩廀\u206b力\uef3c䌶随痼ⶩ裄܄댐隄驚ᓓᅹ樆糚ֲ곇\ue517䤝䷵\uf760甝헤꩹台䍚倬賙\uab1d㔄맋럿\u1afa\udd58抭鼱蹂쨰\udd4a훔䵓횑쟥\u0cfe퓂惫꧅澯펴隕\ude22\uea0f㪙帒퉺兹߮ﻴ᪢랭膎\uf45dѦ薱錷魮Â粫鑜䟆ȥ鼶\u2068털博\uda11\uf7ab\ue6e3";
      char[] var8 = "\u0004\u001c\f\f\u0014\u0010\u001c\b(<,\u001c\u001c\u001c (\b\f\u0010\u0010\u0018$".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            IIIIII = var9;
            IIIIIl = new Object[var9.length];
            int var2 = -842457329;
            byte[] var0 = "À\u008cKÓßþË·\u0084\u00adãgJ2²{hÊ\u0091\u008az\u001f|b~wãÙái\u0083kQ\tXï\u009d/¡²N\u0080¤YB\u008c\u001f¦ÂKà\u008cKØF\u00156æ\u0080V¶ë{V?;p\u00adØÍ²\u0019yñÃr\u009aO®dü6\u0014Ô¡cÑ¢¿¦QðÖ\u0081\u0087ùo\u008eÔò\u008a\u0092\u008aºz\u001a\fØAi<\u009aÑÛ¼Ý¦\b\u0014\u009c\u0084æ\u009f\u0098EÑÇROíO\u009dl\u0011²\rlyoò\u0099\"¹\u000fô\u0089&\u0016\u0093¹4©\u0001É\búæ/Þ\u0003ZS\u0080`z\t©\u0004 å¥Ôthø)y\u0091jBGt\u001d<x\u0019'\u001c\u0016i)\u0010ãÓbi\u009dH\u0011\u00138ß}l¹ê\u001fw-u4\u001c\u008c&R\u0010»å%Ìêíõ\u0002,\u0013ÙØ\u0082é\u0011Çês\u009cT¬iì¼\u009b\u0086¿\fe\u0088Ò\u008bÃêÓ'z\nyÛ»}\u0098¦°MßKö³\u0081bå(½?ï\u009eÝË»[«.".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lllll = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lllll[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            lIIl = new String[IlIIIll(-976353721, -1453012740)];
            IIlllII();
            lIll = TimeUnit.MILLISECONDS.toNanos(1L);
            llll = TimeUnit.MILLISECONDS.toNanos(12L);
            lllIl = TimeUnit.MILLISECONDS.toNanos(25L);
            III = ConcurrentHashMap.newKeySet();
            lII = new Object();
            Illll = false;
            lIIll = false;
            IlllI = false;
            Ill = false;
            IIl = null.lI;
            lIIlI = null.I;
            IlIll = 500L;
            llI = new ConcurrentHashMap();
            IllII = new ConcurrentHashMap();
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 100;
                     break;
                  case 1:
                     var10000 = 77;
                     break;
                  case 2:
                     var10000 = 20;
                     break;
                  case 3:
                     var10000 = 65;
                     break;
                  case 4:
                     var10000 = 106;
                     break;
                  case 5:
                     var10000 = 100;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private boolean lIlll(Object var1) {
      this.lIlII.offer(var1);
      if (var1 != null && var1.l != null) {
         lIIlI(var1.l);
      }

      return true;
   }

   private long llIII(Object var1) {
      return var1 != null && var1.Il == null.II ? lllIl : llll;
   }

   private void llIIl(ChannelHandlerContext var1, long var2) {
      if (this.IIIIl.compareAndSet(false, true)) {
         Runnable var4 = () -> this.IllIII(var1);
         if (var2 > 0L) {
            var1.executor().schedule(var4, Math.max(var2, lIll), TimeUnit.NANOSECONDS);
         } else {
            if (var1.executor().inEventLoop()) {
               var4.run();
            } else {
               var1.executor().execute(var4);
            }

         }
      }
   }

   public static boolean llIlI() {
      return lIIll;
   }

   public static void llIll(Object var0, long var1) {
      <undefinedtype> var3;
      synchronized(lII) {
         if (!Illll || var0 == null || IlI != var0) {
            return;
         }

         var3 = IIl;
      }

      long var4 = Math.max(0L, var1);
      long var6 = System.nanoTime() - TimeUnit.MILLISECONDS.toNanos(var4);

      for(IIIIIlIll var9 : III) {
         var9.llIIlI(var6, var3);
      }

   }

   private boolean lllII(Object var1) {
      if (!(var1 instanceof class_2596 var2)) {
         return false;
      } else if (IIIlIII(var2)) {
         return false;
      } else if (var2 instanceof class_2856) {
         return false;
      } else {
         IllII var3 = x.IllII.IlIll();
         return var3.IIlll() && var3.IlIlI() && var3.Il() && !var2.method_55943();
      }
   }

   private void lllIl() {
      int var1 = this.lIIII.size();
      ll = var1;
      IIIll = Math.max(IIIll, var1);
   }

   private static void llllI(Object var0) {
      if (var0 instanceof class_2923 var1) {
         IllII var2 = x.IllII.IlIll();
         var2.IIlII(var1.comp_2201());
         var2.IIII(var1);
      }

   }

   public void channelRead(ChannelHandlerContext var1, Object var2) throws Exception {
      if (lIII(var2)) {
         this.Illlll(new CancellationException(lIlIII.Il(lIIl[IlIIIll(-976353724, -1214166862)])));
         IlllII(var1, var2);
      } else if (IIIlI(var2)) {
         IlllII(var1, var2);
      } else {
         if (var2 instanceof class_2596) {
            class_2596 var3 = (class_2596)var2;
            if (x.IllII.IllI(var3)) {
               IlllII(var1, var2);
               return;
            }
         }

         if (Ill) {
            if (!this.lIlll(new Record(var2, System.currentTimeMillis()) {
               private final long I;
               private final Object l;

               public Object I() {
                  return this.l;
               }

               private {
                  this.l = var1;
                  this.I = var2;
               }

               public long l() {
                  return this.I;
               }
            })) {
               this.IIllIlI(var1);
               IlllII(var1, var2);
            }

         } else {
            this.llllIl(var1);
            if (this.IIIIlI(var2)) {
               if (!this.lIlll(new Record(var2, System.currentTimeMillis()) {
                  private final long I;
                  private final Object l;

                  public Object I() {
                     return this.l;
                  }

                  private {
                     this.l = var1;
                     this.I = var2;
                  }

                  public long l() {
                     return this.I;
                  }
               })) {
                  this.IIllIlI(var1);
                  IlllII(var1, var2);
               }

            } else if (lIIll) {
               if (!this.lIlll(new Record(var2, System.currentTimeMillis()) {
                  private final long I;
                  private final Object l;

                  public Object I() {
                     return this.l;
                  }

                  private {
                     this.l = var1;
                     this.I = var2;
                  }

                  public long l() {
                     return this.I;
                  }
               })) {
                  this.IIllIlI(var1);
                  IlllII(var1, var2);
               }

            } else {
               long var6 = this.lIlIll(var2);
               if (var6 > 0L) {
                  if (var2 instanceof class_2923) {
                     class_2923 var5 = (class_2923)var2;
                     x.IllII.IlIll().II(var5.comp_2201(), var6);
                  }

                  if (!this.llIIII(new Record(var2, System.nanoTime()) {
                     private final long I;
                     private final Object l;

                     private {
                        this.l = var1;
                        this.I = var2;
                     }

                     public Object I() {
                        return this.l;
                     }

                     public long l() {
                        return this.I;
                     }
                  })) {
                     IlllII(var1, var2);
                  } else {
                     this.IllllI(var1);
                  }
               } else {
                  IlllII(var1, var2);
               }
            }
         }
      }
   }

   private void IIIIIl(ChannelHandlerContext var1) {
      try {
         if (IIIllI() == null.II) {
            this.llIIll(var1);
         } else {
            <undefinedtype> var2 = (<undefinedtype>)this.lIIII.peek();
            if (var2 == null) {
               this.IIlII.set(false);
            } else {
               long var3 = this.lIIIII(var2.lI, this.Il(var2));
               if (var3 > 0L) {
                  this.IIlII.set(false);
                  this.IllI(var1, var3);
               } else {
                  this.lIIII.poll();
                  this.IIIII.remove(var2);
                  if (this.IlIllI(var1, var2.II, var2.I)) {
                     var1.flush();
                  }

                  this.III(var2);
                  this.IIlII.set(false);
                  if (!this.lIIII.isEmpty()) {
                     this.ll(var1);
                  }

               }
            }
         }
      } catch (Exception var5) {
         this.IIlII.set(false);
         throw var5;
      }
   }

   private boolean IIIIlI(Object var1) {
      if (!(var1 instanceof class_2596 var2)) {
         return false;
      } else {
         IllII var3 = x.IllII.IlIll();
         if (var3.IlIlI() && var3.lll() && !var2.method_55943()) {
            return !var3.lI() || IIllII(var2);
         } else {
            return false;
         }
      }
   }

   public static void IIIlII() {
      lIlIl = 0L;
      l = 0L;
      IIlllI();
   }

   private static void IIIlIl(Object var0) {
      if ((var0 instanceof class_2708 || var0 instanceof class_2724) && var0 instanceof class_2596 var1) {
         IIIllIl(() -> {
            lIllIIl var1x = lIllIIl.Il();
            if (var1x != null && var1x.IIl() != null) {
               var1x.IIl().Illlll(var1);
            }

         });
      }
   }

   public static <undefinedtype> IIIllI() {
      return lIIlI;
   }

   private void IIIlll(ChannelHandlerContext var1) throws Exception {
      ArrayList var2 = new ArrayList();

      <undefinedtype> var3;
      while((var3 = (<undefinedtype>)this.Illl.poll()) != null) {
         var2.add(var3);
      }

      for(<undefinedtype> var5 : var2) {
         Object var6 = var5.Il();
         this.lII(var1, var6, var5.II());
         if (lIlI(var6)) {
            this.IIlI = true;
         }
      }

   }

   private boolean IIlIII(long var1, Object var3) {
      <undefinedtype> var4 = (<undefinedtype>)this.lllII.peek();
      return var4 != null && (var3 == null || var4.Il == var3) && var4.lI <= var1;
   }

   private static boolean IIlIIl(Object var0) {
      return var0 instanceof class_2828;
   }

   static boolean IIlIlI(class_2596<?> var0, boolean var1, boolean var2) {
      return var0 != null && !IIIlIII(var0) && (IIlIIl(var0) || var0 instanceof class_9836 || lIlI(var0) || var0 instanceof class_2868 || var1 || var2);
   }

   private static boolean IIllII(class_2596<?> var0) {
      if (var0 == null) {
         return false;
      } else {
         <undefinedtype> var1 = lIII;
         if (var1 == null) {
            return false;
         } else {
            try {
               return var1.l().test(var0);
            } catch (Throwable var3) {
               return false;
            }
         }
      }
   }

   public static void IIllIl(long var0) {
      long var2 = Math.max(0L, Math.min(var0, 60000L));
      if (IlIll != var2) {
         IlIll = var2;
         IIlllI();
      }
   }

   public static void IIlllI() {
      for(IIIIIlIll var1 : III) {
         var1.lIlII();
      }

   }

   private boolean IIllll(Object var1) {
      if (this.IIII.size() >= 4) {
         return false;
      } else {
         this.IIII.offer(var1);
         return true;
      }
   }

   public static boolean IlIIII() {
      return Illll;
   }

   private static boolean IlIIIl(class_2596<?> var0) {
      return lll(var0) != null;
   }

   private long IlIIlI(Object var1) {
      long var2 = this.IlIII(var1.I);
      if (var2 <= 0L) {
         return 0L;
      } else if (this.IIII.size() > 4) {
         return 0L;
      } else {
         long var4 = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - var1.Il);
         return var4 >= 2500L ? var4 : Math.min(var2, 2500L);
      }
   }

   public static long IlIIll() {
      return II;
   }

   public static long IlIlII() {
      return IlIll;
   }

   private static void IlIlIl() {
      llI.clear();
      IllII.clear();
      IIllI = false;
   }

   private boolean IlIllI(ChannelHandlerContext var1, Object var2, ChannelPromise var3) {
      if (var1 != null && var1.channel().isOpen()) {
         ChannelPromise var4 = var3;
         if (var2 instanceof class_2596) {
            class_2596 var5 = (class_2596)var2;
            boolean var6 = var5 instanceof class_2935;
            boolean var7 = lIllll(var5);
            if (var6 || var7) {
               var4 = var3.isVoid() ? var1.newPromise() : var3;
               var4.addListener((var4x) -> {
                  if (var4x.isSuccess()) {
                     if (var6) {
                        this.lllIII(var5);
                     }

                     if (var7) {
                        this.IIllIll(var5);
                     }

                  }
               });
            }
         }

         try {
            var1.write(var2, var4);
            return true;
         } catch (Error | RuntimeException var8) {
            var4.tryFailure(var8);
            return false;
         }
      } else {
         var3.tryFailure(new ClosedChannelException());
         return false;
      }
   }

   private void IlIlll(Object var1) {
      ChannelHandlerContext var2 = this.llIl;
      if (var2 == null) {
         if (var1.Il()) {
            this.llIlIl(this.llII, new ClosedChannelException());
         }

         if (var1.II()) {
            this.lIlII.clear();
         }

      } else {
         if (var1.Il()) {
            Runnable var3 = () -> this.IlIIl(var2);
            if (var2.executor().inEventLoop()) {
               var3.run();
            } else {
               var2.executor().execute(var3);
            }
         }

         if (var1.Il() && !this.IIII.isEmpty()) {
            this.IlIIl.set(false);
            this.lIIIlI(var2);
         }

         if (var1.II()) {
            this.IIIIl();
         }

         if (var1.II() && !this.lllI.isEmpty()) {
            this.IIlIl.set(false);
            this.IllllI(var2);
         }

      }
   }

   private void IllIII(ChannelHandlerContext var1) {
      try {
         <undefinedtype> var2 = (<undefinedtype>)this.lllII.peek();
         boolean var3 = var2 != null && var2.Il == null.II ? this.IIlIIlI(var1) : this.lIllII(var1);
         if (var3 && var1.channel().isOpen()) {
            var1.flush();
            this.lIlI = System.nanoTime();
         }

         this.IIIIl.set(false);
         if (!this.lllII.isEmpty()) {
            this.llIIl(var1, this.llIII((<undefinedtype>)this.lllII.peek()));
         } else {
            this.lIlll = false;
            llII();
         }

      } catch (Exception var4) {
         this.IIIIl.set(false);
         throw var4;
      }
   }

   public static void IllIlI(Predicate<class_2596<?>> var0, Consumer<class_2596<?>> var1) {
      if (var0 != null && var1 != null) {
         lIII = new Record(var0, var1) {
            private final Predicate<class_2596<?>> I;
            private final Consumer<class_2596<?>> l;

            private {
               this.I = var1;
               this.l = var2;
            }

            public Consumer<class_2596<?>> I() {
               return this.l;
            }

            public Predicate<class_2596<?>> l() {
               return this.I;
            }
         };
      } else {
         lIII = null;
      }
   }

   private boolean IllIll(Object var1) {
      if (llIII) {
         return true;
      } else {
         boolean var2 = false;
         if (IIllI && var1 instanceof class_2596) {
            class_2596 var3 = (class_2596)var1;
            var2 = llI.remove(new Object(var3) {
               private final class_2596<?> I;

               public int hashCode() {
                  return System.identityHashCode(this.I);
               }

               public boolean equals(Object var1) {
                  boolean var10000;
                  if (var1 instanceof <undefinedtype> var2) {
                     if (this.I == var2.I) {
                        var10000 = true;
                        return var10000;
                     }
                  }

                  var10000 = false;
                  return var10000;
               }

               private {
                  this.I = var1;
               }
            }) != null;
            if (llI.isEmpty()) {
               IIllI = false;
            }
         }

         return var2 || IllllIlI.IlllIl() || IlIlIl.IIIII();
      }
   }

   public static void IlllII(ChannelHandlerContext var0, Object var1) {
      llllI(var1);
      var0.fireChannelRead(var1);
      IIIlIl(var1);
   }

   public static void IlllIl() {
      for(IIIIIlIll var1 : III) {
         ChannelHandlerContext var2 = var1.llIl;
         if (var2 != null) {
            Runnable var3 = () -> var1.IIllIII(var2);
            if (var2.executor().inEventLoop()) {
               var3.run();
            } else {
               var2.executor().execute(var3);
            }
         }
      }

   }

   private void IllllI(ChannelHandlerContext var1) {
      this.IIlll(var1, 0L);
   }

   private void Illlll(Throwable var1) {
      IIl();
      IIlllIlI.II().lI();
      this.lIllIl(var1);
      this.lllI.clear();
      this.lIlII.clear();
      this.IIIII.clear();
      this.llllll();
      IlIlIl();
      this.IlIIl.set(false);
      this.IIlII.set(false);
      this.IIlIl.set(false);
      this.IIIIl.set(false);
      this.llIll.set(false);
      this.lIlll = false;
      this.llllI = 0L;
      this.IIIlI = 0L;
      this.lIlI = 0L;
      this.IllIl = 0L;
      lIIll = false;
      IlllI = false;
      lIlIl = 0L;
      l = 0L;
      lIIlII();
      IllII var2 = x.IllII.IlIll();
      var2.IIIlI(false);
      var2.llI();
      IllllIlI.III();
      IlIlIl.IlIIl();
   }

   private long lIIIII(long var1, long var3) {
      return var3 <= 0L ? 0L : var1 + TimeUnit.MILLISECONDS.toNanos(var3) - System.nanoTime();
   }

   public void lIIIIl() {
      IIl();
      this.lIllIl(new ClosedChannelException());
      this.lllI.clear();
      this.lIlII.clear();
      this.IIIII.clear();
      this.IIlI = false;
      this.IIll = false;
      this.llIlI = false;
      this.IlIII = false;
      this.IlIIl.set(false);
      this.IIlII.set(false);
      this.IIlIl.set(false);
      this.IIIIl.set(false);
      this.llIll.set(false);
      this.lIlll = false;
      this.llllI = 0L;
      this.IIIlI = 0L;
      this.lIlI = 0L;
      this.IllIl = 0L;
   }

   private void lIIIlI(ChannelHandlerContext var1) {
      this.IlIll(var1, 0L);
   }

   private void lIIIll(ChannelHandlerContext var1) {
      try {
         <undefinedtype> var2 = (<undefinedtype>)this.IIII.peek();
         if (var2 == null) {
            this.IlIIl.set(false);
         } else {
            long var3 = this.lIIIII(var2.Il, this.IlIIlI(var2));
            if (var3 > 0L) {
               this.IlIIl.set(false);
               this.IlIll(var1, var3);
            } else {
               this.IIII.poll();
               if (this.IlIllI(var1, var2.I, var2.II)) {
                  var1.flush();
                  this.llllI = System.nanoTime();
               }

               this.IlIIl.set(false);
               if (!this.IIII.isEmpty()) {
                  this.lIIIlI(var1);
               }

            }
         }
      } catch (Exception var5) {
         this.IlIIl.set(false);
         throw var5;
      }
   }

   private static void lIIlII() {
      synchronized(lII) {
         Illll = false;
         IlI = null;
         lI = null;
         lll = null;
         IIl = null.lI;
         Ill = false;
      }
   }

   public static long lIIlIl() {
      return lIIIl;
   }

   public static void lIIllI() {
      Ill = true;
   }

   private void lIIlll(ChannelHandlerContext var1, long var2) {
      <undefinedtype> var4;
      while((var4 = (<undefinedtype>)this.lIlII.peek()) != null && var4.I <= var2) {
         var4 = (<undefinedtype>)this.lIlII.poll();
         if (var4 != null && var1.channel().isOpen()) {
            IlllII(var1, var4.l);
         }
      }

   }

   static void lIlIII(boolean var0) {
      llIII = var0;
   }

   public static boolean lIlIIl() {
      if (lI != null && lll == null.II) {
         return true;
      } else {
         for(IIIIIlIll var1 : III) {
            if (var1.lIlll) {
               return true;
            }

            for(<undefinedtype> var3 : var1.lllII) {
               if (var3.Il == null.II) {
                  return true;
               }
            }
         }

         return false;
      }
   }

   private void lIlIlI(Throwable var1) {
      <undefinedtype> var2;
      while((var2 = (<undefinedtype>)this.lIIII.poll()) != null) {
         this.IIIII.remove(var2);
         var2.I.tryFailure(var1);
      }

   }

   private long lIlIll(Object var1) {
      if (var1 instanceof class_2596 var2) {
         IllII var3 = x.IllII.IlIll();
         return var3.IIlll() && var3.lll() && !var2.method_55943() ? Math.max(0L, var3.IIIll()) : 0L;
      } else {
         return 0L;
      }
   }

   private boolean lIllII(ChannelHandlerContext var1) {
      ArrayList var2 = new ArrayList(IlIIIll(-976353723, -561602887));

      <undefinedtype> var3;
      while(var2.size() < IlIIIll(-976353718, 1737084349) && (var3 = (<undefinedtype>)this.lllII.poll()) != null) {
         var2.add(var3);
      }

      boolean var4 = false;

      for(<undefinedtype> var6 : var2) {
         var4 |= this.IlIllI(var1, var6.II, var6.l);
      }

      return var4;
   }

   private void lIllIl(Throwable var1) {
      this.IIlllll(this.Illl, var1);
      this.IIlllll(this.IIII, var1);
      this.lIlIlI(var1);
      this.llIlIl(this.lllII, var1);
      this.llIlIl(this.llII, var1);
   }

   private void lIlllI(ChannelHandlerContext var1) {
      try {
         <undefinedtype> var2 = (<undefinedtype>)this.lllI.peek();
         if (var2 == null) {
            this.IIlIl.set(false);
         } else {
            long var3 = this.lIIIII(var2.I, this.lIlIll(var2.l));
            if (var3 > 0L) {
               this.IIlIl.set(false);
               this.IIlll(var1, var3);
            } else {
               this.lllI.poll();
               if (var1.channel().isOpen()) {
                  IlllII(var1, var2.l);
                  this.IIIlI = System.nanoTime();
               }

               this.IIlIl.set(false);
               if (!this.lllI.isEmpty()) {
                  this.IllllI(var1);
               }

            }
         }
      } catch (Exception var5) {
         this.IIlIl.set(false);
         throw var5;
      }
   }

   private static boolean lIllll(class_2596<?> var0) {
      if (!(var0 instanceof class_2868) && !(var0 instanceof class_2828)) {
         if (!(var0 instanceof class_2824)) {
            return false;
         } else {
            lIllIIl var1 = lIllIIl.Il();
            IIllIlII var2 = var1 == null ? null : var1.IIl();
            return var2 != null && var2.IIIIl(var0);
         }
      } else {
         return true;
      }
   }

   private boolean llIIII(Object var1) {
      if (this.lllI.size() >= IlIIIll(-976353717, -2104126978)) {
         return false;
      } else {
         this.lllI.offer(var1);
         return true;
      }
   }

   private void llIIIl(ChannelHandlerContext var1, Object var2, ChannelPromise var3) {
      ChannelPromise var4 = var3.isVoid() ? var1.newPromise() : var3;
      var4.addListener((var2x) -> {
         if (!var2x.isSuccess() && var1.channel().isOpen()) {
            var1.executor().execute(() -> {
               if (var1.channel().isOpen()) {
                  var1.writeAndFlush(var2, var1.newPromise());
               }

            });
         }
      });
      this.IlIllI(var1, var2, var4);
   }

   private void llIIlI(long var1, Object var3) {
      ChannelHandlerContext var4 = this.llIl;
      if (var4 != null && !this.lllII.isEmpty()) {
         this.IIIIIll(var4, var1, var3, 0L);
      }
   }

   private void llIIll(ChannelHandlerContext var1) {
      <undefinedtype> var2 = null;
      long var3 = Long.MAX_VALUE;

      for(<undefinedtype> var6 : this.lIIII) {
         long var7 = this.lIIIII(var6.lI, this.Il(var6));
         if (var7 <= 0L) {
            if (var2 == null || var6.l > var2.l || var6.l == var2.l && var6.lI > var2.lI) {
               var2 = var6;
            }
         } else {
            var3 = Math.min(var3, var7);
         }
      }

      if (var2 == null) {
         this.IIlII.set(false);
         if (!this.lIIII.isEmpty()) {
            this.IllI(var1, var3 == Long.MAX_VALUE ? 0L : var3);
         }

      } else if (!this.lIIII.remove(var2)) {
         this.IIlII.set(false);
         if (!this.lIIII.isEmpty()) {
            this.ll(var1);
         }

      } else {
         this.IIlI(var2.l);
         this.IIIII.remove(var2);
         if (this.IlIllI(var1, var2.II, var2.I)) {
            var1.flush();
         }

         this.III(var2);
         this.IIlII.set(false);
         if (!this.lIIII.isEmpty()) {
            this.ll(var1);
         }

      }
   }

   public void handlerAdded(ChannelHandlerContext var1) {
      this.llIl = var1;
      III.add(this);
   }

   private void llIlII() {
      ChannelHandlerContext var1 = this.llIl;
      if (var1 == null) {
         this.llIlIl(this.lllII, new ClosedChannelException());
         this.lIlll = false;
         llII();
      } else {
         this.lIlll = this.lllII.peek() != null && ((<undefinedtype>)this.lllII.peek()).Il == null.II;
         this.llIIl(var1, 0L);
      }
   }

   private void llIlIl(ConcurrentLinkedQueue<<undefinedtype>> var1, Throwable var2) {
      <undefinedtype> var3;
      while((var3 = (<undefinedtype>)var1.poll()) != null) {
         var3.l.tryFailure(var2);
      }

   }

   public static void llIllI(class_2596<?> var0) {
      if (var0 != null && (IlIlIl.Illl() || IllllIlI.IlIl())) {
         IllII.put(new Object(var0) {
            private final class_2596<?> I;

            public int hashCode() {
               return System.identityHashCode(this.I);
            }

            public boolean equals(Object var1) {
               boolean var10000;
               if (var1 instanceof <undefinedtype> var2) {
                  if (this.I == var2.I) {
                     var10000 = true;
                     return var10000;
                  }
               }

               var10000 = false;
               return var10000;
            }

            private {
               this.I = var1;
            }
         }, Boolean.TRUE);
      }

      if (lIllIIl.Il() != null && IIlIlI(var0, IllllIlI.IlllIl(), IlIlIl.IIIII())) {
         llI.put(new Object(var0) {
            private final class_2596<?> I;

            public int hashCode() {
               return System.identityHashCode(this.I);
            }

            public boolean equals(Object var1) {
               boolean var10000;
               if (var1 instanceof <undefinedtype> var2) {
                  if (this.I == var2.I) {
                     var10000 = true;
                     return var10000;
                  }
               }

               var10000 = false;
               return var10000;
            }

            private {
               this.I = var1;
            }
         }, Boolean.TRUE);
         IIllI = true;
      }
   }

   private llllIll llIlll() {
      lIllIIl var1 = lIllIIl.Il();
      if (var1 == null) {
         return null;
      } else {
         llllIll var2 = var1.IIl().llIIlI();
         if (var2 != null && var2.IIIIIlI()) {
            return var2.IlIl() ? var2 : null;
         } else {
            return null;
         }
      }
   }

   private void lllIII(Object var1) {
      if (var1 instanceof class_2935 var2) {
         x.IllII.IlIll().llll(var2.method_12700());
      }

   }

   static void lllIIl() {
      lIIlII();
   }

   public static boolean lllIlI(Object var0) {
      return var0 != null && Illll && IlI == var0;
   }

   public static void lllIll() {
      for(IIIIIlIll var1 : III) {
         var1.IllII();
      }

   }

   private void llllIl(ChannelHandlerContext var1) {
      IllII var2 = x.IllII.IlIll();
      if (!Ill && (var2.IIlll() || var2.lllI())) {
         IIll();
      }
   }

   public static int lllllI() {
      long var0 = 0L;

      for(IIIIIlIll var3 : III) {
         var0 += (long)var3.lllII.size();
      }

      return var0 > 2147483647L ? IlIIIll(-976353720, 232974944) : (int)var0;
   }

   private void llllll() {
      this.IIlI = false;
      this.IIll = false;
      this.llIlI = false;
      this.IlIII = false;
   }

   private void IIIIIII(long var1) {
      ChannelHandlerContext var3 = this.llIl;
      if (var3 == null) {
         this.lIlII.clear();
      } else {
         Runnable var4 = () -> this.lIIlll(var3, var1);
         if (var3.executor().inEventLoop()) {
            var4.run();
         } else {
            var3.executor().execute(var4);
         }

      }
   }

   private boolean IIIIIIl(Object var1) {
      if (this.lllII.size() >= IlIIIll(-976353719, 1231954396)) {
         return false;
      } else {
         this.lllII.offer(var1);
         return true;
      }
   }

   private static long IIIIIlI() {
      long var0 = System.currentTimeMillis();
      if (var0 > l) {
         lIlIl = 0L;
         l = 0L;
         return 0L;
      } else {
         return Math.max(0L, lIlIl);
      }
   }

   private void IIIIIll(ChannelHandlerContext var1, long var2, Object var4, long var5) {
      if (this.IIIIl.compareAndSet(false, true)) {
         Runnable var7 = () -> this.IIlII(var1, var2, var4);
         if (var5 > 0L) {
            var1.executor().schedule(var7, Math.max(var5, lIll), TimeUnit.NANOSECONDS);
         } else {
            if (var1.executor().inEventLoop()) {
               var7.run();
            } else {
               var1.executor().execute(var7);
            }

         }
      }
   }

   private void IIIIlII(ChannelHandlerContext var1, Object var2, ChannelPromise var3) throws Exception {
      if (this.IIll && !this.Illl.isEmpty()) {
         this.IlIII = false;
         this.IIIlll(var1);
      }

      this.lII(var1, var2, var3);
      this.llIlI = false;
      this.IlIII = true;
      this.IIlI = false;
      this.IIll = !this.Illl.isEmpty();
   }

   public void handlerRemoved(ChannelHandlerContext var1) {
      this.llIl = null;
      III.remove(this);
      this.lIIIIl();
      if (III.isEmpty()) {
         lIIlII();
         IlIlIl();
         IllllIlI.IlIIlll();
         IlIlIl.IlIIl();
      }

   }

   private static boolean IIIIlIl(Object var0) {
      if (!(var0 instanceof class_2848 var1)) {
         return false;
      } else {
         class_2848.class_2849 var2 = var1.method_12365();
         return var2 == class_2849.field_12981 || var2 == class_2849.field_12985;
      }
   }

   public static void IIIIllI(long var0, long var2) {
      long var4 = Math.max(0L, Math.min(var0, 2500L));
      if (var4 > 0L) {
         long var6 = Math.max(var4, Math.min(var2, 5000L));
         long var8 = System.currentTimeMillis();
         if (var8 > l) {
            lIlIl = 0L;
         }

         long var10 = var8 + var6;
         lIlIl = Math.max(lIlIl, var4);
         l = Math.max(l, var10);
         IIlllI();
      }
   }

   private static Integer IIIIlll(class_2596<?> var0, String... var1) {
      for(String var5 : var1) {
         try {
            Method var6 = var0.getClass().getMethod(var5);
            Object var7 = var6.invoke(var0);
            if (var7 instanceof Number var13) {
               return var13.intValue();
            }
         } catch (ReflectiveOperationException var10) {
         }

         try {
            Field var11 = var0.getClass().getDeclaredField(var5);
            var11.setAccessible(true);
            Object var12 = var11.get(var0);
            if (var12 instanceof Number var8) {
               return var8.intValue();
            }
         } catch (ReflectiveOperationException var9) {
         }
      }

      return null;
   }

   private static boolean IIIlIII(Object var0) {
      if (!(var0 instanceof class_2596 var1)) {
         return false;
      } else {
         String var2 = var1.getClass().getSimpleName();
         return var1 instanceof class_2827 || var1 instanceof class_6374 || var1 instanceof class_7640 || var1 instanceof class_8590 || var1 instanceof class_8591 || var1 instanceof class_2793 || var2.equals(lIlIII.Il(lIIl[IlIIIll(-976353714, -639851116)])) || IlIIIl(var1);
      }
   }

   public static boolean IIIlIIl(Object var0, boolean var1) {
      if (var0 == null) {
         return false;
      } else {
         synchronized(lII) {
            if (!Illll || IlI != var0) {
               return false;
            }

            Illll = false;
            IlI = null;
            lI = var0;
            lll = IIl;
         }

         for(IIIIIlIll var3 : III) {
            if (var1) {
               var3.IIlllIl();
            } else {
               var3.llIlII();
            }
         }

         llII();
         return true;
      }
   }

   public static void IIIlIlI() {
      <undefinedtype> var0 = x.IllII.IlIll().llI();

      try {
         for(IIIIIlIll var2 : III) {
            var2.lI(var0);
         }
      } finally {
         Ill = false;
      }

   }

   public static int IIIlIll() {
      return ll;
   }

   private Integer IIIllII(Object var1) {
      if (var1 instanceof class_2596 var2) {
         return lll(var2);
      } else {
         return null;
      }
   }

   private static void IIIllIl(Runnable var0) {
      class_310 var1 = class_310.method_1551();
      if (var1 != null && !var1.method_18854()) {
         var1.execute(var0);
      } else {
         var0.run();
      }

   }

   // $FF: synthetic method
   private static void IIlIIII(class_2596 var0) {
      <undefinedtype> var1 = lIII;
      if (var1 != null) {
         try {
            var1.I().accept(var0);
         } catch (Throwable var3) {
         }

      }
   }

   private ChannelPromise IIlIIIl(ChannelHandlerContext var1, Object var2, ChannelPromise var3) {
      if (var2 instanceof class_2868 var4) {
         IIllIlll.IIIl(var4, var4.method_12442());
         ChannelPromise var5 = var3.isVoid() ? var1.newPromise() : var3;
         var5.addListener((var1x) -> {
            if (!var1x.isSuccess()) {
               IllllIlI.IIIIIll(var4);
            }

         });
         return var5;
      } else {
         return var3;
      }
   }

   private boolean IIlIIlI(ChannelHandlerContext var1) {
      int var2 = 0;
      boolean var3 = false;
      ArrayList var4 = new ArrayList(IlIIIll(-976353713, -1374745092));

      <undefinedtype> var5;
      while(var2 < IlIIIll(-976353716, -1931376901) && (var5 = (<undefinedtype>)this.lllII.peek()) != null && (var5.Il == null.II || var2 <= 0)) {
         var5 = (<undefinedtype>)this.lllII.poll();
         if (var5 == null) {
            break;
         }

         ++var2;
         if (var5.Il == null.II && var5.II instanceof class_2851) {
            if (var3) {
               var5.l.trySuccess();
               continue;
            }

            var3 = true;
         }

         var4.add(var5);
         if (var5.Il == null.II && var5.II instanceof class_9836) {
            break;
         }
      }

      boolean var6 = false;

      for(<undefinedtype> var8 : var4) {
         var6 |= this.IlIllI(var1, var8.II, var8.l);
      }

      return var6;
   }

   private long IIlIIll(long var1, long var3, long var5) {
      return var1 <= 0L ? 0L : Math.max(0L, var1 + var3 - var5);
   }

   private void IIlIlII(ChannelHandlerContext var1, Object var2, ChannelPromise var3) throws Exception {
      if (this.IIll && !this.Illl.isEmpty()) {
         this.IlIII = false;
         this.IIIlll(var1);
      }

      this.lII(var1, var2, var3);
      this.IIlI = false;
      this.IIll = false;
   }

   private void IIlIlIl(ChannelHandlerContext var1) {
      try {
         long var2 = System.nanoTime();
         long var4 = this.IIlIIll(this.IllIl, llll, var2);
         if (var4 > 0L) {
            this.llIll.set(false);
            this.IIIl(var1, var4);
         } else {
            int var6;
            <undefinedtype> var7;
            for(var6 = 0; var6 < IlIIIll(-976353715, 1305927194) && (var7 = (<undefinedtype>)this.lIlII.poll()) != null; ++var6) {
               if (var1.channel().isOpen()) {
                  IlllII(var1, var7.l);
               }
            }

            if (var6 > 0) {
               this.IllIl = System.nanoTime();
            }

            this.llIll.set(false);
            if (!this.lIlII.isEmpty()) {
               this.IIIl(var1, llll);
            }

         }
      } catch (Exception var8) {
         this.llIll.set(false);
         throw var8;
      }
   }

   private long IIlIllI(Object var1) {
      return 0L;
   }

   private void IIllIII(ChannelHandlerContext var1) {
      try {
         if (!this.Illl.isEmpty()) {
            this.IIIlll(var1);
         }
      } catch (Exception var6) {
         this.IIlllll(this.Illl, var6);
      } finally {
         this.llllll();
      }

   }

   private void IIllIIl() {
      ChannelHandlerContext var1 = this.llIl;
      if (var1 == null) {
         this.lIlIlI(new ClosedChannelException());
         this.IIlII.set(false);
      } else {
         Runnable var2 = () -> {
            try {
               this.IIlII.set(false);
               boolean var3 = false;

               <undefinedtype> var2;
               while((var2 = (<undefinedtype>)this.lIIII.poll()) != null) {
                  this.IIIII.remove(var2);
                  var3 |= this.IlIllI(var1, var2.II, var2.I);
                  this.III(var2);
               }

               if (var3 && var1.channel().isOpen()) {
                  var1.flush();
               }
            } catch (Exception var4) {
               this.IIlII.set(false);
            }

         };
         if (var1.executor().inEventLoop()) {
            var2.run();
         } else {
            var1.executor().execute(var2);
         }

      }
   }

   private void IIllIlI(ChannelHandlerContext var1) {
      <undefinedtype> var2;
      while((var2 = (<undefinedtype>)this.lIlII.poll()) != null) {
         if (var1.channel().isOpen()) {
            IlllII(var1, var2.l);
         }
      }

      this.llIll.set(false);
   }

   private void IIllIll(class_2596<?> var1) {
      Runnable var2 = () -> {
         lIllIIl var1x = lIllIIl.Il();
         IIllIlII var2 = var1x == null ? null : var1x.IIl();
         if (var2 != null) {
            var2.lIllll(var1);
         }

      };
      class_310 var3 = class_310.method_1551();
      if (var3 != null && !var3.method_18854()) {
         var3.execute(var2);
      } else {
         var2.run();
      }

   }

   private static void IIlllII() {
      lIIl[0] = llll(IlIIlII(-2086616844, 210596944).toCharArray(), 49051L, IlIIIll(-976353678, -1630456457));
      lIIl[1] = llll(IlIIlII(-2086616843, -1830718209).toCharArray(), 11193L, IlIIIll(-976353677, 1831990309));
      lIIl[2] = llll(IlIIlII(-2086616842, 2034063444).toCharArray(), 69062L, IlIIIll(-976353680, -1873389322));
      lIIl[3] = llll(IlIIlII(-2086616841, -1567160318).toCharArray(), 43708L, IlIIIll(-976353679, -1666952796));
      lIIl[4] = llll(IlIIlII(-2086616848, 1895783014).toCharArray(), 15230L, IlIIIll(-976353674, -826538812));
      lIIl[5] = llll(IlIIlII(-2086616847, 1587835524).toCharArray(), 31161L, IlIIIll(-976353673, 758570957));
      lIIl[IlIIIll(-976353676, 164499847)] = llll(IlIIlII(-2086616846, -40934013).toCharArray(), 8877L, IlIIIll(-976353675, 1038189103));
      lIIl[IlIIIll(-976353670, 1381275922)] = llll(IlIIlII(-2086616845, 814025706).toCharArray(), 54348L, IlIIIll(-976353669, 844243207));
      lIIl[IlIIIll(-976353672, 685948075)] = llll(IlIIlII(-2086616836, -499824880).toCharArray(), 24552L, IlIIIll(-976353671, 1037953957));
      lIIl[IlIIIll(-976353666, 1905685306)] = llll(IlIIlII(-2086616835, 1935963378).toCharArray(), 7469L, IlIIIll(-976353665, -842947525));
      lIIl[IlIIIll(-976353668, 1881030245)] = llll(IlIIlII(-2086616834, -1438688468).toCharArray(), 96320L, IlIIIll(-976353667, -314244041));
      lIIl[IlIIIll(-976353694, -338396401)] = llll(IlIIlII(-2086616833, -1423948503).toCharArray(), 15144L, IlIIIll(-976353693, 2111203313));
      lIIl[IlIIIll(-976353696, 819487759)] = llll(IlIIlII(-2086616840, -629071356).toCharArray(), 71117L, IlIIIll(-976353695, 364866445));
      lIIl[IlIIIll(-976353690, 628239736)] = llll(IlIIlII(-2086616839, 754529717).toCharArray(), 18524L, IlIIIll(-976353689, -1521385202));
      lIIl[IlIIIll(-976353692, -1277018967)] = llll(IlIIlII(-2086616838, -1905237673).toCharArray(), 15800L, IlIIIll(-976353691, 1837274600));
      lIIl[IlIIIll(-976353686, 605339826)] = llll(IlIIlII(-2086616837, 751138206).toCharArray(), 55289L, IlIIIll(-976353685, -2130401349));
      lIIl[IlIIIll(-976353688, -495680221)] = llll(IlIIlII(-2086616860, -12499430).toCharArray(), 85071L, IlIIIll(-976353687, 1744873279));
      lIIl[IlIIIll(-976353682, -1820219780)] = llll(IlIIlII(-2086616859, -1890967867).toCharArray(), 8233L, IlIIIll(-976353681, -1485978851));
      lIIl[IlIIIll(-976353684, -873608618)] = llll(IlIIlII(-2086616858, -1412288491).toCharArray(), 99252L, IlIIIll(-976353683, -1631974419));
      lIIl[IlIIIll(-976353774, -1283817048)] = llll(IlIIlII(-2086616857, 1761744871).toCharArray(), 25043L, IlIIIll(-976353773, 803777850));
      lIIl[IlIIIll(-976353776, -21718935)] = llll(IlIIlII(-2086616864, 1060064459).toCharArray(), 87172L, IlIIIll(-976353775, 924005257));
      lIIl[IlIIIll(-976353770, -409353017)] = llll(IlIIlII(-2086616863, -1307873161).toCharArray(), 52572L, IlIIIll(-976353769, -1665715130));
   }

   private void IIlllIl() {
      ChannelHandlerContext var1 = this.llIl;
      if (var1 == null) {
         this.llIlIl(this.lllII, new ClosedChannelException());
         this.IIIIl.set(false);
         this.lIlll = false;
         llII();
      } else {
         Runnable var2 = () -> this.I(var1);
         if (var1.executor().inEventLoop()) {
            var2.run();
         } else {
            try {
               var1.executor().submit(var2).sync();
            } catch (InterruptedException var4) {
               Thread.currentThread().interrupt();
               this.llIlIl(this.lllII, var4);
               this.IIIIl.set(false);
               this.lIlll = false;
               llII();
            }

         }
      }
   }

   public static void IIllllI() {
      IlllI = false;
      lIIll = false;

      for(IIIIIlIll var1 : III) {
         var1.IIIIl();
      }

   }

   private void IIlllll(ConcurrentLinkedQueue<<undefinedtype>> var1, Throwable var2) {
      <undefinedtype> var3;
      while((var3 = (<undefinedtype>)var1.poll()) != null) {
         var3.II.tryFailure(var2);
      }

   }

   public static boolean IlIIIII(Object var0, Object var1) {
      if (var0 == null) {
         return false;
      } else {
         <undefinedtype> var2 = var1 == null ? null.lI : var1;
         synchronized(lII) {
            if (!Illll) {
               if (lI != null) {
                  return false;
               } else {
                  IlI = var0;
                  IIl = var2;
                  Illll = true;
                  return true;
               }
            } else {
               return IlI == var0 && IIl == var2;
            }
         }
      }
   }

   private <undefinedtype> IlIIIlI(Object var1, ChannelPromise var2, Object var3) {
      return new Record(var1, var2, var3, System.nanoTime(), this.IlII.incrementAndGet()) {
         private final long I;
         private final ChannelPromise l;
         private final Object II;
         private final <undefinedtype> Il;
         private final long lI;

         public long I() {
            return this.I;
         }

         public long l() {
            return this.lI;
         }

         public <undefinedtype> II() {
            return this.Il;
         }

         public Object Il() {
            return this.II;
         }

         public ChannelPromise lI() {
            return this.l;
         }

         private {
            this.II = var1;
            this.l = var2;
            this.Il = var3;
            this.lI = var4;
            this.I = var6;
         }
      };
   }

   private static int IlIIIll(int var0, int var1) {
      return lllll[var0 ^ -976353710] ^ var1 ^ var0;
   }

   private static String IlIIlII(int var0, int var1) {
      int var3 = var0 ^ -2086616844;
      char[] var4 = IIIIII[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IIIIIl[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IIIIIl[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 813684055;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 190;
               break;
            case 1:
               var9 = 166;
               break;
            case 2:
               var9 = 28;
               break;
            case 3:
               var9 = 35;
               break;
            case 4:
               var9 = 50;
               break;
            case 5:
               var9 = 106;
               break;
            case 6:
               var9 = 152;
               break;
            case 7:
               var9 = 53;
               break;
            case 8:
               var9 = 203;
               break;
            case 9:
               var9 = 121;
               break;
            case 10:
               var9 = 184;
               break;
            case 11:
               var9 = 113;
               break;
            case 12:
               var9 = 232;
               break;
            case 13:
               var9 = 253;
               break;
            case 14:
               var9 = 26;
               break;
            case 15:
               var9 = 200;
               break;
            case 16:
               var9 = 22;
               break;
            case 17:
               var9 = 178;
               break;
            case 18:
               var9 = 142;
               break;
            case 19:
               var9 = 21;
               break;
            case 20:
               var9 = 21;
               break;
            case 21:
               var9 = 103;
               break;
            case 22:
               var9 = 135;
               break;
            case 23:
               var9 = 249;
               break;
            case 24:
               var9 = 166;
               break;
            case 25:
               var9 = 75;
               break;
            case 26:
               var9 = 253;
               break;
            case 27:
               var9 = 41;
               break;
            case 28:
               var9 = 72;
               break;
            case 29:
               var9 = 160;
               break;
            case 30:
               var9 = 85;
               break;
            case 31:
               var9 = 222;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
