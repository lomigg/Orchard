package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1764;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_746;
import net.minecraft.class_9278;
import net.minecraft.class_9334;
import net.minecraft.class_239.class_240;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;

@Environment(EnvType.CLIENT)
public final class IllI extends IIIIIIIlI {
   private static final int I = 400;
   private float l;
   private long II;
   private final IIIllIIII Il;
   private final lIIIIl lI;
   private final IlIlIll ll;
   private static final double III = 0.99;
   private static final int IIl = 9;
   private static final double IlI = 0.05;
   private final IIIllIIII Ill;
   private long lII;
   private static String[] lIl;
   private boolean llI;
   private final IIIllIIII lll;
   private static final double IIII = (double)0.0F;
   private final IlIIIlIlI<<undefinedtype>> IIIl;
   private <undefinedtype> IIlI;
   private static final double IIll = 1.6;
   private static final long IlII = 1000L;
   private final IIIllIIII IlIl;
   private Runnable IllI;
   private float Illl;
   private class_1657 lIII;
   private static final double lIIl = 3.15;
   private static final double lIlI = 0.18;
   private int lIll;
   private final lIIIIl llII;
   private static final int[] llIl;
   private static final String[] lllI;
   private static final Object[] llll;

   private class_243 ll(class_310 var1, class_1657 var2) {
      class_243 var3 = var2.method_5829().method_1005();
      return this.IlIll(var1, var1.field_1724.method_33571(), var3) ? var3 : null;
   }

   private class_243 IlI(float var1, float var2) {
      double var3 = Math.toRadians((double)var1);
      double var5 = Math.toRadians((double)var2);
      double var7 = Math.cos(var5);
      return (new class_243(-Math.sin(var3) * var7, -Math.sin(var5), Math.cos(var3) * var7)).method_1029();
   }

   private boolean lII(class_310 var1, class_1657 var2) {
      if (var1 != null && var1.field_1724 != null && var2 != null && var2 != var1.field_1724) {
         if (var2.method_5805() && !var2.method_31481() && !var2.method_7325() && !IlIII.I(var2)) {
            if (!IllllIlI.lllllI(var2) && !(var2.method_6032() > ((Double)this.Ill.III()).floatValue())) {
               double var3 = (Double)this.IlIl.III() * (Double)this.IlIl.III();
               return var1.field_1724.method_5858(var2) <= var3;
            } else {
               return false;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private void llI(class_310 var1) {
      if (this.IIIIll(var1)) {
         if (this.llI) {
            IllllIlI.IIIlIII(var1, this.Illl, this.l);
            this.llI = false;
         }

      }
   }

   private boolean lll(class_310 var1, int var2) {
      if (this.IIIIll(var1) && this.IIIIII(var1.field_1724, var2)) {
         IllllIlI.lIllll(var1);
         class_1269 var3 = var1.field_1761.method_2919(var1.field_1724, class_1268.field_5808);
         return var3 != null && var3.method_23665();
      } else {
         return false;
      }
   }

   private float[] IIII(class_310 var1, class_1657 var2, class_1799 var3) {
      <undefinedtype> var4 = this.IIll(var3);
      class_243 var5 = this.ll(var1, var2);
      return var5 == null ? null : this.lllII(var1, var4, var5);
   }

   private <undefinedtype> IIll(class_1799 var1) {
      class_9278 var2 = var1 == null ? null : (class_9278)var1.method_58694(class_9334.field_49649);
      boolean var3 = var2 != null && var2.method_57438(class_1802.field_8639);
      return var3 ? new Record(1.6, 0.99, (double)0.0F) {
         private final double I;
         private final double l;
         private final double II;

         public double I() {
            return this.II;
         }

         public double l() {
            return this.l;
         }

         private {
            this.I = var1;
            this.II = var3;
            this.l = var5;
         }

         public double II() {
            return this.I;
         }
      } : new Record(3.15, 0.99, 0.05) {
         private final double I;
         private final double l;
         private final double II;

         public double I() {
            return this.II;
         }

         public double l() {
            return this.l;
         }

         private {
            this.I = var1;
            this.II = var3;
            this.l = var5;
         }

         public double II() {
            return this.I;
         }
      };
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (!this.IIIIll(var1)) {
         this.IIlll(var1, true);
      } else if (lIlIllll.lIIl(var1)) {
         this.IIlll(var1, true);
      } else {
         long var2 = System.currentTimeMillis();
         if (this.IIlI != null.lI) {
            this.lIIll(var1, var2);
         } else if (var2 >= this.lII && !var1.field_1724.method_6115() && !IlIlIl.IIIIll() && this.lllll(var1)) {
            int var4 = this.lIII(var1.field_1724);
            if (var4 >= 0) {
               class_1799 var5 = var1.field_1724.method_31548().method_5438(var4);
               class_1657 var6 = this.IlIl(var1, var5);
               if (var6 != null) {
                  this.llIlI(var1, var6, var4, var2);
               }
            }
         }
      }
   }

   private class_1657 IlIl(class_310 var1, class_1799 var2) {
      class_1657 var3 = null;
      double var4 = Double.MAX_VALUE;
      double var6 = (Double)this.IlIl.III() * (Double)this.IlIl.III();

      for(class_1657 var9 : var1.field_1687.method_18456()) {
         if (this.lII(var1, var9)) {
            double var10 = var1.field_1724.method_5858(var9);
            if (!(var10 > var6) && !(var10 >= var4) && this.IIlIl(var1, var9, var2)) {
               var3 = var9;
               var4 = var10;
            }
         }
      }

      return var3;
   }

   private float Illl(class_243 var1, class_243 var2) {
      double var3 = var2.field_1352 - var1.field_1352;
      double var5 = var2.field_1351 - var1.field_1351;
      double var7 = var2.field_1350 - var1.field_1350;
      double var9 = Math.sqrt(var3 * var3 + var7 * var7);
      return (float)(-Math.toDegrees(Math.atan2(var5, var9)));
   }

   private int lIII(class_746 var1) {
      for(int var2 = 0; var2 < IIIlII(-1753514981, 443957706); ++var2) {
         if (this.Illll(var1.method_31548().method_5438(var2))) {
            return var2;
         }
      }

      return -1;
   }

   private boolean lIIl(class_3965 var1) {
      return var1 != null && var1.method_17783() == class_240.field_1332;
   }

   private float[] llII(class_310 var1, Object var2, class_243 var3, float var4, float var5, float var6) {
      float[] var7 = this.IlIII(var1, var4, var5);
      float var8 = this.IIIIlI(var1);
      int var9 = var8 > 1.0E-6F && Float.isFinite(var8) ? 2 : 0;
      float var10 = var1.field_1724.method_36454();
      <undefinedtype> var11 = null;
      float[] var12 = null;

      for(int var13 = -var9; var13 <= var9; ++var13) {
         for(int var14 = -var9; var14 <= var9; ++var14) {
            float var15 = this.IlIIl(var7[0] + (float)var13 * var8, var10);
            float var16 = class_3532.method_15363(var7[1] + (float)var14 * var8, -90.0F, 90.0F);
            <undefinedtype> var17 = this.IllII(var1, var2, var3, var15, var16, var6);
            if (var17 != null && (var11 == null || var17.I() < var11.I())) {
               var11 = var17;
               var12 = new float[]{var15, var16};
            }
         }
      }

      return var12;
   }

   private class_3965 IIIII(class_310 var1, class_243 var2, class_243 var3) {
      return var1 != null && var1.field_1687 != null ? var1.field_1687.method_17742(new class_3959(var2, var3, class_3960.field_17558, class_242.field_1348, var1.field_1724)) : null;
   }

   private boolean IIIIl(class_310 var1, float[] var2) {
      if (!this.llI) {
         this.llI = true;
      }

      IllllIlI.IIIlIII(var1, var2[0], var2[1]);
      if (this.IIIIll(var1) && this.IIIIII(var1.field_1724, this.lIll)) {
         class_1657 var3 = this.lIII;
         int var4 = this.lIll;
         return IlIlIl.IIIlIl(var1, IIIlII(-1753514982, -1797985594), var2[0], var2[1], () -> {
            boolean var4x = this.IIIIIlI() && this.lII(var1, var3) && IllllIlI.llIll(var1, this, var4, () -> this.lll(var1, var4));
            this.llIII(var1, var4x);
            return var4x;
         });
      } else {
         return false;
      }
   }

   public IllI() {
      super((Object)lIlIII.l(lIl[4]), lIllII.I, (Object)lIlIII.l(lIl[IIIlII(-1753514983, 902032479)]));
      this.IIIl = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(lIl[IIIlII(-1753514984, -685047124)]), <undefinedtype>.class, null.Il));
      this.lll = (IIIllIIII)this.IIIlIll((IIIllIIII)(new IIIllIIII(lIlIII.l(lIl[IIIlII(-1753514977, -660834696)]), (double)50.0F, (double)1.0F, (double)100.0F, (double)1.0F)).lIII(() -> this.IIIl.III() == null.I));
      this.ll = new IlIlIll();
      this.IlIl = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(lIl[1]), (double)8.0F, (double)1.0F, (double)64.0F, (double)0.5F)).IIl(lIlIII.Il(lIl[5])));
      this.Ill = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(lIl[3]), (double)1.0F, (double)0.5F, (double)20.0F, (double)0.5F)).IIl(lIlIII.Il(lIl[IIIlII(-1753514978, -1164337468)])));
      this.Il = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(lIl[IIIlII(-1753514979, 1601280382)]), (double)0.0F, (double)0.0F, (double)5000.0F, (double)50.0F)).IIl(lIlIII.Il(lIl[2])));
      this.llII = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lIl[IIIlII(-1753514980, -417054297)]), false));
      this.lI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lIl[0]), false));
      this.IIlI = null.lI;
      this.lIll = -1;
   }

   private static String IIlII(char[] var0, long var1, int var3) {
      int var4 = IIIlII(-1753514989, 1331927857) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IIIlII(-1753514990, 1317462495);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private boolean IIlIl(class_310 var1, class_1657 var2, class_1799 var3) {
      return this.lII(var1, var2) && this.IIII(var1, var2, var3) != null;
   }

   private void IIllI(class_310 var1, long var2) {
      if (this.lII(var1, this.lIII) && this.IIIIII(var1.field_1724, this.lIll) && this.lllll(var1)) {
         class_1799 var4 = var1.field_1724.method_31548().method_5438(this.lIll);
         float[] var5 = this.IIII(var1, this.lIII, var4);
         if (var5 == null) {
            this.llI(var1);
            this.IIlll(var1, false);
         } else {
            if ((Boolean)this.lI.III()) {
               lIlIllll.lll(var1);
            }

            boolean var6 = this.IIIl.III() == null.Il ? this.IIIIIl(var1, var5) : this.IIIIl(var1, var5);
            if (!var6) {
               this.IIlll(var1, true);
            } else {
               this.llIIl(() -> {
                  long var2 = System.currentTimeMillis();
                  this.lII = var2 + Math.max(0L, Math.round((Double)this.Il.III()));
                  this.llI(var1);
                  this.IIlll(var1, false);
               });
            }
         }
      } else {
         this.IIlll(var1, true);
      }
   }

   private void IIlll(class_310 var1, boolean var2) {
      if (var2 && this.llI && var1 != null && var1.field_1724 != null) {
         IllllIlI.IIIlIII(var1, this.Illl, this.l);
      }

      this.IIlI = null.lI;
      this.II = 0L;
      this.lIll = -1;
      this.llI = false;
      this.lIII = null;
      this.IllI = null;
   }

   private float[] IlIII(class_310 var1, float var2, float var3) {
      if (var1 != null && var1.field_1724 != null) {
         float var4 = this.IIIIlI(var1);
         if (!(var4 <= 1.0E-6F) && Float.isFinite(var4)) {
            float var5 = var1.field_1724.method_36454();
            float var6 = var1.field_1724.method_36455();
            float var7 = this.lIIII(class_3532.method_15393(var2 - var5), var4);
            float var8 = this.lIIII(var3 - var6, var4);
            return new float[]{this.IlIIl(var5 + var7, var5), class_3532.method_15363(var6 + var8, -90.0F, 90.0F)};
         } else {
            return new float[]{this.IlIIl(var2, var1.field_1724.method_36454()), class_3532.method_15363(var3, -90.0F, 90.0F)};
         }
      } else {
         return new float[]{var2, var3};
      }
   }

   private float IlIIl(float var1, float var2) {
      float var3;
      for(var3 = var1; var3 - var2 > 180.0F; var3 -= 360.0F) {
      }

      while(var3 - var2 < -180.0F) {
         var3 += 360.0F;
      }

      return var3;
   }

   private boolean IlIll(class_310 var1, class_243 var2, class_243 var3) {
      class_3965 var4 = this.IIIII(var1, var2, var3);
      return !this.lIIl(var4);
   }

   private <undefinedtype> IllII(class_310 var1, Object var2, class_243 var3, float var4, float var5, float var6) {
      class_243 var7 = var1.field_1724.method_33571();
      class_243 var8 = this.IlI(var4, var5).method_1021(var2.II()).method_1019(var1.field_1724.method_18798());
      int var9 = Math.max(IIIlII(-1753514991, 164172137), Math.min(IIIlII(-1753514992, 631631133), (int)Math.ceil(var7.method_1022(var3) / var2.II()) + IIIlII(-1753514985, -785472284)));
      double var10 = 0.0324;
      int var12 = 0;

      while(true) {
         if (var12 < var9) {
            class_243 var13 = var7.method_1019(var8);
            class_3965 var14 = this.IIIII(var1, var7, var13);
            class_243 var15 = this.llllI(var3, var7, var13);
            double var16 = var3.method_1025(var15);
            if (var16 <= var10) {
               if (this.lIllI(var1, var14, var7, var15)) {
                  return null;
               }

               double var18 = (double)Math.abs(var5 - var6) * 0.0025;
               return new Record((double)var5, var16 + var18) {
                  private final double I;
                  private final double l;

                  private {
                     this.I = var1;
                     this.l = var3;
                  }

                  public double I() {
                     return this.l;
                  }

                  public double l() {
                     return this.I;
                  }
               };
            }

            if (this.lIIl(var14)) {
               return null;
            }

            var7 = var13;
            var8 = var8.method_1021(var2.I()).method_1023((double)0.0F, var2.l(), (double)0.0F);
            if (var1.field_1687 == null || !(var13.field_1351 < (double)var1.field_1687.method_31607() - (double)20.0F)) {
               ++var12;
               continue;
            }
         }

         return null;
      }
   }

   private <undefinedtype> IlllI(class_310 var1, Object var2, class_243 var3, float var4, float var5, double var6, double var8, double var10) {
      <undefinedtype> var12 = null;

      for(double var13 = var6; var13 <= var8 + 1.0E-6; var13 += var10) {
         <undefinedtype> var15 = this.IllII(var1, var2, var3, var4, (float)var13, var5);
         if (var15 != null && (var12 == null || var15.I() < var12.I())) {
            var12 = var15;
         }
      }

      return var12;
   }

   private boolean Illll(class_1799 var1) {
      return var1 != null && !var1.method_7960() && var1.method_7909() instanceof class_1764 && class_1764.method_7781(var1);
   }

   private float lIIII(float var1, float var2) {
      if (!(var2 <= 1.0E-6F) && Float.isFinite(var2) && Float.isFinite(var1)) {
         return Math.abs(var1) < var2 * 0.06F ? 0.0F : (float)Math.round(var1 / var2) * var2;
      } else {
         return var1;
      }
   }

   public int IlIlI() {
      return IIIlII(-1753514986, -1010938793);
   }

   private boolean lIIlI(class_310 var1) {
      if (this.IIIIll(var1) && var1.field_1690 != null) {
         class_243 var2 = var1.field_1724.method_18798();
         double var3 = var2.field_1352 * var2.field_1352 + var2.field_1350 * var2.field_1350;
         return var3 <= 0.001225 && !var1.field_1690.field_1894.method_1434() && !var1.field_1690.field_1881.method_1434() && !var1.field_1690.field_1913.method_1434() && !var1.field_1690.field_1849.method_1434() && !var1.field_1690.field_1903.method_1434() && !var1.field_1690.field_1832.method_1434();
      } else {
         return false;
      }
   }

   private void lIIll(class_310 var1, long var2) {
      switch (this.IIlI.ordinal()) {
         case 1:
            if (!this.lII(var1, this.lIII) || !this.IIIIII(var1.field_1724, this.lIll)) {
               this.IIlll(var1, true);
               return;
            }

            class_1799 var4 = var1.field_1724.method_31548().method_5438(this.lIll);
            if (!this.IIlIl(var1, this.lIII, var4)) {
               this.llI(var1);
               this.IIlll(var1, false);
               return;
            }

            float[] var5 = this.IIII(var1, this.lIII, var4);
            if (var5 == null) {
               this.llI(var1);
               this.IIlll(var1, false);
               return;
            }

            float var6 = var5[0];
            float var7 = var5[1];
            float var8 = var6 * ((float)Math.PI / 180F);
            float var9 = var7 * ((float)Math.PI / 180F);
            float var10 = class_3532.method_15362((double)var9);
            float var11 = class_3532.method_15374((double)var9);
            float var12 = class_3532.method_15362((double)var8);
            float var13 = class_3532.method_15374((double)var8);
            class_243 var14 = new class_243((double)(-var13 * var10), (double)(-var11), (double)(var12 * var10));
            double var15 = var1.field_1724.method_33571().method_1022(this.lIII.method_33571());
            class_243 var17 = var1.field_1724.method_33571().method_1019(var14.method_1021(var15));
            float var18 = this.ll.IlIl(var1, var17, ((Double)this.lll.III()).floatValue());
            this.llI = true;
            if (var2 - this.II >= 1500L || var18 <= 0.5F) {
               boolean var19 = this.IIIIl(var1, var5);
               if (!var19) {
                  this.IIlll(var1, true);
                  return;
               }

               this.llIIl(() -> {
                  long var2 = System.currentTimeMillis();
                  this.lII = var2 + Math.max(0L, Math.round((Double)this.Il.III()));
                  this.llI(var1);
                  this.IIlll(var1, false);
               });
            }
            break;
         case 2:
            if (var2 - this.II > 1000L) {
               this.llI(var1);
               this.IIlll(var1, false);
            }
      }

   }

   private static void lIlIl() {
      lIl[0] = IIlII(IIIlIl((short)9355, 950153305, 26532).toCharArray(), 29260L, IIIlII(-1753514987, 523826243));
      lIl[1] = IIlII(IIIlIl((short)5205, 1827878891, 26533).toCharArray(), 54314L, IIIlII(-1753514988, 1109938459));
      lIl[2] = IIlII(IIIlIl((short)1519, 1242576695, 26534).toCharArray(), 53406L, IIIlII(-1753514997, -2037915147));
      lIl[3] = IIlII(IIIlIl((short)21757, -186182197, 26535).toCharArray(), 84679L, IIIlII(-1753514998, -2014656407));
      lIl[4] = IIlII(IIIlIl((short)26604, 681864440, 26528).toCharArray(), 23672L, IIIlII(-1753514999, -1586188788));
      lIl[5] = IIlII(IIIlIl((short)'낼', -571602431, 26529).toCharArray(), 21143L, IIIlII(-1753515000, 1531859752));
      lIl[IIIlII(-1753514993, 1106754616)] = IIlII(IIIlIl((short)'ꬕ', -56224708, 26530).toCharArray(), 30521L, IIIlII(-1753514994, -635097617));
      lIl[IIIlII(-1753514995, -919331206)] = IIlII(IIIlIl((short)11446, -1274018355, 26531).toCharArray(), 17819L, IIIlII(-1753514996, 1719513283));
      lIl[IIIlII(-1753515005, 1068947749)] = IIlII(IIIlIl((short)'\udce0', -440119234, 26540).toCharArray(), 504L, IIIlII(-1753515006, -849797904));
      lIl[IIIlII(-1753515007, 974008000)] = IIlII(IIIlIl((short)14321, -873370338, 26541).toCharArray(), 40709L, IIIlII(-1753515008, -815020217));
      lIl[IIIlII(-1753515001, 1280132239)] = IIlII(IIIlIl((short)4432, 1306081689, 26542).toCharArray(), 14115L, IIIlII(-1753515002, -1561901974));
      lIl[IIIlII(-1753515003, -1660422076)] = IIlII(IIIlIl((short)'\udca5', 1238193414, 26543).toCharArray(), 62342L, IIIlII(-1753515004, 1095490159));
   }

   private boolean lIllI(class_310 var1, class_3965 var2, class_243 var3, class_243 var4) {
      if (!this.lIIl(var2)) {
         return false;
      } else {
         return var3.method_1025(var2.method_17784()) <= var3.method_1025(var4) + 1.0E-6;
      }
   }

   public String Il() {
      return ((<undefinedtype>)this.IIIl.III()).toString();
   }

   private void llIII(class_310 var1, boolean var2) {
      if (this.IIlI == null.Il) {
         Runnable var3 = this.IllI;
         this.IllI = null;
         if (var2 && var3 != null) {
            var3.run();
         } else {
            this.llI(var1);
            this.IIlll(var1, false);
         }
      }
   }

   private void llIIl(Runnable var1) {
      this.IllI = var1;
      this.IIlI = null.Il;
      this.II = System.currentTimeMillis();
   }

   private void llIlI(class_310 var1, class_1657 var2, int var3, long var4) {
      class_746 var6 = var1.field_1724;
      this.lIII = var2;
      this.lIll = var3;
      this.Illl = var6.method_36454();
      this.l = var6.method_36455();
      if (this.IIIl.III() == null.I) {
         this.IIlI = null.I;
         this.II = var4;
      } else {
         this.IIllI(var1, var4);
      }

   }

   public void lIl() {
      this.IIlll(class_310.method_1551(), false);
      this.lII = 0L;
      this.ll.IIlIIII();
   }

   private float llIll(class_243 var1, class_243 var2) {
      double var3 = var2.field_1352 - var1.field_1352;
      double var5 = var2.field_1350 - var1.field_1350;
      return (float)(Math.toDegrees(Math.atan2(var5, var3)) - (double)90.0F);
   }

   private float[] lllII(class_310 var1, Object var2, class_243 var3) {
      class_243 var4 = var1.field_1724.method_33571();
      float var5 = this.llIll(var4, var3);
      float var6 = this.Illl(var4, var3);
      double var7 = Math.max((double)-85.0F, (double)var6 - (double)35.0F);
      double var9 = Math.min((double)85.0F, (double)var6 + (double)10.0F);
      <undefinedtype> var11 = this.IlllI(var1, var2, var3, var5, var6, var7, var9, (double)1.0F);
      if (var11 == null) {
         return null;
      } else {
         double var12 = Math.max((double)-85.0F, var11.l() - (double)1.5F);
         double var14 = Math.min((double)85.0F, var11.l() + (double)1.5F);
         <undefinedtype> var16 = this.IlllI(var1, var2, var3, var5, var6, var12, var14, 0.1);
         if (var16 != null) {
            var11 = var16;
         }

         return this.llII(var1, var2, var3, var5, (float)var11.l(), var6);
      }
   }

   private class_243 llllI(class_243 var1, class_243 var2, class_243 var3) {
      class_243 var4 = var3.method_1020(var2);
      double var5 = var4.method_1027();
      if (var5 <= 1.0E-8) {
         return var2;
      } else {
         double var7 = var1.method_1020(var2).method_1026(var4) / var5;
         var7 = Math.max((double)0.0F, Math.min((double)1.0F, var7));
         return var2.method_1019(var4.method_1021(var7));
      }
   }

   private boolean lllll(class_310 var1) {
      return (Boolean)this.lI.III() || !(Boolean)this.llII.III() || this.lIIlI(var1);
   }

   public void lI() {
      this.IIlll(class_310.method_1551(), true);
      this.lII = 0L;
      this.ll.IIIlIll();
   }

   private boolean IIIIII(class_746 var1, int var2) {
      return var1 != null && var2 >= 0 && var2 < IIIlII(-1753514949, 1985118725) && this.Illll(var1.method_31548().method_5438(var2));
   }

   private boolean IIIIIl(class_310 var1, float[] var2) {
      class_1657 var3 = this.lIII;
      int var4 = this.lIll;
      return IlIlIl.IIIlIl(var1, IIIlII(-1753514950, -1817010365), var2[0], var2[1], () -> {
         boolean var4x = this.IIIIIlI() && this.lII(var1, var3) && IllllIlI.llIll(var1, this, var4, () -> this.lll(var1, var4));
         this.llIII(var1, var4x);
         return var4x;
      });
   }

   private float IIIIlI(class_310 var1) {
      if (var1 != null && var1.field_1690 != null) {
         double var2;
         try {
            var2 = (Double)var1.field_1690.method_42495().method_41753();
         } catch (Exception var8) {
            var2 = (double)0.5F;
         }

         double var4 = var2 * 0.6 + 0.2;
         double var6 = var4 * var4 * var4;
         return (float)(var6 * (double)8.0F * 0.15);
      } else {
         return 0.0F;
      }
   }

   private boolean IIIIll(class_310 var1) {
      return var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var1.field_1755 == null && var1.field_1724.method_5805();
   }

   static {
      short var6 = 9236;
      String var7 = "딪硚㪭诖॒\ue7e8\u0ebfᖦ駑啃㲔퍽ꢓゼꑳ︬礬ၛ擜磧택芻떄嗊㔤⡷钋⌢㎃檓趨뤩䪙Ϳ鏜䢛洳祚帹㪧盛骒佖㡴귣㮃渼䐵\ue76b䵚☡\uea14鑽ﱊ蚏ᇰᕦអ蒅淆ꐿӞ豈揭莂藊评௬愡Ԃﭿ퓻⟁駷쪼貍큦倃熭ᔪ㕻씠⦑ಒ妫ᯂﷷ츸⳽\uf45a氐ۑ枳懾싄 \ud9bf爯硥\u0094ᇊ\ueaca革捑⾷鄉椸햊鹙ꉣ坸\ue1c8ᚁ\uf545ᓅ栝浿\ue775㶟ጩၧ姉ᑀ俠튷䊉굂㔔膩晻螦姸욘⹋쒑椥붹\uf589ꍆ쓺\uddb7Ề嵋\uf510ꑿ첀\ue799阯晻佾鰂\u20fd漁焝\udcb4먯ᇢ俎\ueee0⫸\uf3ea埰凲謥䛮㨼缟旋赗㶘呷땟\u20f9⾒퓈堥젌韩㶻綔\ueec8䎯佛簠";
      char[] var8 = "␀␜␐␜␄␐␄␜␐\u245c␘␘".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            lllI = var9;
            llll = new Object[var9.length];
            int var2 = 1717515492;
            byte[] var0 = "ëR\t<eð£¨Äç¤«&\u000fJW)¸>\u0089K½Ö6®UÑ\u008c\u0016\u0000\tY\u0017\u0087#\u0004¿¢©ÖøíY\u0094Ô\u0081¥¹ \nì\t2\u009a\u000fÔH/8Öu\u0006º}\u0094s¡\u001esC\u009bíúñ\u0006;Í¯\u0018µ°ÓôÕlû¼\u00988\u0010V\u0094[9ÂJÎ\u0092\u0091Ê\u008e{\u0015æË*f,n\f*Ã½i\ffÒ®5¶l#°®\u0004Â\u008dÇ\u0087vÊÓb\u0096Ö\rUÁFW".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            llIl = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               llIl[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            lIl = new String[IIIlII(-1753514951, -1528492410)];
            lIlIl();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static int IIIlII(int var0, int var1) {
      return llIl[var0 ^ -1753514981] ^ var1 ^ var0;
   }

   private static String IIIlIl(short var0, int var1, int var2) {
      int var3 = var2 ^ 26532;
      char[] var4 = lllI[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])llll[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         llll[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 28015;
      int var9 = 0;

      do {
         int var10 = var4[var9] + 3245;
         var10 ^= 15464;
         var10 ^= 42542;
         var10 ^= 58859;
         var10 += 13370;
         var10 ^= 61755;
         var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
