package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class lIIIIIl extends IIIIIIIlI {
   private static String[] I;
   private static final int[] l;
   private static final String[] II;
   private static final Object[] Il;

   public static boolean ll() {
      lIllIIl var0 = lIllIIl.Il();
      if (var0 != null && var0.IIl() != null) {
         return var0.IIl().lIIlll() != null && var0.IIl().lIIlll().IIIIIlI();
      } else {
         return false;
      }
   }

   private static String IlI(char[] var0, long var1, int var3) {
      int var4 = llI(92462592, 1014116567) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & llI(92462593, -1491455157);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   static {
      short var6 = 19162;
      String var7 = "텮\ue949鿤⎠⒫㧱\udc5c藪됭晊䈘\uf4bdจᕡ鳢麭홳넨剨\uddcb\udc02㽯利㍶卛\ueabe\u0b54䶃瓾\ue81b뛼ዌ뉐坹ﯓ▜깴ꬣ⒀捸䌄퀼댽꯲핦灀粘宣෨因죳딣븱솥ﻁ▨귔戀㕌踌\uf8b5巙䚦貧\ue1a7퓘ᘆ䱬\uf655핓\uf110ⶳ䀂隷噱\uf1f7閭袖鸩醘";
      char[] var8 = "䪚䫊".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            II = var9;
            Il = new Object[var9.length];
            int var2 = -1225898450;
            byte[] var0 = "nÓ\u0097#\u0014v«\u009b\u0090¥C\n³-\u008e\u008f".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            l = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               l[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            I = new String[2];
            lII();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static void lII() {
      I[0] = IlI(lll(-764079125, '禗', (short)'딘').toCharArray(), 98253L, llI(92462594, -434627243));
      I[1] = IlI(lll(-1475464781, '禖', (short)24860).toCharArray(), 53976L, llI(92462595, 1632686587));
   }

   public lIIIIIl() {
      super((Object)lIlIII.l(I[1]), lIllII.ll, (Object)lIlIII.l(I[0]));
   }

   private static int llI(int var0, int var1) {
      return l[var0 ^ 92462592] ^ var1 ^ var0;
   }

   private static String lll(int var0, char var1, short var2) {
      int var3 = var1 ^ 31127;
      char[] var4 = II[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])Il[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         Il[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 20941;
      int var9 = 0;

      do {
         int var10 = var4[var9] + 31591;
         var10 += 57668;
         var10 ^= 8142;
         var10 -= 62592;
         var10 -= 62500;
         var10 ^= 47193;
         var10 ^= 26770;
         var10 ^= 2698;
         var10 -= 761;
         var4[var9] = (char)(var10 ^ var8 ^ var2 ^ var0 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
