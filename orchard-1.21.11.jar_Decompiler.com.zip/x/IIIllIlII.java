package x;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_4184;
import net.minecraft.class_746;
import net.minecraft.class_7923;
import net.minecraft.class_9362;
import net.minecraft.class_239.class_240;

@Environment(EnvType.CLIENT)
public final class IIIllIlII extends IIIIIIIlI {
   private final lIIIIl l;
   private static final float II = 200.0F;
   private double Il;
   private static final float lI = 3.4F;
   private int ll;
   private final lIIIIl III;
   private static final float IIl = -90.0F;
   private int IlI;
   private static final float Ill = 0.9F;
   private double lII;
   private final IIIllIIII lIl;
   private final IIIllIIII llI;
   private static final float lll = 120.0F;
   private static final double IIII = (double)8.0F;
   private final lIIIIl IIIl;
   private final IlIIIlIlI<<undefinedtype>> IIlI;
   private final IlIlIll IIll;
   private final IlIIIlII IlII;
   private float IlIl;
   private static final float IllI = 420.0F;
   private static final float Illl = 15.0F;
   private float lIII;
   private final llllIlIl lIIl;
   private final lllIIlIl lIlI;
   private int lIll;
   private class_1309 llII;
   private static final <undefinedtype> llIl;
   private float lllI;
   private static final int llll = 10;
   private final llllIlIl IIIII;
   private static final float IIIIl = 5.0F;
   private long IIIlI;
   private final IIIllIIII IIIll;
   private double IIlII;
   private final llllIlIl IIlIl;
   private static final <undefinedtype> IIllI;
   private boolean IIlll;
   private final lIIIIl IlIII;
   private static final double IlIIl = 9.999;
   private boolean IlIlI;
   private final IIIllIIII IlIll;
   private float IllII;
   private double IllIl;
   private final IIIIllIII IlllI;
   private float Illll;
   private final IlIIIlIlI<<undefinedtype>> lIIII;
   private final lIIIIl lIIIl;
   private static final int lIIlI = 1;
   private static final float lIIll = 490.0F;
   private float lIlII;
   private int lIlIl;
   private int lIllI;
   private final llllIlIl lIlll;
   private double llIII;
   private static final List<<undefinedtype>> llIIl;
   private final lIIIIl llIlI;
   private static final float llIll = 1.35F;
   private static final float lllII = 620.0F;
   private final llllIlIl lllIl;
   private static final double llllI = (double)10.0F;
   private final IIIllIIII lllll;
   private boolean IIIIII;
   private int IIIIIl;
   private int IIIIlI;
   private static final float IIIIll = 90.0F;
   private final IlIIIlIlI<<undefinedtype>> IIIlII;
   private final lIIIIl IIIlIl;
   private final lIIIIl IIIllI;
   private boolean IIIlll;
   private final IIIllIIII IIlIII;
   private static final double IIlIIl = (double)1.0F;
   private final IlIIIlIlI<<undefinedtype>> IIlIlI;
   private final llllIlIl IIlIll;
   private final lIIIIl IIllII;
   private static final float IIllIl = 10.0F;
   private static final <undefinedtype> IIlllI;
   private final IIIllIIII IIllll;
   private static final int IlIIII = 1;
   private final IIIllIIII IlIIIl;
   private static final int[] I;
   private static final String[] IlIIlI;
   private static final Object[] IlIIll;

   private boolean ll() {
      return this.IIlll(this.IIlIll, this.IllIl) >= 9.999 && this.IIlll(this.lIlll, this.Il) >= 9.999;
   }

   private boolean IlI(class_310 var1) {
      for(class_1268 var5 : class_1268.values()) {
         class_1799 var6 = var1.field_1724.method_5998(var5);
         if (!var6.method_7960() && IllllIlI.IlllII(var6)) {
            return true;
         }
      }

      return false;
   }

   private boolean lII(class_746 var1) {
      if (!(Boolean)this.IIIlIl.III()) {
         return false;
      } else if (!var1.method_24828() && !var1.method_6128()) {
         if (class_9362.method_58659(var1)) {
            return false;
         } else {
            return var1.field_6017 >= (double)1.5F && var1.method_18798().field_1351 < (double)0.0F;
         }
      } else {
         return false;
      }
   }

   private <undefinedtype> llI(class_310 var1, class_1309 var2, Object var3) {
      // $FF: Couldn't be decompiled
   }

   public boolean lll() {
      class_310 var1 = class_310.method_1551();
      return this.IIIlll && var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1755 == null ? this.IlIIlI(var1) : false;
   }

   private void IIII(class_310 var1) {
      if (var1 != null && var1.field_1690 != null && var1.field_1690.field_1904 != null) {
         boolean var2 = IllllIlI.IlIll(var1, class_1268.field_5808);
         if (!var2) {
            this.IIIIII = false;
         } else {
            if (!var1.field_1724.method_6115()) {
               var1.field_1724.method_6019(class_1268.field_5808);
            }

            IllllIlI.IIIIllI(var1.field_1690.field_1904);
            this.IIlIIl(var1, true);
            this.IlIlI = true;
            this.IIIIII = false;
            this.lIlIl = 0;
            this.IIIIIl = ThreadLocalRandom.current().nextInt(2, lIIIlI(124442359, -1583225510));
         }
      } else {
         this.IIIIII = false;
      }
   }

   private void IIll() {
      this.llIII = this.IIIII(this.IIlIl);
      this.IIlII = this.IIIII(this.lIIl);
   }

   private float IlII(class_310 var1, class_1309 var2, Object var3) {
      if (var1 != null && var1.field_1724 != null && var2 != null && var3 != null) {
         double var4 = var2.method_18798().method_37267();
         double var6 = var1.field_1724.method_18798().method_37267();
         float var8 = class_3532.method_15363((float)((var4 + var6) * 3.35), 0.0F, 1.0F);
         float var9 = class_3532.method_15363(var3.IlI() * 2.05F, 0.0F, 1.0F);
         if ((Boolean)this.l.III()) {
            float var10 = class_3532.method_15363(var3.IlI() / 0.18F, 0.12F, 1.0F);
            if (IllllIlI.IlIIll(var1, var2, this.IlIll(), true) != null) {
               var10 = Math.min(var10, 0.22F);
            }

            var8 *= var10;
            var9 *= var10;
         }

         float var11 = var3.lI() ? 0.16F : 0.0F;
         return class_3532.method_15363(var11 + var8 * 0.44F + var9 * 0.36F, 0.0F, 1.0F);
      } else {
         return 0.0F;
      }
   }

   private boolean IlIl(class_310 var1) {
      if (!this.IIIIIlI()) {
         this.IlII.I();
         this.IIllIl(var1);
         return false;
      } else if (var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1755 == null) {
         if (!this.lIlll(var1)) {
            this.IlII.I();
            this.IIllIl(var1);
            return false;
         } else {
            int var2 = IllllIlI.lIIlI(var1.field_1724.method_31548());
            if (this.IIIIlI != -1 && var2 != this.IIIIlI) {
               this.IlI = 1;
            }

            this.IIIIlI = var2;
            if (this.IlI > 0) {
               --this.IlI;
               return false;
            } else {
               class_1309 var3 = this.IIIIIl(var1);
               if (var3 == null) {
                  this.llII = null;
                  this.IlII.I();
                  this.IIllIl(var1);
                  return false;
               } else {
                  return this.lllll(var1, var3);
               }
            }
         }
      } else {
         this.IlII.I();
         this.IIllIl(var1);
         return false;
      }
   }

   private boolean Illl(class_310 var1) {
      if (var1.method_22683() == null) {
         return false;
      } else {
         return !this.lIlI.I() ? false : IllllIlI.IlIII(var1, (class_3675.class_306)this.lIlI.III());
      }
   }

   public void Ill() {
      this.llIll();
      class_310 var1 = class_310.method_1551();
      this.IlIII(var1, false);
      boolean var2 = this.lIlll(var1);
      class_1309 var3 = var2 ? this.IIIIIl(var1) : null;
      <undefinedtype> var4 = var3 != null ? this.IlIllI(var1, var3, true) : null;
      this.IIll.IIllIl(var1, this.llI(var1, var3, var4), var2, var4, false);
   }

   protected boolean lIll() {
      lIllIIl var1 = lIllIIl.Il();
      if (var1 != null && var1.IIl() != null) {
         IIIIIIIIl var2 = var1.IIl().lIlll();
         if (var2 != null && var2.IIIIIlI()) {
            IIlllIlI.II().III(null.l, lIlIII.Il(lIIIll(1642098940, -1213315046)), "", 3200L);
            return false;
         }
      }

      return true;
   }

   private boolean llII(class_310 var1) {
      class_746 var2 = var1.field_1724;
      return var2.method_6039() || var2.method_6115();
   }

   private float lllI(double var1) {
      double var3 = class_3532.method_15350(var1, (double)1.0F, (double)10.0F);
      if (var3 <= (double)8.0F) {
         double var7 = (var3 - (double)1.0F) / (double)7.0F;
         return (float)class_3532.method_16436(var7, (double)200.0F, (double)420.0F);
      } else {
         double var5 = (var3 - (double)8.0F) / (double)2.0F;
         return (float)class_3532.method_16436(var5, (double)420.0F, (double)490.0F);
      }
   }

   private double IIIII(llllIlIl var1) {
      double var2 = var1.IlII();
      double var4 = var1.IlI();
      return var2 == var4 ? var2 : ThreadLocalRandom.current().nextDouble(var2, var4);
   }

   private boolean IIIIl(double var1, double var3, double var5, double var7, double var9, double var11) {
      int var13 = Double.compare(var1, var3);
      if (var13 != 0) {
         return var13 < 0;
      } else {
         int var14 = Double.compare(var5, var7);
         if (var14 != 0) {
            return var14 < 0;
         } else {
            return Double.compare(var9, var11) < 0;
         }
      }
   }

   private boolean IIIll(class_310 var1, class_1309 var2) {
      lIllIIl var3 = lIllIIl.Il();
      if (var3 != null && var1 != null && var1.field_1724 != null && var2 != null) {
         IIllIllll var4 = var3.IIl().lI();
         return var4 != null && var4.IlIl(var1, var2);
      } else {
         return false;
      }
   }

   public boolean IIlII(class_1297 var1) {
      class_310 var2 = class_310.method_1551();
      return var2 != null && var2.field_1724 != null && var1 == var2.field_1724 && this.lll();
   }

   private boolean IIlIl(class_310 var1, class_1309 var2) {
      lIllIIl var3 = lIllIIl.Il();
      if (var3 != null && var1 != null && var1.field_1724 != null && var2 != null) {
         IIIIIIIIl var4 = var3.IIl().lIlll();
         if (var4 != null && var4.IIIIIlI() && var4.lIIII(var1, var2)) {
            return true;
         } else {
            llIIIllI var5 = var3.IIl().IIIllll();
            if (var5 != null && var5.IIIIIlI()) {
               if (var5.llI()) {
                  return true;
               }

               if (var5.Illl(var1, var2)) {
                  return true;
               }
            }

            return false;
         }
      } else {
         return false;
      }
   }

   private class_1309 IIllI(class_310 var1) {
      lIllIIl var2 = lIllIIl.Il();
      IIllllllI var3 = var2 != null && var2.IIl() != null ? var2.IIl().l() : null;
      class_1657 var4 = var3 == null ? null : var3.lIIll(var1);
      return this.IllllI(var1, var4) ? var4 : null;
   }

   private double IIlll(llllIlIl var1, double var2) {
      double var4 = var1.IlII();
      double var6 = var1.IlI();
      return Math.abs(var4 - var6) <= 1.0E-6 ? class_3532.method_15350(var4, (double)1.0F, (double)10.0F) : class_3532.method_15350(var2, Math.min(var4, var6), Math.max(var4, var6));
   }

   private void IlIII(class_310 var1, boolean var2) {
      boolean var3 = this.IIIIIlI() && this.IIlIlI.III() == null.l && var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1755 == null && this.IlIIlI(var1);
      if (var3 == this.IIIlll) {
         if (var3) {
            this.IIlll = false;
            this.lIlII = this.lIII;
            this.Illll = this.lllI;
         } else {
            this.IlIlll(var1);
         }

      } else {
         boolean var4 = this.IIIlll;
         this.IIIlll = var3;
         if (var3) {
            this.IIlll = false;
            this.lIII = var1.field_1724.method_36454();
            this.lllI = var1.field_1724.method_36455();
            this.lIlII = this.lIII;
            this.Illll = this.lllI;
         } else {
            if (!var2 && var4 && var1 != null && var1.field_1724 != null) {
               this.IIlll = true;
               this.IlIl = this.lIII;
               this.IllII = this.lllI;
               this.IIIlI = Long.MIN_VALUE;
               this.lIllI = 1;
               this.IlIlll(var1);
            }

         }
      }
   }

   public void IIIlI(class_332 var1, int var2, int var3, float var4) {
      class_310 var5 = class_310.method_1551();
      this.IlIII(var5, false);
      boolean var6 = this.lIlll(var5);
      class_1309 var7 = var6 ? this.IIIIIl(var5) : null;
      <undefinedtype> var8 = var7 != null ? this.IlIllI(var5, var7, true) : null;
      if (this.IIlIlI.III() == null.l) {
         this.IIll.IIllII();
      } else {
         this.IIll.llIIlI(var5, this.llI(var5, var7, var8), var6, var8, false);
      }
   }

   private <undefinedtype> IlIIl(class_243 var1, class_1309 var2, Object var3) {
      double var4 = var1.method_1022(var3.ll());
      double var6 = (double)(var3.IlI() * var3.Il());
      return new Record(var2, var3, var4, var6, var2.method_6032()) {
         private final double I;
         private final double l;
         private final float II;
         private final <undefinedtype> Il;
         private final class_1309 lI;

         public class_1309 I() {
            return this.lI;
         }

         public double l() {
            return this.l;
         }

         public <undefinedtype> II() {
            return this.Il;
         }

         private {
            this.lI = var1;
            this.Il = var2;
            this.I = var3;
            this.l = var5;
            this.II = var7;
         }

         public float Il() {
            return this.II;
         }

         public double lI() {
            return this.I;
         }
      };
   }

   private double IlIll() {
      return this.IIlIII();
   }

   private boolean IllIl(class_1799 var1) {
      if (var1.method_7960()) {
         return false;
      } else if (!(var1.method_7909() instanceof class_1743) && !(var1.method_7909() instanceof class_9362)) {
         String var2 = class_7923.field_41178.method_10221(var1.method_7909()).method_12832();
         return var2.endsWith(lIlIII.Il(lIIIll(1642098941, -1104784380)));
      } else {
         return true;
      }
   }

   private boolean IlllI(class_310 var1, class_1309 var2) {
      if (var1 != null && var1.field_1724 != null && var2 != var1.field_1724 && var2.method_5805() && !var2.method_31481()) {
         if (x.IlIII.l(var2)) {
            return false;
         } else if ((Boolean)this.llIlI.III() && !(var2 instanceof class_1657)) {
            return false;
         } else {
            return (Boolean)this.lIIIl.III() && !this.IllIl(var1.field_1724.method_6047()) ? false : this.IIlIll(var1, var2);
         }
      } else {
         return false;
      }
   }

   private void Illll(ThreadLocalRandom var1, int var2, int var3) {
      this.IIIIII = true;
      this.lIlIl = var1.nextInt(Math.max(0, var2), Math.max(var2 + 1, var3));
   }

   public float lIIII(float var1) {
      return class_3532.method_16439(var1, this.Illll, this.lllI);
   }

   private boolean lIIIl(class_310 var1) {
      return var1 != null && var1.field_1724 != null && var1.field_1724.method_6047().method_7909() instanceof class_1743;
   }

   private class_243 lIIlI(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         if (this.IIIlll) {
            return this.IllIlI(this.lIII, this.lllI);
         } else if (var1.field_1773 != null && var1.field_1773.method_19418() != null) {
            class_4184 var5 = var1.field_1773.method_19418();
            return this.IllIlI(var5.method_19330(), var5.method_19329());
         } else {
            class_243 var2 = var1.field_1724.method_5828(1.0F);
            double var3 = var2.method_1027();
            return var3 <= 1.0E-7 ? null : var2.method_1021((double)1.0F / Math.sqrt(var3));
         }
      } else {
         return null;
      }
   }

   private boolean lIIll(Object var1, Object var2) {
      if (var2 == null) {
         return true;
      } else {
         boolean var10000;
         switch (((<undefinedtype>)this.IIlI.III()).ordinal()) {
            case 0:
            case 3:
               var10000 = this.IIIIl(var1.l(), var2.l(), var1.lI(), var2.lI(), (double)var1.Il(), (double)var2.Il());
               break;
            case 1:
               var10000 = this.IIIIl(var1.lI(), var2.lI(), var1.l(), var2.l(), (double)var1.Il(), (double)var2.Il());
               break;
            case 2:
               var10000 = this.IIIIl((double)var1.Il(), (double)var2.Il(), var1.lI(), var2.lI(), var1.l(), var2.l());
               break;
            default:
               throw new MatchException((String)null, (Throwable)null);
         }

         return var10000;
      }
   }

   private void lIlII(class_310 var1) {
      if (this.IlIlI) {
         if (var1 != null && var1.field_1724 != null && var1.field_1761 != null && var1.field_1724.method_6115() && var1.field_1724.method_6058() == class_1268.field_5808) {
            var1.field_1761.method_2897(var1.field_1724);
         }

         if (var1 != null && var1.field_1690 != null && var1.field_1690.field_1904 != null) {
            this.IIlIIl(var1, false);
         }

         this.IlIlI = false;
         this.IIIIIl = 0;
         this.lIll = var1 != null && var1.field_1724 != null ? var1.field_1724.field_6012 : lIIIlI(124442358, 1978206121);
      }
   }

   private void lIlIl() {
      this.IllIII();
      this.lIllI();
      this.IIll();
      if (this.IlllII()) {
         this.IlII.l(this.IIIII.IlII(), this.IIIII.IlI());
      }

   }

   private void lIllI() {
      if (!(Boolean)this.IIIl.III()) {
         this.lII = (Double)this.lllll.III();
      } else {
         double var1 = this.lllIl.IlII();
         double var3 = this.lllIl.IlI();
         this.lII = var1 == var3 ? var1 : ThreadLocalRandom.current().nextDouble(var1, var3);
      }
   }

   private boolean lIlll(class_310 var1) {
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1690 != null && var1.field_1755 == null) {
         class_746 var2 = var1.field_1724;
         if (var2.method_5805() && !var2.method_5765()) {
            lIllIIl var3 = lIllIIl.Il();
            IIIIIIIl var4 = var3 != null && var3.IIl() != null ? var3.IIl().lIIl() : null;
            if (var4 != null && var4.IIlll()) {
               return false;
            } else if ((Boolean)this.lIIIl.III() && !this.IllIl(var2.method_6047())) {
               return false;
            } else if (this.IIIIII(var2)) {
               return false;
            } else {
               return !(Boolean)this.IIIllI.III() || this.Illl(var1);
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public void lllIl(class_310 var1) {
      this.IlIl(var1);
      class_1309 var2 = this.lIlll(var1) ? this.IIIIIl(var1) : null;
      this.IlIlIl(var1, var2);
   }

   private void llIII(class_310 var1) {
      if (var1.field_1690 != null && var1.field_1690.field_1904 != null) {
         var1.field_1690.field_1904.method_23481(false);
      }

   }

   private boolean llIIl(class_310 var1, class_1309 var2) {
      if (this.IIIIIlI() && this.IlllII() && (Boolean)this.IIllII.III()) {
         if (var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1755 == null && var2 != null) {
            if (var2.method_5805() && !this.IIIIII(var1.field_1724)) {
               if (var1.field_1724.method_6115() && !this.IlIlI) {
                  return false;
               } else {
                  double var3 = this.IIlIII() + (double)0.75F;
                  return var1.field_1724.method_5858(var2) > var3 * var3 ? false : this.lllII(var1.field_1724.method_6047());
               }
            } else {
               return false;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public void IIl(JsonObject var1) {
      super.IIl(var1);
      if (Math.abs(this.IIlIll.IlII() - (double)6.0F) < 1.0E-6 && Math.abs(this.IIlIll.IlI() - (double)6.0F) < 1.0E-6 || Math.abs(this.IIlIll.IlII() - (double)1.0F) < 1.0E-6 && Math.abs(this.IIlIll.IlI() - (double)8.0F) < 1.0E-6) {
         this.IIlIll.IIIl(new double[]{(double)10.0F, (double)10.0F});
      }

      if (Math.abs(this.lIlll.IlII() - (double)6.0F) < 1.0E-6 && Math.abs(this.lIlll.IlI() - (double)6.0F) < 1.0E-6 || Math.abs(this.lIlll.IlII() - (double)1.0F) < 1.0E-6 && Math.abs(this.lIlll.IlI() - (double)8.0F) < 1.0E-6) {
         this.lIlll.IIIl(new double[]{(double)10.0F, (double)10.0F});
      }

   }

   public IIIllIlII() {
      super((Object)lIlIII.l(lIIIll(1642098942, 215815297)), lIllII.I, (Object)lIlIII.l(lIIIll(1642098943, 2047018683)));
      this.IIlIlI = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(lIIIll(1642098936, -313057736)), <undefinedtype>.class, null.II));
      this.IIlI = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(lIIIll(1642098937, 117008604)), <undefinedtype>.class, null.l));
      this.lIIII = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(lIIIll(1642098938, -1638395346)), <undefinedtype>.class, null.I));
      this.IIIII = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(lIIIll(1642098939, -1186059495)), (double)10.0F, (double)14.0F, (double)1.0F, (double)20.0F, (double)0.5F)).Ill(lIlIII.l(lIIIll(1642098932, 265122535))));
      this.IIlIll = (llllIlIl)this.IIIlIll(new llllIlIl(lIlIII.l(lIIIll(1642098933, -1137420817)), (double)10.0F, (double)10.0F, (double)1.0F, (double)10.0F, 0.1));
      this.lIlll = (llllIlIl)this.IIIlIll(new llllIlIl(lIlIII.l(lIIIll(1642098934, -885167230)), (double)10.0F, (double)10.0F, (double)1.0F, (double)10.0F, 0.1));
      this.IIlIl = (llllIlIl)this.IIIlIll(new llllIlIl(lIlIII.l(lIIIll(1642098935, 288174141)), 0.89, 0.93, 0.8, (double)1.0F, 0.01));
      this.lIIl = (llllIlIl)this.IIIlIll(new llllIlIl(lIlIII.l(lIIIll(1642098928, 954028536)), 0.89, 0.93, 0.8, (double)1.0F, 0.01));
      this.III = (lIIIIl)this.IIIlIll((lIIIIl)(new lIIIIl(lIlIII.l(lIIIll(1642098929, -1028177961)), false)).lIII(() -> !this.IlllII()));
      this.IIllll = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(lIIIll(1642098930, 1883455746)), (double)22.0F, (double)0.0F, (double)100.0F, (double)1.0F)).IIIl(lIlIII.l(lIIIll(1642098931, -1116637288))));
      this.lIl = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(lIIIll(1642098924, 1466265148)), (double)195.0F, (double)0.0F, (double)500.0F, (double)5.0F)).IIIl(lIlIII.l(lIIIll(1642098925, 1146159587))));
      this.IlIll = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(lIIIll(1642098926, 148986671)), (double)10.0F, (double)0.0F, (double)100.0F, (double)1.0F)).IIIl(lIlIII.l(lIIIll(1642098927, 1818300023))));
      this.IIlIII = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(lIIIll(1642098920, 222971394)), (double)0.0F, (double)0.0F, (double)100.0F, (double)1.0F)).IIIl(lIlIII.l(lIIIll(1642098921, -891784852))));
      this.IlIIIl = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(lIIIll(1642098922, 1018302031)), (double)65.0F, (double)0.0F, (double)100.0F, (double)1.0F)).IIIl(lIlIII.l(lIIIll(1642098923, 1592001852))));
      this.IlllI = (IIIIllIII)this.IIIlIll(new IIIIllIII(lIlIII.l(lIIIll(1642098916, 738919343)), llIIl, Set.of(IIllI, IIlllI, llIl)));
      this.IIIlII = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(lIIIll(1642098917, -1351012001)), <undefinedtype>.class, null.II));
      this.IIIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lIIIll(1642098918, 327222893)), false));
      this.lllll = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(lIIIll(1642098919, 1891064728)), (double)3.0F, (double)1.0F, (double)3.0F, 0.01)).IIIl(lIlIII.l(lIIIll(1642098912, 938683751))));
      this.lllIl = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(lIIIll(1642098913, -903866443)), 2.7, (double)3.0F, (double)2.0F, (double)3.0F, 0.01)).Ill(lIlIII.l(lIIIll(1642098914, 987069663))));
      this.llI = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(lIIIll(1642098915, -1955250911)), (double)3.0F, (double)1.0F, (double)8.0F, 0.01)).IIIl(lIlIII.l(lIIIll(1642098908, 316288642))));
      this.IIIll = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(lIIIll(1642098909, -1680073806)), (double)180.0F, (double)2.0F, (double)360.0F, (double)1.0F)).IIIl(lIlIII.l(lIIIll(1642098910, -58583674))));
      this.l = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lIIIll(1642098911, 684014373)), true));
      this.llIlI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lIIIll(1642098904, -734000815)), true));
      this.IIIlIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lIIIll(1642098905, 1646140856)), true));
      this.IlIII = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lIIIll(1642098906, -2078664088)), true));
      this.IIllII = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lIIIll(1642098907, 1212236034)), false));
      this.lIIIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lIIIll(1642098900, -1440334194)), false));
      this.IIIllI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lIIIll(1642098901, -599493034)), false));
      this.lIlI = (lllIIlIl)this.IIIlIll(new lllIIlIl(lIlIII.l(lIIIll(1642098902, 1420122248))));
      this.IIIlI = Long.MIN_VALUE;
      this.IIll = new IlIlIll();
      this.IlII = new IlIIIlII();
      this.IIIIlI = -1;
      this.lIll = lIIIlI(124442357, 707028519);
      this.ll = lIIIlI(124442356, 947187614);
      lllIIlIl var10000 = this.lIlI;
      lIIIIl var10001 = this.IIIllI;
      Objects.requireNonNull(var10001);
      var10000.lIII(var10001::III);
      this.IIIII.lIII(this::IlllII);
      this.IIllII.lIII(this::IlllII);
      this.IIIlIl.lIII(() -> !this.IlllII());
      this.IlIII.lIII(() -> false);
      this.IIlIl.lIII(() -> !this.IlllII());
      this.lIIl.lIII(() -> !this.IlllII());
      this.lllll.lIII(() -> !(Boolean)this.IIIl.III());
      llllIlIl var1 = this.lllIl;
      var10001 = this.IIIl;
      Objects.requireNonNull(var10001);
      var1.lIII(var10001::III);
   }

   private void llIll() {
      if (this.IIlIlI.III() == null.l) {
         this.IIlIlI.I(null.II);
         IIlllIlI var1 = IIlllIlI.II();
         if (var1 != null) {
            var1.III(null.l, lIlIII.Il(lIIIll(1642098903, 157509990)), lIlIII.Il(lIIIll(1642098896, 439376264)), 4000L);
         }
      }

   }

   private boolean lllII(class_1799 var1) {
      if (var1.method_7960()) {
         return false;
      } else {
         return IllllIlI.IlllII(var1) ? true : class_7923.field_41178.method_10221(var1.method_7909()).method_12832().endsWith(lIlIII.Il(lIIIll(1642098897, -1615041035)));
      }
   }

   private boolean llllI() {
      return !this.IlllII() ? true : this.IlII.Il();
   }

   public void lI() {
      this.IlIII(class_310.method_1551(), false);
      this.IIll.IIIlIll();
      this.IIllIl(class_310.method_1551());
      this.IlII.I();
      this.lIll = lIIIlI(124442355, -1724341977);
   }

   private boolean lllll(class_310 var1, class_1309 var2) {
      if (var2 != this.llII) {
         this.llII = var2;
      }

      if (!lIlIllll.lIIl(var1) && !IllllIlI.IlllIl()) {
         if (var1.field_1724.method_6115() && !this.IlIlI) {
            return false;
         } else {
            class_3966 var3 = IllllIlI.IlIIll(var1, var2, this.IlIll(), true);
            if (var3 == null) {
               class_3966 var4 = IllllIlI.IlIIllI(var1, this.IlIll());
               if (var4 != null && (var2 == null || var4.method_17782() == var2)) {
                  var3 = var4;
               }
            }

            if (var3 == null) {
               class_239 var5 = var1.field_1765;
               if (var5 instanceof class_3966) {
                  class_3966 var7 = (class_3966)var5;
                  if (var2 == null || var7.method_17782() == var2) {
                     var3 = var7;
                  }
               }
            }

            if (var3 == null && this.IIlIlI.III() == null.l && (IlIlIl.IIIlI(var1, var2, this.IlIll()) || this.IIll.IIIIIlI(var1, var2.method_5829().method_1005()) <= 35.0F || (double)var1.field_1724.method_5739(var2) <= this.IlIll())) {
               class_243 var8 = this.IIllII(var1, var2);
               if (var8 == null) {
                  var8 = var2.method_5829().method_1005();
               }

               var3 = new class_3966(var2, var8);
            }

            if (this.IIll.llIIIl() && var3 == null) {
               return false;
            } else if (this.IIIlII(var1, var2)) {
               return false;
            } else if (var3 != null && IllllIlI.l(var2, var1.field_1724) && !(Boolean)this.III.III() && this.IIIIlI(var1, var2)) {
               return false;
            } else if (!this.IlIIll(var1, var2) && var3 == null) {
               return false;
            } else {
               boolean var9 = this.IlllII();
               double var10 = var9 ? (double)0.0F : this.IIIllI(var1.field_1724.method_6047());
               if (IllllIlI.IlIIlII(var1, var10, !var9) && this.IIIlIl(var1, var2)) {
                  if (var1.field_1724.field_6012 <= this.lIll) {
                     return false;
                  } else if (!this.llllI()) {
                     return false;
                  } else {
                     this.lIlII(var1);
                     if (var1.field_1724.method_6115()) {
                        return false;
                     } else if (var3 == null) {
                        return false;
                     } else if (this.IIIll(var1, var2)) {
                        return false;
                     } else {
                        if (this.llII(var1)) {
                           if (this.IlllII() || !(Boolean)this.IlIII.III() || !IllllIlI.lllllI(var1.field_1724) || !this.IlI(var1)) {
                              return false;
                           }

                           IllllIlI.IlI(var1, 3);
                           this.llIII(var1);
                           var1.field_1761.method_2897(var1.field_1724);
                        }

                        if (this.IIlIl(var1, var2)) {
                           this.lIlIl();
                           return true;
                        } else if (!IllllIlI.lllII(var1, var3)) {
                           return false;
                        } else {
                           this.lIlIl();
                           this.IIllll(var1, var2);
                           return true;
                        }
                     }
                  }
               } else {
                  return false;
               }
            }
         }
      } else {
         return false;
      }
   }

   private boolean IIIIII(class_746 var1) {
      return var1 != null && var1.method_6115() && var1.method_6058() == class_1268.field_5810;
   }

   private class_1309 IIIIIl(class_310 var1) {
      class_746 var2 = var1.field_1724;
      if (var2 != null && var1.field_1687 != null) {
         class_1309 var3 = this.IIllI(var1);
         if (var3 != null) {
            this.IIll.llllIl(var3.method_5628(), (double)var2.method_5739(var3));
            return var3;
         } else {
            if (this.IIlI.III() == null.lI) {
               lIllIIl var4 = lIllIIl.Il();
               class_1309 var5 = var4 == null ? null : var4.IlII().Ill();
               if (var5 != null && var5.method_5805() && !var5.method_31481() && this.IlllI(var1, var5) && this.IlIllI(var1, var5, true) != null) {
                  return var5;
               }
            }

            class_243 var13 = var2.method_33571();
            Object var14 = (Boolean)this.llIlI.III() ? var1.field_1687.method_18456() : var1.field_1687.method_18112();
            <undefinedtype> var6 = null;
            class_1309 var7 = null;

            for(class_1297 var9 : var14) {
               if (var9 instanceof class_1309) {
                  class_1309 var10 = (class_1309)var9;
                  if (this.IlllI(var1, var10)) {
                     <undefinedtype> var11 = this.IllIIl(var1, var10);
                     if (var11 != null) {
                        <undefinedtype> var12 = this.IlIIl(var13, var10, var11);
                        if (var6 == null || this.lIIll(var12, var6)) {
                           var6 = var12;
                           var7 = var10;
                        }
                     }
                  }
               }
            }

            if (var7 != null && var6 != null) {
               if (!this.IIll.lIIllI(var7.method_5628(), var6.lI()) && this.llII != null && this.llII.method_5805() && !this.llII.method_31481() && this.IlllI(var1, this.llII)) {
                  return this.llII;
               }

               this.IIll.llllIl(var7.method_5628(), var6.lI());
            }

            return var7;
         }
      } else {
         return null;
      }
   }

   private boolean IIIIlI(class_310 var1, class_1309 var2) {
      lIllIIl var3 = lIllIIl.Il();
      if (var3 != null && var1 != null && var1.field_1724 != null && var2 != null) {
         IIIIIIIIl var4 = var3.IIl().lIlll();
         if (var4 != null && var4.IIIIIlI()) {
            if (var4.IIlll(var2)) {
               return true;
            }

            if (var4.lIIII(var1, var2)) {
               return true;
            }
         }

         llIlIlI var5 = var3.IIl().IlIlll();
         if (var5 != null && var5.IIIIIlI()) {
            if (var5.IIlIIl(var2)) {
               return true;
            }

            if (var5.IIlll(var1, var2)) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public void lIl() {
      this.llIll();
      this.IIll.IIlIIII();
      this.IlIII(class_310.method_1551(), true);
      this.lIllI();
      this.IIll();
      this.IllIII();
      this.lIll = lIIIlI(124442354, -1263455907);
      this.IlI = 0;
      this.IIIIlI = -1;
      this.llII = null;
      this.IIllIl(class_310.method_1551());
      this.IlII.I();
   }

   private double IIIIll(llllIlIl var1) {
      double var2 = var1.IlII();
      double var4 = var1.IlI();
      return var2 == var4 ? var2 : ThreadLocalRandom.current().nextDouble(var2, var4);
   }

   private boolean IIIlII(class_310 var1, class_1309 var2) {
      lIllIIl var3 = lIllIIl.Il();
      if (var3 == null) {
         return false;
      } else {
         IIllIlII var4 = var3.IIl();
         return var4 != null && var4.IIIlIII() != null && var4.IIIlIII().lllll(var1, var2);
      }
   }

   private boolean IIIlIl(class_310 var1, class_1309 var2) {
      class_746 var3 = var1.field_1724;
      if (this.IIIIII(var3)) {
         return false;
      } else if (this.IlllII()) {
         return true;
      } else if (IllllIlI.lIllI(var1) <= 0 && IllllIlI.IIIIlII(var1) <= 0) {
         class_1799 var4 = var3.method_6047();
         float var5 = var3.method_7261(1.0F);
         if ((double)var5 < this.IIIllI(var4)) {
            return false;
         } else if (var4.method_7909() instanceof class_9362) {
            return !this.lII(var3);
         } else {
            return !this.IllIll(var3, var5);
         }
      } else {
         return false;
      }
   }

   private double IIIllI(class_1799 var1) {
      return var1 != null && !var1.method_7960() && var1.method_7909() instanceof class_1743 ? this.IIlII : this.llIII;
   }

   public void IllI(class_310 var1) {
   }

   private double IIlIII() {
      return (Boolean)this.IIIl.III() ? this.lII : (Double)this.lllll.III();
   }

   private void IIlIIl(class_310 var1, boolean var2) {
      if (var1 != null && var1.field_1690 != null && var1.field_1690.field_1904 != null) {
         lllI var3 = x.lllI.lll();
         if (var3 != null) {
            if (var2) {
               var3.IlI(this, var1, var1.field_1690.field_1904, true);
            } else {
               var3.IIIl(this, var1, var1.field_1690.field_1904);
            }

         } else {
            var1.field_1690.field_1904.method_23481(var2 || IllllIlI.IIIll(var1, var1.field_1690.field_1904));
         }
      }
   }

   public void IIlIlI(float var1, float var2, float var3, float var4) {
      float var5 = class_3532.method_15393(var3 - var1);
      float var6 = var4 - var2;
      this.lIII = class_3532.method_15393(this.lIII + var5);
      this.lllI = class_3532.method_15363(this.lllI + var6, -90.0F, 90.0F);
   }

   private boolean IIlIll(class_310 var1, class_1309 var2) {
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null && var2 != null) {
         class_243 var3 = var1.field_1724.method_33571();
         class_238 var4 = var2.method_5829();
         double var5 = (var4.field_1323 + var4.field_1320) * (double)0.5F;
         double var7 = (var4.field_1322 + var4.field_1325) * (double)0.5F;
         double var9 = (var4.field_1321 + var4.field_1324) * (double)0.5F;
         return this.IlIIII(var1, var3, new class_243(var5, var7, var9)) || this.IlIIII(var1, var3, new class_243(var5, var4.field_1322 + (double)var2.method_5751() * 0.85, var9)) || this.IlIIII(var1, var3, new class_243(var5, var4.field_1322 + (var4.field_1325 - var4.field_1322) * 0.35, var9)) || this.IlIIII(var1, var3, new class_243(var4.field_1323, var7, var9)) || this.IlIIII(var1, var3, new class_243(var4.field_1320, var7, var9));
      } else {
         return false;
      }
   }

   private class_243 IIllII(class_310 var1, class_1309 var2) {
      if (var1 != null && var1.field_1724 != null && var2 != null) {
         class_243 var3 = var1.field_1724.method_33571();
         class_238 var4 = var2.method_5829();
         class_243 var5 = new class_243(class_3532.method_15350(var3.field_1352, var4.field_1323, var4.field_1320), class_3532.method_15350(var3.field_1351, var4.field_1322, var4.field_1325), class_3532.method_15350(var3.field_1350, var4.field_1321, var4.field_1324));
         double var6 = this.IlIll() + 1.0E-4;
         return var3.method_1025(var5) <= var6 * var6 && this.IlIIII(var1, var3, var5) ? var5 : null;
      } else {
         return null;
      }
   }

   private void IIllIl(class_310 var1) {
      this.lIlII(var1);
      this.IIIIII = false;
      this.lIlIl = 0;
      this.IIIIIl = 0;
   }

   private <undefinedtype> IIlllI() {
      // $FF: Couldn't be decompiled
   }

   private void IIllll(class_310 var1, class_1309 var2) {
      if (!this.llIIl(var1, var2)) {
         this.IIllIl(var1);
      } else {
         ThreadLocalRandom var3 = ThreadLocalRandom.current();
         if (var3.nextDouble() > 0.86) {
            this.Illll(var3, 2, 5);
         } else {
            this.Illll(var3, 0, 3);
            if (this.lIlIl == 0) {
               this.IIII(var1);
            }

         }
      }
   }

   private boolean IlIIII(class_310 var1, class_243 var2, class_243 var3) {
      if (var1 != null && var1.field_1687 != null && var2 != null && var3 != null) {
         class_3965 var4 = IllllIlI.IIIlIll(var1, var1.field_1724, var2, var3);
         if (var4 != null && var4.method_17783() != class_240.field_1333) {
            return var2.method_1025(var4.method_17784()) + 1.0E-4 >= var2.method_1025(var3);
         } else {
            return true;
         }
      } else {
         return false;
      }
   }

   private boolean IlIIlI(class_310 var1) {
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null) {
         if (this.lIIIIl(var1)) {
            this.ll = var1.field_1724.field_6012;
            return true;
         } else {
            return this.IIIlll && this.ll != lIIIlI(124442353, -1139565912) && var1.field_1724.field_6012 - this.ll <= lIIIlI(124442352, 310671558);
         }
      } else {
         return false;
      }
   }

   private boolean IlIIll(class_310 var1, class_1309 var2) {
      if (var1 != null && var1.field_1724 != null && var2 != null) {
         <undefinedtype> var3 = this.IlIllI(var1, var2, true);
         if (var3 == null) {
            return false;
         } else {
            float var4 = this.IIll.IIIIIlI(var1, var3.ll());
            if (var4 > 28.0F) {
               return false;
            } else if (var4 > 10.0F) {
               return false;
            } else {
               float var5 = this.IIll.lllIIl() * 20.0F;
               if (var5 > 120.0F) {
                  return false;
               } else {
                  double var6 = var1.field_1724.method_18798().method_37267();
                  return !(var6 > 0.22) || !(var4 > 15.0F);
               }
            }
         }
      } else {
         return false;
      }
   }

   public boolean IIlI(class_310 var1) {
      return this.IIlll;
   }

   private void IlIlIl(class_310 var1, class_1309 var2) {
      if (!this.llIIl(var1, var2)) {
         this.IIllIl(var1);
      } else if (this.IlIlI) {
         if (--this.IIIIIl <= 0) {
            this.lIlII(var1);
         }

      } else if (!this.IIIIII) {
         this.Illll(ThreadLocalRandom.current(), 2, lIIIlI(124442367, -525132213));
      } else if (this.lIlIl > 0) {
         --this.lIlIl;
      } else {
         this.IIII(var1);
      }
   }

   private <undefinedtype> IlIllI(class_310 var1, class_1309 var2, boolean var3) {
      // $FF: Couldn't be decompiled
   }

   private void IlIlll(class_310 var1) {
      if (this.IIlll) {
         if (var1 != null && var1.field_1724 != null && var1.field_1687 != null) {
            long var2 = var1.field_1687.method_75260();
            if (var2 != this.IIIlI) {
               this.IIIlI = var2;
               float var4 = this.IlIl;
               float var5 = class_3532.method_15363(this.IllII, -90.0F, 90.0F);
               if (IlIlIl.llI(var1, lIIIlI(124442366, -2100332929), var4, var5)) {
                  --this.lIllI;
                  if (this.lIllI <= 0) {
                     this.IIlll = false;
                  }

               }
            }
         } else {
            this.IIlll = false;
         }
      }
   }

   private void IllIII() {
      this.IllIl = this.IIIIll(this.IIlIll);
      this.Il = this.IIIIll(this.lIlll);
   }

   static {
      short var6 = 18171;
      String var7 = "\uee1d\uee02\uee85\ueeed\uee7e\uee62\ueee8\uee30\ueeff\ueeca\uee84\ueef8\uee9f\uee39\uee3d\ueef9\uee94\uee8f\uee04\uee2e\uee4f\uee50\uee7a\uee0c\ueeb3\uee10\uee88\ueee2\ue393\ue3e1\ue31c\ue37c\ue3f3\ue3e0\ue343\ue3a1㤂㥲㧛㧳㥡㥁㧍㤤㧤㧬㧂㦍係促伅伮俧依伱俱似优佻伪\ud88f\ud897\ud814\ud871\ud8ed\ud8de\ud812\ud8d0㌧㌩㎘㏉㍃㍙㏹㌇㏔㏤㎑㏍㎣㌸㌧㎜ꮇꮈꭞ\uab6eꮼꯄꭲꮻꭦꭃ\uab1c\uab08貗賢谫豗㨌㩣㪨㫲觫觤襷褄規覽褂觗褄褊襲褎襨觱覼褝襾襹覧觨覹覮覃覞ﻣﻗ﹌︍ﺃﺧ︇ﻒ︀︶﹖︈\ufe6cﺂﺵ︆ﹼ︽ﺯﺾ⓰⒃\u2454\u2438⒐⒝⑥Ⓩ␦␌\u244d␙⑱⓬ⓨ␢⑨␗⓬⒮ഄഞඒ\u0df8ഹു\u0dd5ാ෭\u0dfcන\u0de4ඁൢഄෝ\uf768\uf777\uf7ce\uf7a1\uf70b\uf718\uf7bb\uf75e\uf79a\uf7ad\uf7b3\uf7bc\uf7e8\uf766\uf776\uf7b9\uf7f6\uf7fb\uf707\uf734䖞䗬䔘䕖䗿䗬䔊䖟䕳䕲䔁䕫䔚䖿䗏䔦裮袺衻蠻抸抏戔扄拜拊戬抺払扄戆扐戫护抎扨戤扶抩拦熑熒焅焛㴸㴡㷧㷌㴅㵽㶨㴝㷞㷪㶿㷈姾妪奫夫㢕㢚㠫㡜㣰㣔㡞㢚㡳㡻㠈㡆㠖㣵㣋㠯ｇ３ￒﾒ९ॢ\u09b4\u0984ऋऒএॐঃঃযছ৭ॣूৗ死欯毮殮᧒\u19cbᤍᤦ᧯ᦐ\u191f᧦ᤲᤵ\u1943ᥛ骠骹驿驔骝髢驭骅驆驲騙驒騦骫骼驠♜♫⛠⚗☻☡⚎♣⚳⚰⚜⚪⛞♐★⚻⛁⚁♟♧☈☓♎☫䕪䕝䗖䖡䔍䔗䖸䔰ȳȸ˹ʹ�ￊａＶﾚﾀＯￂ２！ｘ７ｺ￡ￓＷ༕༞\u0fdfྟ뺨뺟븶빃뻌뻼븼뺜빘빯빬빏븩뺎뺬빎✚✑⟐➐긆긴꺟껂쥀쥒짳즡ᴘᵪᶞᷤᵸᵺᶍᴧ᷵ᷞᶥᷱᶚᴹᵉᶠ\ue19d\ue190\ue11f\ue161\ue1ff\ue1ca\ue140\ue1bc\ue179\ue128\ue116\ue119\ue11c\ue1bb\ue1bf\ue159埃垱坅圿垣垡坖埼圕地圇圖坈埜埘坻뇄뇚녝넥놡놀넠뇳넪넁녒녊綘綂細絷緽緣絍継統絠絅絏鿸龉齗鼇龛龼鼄鿆鼋鼻齆鼑齺鿤鿎齃\ue99b\ue994\ue907\ue96a\ue9fe\ue9da\ue950\ue994\ue974\ue92c\ue912\ue940\ue91d\ue9fa\ue99a\ue921慺慵懦憋感愻憱愮憚憮懁憜囃囬噴嘼嚣嚓嘷固嘩嘸噐嘬噋囘囲嘊噟嘙嚠围嚔囑囤嚳䖐䖿䔧䕯䗰䗀䕤䖩䕺䕫䔃䕿䔖䖛䖹䕶䔋䕎䗫䖬䗀䗓䖩䖌䔶䖘䔀䔎䖔䔪䕂䔯䗣䗇䔵䕢䖦䖔䔧䖅䔗䔴䕌䕐䕄䖂䗁䔯䔧䕍䗚䗑䖂䗊䖒䖝䔰䖞䕬䔽䖬䔨䔲䔊䗎䖸䕷䔇䗤䖜䕠䗥䔑䔡䕦䕟쀚쁨삕샵쁺쁩샊쀨\udea6\udeb1\ude10\ude40\udedb\udef8\ude24\udee6蟮螀蝠蜊螒螀蝧螨⯕⯅⭤⬶⮨⮺⭐⮒\udabe\udab1\uda10\uda40\udadb\udaf8\uda24\udae6쯑쮧쭇쬭쮵쮧쭀쮏랟랗뜶띤럺럨뜂럀";
      char[] var8 = "\u001c\b\f\f\b\u0010\f\u0004\u0004\u0018\u0014\u0014\u0010\u0014\u0010\u0004\u0014\u0004\f\u0004\u0010\u0004\u0010\u0004\f\u0010\u0018\b\u0004\u0010\u0004\u0010\u0004\u0004\u0004\u0010\u0010\u0010\f\f\u0010\u0010\f\u0018L\b\b\b\b\b\b\b".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            IlIIlI = var9;
            IlIIll = new Object[var9.length];
            int var2 = -852555635;
            byte[] var0 = "kä;&?¬ÙÒ`a¸_r11çÓ}\u007fYþôï\"öVDÔØÁ¦±*öÀ?H\u008a¨ö".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            I = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               I[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            IIllI = lIlIII.l(lIIIll(1642098898, 187259235));
            IIlllI = lIlIII.l(lIIIll(1642098899, 1382512711));
            llIl = lIlIII.l(lIIIll(1642098892, -27456460));
            llIIl = List.of(new Object(IIllI, lIlIII.l(lIIIll(1642098893, 254349808))) {
               private final <undefinedtype> I;
               private final int l;
               private final <undefinedtype> II;
               private final long Il;
               private final int lI;
               private static final int[] ll;

               public {
                  this((Object)var1, (Object)var2);
               }

               private static <undefinedtype> I(Object var0) {
                  return lIlIII.IIIl(var0);
               }

               public <undefinedtype> l() {
                  return this.I;
               }

               public JsonElement II() {
                  return new JsonPrimitive(this.ll());
               }

               public <undefinedtype> Il() {
                  return this.II;
               }

               public long lI() {
                  return this.Il;
               }

               public {
                  this((String)var1, (Object)var2);
               }

               public {
                  this((Object)var1, (Object)var2);
               }

               public String ll() {
                  return this.II.lIlI();
               }

               private static int III(Object var0) {
                  int[] var1 = new int[]{0};
                  var0.Ill((var1) -> {
                     if (Character.isBmpCodePoint(var1)) {
                        var0[0] = Ill(-1117285940, 345343004) * var0[0] + var1;
                     } else {
                        char[] var2 = Character.toChars(var1);
                        var0[0] = Ill(-1117285939, 1915072505) * var0[0] + var2[0];
                        var0[0] = Ill(-1117285938, 1789475354) * var0[0] + var2[1];
                     }
                  });
                  return var1[0];
               }

               // $FF: synthetic method
               private static void IIl(int[] var0, int var1) {
                  if (Character.isBmpCodePoint(var1)) {
                     var0[0] = Ill(-1117285940, 345343004) * var0[0] + var1;
                  } else {
                     char[] var2 = Character.toChars(var1);
                     var0[0] = Ill(-1117285939, 1915072505) * var0[0] + var2[0];
                     var0[0] = Ill(-1117285938, 1789475354) * var0[0] + var2[1];
                  }
               }

               public int hashCode() {
                  return Ill(-1117285937, -372372636) * this.l + this.lI;
               }

               public String IlI() {
                  return this.I.lIlI();
               }

               public {
                  this.II = I(var1);
                  this.I = I(var2);
                  this.Il = this.II.lll();
                  this.l = III(this.II);
                  this.lI = III(this.I);
               }

               public boolean equals(Object var1) {
                  if (var1 == this) {
                     return true;
                  } else {
                     if (var1 instanceof <undefinedtype>) {
                        <undefinedtype> var2 = (<undefinedtype>)var1;
                        if (this.Il == var2.Il && this.I.lll() == var2.I.lll()) {
                           return this.ll().equals(var2.ll()) && this.IlI().equals(var2.IlI());
                        }
                     }

                     return false;
                  }
               }

               private static int Ill(int var0, int var1) {
                  return ll[var0 ^ -1117285940] ^ var1 ^ var0;
               }

               static {
                  int var2 = 1128642418;
                  byte[] var0 = "ê·¢½\u008c\u0007\u0089Y\u0094\u008b\u001c¹\u0017ì-Æ".getBytes("ISO-8859-1");
                  int var1 = var0.length / 4;
                  ll = new int[var1];
                  int var3 = 0;
                  int var4 = 0;

                  do {
                     int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
                     var5 ^= var2;
                     ll[var4] = var5;
                     var3 += 4;
                     ++var4;
                  } while(var4 < var1);

               }
            }, new Object(IIlllI, lIlIII.l(lIIIll(1642098894, 507517519))) {
               private final <undefinedtype> I;
               private final int l;
               private final <undefinedtype> II;
               private final long Il;
               private final int lI;
               private static final int[] ll;

               public {
                  this((Object)var1, (Object)var2);
               }

               private static <undefinedtype> I(Object var0) {
                  return lIlIII.IIIl(var0);
               }

               public <undefinedtype> l() {
                  return this.I;
               }

               public JsonElement II() {
                  return new JsonPrimitive(this.ll());
               }

               public <undefinedtype> Il() {
                  return this.II;
               }

               public long lI() {
                  return this.Il;
               }

               public {
                  this((String)var1, (Object)var2);
               }

               public {
                  this((Object)var1, (Object)var2);
               }

               public String ll() {
                  return this.II.lIlI();
               }

               private static int III(Object var0) {
                  int[] var1 = new int[]{0};
                  var0.Ill((var1) -> {
                     if (Character.isBmpCodePoint(var1)) {
                        var0[0] = Ill(-1117285940, 345343004) * var0[0] + var1;
                     } else {
                        char[] var2 = Character.toChars(var1);
                        var0[0] = Ill(-1117285939, 1915072505) * var0[0] + var2[0];
                        var0[0] = Ill(-1117285938, 1789475354) * var0[0] + var2[1];
                     }
                  });
                  return var1[0];
               }

               // $FF: synthetic method
               private static void IIl(int[] var0, int var1) {
                  if (Character.isBmpCodePoint(var1)) {
                     var0[0] = Ill(-1117285940, 345343004) * var0[0] + var1;
                  } else {
                     char[] var2 = Character.toChars(var1);
                     var0[0] = Ill(-1117285939, 1915072505) * var0[0] + var2[0];
                     var0[0] = Ill(-1117285938, 1789475354) * var0[0] + var2[1];
                  }
               }

               public int hashCode() {
                  return Ill(-1117285937, -372372636) * this.l + this.lI;
               }

               public String IlI() {
                  return this.I.lIlI();
               }

               public {
                  this.II = I(var1);
                  this.I = I(var2);
                  this.Il = this.II.lll();
                  this.l = III(this.II);
                  this.lI = III(this.I);
               }

               public boolean equals(Object var1) {
                  if (var1 == this) {
                     return true;
                  } else {
                     if (var1 instanceof <undefinedtype>) {
                        <undefinedtype> var2 = (<undefinedtype>)var1;
                        if (this.Il == var2.Il && this.I.lll() == var2.I.lll()) {
                           return this.ll().equals(var2.ll()) && this.IlI().equals(var2.IlI());
                        }
                     }

                     return false;
                  }
               }

               private static int Ill(int var0, int var1) {
                  return ll[var0 ^ -1117285940] ^ var1 ^ var0;
               }

               static {
                  int var2 = 1128642418;
                  byte[] var0 = "ê·¢½\u008c\u0007\u0089Y\u0094\u008b\u001c¹\u0017ì-Æ".getBytes("ISO-8859-1");
                  int var1 = var0.length / 4;
                  ll = new int[var1];
                  int var3 = 0;
                  int var4 = 0;

                  do {
                     int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
                     var5 ^= var2;
                     ll[var4] = var5;
                     var3 += 4;
                     ++var4;
                  } while(var4 < var1);

               }
            }, new Object(llIl, lIlIII.l(lIIIll(1642098895, 1645170423))) {
               private final <undefinedtype> I;
               private final int l;
               private final <undefinedtype> II;
               private final long Il;
               private final int lI;
               private static final int[] ll;

               public {
                  this((Object)var1, (Object)var2);
               }

               private static <undefinedtype> I(Object var0) {
                  return lIlIII.IIIl(var0);
               }

               public <undefinedtype> l() {
                  return this.I;
               }

               public JsonElement II() {
                  return new JsonPrimitive(this.ll());
               }

               public <undefinedtype> Il() {
                  return this.II;
               }

               public long lI() {
                  return this.Il;
               }

               public {
                  this((String)var1, (Object)var2);
               }

               public {
                  this((Object)var1, (Object)var2);
               }

               public String ll() {
                  return this.II.lIlI();
               }

               private static int III(Object var0) {
                  int[] var1 = new int[]{0};
                  var0.Ill((var1) -> {
                     if (Character.isBmpCodePoint(var1)) {
                        var0[0] = Ill(-1117285940, 345343004) * var0[0] + var1;
                     } else {
                        char[] var2 = Character.toChars(var1);
                        var0[0] = Ill(-1117285939, 1915072505) * var0[0] + var2[0];
                        var0[0] = Ill(-1117285938, 1789475354) * var0[0] + var2[1];
                     }
                  });
                  return var1[0];
               }

               // $FF: synthetic method
               private static void IIl(int[] var0, int var1) {
                  if (Character.isBmpCodePoint(var1)) {
                     var0[0] = Ill(-1117285940, 345343004) * var0[0] + var1;
                  } else {
                     char[] var2 = Character.toChars(var1);
                     var0[0] = Ill(-1117285939, 1915072505) * var0[0] + var2[0];
                     var0[0] = Ill(-1117285938, 1789475354) * var0[0] + var2[1];
                  }
               }

               public int hashCode() {
                  return Ill(-1117285937, -372372636) * this.l + this.lI;
               }

               public String IlI() {
                  return this.I.lIlI();
               }

               public {
                  this.II = I(var1);
                  this.I = I(var2);
                  this.Il = this.II.lll();
                  this.l = III(this.II);
                  this.lI = III(this.I);
               }

               public boolean equals(Object var1) {
                  if (var1 == this) {
                     return true;
                  } else {
                     if (var1 instanceof <undefinedtype>) {
                        <undefinedtype> var2 = (<undefinedtype>)var1;
                        if (this.Il == var2.Il && this.I.lll() == var2.I.lll()) {
                           return this.ll().equals(var2.ll()) && this.IlI().equals(var2.IlI());
                        }
                     }

                     return false;
                  }
               }

               private static int Ill(int var0, int var1) {
                  return ll[var0 ^ -1117285940] ^ var1 ^ var0;
               }

               static {
                  int var2 = 1128642418;
                  byte[] var0 = "ê·¢½\u008c\u0007\u0089Y\u0094\u008b\u001c¹\u0017ì-Æ".getBytes("ISO-8859-1");
                  int var1 = var0.length / 4;
                  ll = new int[var1];
                  int var3 = 0;
                  int var4 = 0;

                  do {
                     int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
                     var5 ^= var2;
                     ll[var4] = var5;
                     var3 += 4;
                     ++var4;
                  } while(var4 < var1);

               }
            });
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 43;
                     break;
                  case 1:
                     var10000 = 9;
                     break;
                  case 2:
                     var10000 = 69;
                     break;
                  case 3:
                     var10000 = 46;
                     break;
                  case 4:
                     var10000 = 100;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private <undefinedtype> IllIIl(class_310 var1, class_1309 var2) {
      return this.IlIllI(var1, var2, false);
   }

   private class_243 IllIlI(float var1, float var2) {
      double var3 = Math.toRadians((double)var1);
      double var5 = Math.toRadians((double)var2);
      double var7 = Math.cos(var5);
      return (new class_243(-Math.sin(var3) * var7, -Math.sin(var5), Math.cos(var3) * var7)).method_1029();
   }

   private boolean IllIll(class_746 var1, float var2) {
      if (!(Boolean)this.IIIlIl.III()) {
         return false;
      } else if (!this.Illlll(var1)) {
         return false;
      } else if (lIlllllI.ll(true, var1.method_24828(), var1.method_18798().field_1351, var1.field_6017)) {
         return true;
      } else {
         boolean var3 = var2 > 0.88F && var1.method_18798().field_1351 < (double)0.0F;
         return !var3;
      }
   }

   private boolean IlllII() {
      return this.lIIII.III() == null.Il;
   }

   public float IlllIl(float var1) {
      return class_3532.method_17821(var1, this.lIlII, this.lIII);
   }

   public boolean IllllI(class_310 var1, class_1309 var2) {
      return this.IIIIIlI() && this.lIlll(var1) && var2 != null && this.IlllI(var1, var2) && this.IlIllI(var1, var2, true) != null;
   }

   private boolean Illlll(class_746 var1) {
      return !var1.method_24828() && !var1.method_5799() && !var1.method_5869() && !var1.method_5771() && !IllllIlI.ll(var1) && !var1.method_5765() && !var1.method_6101() && !var1.method_5740() && !var1.method_6115() && !IllllIlI.lllllI(var1) && !IllllIlI.IIllIII(var1) && !var1.method_31549().field_7479 && !var1.method_6059(class_1294.field_5902) && !var1.method_6059(class_1294.field_5919) && !var1.method_6059(class_1294.field_5906);
   }

   private boolean lIIIIl(class_310 var1) {
      if (var1 != null && var1.field_1724 != null && this.lIlll(var1)) {
         class_1309 var2 = this.IIIIIl(var1);
         if (var2 != null && var2.method_5805() && !var2.method_31481()) {
            double var3 = this.IlIll() + 1.0E-4;
            double var5 = Math.max(var3, (Double)this.llI.III() + 1.0E-4);
            double var7 = var1.field_1724.method_5858(var2);
            return var7 <= var5 * var5;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private static int lIIIlI(int var0, int var1) {
      return I[var0 ^ 124442359] ^ var1 ^ var0;
   }

   private static String lIIIll(int var0, int var1) {
      int var3 = var0 ^ 1642098940;
      char[] var4 = IlIIlI[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IlIIll[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IlIIll[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -1687587710;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 134;
               break;
            case 1:
               var9 = 146;
               break;
            case 2:
               var9 = 115;
               break;
            case 3:
               var9 = 88;
               break;
            case 4:
               var9 = 178;
               break;
            case 5:
               var9 = 242;
               break;
            case 6:
               var9 = 112;
               break;
            case 7:
               var9 = 254;
               break;
            case 8:
               var9 = 71;
               break;
            case 9:
               var9 = 60;
               break;
            case 10:
               var9 = 5;
               break;
            case 11:
               var9 = 101;
               break;
            case 12:
               var9 = 90;
               break;
            case 13:
               var9 = 164;
               break;
            case 14:
               var9 = 212;
               break;
            case 15:
               var9 = 114;
               break;
            case 16:
               var9 = 10;
               break;
            case 17:
               var9 = 48;
               break;
            case 18:
               var9 = 222;
               break;
            case 19:
               var9 = 219;
               break;
            case 20:
               var9 = 202;
               break;
            case 21:
               var9 = 245;
               break;
            case 22:
               var9 = 206;
               break;
            case 23:
               var9 = 184;
               break;
            case 24:
               var9 = 65;
               break;
            case 25:
               var9 = 161;
               break;
            case 26:
               var9 = 122;
               break;
            case 27:
               var9 = 89;
               break;
            case 28:
               var9 = 167;
               break;
            case 29:
               var9 = 83;
               break;
            case 30:
               var9 = 85;
               break;
            case 31:
               var9 = 55;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
