package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_265;
import net.minecraft.class_2680;

@Environment(EnvType.CLIENT)
public final class llIlIl extends IIIIIIIlI {
   private static volatile llIlIl I;
   private final lIIIIl l = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIII(463534600, 513278950)), false));
   private static final String[] II;
   private static final Object[] Il;

   public static void ll() {
      I = null;
   }

   private boolean IlI(class_1297 var1, class_1297 var2) {
      return this.lII(var1) || this.lII(var2);
   }

   private boolean lII(class_1297 var1) {
      if (var1 instanceof class_1657 var2) {
         if (var2.method_73183() != null) {
            return var2.method_5757() || this.lll(var2);
         }
      }

      return false;
   }

   public static boolean llI(class_1297 var0, class_1297 var1) {
      llIlIl var2 = I;
      return var2 != null && var2.IIIIIlI() && (!(Boolean)var2.l.III() || !var2.IlI(var0, var1));
   }

   public llIlIl() {
      super((Object)lIlIII.l(IIII(463534602, 1550860969)), lIllII.III, (Object)lIlIII.l(IIII(463534603, -1253408858)));
      I = this;
   }

   private boolean lll(class_1657 var1) {
      class_238 var2 = var1.method_5829().method_35580(0.05, 0.05, 0.05);
      if (!(var2.method_17939() <= (double)0.0F) && !(var2.method_17940() <= (double)0.0F) && !(var2.method_17941() <= (double)0.0F)) {
         class_1937 var3 = var1.method_73183();
         class_2338 var4 = class_2338.method_49637(var2.field_1323, var2.field_1322, var2.field_1321);
         class_2338 var5 = class_2338.method_49637(var2.field_1320, var2.field_1325, var2.field_1324);

         for(class_2338 var7 : class_2338.method_10097(var4, var5)) {
            class_2680 var8 = var3.method_8320(var7);
            if (!var8.method_26215()) {
               class_265 var9 = var8.method_26220(var3, var7);
               if (!var9.method_1110()) {
                  for(class_238 var11 : var9.method_1090()) {
                     if (var11.method_996(var7).method_994(var2)) {
                        return true;
                     }
                  }
               }
            }
         }

         return false;
      } else {
         return false;
      }
   }

   static {
      short var0 = 14604;
      String var1 = "崥巿嵮崿嵤嵱崬嵍嶂崚差崍됚듼둽됂둅둢됖둨뒽될듆둒듈든듑듟둿뒳뒱듃됆됣됔둼뒹됙됢둰뒔뒢됋됚둋듧됆됂둡둌됊둶듆둖듀둘뒯뒂뒄듬둰뒖뒈듀둸둱됍둛듆됬둽둲듪뒄둉됪된듼둝되됐둛됯둫듬됆뒄됴ῊἽΆΰᾕᾯῈᾳὸῷὬᾂἋὊ\u1f46Ἁᾯ\u1f5cὠἢΐᾕᾚῒ";
      char[] var2 = "\fL\u0018".toCharArray();
      String[] var3 = new String[var2.length];
      byte var7 = -1;

      while(true) {
         int var4 = 0;
         int var5 = 0;
         char var6 = '\u0000';
         if (var7 == 0) {
            II = var3;
            Il = new Object[var3.length];
            return;
         }

         do {
            var6 = var2[var4];
            char[] var8 = var1.substring(var5, var5 + var6).toCharArray();
            int var9 = 0;

            do {
               byte var10000;
               switch (var9 % 6) {
                  case 0:
                  default:
                     var10000 = 54;
                     break;
                  case 1:
                     var10000 = 84;
                     break;
                  case 2:
                     var10000 = 125;
                     break;
                  case 3:
                     var10000 = 84;
                     break;
                  case 4:
                     var10000 = 45;
                     break;
                  case 5:
                     var10000 = 87;
               }

               byte var10 = var10000;
               var8[var9] = (char)(var8[var9] ^ var10 ^ var0);
               ++var9;
            } while(var9 < var8.length);

            var3[var4] = (new String(var8)).intern();
            var5 += var6;
            ++var4;
         } while(var4 < var2.length);

         var7 = 0;
      }
   }

   private static String IIII(int var0, int var1) {
      int var3 = var0 ^ 463534602;
      char[] var4 = II[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])Il[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         Il[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -616520415;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 47;
               break;
            case 1:
               var9 = 147;
               break;
            case 2:
               var9 = 40;
               break;
            case 3:
               var9 = 118;
               break;
            case 4:
               var9 = 115;
               break;
            case 5:
               var9 = 47;
               break;
            case 6:
               var9 = 42;
               break;
            case 7:
               var9 = 20;
               break;
            case 8:
               var9 = 224;
               break;
            case 9:
               var9 = 71;
               break;
            case 10:
               var9 = 182;
               break;
            case 11:
               var9 = 47;
               break;
            case 12:
               var9 = 206;
               break;
            case 13:
               var9 = 242;
               break;
            case 14:
               var9 = 170;
               break;
            case 15:
               var9 = 171;
               break;
            case 16:
               var9 = 99;
               break;
            case 17:
               var9 = 229;
               break;
            case 18:
               var9 = 178;
               break;
            case 19:
               var9 = 128;
               break;
            case 20:
               var9 = 100;
               break;
            case 21:
               var9 = 48;
               break;
            case 22:
               var9 = 42;
               break;
            case 23:
               var9 = 24;
               break;
            case 24:
               var9 = 165;
               break;
            case 25:
               var9 = 102;
               break;
            case 26:
               var9 = 74;
               break;
            case 27:
               var9 = 7;
               break;
            case 28:
               var9 = 158;
               break;
            case 29:
               var9 = 236;
               break;
            case 30:
               var9 = 1;
               break;
            case 31:
               var9 = 95;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
