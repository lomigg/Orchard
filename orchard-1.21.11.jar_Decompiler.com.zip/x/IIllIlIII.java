package x;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class IIllIlIII extends llllllI<Color> {
   private static String[] I;
   private static final Color l;
   private static final int[] II;
   private static final String[] Il;
   private static final Object[] lII;

   public IIllIlIII(String var1, Color var2) {
      this((Object)var1, var2);
   }

   public IIllIlIII(Object var1, Color var2) {
      super((Object)var1, var2 == null ? l : var2);
   }

   public JsonElement lI() {
      Color var1 = (Color)this.III();
      Color var2 = var1 == null ? (Color)this.l() : var1;
      if (var2 == null) {
         var2 = l;
      }

      JsonObject var3 = new JsonObject();
      var3.addProperty(lIlIII.Il(I[2]), var2.getRed());
      var3.addProperty(lIlIII.Il(I[0]), var2.getGreen());
      var3.addProperty(lIlIII.Il(I[3]), var2.getBlue());
      var3.addProperty(lIlIII.Il(I[1]), var2.getAlpha());
      return var3;
   }

   static {
      short var6 = 23088;
      String var7 = "䋮ꫣ굱\u0ff4涤㼜붕\udbb1\ue511懳ﺮ줒\ue8e8㲺伭轑";
      char[] var8 = "娴娴娴娴".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            Il = var9;
            lII = new Object[var9.length];
            int var2 = -430032344;
            byte[] var0 = "\t1¢Dqæ\u0000\u0017\u001d*v°ì\u0099\u001b\u0095\u0014\u009c0\u0090ýÏ\u009d¢¦\u000b¨\u0097\t~ì\bwÞÔMD£6\u0011".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            II = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               II[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            I = new String[4];
            ll();
            l = new Color(Ill(-1514032496, 1252928003), Ill(-1514032495, 846825553), Ill(-1514032494, 1588985589), Ill(-1514032493, -1358523439));
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 111;
                     break;
                  case 1:
                     var10000 = 107;
                     break;
                  case 2:
                     var10000 = 116;
                     break;
                  case 3:
                     var10000 = 83;
                     break;
                  case 4:
                     var10000 = 28;
                     break;
                  case 5:
                     var10000 = 42;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static String I(char[] var0, long var1, int var3) {
      int var4 = Ill(-1514032492, -398331090) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & Ill(-1514032491, -1102047776);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private static void ll() {
      I[0] = I(lII(-32705214, 586963003).toCharArray(), 85701L, Ill(-1514032490, 2147379475));
      I[1] = I(lII(-32705213, -1663482841).toCharArray(), 17625L, Ill(-1514032489, 956517790));
      I[2] = I(lII(-32705216, -1480698524).toCharArray(), 58424L, Ill(-1514032488, -2031440925));
      I[3] = I(lII(-32705215, -1669247710).toCharArray(), 30153L, Ill(-1514032487, 983402926));
   }

   public void IlI(Color var1) {
      Color var2 = (Color)this.l();
      super.Il(var1 == null ? (var2 == null ? l : var2) : var1);
   }

   public void II(JsonElement var1) {
      if (var1 != null && var1.isJsonObject()) {
         JsonObject var2 = var1.getAsJsonObject();
         this.IlI(new Color(var2.get(lIlIII.Il(I[2])).getAsInt(), var2.get(lIlIII.Il(I[0])).getAsInt(), var2.get(lIlIII.Il(I[3])).getAsInt(), var2.get(lIlIII.Il(I[1])).getAsInt()));
      }
   }

   private static int Ill(int var0, int var1) {
      return II[var0 ^ -1514032496] ^ var1 ^ var0;
   }

   private static String lII(int var0, int var1) {
      int var3 = var0 ^ -32705214;
      char[] var4 = Il[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])lII[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         lII[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -69561581;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 146;
               break;
            case 1:
               var9 = 61;
               break;
            case 2:
               var9 = 158;
               break;
            case 3:
               var9 = 120;
               break;
            case 4:
               var9 = 106;
               break;
            case 5:
               var9 = 111;
               break;
            case 6:
               var9 = 44;
               break;
            case 7:
               var9 = 87;
               break;
            case 8:
               var9 = 245;
               break;
            case 9:
               var9 = 193;
               break;
            case 10:
               var9 = 169;
               break;
            case 11:
               var9 = 197;
               break;
            case 12:
               var9 = 247;
               break;
            case 13:
               var9 = 252;
               break;
            case 14:
               var9 = 151;
               break;
            case 15:
               var9 = 239;
               break;
            case 16:
               var9 = 3;
               break;
            case 17:
               var9 = 1;
               break;
            case 18:
               var9 = 255;
               break;
            case 19:
               var9 = 86;
               break;
            case 20:
               var9 = 252;
               break;
            case 21:
               var9 = 188;
               break;
            case 22:
               var9 = 3;
               break;
            case 23:
               var9 = 149;
               break;
            case 24:
               var9 = 223;
               break;
            case 25:
               var9 = 193;
               break;
            case 26:
               var9 = 208;
               break;
            case 27:
               var9 = 215;
               break;
            case 28:
               var9 = 37;
               break;
            case 29:
               var9 = 106;
               break;
            case 30:
               var9 = 197;
               break;
            case 31:
               var9 = 12;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
