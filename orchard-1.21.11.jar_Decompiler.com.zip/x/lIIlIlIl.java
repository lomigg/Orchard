package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1294;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import y.IIlIl;

@Environment(EnvType.CLIENT)
public final class lIIlIlIl extends IIIIIIIlI {
   private boolean I;
   private final IlIIIlIlI<<undefinedtype>> l;
   private boolean II;
   private boolean Il;
   private final lIIIIl lI;
   private static String[] III;
   private static final double IIl = 0.09;
   private static final float IlI = 45.0F;
   private static final double Ill = 1.0E-4;
   private static final double lII = 1.0E-5;
   private boolean lIl;
   private static final int[] ll;
   private static final String[] llI;
   private static final Object[] lll;

   private static String ll(char[] var0, long var1, int var3) {
      int var4 = IIIII(-223508937, -1340041520) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IIIII(-223508938, -124568207);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private void IlI(class_310 var1) {
      boolean var2 = var1.field_1724.method_24828();
      double var3 = var1.field_1724.method_18798().field_1351;
      if (var2) {
         this.lIl = false;
         this.I = false;
         this.II = true;
      } else {
         if (this.II && var3 > 0.09 && this.IlII(var1)) {
            this.lIl = true;
         }

         this.II = false;
         if (this.lIl && !this.I && !IllllIlI.ll(var1.field_1724) && !(var3 < 1.0E-4) && !(var3 > 0.09)) {
            double var5 = this.Illl(var1);
            if (!Double.isNaN(var5)) {
               float var7 = class_3532.method_15393((float)Math.toDegrees(var5) + 45.0F);
               IlIlIl.IIIlIl(var1, IIIII(-223508939, -1272786745), var7, var1.field_1724.method_36455(), () -> {
                  this.I = true;
                  return true;
               });
            }
         }
      }
   }

   private static void llI() {
      III[0] = ll(IIIIl(-2096857292, '⼒', (short)'\uf2fa').toCharArray(), 8657L, IIIII(-223508940, 456013401));
      III[1] = ll(IIIIl(1767064461, '⼓', (short)'썕').toCharArray(), 26597L, IIIII(-223508941, -433838858));
      III[2] = ll(IIIIl(1461539730, '⼐', (short)'녨').toCharArray(), 36786L, IIIII(-223508942, -1652671351));
      III[3] = ll(IIIIl(343372154, '⼑', (short)'묁').toCharArray(), 65513L, IIIII(-223508943, 1106662435));
   }

   private int lll(class_310 var1) {
      if (var1 != null && var1.field_1690 != null) {
         int var2 = 0;
         if (var1.field_1690.field_1894.method_1434()) {
            ++var2;
         }

         if (var1.field_1690.field_1881.method_1434()) {
            ++var2;
         }

         if (var1.field_1690.field_1913.method_1434()) {
            ++var2;
         }

         if (var1.field_1690.field_1849.method_1434()) {
            ++var2;
         }

         return var2;
      } else {
         return 0;
      }
   }

   static {
      short var6 = 19680;
      String var7 = "岼ᯯ堆\ud890慮肶綥ߴ缣觕㸰䗏휈\ue95b\ue40e몜틲弘횥灠퐓俕\uead3\uea5b湹ꑻ튭\ueaf0佰\uef1c\udae9᪺㮹呫쥣\ue45a鑍拍\u2d76\ufde1ु拴贼⋔\u1aaf\u0db2ᓽ嶕ᬸὦ컪悪侀ꌗ櫻ധ礥톶睌偿\ue0ff诬褌Ȗʑ聍뗣ﰑ\ue6b6맾䖾ᘔ⾮澐귐\ue44b㮔燋䀺砠惋肔퉿᫊㺳閞荴忏柿嘤侁㓘\ueca5趻꺭崪β檡녣ચ䒟翏횶튝♅㰳政딑ʪ鶏㞭\ue21e䮲骦茚畟롮痨咑윸酛⾋\uf72b\u0d80쯀\uf241ꭥ撋㋪ᗞ쿐巪";
      char[] var8 = "䳴䳨䲸䳰".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            llI = var9;
            lll = new Object[var9.length];
            int var2 = 1466837777;
            byte[] var0 = "P\u0088ãö]P\u0090©\u0011á}ÑK\u0092)-Íxþª\u0080@<µ,ÇÙ\u0018ÓßW\u0005".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            ll = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               ll[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            III = new String[4];
            llI();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private boolean IIII(class_310 var1) {
      return this.IIll(var1) && var1.field_1724.method_7344().method_7586() >= IIIII(-223508944, 1981610530) && !var1.field_1724.method_6059(class_1294.field_5919);
   }

   private boolean IIll(class_310 var1) {
      return var1 != null && var1.field_1724 != null && var1.field_1690 != null && var1.method_1562() != null && var1.field_1724.method_5805() && !var1.field_1724.method_5715() && !var1.field_1724.method_6115() && !var1.field_1724.method_5799() && !var1.field_1724.method_5771() && !var1.field_1724.method_6101();
   }

   private boolean IlII(class_310 var1) {
      return this.lll(var1) > 0;
   }

   public void lIl() {
      this.lIII();
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (var1.field_1724 != null && var1.field_1690 != null && var1.method_1562() != null) {
         if ((Boolean)this.lI.III()) {
            ((IIlIl)var1.field_1724).ilovcats$setJumpingCooldown(0);
         }

         if (this.IIll(var1) && this.l.III() == null.l) {
            this.lllI(var1);
            this.IlI(var1);
         } else {
            this.Il = false;
            this.lIl = false;
            this.I = false;
            this.II = var1.field_1724.method_24828();
         }
      } else {
         this.lIII();
      }
   }

   public boolean IlIl(class_310 var1) {
      if (this.IIIIIlI() && this.l.III() == null.II) {
         if (var1 != null && var1.field_1724 != null && var1.field_1690 != null) {
            return var1.field_1724.method_24828() && this.IlII(var1) && this.IIII(var1);
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private double Illl(class_310 var1) {
      float var2 = 0.0F;
      if (var1.field_1690.field_1894.method_1434()) {
         ++var2;
      }

      if (var1.field_1690.field_1881.method_1434()) {
         --var2;
      }

      float var3 = 0.0F;
      if (var1.field_1690.field_1913.method_1434()) {
         ++var3;
      }

      if (var1.field_1690.field_1849.method_1434()) {
         --var3;
      }

      if (var2 == 0.0F && var3 == 0.0F) {
         return Double.NaN;
      } else {
         float var4 = var1.field_1724.method_36454();
         if (var2 < 0.0F) {
            var4 += 180.0F;
         }

         float var5 = 1.0F;
         if (var2 < 0.0F) {
            var5 = -0.5F;
         } else if (var2 > 0.0F) {
            var5 = 0.5F;
         }

         if (var3 > 0.0F) {
            var4 -= 90.0F * var5;
         }

         if (var3 < 0.0F) {
            var4 += 90.0F * var5;
         }

         return Math.toRadians((double)var4);
      }
   }

   private void lIII() {
      this.Il = false;
      this.lIl = false;
      this.I = false;
      this.II = false;
   }

   public void IllI(class_310 var1) {
   }

   public boolean lIIl(class_310 var1) {
      if (this.IIIIIlI() && this.l.III() == null.II) {
         if (var1 != null && var1.field_1724 != null && var1.field_1690 != null) {
            return var1.field_1690.field_1894.method_1434() && this.IIII(var1);
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public lIIlIlIl() {
      super((Object)lIlIII.l(III[1]), lIllII.III, (Object)lIlIII.l(III[2]));
      this.l = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(III[3]), <undefinedtype>.class, null.l));
      this.lI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(III[0]), true));
   }

   public void lI() {
      this.lIII();
   }

   private void llII(class_310 var1, double var2) {
      if (var1 != null && var1.field_1724 != null && var1.field_1690 != null && var2 != (double)0.0F) {
         double var4 = this.Illl(var1);
         if (!Double.isNaN(var4)) {
            var1.field_1724.method_18799(var1.field_1724.method_18798().method_1031(-Math.sin(var4) * var2, (double)0.0F, Math.cos(var4) * var2));
         }
      }
   }

   private void lllI(class_310 var1) {
      if (var1.field_1690.field_1903.method_1434() && var1.field_1724.method_24828()) {
         if (!this.Il && this.IlII(var1)) {
            this.llII(var1, 1.0E-5);
            this.Il = true;
         }
      } else {
         this.Il = false;
      }
   }

   private static int IIIII(int var0, int var1) {
      return ll[var0 ^ -223508937] ^ var1 ^ var0;
   }

   private static String IIIIl(int var0, char var1, short var2) {
      int var3 = var1 ^ 12050;
      char[] var4 = llI[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])lll[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         lll[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 17294;
      int var9 = 0;

      do {
         int var10 = var4[var9] - 31266;
         var10 -= 28250;
         var10 += 48642;
         var10 += 32048;
         var4[var9] = (char)(var10 ^ var8 ^ var2 ^ var0 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
