package x;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
final class IIlIlIlIl {
   private final List<String> I;
   private final List<<undefinedtype>> l;
   private static String[] II;
   static final IIlIlIlIl Il;
   private static final Pattern lI;
   private static final int[] ll;
   private static final String[] III;
   private static final Object[] IIl;

   private static List<<undefinedtype>> I(String var0) {
      if (var0 != null && !var0.isBlank()) {
         ArrayList var1 = new ArrayList();

         for(String var5 : var0.split(lIlIII.Il(II[1]))) {
            Matcher var6 = lI.matcher(var5);
            ArrayList var7 = new ArrayList();

            int var8;
            for(var8 = 0; var6.find(); var8 = var6.end()) {
               long var9 = Il(var6.group(1));
               long var11 = Il(var6.group(2));
               long var13 = II(var6.group(3));
               var7.add(Math.max(0L, var9 * 60000L + var11 * 1000L + var13));
            }

            String var15 = var5.substring(Math.min(var8, var5.length())).trim();
            if (!var7.isEmpty() && !var15.isEmpty()) {
               for(long var16 : var7) {
                  var1.add(new Record(var16, var15) {
                     private final long I;
                     private final String l;

                     private {
                        this.I = var1;
                        this.l = var3;
                     }

                     public String I() {
                        return this.l;
                     }

                     public long l() {
                        return this.I;
                     }
                  });
               }
            }
         }

         var1.sort(Comparator.comparingLong(<undefinedtype>::l));
         return var1;
      } else {
         return List.of();
      }
   }

   private static List<String> l(String var0) {
      if (var0 != null && !var0.isBlank()) {
         ArrayList var1 = new ArrayList();

         for(String var5 : var0.split(lIlIII.Il(II[1]))) {
            String var6 = var5.trim();
            if (!var6.isEmpty()) {
               var1.add(var6);
            }
         }

         return var1;
      } else {
         return List.of();
      }
   }

   private static long II(String var0) {
      if (var0 != null && !var0.isEmpty()) {
         long var1 = Il(var0);
         long var10000;
         switch (var0.length()) {
            case 1 -> var10000 = var1 * 100L;
            case 2 -> var10000 = var1 * 10L;
            default -> var10000 = var1;
         }

         return var10000;
      } else {
         return 0L;
      }
   }

   private static long Il(String var0) {
      try {
         return Long.parseLong(var0);
      } catch (NumberFormatException var2) {
         return 0L;
      }
   }

   private static String lI(char[] var0, long var1, int var3) {
      int var4 = Ill(-1723052530, -28748822) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & Ill(-1723052529, -764677570);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   boolean ll() {
      return this.l.isEmpty() && this.I.isEmpty();
   }

   private IIlIlIlIl(List<<undefinedtype>> var1, List<String> var2) {
      this.l = List.copyOf(var1);
      this.I = List.copyOf(var2);
   }

   String III(long var1, long var3) {
      long var5 = Math.max(0L, var1);
      if (!this.l.isEmpty()) {
         int var11 = 0;
         int var8 = this.l.size() - 1;
         int var12 = -1;

         while(var11 <= var8) {
            int var10 = var11 + var8 >>> 1;
            if (((<undefinedtype>)this.l.get(var10)).l() <= var5) {
               var12 = var10;
               var11 = var10 + 1;
            } else {
               var8 = var10 - 1;
            }
         }

         return var12 < 0 ? II[0] : ((<undefinedtype>)this.l.get(var12)).I();
      } else if (this.I.isEmpty()) {
         return II[0];
      } else if (var3 <= 0L) {
         return (String)this.I.get(0);
      } else {
         double var7 = Math.max((double)0.0F, Math.min((double)1.0F, (double)var5 / (double)var3));
         int var9 = Math.min(this.I.size() - 1, (int)Math.floor(var7 * (double)this.I.size()));
         return (String)this.I.get(var9);
      }
   }

   static {
      short var6 = 23673;
      String var7 = "䁎ⳏ蚣昚뜹돀㇚풭\uf0f8ᑭⲕ鑯\ud910\ued9a裦ㇿ䛈嬪눯ủ\u0b98⏄텁쇎㤅鞿获蓡쮰뼌䔣曝ꔅ풋ꪤ訌\ue9d3ﳾ蒈くⶉዂ쉖鼈泓壈㿡뷴육∵ꡯ큨ꥒ\ue2ca秀⺽";
      char[] var8 = "屽屍".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            III = var9;
            IIl = new Object[var9.length];
            int var2 = -1588111326;
            byte[] var0 = "ÔéÞlêpäìW½&× ¶7bÎ(rá".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            ll = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               ll[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            II = new String[3];
            IIl();
            lI = Pattern.compile(lIlIII.Il(II[2]));
            Il = new IIlIlIlIl(List.of(), List.of());
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 98;
                     break;
                  case 1:
                     var10000 = 75;
                     break;
                  case 2:
                     var10000 = 102;
                     break;
                  case 3:
                     var10000 = 64;
                     break;
                  case 4:
                     var10000 = 108;
                     break;
                  case 5:
                     var10000 = 13;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static void IIl() {
      II[0] = lI("".toCharArray(), 84112L, Ill(-1723052532, -1394292057));
      II[1] = lI(lII(-1997004560, 1564047649).toCharArray(), 97591L, Ill(-1723052531, 328301687));
      II[2] = lI(lII(-1997004559, 101733024).toCharArray(), 82207L, Ill(-1723052534, 637656930));
   }

   static IIlIlIlIl IlI(String var0, String var1) {
      List var2 = I(var0);
      List var3 = l(var1);
      return var2.isEmpty() && var3.isEmpty() ? Il : new IIlIlIlIl(var2, var3);
   }

   private static int Ill(int var0, int var1) {
      return ll[var0 ^ -1723052530] ^ var1 ^ var0;
   }

   private static String lII(int var0, int var1) {
      int var3 = var0 ^ -1997004560;
      char[] var4 = III[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IIl[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IIl[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 485085946;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 181;
               break;
            case 1:
               var9 = 153;
               break;
            case 2:
               var9 = 75;
               break;
            case 3:
               var9 = 225;
               break;
            case 4:
               var9 = 83;
               break;
            case 5:
               var9 = 235;
               break;
            case 6:
               var9 = 61;
               break;
            case 7:
               var9 = 58;
               break;
            case 8:
               var9 = 117;
               break;
            case 9:
               var9 = 219;
               break;
            case 10:
               var9 = 236;
               break;
            case 11:
               var9 = 148;
               break;
            case 12:
               var9 = 92;
               break;
            case 13:
               var9 = 132;
               break;
            case 14:
               var9 = 3;
               break;
            case 15:
               var9 = 192;
               break;
            case 16:
               var9 = 158;
               break;
            case 17:
               var9 = 95;
               break;
            case 18:
               var9 = 119;
               break;
            case 19:
               var9 = 55;
               break;
            case 20:
               var9 = 177;
               break;
            case 21:
               var9 = 135;
               break;
            case 22:
               var9 = 48;
               break;
            case 23:
               var9 = 29;
               break;
            case 24:
               var9 = 202;
               break;
            case 25:
               var9 = 52;
               break;
            case 26:
               var9 = 229;
               break;
            case 27:
               var9 = 41;
               break;
            case 28:
               var9 = 127;
               break;
            case 29:
               var9 = 162;
               break;
            case 30:
               var9 = 1;
               break;
            case 31:
               var9 = 103;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
