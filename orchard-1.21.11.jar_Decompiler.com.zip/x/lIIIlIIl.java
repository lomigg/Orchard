package x;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.ref.WeakReference;
import java.nio.charset.StandardCharsets;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3298;
import net.minecraft.class_332;

@Environment(EnvType.CLIENT)
final class lIIIlIIl {
   private static volatile <undefinedtype> I;
   private static final <undefinedtype> l;
   private static final <undefinedtype> II;
   private static final Map<Long, WeakReference<<undefinedtype>>> Il;
   private static final double lI = (double)11.0F;
   private static final double ll = (double)9.0F;
   private static final <undefinedtype> III;
   private static final float IIl = 12.0F;
   private static final Map<<undefinedtype>, WeakReference<<undefinedtype>>> IlI;
   private static volatile <undefinedtype> Ill;
   private static final <undefinedtype> lII;
   private static final <undefinedtype> lIl;
   private static final int[] llI;
   private static final String[] lll;
   private static final Object[] IIII;

   static int I(Object var0, String var1) {
      return llI(l(var0), var1);
   }

   private static <undefinedtype> l(Object var0) {
      if (var0 != null && !var0.ll()) {
         long var1 = var0.lll();
         synchronized(Il) {
            WeakReference var4 = (WeakReference)Il.get(var1);
            <undefinedtype> var5 = var4 == null ? null : (<undefinedtype>)var4.get();
            if (var5 != null) {
               return var5;
            } else {
               <undefinedtype> var6 = lll(var0);
               if (var6 == null) {
                  Il.remove(var1);
                  return null;
               } else {
                  Il.put(var1, new WeakReference(var6));
                  return var6;
               }
            }
         }
      } else {
         return null;
      }
   }

   private static boolean II(Object var0, class_332 var1, String var2, double var3, double var5, int var7, boolean var8, boolean var9) {
      if (var0 == null) {
         return false;
      } else {
         String var10 = var2 == null ? "" : var2;
         if (var8) {
            int var11 = (var7 >>> IlIl(770827058, -120882551) & IlIl(770827059, 1146733585)) << IlIl(770827056, -1657173184);
            IIII(var0, var1, var10, var3 + (double)1.0F, var5 + (double)1.0F + lII(var0), var11, false);
         }

         IIII(var0, var1, var10, var3, var5 + lII(var0), var7, var9);
         return true;
      }
   }

   static int Il(String var0) {
      <undefinedtype> var1 = III();
      return llI(var1, var0);
   }

   static boolean lI(Object var0, class_332 var1, String var2, double var3, double var5, int var7, boolean var8, boolean var9) {
      return II(l(var0), var1, var2, var3, var5, var7, var8, var9);
   }

   static boolean ll(class_332 var0, String var1, double var2, double var4, int var6, boolean var7, boolean var8) {
      <undefinedtype> var9 = III();
      return II(var9, var0, var1, var2, var4, var6, var7, var8);
   }

   private static <undefinedtype> III() {
      <undefinedtype> var0 = lIIIllll.lIIll();
      if (var0.II().ll()) {
         return null;
      } else if (I == var0 && Ill != null) {
         return Ill;
      } else {
         synchronized(IlI) {
            WeakReference var2 = (WeakReference)IlI.get(var0);
            <undefinedtype> var3 = var2 == null ? null : (<undefinedtype>)var2.get();
            if (var3 != null) {
               Ill = var3;
               I = var0;
               return var3;
            } else {
               <undefinedtype> var4 = IlI(var0);
               if (var4 != null) {
                  IlI.put(var0, new WeakReference(var4));
                  Ill = var4;
                  I = var0;
               } else {
                  IlI.remove(var0);
                  if (I == var0) {
                     Ill = null;
                     I = null;
                  }
               }

               return var4;
            }
         }
      }
   }

   static double IIl() {
      <undefinedtype> var0 = III();
      return var0 == null ? (double)-1.0F : (double)9.0F;
   }

   private static <undefinedtype> IlI(Object var0) {
      return lll(var0.II());
   }

   static boolean Ill() {
      return !lIIIllll.lIIll().II().ll();
   }

   private static double lII(Object var0) {
      double var1 = lIIlIll.llI((double)11.0F, var0.II, var0.Il, var0.lI);
      return ((double)9.0F - var1) * (double)0.5F;
   }

   static double lIl(String var0) {
      <undefinedtype> var1 = III();
      return IIlI(var1, var0);
   }

   static {
      short var6 = 29587;
      String var7 = "\uf353\uf326\uf3c9\uf365\uf324\uf3e1\uf31f\uf302\ue13d\ue134\ue1b7\ue101\ue15c\ue1be\ue119\ue112\ue144\ue169\ue17d\ue179⢱⣝⠔⣒⢛⡐⣿⢼撊擹摈擀撦摤撚撇㛑㛘㘯㛭㚦㙕㛋㛤㚲㚍㛆㛃㚂㘆㙔㘎㘚㚌㚧㚗\u0dfe෧൴ැඈ൹ෝ\u0df0\u07b2ߙܟޤᣳᣪ\u187dᣝᢀᡧᣭᢢ\udc7e\udc65\udcf5\udc49\udc08\udcd2\udc4c\udc46\udc1b\udc2f\udc3b\udc3f悔惦恮悵惧怔悧惂┅┉▉┐╳▾┴┫馛馐饧馌駪餋馭馥駸駯首馁駁饕饧餞ର\u0b29\u0b98ଟୀ\u0ba7ଥଈ\u0b53\u0b46\u0b7d୰ᓌᓅᑅᓰᒼᑲᓆᓹᒬᒪᓛᓴ\u086f࠙ࣈࡕ࡛ࠛ࣫ࡅ\ue5ed\ue5f0\ue556\ue5f9\ue599\ue557\ue5c1\ue5d2\ue589\ue59c\ue5ae\ue5aa꼜꼆꾒꼨꽯꾋꼉꼥꽿꽪꽘꽜弡弯征弄当很弬彸彈彵弱异彲忢徒御믲민뭒믗뮀뭛믿뮫뮛뮦믢믑뮡묱뭁뭲㸙㸀㺗㸷㹪㺍㸘㹄㹴㹉㸍㸾㹎㻞㺮㺝꺴꺭긺꺚껇긠꺵껩껙껤꺠꺓껣깳긃기下一亀丮乾于乆乛ݏݿ߷ݹܻ߈ݤ݂\udfc3\udff7\udf3a\udfe4\udfb6\udf43\udf86\udf96\uead0\ueadd\uea6f\ueae5\ue2d6\ue2dd\ue25d\ue2f3\ue2a3\ue253\ue29b\ue286䀔䀤䂬䀢䁠䂓䀿䀙쀅쀱샼쀢쁰삅쁀쁐魅魈鯺魰";
      char[] var8 = "玛玟玛玛率玛玗玛玟玛玛玃玟玟玛玟玟玃玃玃玃玛玛玛玗玛玛玛玗".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            lll = var9;
            IIII = new Object[var9.length];
            int var2 = -443544766;
            byte[] var0 = "0ª\u0092á\u008c8,\u009fUXc*ª@\u0016Úd*\u0013ØJ@\u000e\nv\u008d£Ê©¯<Ç".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            llI = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               llI[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            lIl = lIlIII.l(IllI(-1122819938, 1840645510));
            III = lIlIII.l(IllI(-1122819937, 2145144380));
            lII = lIlIII.l(IllI(-1122819940, -1240985393));
            l = lIlIII.l(IllI(-1122819939, -97304632));
            II = lIlIII.l(IllI(-1122819942, -1472789562));
            IlI = new EnumMap(<undefinedtype>.class);
            Il = new HashMap();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static int llI(Object var0, String var1) {
      if (var0 == null) {
         return -1;
      } else {
         double var2 = (double)0.0F;
         String var4 = var1 == null ? "" : var1;

         int var6;
         for(int var5 = 0; var5 < var4.length(); var5 += Character.charCount(var6)) {
            var6 = var4.codePointAt(var5);
            <undefinedtype> var7 = (<undefinedtype>)var0.IIl.getOrDefault(var6, var0.ll);
            if (var7 != null) {
               var2 += var7.IIl * (double)11.0F;
            }
         }

         return (int)Math.ceil(var2);
      }
   }

   private static <undefinedtype> lll(Object var0) {
      class_2960 var1 = IlII(var0, lII);
      class_2960 var2 = IlII(var0, l);

      try {
         InputStream var3 = null;

         try {
            class_310 var4 = class_310.method_1551();
            if (var4 != null && var4.method_1478() != null) {
               class_3298 var5 = (class_3298)var4.method_1478().method_14486(var1).orElse((Object)null);
               if (var5 != null) {
                  var3 = var5.method_14482();
               }
            }
         } catch (Exception var34) {
         }

         if (var3 == null) {
            String var10000 = lIlIII.Il(IllI(-1122819941, 520908744));
            String var10001 = var1.method_12836();
            String var10002 = lIlIII.Il(IllI(-1122819944, 354179945));
            String var32 = var1.method_12832();
            String var31 = var10002;
            String var30 = var10001;
            String var29 = var10000;
            String var37 = var29 + var30 + var31 + var32;
            var3 = lIIIlIIl.class.getClassLoader().getResourceAsStream(var37);
         }

         if (var3 == null) {
            return null;
         } else {
            InputStreamReader var38 = new InputStreamReader(var3, StandardCharsets.UTF_8);

            Record var40;
            try {
               JsonObject var39 = JsonParser.parseReader(var38).getAsJsonObject();
               JsonObject var6 = var39.getAsJsonObject(lIlIII.Il(IllI(-1122819943, 167847941)));
               JsonObject var7 = var39.getAsJsonObject(lIlIII.Il(IllI(-1122819946, -829600668)));
               double var8 = var6.get(lIlIII.Il(IllI(-1122819945, 1918976262))).getAsDouble();
               double var10 = var6.get(lIlIII.Il(IllI(-1122819948, 938570723))).getAsDouble();
               float var12 = var6.has(II.lIlI()) ? var6.get(II.lIlI()).getAsFloat() : 12.0F;
               double var13 = var7.get(lIlIII.Il(IllI(-1122819947, -1956102622))).getAsDouble();
               double var15 = var7.get(lIlIII.Il(IllI(-1122819950, 432163278))).getAsDouble();
               double var17 = var7.get(lIlIII.Il(IllI(-1122819949, 104685484))).getAsDouble();
               HashMap var19 = new HashMap();

               for(JsonElement var22 : var39.getAsJsonArray(lIlIII.Il(IllI(-1122819952, 446587987)))) {
                  JsonObject var23 = var22.getAsJsonObject();
                  int var24 = var23.get(lIlIII.Il(IllI(-1122819951, -149394568))).getAsInt();
                  double var25 = var23.get(lIlIII.Il(IllI(-1122819954, -1108470618))).getAsDouble();
                  JsonObject var27 = var23.has(lIlIII.Il(IllI(-1122819953, 1305954222))) ? var23.getAsJsonObject(lIlIII.Il(IllI(-1122819956, -1459339526))) : null;
                  JsonObject var28 = var23.has(lIlIII.Il(IllI(-1122819955, 753612984))) ? var23.getAsJsonObject(lIlIII.Il(IllI(-1122819958, -1136258531))) : null;
                  var19.put(var24, IIll(var24, var25, var27, var28));
               }

               var40 = new Record(var2, var8, var10, var12, var13, var15, var17, var19, (<undefinedtype>)var19.get(IlIl(770827057, 1646395030))) {
                  private final class_2960 I;
                  private final float l;
                  private final double II;
                  private final double Il;
                  private final double lI;
                  private final <undefinedtype> ll;
                  private final double III;
                  private final Map<Integer, <undefinedtype>> IIl;
                  private final double IlI;

                  public class_2960 I() {
                     return this.I;
                  }

                  public Map<Integer, <undefinedtype>> l() {
                     return this.IIl;
                  }

                  public float II() {
                     return this.l;
                  }

                  public <undefinedtype> Il() {
                     return this.ll;
                  }

                  public double lI() {
                     return this.III;
                  }

                  public double ll() {
                     return this.Il;
                  }

                  private {
                     this.I = var1;
                     this.IlI = var2;
                     this.III = var4;
                     this.l = var6;
                     this.II = var7;
                     this.Il = var9;
                     this.lI = var11;
                     this.IIl = var13;
                     this.ll = var14;
                  }

                  public double III() {
                     return this.II;
                  }

                  public double IIl() {
                     return this.lI;
                  }

                  public double IlI() {
                     return this.IlI;
                  }
               };
            } catch (Throwable var35) {
               try {
                  var38.close();
               } catch (Throwable var33) {
                  var35.addSuppressed(var33);
               }

               throw var35;
            }

            var38.close();
            return var40;
         }
      } catch (Exception var36) {
         return null;
      }
   }

   private static void IIII(Object var0, class_332 var1, String var2, double var3, double var5, int var7, boolean var8) {
      if (var1 != null && !var2.isEmpty() && (var7 >>> IlIl(770827062, -1404306508) & IlIl(770827063, -2111707520)) > 0) {
         double var9 = var3;
         double var11 = var5 + lIIlIll.IlII((double)11.0F, var0.II, var0.Il, var0.lI);
         int var13 = 0;

         for(int var14 = 0; var14 < var2.length(); ++var13) {
            int var15 = var2.codePointAt(var14);
            <undefinedtype> var16 = (<undefinedtype>)var0.IIl.getOrDefault(var15, var0.ll);
            if (var16 != null) {
               if (var16.lI()) {
                  int var17 = var8 ? IIIIIIllI.lIIlI(var7 >>> IlIl(770827060, -1091810396) & IlIl(770827061, 1640944719), (int)Math.round(var3), (int)Math.round(var5), var13) : var7;
                  double var18 = var9 + var16.lI * (double)11.0F;
                  double var20 = var11 - var16.ll * (double)11.0F;
                  double var22 = (var16.Ill - var16.lI) * (double)11.0F;
                  double var24 = (var16.ll - var16.I) * (double)11.0F;
                  float var26 = (float)(var16.Il / var0.IlI);
                  float var27 = (float)((double)1.0F - var16.II / var0.III);
                  float var28 = (float)(var16.IlI / var0.IlI);
                  float var29 = (float)((double)1.0F - var16.III / var0.III);
                  IIIIIIllI.Illll(var1, var0.I, var18, var20, var22, var24, var26, var27, var28, var29, var17, var0.l);
               }

               var9 += var16.IIl * (double)11.0F;
            }

            var14 += Character.charCount(var15);
         }

      }
   }

   static void IIIl() {
      synchronized(IlI) {
         Ill = null;
         I = null;

         for(WeakReference var2 : IlI.values()) {
            if (var2 != null) {
               var2.clear();
            }
         }

         IlI.clear();
      }

      synchronized(Il) {
         for(WeakReference var8 : Il.values()) {
            if (var8 != null) {
               var8.clear();
            }
         }

         Il.clear();
      }
   }

   private static double IIlI(Object var0, String var1) {
      if (var0 == null) {
         return (double)-1.0F;
      } else {
         double var2 = (double)0.0F;
         String var4 = var1 == null ? "" : var1;

         int var6;
         for(int var5 = 0; var5 < var4.length(); var5 += Character.charCount(var6)) {
            var6 = var4.codePointAt(var5);
            <undefinedtype> var7 = (<undefinedtype>)var0.IIl.getOrDefault(var6, var0.ll);
            if (var7 != null) {
               var2 += var7.IIl * (double)11.0F;
            }
         }

         return var2;
      }
   }

   private static <undefinedtype> IIll(int var0, double var1, JsonObject var3, JsonObject var4) {
      return var3 != null && var4 != null ? new Record(var0, var1, var3.get(lIlIII.Il(IllI(-1122819957, 1557878774))).getAsDouble(), var3.get(lIlIII.Il(IllI(-1122819960, 362691351))).getAsDouble(), var3.get(lIlIII.Il(IllI(-1122819959, -854183238))).getAsDouble(), var3.get(lIlIII.Il(IllI(-1122819962, -133804349))).getAsDouble(), var4.get(lIlIII.Il(IllI(-1122819961, -268014573))).getAsDouble(), var4.get(lIlIII.Il(IllI(-1122819964, 1388662649))).getAsDouble(), var4.get(lIlIII.Il(IllI(-1122819963, -758105520))).getAsDouble(), var4.get(lIlIII.Il(IllI(-1122819966, -1986834067))).getAsDouble()) {
         private final double I;
         private final int l;
         private final double II;
         private final double Il;
         private final double lI;
         private final double ll;
         private final double III;
         private final double IIl;
         private final double IlI;
         private final double Ill;

         public double I() {
            return this.IlI;
         }

         public int l() {
            return this.l;
         }

         public double II() {
            return this.III;
         }

         public double Il() {
            return this.IIl;
         }

         boolean lI() {
            return this.Ill > this.lI && this.ll > this.I && this.IlI > this.Il && this.II > this.III;
         }

         public double ll() {
            return this.lI;
         }

         public double III() {
            return this.Il;
         }

         private {
            this.l = var1;
            this.IIl = var2;
            this.lI = var4;
            this.I = var6;
            this.Ill = var8;
            this.ll = var10;
            this.Il = var12;
            this.III = var14;
            this.IlI = var16;
            this.II = var18;
         }

         public double IIl() {
            return this.ll;
         }

         public double IlI() {
            return this.Ill;
         }

         public double Ill() {
            return this.II;
         }

         public double lII() {
            return this.I;
         }
      } : new Record(var0, var1, (double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F) {
         private final double I;
         private final int l;
         private final double II;
         private final double Il;
         private final double lI;
         private final double ll;
         private final double III;
         private final double IIl;
         private final double IlI;
         private final double Ill;

         public double I() {
            return this.IlI;
         }

         public int l() {
            return this.l;
         }

         public double II() {
            return this.III;
         }

         public double Il() {
            return this.IIl;
         }

         boolean lI() {
            return this.Ill > this.lI && this.ll > this.I && this.IlI > this.Il && this.II > this.III;
         }

         public double ll() {
            return this.lI;
         }

         public double III() {
            return this.Il;
         }

         private {
            this.l = var1;
            this.IIl = var2;
            this.lI = var4;
            this.I = var6;
            this.Ill = var8;
            this.ll = var10;
            this.Il = var12;
            this.III = var14;
            this.IlI = var16;
            this.II = var18;
         }

         public double IIl() {
            return this.ll;
         }

         public double IlI() {
            return this.Ill;
         }

         public double Ill() {
            return this.II;
         }

         public double lII() {
            return this.I;
         }
      };
   }

   private lIIIlIIl() {
   }

   private static class_2960 IlII(Object var0, Object var1) {
      return class_2960.method_60655(lIl.lIlI(), III.IIII(var0).IIII(var1).lIlI());
   }

   private static int IlIl(int var0, int var1) {
      return llI[var0 ^ 770827058] ^ var1 ^ var0;
   }

   private static String IllI(int var0, int var1) {
      int var3 = var0 ^ -1122819938;
      char[] var4 = lll[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IIII[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IIII[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 170295874;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 251;
               break;
            case 1:
               var9 = 214;
               break;
            case 2:
               var9 = 90;
               break;
            case 3:
               var9 = 225;
               break;
            case 4:
               var9 = 139;
               break;
            case 5:
               var9 = 83;
               break;
            case 6:
               var9 = 231;
               break;
            case 7:
               var9 = 250;
               break;
            case 8:
               var9 = 163;
               break;
            case 9:
               var9 = 177;
               break;
            case 10:
               var9 = 239;
               break;
            case 11:
               var9 = 235;
               break;
            case 12:
               var9 = 133;
               break;
            case 13:
               var9 = 24;
               break;
            case 14:
               var9 = 86;
               break;
            case 15:
               var9 = 47;
               break;
            case 16:
               var9 = 29;
               break;
            case 17:
               var9 = 175;
               break;
            case 18:
               var9 = 222;
               break;
            case 19:
               var9 = 238;
               break;
            case 20:
               var9 = 47;
               break;
            case 21:
               var9 = 187;
               break;
            case 22:
               var9 = 193;
               break;
            case 23:
               var9 = 8;
               break;
            case 24:
               var9 = 19;
               break;
            case 25:
               var9 = 60;
               break;
            case 26:
               var9 = 86;
               break;
            case 27:
               var9 = 92;
               break;
            case 28:
               var9 = 153;
               break;
            case 29:
               var9 = 99;
               break;
            case 30:
               var9 = 174;
               break;
            case 31:
               var9 = 78;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
