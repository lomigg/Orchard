package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1799;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_742;
import net.minecraft.class_7833;

@Environment(EnvType.CLIENT)
public final class IIIlllIll {
   private IIIlllIll() {
   }

   public static IlIIlIlll I() {
      lIllIIl var0 = lIllIIl.Il();
      return var0 == null ? null : var0.IIl().IlIllI();
   }

   public static boolean l(class_1268 var0) {
      IlIIlIlll var1 = I();
      return var1 != null && var1.lIIl() && var1.IIIIl(var0) != null.Il;
   }

   private static class_1306 II(class_742 var0, class_1268 var1) {
      return var1 == class_1268.field_5808 ? var0.method_6068() : var0.method_6068().method_5928();
   }

   public static boolean Il(class_742 var0, class_1268 var1) {
      IlIIlIlll var2 = I();
      if (var2 != null && var2.lIIl() && !var2.IIlll()) {
         return II(var0, var1) != class_1306.field_6182;
      } else {
         return true;
      }
   }

   public static void lI(class_742 var0, class_1268 var1, class_1799 var2, float var3, float var4, class_4587 var5) {
      IlIIlIlll var6 = I();
      if (var6 != null && var6.lIIl() && !var2.method_7960() && Il(var0, var1)) {
         class_1306 var7 = II(var0, var1);
         float var8 = var7 == class_1306.field_6183 ? 1.0F : -1.0F;
         class_1268 var9 = var0.field_6266 != null ? var0.field_6266 : class_1268.field_5808;
         float var10 = var9 == var1 ? var4 : 0.0F;
         float var11 = var0.field_6252 && var9 == var1 ? Math.max(0.0F, var0.method_6055(var3)) : 0.0F;
         float var12 = Math.max(0.0F, Math.max(var10, var11));
         <undefinedtype> var13 = var6.llII(var1);
         float var14 = var13.llI(var12);
         float var15 = class_3532.method_15374((double)(var12 * var12 * (float)Math.PI));
         float var16 = 1.0F;
         float var17 = var13.IlI();
         if (!var6.IIIII() && var7 == class_1306.field_6182) {
            var17 = -var17;
         }

         var5.method_46416(var17, var13.I(), var13.lIl());
         float var18 = var13.lII();
         switch (var13.IlII()) {
            case II:
               var5.method_46416(-0.14142136F * var8 - 0.05F * var8 * var14 * var18, 0.08F + 0.06F * var14 * var18, 0.14142136F - 0.09F * var15 * var18);
               var5.method_22907(class_7833.field_40714.rotationDegrees(-102.25F - 80.0F * var14 * var18));
               var5.method_22907(class_7833.field_40716.rotationDegrees(13.365F * var8 - 20.0F * var8 * var15 * var18));
               var5.method_22907(class_7833.field_40718.rotationDegrees(78.05F * var8 - 20.0F * var8 * var14 * var18));
               break;
            case Il:
               var5.method_22907(class_7833.field_40716.rotationDegrees(var6.IIII(var1)));
            case ll:
         }

         switch (null.l[var13.IIll().ordinal()]) {
            case 1:
               float var27 = var14 * var18;
               var5.method_46416(-0.14F * var8 * var27, 0.06F * var27, -0.08F * var27);
               var5.method_22907(class_7833.field_40716.rotationDegrees(var8 * (45.0F - 24.0F * var15 * var18)));
               var5.method_22907(class_7833.field_40718.rotationDegrees(var8 * -18.0F * var27));
               var5.method_22907(class_7833.field_40714.rotationDegrees(-72.0F * var27));
               var5.method_22907(class_7833.field_40716.rotationDegrees(var8 * -45.0F));
               break;
            case 2:
               float var26 = var14 * var18;
               var5.method_46416(0.0F, 0.035F * var26, -0.06F * var26);
               var5.method_22907(class_7833.field_40714.rotationDegrees(-58.0F * var26));
               break;
            case 3:
               float var25 = var13.ll(var12);
               var5.method_22907(class_7833.field_40714.rotationDegrees(var25 * 360.0F * var18 * var8));
               break;
            case 4:
               float var24 = 1.0F - var14 * 0.16F * var18;
               var16 = class_3532.method_15363(var24, 0.72F, 1.25F);
               break;
            case 5:
               var5.method_46416(0.0F, -var14 * 0.02F * var18, -var14 * 0.42F * var18);
               var5.method_22907(class_7833.field_40714.rotationDegrees(-22.0F * var14 * var18));
               break;
            case 6:
               float var19 = var14 * var18;
               var5.method_22907(class_7833.field_40714.rotationDegrees(var13.IIlI() * var19));
               var5.method_22907(class_7833.field_40716.rotationDegrees(var13.II() * var19 * var8));
               var5.method_22907(class_7833.field_40718.rotationDegrees(var13.Il() * var19 * var8));
            case 7:
         }

         float var28 = var13.IIIl();
         if (var28 != 0.0F) {
            var5.method_22907(class_7833.field_40714.rotationDegrees(var28));
         }

         float var20 = var13.IIII();
         if (var20 != 0.0F) {
            var5.method_22907(class_7833.field_40716.rotationDegrees(var20));
         }

         float var21 = var13.lll();
         if (var21 != 0.0F) {
            var5.method_22907(class_7833.field_40718.rotationDegrees(var21));
         }

         float var22 = var13.lI();
         if (var22 != 0.0F) {
            var5.method_22907(class_7833.field_40718.rotationDegrees(var22 * var8));
         }

         float var23 = var13.l() * var16;
         var5.method_22905(var23, var23, var23);
      }
   }
}
