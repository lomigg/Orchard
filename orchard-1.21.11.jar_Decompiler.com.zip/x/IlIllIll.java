package x;

import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Stream;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1011;
import net.minecraft.class_2960;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Environment(EnvType.CLIENT)
public final class IlIllIll {
   private static final <undefinedtype> I;
   private static final <undefinedtype> l;
   private static final <undefinedtype> II;
   private static volatile WeakReference<<undefinedtype>> Il;
   private static final float lI = 6.0F;
   private static final float ll = 8.0F;
   private static final <undefinedtype> III;
   private static final <undefinedtype> IIl;
   private static final <undefinedtype> IlI;
   private static final Logger Ill;
   private static final <undefinedtype> lII;
   private static final int[] lIl;
   private static final String[] llI;
   private static final Object[] lll;

   private static List<<undefinedtype>> I() {
      ArrayList var0 = new ArrayList();
      <undefinedtype>[] var10000 = new <undefinedtype>[IlII(1299998402, 632960338)];
      var10000[0] = lIlIII.l(IlIl('鐊', 44855, 408178134));
      var10000[1] = lIlIII.l(IlIl('ךּ', 44854, 7947324));
      var10000[2] = lIlIII.l(IlIl('愈', 44853, 423306631));
      var10000[3] = lIlIII.l(IlIl('\ua8df', 44852, 1424321122));
      var10000[4] = lIlIII.l(IlIl('캘', 44851, 137394745));
      var10000[5] = lIlIII.l(IlIl('\ue0d6', 44850, 1213942669));
      var10000[IlII(1299998403, -1536304032)] = lIlIII.l(IlIl('᳞', 44849, 375869577));
      var10000[IlII(1299998400, -640104229)] = lIlIII.l(IlIl('袾', 44848, -1613925805));
      var10000[IlII(1299998401, 451446393)] = lIlIII.l(IlIl('媥', 44863, 1329928165));
      var10000[IlII(1299998406, 1353461176)] = lIlIII.l(IlIl('숹', 44862, -1091555233));
      var10000[IlII(1299998407, -1801049197)] = lIlIII.l(IlIl('겢', 44861, -266767405));
      var10000[IlII(1299998404, 336810438)] = lIlIII.l(IlIl('촗', 44860, -689755707));
      var10000[IlII(1299998405, -1266171379)] = lIlIII.l(IlIl('沶', 44859, 1138830298));
      var10000[IlII(1299998410, 862152451)] = lIlIII.l(IlIl('\ue2d3', 44858, -1560990035));
      var10000[IlII(1299998411, -1309218934)] = lIlIII.l(IlIl('뼏', 44857, -1833551771));
      var10000[IlII(1299998408, 819887875)] = lIlIII.l(IlIl('嘢', 44856, -1755770417));
      var10000[IlII(1299998409, 1547941961)] = lIlIII.l(IlIl('큓', 44839, 2018533982));
      var10000[IlII(1299998414, 1717775157)] = lIlIII.l(IlIl('풽', 44838, -142838614));
      var10000[IlII(1299998415, 751960655)] = lIlIII.l(IlIl('ⱏ', 44837, 1904744345));

      for(<undefinedtype> var3 : List.of(var10000)) {
         String var4 = var3.lIlI();
         String var18 = I.lIlI();
         String var11 = lIlIII.Il(IlIl('ᝊ', 44836, -1328320876));
         String var10 = var18;
         String var5 = var10 + var11 + var4;

         try {
            InputStream var6 = IlIllIll.class.getClassLoader().getResourceAsStream(var5);

            label90: {
               label89: {
                  try {
                     if (var6 != null) {
                        class_1011 var7 = class_1011.method_4309(var6);

                        label102: {
                           try {
                              if (var7 != null && var7.method_4307() > 0 && var7.method_4323() > 0) {
                                 String var8 = var4.substring(0, var4.length() - 4);
                                 var0.add(new Object(var8, IIIl(var8), lII.IIII(lIlIII.III(var4)), var7.method_4307(), var7.method_4323(), III(var7.method_4307(), var7.method_4323(), 8.0F), 8.0F, III(var7.method_4307(), var7.method_4323(), 6.0F), 6.0F) {
                                    private final <undefinedtype> I;
                                    private final int l;
                                    private final <undefinedtype> II;
                                    private final float Il;
                                    private final float lI;
                                    private final float ll;
                                    private final <undefinedtype> III;
                                    private final int IIl;
                                    private final float IlI;

                                    private {
                                       this.I = lIlIII.III(var1);
                                       this.III = lIlIII.III(var2);
                                       this.II = var3 == null ? lIlIII.III("") : var3;
                                       this.IIl = var4;
                                       this.l = var5;
                                       this.ll = var6;
                                       this.IlI = var7;
                                       this.lI = var8;
                                       this.Il = var9;
                                    }

                                    public float I(float var1) {
                                       return var1 * ((float)this.IIl / (float)this.l);
                                    }

                                    public String l() {
                                       return this.I.lIlI();
                                    }

                                    private <undefinedtype> II(String var1) {
                                       return (<undefinedtype>)(new <anonymous constructor>(this.l(), var1, this.II, this.IIl, this.l, this.ll, this.IlI, this.lI, this.Il));
                                    }

                                    public int Il() {
                                       return Math.max(0, Math.round(this.lI + 2.0F));
                                    }

                                    public class_2960 lI() {
                                       return class_2960.method_60655(IlIllIll.l.lIlI(), this.II.lIlI());
                                    }

                                    public String ll() {
                                       return this.III.lIlI();
                                    }

                                    public <undefinedtype> III() {
                                       return this.III;
                                    }

                                    public <undefinedtype> IIl() {
                                       return this.I;
                                    }

                                    public float IlI() {
                                       return this.ll;
                                    }

                                    public int Ill() {
                                       return Math.max(0, Math.round(this.ll + 3.0F));
                                    }

                                    public int lII() {
                                       return this.IIl;
                                    }

                                    public float lIl() {
                                       return this.lI;
                                    }

                                    public int llI() {
                                       return this.l;
                                    }

                                    public float lll() {
                                       return this.Il;
                                    }

                                    public long IIII() {
                                       return this.III.lll();
                                    }

                                    public float IIIl() {
                                       return this.IlI;
                                    }
                                 });
                                 break label102;
                              }
                           } catch (Throwable var15) {
                              if (var7 != null) {
                                 try {
                                    var7.close();
                                 } catch (Throwable var14) {
                                    var15.addSuppressed(var14);
                                 }
                              }

                              throw var15;
                           }

                           if (var7 != null) {
                              var7.close();
                           }
                           break label89;
                        }

                        if (var7 != null) {
                           var7.close();
                        }
                        break label90;
                     }
                  } catch (Throwable var16) {
                     if (var6 != null) {
                        try {
                           var6.close();
                        } catch (Throwable var13) {
                           var16.addSuppressed(var13);
                        }
                     }

                     throw var16;
                  }

                  if (var6 != null) {
                     var6.close();
                  }
                  continue;
               }

               if (var6 != null) {
                  var6.close();
               }
               continue;
            }

            if (var6 != null) {
               var6.close();
            }
         } catch (Exception var17) {
            Ill.warn(lIlIII.Il(IlIl('벷', 44835, 1893478891)), var4, var17);
         }
      }

      return var0;
   }

   private static Optional<<undefinedtype>> l(Path var0, Path var1) {
      String var2 = var0.relativize(var1).toString().replace((char)IlII(1299998412, -768029190), (char)IlII(1299998413, -555882048));
      if (var2.equalsIgnoreCase(lIlIII.Il(IlIl('믥', 44834, -555281388)))) {
         return Optional.empty();
      } else {
         try {
            InputStream var3 = Files.newInputStream(var1);

            Optional var8;
            label86: {
               Optional var14;
               try {
                  class_1011 var4 = class_1011.method_4309(var3);

                  label88: {
                     try {
                        if (var4 == null || var4.method_4307() <= 0 || var4.method_4323() <= 0) {
                           var14 = Optional.empty();
                           break label88;
                        }

                        String var5 = var2.substring(0, var2.length() - 4);
                        float var6 = III(var4.method_4307(), var4.method_4323(), 8.0F);
                        float var7 = III(var4.method_4307(), var4.method_4323(), 6.0F);
                        var8 = Optional.of(new Object(var5, IIIl(var5), lII.IIII(lIlIII.III(var2)), var4.method_4307(), var4.method_4323(), var6, 8.0F, var7, 6.0F) {
                           private final <undefinedtype> I;
                           private final int l;
                           private final <undefinedtype> II;
                           private final float Il;
                           private final float lI;
                           private final float ll;
                           private final <undefinedtype> III;
                           private final int IIl;
                           private final float IlI;

                           private {
                              this.I = lIlIII.III(var1);
                              this.III = lIlIII.III(var2);
                              this.II = var3 == null ? lIlIII.III("") : var3;
                              this.IIl = var4;
                              this.l = var5;
                              this.ll = var6;
                              this.IlI = var7;
                              this.lI = var8;
                              this.Il = var9;
                           }

                           public float I(float var1) {
                              return var1 * ((float)this.IIl / (float)this.l);
                           }

                           public String l() {
                              return this.I.lIlI();
                           }

                           private <undefinedtype> II(String var1) {
                              return (<undefinedtype>)(new <anonymous constructor>(this.l(), var1, this.II, this.IIl, this.l, this.ll, this.IlI, this.lI, this.Il));
                           }

                           public int Il() {
                              return Math.max(0, Math.round(this.lI + 2.0F));
                           }

                           public class_2960 lI() {
                              return class_2960.method_60655(IlIllIll.l.lIlI(), this.II.lIlI());
                           }

                           public String ll() {
                              return this.III.lIlI();
                           }

                           public <undefinedtype> III() {
                              return this.III;
                           }

                           public <undefinedtype> IIl() {
                              return this.I;
                           }

                           public float IlI() {
                              return this.ll;
                           }

                           public int Ill() {
                              return Math.max(0, Math.round(this.ll + 3.0F));
                           }

                           public int lII() {
                              return this.IIl;
                           }

                           public float lIl() {
                              return this.lI;
                           }

                           public int llI() {
                              return this.l;
                           }

                           public float lll() {
                              return this.Il;
                           }

                           public long IIII() {
                              return this.III.lll();
                           }

                           public float IIIl() {
                              return this.IlI;
                           }
                        });
                     } catch (Throwable var11) {
                        if (var4 != null) {
                           try {
                              var4.close();
                           } catch (Throwable var10) {
                              var11.addSuppressed(var10);
                           }
                        }

                        throw var11;
                     }

                     if (var4 != null) {
                        var4.close();
                     }
                     break label86;
                  }

                  if (var4 != null) {
                     var4.close();
                  }
               } catch (Throwable var12) {
                  if (var3 != null) {
                     try {
                        var3.close();
                     } catch (Throwable var9) {
                        var12.addSuppressed(var9);
                     }
                  }

                  throw var12;
               }

               if (var3 != null) {
                  var3.close();
               }

               return var14;
            }

            if (var3 != null) {
               var3.close();
            }

            return var8;
         } catch (Exception var13) {
            Ill.warn(lIlIII.Il(IlIl('ら', 44833, -340063360)), var1, var13);
            return Optional.empty();
         }
      }
   }

   public static <undefinedtype> II(String var0) {
      return lIl().I(var0);
   }

   private static <undefinedtype> Il() {
      LinkedHashSet var0 = new LinkedHashSet();
      llI(var0, Paths.get(lIlIII.Il(IlIl('ｰ', 44832, -901492052)), lIlIII.Il(IlIl('҄', 44847, -2070013957)), lIlIII.Il(IlIl('䵸', 44846, -1462695977)), lIlIII.Il(IlIl('ꭓ', 44845, -1642183708)), I.lIlI()));
      llI(var0, Paths.get(lIlIII.Il(IlIl('眣', 44844, 154672149)), lIlIII.Il(IlIl('ᙁ', 44843, -994416723)), lIlIII.Il(IlIl('\udb48', 44842, -1531355095)), I.lIlI()));
      FabricLoader.getInstance().getModContainer(lIlIII.Il(IlIl('靊', 44841, -1056553256))).ifPresent((var1x) -> var1x.findPath(I.lIlI()).ifPresent((var1) -> llI(var0, var1)));
      ArrayList var1 = new ArrayList();

      for(Path var3 : var0) {
         var1.addAll(Ill(var3));
      }

      if (var1.isEmpty()) {
         var1.addAll(I());
      }

      var1.sort(Comparator.comparing(<undefinedtype>::ll, String.CASE_INSENSITIVE_ORDER));
      <undefinedtype> var14 = null;
      LinkedHashMap var15 = new LinkedHashMap();
      ArrayList var4 = new ArrayList(var1.size());
      LinkedHashMap var5 = new LinkedHashMap();

      for(<undefinedtype> var7 : var1) {
         int var8 = (Integer)var15.merge(var7.ll(), 1, Integer::sum);
         <undefinedtype> var10000;
         if (var8 > 1) {
            String var10001 = var7.ll();
            String var10002 = lIlIII.Il(IlIl('\ue4c0', 44840, -1287631756));
            String var13 = lIlIII.Il(IlIl('ᢈ', 44823, 95316983));
            String var11 = var10002;
            String var10 = var10001;
            var10000 = var7.II(var10 + var11 + var8 + var13);
         } else {
            var10000 = var7;
         }

         <undefinedtype> var9 = var10000;
         var4.add(var9);
         var5.put(var9.IIII(), var9);
         if (var14 == null) {
            var14 = var9;
         }
      }

      return new Record(List.copyOf(var4), Map.copyOf(var5), var14) {
         private final Map<Long, <undefinedtype>> I;
         private final <undefinedtype> l;
         private final List<<undefinedtype>> II;

         private <undefinedtype> I(String var1) {
            if (var1 != null && !var1.isBlank()) {
               <undefinedtype> var2 = (<undefinedtype>)this.I.get(lIlIII.II(var1));
               if (var2 != null && var2.III().IlII(var1)) {
                  return var2;
               } else {
                  for(<undefinedtype> var4 : this.II) {
                     if (var4.III().IlII(var1)) {
                        return var4;
                     }
                  }

                  return null;
               }
            } else {
               return null;
            }
         }

         private List<String> l() {
            ArrayList var1 = new ArrayList(this.II.size() + 1);
            var1.add("");

            for(<undefinedtype> var3 : this.II) {
               var1.add(var3.ll());
            }

            return List.copyOf(var1);
         }

         public Map<Long, <undefinedtype>> II() {
            return this.I;
         }

         private {
            this.II = var1;
            this.I = var2;
            this.l = var3;
         }

         public List<<undefinedtype>> Il() {
            return this.II;
         }

         public <undefinedtype> lI() {
            return this.l;
         }
      };
   }

   static {
      short var6 = 10539;
      String var7 = "푄퐁퐭푫푞퐠푛푐푠푞퐥퐫퐠퐟퐳푃푖푰퐖퐑푄푄푎퐟푯퐨퐏퐯푧푶퐲퐷\ue371\ue30c\ue328\ue34e\ue333\ue355\ue35e\ue325\ue36d\ue333\ue350\ue30e\ue355\ue31a\ue35e\ue34e\ue323\ue345\ue363\ue364\ue371\ue355\ue37b\ue312\ue338\ue322\ue33f\ue379\ue312\ue364\ueedf\ue321\ue377\ue36d\ue342\ue306쥡\uf6fc\uf658\uf6be줣\uf685\uf62e\uf6b5\uf69d줣\uf680\uf6fe\uf685\uf68a줮\uf6be\uf6f3\uf695\uf6b3\uf6f4쥦\uf6fc\uf6d4\uf6b3\uf6cf\uf6bd\uf6cd\uf689\uf682\uf68b\uf68e\uf6f7\uf6d4\uf682줣\uf6b5\uf6c4\uf6b9\uf6e1\uf697\ue438\ue465\ue401\ue407\ue45a\ue40c\ue477\ue43c\ue404\ue45a\ue7d9\ue447\ue40c\ue403\ue457\ue4e7\ue47a\ue41c\ue43a\ue47d\ue4e5\ue45c\ue424\ue4d4\ue476\ue42b\ue420\ue42b\ue40b\ue412\ue456\ue49b\uec6e\uec1b\uedb7\uedb1\uedd4\uedb2\uedc1\ued82\uedba\uedd4\ued8f\uedf1\uedb2\ued8d\uec21\ued91\uedc4\uec62\ued84\uedc3\ued8a\uec1b\uec68\ued80\uedcc\uedaa\uedc2\ued92\uedb5\uedc3\ueda0\uedfe\uec68\uedba\uede5\uedf9㎫㏶㎒㉔㏉㎗㏤㉧㉗㏉㎊㈔㎗㎈㏌㎼㏡㎇㎡㈦㎏㏝㎁㎀㏓㎪㏵㎸㉛㏑㏄㎳冿凪円冀倥冃凰决冋倥兞净冃农凐偠凵冓况凲军凃冕冀凱冝凪冴冄冝凑倔弡弼弘彾彣彅彮彵彝彣彀弾彅彊彮彾弳录彳弴弢徘弯彂弴弯張彌彿弈弤彡峐岊峏峢岗峅岏峖岮岝岚峯峉岎峥峳岲峷岠岱峓岅峐峸岎峂弓岩岨岑峓岌岛峍岜峺岻岮彖张柉枣柖柋枎枬架柏林枴枃柖某枷枌柊柛枮枹柨柪枼柉柡林柛柺柱林枈极枣枂枔枵枣柒柷杯朙\u07bfߍހٕ߸\u07b2ߠ\u07b9ށߚߝ߀ކߡߒބ߅ݘߏܞ٤߲\u07bf\u07b7߁\u07b5ؗ٭ޅ\u07fcߗܩ\u07bfޅފޮ京亶任从代仉亣亢仂仡䅮亃仅亢仩仇亾仃䅔亍产亱京仌人件付仾仝亻亯亃䅯仹仠从亇仚亪仜띃띑뜤뜩뜌뜮뜜띍락뜆뜉뜼띚뜝뜎뜠띙뜬뜻띢띀띖띃뜓띥띑띕뜭띣뜔띊띛뜈뜞뜇뜩뜠띅뜅띳栒桀栵棘桝毟桭栜栌桗桸桍栫桬桿栱殨栽桪桳树桇栒栂桴标梒栆毯桺毟殮栐校桹毘殮毞栁桺뒹듳뒆띛듾뒼듦뒿뒇뜤듓듆뒀듧드뒺듋둞듉되뒚듌뒹뒱듇뒴듡뒲뒀듛둘드듒뒄뜥뒳듂띧뒟듩长锍镀锕锸镲锠镹镁锚锝销镆锡锒镄锅锘锏镞锤锲长長锁镪锧镰镆锾锤锋锜镊锛镽锜锡闙閯〷づヨ〝ば〚㎨〱〉ひぅえヮ〩ぺ〜ね【ぇざ〼な〷ミォモ〴【『ぶモそいヒびュゔ〉ぱ〇뛱뚫뚮뛃뚶뚤뛮뛷뛏뚼뚻뚎뚨뙯뚄뛒뛓뛖뚁뚐뛲뚤뛱뚙뛯뚬뚹뛫뛬뛩뚤뛔뛼뛏뚵뚥뚈뚟뛹뛁ӳҡӔӹҼӾҌӽӭҶљҬӊҍӞӐ҉ӓӈҹӶӌӄӹҸӑҡӫૼુૉ૿鐡鑔鑀鑠鐕鑽鐬鑆鑁鐳鑊鐍鑍鑂鐈鑀鐀鐦鑡鐗鐮鐂鐯鑍鐁鑵钐鑻鑶鐰鐧鐫鐭鑵鑯鑆鐌鑷铟鑡铣鑔鑗鑠鑯鑔鐀鑝鑇钣鑅鐱鑱铑鐴鑪钚鑷鑝鐍鐯鐅鐿鐉䤰䥍䧩䤏䥲䤔䦟䧤䤬䥷䤑䦓䧯䧛䥞䤐䥣䥂䤃䥖䤱䦛䧨䧕䥸䤟䥫䧣䧓䤺䤞䥃菨荽茉茉莬茄荥茏軨荺菣荄茴茻荽茲荵茆茝莥菠荄茝茸莤茊茽茴茸莣茻荖菦菞躘茛荿茓菘荏荕荻茬菒莬荋荵菤軩草茌荴茄茴荂茛莐菣菑荂茓荰茫茋맢릟뤫뤜릧맠벩뤴뤷륏뤮륷뤺뤱륃뤿륾뤕뤳륎맬뤢뤯뤎륈볙뤪륜⠻⠁⠕⠽콨쳗첔첦켩첃쳦첰륈뤶륒뤞뤏륂륮륒뤛류르뤫戺戀戔戼駾駡駚馐馿駽駐駆抬抢択拺拣抮抪択拿抜抠拯ᩏᨉᩉᩁᨈᩈᨷᨢᨑᨐᷘᩲ\u1afa\u1ae1ᩞᵛ䅾䒨䄢䄔狾狡狰狵狤狐甙畯ⱏⰬⱷⱽⰎⰣⱴⱖⱽⰻⰵⱖⱋⱼⰀⰡⰦⰺⱋⰐⱫⰾⰍⱦⱦⱛⱌⰠⰔⰒⱛⰼⱻⰔⰁⱊⰧⱰⱿⱬⰃⱓⱆⱿⰏⰃⰜⰡⱽⰑⱎⰠ⚎㤙⚓⚢⛈⚑☯⚓㥕㤠⛫⛎㥩⚯⛵⚊⛏⚽⚠⛒⛀⛉⛃㥕⛹⛍⛸⚴㥕⛓⚃㤕⚎⚄⛰⚔⛥⚲⛲⚄ԁ՜ԸמՃץՎԕԽՃנ֞ץԪՎᣞ֓ԵԭԷ奙堓塦妻夞妜姆奟妧姄姳姦塠姇姼妚\uddcc\uddb1\udddd\udd9b\udd8e\uddd0\uddab\udda0\udd90\uddbc\uddbb\uddcc馔駶馻馎頣馉領駜扇扙扱扊돐뎥돱뎑돤돌뎽돷돰뎂돛뎜돼돌뎋뎣뎱돗뎫돦돗뎳돾뎗뎶뎦뎦뎑돆돒뎥뎃돾돋뎕뎠뎆돐뎦뎫뎜뎃돑돜뎛돾뎠돷돱뎽뎭뎝돍뎡뎓돲\uf7fe\uf7fe\uf7ac\uf79aꫤꨡꩺꩣꨑꩾꪗꫡ";
      char[] var8 = " $( $   (($(((((((\u001c\u0004@ @\u001c\u0004\b\f\u0004\b\f\f\u0004\u0004\b4(\u0014\u0010\f\b\u00048\u0004\b".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            llI = var9;
            lll = new Object[var9.length];
            int var2 = 1715095942;
            byte[] var0 = "\u000eü\u001a\u0005\u008f+ó#ò\u009eç\u009a1®©6{ê\u0002ñ¿à\u0004Ø?U~\u008f\u009fÁíB\u0018%HB\u009a°ÈÉ\u001b\u0098PBw\u0005\u0097\u0016M%\u0004l\u0007\u0094-\u0014ù~âìõ\u009bÆ¤\u0080\u001f;\u0091¯\u001fÖ%\u009eÓòÝ¸\u008bêÈ(c\u001f·Ýª\"ù8\u0011\\óðõ\u0094lÎøÝv[î1\u009eæöñ\u001fmðR¦".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lIl = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lIl[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            Ill = LoggerFactory.getLogger(IlIllIll.class);
            l = lIlIII.l(IlIl('緬', 44822, -1644100218));
            I = lIlIII.l(IlIl('ᕹ', 44821, 488966578));
            lII = lIlIII.l(IlIl('└', 44820, 445542563));
            IIl = lIlIII.l(IlIl('씱', 44819, 406088849));
            IlI = lIlIII.l(IlIl('뚏', 44818, 671111771));
            III = lIlIII.l(IlIl('⋲', 44817, 942298128));
            II = lIlIII.l(IlIl('ᜇ', 44816, 1235568543));
            Il = new WeakReference((Object)null);
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 78;
                     break;
                  case 1:
                     var10000 = 57;
                     break;
                  case 2:
                     var10000 = 79;
                     break;
                  case 3:
                     var10000 = 121;
                     break;
                  case 4:
                     var10000 = 15;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static String ll(String var0) {
      if (var0 != null && !var0.isBlank()) {
         String[] var1 = var0.trim().split(lIlIII.Il(IlIl('㥓', 44831, 1193018813)));
         StringBuilder var2 = new StringBuilder();

         for(String var6 : var1) {
            if (!var6.isBlank()) {
               if (var2.length() > 0) {
                  var2.append((char)IlII(1299998418, -1420225307));
               }

               String var7 = var6.toLowerCase(Locale.ROOT);
               var2.append(Character.toUpperCase(var7.charAt(0)));
               if (var7.length() > 1) {
                  var2.append(var7.substring(1));
               }
            }
         }

         return var2.toString();
      } else {
         return "";
      }
   }

   private static float III(int var0, int var1, float var2) {
      return var2 * ((float)var0 / (float)var1);
   }

   static void IIl() {
      synchronized(IlIllIll.class) {
         Il.clear();
         Il = new WeakReference((Object)null);
      }
   }

   public static <undefinedtype> IlI() {
      return lIl().lI();
   }

   private static List<<undefinedtype>> Ill(Path var0) {
      ArrayList var1 = new ArrayList();

      try {
         Stream var2 = Files.walk(var0);

         try {
            var2.filter((var0x) -> Files.isRegularFile(var0x, new LinkOption[0])).filter((var0x) -> var0x.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(lIlIII.Il(IlIl('鉆', 44828, -1811605989)))).forEach((var2x) -> {
               Optional var10000 = l(var0, var2x);
               Objects.requireNonNull(var1);
               var10000.ifPresent(var1::add);
            });
         } catch (Throwable var6) {
            if (var2 != null) {
               try {
                  var2.close();
               } catch (Throwable var5) {
                  var6.addSuppressed(var5);
               }
            }

            throw var6;
         }

         if (var2 != null) {
            var2.close();
         }
      } catch (Exception var7) {
         Ill.warn(lIlIII.Il(IlIl('锄', 44830, -1107349756)), var0, var7);
      }

      return var1;
   }

   private static <undefinedtype> lIl() {
      <undefinedtype> var0 = (<undefinedtype>)Il.get();
      if (var0 != null) {
         return var0;
      } else {
         synchronized(IlIllIll.class) {
            var0 = (<undefinedtype>)Il.get();
            if (var0 == null) {
               var0 = Il();
               Il = new WeakReference(var0);
            }

            return var0;
         }
      }
   }

   private static void llI(Set<Path> var0, Path var1) {
      if (var1 != null) {
         try {
            if (Files.isDirectory(var1, new LinkOption[0])) {
               var0.add(var1.toAbsolutePath().normalize());
            }
         } catch (Exception var3) {
         }

      }
   }

   public static List<String> IIII() {
      return lIl().l();
   }

   private static String IIIl(String var0) {
      String var1 = var0.replace((char)IlII(1299998419, -2074478292), (char)IlII(1299998416, -1248469596));
      int var2 = var1.indexOf(IlII(1299998417, -1815231056));
      String var3 = var2 >= 0 ? var1.substring(0, var2) : "";
      String var4 = var2 >= 0 ? var1.substring(var2 + 1) : var1;
      String var5;
      if (var3.isEmpty()) {
         var5 = "";
      } else if (IIl.IlII(var3)) {
         var5 = III.lIlI();
      } else if (IlI.IlII(var3)) {
         var5 = II.lIlI();
      } else {
         var5 = ll(var3.replace((char)IlII(1299998422, 52768968), (char)IlII(1299998423, -152302200)));
      }

      String var6 = ll(var4.replace((char)IlII(1299998420, 324498318), (char)IlII(1299998421, -608978145)).replace((char)IlII(1299998426, -440471033), (char)IlII(1299998427, 1890066147)).replace((char)IlII(1299998424, -844046818), (char)IlII(1299998425, 1186364889)));
      if (var6.isBlank()) {
         return var5;
      } else if (var5.isBlank()) {
         return var6;
      } else {
         String var8 = lIlIII.Il(IlIl('\uda76', 44829, 921717252));
         return var5 + var8 + var6;
      }
   }

   private IlIllIll() {
   }

   private static int IlII(int var0, int var1) {
      return lIl[var0 ^ 1299998402] ^ var1 ^ var0;
   }

   private static String IlIl(char var0, int var1, int var2) {
      int var3 = var1 ^ '꼷';
      char[] var4 = llI[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])lll[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         lll[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 16589;
      int var9 = 0;

      do {
         int var10 = var4[var9] - '팎';
         var10 ^= 687;
         var10 -= 17818;
         var10 += 29206;
         var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var2 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
