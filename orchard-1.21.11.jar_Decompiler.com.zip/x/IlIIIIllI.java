package x;

import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class IlIIIIllI extends llllllI<String> {
   private static String[] I;
   private final Runnable l;
   private static final int[] II;

   private static void I() {
      I[0] = III("".toCharArray(), 43902L, IlI(-990213777, 745022375));
   }

   public void l() {
      if (this.l != null) {
         this.l.run();
      }

   }

   public void II(JsonElement var1) {
   }

   public IlIIIIllI(Object var1) {
      this(var1, I[0], (Runnable)null);
   }

   public IlIIIIllI(Object var1, String var2, Runnable var3) {
      super((Object)var1, var2 == null ? I[0] : var2);
      this.l = var3;
   }

   static {
      int var2 = 1877494645;
      byte[] var0 = "\"ÙK\u0084hÔ\u0091%\u000fwT0".getBytes("ISO-8859-1");
      int var1 = var0.length / 4;
      II = new int[var1];
      int var3 = 0;
      int var4 = 0;

      do {
         int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
         var5 ^= var2;
         II[var4] = var5;
         var3 += 4;
         ++var4;
      } while(var4 < var1);

      I = new String[1];
      I();
   }

   public JsonElement lI() {
      return JsonNull.INSTANCE;
   }

   public IlIIIIllI(Object var1, String var2) {
      this(var1, var2, (Runnable)null);
   }

   public void ll(String var1) {
      super.Il(var1 == null ? I[0] : var1);
   }

   private static String III(char[] var0, long var1, int var3) {
      int var4 = IlI(-990213778, -797990360) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IlI(-990213779, -1536846121);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   public String IIl() {
      return (String)this.III();
   }

   private static int IlI(int var0, int var1) {
      return II[var0 ^ -990213777] ^ var1 ^ var0;
   }
}
