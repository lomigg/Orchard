package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class lIIllIlI {
   public static boolean I() {
      return false;
   }

   private lIIllIlI() {
   }
}
