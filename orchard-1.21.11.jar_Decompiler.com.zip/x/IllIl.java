package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;

@Environment(EnvType.CLIENT)
public interface IllIl {
   boolean lIIIl();

   boolean II(class_1297 var1);
}
