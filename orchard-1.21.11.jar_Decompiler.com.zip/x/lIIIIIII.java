package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public enum lIIIIIII {
   I;

   private static String[] II;
   Il,
   lI,
   ll,
   III;

   private static final int[] IIl;
   private static final String[] IlI;
   private static final Object[] Ill;

   private static void I() {
      II[0] = l(lI(862127123, -230222083).toCharArray(), 83161L, Il(-1176307736, -626774704));
      II[1] = l(lI(862127122, -262916804).toCharArray(), 57534L, Il(-1176307735, 402633055));
      II[2] = l(lI(862127121, 413169422).toCharArray(), 43569L, Il(-1176307734, 2070432087));
      II[3] = l(lI(862127120, 463154985).toCharArray(), 62388L, Il(-1176307733, 137808768));
      II[4] = l(lI(862127127, -876195148).toCharArray(), 67230L, Il(-1176307732, 498267380));
   }

   private static String l(char[] var0, long var1, int var3) {
      int var4 = Il(-1176307731, -286854006) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & Il(-1176307730, 1567420392);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   // $FF: synthetic method
   private static lIIIIIII[] II() {
      return new lIIIIIII[]{III, ll, I, Il, lI};
   }

   static {
      short var6 = 5433;
      String var7 = "䍘㨪⮻\uf402맜ᑹ騼ﳘ畴귤懊嘕㊣Ɡ꾆決氻\u2b74ꁡ亅此ﰇ氚\uf113埄傖䬵ﶹ\ua8df潀쏹Հ䡾ꙫ媶禁⃓瀼傜宱ꋀⲸ轥\uf349";
      char[] var8 = "\b\t\f\u0007\b".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            IlI = var9;
            Ill = new Object[var9.length];
            int var2 = 624445908;
            byte[] var0 = "\u009b\u0013?éÛ±Q]¥M\u009fþ%\u0014|Ê\u0084z\u009cój\u008akRÁ¶Q-".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IIl = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IIl[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            II = new String[5];
            I();
            III = new lIIIIIII(II[4], 0);
            ll = new lIIIIIII(II[0], 1);
            I = new lIIIIIII(II[1], 2);
            Il = new lIIIIIII(II[3], 3);
            lI = new lIIIIIII(II[2], 4);
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 25;
                     break;
                  case 1:
                     var10000 = 13;
                     break;
                  case 2:
                     var10000 = 125;
                     break;
                  case 3:
                     var10000 = 107;
                     break;
                  case 4:
                     var10000 = 58;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static int Il(int var0, int var1) {
      return IIl[var0 ^ -1176307736] ^ var1 ^ var0;
   }

   private static String lI(int var0, int var1) {
      int var3 = var0 ^ 862127123;
      char[] var4 = IlI[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])Ill[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         Ill[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -882911692;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 211;
               break;
            case 1:
               var9 = 162;
               break;
            case 2:
               var9 = 206;
               break;
            case 3:
               var9 = 254;
               break;
            case 4:
               var9 = 54;
               break;
            case 5:
               var9 = 100;
               break;
            case 6:
               var9 = 15;
               break;
            case 7:
               var9 = 35;
               break;
            case 8:
               var9 = 243;
               break;
            case 9:
               var9 = 135;
               break;
            case 10:
               var9 = 246;
               break;
            case 11:
               var9 = 115;
               break;
            case 12:
               var9 = 48;
               break;
            case 13:
               var9 = 241;
               break;
            case 14:
               var9 = 19;
               break;
            case 15:
               var9 = 164;
               break;
            case 16:
               var9 = 162;
               break;
            case 17:
               var9 = 205;
               break;
            case 18:
               var9 = 223;
               break;
            case 19:
               var9 = 204;
               break;
            case 20:
               var9 = 213;
               break;
            case 21:
               var9 = 32;
               break;
            case 22:
               var9 = 221;
               break;
            case 23:
               var9 = 102;
               break;
            case 24:
               var9 = 179;
               break;
            case 25:
               var9 = 223;
               break;
            case 26:
               var9 = 171;
               break;
            case 27:
               var9 = 236;
               break;
            case 28:
               var9 = 178;
               break;
            case 29:
               var9 = 203;
               break;
            case 30:
               var9 = 209;
               break;
            case 31:
               var9 = 60;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
