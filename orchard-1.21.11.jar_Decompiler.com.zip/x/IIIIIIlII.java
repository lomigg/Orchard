package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;

@Environment(EnvType.CLIENT)
public final class IIIIIIlII extends IIIIIIIlI {
   private int I = lll(1064334420, 738628516);
   private int l = -1;
   private static final int II = 6;
   private static final int[] Il;
   private static final String[] lI;
   private static final Object[] ll;

   public int ll(int var1) {
      if (!this.IIIIIlI()) {
         return -1;
      } else {
         return this.l >= 0 && this.l <= lll(1064334416, -1753054982) && var1 <= this.I ? this.l : -1;
      }
   }

   public void IlI() {
      this.l = -1;
      this.I = lll(1064334417, 1261771826);
   }

   public boolean IIIIIII() {
      return true;
   }

   public void lII(int var1, int var2) {
      class_310 var3 = class_310.method_1551();
      if (var3 != null && var3.field_1724 != null && var1 >= 0 && var1 < lll(1064334418, -1827222388)) {
         this.l = var1;
         this.I = var3.field_1724.field_6012 + Math.max(1, var2);
      }

   }

   public void llI(int var1) {
      this.lII(var1, lll(1064334419, 193523253));
   }

   public void lI() {
      this.IlI();
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (var1 != null && var1.field_1724 != null && this.l >= 0 && var1.field_1724.field_6012 > this.I) {
         this.IlI();
      }

   }

   public IIIIIIlII() {
      super((Object)lIlIII.l(IIII('᩿', (short)19787, 706953436)), lIllII.lI, (Object)lIlIII.l(IIII('\u1a7e', (short)29414, -1784407969)));
   }

   private static int lll(int var0, int var1) {
      return Il[var0 ^ 1064334416] ^ var1 ^ var0;
   }

   static {
      short var6 = 15891;
      String var7 = "\udea5\udea3\udf0a\udea1\ude96\udeb6\udea3\udebd\udefe\udeb4\ude34\udea7\ude94\udf44\udec9\ude96\udebf\ude91\udf08\udf00庳彅开店庼䣠底庋廋彼序庖彘彡廻彬彲彵彙彀廼彋庅庙庥庳廜底彥彼庺庸开座庠彺彏庝廁彼庽彾庮庿廻庳彙䣟庵庝廗庛庐役庲庱建彌庯䣞弍庡弝庖庾庘庩庶廵彌庶影";
      char[] var8 = "㸇㹛".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            lI = var9;
            ll = new Object[var9.length];
            int var2 = -2023505802;
            byte[] var0 = "/\u00914Ôs&¨\u0015+\u0005x¡³\u009bZ\u0016\u0014\u0015'\u0086".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            Il = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               Il[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 76;
                     break;
                  case 1:
                     var10000 = 68;
                     break;
                  case 2:
                     var10000 = 34;
                     break;
                  case 3:
                     var10000 = 110;
                     break;
                  case 4:
                     var10000 = 102;
                     break;
                  case 5:
                     var10000 = 127;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static String IIII(char var0, short var1, int var2) {
      int var3 = var0 ^ 6783;
      char[] var4 = lI[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])ll[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         ll[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 21553;
      int var9 = 0;

      do {
         int var10 = var4[var9] - '\ue3c6';
         var10 ^= 43918;
         var10 -= 53523;
         var10 += 56764;
         var10 -= 26029;
         var10 ^= 10414;
         var10 -= 27901;
         var4[var9] = (char)(var10 ^ var8 ^ var1 ^ var2 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
