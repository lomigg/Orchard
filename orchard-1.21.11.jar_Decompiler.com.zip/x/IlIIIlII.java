package x;

import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
final class IlIIIlII {
   static final double I = (double)20.0F;
   private static final long l = 250000000L;
   private static final double II = (double)1.0E9F;
   private long Il;

   void I() {
      this.Il = 0L;
   }

   void l(double var1, double var3) {
      long var5 = System.nanoTime();
      long var7 = this.Il > 0L && var5 - this.Il <= 250000000L ? this.Il : var5;
      this.Il = var7 + this.II(var1, var3);
   }

   private long II(double var1, double var3) {
      double var5 = Math.max(0.1, Math.min((double)20.0F, var1));
      double var7 = Math.max(var5, Math.min((double)20.0F, var3));
      double var9 = var5 == var7 ? var5 : ThreadLocalRandom.current().nextDouble(var5, var7);
      return Math.max(1L, Math.round((double)1.0E9F / var9));
   }

   boolean Il() {
      long var1 = System.nanoTime();
      return this.Il <= 0L || var1 >= this.Il;
   }
}
