package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public interface llIlllI {
   default boolean I() {
      return true;
   }

   default Enum<?> l() {
      return (Enum)this;
   }
}
