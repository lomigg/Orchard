package x;

import com.google.gson.JsonObject;
import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;

@Environment(EnvType.CLIENT)
public final class IlIIll extends IIIIIIIlI {
   private long I;
   private static final int l = 9;
   private boolean II;
   private final lIIIIl Il;
   private <undefinedtype> lI;
   private final lIIIIl ll;
   private int III;
   private static final long IIl = 3000L;
   private int IlI;
   private int Ill;
   private static int lII;
   private boolean lIl;
   private final boolean llI;
   private boolean lll;
   private <undefinedtype> IIII;
   private boolean IIIl;
   private int IIlI;
   private static final <undefinedtype> IIll;
   private final llllIlIl IlII;
   private int IlIl;
   private static final int[] IllI;
   private static final String[] Illl;
   private static final Object[] lIII;

   public IlIIll() {
      this(false);
   }

   private int ll(llllIlIl var1) {
      return Math.max(0, (int)Math.ceil((double)this.lIIl(var1) / (double)50.0F));
   }

   public void lIl() {
      class_310 var1 = class_310.method_1551();
      IllllIlI.IlII(var1, this, null.II);
      this.II = false;
      this.IIIl = false;
      this.lIl = false;
      this.IIllI();
   }

   private void IlI(Object var1, long var2) {
      this.IIII = var1;
      this.I = var2;
   }

   public lIIIIl lII() {
      return this.Il;
   }

   public void lI() {
      class_310 var1 = class_310.method_1551();
      if (!this.lIl) {
         this.IlIIl(var1);
      }

      this.IIllI();
      this.II = false;
      this.IIIl = false;
   }

   public boolean llI() {
      return this.IIII != null.l;
   }

   public boolean IIIIIIl() {
      return this.llI;
   }

   static {
      short var6 = 11488;
      String var7 = "\\$V+ﴯ[ﲒﱶﴗﴆﱻﱴ\")ﲕﲕ\uf8d2\uf8a3\uf8b7\uf8c7ﮃﮅ\uf8c7欄\uf8fe\uf8f2ﮚ\uf8fe\uf8a2\uf8a2烙烙㈨㙨㜗㜃㜍㈧㈩㜍㙵㙱㚑㈥㈡㈤㚐㚐苌茴苆茻芿苋綍茽茽茼綌苤苷茴苎苦茇綁茜茵綗茓茑苬苠苡綂苠茰綉茽苷芿綎茑茊苭苩苌茒苨苎苓苡茛綉綌苷茶苬茒苢茰茴苡茙茕茰苆苮綉苧苁苬苪茒苬茈芿苋苆茰茽茼苷苡茶茴綉苡茶苤綎綅ᶞᵝᵣᵍᵆᵷᶙᵋᶻᶾḘᶱᵡᶏᵮᵟᵭᶙᶹᵸᵚᵒᵚᵠᶰᵣᵷᵟᶾᵞᵀᵸᵚᵷḄᵺᵠᶾᵗᵡᵄᶝᵛᵟᵚᵅᵭᵌᵬᵞᶏᵭᵬᶏᵀᵎᵚᵄᶙᶹᶑᵖᵎᵗᴧᵦᶇᵠᵚᶾᵖᵂᶱᶐᵚᵢᶼᵦᶑᶻᵮᵺᵂᶾ㫷㫃㬞㬛㬵㪫㬴㪢㫉㫂㫧㫏ꐩꁢꐨꁲꁱꑜꐮꁰꑝꑒꁱꄗꑜꑔꁭꑙ魁鮊魀魖飌鮋餵餛餔餹飗餝餰餻鮍飢餾鮀飬鮘";
      char[] var8 = "⳰⳰⳰ⲴⲴⳬ⳰ⳤ⳰".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            Illl = var9;
            lIII = new Object[var9.length];
            int var2 = 1698567008;
            byte[] var0 = "×X<W\u0092\u008fè\u0002h\u0007Vi\u00ad\u0011`\u009c#\u008f\u0080\u008dJÅtn\u001a\u009eU4GÖ\u0010\"\u0015\u001bYj\u007fß7¸Uö\u0005±\u000e=¡ÂÊ=N«ë]ÇÏ".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IllI = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IllI[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            IIll = lIlIII.l(IlllI(46773, (short)31134, -1118552603));
            lII = IllIl(-542910543, -305792890);
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private void lll(class_310 var1) {
      if (!this.lIl) {
         this.IlIIl(var1);
      }

      this.IIllI();
      if (!this.llI && this.IIIIIlI()) {
         this.IIIllIl(false);
      }

   }

   private void IIII(class_310 var1) {
      if (var1 != null && var1.field_1724 != null && this.III != IllIl(-542910544, -1475203886)) {
         if (var1.field_1724.field_6012 > this.III) {
            this.III = IllIl(-542910541, 1385861818);
            if (this.IIII == null.ll) {
               this.IIII = null.Il;
            } else if (this.IIII == null.II) {
               this.IIII = null.lI;
            }
         }

      }
   }

   private boolean IIll(class_310 var1) {
      return var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var1.field_1690 != null && var1.field_1755 == null && var1.field_1724.method_5805();
   }

   public void IllI(class_310 var1) {
      if (!this.IIll(var1)) {
         this.lll(var1);
         this.II = false;
         this.IIIl = false;
      } else {
         long var2 = System.currentTimeMillis();
         if (lIlIllll.lIIl(var1)) {
            if (this.IIII != null.l && var2 - this.I > 3000L) {
               this.lll(var1);
            }

         } else if (this.IIII != null.l) {
            this.IIII(var1);
            this.lIII(var1, var2);
         } else if (this.IllII()) {
            this.lll(var1);
         } else {
            if (this.llI) {
               boolean var4 = this.IIlllll() && IllllIlI.IlIII(var1, this.IIIlIII());
               boolean var5 = var4 && !this.IIIl;
               this.IIIl = var4;
               if (!var4) {
                  this.II = false;
               }

               if (!var5) {
                  return;
               }
            }

            if (!this.II) {
               this.II = true;
               if (!this.IIlll(var1, var2, this.llI)) {
                  this.lll(var1);
                  return;
               }

               this.lIII(var1, var2);
            }

         }
      }
   }

   private void IlII(class_310 var1) {
      this.III = IllIl(-542910542, -1752390578);
      if (this.IIII == null.ll) {
         if (!this.lll) {
            this.lll(var1);
         } else {
            long var2 = System.currentTimeMillis();
            this.IlI = var1.field_1724.field_6012 + 1;
            this.IlI(null.lI, var2);
         }
      }
   }

   private boolean IlIl(class_310 var1, int var2, long var3) {
      if (this.lI == null || this.lI.ll() != var2) {
         this.IIlIl(var1, var2);
      }

      return this.lI != null && this.lI.III() && IllllIlI.IlIllII(var1, this.lI) && IllllIlI.lIIlI(var1.field_1724.method_31548()) == var2;
   }

   private static void Illl(int var0) {
      lII = var0;
   }

   private void lIII(class_310 var1, long var2) {
      if (var2 - this.I > 3000L) {
         this.lll(var1);
      } else {
         switch (this.IIII.ordinal()) {
            case 1:
               if (!this.IlIl(var1, this.Ill, var2)) {
                  return;
               }

               float var6 = var1.field_1724.method_36454();
               float var7 = (Boolean)this.Il.III() ? -90.0F : var1.field_1724.method_36455();
               if (!this.IIIll(var1, this.Ill, class_1802.field_8634, var6, var7, () -> this.IlII(var1))) {
                  return;
               }

               this.IlI(null.ll, var2);
               break;
            case 3:
               if (var1.field_1724.field_6012 < this.IlI) {
                  return;
               }

               if (!this.IlIl(var1, this.IlIl, var2)) {
                  return;
               }

               float var4 = var1.field_1724.method_36454();
               float var5 = (Boolean)this.Il.III() ? -90.0F : var1.field_1724.method_36455();
               if (!this.IIIll(var1, this.IlIl, class_1802.field_49098, var4, var5, () -> this.IIlII(var1))) {
                  return;
               }

               this.IlI(null.II, var2);
         }

      }
   }

   private long lIIl(llllIlIl var1) {
      double var2 = var1.IlII();
      double var4 = var1.IlI();
      return var2 >= var4 ? Math.max(0L, Math.round(var2)) : Math.max(0L, Math.round(ThreadLocalRandom.current().nextDouble(var2, var4)));
   }

   public IlIIll(boolean var1) {
      super(var1 ? lIlIII.Il(IlllI(46772, (short)3598, -569818805)) : lIlIII.Il(IlllI(46775, (short)'\uf281', 2013793652)), lIllII.I, var1 ? lIlIII.Il(IlllI(46774, (short)'뫸', 480913540)) : lIlIII.Il(IlllI(46769, (short)'蟱', 36846070)));
      this.IIII = null.l;
      this.Ill = -1;
      this.IlIl = -1;
      this.IIlI = -1;
      this.III = IllIl(-542910539, 420627544);
      this.IlI = IllIl(-542910540, 1884860602);
      this.llI = var1;
      this.Il = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IlllI(46768, (short)9647, -1411697328)), false));
      this.IlII = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(IlllI(46771, (short)32305, 1988320168)), (double)55.0F, (double)60.0F, (double)0.0F, (double)300.0F, (double)5.0F)).Ill(lIlIII.l(IlllI(46770, (short)'雡', 958819397))));
      this.ll = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IlllI(46781, (short)'\uee9f', 1590583058)), true));
   }

   private void llII(class_310 var1) {
      this.III = IllIl(-542910537, 537104867);
      if (this.IIII == null.ll || this.IIII == null.II) {
         this.lll(var1);
      }

   }

   public void IIl(JsonObject var1) {
      super.IIl(var1);
      this.lllIll(var1, IIll.lIlI());
   }

   private boolean IIIII(class_310 var1, boolean var2) {
      if (var1 != null && var1.field_1724 != null) {
         boolean var3 = var1.field_1724.method_7357().method_7904(new class_1799(class_1802.field_8634));
         boolean var4 = var2 && var1.field_1724.method_7357().method_7904(new class_1799(class_1802.field_49098));
         return var3 || var4;
      } else {
         return true;
      }
   }

   private boolean IIIll(class_310 var1, int var2, class_1792 var3, float var4, float var5, Runnable var6) {
      if (var1 != null && var1.field_1724 != null && var2 >= 0 && var2 < IllIl(-542910538, -45361923) && var1.field_1724.method_31548().method_5438(var2).method_31574(var3) && this.lI != null && IllllIlI.IlIllII(var1, this.lI) && var6 != null) {
         int var7 = var1.field_1724.field_6012;
         if (lII == var7) {
            return false;
         } else {
            boolean var8 = IlIlIl.IIlll(var1, IllIl(-542910535, -1350132407), var4, var5, () -> {
               if (var1.field_1724.method_31548().method_5438(var2).method_31574(var3) && IllllIlI.lIIlI(var1.field_1724.method_31548()) == var2) {
                  boolean var5 = IllllIlI.IlIll(var1, class_1268.field_5808);
                  if (var5) {
                     Illl(var1.field_1724.field_6012);
                     var1.field_1724.method_6104(class_1268.field_5808);
                     var6.run();
                  } else {
                     this.llII(var1);
                  }

                  return var5;
               } else {
                  this.llII(var1);
                  return false;
               }
            });
            if (var8) {
               this.III = var7 + 2;
            }

            return var8;
         }
      } else {
         return false;
      }
   }

   private void IIlII(class_310 var1) {
      this.III = IllIl(-542910536, 1162015584);
      if (this.IIII == null.II) {
         this.lll(var1);
      }

   }

   private void IIlIl(class_310 var1, int var2) {
      boolean var3 = IllllIlI.IIlIl(var1) != var2;
      int var4 = var3 ? this.ll(this.IlII) : 0;
      this.lI = IllllIlI.lIll(var1, this, var2, var4, true);
   }

   private void IIllI() {
      this.IIII = null.l;
      this.I = 0L;
      this.Ill = -1;
      this.IlIl = -1;
      this.IIlI = -1;
      this.lll = false;
      this.lI = null;
      this.III = IllIl(-542910533, 1869332842);
      this.IlI = IllIl(-542910534, 882926872);
   }

   private boolean IIlll(class_310 var1, long var2, boolean var4) {
      class_1661 var5 = var1.field_1724.method_31548();
      int var6 = this.IlIll(var5, class_1802.field_8634);
      int var7 = var4 ? this.IlIll(var5, class_1802.field_49098) : -1;
      if (var6 >= 0 && (!var4 || var7 >= 0) && !this.IIIII(var1, var4)) {
         this.Ill = var6;
         this.IlIl = var7;
         this.IIlI = IllllIlI.lIIlI(var5);
         this.lll = var4;
         this.lIl = false;
         this.IIlIl(var1, var6);
         this.IlI(null.Il, var2);
         return true;
      } else {
         return false;
      }
   }

   private void IlIIl(class_310 var1) {
      int var2 = this.IIlI;
      if ((Boolean)this.ll.III() && var2 >= 0 && var2 < IllIl(-542910531, 1889569407) && var1 != null && var1.field_1724 != null) {
         IllllIlI.llIIlI(var1, this, var2);
      } else {
         IllllIlI.IlII(var1, this, null.Il);
      }

      this.lI = null;
      this.lIl = true;
   }

   private int IlIll(class_1661 var1, class_1792 var2) {
      if (var1 == null) {
         return -1;
      } else {
         for(int var3 = 0; var3 < IllIl(-542910532, 1371538202); ++var3) {
            if (var1.method_5438(var3).method_31574(var2)) {
               return var3;
            }
         }

         return -1;
      }
   }

   private boolean IllII() {
      lIllIIl var1 = lIllIIl.Il();
      if (var1 != null && var1.IIl() != null) {
         for(IIIIIIIlI var3 : var1.IIl().IIIIlII()) {
            if (var3 instanceof IIIlllIIl) {
               IIIlllIIl var4 = (IIIlllIIl)var3;
               if (var4.lllI()) {
                  return true;
               }
            }
         }
      }

      return false;
   }

   private static int IllIl(int var0, int var1) {
      return IllI[var0 ^ -542910543] ^ var1 ^ var0;
   }

   private static String IlllI(int var0, short var1, int var2) {
      int var3 = var0 ^ '뚵';
      char[] var4 = Illl[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])lIII[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         lIII[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 1625;
      int var9 = 0;

      do {
         int var10 = var4[var9] - 4627;
         var10 -= 45892;
         var10 += 26872;
         var10 ^= 49066;
         var10 ^= 19493;
         var10 ^= 28262;
         var10 -= 49203;
         var10 ^= 43158;
         var10 -= 55825;
         var4[var9] = (char)(var10 ^ var8 ^ var1 ^ var2 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
