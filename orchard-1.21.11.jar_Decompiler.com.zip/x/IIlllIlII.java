package x;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.URL;
import java.security.CodeSource;
import java.util.ArrayList;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;

@Environment(EnvType.CLIENT)
public final class IIlllIlII {
   private static final URL I;
   private static final String[] l;
   private static final Object[] II;

   private static URL I(Class<?> var0) {
      if (var0 != null && var0.getProtectionDomain() != null) {
         CodeSource var1 = var0.getProtectionDomain().getCodeSource();
         return var1 == null ? null : var1.getLocation();
      } else {
         return null;
      }
   }

   private static Method l(Class<?> var0, String var1) {
      for(Class var2 = var0; var2 != null && var2 != Object.class; var2 = var2.getSuperclass()) {
         try {
            return var2.getDeclaredMethod(var1);
         }
      }

      return null;
   }

   private IIlllIlII() {
   }

   private static Field II(Class<?> var0, String var1) {
      for(Class var2 = var0; var2 != null && var2 != Object.class; var2 = var2.getSuperclass()) {
         try {
            return var2.getDeclaredField(var1);
         }
      }

      return null;
   }

   private static void Il(Object var0) throws ReflectiveOperationException {
      if (var0 != null) {
         Field var1 = II(var0.getClass(), lIlIII.Il(IIl(1441890381, 776420186)));
         if (var1 != null) {
            var1.setAccessible(true);
            Object var2 = var1.get(var0);
            if (var2 instanceof Object[]) {
               Object[] var3 = var2;
               if (var3.length != 0) {
                  ArrayList var4 = new ArrayList(var3.length);

                  for(Object var8 : var3) {
                     if (var8 != null && !lI(var8)) {
                        var4.add(var8);
                     }
                  }

                  if (var4.size() == var3.length) {
                     return;
                  }

                  Object var9 = Array.newInstance(var3.getClass().getComponentType(), var4.size());

                  for(int var10 = 0; var10 < var4.size(); ++var10) {
                     Array.set(var9, var10, var4.get(var10));
                  }

                  var1.set(var0, var9);
                  Method var11 = l(var0.getClass(), lIlIII.Il(IIl(1441890380, 621019847)));
                  if (var11 != null) {
                     var11.setAccessible(true);
                     var11.invoke(var0);
                  }

                  return;
               }
            }

         }
      }
   }

   private static boolean lI(Object var0) {
      URL var1 = I(var0.getClass());
      return I != null && I.equals(var1);
   }

   private static void ll(Object var0) {
      try {
         Il(var0);
      } catch (Throwable var2) {
      }

   }

   public static void III() {
      ll(ClientTickEvents.END_CLIENT_TICK);
      ll(HudRenderCallback.EVENT);
      ll(IIIIIIIII.I);
      ll(ClientPlayConnectionEvents.JOIN);
   }

   static {
      short var0 = 25726;
      String var1 = "\u0fe2༅ཌ༺\u0fe6༧ྩྫཡ༃\u0f70ཾҠѕЋщҦѷҍӨ";
      char[] var2 = "摲摶".toCharArray();
      String[] var3 = new String[var2.length];
      byte var7 = -1;

      while(true) {
         int var4 = 0;
         int var5 = 0;
         int var6 = 0;
         if (var7 == 0) {
            l = var3;
            II = new Object[var3.length];
            I = I(IIlllIlII.class);
            return;
         }

         do {
            var6 = var2[var4] ^ var0;
            var3[var4] = var1.substring(var5, var5 + var6);
            var5 += var6;
            ++var4;
         } while(var4 < var2.length);

         var7 = 0;
      }
   }

   private static String IIl(int var0, int var1) {
      int var3 = var0 ^ 1441890381;
      char[] var4 = l[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])II[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         II[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 682526533;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 43;
               break;
            case 1:
               var9 = 237;
               break;
            case 2:
               var9 = 184;
               break;
            case 3:
               var9 = 249;
               break;
            case 4:
               var9 = 41;
               break;
            case 5:
               var9 = 199;
               break;
            case 6:
               var9 = 93;
               break;
            case 7:
               var9 = 90;
               break;
            case 8:
               var9 = 146;
               break;
            case 9:
               var9 = 198;
               break;
            case 10:
               var9 = 234;
               break;
            case 11:
               var9 = 225;
               break;
            case 12:
               var9 = 148;
               break;
            case 13:
               var9 = 5;
               break;
            case 14:
               var9 = 168;
               break;
            case 15:
               var9 = 21;
               break;
            case 16:
               var9 = 163;
               break;
            case 17:
               var9 = 181;
               break;
            case 18:
               var9 = 10;
               break;
            case 19:
               var9 = 255;
               break;
            case 20:
               var9 = 139;
               break;
            case 21:
               var9 = 111;
               break;
            case 22:
               var9 = 197;
               break;
            case 23:
               var9 = 201;
               break;
            case 24:
               var9 = 70;
               break;
            case 25:
               var9 = 116;
               break;
            case 26:
               var9 = 43;
               break;
            case 27:
               var9 = 253;
               break;
            case 28:
               var9 = 42;
               break;
            case 29:
               var9 = 35;
               break;
            case 30:
               var9 = 2;
               break;
            case 31:
               var9 = 72;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
