package x;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_2596;
import net.minecraft.class_2824;
import net.minecraft.class_2828;
import net.minecraft.class_2868;
import net.minecraft.class_2885;
import net.minecraft.class_2886;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_437;

@Environment(EnvType.CLIENT)
public final class IIllIlII {
   private final Illlll I;
   private final IIIlll l;
   private final llIIIllI II;
   private final IIIIIIIl Il;
   private final Map<IIIIIIIlI, Integer> lI;
   private final IlIIlIlII ll;
   private final Map<Class<?>, IIIIIIIlI> III;
   private final IlIIIlIII IIl;
   private final IIlllll IlI;
   private final lIIIIlll Ill;
   private final lIIIllII lII;
   private final IIlIlII lIl;
   private final IIlIll llI;
   private final llIIIIlI lll;
   private final IIIIIIlII IIII;
   private final lIlIllI IIIl;
   private final IIIIlllll IIlI;
   private final IIllIllIl IIll;
   private final llIlIl IlII;
   private final IIIIIIIIl IlIl;
   private final lIIIIIIl IllI;
   private final IIIIllIl Illl;
   private final llIlIII lIII;
   private final IIIIlIIl lIIl;
   private final IIlllI lIlI;
   private final lIlIllII lIll;
   private final lIl llII;
   private final llIlII llIl;
   private final IIIII lllI;
   private final IIllllllI llll;
   private final lIIIIIl IIIII;
   private final lIllIll IIIIl;
   private final IllI IIIlI;
   private final lllIII IIIll;
   private final IlIIlllI IIlII;
   private final IlllIllI IIlIl;
   private final lllIlIll IIllI;
   private final IlIIIIl IIlll;
   private final IIllIllll IlIII;
   private final IIIlllI IlIIl;
   private final IIIlI IlIlI;
   private final IlIl IlIll;
   private final IllIIIlI IllII;
   private final IIIIIllII IllIl;
   private final IIIllIlII IlllI;
   private final List<IIIIIIIlI> Illll = new ArrayList();
   private final lllIIIIl lIIII;
   private final lIllIIII lIIIl;
   private final lIllllll lIIlI;
   private final IIIllI lIIll;
   private final llIIl lIlII;
   private final llIIlIll lIlIl;
   private final IIIlIIll lIllI;
   private final List<IIIIIIIlI> lIlll = new ArrayList();
   private final IIIIIlI llIII;
   private final llllIll llIIl;
   private final Map<IIIIIIIlI, Boolean> llIlI;
   private final llIl llIll;
   private final IIIllIIl lllII;
   private final IIllIIlll lllIl;
   private final lIIlIlIl llllI;
   private final IllIIII lllll;
   private final lIlIIIlI IIIIII;
   private final IlIlIIII IIIIIl;
   private final IIlIlll IIIIlI;
   private final llIIlIlI IIIIll;
   private final IlI IIIlII;
   private final IIIlllIIl IIIlIl;
   private final llIllII IIIllI;
   private final lIllI IIIlll;
   private final IIIlIlI IIlIII;
   private final llIIIl IIlIIl;
   private final llIlIllI IIlIlI;
   private final List<IIIIIIIlI> IIlIll = new ArrayList();
   private final llIlIIIl IIllII;
   private final List<IIIIIIIlI> IIllIl = new ArrayList();
   private final IIIIllIIl IIlllI;
   private final IIllIlIll IIllll;
   private int IlIIII;
   private final lIIIlIll IlIIIl;
   private final IIlllII IlIIlI;
   private final IIIlllll IlIIll;
   private final lllIIII IlIlII;
   private final IIlIIllI IlIlIl;
   private final llIIIlII IlIllI;
   private final IIIlIIIII IlIlll;
   private final IIIIll IllIII;
   private final lllIIlII IllIIl;
   private final IlIIII IllIlI;
   private final IlIIllII IllIll;
   private final llIIlIII IlllII;
   private final lIII IlllIl;
   private final lIllIlII IllllI;
   private final List<llIlIIII> Illlll = new ArrayList();
   private final llIlIlI lIIIII;
   private final IIIllIIll lIIIIl;
   private final IlIIlIlll lIIIlI;
   private final llIIIlll lIIIll;
   private final IlIIll lIIlII;
   private final List<IIIIIIIlI> lIIlIl = new ArrayList();
   private final lIIIlI lIIllI;
   private final IIIIIlIlI lIIlll;
   private final lIlllII lIlIII;
   private final IIIIIIlIl lIlIIl;
   private final IllIlI lIlIlI;
   private final lIIlllll lIlIll;
   private final lIIIllll lIllII;
   private final IIIlIllll lIllIl;
   private final III lIlllI;
   private final IIIll lIllll;
   private final llllII llIIII;
   private final IIlIIlIll llIIIl;
   private final lIIIllI llIIlI;
   private final IIIIIl llIIll;
   private final IIIlII llIlII;
   private final lIllll llIlIl;
   private final IllIllII llIllI;
   private final lI llIlll;
   private final IIllIIIII lllIII;
   private final IlIIll lllIIl;
   private final List<llIlIIII> lllIlI;
   private final lIIlIl lllIll;
   private final lIIIll llllII;
   private final IIllIIlIl llllIl;
   private final lllI lllllI;
   private final llIlIIl llllll;
   private final IllllIIl IIIIIII;
   private final lIlIlIII IIIIIIl;
   private final IllIIIll IIIIIlI;
   private final lIlIIII IIIIIll;
   private final IIIlIllI IIIIlII;
   private final lllIllI IIIIlIl;
   private final IlllIIl IIIIllI;
   private final IllllllI IIIIlll;
   private static final int[] IIIlIII;
   private static final String[] IIIlIIl;
   private static final Object[] IIIlIlI;

   public IIIlIllll I() {
      return this.lIllIl;
   }

   public IIllllllI l() {
      return this.llll;
   }

   public List<IIIIIIIlI> II(lIllII var1) {
      return var1 == x.lIllII.lI ? Collections.emptyList() : this.lIIlIl.stream().filter((var1x) -> {
         lIllII var2 = var1x.IlIIIII();
         if (var1 != x.lIllII.l) {
            return var2 == var1;
         } else {
            return var2 == x.lIllII.l || var2 == x.lIllII.lI;
         }
      }).sorted(this.lIllIl(var1)).toList();
   }

   private int Il(IIIIIIIlI var1, IIIIIIIlI var2) {
      int var3 = Integer.compare(this.lIIII(var2), this.lIIII(var1));
      return var3 != 0 ? var3 : Integer.compare((Integer)this.lI.getOrDefault(var1, IIlIlIl(144642009, 515168693)), (Integer)this.lI.getOrDefault(var2, IIlIlIl(144642008, -822820150)));
   }

   public IIllIllll lI() {
      return this.IlIII;
   }

   public void ll(class_1297 var1) {
      if (!x.IlIII.II(var1)) {
         this.lIlIII.IllI(var1);

         for(IIIIIIIlI var3 : this.lIlll) {
            if (var3.IIIIIlI() || !var3.IIlIlIl()) {
               var3.lIlI(var1);
            }
         }

      }
   }

   public IIIllI III() {
      return this.lIIll;
   }

   public IIlllll IIl() {
      return this.IlI;
   }

   public IlIIll Ill() {
      return this.lllIll();
   }

   public void lII(class_1297 var1, int var2) {
      if (var1 != null && !x.IlIII.II(var1)) {
         for(IIIIIIIlI var4 : this.lIlll) {
            if (var4.IIIIIlI() || !var4.IIlIlIl()) {
               var4.IIllIll(var1, var2);
            }
         }

      }
   }

   public llIIl lIl() {
      return this.lIlII;
   }

   public lIIIllll llI() {
      return this.lIllII;
   }

   public lIllIIII lll() {
      return this.lIIIl;
   }

   public lIIIllll IIII() {
      return this.lIllII;
   }

   public IlIIIIl IIIl() {
      return this.IIlll;
   }

   public IIIlll IIlI() {
      return this.l;
   }

   public void IIll(llIIllI var1) {
      if (var1 != null) {
         for(IIIIIIIlI var3 : this.lIIlIl) {
            if (var3.IIIIIlI() || !var3.IIlIlIl()) {
               try {
                  var3.llIl(var1);
               } catch (RuntimeException var5) {
               }
            }
         }

      }
   }

   public IIllIIlIl IlII() {
      return this.llllIl;
   }

   public lllIIlII IlIl() {
      return this.IllIIl;
   }

   public llIlII IllI() {
      return this.llIl;
   }

   public lIIlllI Illl() {
      return lIIlllI.ll();
   }

   public List<IIIIIIIlI> lIII() {
      return Collections.unmodifiableList(this.lIIlIl);
   }

   public IIIIIIIl lIIl() {
      return this.Il;
   }

   public IllllIIl lIlI() {
      return this.IIIIIII;
   }

   public IIllIIIII lIll() {
      return this.lllIII;
   }

   public IlIIIlIII llII() {
      return this.IIl;
   }

   public IIIIllIIl llIl() {
      return this.IIlllI;
   }

   private <T extends IIIIIIIlI> T lllI(T var1) {
      var1.llIlll();
      this.lI.put(var1, this.IlIIII++);
      this.lIIlIl.add(var1);
      if (var1 instanceof llIlIIII var2) {
         this.Illlll.add(var2);
      }

      this.III.putIfAbsent(var1.getClass(), var1);
      this.lIlll.add(var1);
      if (llllI(var1, x.lIlIII.Il(IIlIllI((short)'컭', -1766718725, 45139)))) {
         this.IIllIl.add(var1);
      }

      if (llllI(var1, x.lIlIII.Il(IIlIllI((short)30049, 1514804419, 45138)))) {
         this.Illll.add(var1);
      }

      if (llllI(var1, x.lIlIII.Il(IIlIllI((short)31155, -642642119, 45137)))) {
         this.IIlIll.add(var1);
      }

      this.lIlll.sort(this::Il);
      return (T)var1;
   }

   public lIIIllI llll() {
      return this.llIIlI;
   }

   public IIIIlllll IIIII() {
      return this.IIlI;
   }

   public boolean IIIIl(class_2596<?> var1) {
      if (!(var1 instanceof class_2824)) {
         return false;
      } else {
         for(IIIIIIIlI var3 : this.IIlIll) {
            if (var3.IIIIIlI() || !var3.IIlIlIl()) {
               return true;
            }
         }

         return false;
      }
   }

   public lIllIll IIIlI() {
      return this.IIIIl;
   }

   public IlI IIIll() {
      return this.IIIlII;
   }

   public void IIlII(class_2596<?> var1) {
      if (var1 != null) {
         if (var1 instanceof class_2868) {
            IllllIlI.lIlIll(var1);
         } else if (var1 instanceof class_2885 || var1 instanceof class_2824 || var1 instanceof class_2886) {
            IllllIlI.lIIlII(var1);
         }

         for(IIIIIIIlI var3 : this.IIllIl) {
            if (var3.IIIIIlI() || !var3.IIlIlIl()) {
               var3.llllII(var1);
            }
         }

      }
   }

   public lIlIIII IIlIl() {
      return this.IIIIIll;
   }

   public IIIIIlIlI IIllI() {
      return this.lIIlll;
   }

   public IIIlIlI IIlll() {
      return this.IIlIII;
   }

   public IlIIlIlII IlIII() {
      return this.ll;
   }

   public llIlIII IlIIl() {
      return this.lIII;
   }

   private int IlIlI(lIllII var1, IIIIIIIlI var2) {
      return 1;
   }

   public IIIIIllII IlIll() {
      return this.IllIl;
   }

   public llIIlIlI IllII() {
      return this.IIIIll;
   }

   public llIIIlll IllIl() {
      return this.lIIIll;
   }

   public llIIIIlI IlllI() {
      return this.lll;
   }

   public llIIlIll Illll() {
      return this.lIlIl;
   }

   private int lIIII(IIIIIIIlI var1) {
      if (var1 instanceof lIllll) {
         return IIlIlIl(144642011, -142298684);
      } else if (var1 instanceof llIIl) {
         return IIlIlIl(144642010, -461920108);
      } else if (var1 instanceof IllIllII) {
         return IIlIlIl(144642013, -742837426);
      } else if (var1 instanceof IlIl) {
         return IIlIlIl(144642012, -1546910529);
      } else if (var1 instanceof lIIIlIll) {
         return IIlIlIl(144642015, 566845746);
      } else if (var1 instanceof IIIlllIIl) {
         return IIlIlIl(144642014, 182507336);
      } else if (var1 instanceof IIlIlll) {
         return IIlIlIl(144642001, 1650575870);
      } else if (var1 instanceof IIIIIIIl) {
         return IIlIlIl(144642000, 45288676);
      } else if (var1 instanceof IIIIIIIIl) {
         return IIlIlIl(144642003, -1130150091);
      } else if (var1 instanceof llIIIllI) {
         return IIlIlIl(144642002, -875218183);
      } else if (var1 instanceof llIlIlI) {
         return IIlIlIl(144642005, -2030337717);
      } else if (var1 instanceof IIIlIlI) {
         return IIlIlIl(144642004, 1224537960);
      } else if (var1 instanceof llIIlIII) {
         return IIlIlIl(144642007, 1870701732);
      } else if (var1 instanceof llIIlIlI) {
         return IIlIlIl(144642006, 219849458);
      } else if (var1 instanceof Illlll) {
         return IIlIlIl(144641993, -768490756);
      } else if (var1 instanceof IIIIllIIl) {
         return IIlIlIl(144641992, 1319935387);
      } else if (var1 instanceof IlIIlllI) {
         return IIlIlIl(144641995, 1069503030);
      } else if (var1 instanceof lllIII) {
         return IIlIlIl(144641994, 1563780785);
      } else if (var1 instanceof IIIIll) {
         return IIlIlIl(144641997, -740467605);
      } else if (var1 instanceof IlIIll) {
         return IIlIlIl(144641996, -592927637);
      } else if (var1 instanceof IIIIIlIlI) {
         return IIlIlIl(144641999, 1925602656);
      } else if (var1 instanceof IIIlllI) {
         return IIlIlIl(144641998, -1165847450);
      } else if (var1 instanceof llIIIl) {
         return IIlIlIl(144641985, -1222427737);
      } else if (var1 instanceof lIlIlIII) {
         return IIlIlIl(144641984, 380567949);
      } else if (var1 instanceof IIlllI) {
         return IIlIlIl(144641987, 118807796);
      } else if (var1 instanceof IIIllIlII) {
         return IIlIlIl(144641986, -1060717987);
      } else if (var1 instanceof lIIIlI) {
         return IIlIlIl(144641989, 295812596);
      } else if (var1 instanceof lIlIIIlI) {
         return IIlIlIl(144641988, 862917212);
      } else if (var1 instanceof llllIll) {
         return IIlIlIl(144641991, 1573487436);
      } else if (var1 instanceof lIlIllII) {
         return IIlIlIl(144641990, -830232290);
      } else if (var1 instanceof lIIlIlIl) {
         return IIlIlIl(144642041, -9514739);
      } else if (var1 instanceof IIllIllIl) {
         return IIlIlIl(144642040, -1982941486);
      } else if (var1 instanceof IIIIlllll) {
         return IIlIlIl(144642043, 1770945010);
      } else if (var1 instanceof IIIIlIIl) {
         return IIlIlIl(144642042, 75237556);
      } else if (var1 instanceof llIlIII) {
         return IIlIlIl(144642045, 1897439797);
      } else if (var1 instanceof IIlIll) {
         return IIlIlIl(144642044, -913415439);
      } else if (var1 instanceof IlIIII) {
         return IIlIlIl(144642047, -643034356);
      } else if (var1 instanceof llIllII) {
         return IIlIlIl(144642046, -2056852051);
      } else if (var1 instanceof llIlIl) {
         return IIlIlIl(144642033, -1270287794);
      } else if (var1 instanceof IllIIIlI) {
         return IIlIlIl(144642032, 302815181);
      } else if (var1 instanceof IllllllI) {
         return IIlIlIl(144642035, 41399429);
      } else if (var1 instanceof IIlllII) {
         return IIlIlIl(144642034, 418602828);
      } else if (var1 instanceof llIIIlII) {
         return IIlIlIl(144642037, 2024220894);
      } else if (var1 instanceof IllllIIl) {
         return IIlIlIl(144642036, -459279160);
      } else if (var1 instanceof lllIIIIl) {
         return IIlIlIl(144642039, 1128495371);
      } else if (var1 instanceof IIIlll) {
         return IIlIlIl(144642038, -349680157);
      } else if (var1 instanceof lIllIlII) {
         return IIlIlIl(144642025, -1741892404);
      } else if (var1 instanceof llIlII) {
         return IIlIlIl(144642024, 1896525893);
      } else if (var1 instanceof lllIllI) {
         return IIlIlIl(144642027, -966107149);
      } else if (var1 instanceof IlIIIIl) {
         return IIlIlIl(144642026, 1121902321);
      } else if (var1 instanceof lIIlIl) {
         return IIlIlIl(144642029, -468291529);
      } else if (var1 instanceof lIl) {
         return IIlIlIl(144642028, -207394203);
      } else if (var1 instanceof IIlIlII) {
         return IIlIlIl(144642031, -569663451);
      } else if (var1 instanceof lIIIIlll) {
         return IIlIlIl(144642030, -236219003);
      } else if (var1 instanceof IIIlIllll) {
         return IIlIlIl(144642017, -156229328);
      } else if (var1 instanceof llIIIlll) {
         return IIlIlIl(144642016, 801053350);
      } else if (var1 instanceof IllIIII) {
         return IIlIlIl(144642019, -23983310);
      } else if (var1 instanceof lllIlIll) {
         return IIlIlIl(144642018, 973934049);
      } else if (var1 instanceof lIII) {
         return IIlIlIl(144642021, 258613014);
      } else if (var1 instanceof lI) {
         return IIlIlIl(144642020, -911436882);
      } else if (var1 instanceof llIlIIII) {
         return IIlIlIl(144642023, 1108221342);
      } else if (var1 instanceof llIIlIll) {
         return IIlIlIl(144642022, 1902676647);
      } else if (var1 instanceof IlIIlIlll) {
         return IIlIlIl(144641945, -836364103);
      } else if (var1 instanceof lllIIlII) {
         return IIlIlIl(144641944, -1756548079);
      } else if (var1 instanceof IlI) {
         return IIlIlIl(144641947, -799079362);
      } else if (var1 instanceof IIIlI) {
         return IIlIlIl(144641946, -1189415355);
      } else if (var1 instanceof IlIIllII) {
         return IIlIlIl(144641949, 1883467579);
      } else if (var1 instanceof llllII) {
         return IIlIlIl(144641948, 1087257095);
      } else if (var1 instanceof IlllIIl) {
         return IIlIlIl(144641951, -598143567);
      } else if (var1 instanceof lIllIll) {
         return IIlIlIl(144641950, -1173103601);
      } else if (var1 instanceof lllIIII) {
         return IIlIlIl(144641937, 1637112308);
      } else if (var1 instanceof IIIlllll) {
         return IIlIlIl(144641936, 1476977758);
      } else if (var1 instanceof IllIlI) {
         return IIlIlIl(144641939, -1299482204);
      } else if (var1 instanceof lIIIllII) {
         return IIlIlIl(144641938, 459473110);
      } else if (var1 instanceof IIIIIllII) {
         return IIlIlIl(144641941, 829761461);
      } else if (var1 instanceof IIllIIlll) {
         return IIlIlIl(144641940, -1539003182);
      } else if (var1 instanceof III) {
         return IIlIlIl(144641943, -497618715);
      } else if (var1 instanceof IlIIlIlII) {
         return IIlIlIl(144641942, 1670067572);
      } else if (var1 instanceof llIl) {
         return IIlIlIl(144641929, -75753411);
      } else if (var1 instanceof IIIllI) {
         return IIlIlIl(144641928, -402714611);
      } else if (var1 instanceof IIIIIl) {
         return IIlIlIl(144641931, -2099896872);
      } else {
         return var1.IlIIIII() != x.lIllII.ll && var1.IlIIIII() != x.lIllII.IIl ? var1.IlIlI() : IIlIlIl(144641930, -1807431954);
      }
   }

   public III lIIIl() {
      return this.lIlllI;
   }

   public lllI lIIlI() {
      return this.lllllI;
   }

   public void lIIll(class_1297 var1, byte var2) {
      if (var1 != null && !x.IlIII.II(var1)) {
         for(IIIIIIIlI var4 : this.lIlll) {
            if (var4.IIIIIlI() || !var4.IIlIlIl()) {
               var4.II(var1, var2);
            }
         }

      }
   }

   public boolean lIlII(String var1) {
      if (var1 != null && !var1.isBlank()) {
         String var2 = var1.trim();
         if (!var2.startsWith(x.lIlIII.Il(IIlIllI((short)'헅', 811013166, 45136))) && !var2.startsWith(x.lIlIII.Il(IIlIllI((short)'\ue406', -1007399921, 45143)))) {
            return false;
         } else {
            boolean var3 = var2.startsWith(x.lIlIII.Il(IIlIllI((short)7086, 633686701, 45142)));
            String var4 = var2.substring(1).trim();
            if (var4.isEmpty()) {
               return var3;
            } else {
               String[] var5 = var4.split(x.lIlIII.Il(IIlIllI((short)7516, 956580875, 45141)), 3);
               String var6 = var5[0].toLowerCase(Locale.ROOT);
               if (!var6.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)14993, 1421878603, 45140))) && !var6.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)'ײַ', -1482680857, 45147))) && (!var3 || !var6.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)'蓦', 1315455597, 45146))))) {
                  if (!var3 && !var6.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)24036, 302322986, 45145))) && !var6.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)'팚', -539665213, 45144))) && !var6.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)'켪', -1373866956, 45151))) && !var6.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)30439, 1497831472, 45150))) && !var6.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)'\ue9e8', -452698090, 45149))) && !var6.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)'ꚭ', 950749140, 45148))) && !var6.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)24860, -525725896, 45123))) && !var6.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)27309, -1165221896, 45122))) && !var6.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)19123, -896765066, 45121))) && !var6.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)17081, 630086518, 45120))) && !var6.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)32278, 20457946, 45127)))) {
                     return false;
                  } else if (!var6.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)'\ue2a2', 1318659430, 45126))) && !var6.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)'ꓟ', 1062950601, 45125))) && !var6.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)'鷢', -1607380226, 45124)))) {
                     if (!var6.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)23107, -1259449960, 45129))) && !var6.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)'\udc3a', 1480881720, 45128)))) {
                        if (!var6.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)'ꌑ', 360407073, 45174))) && !var6.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)'죂', 1695489481, 45173)))) {
                           if (var6.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)3856, 59908687, 45152)))) {
                              if (var5.length < 2) {
                                 String var103 = x.lIlIII.Il(IIlIllI((short)'闪', -2089192847, 45159));
                                 String var118 = x.lIlIII.Il(IIlIllI((short)25977, 1833204571, 45158));
                                 String var122 = x.lIlIII.Il(IIlIllI((short)27301, -267557107, 45157));
                                 String var76 = x.lIlIII.Il(IIlIllI((short)'\uf8aa', -1004138199, 45156));
                                 String var72 = var122;
                                 String var69 = var118;
                                 String var66 = var103;
                                 lIllIlIl.I(var66 + var69 + var72 + var76);
                                 return true;
                              } else {
                                 IIIIIIIlI var43 = this.llllll(var5[1]);
                                 if (var43 == null) {
                                    String var102 = x.lIlIII.Il(IIlIllI((short)27469, 1556960499, 45163));
                                    String var117 = x.lIlIII.Il(IIlIllI((short)'\ue780', -839642960, 45162));
                                    String var75 = var5[1];
                                    String var71 = var117;
                                    String var68 = var102;
                                    lIllIlIl.I(var68 + var71 + var75);
                                    return true;
                                 } else {
                                    var43.IIlIlll(class_3675.field_16237);
                                    String var101 = x.lIlIII.Il(IIlIllI((short)8858, -2119539874, 45161));
                                    String var116 = x.lIlIII.Il(IIlIllI((short)29432, 958226631, 45160));
                                    String var78 = var43.IIlllII();
                                    String var74 = var116;
                                    String var70 = var101;
                                    lIllIlIl.I(var70 + var74 + var78);
                                    return true;
                                 }
                              }
                           } else if (!var6.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)21481, 709039529, 45167))) && !var6.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)16456, 1976573087, 45166))) && !var6.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)'쌩', -1978385493, 45165))) && !var6.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)'첸', -2144265080, 45164)))) {
                              if (!var6.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)'\uda1b', 4859546, 45064))) && !var6.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)25030, -2034425112, 45071))) && !var6.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)'ꦽ', -2135027819, 45070))) && !var6.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)'餰', 142757301, 45069)))) {
                                 if (!var6.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)'跁', 1297765103, 45068))) && !var6.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)'묥', 1672965195, 45107))) && !var6.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)4764, -1487922606, 45106)))) {
                                    if (var3) {
                                       String var100 = x.lIlIII.Il(IIlIllI((short)14499, 1586784249, 45105));
                                       String var38 = x.lIlIII.Il(IIlIllI((short)6867, 571881301, 45104));
                                       String var86 = var100;
                                       lIllIlIl.I(var86 + var38);
                                       return true;
                                    } else {
                                       return false;
                                    }
                                 } else {
                                    IlIllIII.I(class_310.method_1551(), this);
                                    return true;
                                 }
                              } else {
                                 lIllIIl var42 = lIllIIl.Il();
                                 if (var42 != null) {
                                    var42.I();
                                 }

                                 return true;
                              }
                           } else {
                              IIllIIIIl var41 = new IIllIIIIl(lIllIIl.Il() != null ? lIllIIl.Il().lI() : new IIllIIl());
                              if (var5.length == 1 || var5.length >= 2 && var5[1].equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)'\ude28', 1108025878, 45075)))) {
                                 List var46 = var41.IllI();
                                 String var99 = x.lIlIII.Il(IIlIllI((short)30249, -278523070, 45074));
                                 String var115 = x.lIlIII.Il(IIlIllI((short)29285, -292609687, 45073));
                                 String var80 = var46.isEmpty() ? x.lIlIII.Il(IIlIllI((short)'봘', 1604016385, 45072)) : String.join(x.lIlIII.Il(IIlIllI((short)'頾', 1635256983, 45079)), var46);
                                 String var77 = var115;
                                 String var73 = var99;
                                 lIllIlIl.I(var73 + var77 + var80);
                                 return true;
                              } else {
                                 String var45 = var5[1].toLowerCase(Locale.ROOT);
                                 if (var5.length < 3) {
                                    String var98 = x.lIlIII.Il(IIlIllI((short)27640, 1777355763, 45078));
                                    String var114 = x.lIlIII.Il(IIlIllI((short)'諣', 1342905505, 45077));
                                    String var123 = x.lIlIII.Il(IIlIllI((short)27881, -1989187365, 45076));
                                    String var83 = x.lIlIII.Il(IIlIllI((short)9322, 1104312233, 45083));
                                    String var81 = var123;
                                    String var79 = var114;
                                    String var24 = var98;
                                    lIllIlIl.I(var24 + var79 + var6 + var81 + var45 + var83);
                                    return true;
                                 } else {
                                    String var47 = var5[2].trim();
                                    if (var47.length() > IIlIlIl(144641933, 793252626)) {
                                       var47 = var47.substring(0, IIlIlIl(144641932, -1382001142));
                                    }

                                    if (var45.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)'\ud8c0', -1572705027, 45082)))) {
                                       boolean var50 = var41.IIlI(var47, this);
                                       String var97 = x.lIlIII.Il(IIlIllI((short)'씬', 233208179, 45081));
                                       String var113;
                                       if (var50) {
                                          String var25 = x.lIlIII.Il(IIlIllI((short)'\ued71', 1800997575, 45080));
                                          var113 = var25 + var47;
                                       } else {
                                          String var26 = x.lIlIII.Il(IIlIllI((short)'荫', 494091337, 45087));
                                          var113 = var26 + var47;
                                       }

                                       String var82 = var113;
                                       String var27 = var97;
                                       lIllIlIl.I(var27 + var82);
                                       return true;
                                    } else if (var45.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)30577, 1888360395, 45086)))) {
                                       boolean var49 = var41.lIIl(var47, this);
                                       String var96 = x.lIlIII.Il(IIlIllI((short)21759, -2135151882, 45085));
                                       String var112;
                                       if (var49) {
                                          String var28 = x.lIlIII.Il(IIlIllI((short)'藹', -2050017220, 45084));
                                          var112 = var28 + var47;
                                       } else {
                                          String var29 = x.lIlIII.Il(IIlIllI((short)5435, -1099543700, 45059));
                                          var112 = var29 + var47;
                                       }

                                       String var84 = var112;
                                       String var30 = var96;
                                       lIllIlIl.I(var30 + var84);
                                       return true;
                                    } else if (!var45.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)'逮', 569323940, 45058))) && !var45.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)29671, -674097590, 45057))) && !var45.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)28134, 1766864196, 45056)))) {
                                       if (var45.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)'\ue368', -1245243148, 45060)))) {
                                          boolean var48 = var41.l(var47);
                                          String var95 = x.lIlIII.Il(IIlIllI((short)18699, 1504789726, 45067));
                                          String var111;
                                          if (var48) {
                                             String var85 = x.lIlIII.Il(IIlIllI((short)'퇈', 236414746, 45066));
                                             var111 = var85 + var47;
                                          } else {
                                             String var35 = x.lIlIII.Il(IIlIllI((short)27684, -767732593, 45065));
                                             var111 = var35 + var47;
                                          }

                                          String var37 = var111;
                                          String var36 = var95;
                                          lIllIlIl.I(var36 + var37);
                                          return true;
                                       } else {
                                          return true;
                                       }
                                    } else {
                                       boolean var10 = var41.Illl(var47);
                                       String var94 = x.lIlIII.Il(IIlIllI((short)19412, -750027317, 45063));
                                       String var110;
                                       if (var10) {
                                          String var31 = x.lIlIII.Il(IIlIllI((short)'鑟', -367185446, 45062));
                                          var110 = var31 + var47;
                                       } else {
                                          String var32 = x.lIlIII.Il(IIlIllI((short)28988, 271195690, 45061));
                                          var110 = var32 + var47;
                                       }

                                       String var34 = var110;
                                       String var33 = var94;
                                       lIllIlIl.I(var33 + var34);
                                       return true;
                                    }
                                 }
                              }
                           }
                        } else if (var5.length == 1 || var5.length >= 2 && var5[1].equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)32578, 726865165, 45172)))) {
                           ArrayList var40 = new ArrayList();

                           for(IIIIIIIlI var9 : this.lIIlIl) {
                              if (var9.IIlllll()) {
                                 String var109 = var9.IIlllII();
                                 String var121 = x.lIlIII.Il(IIlIllI((short)'욆', 1505507959, 45179));
                                 String var60 = this.IIlIIII(var9.IIIlIII());
                                 String var58 = var121;
                                 String var57 = var109;
                                 var40.add(var57 + var58 + var60);
                              }
                           }

                           String var93 = x.lIlIII.Il(IIlIllI((short)'ꋅ', -1705637663, 45178));
                           String var61 = var40.isEmpty() ? x.lIlIII.Il(IIlIllI((short)'눋', 935414721, 45177)) : String.join(x.lIlIII.Il(IIlIllI((short)'츏', -1131449594, 45176)), var40);
                           String var59 = var93;
                           lIllIlIl.I(var59 + var61);
                           return true;
                        } else {
                           IIIIIIIlI var39 = this.llllll(var5[1]);
                           if (var39 == null) {
                              String var92 = x.lIlIII.Il(IIlIllI((short)25265, 618951569, 45183));
                              String var108 = x.lIlIII.Il(IIlIllI((short)22436, 112800123, 45182));
                              String var64 = var5[1];
                              String var62 = var108;
                              String var17 = var92;
                              lIllIlIl.I(var17 + var62 + var64);
                              return true;
                           } else if (var5.length < 3) {
                              String var91 = x.lIlIII.Il(IIlIllI((short)16023, 2050236845, 45181));
                              String var107 = var39.IIlllII();
                              String var120 = x.lIlIII.Il(IIlIllI((short)'쭷', -525838860, 45180));
                              String var67 = this.IIlIIII(var39.IIIlIII());
                              String var65 = var120;
                              String var63 = var107;
                              String var18 = var91;
                              lIllIlIl.I(var18 + var63 + var65 + var67);
                              return true;
                           } else {
                              class_3675.class_306 var8 = this.lllll(var5[2]);
                              var39.IIlIlll(var8);
                              String var90 = x.lIlIII.Il(IIlIllI((short)'ﱸ', 551956790, 45155));
                              String var106 = x.lIlIII.Il(IIlIllI((short)'픺', 1713442145, 45154));
                              String var119 = var39.IIlllII();
                              String var10003 = x.lIlIII.Il(IIlIllI((short)'읉', -426285196, 45153));
                              String var23 = this.IIlIIII(var8);
                              String var22 = var10003;
                              String var21 = var119;
                              String var20 = var106;
                              String var19 = var90;
                              lIllIlIl.I(var19 + var20 + var21 + var22 + var23);
                              return true;
                           }
                        }
                     } else if (var5.length < 2) {
                        String var89 = x.lIlIII.Il(IIlIllI((short)23782, -309757256, 45135));
                        String var105 = x.lIlIII.Il(IIlIllI((short)'뭐', 897011446, 45134));
                        String var10002 = x.lIlIII.Il(IIlIllI((short)'隺', -1404749356, 45133));
                        String var56 = x.lIlIII.Il(IIlIllI((short)'釶', 2071268256, 45132));
                        String var54 = var10002;
                        String var52 = var105;
                        String var51 = var89;
                        lIllIlIl.I(var51 + var52 + var54 + var56);
                        return true;
                     } else {
                        IIIIIIIlI var7 = this.llllll(var5[1]);
                        if (var7 == null) {
                           String var88 = x.lIlIII.Il(IIlIllI((short)'螣', 2045379585, 45171));
                           String var104 = x.lIlIII.Il(IIlIllI((short)'큮', -1288802350, 45170));
                           String var55 = var5[1];
                           String var53 = var104;
                           String var13 = var88;
                           lIllIlIl.I(var13 + var53 + var55);
                           return true;
                        } else {
                           var7.IIIlllI();
                           String var87 = x.lIlIII.Il(IIlIllI((short)6552, 1886942510, 45169));
                           String var10001 = var7.IIIIIlI() ? x.lIlIII.Il(IIlIllI((short)10013, -1181277791, 45168)) : x.lIlIII.Il(IIlIllI((short)25507, -1644018306, 45175));
                           String var16 = var7.IIlllII();
                           String var15 = var10001;
                           String var14 = var87;
                           lIllIlIl.I(var14 + var15 + var16);
                           return true;
                        }
                     }
                  } else {
                     String var10000 = x.lIlIII.Il(IIlIllI((short)'\uddc3', 543652638, 45131));
                     String var12 = x.lIlIII.Il(IIlIllI((short)7462, -1655894370, 45130));
                     String var11 = var10000;
                     lIllIlIl.I(var11 + var12);
                     return true;
                  }
               } else {
                  return this.llIlll != null ? this.llIlll.IlIl(var2) : var3;
               }
            }
         }
      } else {
         return false;
      }
   }

   public lIllllll lIlIl() {
      return this.lIIlI;
   }

   public llIIIl lIllI() {
      return this.IIlIIl;
   }

   public IIIIIIIIl lIlll() {
      return this.IlIl;
   }

   public IIlllI llIII() {
      return this.lIlI;
   }

   public IIIIIIIIl llIIl() {
      return this.lIlll();
   }

   public List<llIlIIII> llIlI() {
      return this.lllIlI;
   }

   public lIlIlIII llIll() {
      return this.IIIIIIl;
   }

   public IIIlllI lllII() {
      return this.IlIIl;
   }

   public lllIII lllIl() {
      return this.IIIll;
   }

   private static boolean llllI(IIIIIIIlI var0, String var1) {
      try {
         return var0.getClass().getMethod(var1, class_2596.class).getDeclaringClass() != IIIIIIIlI.class;
      } catch (ReflectiveOperationException var3) {
         return false;
      }
   }

   private class_3675.class_306 lllll(String var1) {
      if (var1 != null && !var1.isBlank() && !var1.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)1122, 2129148469, 45111))) && !var1.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)18287, 1514621884, 45110))) && !var1.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)21339, 1156459400, 45109)))) {
         String var2 = var1.toLowerCase(Locale.ROOT);
         if (var2.startsWith(x.lIlIII.Il(IIlIllI((short)'꽡', 2105954841, 45108))) || var2.startsWith(x.lIlIII.Il(IIlIllI((short)'춷', -79727629, 45115)))) {
            try {
               String var3 = var2.replaceAll(x.lIlIII.Il(IIlIllI((short)31339, 1349191609, 45114)), "");
               if (!var3.isEmpty()) {
                  int var4 = Integer.parseInt(var3);
                  if (var4 >= 1 && var4 <= IIlIlIl(144641935, 226216005)) {
                     return IllllIlI.IllII(var4 - 1);
                  }
               }
            } catch (Exception var9) {
            }
         }

         if (var2.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)'쯒', 1253119102, 45113)))) {
            return IllllIlI.IllII(2);
         } else if (var2.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)27646, 433081826, 45112)))) {
            return IllllIlI.IllII(0);
         } else if (var2.equalsIgnoreCase(x.lIlIII.Il(IIlIllI((short)22013, -475394351, 45119)))) {
            return IllllIlI.IllII(1);
         } else {
            if (var1.length() == 1) {
               char var10 = Character.toUpperCase(var1.charAt(0));
               if (var10 >= IIlIlIl(144641934, -840526306) && var10 <= IIlIlIl(144641921, 298492990)) {
                  return IllllIlI.lllll(IIlIlIl(144641920, 1608354334) + (var10 - IIlIlIl(144641923, 1917119782)));
               }

               if (var10 >= IIlIlIl(144641922, 1005884470) && var10 <= IIlIlIl(144641925, 1190045718)) {
                  return IllllIlI.lllll(IIlIlIl(144641924, -2129208272) + (var10 - IIlIlIl(144641927, 1874874983)));
               }
            }

            try {
               class_3675.class_306 var11 = class_3675.method_15981(var1);
               if (var11 != null && var11 != class_3675.field_16237) {
                  return var11;
               }
            } catch (Exception var8) {
            }

            try {
               String var5 = x.lIlIII.Il(IIlIllI((short)8807, -2102635872, 45118));
               class_3675.class_306 var12 = class_3675.method_15981(var5 + var2);
               if (var12 != null && var12 != class_3675.field_16237) {
                  return var12;
               }
            } catch (Exception var7) {
            }

            return class_3675.field_16237;
         }
      } else {
         return class_3675.field_16237;
      }
   }

   public IIIll IIIIII() {
      return this.lIllll;
   }

   public lIIIlIll IIIIIl() {
      return this.IlIIIl;
   }

   public llIIlIII IIIIlI() {
      return this.IlllII;
   }

   public void IIIIll() {
      class_310 var1 = class_310.method_1551();
      IllllIlI.IIlll(var1);
      this.lllllI.I(var1);
      this.IIlIl.lllI(var1);

      for(IIIIIIIlI var3 : this.lIlll) {
         if (this.IlllII(var3, var1)) {
            var3.Ill();
         }
      }

   }

   public lIIlIl IIIlII() {
      return this.lllIll;
   }

   public IIIlIIIII IIIlIl() {
      return this.IlIlll;
   }

   public void IIIllI(String var1) {
      this.lIIIll.llI(var1);
   }

   public llllIlII IIIlll() {
      return llllIlII.IlI();
   }

   public IIIIlIIl IIlIII() {
      return this.lIIl;
   }

   public lIIlllll IIlIIl() {
      return this.lIlIll;
   }

   public IIlIIlIll IIlIlI() {
      return this.llIIIl;
   }

   public IIllIlII(lIlllII var1) {
      this.lllIlI = Collections.unmodifiableList(this.Illlll);
      this.III = new HashMap();
      this.lI = new HashMap();
      this.llIlI = new HashMap();
      this.lllllI = x.lllI.lll();
      this.lIlIII = var1;
      this.lIllII = (lIIIllll)this.lllI(new lIIIllll());
      this.llIlll = (lI)this.lllI(new lI());
      this.lll = (llIIIIlI)this.lllI(new llIIIIlI());
      this.llll = (IIllllllI)this.lllI(new IIllllllI());
      this.lIllll = (IIIll)this.lllI(new IIIll(this));
      this.lIIlI = (lIllllll)this.lllI(new lIllllll(this));
      this.IlIIIl = (lIIIlIll)this.lllI(new lIIIlIll());
      this.llIIl = (llllIll)this.lllI(new llllIll(var1));
      this.lIIllI = (lIIIlI)this.lllI(new lIIIlI(var1));
      this.IIIIII = (lIlIIIlI)this.lllI(new lIlIIIlI());
      this.IIIIIIl = (lIlIlIII)this.lllI(new lIlIlIII(var1));
      this.lIlI = (IIlllI)this.lllI(new IIlllI());
      this.IlllI = (IIIllIlII)this.lllI(new IIIllIlII());
      this.lIlIIl = (IIIIIIlIl)this.lllI(new IIIIIIlIl());
      this.lllIII = (IIllIIIII)this.lllI(new IIllIIIII());
      this.llIIlI = (lIIIllI)this.lllI(new lIIIllI());
      this.IIlI = (IIIIlllll)this.lllI(new IIIIlllll());
      this.IlIll = (IlIl)this.lllI(new IlIl());
      this.llIllI = (IllIllII)this.lllI(new IllIllII());
      this.IIIlIl = (IIIlllIIl)this.lllI(new IIIlllIIl());
      this.llIlIl = null;
      this.Il = (IIIIIIIl)this.lllI(new IIIIIIIl());
      this.IlIl = (IIIIIIIIl)this.lllI(new IIIIIIIIl());
      this.II = (llIIIllI)this.lllI(new llIIIllI());
      this.IIIIlI = null;
      this.lIIIII = (llIlIlI)this.lllI(new llIlIlI());
      this.IIlIII = (IIIlIlI)this.lllI(new IIIlIlI());
      this.IlllII = (llIIlIII)this.lllI(new llIIlIII());
      this.lIIIl = (lIllIIII)this.lllI(new lIllIIII());
      this.IIIIll = (llIIlIlI)this.lllI(new llIIlIlI());
      this.llIIIl = null;
      this.IlIlIl = (IIlIIllI)this.lllI(new IIlIIllI());
      this.IIIlll = (lIllI)this.lllI(new lIllI());
      this.I = (Illlll)this.lllI(new Illlll());
      this.IIlllI = (IIIIllIIl)this.lllI(new IIIIllIIl());
      this.lIIIIl = (IIIllIIll)this.lllI(new IIIllIIll());
      this.lIlII = (llIIl)this.lllI(new llIIl());
      this.IIIll = (lllIII)this.lllI(new lllIII());
      this.IIlII = (IlIIlllI)this.lllI(new IlIIlllI());
      this.IllIII = (IIIIll)this.lllI(new IIIIll());
      this.lllIIl = (IlIIll)this.lllI(new IlIIll());
      this.lIIlII = (IlIIll)this.lllI(new IlIIll(true));
      this.lIIlll = (IIIIIlIlI)this.lllI(new IIIIIlIlI(var1));
      this.IlIIl = (IIIlllI)this.lllI(new IIIlllI());
      this.IIlIIl = (llIIIl)this.lllI(new llIIIl());
      this.IlI = (IIlllll)this.lllI(new IIlllll());
      this.lIIIlI = (IlIIlIlll)this.lllI(new IlIIlIlll());
      this.IlllIl = (lIII)this.lllI(new lIII());
      this.lIll = (lIlIllII)this.lllI(new lIlIllII());
      this.ll = (IlIIlIlII)this.lllI(new IlIIlIlII());
      this.llIll = (llIl)this.lllI(new llIl());
      this.lIIll = (IIIllI)this.lllI(new IIIllI());
      this.llIIll = (IIIIIl)this.lllI(new IIIIIl());
      this.IlIlll = (IIIlIIIII)this.lllI(new IIIlIIIII());
      this.lllIll = (lIIlIl)this.lllI(new lIIlIl());
      this.llIIII = (llllII)this.lllI(new llllII());
      this.IIIllI = (llIllII)this.lllI(new llIllII());
      this.IIIIIII = (IllllIIl)this.lllI(new IllllIIl());
      this.lIIII = (lllIIIIl)this.lllI(new lllIIIIl());
      this.l = (IIIlll)this.lllI(new IIIlll());
      this.IlIllI = (llIIIlII)this.lllI(new llIIIlII());
      this.IlIIlI = (IIlllII)this.lllI(new IIlllII());
      this.llIl = (llIlII)this.lllI(new llIlII());
      this.IIlll = (IlIIIIl)this.lllI(new IlIIIIl());
      this.IIIIlIl = (lllIllI)this.lllI(new lllIllI());
      this.lIlIl = (llIIlIll)this.lllI(new llIIlIll());
      this.IllIIl = (lllIIlII)this.lllI(new lllIIlII());
      this.IIIlII = (IlI)this.lllI(new IlI());
      this.IlIlI = (IIIlI)this.lllI(new IIIlI());
      this.IllIll = (IlIIllII)this.lllI(new IlIIllII());
      this.IIIIllI = (IlllIIl)this.lllI(new IlllIIl(var1, this.lIllII));
      this.IIIIl = (lIllIll)this.lllI(new lIllIll());
      this.IlIlII = (lllIIII)this.lllI(new lllIIII(() -> this.lIIlIl, this.lIllII));
      this.IlIIll = (IIIlllll)this.lllI(new IIIlllll());
      this.lIlIlI = (IllIlI)this.lllI(new IllIlI());
      this.lllII = (IIIllIIl)this.lllI(new IIIllIIl());
      this.IllI = (lIIIIIIl)this.lllI(new lIIIIIIl());
      this.llIII = (IIIIIlI)this.lllI(new IIIIIlI());
      this.lII = (lIIIllII)this.lllI(new lIIIllII(var1));
      this.IllIl = (IIIIIllII)this.lllI(new IIIIIllII(() -> this.lIIlIl, this.lIllII));
      this.lllIl = (IIllIIlll)this.lllI(new IIllIIlll(this.lIllII));
      this.IlII = (llIlIl)this.lllI(new llIlIl());
      this.llllI = (lIIlIlIl)this.lllI(new lIIlIlIl());
      this.IIll = (IIllIllIl)this.lllI(new IIllIllIl());
      this.IllII = (IllIIIlI)this.lllI(new IllIIIlI());
      this.lIIl = (IIIIlIIl)this.lllI(new IIIIlIIl());
      this.lIII = (llIlIII)this.lllI(new llIlIII());
      this.llII = (lIl)this.lllI(new lIl());
      this.IIllI = (lllIlIll)this.lllI(new lllIlIll());
      this.IllIlI = (IlIIII)this.lllI(new IlIIII());
      this.llI = (IIlIll)this.lllI(new IIlIll());
      this.lllll = (IllIIII)this.lllI(new IllIIII(var1));
      this.lIIIll = (llIIIlll)this.lllI(new llIIIlll());
      this.IIIlI = (IllI)this.lllI(new IllI());
      this.lIl = (IIlIlII)this.lllI(new IIlIlII());
      this.Ill = (lIIIIlll)this.lllI(new lIIIIlll());
      this.lllI = (IIIII)this.lllI(new IIIII(var1));
      this.Illl = (IIIIllIl)this.lllI(new IIIIllIl());
      this.llllll = (llIlIIl)this.lllI(new llIlIIl());
      this.llllII = (lIIIll)this.lllI(new lIIIll());
      this.lIllIl = (IIIlIllll)this.lllI(new IIIlIllll());
      this.IIIIIl = (IlIlIIII)this.lllI(new IlIlIIII());
      this.IIIII = (lIIIIIl)this.lllI(new lIIIIIl());
      this.IIIl = null;
      this.lIllI = (IIIlIIll)this.lllI(new IIIlIIll());
      this.lIlllI = (III)this.lllI(new III());
      this.llllIl = (IIllIIlIl)this.lllI(new IIllIIlIl());
      this.IIIIlll = (IllllllI)this.lllI(new IllllllI());
      this.llIlII = (IIIlII)this.lllI(new IIIlII());
      this.IIIIlII = (IIIlIllI)this.lllI(new IIIlIllI());
      this.IIIIIll = (lIlIIII)this.lllI(new lIlIIII());
      this.IllllI = (lIllIlII)this.lllI(new lIllIlII());
      this.lIlIll = null;
      this.IIlIlI = null;
      this.IIl = (IlIIIlIII)this.lllI(new IlIIIlIII());
      this.IIIIIlI = (IllIIIll)this.lllI(new IllIIIll());
      this.IIlIl = (IlllIllI)this.lllI(new IlllIllI());
      this.IIII = (IIIIIIlII)this.lllI(new IIIIIIlII());
      this.IlIII = (IIllIllll)this.lllI(new IIllIllll());
      this.IIllII = (llIlIIIl)this.lllI(new llIlIIIl());
      this.IIllll = (IIllIlIll)this.lllI(new IIllIlIll());
   }

   public void IIlIll(class_310 var1) {
      if (var1.method_22683() != null && var1.field_1755 == null) {
         long var2 = var1.method_22683().method_4490();

         for(IIIIIIIlI var5 : this.lIlll) {
            if (var5.IIlIlIl() && var5.IIlllll()) {
               class_3675.class_306 var6 = var5.IIIlIII();
               boolean var7 = !this.IlIIII(var6) && IllllIlI.IlIII(var1, var6);
               boolean var8 = (Boolean)this.llIlI.getOrDefault(var5, false);
               if (!var5.IIIIIIl() && var7 && !var8) {
                  var5.IIIlllI();
               }

               this.llIlI.put(var5, var7);
            }
         }

      }
   }

   public lIIlIlIl IIllII() {
      return this.llllI;
   }

   public IIIllIIll IIllIl() {
      return this.lIIIIl;
   }

   public lllIIII IIlllI() {
      return this.IlIlII;
   }

   public boolean IlIIII(class_3675.class_306 var1) {
      return this.lllllI.ll(var1) || this.IIlIl.lII(var1);
   }

   public IllllllI IlIIIl() {
      return this.IIIIlll;
   }

   public IIIIIIlIl IlIIlI() {
      return this.lIlIIl;
   }

   public IIIIll IlIIll() {
      return this.IllIII;
   }

   public IlIl IlIlII() {
      return this.IlIll;
   }

   public IlllIllI IlIlIl() {
      return this.IIlIl;
   }

   public IlIIlIlll IlIllI() {
      return this.lIIIlI;
   }

   public llIlIlI IlIlll() {
      return this.lIIIII;
   }

   public boolean IllIII(double var1, double var3, int var5) {
      class_310 var6 = class_310.method_1551();
      if (var6 == null) {
         return false;
      } else {
         for(int var7 = this.lIIlIl.size() - 1; var7 >= 0; --var7) {
            IIIIIIIlI var8 = (IIIIIIIlI)this.lIIlIl.get(var7);
            if ((var8.IIIIIlI() || !var8.IIlIlIl()) && var8.lllIIl(var1, var3, var5)) {
               return true;
            }
         }

         return false;
      }
   }

   public IIllIIlll IllIIl() {
      return this.lllIl;
   }

   public lllIlIll IllIlI() {
      return this.IIllI;
   }

   public IIIIllIl IllIll() {
      return this.Illl;
   }

   private boolean IlllII(IIIIIIIlI var1, class_310 var2) {
      return var1.IIIIIlI() || !var1.IIlIlIl() || var1.IIlI(var2);
   }

   public lIlIllI IlllIl() {
      return this.IIIl;
   }

   public IIIIIIlII IllllI() {
      return this.IIII;
   }

   public void Illlll(class_2596<?> var1) {
      if (var1 != null) {
         String var2 = var1.getClass().getSimpleName();
         if (var2.equals(x.lIlIII.Il(IIlIllI((short)'\ue5cb', 403965177, 45117))) || var2.equals(x.lIlIII.Il(IIlIllI((short)13019, 630271088, 45116)))) {
            IllllIlI.III();
            x.IlIlIl.IlIIl();
         }

      }
   }

   public lIllIlII lIIIII() {
      return this.IllllI;
   }

   public lIIIlI lIIIIl() {
      return this.lIIllI;
   }

   public IIlIIllI lIIIlI() {
      return this.IlIlIl;
   }

   public Illlll lIIlII() {
      return this.I;
   }

   public llIIIlII lIIlIl() {
      return this.IlIllI;
   }

   private boolean lIIllI(class_310 var1, IIIIIIIlI var2) {
      boolean var10000;
      if (var2 instanceof llIlIIII var3) {
         if (IIIllllll.l(var1, var3)) {
            var10000 = true;
            return var10000;
         }
      }

      var10000 = false;
      return var10000;
   }

   public lIIIIIl lIIlll() {
      return this.IIIII;
   }

   public IIIIIlI lIlIII() {
      return this.llIII;
   }

   public lIII lIlIIl() {
      return this.IlllIl;
   }

   public IIlIll lIlIlI() {
      return this.llI;
   }

   public IlIIllII lIlIll() {
      return this.IllIll;
   }

   public void lIllII(class_1297 var1) {
      if (!x.IlIII.II(var1)) {
         if (IllllIlI.IIIllI()) {
            if (this.lIlIIl != null && this.lIlIIl.IIIIIlI()) {
               this.lIlIIl.III(var1);
            }

         } else {
            for(IIIIIIIlI var3 : this.lIlll) {
               if (var3.IIIIIlI() || !var3.IIlIlIl()) {
                  var3.III(var1);
               }
            }

         }
      }
   }

   private Comparator<IIIIIIIlI> lIllIl(lIllII var1) {
      return Comparator.comparingInt((var2) -> this.IlIlI(var1, var2)).thenComparing(IIIIIIIlI::IIlllII);
   }

   public lIllll lIlllI() {
      return this.llIlIl;
   }

   public void lIllll(class_2596<?> var1) {
      if (var1 instanceof class_2868) {
         IllllIlI.llIlI(var1);
      } else if (var1 instanceof class_2828) {
         x.IlIlIl.IIllI(var1);
      }

      if (var1 instanceof class_2824) {
         for(IIIIIIIlI var3 : this.IIlIll) {
            if (var3.IIIIIlI() || !var3.IIlIlIl()) {
               var3.IIlIIlI(var1);
            }
         }

      }
   }

   public lllIllI llIIII() {
      return this.IIIIlIl;
   }

   public lIllI llIIIl() {
      return this.IIIlll;
   }

   public llllIll llIIlI() {
      return this.llIIl;
   }

   public void llIIll(class_310 var1) {
      if (var1 != null) {
         IllllIlI.IIll(var1);
         boolean var2 = false;

         for(IIIIIIIlI var4 : this.lIlll) {
            if (this.IlllII(var4, var1) && var4.IIIlIIl(var1)) {
               var2 = true;
               break;
            }
         }

         if (var2) {
            IllllIlI.IllIIlI(var1);

            try {
               for(IIIIIIIlI var29 : this.lIlll) {
                  if (this.IlllII(var29, var1) && var29.IIIlIIl(var1)) {
                     var29.IllI(var1);
                  }
               }
            } finally {
               IllllIlI.IIIlII();
            }
         }

         try {
            for(IIIIIIIlI var30 : this.lIlll) {
               if (this.IlllII(var30, var1)) {
                  var30.lllIl(var1);
               }
            }
         } finally {
            try {
               IllllIlI.IIllII(var1, null.II);
            } finally {
               IllllIlI.IIlIlll();
            }
         }

      }
   }

   public IIIllIlII llIlII() {
      return this.IlllI;
   }

   public void llIlIl(class_310 var1) {
      if (var1 != null) {
         for(IIIIIIIlI var3 : this.lIlll) {
            if (var3.IIIIIlI() || !var3.IIlIlIl()) {
               var3.IIIIlll(var1);
            }
         }

      }
   }

   public lIlIllII llIllI() {
      return this.lIll;
   }

   public IIIlIIll llIlll() {
      return this.lIllI;
   }

   public lllIIIIl lllIII() {
      return this.lIIII;
   }

   public llIl lllIlI() {
      return this.llIll;
   }

   public IlIIll lllIll() {
      return this.lllIIl;
   }

   public IIIlllIIl llllII() {
      return this.IIIlIl;
   }

   public void llllIl(class_310 var1) {
      if (var1 != null) {
         IllllIlI.IllIIlI(var1);

         try {
            for(IIIIIIIlI var3 : this.lIlll) {
               if (this.IlllII(var3, var1) && !var3.IIIlIIl(var1)) {
                  var3.IllI(var1);
               }
            }
         } finally {
            IllllIlI.IIIlII();
         }

      }
   }

   public IlIlIIII lllllI() {
      return this.IIIIIl;
   }

   public IIIIIIIlI llllll(String var1) {
      if (var1 != null && !var1.isBlank()) {
         for(IIIIIIIlI var3 : this.lIIlIl) {
            if (var3.IIllllI().lllI(var1)) {
               return var3;
            }
         }

         for(IIIIIIIlI var8 : this.lIIlIl) {
            if (var8.IIlllII().equalsIgnoreCase(var1)) {
               return var8;
            }
         }

         String var7 = var1.replaceAll(x.lIlIII.Il(IIlIllI((short)28922, -1883307363, 45091)), "");

         for(IIIIIIIlI var4 : this.lIIlIl) {
            String var5 = var4.IIlllII().replaceAll(x.lIlIII.Il(IIlIllI((short)16986, 1267344934, 45090)), "");
            if (var5.equalsIgnoreCase(var7)) {
               return var4;
            }
         }

         return null;
      } else {
         return null;
      }
   }

   public <T extends IIIIIIIlI> T IIIIIII(Class<T> var1) {
      IIIIIIIlI var2 = (IIIIIIIlI)this.III.get(var1);
      if (var2 != null) {
         return (T)(var1.cast(var2));
      } else {
         for(IIIIIIIlI var4 : this.lIIlIl) {
            if (var1.isInstance(var4)) {
               return (T)(var1.cast(var4));
            }
         }

         return null;
      }
   }

   public IIlllII IIIIIIl() {
      return this.IlIIlI;
   }

   private void IIIIIlI(class_332 var1, int var2, int var3, float var4) {
      class_310 var5 = class_310.method_1551();
      if (var5 != null) {
         boolean var10000;
         label72: {
            IIIIIIllI.II((double)1.0F);
            IlIlIll.IlIIIl(var5);
            class_437 var8 = var5.field_1755;
            if (var8 instanceof lIIIllIl) {
               lIIIllIl var7 = (lIIIllIl)var8;
               if (var7.IlIIlII() == IIIlIlIII.l) {
                  var10000 = true;
                  break label72;
               }
            }

            var10000 = false;
         }

         boolean var6 = var10000;

         for(IIIIIIIlI var10 : this.lIIlIl) {
            if (var10 != this.lII && !this.lIIllI(var5, var10) && (!var6 || !(var10 instanceof llIlIIII)) && (var10.IIIIIlI() || !var10.IIlIlIl())) {
               var10.IIIlI(var1, var2, var3, var4);
            }
         }

         if (!var6 && !this.lIIllI(var5, this.lII) && (this.lII.IIIIIlI() || !this.lII.IIlIlIl() || IIlllIlI.II().Il())) {
            this.lII.IIIlI(var1, var2, var3, var4);
         }

      }
   }

   public lI IIIIIll() {
      return this.llIlll;
   }

   public List<IIIIIIIlI> IIIIlII() {
      return this.lIIlIl.stream().toList();
   }

   public void IIIIlIl(class_332 var1, int var2, int var3, float var4) {
      class_310 var5 = class_310.method_1551();
      if (var5 != null) {
         this.IIIIIlI(var1, var2, var3, var4);
      }
   }

   public lIlIIIlI IIIIllI() {
      return this.IIIIII;
   }

   public IlIIII IIIIlll() {
      return this.IllIlI;
   }

   public llIlIllI IIIlIII() {
      return this.IIlIlI;
   }

   public IIIlI IIIlIIl() {
      return this.IlIlI;
   }

   public lllIII IIIlIlI() {
      return this.IIIll;
   }

   public IlllIIl IIIlIll() {
      return this.IIIIllI;
   }

   public llllII IIIllII() {
      return this.llIIII;
   }

   public IllIllII IIIllIl() {
      return this.llIllI;
   }

   public IlIIlllI IIIlllI() {
      return this.IIlII;
   }

   public llIIIllI IIIllll() {
      return this.II;
   }

   private String IIlIIII(class_3675.class_306 var1) {
      if (var1 != null && var1 != class_3675.field_16237) {
         String var2 = var1.method_1441();
         if (var2.startsWith(x.lIlIII.Il(IIlIllI((short)26163, -833403047, 45088)))) {
            return var2.substring(IIlIlIl(144641926, -309981342)).toUpperCase(Locale.ROOT);
         } else if (var2.startsWith(x.lIlIII.Il(IIlIllI((short)'뛼', -96772790, 45095)))) {
            String var10000 = x.lIlIII.Il(IIlIllI((short)'ꟑ', -1438048029, 45094)).toUpperCase(Locale.ROOT);
            String var4 = var2.substring(IIlIlIl(144641977, 617898817));
            String var3 = var10000;
            return var3 + var4;
         } else {
            return var2.toUpperCase(Locale.ROOT);
         }
      } else {
         return x.lIlIII.Il(IIlIllI((short)'\ueb55', 634061488, 45089));
      }
   }

   public void IIlIIIl(class_2596<?> var1) {
      if (var1 != null) {
         for(IIIIIIIlI var3 : this.Illll) {
            if (var3.IIIIIlI() || !var3.IIlIlIl()) {
               var3.IIIIllI(var1);
            }
         }

      }
   }

   public lIl IIlIIlI() {
      return this.llII;
   }

   public IIlIlll IIlIIll() {
      return this.IIIIlI;
   }

   public IIIIIl IIlIlII() {
      return this.llIIll;
   }

   private static int IIlIlIl(int var0, int var1) {
      return IIIlIII[var0 ^ 144642009] ^ var1 ^ var0;
   }

   static {
      short var6 = 9672;
      String var7 = "皹疲痕痰皻皷痕皸盓皶皾痰皡盏皣盁皵痨痧痧皾疲疗皶沍槆污沌沏沃污汴沧沂沊沌沕汻沗汵沁榙沩沓\ued97\uedf0\ued7b\uedb2\ued95\ued59\ued7b\uedaa\ued5d\ued5c\ued94\uedb2\ued8f\ued61\ued8d\ued75굏\uffd9굓굓港湩渳渳ᕸᗲᕼᕼ삶삽샇샄蚣蛄藗蚙蚢藯蚙藩狽狾猉猧猰猑猧狷狴猖栠栠┎⓵䨟䨟꙲ꗺꌹꙮ꙲ꙕꍏꌞ\ue300\ue2d8흩흧풃푣풒푺풧풤푚푺풎풋탗탗옕엵엘엠옱옖움엠엜엝왦썁흭\ud842\ue301흱흭\ud851\ue2fd\ue2fd㖒㖂㕜㕽㖈㕺㙀㖰㐂㏢㏠㓀㐧㐔㐎㐉䎱䒹䎇䎅䎱䎏䎕䎋䍛䎎䓂䓂㍹㎳㏔㎆㎰㎑㎈㒠⺂\u2e61⹝\u2e74⺁⹜⫨⫨횯틧홸홚횩홢횬홚횆횓펼펿㝾㝝㝡㡀㝽㝘㟬㟬ᨓᨩᝅᝅᕄࠌᕋࡕᕆ\u086dᕇࡕࡩࡰ߷ߴ䠗唿䟾䠏䠨䠂䣀䟟䟙䠲䠱䟹䟛䠉䡥䡥㏤㓐㓍㒡㏫㓅㒡㒢㓄㏯㒶㓆㓆㓍㒿㒢㓈㓃㎂㏱㏮㓍㏰㓏㓓㓃㒿㒟㒟㍸㓄㒘㏯㎧㒣㏱㓑㒿㓁㏖㎥㒝㏬㓄㏮㓅㒣㓈㓑㓑㏯㓄㒘㓃㓃㎀㎧㒡㏦㓒㎦㏳㏥㏔㒿㓍㏫㏕㏬㒴㏖㒟㓓㒵㏔㓆㒴㏖㒴㒡㒣㎤㎦㓋㏮㓍㒸㏳㒢㏧㏯㒝㒶㍸㎧㒣㏮㍸㏕㒣㓒㓄㓏㒡㒽㓍㏔㏳㏬㏫㓓㏖㓅㒡㒝㓄㓒㎀㏦㏨㏬㏫㒘㓈㒿㏳㏤㒶㏫㓍㍸㓏㒠㒴㏖㒟㓓㒵㓎㒢㒵㒝㏪㓏㒘㎤㓊㒘㏩㒝㏔㏨㓄㏧㓄㏔㓑㓂㓂㒘㏩㏯㏤㓋㓅㒘㓇㏖㎦㎤㒸㒴㏯㍸㒢㓎㓏㒴㓃㓄㓒㒝㏦㓉㒠㍸㓂㒣㍸㏦㏨㓊㏫㎃㒝㓈㓂㏫㏮㓋㒟㏯㎥㏨㓓㏖㒴㒡㒣㎤㎦㒝㒠㎤㓏㓐㓑㓉㎀㓌㒢㒡㓂㒣㏫㏲㓂㍼īċĥąĮùćĄ悺患徯徯惮撦惧憶惭憻憵懆懄惫惬惤憢憴撰撰暼斮暸暸塀神綾嘆殺參卑禍ꨝԔӷԥӶԇ꩐Ԯԧԭԑԕ囌善嚡嗔囋嚝嗳嗤嗦囍囎囆嚸嗖啚啚쿐쾸쾞쿌쾷쾶쾸컭컦쿒쿅쿍쾠퉙쾚컱컭튅쿍컩퉟쿋퉡퉡ⱳ⯻⤺⥋ⱔⱦ⥌⤛⤝ⱖⱕ⤽⤟⥍ⰁⰁモヾヘ\u3102ㄊ㇀\u3102ㄥ\u3102ㄲメ㘛䟻䟷唾䟵䠳䟟䟹䠯䟛䟟䠗䠅緫纸綧緗緫纷絻絻䕎䕈㟞㟞潡澧烎澥澆潾烒烒㋖㙟㚆㚦㋕㚇㋫㋫\uf6e2ﱊ\uf70b\uf6fa\uf6e1\uf6f7\uf6f9\uf72a\uf6e0\uf707\uf6d8\uf7c0\uf72e\uf730ﰴﰴ资贘资贷赋恧忛忛ꈝ봔볽ꈡ캘칀컍췰컇컑캿캠췪캡캢컊췬캺쵶쵶쒓쒫쒑쒇쑜쑙쒫쒂쒩쑝쒊쑢쒃솶쑵쑾쒂쇊쑢쒦솴쑘쇎쇎쬲ꀺ쫻쬊쬱쬧쬉쫚쬐쬗쬨쬰쫞쯀齤齤樑朼杁朡樒橤櫀櫀\uf2dd\ue835\uf308\uf325\uf2de\uf30c\uf326\uf315\uf333\uf2dc\uf2db\uf313\uf331\uf303\ue84f\ue84f扴扷抓报扞扟德抯ᐒᄻᅂᄢᐑᅃᐏᐏ\ue2f6\ue326\ue310\ue2f9\ue2f4\ue2fe\ue30c\ue2fc飢鹊餋飺飡飷飹餪飠餇飘駀餮餰鸴鸴௲\u0b78௮௮㓠㔐㔦㓣㔪㓘㔲㓢ࡄጭጊዼጋዚࠡጳዺጔᏀጬ︓\ufb1b\ufdda︫ﷴ︆︬ﷻ﷽ﷶﷵ\ufddd﷿︭ﬡﬡ槬檴槪槰櫃櫂檴檙櫒槦槱檹檜榭槮櫅檙榱檹檝榫檿榕榕銃軫銪鉛銤銖鉜銋銍銦銥銭銏鉝軱軱윻윣윹읐쩔쩰읁윣윟읏쩰쨦밫륃밤밗밫믠믶밇࿙ﵑူဲ챺챚첋첃챾챹챣첃챷첒죮죮ꌎꌮꋿꋷꌊꌍꌗꋷꌃꌦ頝頚➳❵⟰❷➨⡀⟤⟤\u19ceᲆᧇᣖ\u19cdᦛᣕᣦᣤ\u19cb\u19ccᧄᧂᣔᲐᲐ⡃㌃❤❗❫⠠⠶⡇⡇㋸❖⡐곛곟곛귀곴괰剄剄㱛㣖㦻㲇놋늣녢놳놌녞놔놃놥놎농놅놧놕늙늙\uf525\ud973\uf4f9\uf4f9괚+굇굇聨翙翾耥翼耈耈翷翢考聩聩퓴픖퓜퓺픓픯먣먣䱉䛡䱄䭱䱊䱐䭲䱁䭧䜀䱏䱇䭥䭗䛛䛛趁軁趂趕趩趮趈超趑趈起赝起趐趂趗起軂趩趱㕴㕶㖔㕢㕟㕸㖎㖲㖁㖥㕝㖭㖗㖰㕼㖳㖂㖒㕡㕡㕜㕠㕡㖅㖱㕶㖱㕡㖂㖨㖥㛉଼ศଵଢ\u0e70\u0b34\u0de0\u0de0\uf0d2\uef5a\uf09b\uefea\uf0d1\uf0c7\uefe9\uf0ba\ueff0\uf0b7\uf0c8\uf0d0\uf0be\uf0a0\uef84\uef84뎯돯덠덻뎧뎤덚뎋덟덛듁뎍뎄뎬뎬뎰뎎뎒뎇돗\ue7c7\ue7a1\ue6e7\ue7b5\ue7cc\ue6f3\ue799\ue6e5\ue6d6\ue6f2\ue7ca\ue7ba\ue6e4\ue6ea\ue799\ue7ba\ue6e8\ue7b5\ue7d2\ue7b6\ue7cf\ue7bb\ue7b6\ue7d2\ue6e6\ue7a1\ue6e6\ue7b6\ue6d5\ue7c3\ue6f2\uea5e慓摗摫摦慒愾揞摰㾧㽣㽟㾒ଃବ\u0ade\u0b12ଁଭ\udf73ଉᛞᰶᛷᜦᛝᜋᜥ\u1716᜔ᛛᛜᛴᜲᜤᜀᜀ횛핛횜훏훓훈헮횿헫헮횷횽헮헖훐헲헭횜훋헫핝훉핣핣풎풌풮풐푡푺푴푠푿푻푣풳풩풂텀푙푻퇓푚풁풇퇓푣풔풭퇏풃푞풔푘풐푽퇋풍톷톷夭壜壻夈太夦大壷ﻹͱ４ﻡﻺﻠﻢ１ﻷＰ\ufeff７ﻵ＇ͫͫ\uf348\uf608\uf337\uf344\uf350\uf31b\uf341\uf654\uf338\uf341\uf350\uf673\uf666\uf339\uf341\uf33f\uf666\uf60c\uf321\uf344\uf34b\uf33d\uf346\uf6c0間镵閳镡閐閧閍閱閂閦镞閮閨长镵閧镽雎閏镺镞閑镞閭閔雒镾镣閭镙镡閤隶镴雊雊\udaa3\ud989\udabb\uda99ꮻꯍꮡꮸ꫰ꯈ꺬꺬沓榛沥沧沓沭汷沩汹池槄槄萦菠葯菙萃萎萋葳\uef10\ueefd\uef31\ueed8\ueedb\uef15\ueeda\uf44c휆휖ퟀ휗휅휈훘휬絉逅遨紹絍絊迡絃絁絇絉遨遪紼級素ⶦⷮ\u2dafⵞⶥⶳⵝⶎⶌⶃⶤⶬⶊⵜⷨⷨﰛﱃﰙﱏﰴﱑﱃﭪﱁﰵﰢﰾﭫ\uf6deﭳﰾﭭﰝ\uf6dcﱊ\uf6d9ﭗﱒ\uf700ﰽﱂﱐﱌﭯﰡ\uf6ddﰾﰴ\uf700ﰼﰹﰠﰺﰷﱌﰣﭗ\uf6dfﱃ\uf6daﭯﱒﰿﭬﰴﭖﰺﭮ\uf6deﭯﭲﰷﭯﱂﭬ\uf6dcﰝ\uf6f4ﰺﰷﭲﱌﱊ픔픨픔픧퓻퓷륫륫ꢒꢈꢒ떴ꢑꢕ뗉뗉鷶鬞鸑鷻鷷鷺鷜魆䉇䅱䉏䈹䈡䉓䉎\udd08\uf8fa\uf8f5ﵩﵩ榮楢楝槱ㆣフㅀㆠ㇄ㆽラヮꆐꅺꆦꆱꅛꆃꋏꋏ緔纻絼纟緗绌絻絸鐾輔鐡鐙輗鐿鐝鐶鐶鐵輱輀鑆輀輨鑃鑈鑈輬輬룲릛릹릷릹맓룩맇맊릣말맆릢맊룕맒릢릟범룪림맋룦룧맋벩법벗맋벲맆룧릿릢벳릝艥舀艮罄艮缘缾缴缝艮艩网罓舀舁罋缵艱缷罉艤艕艭罄罄舁艗艗罅罃臹臹캔쮻칽쮾쮽캐캓친칵칞캯칵칟칠캇캲캒캬쯂쯂搧愠搪摩摪搋揘搏揢搉揼揢搌揻援搥搅揿摕摕쑐쐚쑐뻞쐟쐻뼇뼇ﵿﷱﶄﵜ\ufdd6ﵾ\ufd90ﵷﵷﶈ\ufdd4ﶍﶇﶍ\ufdd5ﶂﵵﵵ\ufde9\ufde9\udcda䉈\udd25\udcfd䉓\udcdb\udd31\udd2c\udd31\udd14䈚\udd32\udd31\udd06\udd00\udd00罒缸缚缠罈罆缛臡";
      char[] var8 = "◐◜◘◌◌◌◌◀◄◌◀◌◄◄◀◀◀◄◀◀◄◀◌◄◘┬◀◌◘◌◀◄◘◐◘◄◄◀◌◀◀◘◀◌◘◐◘◀◘◀◀◀◘◌◀◄◘◐◘◄◀◌◄◄◀◘◄◀◌◘◌◌◄◀◘◜◨◀◘◜◨◀◌◀◘◐◬◀◘◐◬◌◀◄◀◀◀◘◘▌◀◀◀◀◌◌◀◀◀◜◬◨◜◜◀◜◘◀".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IIIlIIl = var9;
            IIIlIlI = new Object[var9.length];
            int var2 = 2093085055;
            byte[] var0 = "\u0015\u0015ØìÅUÃ\u0092\u0083ÚDÝ\u0090)]\u0082§çÆC×\u0092ñ²U\u0097\u0094;~¾\"M\u0016?<ÖvíùÔÈý²\u0007¿\u008bÏÉò¥tt<¢\u0002E\u001bÞQ\u0089yDWÚ¦o75:òhRKá§\u0003)k\u0093x§\u0083©£¨öQª\u0006\u0098¨ ÎÜa¸Ã}ÎwbñôZsJ)+´\u0098O¾eÿH\u001aG1ç\u00ad)\u0097vìºÝ]]\u008b0%{ý\u0090B»\u001dÐ\u008d\u0090p\"üã\u0005FVz½Ð\u0096º\u00adòç2ñ8\u0019\u0098À\u0016\u0006jfRcâv)@\u009fl\u00ad«M\fùÝç\u0090Á\u0000Á7\u001d\u008d\u0007\u009fv¹ïìr %\u0005TDS²4«ä6\u0080*ä\u0090H\u0084Ý\u0087ý\u009f³ªU]\u008c\u0085µh#\u0082îÜ\u0098[áîc\u008aÌÿþNSù@{4ë¤½ònÖ6Pà\u0082\u00056wAºxå%ã\u0013É\u0090¤\u0001ùäÍD\u000b\u0094\u0004\u001d\u0092ó4\u0090Çò¨\u0007ð]ÎM!é\u0015Ê¤\u0018,V\u0018JÆÕ\u0085²o=üÃE+Û±Ð\u001aPÝ\u0096\b\fÕ\u0017ÕÉM\u008f\"ä\r\u0093¡ìFö\u0088á\u009eà\u001a:§[\u0016íôÙþ¨íy%6½¹¸h®e\u0094Z\u009a+\u0083t \u0006\u001a\u0013\u009bOªjû2°VÕõH\"û\u001b\u009e¬¯\u0099Øñ\u0096P\u008a\u009d\u008d".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IIIlIII = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IIIlIII[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static String IIlIllI(short var0, int var1, int var2) {
      int var3 = var2 ^ '끓';
      char[] var4 = IIIlIIl[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])IIIlIlI[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         IIIlIlI[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 3836;
      int var9 = 0;

      do {
         int var10 = var4[var9] + 15997;
         var10 -= 38225;
         var10 ^= 10643;
         var10 += 40835;
         var10 -= 54241;
         var10 += 51978;
         var10 ^= 22123;
         var10 -= 51106;
         var10 -= 1183;
         var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
