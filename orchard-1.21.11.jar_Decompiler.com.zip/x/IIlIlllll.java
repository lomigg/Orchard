package x;

import java.awt.GraphicsEnvironment;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.util.Locale;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_3675.class_307;

@Environment(EnvType.CLIENT)
public final class IIlIlllll {
   private static final int I;
   private static final boolean l;
   private static final boolean II;
   private static final Object Il;
   private static final int[] lI;
   private static final String[] ll;
   private static final Object[] III;

   private static boolean I(class_310 var0) {
      return var0 != null && var0.field_1755 == null && var0.method_1569() && var0.method_22683() != null;
   }

   private static int l(int var0) {
      if ((var0 < IIl(1504477831, 1532645488) || var0 > IIl(1504477830, 1804188159)) && (var0 < IIl(1504477829, -2057878856) || var0 > IIl(1504477828, 397101094))) {
         if (var0 >= IIl(1504477827, 1575860828) && var0 <= IIl(1504477826, -1992872885)) {
            return IIl(1504477825, -1321003829) + var0 - IIl(1504477824, -247938625);
         } else if (var0 >= IIl(1504477839, 121294773) && var0 <= IIl(1504477838, -2074316585)) {
            return IIl(1504477837, -503386706) + var0 - IIl(1504477836, 1650281791);
         } else if (var0 >= IIl(1504477835, 958691194) && var0 <= IIl(1504477834, 1619516907)) {
            return IIl(1504477833, -755444323) + var0 - IIl(1504477832, -1131127547);
         } else {
            int var10000;
            switch (var0) {
               case 32:
                  var10000 = IIl(1504477847, 386422119);
                  break;
               case 39:
                  var10000 = IIl(1504477846, -1631185603);
                  break;
               case 44:
                  var10000 = IIl(1504477845, -1856010640);
                  break;
               case 45:
                  var10000 = IIl(1504477844, -1882764202);
                  break;
               case 46:
                  var10000 = IIl(1504477843, -1751347691);
                  break;
               case 47:
                  var10000 = IIl(1504477842, 285856317);
                  break;
               case 59:
                  var10000 = IIl(1504477841, -1084450202);
                  break;
               case 61:
                  var10000 = IIl(1504477840, -1621053881);
                  break;
               case 91:
                  var10000 = IIl(1504477855, -1249082146);
                  break;
               case 92:
                  var10000 = IIl(1504477854, 584962085);
                  break;
               case 93:
                  var10000 = IIl(1504477853, 1372043525);
                  break;
               case 96:
                  var10000 = IIl(1504477852, 137089173);
                  break;
               case 256:
                  var10000 = IIl(1504477851, 195210208);
                  break;
               case 257:
                  var10000 = IIl(1504477850, 843347173);
                  break;
               case 258:
                  var10000 = IIl(1504477849, 302479691);
                  break;
               case 259:
                  var10000 = IIl(1504477848, -1500692710);
                  break;
               case 260:
                  var10000 = IIl(1504477863, 482421415);
                  break;
               case 261:
                  var10000 = IIl(1504477862, -1964124931);
                  break;
               case 262:
                  var10000 = IIl(1504477861, -1342998813);
                  break;
               case 263:
                  var10000 = IIl(1504477860, -1233482171);
                  break;
               case 264:
                  var10000 = IIl(1504477859, 1075449507);
                  break;
               case 265:
                  var10000 = IIl(1504477858, -1311336869);
                  break;
               case 266:
                  var10000 = IIl(1504477857, -350394593);
                  break;
               case 267:
                  var10000 = IIl(1504477856, 1321277627);
                  break;
               case 268:
                  var10000 = IIl(1504477871, -767423282);
                  break;
               case 269:
                  var10000 = IIl(1504477870, -1446184612);
                  break;
               case 280:
                  var10000 = IIl(1504477869, -1731359883);
                  break;
               case 281:
                  var10000 = IIl(1504477868, -1886994622);
                  break;
               case 282:
                  var10000 = IIl(1504477867, 1390233700);
                  break;
               case 283:
                  var10000 = IIl(1504477866, 1329485778);
                  break;
               case 284:
                  var10000 = IIl(1504477865, -1955287727);
                  break;
               case 330:
                  var10000 = IIl(1504477864, -1168809934);
                  break;
               case 331:
                  var10000 = IIl(1504477879, -10252347);
                  break;
               case 332:
                  var10000 = IIl(1504477878, 1875234077);
                  break;
               case 333:
                  var10000 = IIl(1504477877, 153405330);
                  break;
               case 334:
                  var10000 = IIl(1504477876, 1211965551);
                  break;
               case 335:
                  var10000 = IIl(1504477875, -763969581);
                  break;
               case 336:
                  var10000 = IIl(1504477874, 300973338);
                  break;
               case 340:
               case 344:
                  var10000 = IIl(1504477873, -1050468656);
                  break;
               case 341:
               case 345:
                  var10000 = IIl(1504477872, 360135755);
                  break;
               case 342:
               case 346:
                  var10000 = IIl(1504477887, 1973459323);
                  break;
               case 343:
               case 347:
                  var10000 = IIl(1504477886, 110928240);
                  break;
               case 348:
                  var10000 = IIl(1504477885, 1680115365);
                  break;
               default:
                  var10000 = 0;
            }

            return var10000;
         }
      } else {
         return var0;
      }
   }

   private static int II(int var0) {
      int var10000;
      switch (var0) {
         case 0 -> var10000 = 1;
         case 1 -> var10000 = 3;
         case 2 -> var10000 = 2;
         case 3 -> var10000 = 4;
         case 4 -> var10000 = 5;
         case 5 -> var10000 = IIl(1504477884, 1662121070);
         case 6 -> var10000 = IIl(1504477883, 1621050497);
         case 7 -> var10000 = IIl(1504477882, -1141512997);
         default -> var10000 = 0;
      }

      int var1 = var10000;
      return var1 == 0 ? 0 : InputEvent.getMaskForButton(var1);
   }

   static {
      short var6 = 8278;
      String var7 = "뜧뜍러락뜲뜝략랊뜻란랰뜹폏폢퍐펓폚폙퍩퍄폒퍈퍞폗甼畨疥畦甫甿疃痍⢆⣂⡸⣥䯼䮪䬀䮂䯩䯔䭆䭨";
      char[] var8 = "⁚⁚⁞⁒⁞".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            ll = var9;
            III = new Object[var9.length];
            int var2 = -376074612;
            byte[] var0 = "ëc\\KÛ°µÌ5nNð§\u0092DtíÔ·q9\u000e!h\u0001z\u0018¶A\u0001Ì\u0091·\u0003Â\u00984e}ìQÇ\u0011¯Òd@\u0011\u0089\u001dz=Ð¾Ð¤bÁÙø\f\u00adPA§1Y\\.ÿ\u0019ù!f\u008aE?þ@c'¥\u0082$¡0Þ\f\u000fe\u0096@/Y¢f\u0005µ\u0088\u0096\u0092äÜkáþµI¸\u0012ÜE»\u009b§ì\u0082}xù¢>uW\u0016´3\u0006¬ø&\u0017:ÔØ¨\u001fÊzí\u0006C\u0082Hð#\u0002¤\u0001ï\u009aS[$k\u0013þø\u0014µb{\u0000É\u0019õõ](ô\u0087@?¿³óâäDÓÿ\u0007[n;M¡g\nllxOZ\u0083\u0091ßüÁM¹\u001dËÆø\u0004,<bO³æ¡Éq\u0019qZ\u0012ý¥N0fÅ\u0099\u0095Z¶¥\u00adßÔ\u001d\u0088\u0099Ó(øXÐ¦H±\u000bÌèå".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lI = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lI[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            I = ll();
            l = (I & 1) != 0;
            II = (I & 2) != 0;
            Il = new Object();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 43;
                     break;
                  case 1:
                     var10000 = 97;
                     break;
                  case 2:
                     var10000 = 68;
                     break;
                  case 3:
                     var10000 = 15;
                     break;
                  case 4:
                     var10000 = 41;
                     break;
                  case 5:
                     var10000 = 59;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public static boolean Il(class_310 var0, class_3675.class_306 var1, boolean var2, boolean var3) {
      if (l) {
         return IIllIlI.III(var0, var1, var2, var3);
      } else if (II && var1 != null && (!var2 && var3 || I(var0))) {
         try {
            Robot var4 = null.I();
            if (var4 == null) {
               return false;
            } else {
               synchronized(Il) {
                  if (var1.method_1442() == class_307.field_1672) {
                     int var10 = II(var1.method_1444());
                     if (var10 == 0) {
                        return false;
                     } else {
                        if (var2) {
                           var4.mousePress(var10);
                        } else {
                           var4.mouseRelease(var10);
                        }

                        return true;
                     }
                  } else {
                     int var6 = l(var1.method_1444());
                     if (var6 == 0) {
                        return false;
                     } else {
                        if (var2) {
                           var4.keyPress(var6);
                        } else {
                           var4.keyRelease(var6);
                        }

                        return true;
                     }
                  }
               }
            }
         } catch (Throwable var9) {
            return false;
         }
      } else {
         return false;
      }
   }

   public static boolean lI() {
      if (l) {
         return IIllIlI.I();
      } else {
         try {
            return II && !GraphicsEnvironment.isHeadless() && null.I() != null;
         } catch (Throwable var1) {
            return false;
         }
      }
   }

   private static int ll() {
      String var0 = System.getProperty(lIlIII.Il(IlI(-35837245, 2114462158)), "").toLowerCase(Locale.ROOT);
      if (var0.startsWith(lIlIII.Il(IlI(-35837246, 451301299)))) {
         return 1;
      } else {
         return !var0.contains(lIlIII.Il(IlI(-35837247, -1139575129))) && !var0.contains(lIlIII.Il(IlI(-35837248, -509015787))) && !var0.contains(lIlIII.Il(IlI(-35837241, -2100231925))) ? 0 : 2;
      }
   }

   public static void III() {
      if (II) {
         null.I();
      }

   }

   private IIlIlllll() {
   }

   private static int IIl(int var0, int var1) {
      return lI[var0 ^ 1504477831] ^ var1 ^ var0;
   }

   private static String IlI(int var0, int var1) {
      int var3 = var0 ^ -35837245;
      char[] var4 = ll[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])III[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         III[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -924408924;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 58;
               break;
            case 1:
               var9 = 2;
               break;
            case 2:
               var9 = 145;
               break;
            case 3:
               var9 = 73;
               break;
            case 4:
               var9 = 42;
               break;
            case 5:
               var9 = 20;
               break;
            case 6:
               var9 = 172;
               break;
            case 7:
               var9 = 208;
               break;
            case 8:
               var9 = 115;
               break;
            case 9:
               var9 = 132;
               break;
            case 10:
               var9 = 254;
               break;
            case 11:
               var9 = 101;
               break;
            case 12:
               var9 = 83;
               break;
            case 13:
               var9 = 64;
               break;
            case 14:
               var9 = 96;
               break;
            case 15:
               var9 = 198;
               break;
            case 16:
               var9 = 71;
               break;
            case 17:
               var9 = 234;
               break;
            case 18:
               var9 = 159;
               break;
            case 19:
               var9 = 152;
               break;
            case 20:
               var9 = 105;
               break;
            case 21:
               var9 = 136;
               break;
            case 22:
               var9 = 12;
               break;
            case 23:
               var9 = 177;
               break;
            case 24:
               var9 = 51;
               break;
            case 25:
               var9 = 38;
               break;
            case 26:
               var9 = 255;
               break;
            case 27:
               var9 = 4;
               break;
            case 28:
               var9 = 248;
               break;
            case 29:
               var9 = 92;
               break;
            case 30:
               var9 = 182;
               break;
            case 31:
               var9 = 3;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
