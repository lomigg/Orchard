package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class lIIlIll {
   private static final int[] I;

   public static boolean I(double var0, double var2, double var4, double var6, double var8, double var10) {
      double var12 = Math.min(var4, var4 + var8);
      double var14 = Math.max(var4, var4 + var8);
      double var16 = Math.min(var6, var6 + var10);
      double var18 = Math.max(var6, var6 + var10);
      return var0 > var12 && var0 < var14 && var2 > var16 && var2 < var18;
   }

   public static int l(int var0, int var1) {
      return IIl(var1, 0, IlIl(-1389533668, 2062083395)) << IlIl(-1389533667, -838022193) | var0 & IlIl(-1389533666, -1033039311);
   }

   public static double II(double var0, double var2, double var4, double var6) {
      double var8 = lIl(var6 * var4, (double)0.0F, (double)1.0F);
      return ((double)1.0F - var8) * var0 + var8 * var2;
   }

   public static double Il(double var0, double var2, double var4) {
      return var0 + (var2 - var0) * var4;
   }

   public static double lI(double var0, double var2, double var4) {
      return Il(var0, var2, lIl(var4, (double)0.0F, (double)1.0F));
   }

   public static float ll(float var0, float var1, float var2) {
      float var3 = (float)lIl((double)var2, (double)0.0F, (double)1.0F);
      float var4 = Math.max(var0, var1) - Math.min(var0, var1);
      float var5 = var4 * var3;
      return var1 + (var0 > var1 ? var5 : -var5);
   }

   public static <undefinedtype> III(Object var0, Iterable<<undefinedtype>> var1, double var2, double var4) {
      if (var0 != null && var1 != null && !(var4 <= (double)0.0F)) {
         double var6 = var0.Il();
         double var8 = var0.I();
         boolean var10 = var6 + var0.II() * (double)0.5F >= var2 * (double)0.5F;

         for(<undefinedtype> var12 : var1) {
            if (var12 != null && !var12.equals(var0)) {
               if (var10) {
                  double var13 = var12.Il() + var12.II();
                  double var15 = var6 + var0.II();
                  if (Math.abs(var13 - var15) < var4) {
                     var6 = var13 - var0.II();
                  }
               } else if (Math.abs(var12.Il() - var6) < var4) {
                  var6 = var12.Il();
               }

               if (Math.abs(var12.I() - var8) < var4) {
                  var8 = var12.I();
               }
            }
         }

         return new Record(var6, var8, var0.II(), var0.l()) {
            private final double I;
            private final double l;
            private final double II;
            private final double Il;

            public double I() {
               return this.II;
            }

            public double l() {
               return this.I;
            }

            public {
               this.l = var1;
               this.II = var3;
               this.Il = var5;
               this.I = var7;
            }

            public double II() {
               return this.Il;
            }

            public double Il() {
               return this.l;
            }
         };
      } else {
         return var0;
      }
   }

   public static int IIl(int var0, int var1, int var2) {
      return Math.max(var1, Math.min(var2, var0));
   }

   private static int IlI(int var0, int var1, int var2, double var3) {
      int var5 = var0 >>> var2 & IlIl(-1389533665, -144527219);
      int var6 = var1 >>> var2 & IlIl(-1389533672, 904534348);
      return IIl((int)Il((double)var5, (double)var6, var3), 0, IlIl(-1389533671, -1963479747));
   }

   public static <undefinedtype> Ill(double var0, double var2, double var4, double var6, double var8, double var10) {
      double var12 = Math.max((double)0.0F, var4);
      double var14 = Math.max((double)0.0F, var6);
      double var16 = Math.max((double)0.0F, var8 - var12);
      double var18 = Math.max((double)0.0F, var10 - var14);
      return new Record(lIl(var0, (double)0.0F, var16), lIl(var2, (double)0.0F, var18), var12, var14) {
         private final double I;
         private final double l;
         private final double II;
         private final double Il;

         public double I() {
            return this.II;
         }

         public double l() {
            return this.I;
         }

         public {
            this.l = var1;
            this.II = var3;
            this.Il = var5;
            this.I = var7;
         }

         public double II() {
            return this.Il;
         }

         public double Il() {
            return this.l;
         }
      };
   }

   public static int lII(int var0, double var1) {
      int var3 = var0 >>> IlIl(-1389533670, 209124005) & IlIl(-1389533669, 9564018);
      return l(var0, (int)((double)var3 * lIl(var1, (double)0.0F, (double)1.0F)));
   }

   public static double lIl(double var0, double var2, double var4) {
      return Math.max(var2, Math.min(var4, var0));
   }

   public static double llI(double var0, double var2, double var4, double var6) {
      double var8 = IIll(var0, (double)0.0F);
      double var10 = IIlI(var4, (double)1.0F);
      double var12 = IIlI(var6, (double)0.0F);
      double var14 = Math.max((double)0.0F, var10 - var12);
      double var16 = IIll(var2, var14);
      return var8 * Math.max(var16, var14);
   }

   public static <undefinedtype> lll(double var0, double var2, double var4, double var6, double var8, double var10) {
      if (Double.isFinite(var0) && Double.isFinite(var2) && Double.isFinite(var4) && Double.isFinite(var6) && Double.isFinite(var8) && Double.isFinite(var10)) {
         double var12 = var4 < (double)0.0F ? var0 + var4 : var0;
         double var14 = var6 < (double)0.0F ? var2 + var6 : var2;
         double var16 = Math.abs(var4);
         double var18 = Math.abs(var6);
         if (!(var16 <= (double)0.0F) && !(var18 <= (double)0.0F)) {
            double var20 = Math.min(var16, var18) * (double)0.5F;
            return new Record(var12, var14, var16, var18, lIl(var8, (double)0.0F, var20), lIl(var10, (double)0.0F, var20)) {
               private final double I;
               private final double l;
               private final double II;
               private static final <undefinedtype> Il = new <anonymous constructor>((double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F);
               private final double lI;
               private final double ll;
               private final double III;

               public double I() {
                  return this.I;
               }

               public boolean l() {
                  return this.ll > (double)0.0F && this.lI > (double)0.0F;
               }

               public double II() {
                  return this.ll;
               }

               public double Il() {
                  return this.l;
               }

               public double lI() {
                  return this.lI;
               }

               public {
                  this.l = var1;
                  this.II = var3;
                  this.ll = var5;
                  this.lI = var7;
                  this.III = var9;
                  this.I = var11;
               }

               public double ll() {
                  return this.III;
               }

               public double III() {
                  return this.II;
               }
            };
         } else {
            return null.Il;
         }
      } else {
         return null.Il;
      }
   }

   private lIIlIll() {
   }

   public static double IIII(double var0, double var2, double var4) {
      return var0 + (var2 - var0) * lIl(var4, (double)0.0F, (double)1.0F);
   }

   public static int IIIl(int var0, int var1, double var2) {
      double var4 = lIl(var2, (double)0.0F, (double)1.0F);
      int var6 = IlI(var0, var1, IlIl(-1389533676, -1713413190), var4);
      int var7 = IlI(var0, var1, IlIl(-1389533675, -1889685610), var4);
      int var8 = IlI(var0, var1, IlIl(-1389533674, 1491070147), var4);
      int var9 = IlI(var0, var1, 0, var4);
      return var6 << IlIl(-1389533673, -1037371737) | var7 << IlIl(-1389533680, -1350024197) | var8 << IlIl(-1389533679, 1881042807) | var9;
   }

   private static double IIlI(double var0, double var2) {
      return Double.isFinite(var0) ? var0 : var2;
   }

   private static double IIll(double var0, double var2) {
      return Double.isFinite(var0) && var0 > (double)0.0F ? var0 : var2;
   }

   public static double IlII(double var0, double var2, double var4, double var6) {
      double var8 = IIll(var0, (double)0.0F);
      double var10 = IIlI(var4, (double)1.0F);
      double var12 = IIlI(var6, (double)0.0F);
      double var14 = Math.max((double)0.0F, var10 - var12);
      double var16 = Math.max(IIll(var2, var14), var14);
      return var8 * (var10 + (var16 - var14) * (double)0.5F);
   }

   private static int IlIl(int var0, int var1) {
      return I[var0 ^ -1389533668] ^ var1 ^ var0;
   }

   static {
      int var2 = 987434149;
      byte[] var0 = "í\u001e\u008f\u0005Yú¡oUd\u0087u`\u0094ÚÈ¢\u001cs\u000e\u001d\u0001Ç~\u009b\u0080\u0090\u0002\u0097g\u00853\u000e)\t\u0013\u0018«Å6Ï)\u0086xUÜ\u009c\r8~)^çè\u0005Ë".getBytes("ISO-8859-1");
      int var1 = var0.length / 4;
      I = new int[var1];
      int var3 = 0;
      int var4 = 0;

      do {
         int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
         var5 ^= var2;
         I[var4] = var5;
         var3 += 4;
         ++var4;
      } while(var4 < var1);

   }
}
