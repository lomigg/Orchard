package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class IIIlIIIII extends IIIIIIIlI {
   private static final String[] I;
   private static final Object[] l;

   public IIIlIIIII() {
      super((Object)lIlIII.l(ll((short)27267, 1018496297, '㳃')), lIllII.l, (Object)lIlIII.l(ll((short)'\uf69a', 694841683, '㳂')));
   }

   static {
      short var0 = 32170;
      String var1 = "㞒㥒㟰㠎㞫㟰㞵㥛郯鄺郐酂郪部部鄲鄱鄽郝酅郔酅鄝鄽酇鄥郭郡郫酅郵郔鄱鄺鄥鄺鄷部鄤酅鄒鄜郵鄶鄰酂郚郔郮郜郡鄷郴鄝鄒酅郔酂郠鄯酀郜鄽配郮郫郓酈郮鄽鄙鄙";
      char[] var2 = "綢緪".toCharArray();
      String[] var3 = new String[var2.length];
      byte var7 = -1;

      while(true) {
         int var4 = 0;
         int var5 = 0;
         int var6 = 0;
         if (var7 == 0) {
            I = var3;
            l = new Object[var3.length];
            return;
         }

         do {
            var6 = var2[var4] ^ var0;
            var3[var4] = var1.substring(var5, var5 + var6);
            var5 += var6;
            ++var4;
         } while(var4 < var2.length);

         var7 = 0;
      }
   }

   private static String ll(short var0, int var1, char var2) {
      int var3 = var2 ^ 15555;
      char[] var4 = I[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])l[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         l[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 5247;
      int var9 = 0;

      do {
         int var10 = var4[var9] - 'ꛅ';
         var10 += 49973;
         var10 ^= 13016;
         var10 ^= 23523;
         var10 -= 62840;
         var10 += 65434;
         var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
