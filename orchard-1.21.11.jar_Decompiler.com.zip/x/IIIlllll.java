package x;

import java.util.Objects;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

@Environment(EnvType.CLIENT)
public final class IIIlllll extends IIIIIIIlI implements llIlIIII {
   private final IIIllIIII I;
   private final IIIllIIII l;
   private static String[] II;
   private final IIIllIIII Il;
   private static final double lI = (double)18.0F;
   private static final double ll = (double)4.0F;
   private static final <undefinedtype> III;
   private static final double IIl = (double)7.0F;
   private static final int[] IlI;
   private static final String[] Ill;
   private static final Object[] lII;

   public boolean IIlI(double var1, double var3) {
      return var1 >= this.Il() && var1 <= this.Il() + this.llll() && var3 >= this.Ill() && var3 <= this.Ill() + this.lIIl();
   }

   static {
      short var6 = 28831;
      String var7 = "\uf7a5\u3101쨬ꉶ氛楇\uf7d5ᇄǗ儌᛭Ǥ쯯\u1adb\uedfaꃵ擆ﳳ\udd85삙蝲\uf513眅凮杪\ue7b6뒯പ뤍\ue9ad偄ℬ\ue3bf鷤뿨䎤걜䠖췺⁻䁠뙃複橧\ue0a0省굇尿콣椈訧䣒蒹鈽✖\uf63a칁詿㫰쇭珋躄彵飮\ue664\u135b\uf6ec\uf716練\uf157࿐ੰ\udc0f狶㫽्\ue19c䟃ܪ뛗䓠礱ⲑ箮᧐腛稏\ue2e7";
      char[] var8 = "\u0004\u0004\u0004\u0004\u00048\u0004\b".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            Ill = var9;
            lII = new Object[var9.length];
            int var2 = 1751459674;
            byte[] var0 = "\u007fD\u008cæ×þ\u000bªtP\u008aW\u00adàrÐý\u0019%\u007fú0\u001b jwÎL #£ëææ58»Æzy\u00adõ\u000f\u001f¡ ;Ù,á@\u0086È#ú \u0016ú\u0015\fÏT*Æ·4\u001eB".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IlI = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IlI[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            II = new String[IlII(-1988155952, -1637970332)];
            ll();
            III = null.ll;
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 124;
                     break;
                  case 1:
                     var10000 = 16;
                     break;
                  case 2:
                     var10000 = 23;
                     break;
                  case 3:
                     var10000 = 44;
                     break;
                  case 4:
                     var10000 = 75;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static void ll() {
      II[0] = llI(IlIl(-539136720, -1268643387).toCharArray(), 15547L, IlII(-1988155951, -372706624));
      II[1] = llI(IlIl(-539136719, -187814453).toCharArray(), 48960L, IlII(-1988155950, 1945543213));
      II[2] = llI(IlIl(-539136718, -384221477).toCharArray(), 71342L, IlII(-1988155949, -855805167));
      II[3] = llI(IlIl(-539136717, 1507601551).toCharArray(), 91490L, IlII(-1988155948, -647121628));
      II[4] = llI(IlIl(-539136716, -1755029641).toCharArray(), 705L, IlII(-1988155947, -802009631));
      II[5] = llI(IlIl(-539136715, 317746457).toCharArray(), 55969L, IlII(-1988155946, -1354800945));
      II[IlII(-1988155945, -1053187744)] = llI(IlIl(-539136714, -1274652828).toCharArray(), 19520L, IlII(-1988155944, -33458454));
      II[IlII(-1988155943, 1524398333)] = llI(IlIl(-539136713, 446172738).toCharArray(), 76025L, IlII(-1988155942, 172545719));
   }

   private String IlI() {
      return String.valueOf(class_310.method_1551().method_47599());
   }

   public void lIlI(double var1, double var3) {
      this.I.III(Math.max((double)0.0F, var1));
      this.Il.III(Math.max((double)0.0F, var3));
   }

   public IIIlllll() {
      super((Object)lIlIII.l(II[1]), lIllII.IIl, (Object)lIlIII.l(II[5]));
      this.I = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(II[2]), (double)18.0F, (double)0.0F, (double)4000.0F, (double)1.0F)).IIl(lIlIII.Il(II[3])));
      this.Il = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(II[4]), (double)72.0F, (double)0.0F, (double)4000.0F, (double)1.0F)).IIl(lIlIII.Il(II[3])));
      this.l = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(II[IlII(-1988155940, -839171577)]), (double)100.0F, (double)75.0F, (double)200.0F, (double)5.0F)).IIl(lIlIII.Il(II[IlII(-1988155939, 691665057)])));
   }

   public void III(class_332 var1, int var2, int var3, float var4, boolean var5) {
      this.lll(var1, var5);
   }

   public double llll() {
      class_310 var1 = class_310.method_1551();
      return var1 != null && var1.field_1772 != null ? this.IIll(var1.field_1772, this.IlI()) * this.IIII() : (double)42.0F * this.IIII();
   }

   private static String llI(char[] var0, long var1, int var3) {
      int var4 = IlII(-1988155938, -1698981188) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IlII(-1988155937, 776874172);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   public double Il() {
      return (Double)this.I.III();
   }

   public void IIl(class_332 var1, int var2, int var3, float var4) {
      this.lll(var1, false);
   }

   private void lll(class_332 var1, boolean var2) {
      class_310 var3 = class_310.method_1551();
      if (var1 != null && var3 != null && var3.field_1772 != null) {
         double var4 = this.IIII();
         double var6 = this.Il();
         double var8 = this.Ill();
         class_327 var10 = var3.field_1772;
         String var11 = lIlIII.Il(II[0]);
         String var12 = this.IlI();
         double var13 = this.IIll(var10, var12);
         IIIIIIllI.IIIllI(var1);
         IIIIIIllI.IlII(var1, var6, var8);
         IIIIIIllI.lllI(var1, var4, var4);

         try {
            lllIIlI.lI(var1, III, (double)0.0F, (double)0.0F, var13, (double)18.0F, var2);
            double var15 = (double)7.0F;
            double var17 = var15 + (double)IIIIIIllI.IlIl(var10, var11) + (double)4.0F;
            Objects.requireNonNull(var10);
            double var19 = ((double)18.0F - (double)9.0F) * (double)0.5F;
            IIIIIIllI.IlIIll(true, () -> IIIIIIllI.llIl(var1, var10, var11, var15, var19, lllIIlI.Illl(IlII(-1988155941, 1085946285))));
            IIIIIIllI.llIl(var1, var10, var12, var17, var19, lllIIlI.Illl(IlII(-1988155968, 1445862445)));
         } finally {
            IIIIIIllI.lIIlIl(var1);
         }

      }
   }

   private double IIII() {
      return (Double)this.l.III() / (double)100.0F;
   }

   public double lIIl() {
      return (double)18.0F * this.IIII();
   }

   public void IIIlI(class_332 var1, int var2, int var3, float var4) {
      this.lll(var1, false);
   }

   private double IIll(class_327 var1, String var2) {
      return (double)14.0F + (double)IIIIIIllI.IlIl(var1, lIlIII.Il(II[0])) + (double)4.0F + (double)IIIIIIllI.IlIl(var1, var2);
   }

   public double Ill() {
      return (Double)this.Il.III();
   }

   private static int IlII(int var0, int var1) {
      return IlI[var0 ^ -1988155952] ^ var1 ^ var0;
   }

   private static String IlIl(int var0, int var1) {
      int var3 = var0 ^ -539136720;
      char[] var4 = Ill[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])lII[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         lII[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -1806872025;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 177;
               break;
            case 1:
               var9 = 17;
               break;
            case 2:
               var9 = 204;
               break;
            case 3:
               var9 = 31;
               break;
            case 4:
               var9 = 240;
               break;
            case 5:
               var9 = 126;
               break;
            case 6:
               var9 = 115;
               break;
            case 7:
               var9 = 222;
               break;
            case 8:
               var9 = 63;
               break;
            case 9:
               var9 = 95;
               break;
            case 10:
               var9 = 197;
               break;
            case 11:
               var9 = 36;
               break;
            case 12:
               var9 = 51;
               break;
            case 13:
               var9 = 219;
               break;
            case 14:
               var9 = 81;
               break;
            case 15:
               var9 = 30;
               break;
            case 16:
               var9 = 212;
               break;
            case 17:
               var9 = 243;
               break;
            case 18:
               var9 = 8;
               break;
            case 19:
               var9 = 129;
               break;
            case 20:
               var9 = 37;
               break;
            case 21:
               var9 = 233;
               break;
            case 22:
               var9 = 48;
               break;
            case 23:
               var9 = 13;
               break;
            case 24:
               var9 = 214;
               break;
            case 25:
               var9 = 125;
               break;
            case 26:
               var9 = 94;
               break;
            case 27:
               var9 = 38;
               break;
            case 28:
               var9 = 209;
               break;
            case 29:
               var9 = 107;
               break;
            case 30:
               var9 = 11;
               break;
            case 31:
               var9 = 74;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
