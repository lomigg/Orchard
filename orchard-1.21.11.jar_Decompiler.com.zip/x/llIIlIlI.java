package x;

import com.google.gson.JsonObject;
import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_239.class_240;

@Environment(EnvType.CLIENT)
public final class llIIlIlI extends IIIIIIIlI {
   private int I;
   private static final double l = (double)20.25F;
   private boolean II;
   private int Il;
   private final llllIlIl lI;
   private class_2338 ll;
   private final llllIlIl III;
   private int IIl;
   private boolean IlI;
   private int Ill;
   private static final double lII = (double)0.125F;
   private int lIl;
   private boolean llI;
   private static final long lll = 50L;
   private int IIII;
   private static final int IIIl = 9;
   private static final double IIlI = (double)4.5F;
   private static final int IIll = 1;
   private class_3965 IlII;
   private static final String IlIl;
   private int IllI;
   private <undefinedtype> Illl;
   private final lIIIIl lIII;
   private static String[] lIIl;
   private static final int lIlI = 20;
   private long lIll;
   private long llII;
   private static final int[] llIl;
   private static final String[] lllI;
   private static final Object[] llll;

   private class_2338 ll(class_310 var1, class_3965 var2) {
      if (var1 != null && var1.field_1687 != null && var2 != null) {
         class_2338 var3 = var2.method_17777();
         class_2338 var4 = var3.method_10093(var2.method_17780());
         if (this.IIll(var1.field_1687.method_8320(var4))) {
            return var4.method_10062();
         } else {
            return this.IIll(var1.field_1687.method_8320(var3)) ? var3.method_10062() : var4.method_10062();
         }
      } else {
         return null;
      }
   }

   private void IlI(class_310 var1) {
      int var2 = this.IIII >= 0 ? this.IIII : this.lIl;
      if (var1 != null && var1.field_1724 != null) {
         if ((Boolean)this.lIII.III() && var2 >= 0 && var2 < lIIlI(1418845453, -120197165)) {
            IllllIlI.llIIlI(var1, this, var2);
         } else {
            IllllIlI.IlII(var1, this, null.Il);
         }

      }
   }

   private void lII(class_310 var1) {
      this.IlI(var1);
      this.IlII();
      this.IIlIl();
      this.llI = false;
   }

   private boolean llI(class_310 var1) {
      return this.IIIIIlI() && var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var1.field_1724.method_5805();
   }

   private boolean lll(class_310 var1, int var2) {
      return var1 != null && var1.field_1724 != null && var2 >= 0 && var2 < lIIlI(1418845452, -601039671) && !lIlIllll.lIIl(var1) ? this.lIIII(var1.field_1724.method_31548().method_5438(var2)) : false;
   }

   public void IIl(JsonObject var1) {
      super.IIl(var1);
      this.llIlIl(var1, IlIl, new llllIlIl[]{this.lI, this.III});
   }

   private int IIII(class_1657 var1, class_1792 var2) {
      for(int var3 = 0; var3 < lIIlI(1418845455, -1327885069); ++var3) {
         class_1799 var4 = var1.method_31548().method_5438(var3);
         if (var4.method_31574(var2)) {
            return var3;
         }
      }

      return -1;
   }

   public llIIlIlI() {
      super((Object)lIlIII.l(lIIl[0]), lIllII.I, (Object)lIlIII.l(lIIl[3]));
      this.lI = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(lIIl[2]), (double)0.0F, (double)0.0F, (double)0.0F, (double)300.0F, (double)5.0F)).IIII(lIlIII.Il(lIIl[4])));
      this.III = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(lIIl[1]), (double)0.0F, (double)0.0F, (double)0.0F, (double)300.0F, (double)5.0F)).IIII(lIlIII.Il(lIIl[4])));
      this.lIII = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lIIl[5]), true));
      this.I = lIIlI(1418845454, 1139025532);
      this.llII = Long.MIN_VALUE;
      this.lIl = -1;
      this.IIII = -1;
      this.Il = -1;
      this.IllI = lIIlI(1418845449, 1285604472);
      this.IIl = lIIlI(1418845448, 1086141232);
   }

   private boolean IIll(class_2680 var1) {
      return var1 != null && (var1.method_27852(class_2246.field_10167) || var1.method_27852(class_2246.field_10425) || var1.method_27852(class_2246.field_10025) || var1.method_27852(class_2246.field_10546));
   }

   private void IlII() {
      this.I = lIIlI(1418845451, -795125988);
      this.llII = Long.MIN_VALUE;
      this.IlII = null;
      this.lIl = -1;
   }

   private void IlIl(class_310 var1) {
      ++this.Ill;
      if (this.Ill > lIIlI(1418845450, -2084609127)) {
         this.Illll(var1);
      } else {
         this.lIll = System.currentTimeMillis() + 50L;
      }
   }

   public void lI() {
      this.IlI(class_310.method_1551());
      this.IlII();
      this.IIlIl();
      this.llI = false;
   }

   private long lIII(llllIlIl var1) {
      double var2 = var1.IlII();
      double var4 = var1.IlI();
      return var2 >= var4 ? Math.max(0L, Math.round(var2)) : Math.max(0L, Math.round(ThreadLocalRandom.current().nextDouble(var2, var4)));
   }

   private class_243 lIIl(class_2338 var1) {
      return class_243.method_24955(var1).method_1031((double)0.0F, (double)0.125F, (double)0.0F);
   }

   private boolean llII() {
      lIllIIl var1 = lIllIIl.Il();
      if (var1 != null && var1.IIl() != null) {
         Illlll var2 = var1.IIl().lIIlII();
         if (var2 != null && var2.IlllI()) {
            return true;
         } else {
            IIIIllIIl var3 = var1.IIl().llIl();
            return var3 != null && var3.IIlIl();
         }
      } else {
         return false;
      }
   }

   private int lllI(class_1657 var1) {
      return this.IIII(var1, class_1802.field_8069);
   }

   private static void IIIII() {
      lIIl[0] = IlIll(lIIll(74642341, 843522747).toCharArray(), 57630L, lIIlI(1418845445, 1412299671));
      lIIl[1] = IlIll(lIIll(74642340, -1883240396).toCharArray(), 65681L, lIIlI(1418845444, -1840571245));
      lIIl[2] = IlIll(lIIll(74642343, -2126088030).toCharArray(), 24309L, lIIlI(1418845447, 1502323868));
      lIIl[3] = IlIll(lIIll(74642342, -1649719144).toCharArray(), 4172L, lIIlI(1418845446, -1141037352));
      lIIl[4] = IlIll(lIIll(74642337, 2086996461).toCharArray(), 28656L, lIIlI(1418845441, -940131879));
      lIIl[5] = IlIll(lIIll(74642336, 878458165).toCharArray(), 42148L, lIIlI(1418845440, 1918413035));
      lIIl[lIIlI(1418845443, 25278781)] = IlIll(lIIll(74642339, -1798150056).toCharArray(), 39189L, lIIlI(1418845442, 685498027));
      lIIl[lIIlI(1418845469, 763940911)] = IlIll(lIIll(74642338, 1737499443).toCharArray(), 61626L, lIIlI(1418845468, 1461228060));
   }

   public String Il() {
      return null;
   }

   private int IIIIl(llllIlIl var1) {
      return Math.max(0, (int)Math.ceil((double)this.lIII(var1) / (double)50.0F));
   }

   public void IIIll(class_310 var1, class_1268 var2, class_3965 var3) {
      if (this.IllII(var1, var2, var3)) {
         this.IlI(var1);
         this.IlII();
         this.IIlIl();
         this.I = var1.field_1724.field_6012;
         this.llII = IllllIlI.IIlIIIl();
         this.IlII = var3;
         this.lIl = IllllIlI.lIIlI(var1.field_1724.method_31548());
      }
   }

   public void IIlII(class_310 var1, class_1268 var2, class_3965 var3, class_1269 var4) {
      if (this.I != lIIlI(1418845471, -900840269)) {
         try {
            if (this.IIIIIlI() && !this.llI && !this.llII() && var4 != null && var4.method_23665() && var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var2 == class_1268.field_5808 && var1.field_1724.field_6012 == this.I && IllllIlI.IIlIIIl() > this.llII) {
               class_3965 var5 = this.IlII != null ? this.IlII : var3;
               class_2338 var6 = this.ll(var1, var5);
               if (var6 != null) {
                  this.lIIIl(var6, this.lIl);
                  this.IIllI(var1);
               }

               return;
            }
         } finally {
            this.IlII();
         }

      }
   }

   private void IIlIl() {
      this.ll = null;
      this.IIII = -1;
      this.Il = -1;
      this.II = false;
      this.Illl = null;
      this.lIll = 0L;
      this.IllI = lIIlI(1418845470, -1768557187);
      this.IIl = lIIlI(1418845465, -1767148138);
      this.IlI = false;
      this.Ill = 0;
   }

   private void IIllI(class_310 var1) {
      if (this.ll != null) {
         if (this.llII()) {
            this.lII(var1);
         } else if (!this.llI(var1)) {
            this.IlI(var1);
            this.IIlIl();
         } else if (this.IIl != lIIlI(1418845464, 189471579)) {
            if (var1.field_1724.field_6012 >= this.IIl) {
               this.IlI(var1);
               this.IIlIl();
            }
         } else if (this.IllI != lIIlI(1418845467, 2095981218)) {
            if (var1.field_1724.field_6012 > this.IllI) {
               this.IllI = lIIlI(1418845466, -1332934678);
               this.lIll = System.currentTimeMillis() + 50L;
            }
         } else if (System.currentTimeMillis() >= this.lIll) {
            class_2338 var2 = this.ll;
            if (!this.IIll(var1.field_1687.method_8320(var2))) {
               this.IlIl(var1);
            } else if (!this.IlIIl(var1, var2)) {
               this.Illll(var1);
            } else {
               if (this.Il < 0) {
                  this.Il = this.lllI(var1.field_1724);
               }

               if (!this.II) {
                  if (this.Il < 0 || !this.lll(var1, this.Il)) {
                     this.Illll(var1);
                     return;
                  }

                  if (this.Illl == null || !IllllIlI.IIII(var1, this.Illl) || this.Illl.ll() != this.Il) {
                     boolean var3 = IllllIlI.IIlIl(var1) != this.Il;
                     int var4 = var3 ? this.IIIIl(this.lI) : 0;
                     this.Illl = IllllIlI.lIll(var1, this, this.Il, var4, true);
                  }

                  if (!this.Illl.III()) {
                     this.Illl = null;
                     this.lIll = System.currentTimeMillis() + 50L;
                     return;
                  }

                  if (!IllllIlI.IlIllII(var1, this.Illl)) {
                     return;
                  }

                  this.Illl = null;
                  this.II = true;
               }

               if (this.IlllI(var1, var2)) {
                  this.IIlll(var1, var2);
               } else {
                  float[] var5 = IlIlIl.llIlI(var1, this.lIIl(var2));
                  if (var5 == null) {
                     this.IlIl(var1);
                  } else {
                     this.IllI = var1.field_1724.field_6012 + 1;
                     boolean var6 = IlIlIl.IIIIlI(var1, lIIlI(1418845461, 1353231822), var5[0], var5[1], () -> this.IIlll(var1, var2));
                     if (!var6) {
                        this.IllI = lIIlI(1418845460, 2088993189);
                        this.lIll = System.currentTimeMillis() + 50L;
                     }

                  }
               }
            }
         }
      }
   }

   private boolean IIlll(class_310 var1, class_2338 var2) {
      this.IllI = lIIlI(1418845463, -1082158546);
      if (this.llII()) {
         this.lII(var1);
         return false;
      } else if (this.ll != null && this.ll.equals(var2) && !this.IlI && this.IlIIl(var1, var2) && this.IlllI(var1, var2) && this.Il >= 0 && this.lIIII(var1.field_1724.method_31548().method_5438(this.Il))) {
         class_3965 var3 = new class_3965(this.lIIl(var2), class_2350.field_11036, var2, false);
         if (IllllIlI.IIlIl(var1) != this.Il) {
            this.IlIl(var1);
            return false;
         } else {
            long var4 = IllllIlI.IIlIIIl();
            boolean var6 = IllllIlI.lIlIl();
            if (!var6) {
               this.IlIl(var1);
               return false;
            } else {
               class_1269 var7;
               try {
                  this.llI = true;

                  try {
                     var7 = var1.field_1761.method_2896(var1.field_1724, class_1268.field_5808, var3);
                  } finally {
                     this.llI = false;
                  }
               } finally {
                  IllllIlI.IIlllI();
               }

               if (var7 != null && var7.method_23665()) {
                  var1.field_1724.method_6104(class_1268.field_5808);
               }

               this.IlI = IllllIlI.IIlIIIl() != var4;
               if (!this.IlI) {
                  this.IlIl(var1);
                  return false;
               } else {
                  this.Illll(var1);
                  return true;
               }
            }
         }
      } else {
         this.IlIl(var1);
         return false;
      }
   }

   private boolean IlIII(class_1799 var1) {
      return var1 != null && !var1.method_7960() && (var1.method_31574(class_1802.field_8129) || var1.method_31574(class_1802.field_8848) || var1.method_31574(class_1802.field_8211) || var1.method_31574(class_1802.field_8655));
   }

   private boolean IlIIl(class_310 var1, class_2338 var2) {
      return this.llI(var1) && var2 != null && this.IIll(var1.field_1687.method_8320(var2)) && var1.field_1724.method_33571().method_1025(this.lIIl(var2)) <= (double)20.25F;
   }

   private static String IlIll(char[] var0, long var1, int var3) {
      int var4 = lIIlI(1418845462, 433934995) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & lIIlI(1418845457, -92593252);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   public String IIlllIl() {
      String var1 = this.Il();
      String var10000;
      if (var1 != null && !var1.isBlank()) {
         var10000 = this.llll();
         String var3 = lIlIII.Il(lIIl[lIIlI(1418845456, -520801088)]);
         String var2 = var10000;
         var10000 = var2 + var3 + var1;
      } else {
         var10000 = this.llll();
      }

      return var10000;
   }

   private boolean IllII(class_310 var1, class_1268 var2, class_3965 var3) {
      return this.IIIIIlI() && !this.llI && !this.llII() && var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var2 == class_1268.field_5808 && var3 != null && var3.method_17783() == class_240.field_1332 && var3.method_17780() == class_2350.field_11036 && !lIlIllll.lIIl(var1) && this.IlIII(var1.field_1724.method_6047());
   }

   public boolean IllIl() {
      return this.llI;
   }

   static {
      short var6 = 24436;
      String var7 = "铬ꑙ玆宩Ⱕኪ\uf3dbꊢᤡ㼢ꓵ\udb9d䫐㺥جぅ扉狿⋠༌絼袴掃礲媇ꨀ쐵鳕ꀻ\ue635鹼趕亅솞笮䌿支伾\ud96a釘⨅柽㇊ꇊꏅश梞珲솷몈⻮楛馱篓쉀옫㾯落ᷟ狔\ud88c\uf7af勹⎴\uf488㴥﷼ᚿ⻕\uebf0澕턺毆︁춫捼ភ\ue139晴㸬캛율닛䕻顥㏅蚪\uecd4㐔깎ㄛ와쩼甎←箻뤔篫劬\ue3f8쳕㋞⑭ꐘ駕霭齵掶\ud9de\ue34e낭䰞⒆䒊✕蟚⫬䩏ꋐ摐詬\uf4aa淋ঘꊝ\ue8efࢀ鴭濦\uec68꒙⫎쐭㟐s닍癍醨\u0b9d岳录듰ﲍ\u088f";
      char[] var8 = "彸彬彤彌彰彤彼彼".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            lllI = var9;
            llll = new Object[var9.length];
            int var2 = -2116927389;
            byte[] var0 = "-\u0096r´\toA¯e\u0099\u0089\u0096\u0016§»\u0011\u0019ãY\u0012\u0015þ®[\u0085ØÊtVüþäG÷ ÈÉ©\u0017^hLq%^ÿ¨\u001d!Ì\u008eþqòX:ÔÂ$[G\u00808ðøËMV\f¾¤\u0003\u009f\rÙÏÃÖh\u0000Ãèèì^\b\u0086 )\u00ad¿ÚåÎ\u009a\u0093\u0085ë0p)À\u001cÒê<\u000fZR)\t\u009d/8¾\u00115¶©µ\u00adâ<Ïx\u0007\u001e5\\\u001b\u0091\u0089\u0011\u000bì\u00031\u0086&k".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            llIl = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               llIl[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            lIIl = new String[lIIlI(1418845459, 2023858615)];
            IIIII();
            IlIl = lIlIII.Il(lIIl[lIIlI(1418845458, -1388018877)]);
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 74;
                     break;
                  case 1:
                     var10000 = 11;
                     break;
                  case 2:
                     var10000 = 118;
                     break;
                  case 3:
                     var10000 = 72;
                     break;
                  case 4:
                     var10000 = 121;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private boolean IlllI(class_310 var1, class_2338 var2) {
      if (this.llI(var1) && var2 != null) {
         class_239 var3 = var1.field_1724.method_5745((double)4.5F, 1.0F, false);
         boolean var10000;
         if (var3 instanceof class_3965) {
            class_3965 var4 = (class_3965)var3;
            if (var4.method_17783() == class_240.field_1332 && var4.method_17777().equals(var2) && var4.method_17780() == class_2350.field_11036 && this.IIll(var1.field_1687.method_8320(var2))) {
               var10000 = true;
               return var10000;
            }
         }

         var10000 = false;
         return var10000;
      } else {
         return false;
      }
   }

   private void Illll(class_310 var1) {
      if ((Boolean)this.lIII.III() && this.IIII >= 0 && this.IIII < lIIlI(1418845485, -1990718258) && this.IIII != this.Il) {
         this.IIl = var1.field_1724.field_6012 + 1;
      } else {
         this.IIlIl();
      }
   }

   private boolean lIIII(class_1799 var1) {
      return var1 != null && !var1.method_7960() && var1.method_31574(class_1802.field_8069);
   }

   public void Ill() {
      this.IIllI(class_310.method_1551());
   }

   private void lIIIl(class_2338 var1, int var2) {
      this.ll = var1.method_10062();
      this.IIII = var2;
      this.Il = -1;
      this.II = false;
      this.Illl = null;
      this.Ill = 0;
      this.IllI = lIIlI(1418845484, 1145598284);
      this.IIl = lIIlI(1418845487, 1690680103);
      this.IlI = false;
      this.lIll = System.currentTimeMillis() + this.lIII(this.III);
   }

   private static int lIIlI(int var0, int var1) {
      return llIl[var0 ^ 1418845453] ^ var1 ^ var0;
   }

   private static String lIIll(int var0, int var1) {
      int var3 = var0 ^ 74642341;
      char[] var4 = lllI[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])llll[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         llll[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -1263353832;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 190;
               break;
            case 1:
               var9 = 103;
               break;
            case 2:
               var9 = 168;
               break;
            case 3:
               var9 = 218;
               break;
            case 4:
               var9 = 136;
               break;
            case 5:
               var9 = 187;
               break;
            case 6:
               var9 = 126;
               break;
            case 7:
               var9 = 84;
               break;
            case 8:
               var9 = 153;
               break;
            case 9:
               var9 = 233;
               break;
            case 10:
               var9 = 14;
               break;
            case 11:
               var9 = 72;
               break;
            case 12:
               var9 = 132;
               break;
            case 13:
               var9 = 174;
               break;
            case 14:
               var9 = 181;
               break;
            case 15:
               var9 = 182;
               break;
            case 16:
               var9 = 26;
               break;
            case 17:
               var9 = 151;
               break;
            case 18:
               var9 = 123;
               break;
            case 19:
               var9 = 2;
               break;
            case 20:
               var9 = 102;
               break;
            case 21:
               var9 = 42;
               break;
            case 22:
               var9 = 237;
               break;
            case 23:
               var9 = 74;
               break;
            case 24:
               var9 = 215;
               break;
            case 25:
               var9 = 96;
               break;
            case 26:
               var9 = 218;
               break;
            case 27:
               var9 = 219;
               break;
            case 28:
               var9 = 110;
               break;
            case 29:
               var9 = 115;
               break;
            case 30:
               var9 = 81;
               break;
            case 31:
               var9 = 56;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
