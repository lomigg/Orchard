package x;

import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_3966;
import y.lIIllll;

@Environment(EnvType.CLIENT)
public final class llIIIl extends IIIIIIIlI {
   private final IIIllIIII I;
   private int l;
   private boolean II;
   private static String[] Il;
   private static final int[] lI;
   private static final String[] ll;
   private static final Object[] III;

   private boolean ll() {
      double var1 = (Double)this.I.III();
      if (var1 <= (double)0.0F) {
         return false;
      } else if (var1 >= (double)100.0F) {
         return true;
      } else {
         return ThreadLocalRandom.current().nextDouble((double)100.0F) < var1;
      }
   }

   public void lI() {
      this.l = 0;
      this.II = false;
   }

   static {
      short var6 = 12594;
      String var7 = "櫞í䦈ᖚ˗貑\ue787掼䦅홀乩窝㦱찂\u17fe䱂煉襖鋓힁\uef68㡍덶钵\ue52e揫䗰\u0ee5㻢\ue4caᙾݫ쬸\uf0fc\ud802〺⹋á⸑\uf3b0枃坚巸⧰婠ᦌ掗洀플脕✟\udba0婙⓮鿳⑭㮮\uf030舴쏫⢛邶ꎲ㢊\u19cb륹䂚﹉䤙飪↚\ue79a얇辫䐋\u1ccd\ud8c8䡥챇\udb3a⋭弙粕緧\uf74a؛䳡☭⁑똰粕粨㡽ܬ妜˦霨ઐ㊧\ue20d";
      char[] var8 = "H\u0010\b\u0004".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            ll = var9;
            III = new Object[var9.length];
            int var2 = -1078936681;
            byte[] var0 = "¥Å.=þÆ-Èw¾\u0015Éé\u0093\u009câ\u0086\t\u001d:¥V[¤".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lI = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lI[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            Il = new String[4];
            IlI();
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 113;
                     break;
                  case 1:
                     var10000 = 113;
                     break;
                  case 2:
                     var10000 = 61;
                     break;
                  case 3:
                     var10000 = 18;
                     break;
                  case 4:
                     var10000 = 8;
                     break;
                  case 5:
                     var10000 = 25;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static void IlI() {
      Il[0] = lII(IIII(-135464701, 1640700037).toCharArray(), 22346L, lll(-1002157198, 256868715));
      Il[1] = lII(IIII(-135464702, -1668073590).toCharArray(), 50727L, lll(-1002157197, 1795514972));
      Il[2] = lII(IIII(-135464703, 759770455).toCharArray(), 41809L, lll(-1002157200, -34381389));
      Il[3] = lII(IIII(-135464704, 2131453295).toCharArray(), 54158L, lll(-1002157199, -1766985771));
   }

   public void lIl() {
      this.l = 0;
      this.II = false;
   }

   private static String lII(char[] var0, long var1, int var3) {
      int var4 = lll(-1002157194, -965322742) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & lll(-1002157193, -559764549);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (var1 != null && var1.field_1724 != null) {
         lIIllll var2 = (lIIllll)var1;
         int var3 = var2.ilovcats$getAttackCooldown();
         if (var3 > 0 && this.l <= 0) {
            if (!this.II && this.ll()) {
               var2.ilovcats$setAttackCooldown(0);
               var3 = 0;
            }

            this.II = false;
         } else if (var3 <= 0 && this.l <= 0) {
            this.II = false;
         }

         this.l = var3;
      } else {
         this.l = 0;
         this.II = false;
      }
   }

   public void III(class_1297 var1) {
      this.II = var1 != null;
   }

   public llIIIl() {
      super((Object)lIlIII.l(Il[1]), lIllII.I, (Object)lIlIII.l(Il[0]));
      this.I = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(Il[2]), (double)100.0F, (double)0.0F, (double)100.0F, (double)1.0F)).IIl(lIlIII.Il(Il[3])));
   }

   public boolean llI(class_310 var1) {
      if (this.IIIIIlI() && var1 != null && var1.field_1724 != null) {
         class_239 var3 = var1.field_1765;
         if (var3 instanceof class_3966) {
            class_3966 var2 = (class_3966)var3;
            class_1297 var4 = var2.method_17782();
            if (var4 != null && var4 != var1.field_1724 && var4.method_5805() && !var4.method_31481() && !var4.method_7325() && !IlIII.II(var4)) {
               return false;
            }
         }

         return this.ll();
      } else {
         return false;
      }
   }

   private static int lll(int var0, int var1) {
      return lI[var0 ^ -1002157198] ^ var1 ^ var0;
   }

   private static String IIII(int var0, int var1) {
      int var3 = var0 ^ -135464701;
      char[] var4 = ll[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])III[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         III[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 316644574;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 167;
               break;
            case 1:
               var9 = 142;
               break;
            case 2:
               var9 = 32;
               break;
            case 3:
               var9 = 196;
               break;
            case 4:
               var9 = 181;
               break;
            case 5:
               var9 = 53;
               break;
            case 6:
               var9 = 60;
               break;
            case 7:
               var9 = 172;
               break;
            case 8:
               var9 = 57;
               break;
            case 9:
               var9 = 51;
               break;
            case 10:
               var9 = 235;
               break;
            case 11:
               var9 = 82;
               break;
            case 12:
               var9 = 49;
               break;
            case 13:
               var9 = 203;
               break;
            case 14:
               var9 = 191;
               break;
            case 15:
               var9 = 120;
               break;
            case 16:
               var9 = 34;
               break;
            case 17:
               var9 = 15;
               break;
            case 18:
               var9 = 239;
               break;
            case 19:
               var9 = 36;
               break;
            case 20:
               var9 = 78;
               break;
            case 21:
               var9 = 119;
               break;
            case 22:
               var9 = 95;
               break;
            case 23:
               var9 = 135;
               break;
            case 24:
               var9 = 168;
               break;
            case 25:
               var9 = 114;
               break;
            case 26:
               var9 = 75;
               break;
            case 27:
               var9 = 48;
               break;
            case 28:
               var9 = 74;
               break;
            case 29:
               var9 = 217;
               break;
            case 30:
               var9 = 61;
               break;
            case 31:
               var9 = 172;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
