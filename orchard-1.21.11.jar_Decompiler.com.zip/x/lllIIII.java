package x;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Supplier;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_332;

@Environment(EnvType.CLIENT)
public final class lllIIII extends IIIIIIIlI implements llIlIIII {
   private static String[] I;
   private List<<undefinedtype>> l;
   private final lIIIllll II;
   private final IIIllIIII Il;
   private <undefinedtype> lI;
   private static final <undefinedtype> ll;
   private final Supplier<List<IIIIIIIlI>> III;
   private final IIIllIIII IIl;
   private final lIIIIl IlI;
   private int Ill;
   private final IIIllIIII lII;
   private static final int[] lIl;
   private static final String[] llI;
   private static final Object[] lll;

   public void IIIlI(class_332 var1, int var2, int var3, float var4) {
      if (this.IIIIIlI()) {
         this.IlIl(var1, false);
      }
   }

   public double Il() {
      return (Double)this.Il.III();
   }

   public void III(class_332 var1, int var2, int var3, float var4, boolean var5) {
      this.IlIl(var1, var5);
   }

   private double ll() {
      return (Double)this.lII.III() / (double)100.0F;
   }

   public void IIl(class_332 var1, int var2, int var3, float var4) {
      this.IlIl(var1, false);
   }

   private static String IlI(char[] var0, long var1, int var3) {
      int var4 = Illl(-643386957, -444252111) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & Illl(-643386958, 1238206824);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private int lII() {
      int var1 = (Boolean)this.IlI.III() ? 1 : 0;

      for(IIIIIIIlI var3 : (List)this.III.get()) {
         if (var3 != this) {
            var1 = Illl(-643386959, 1571641120) * var1 + System.identityHashCode(var3);
            var1 = Illl(-643386960, -1284528591) * var1 + (var3.IIlllll() ? 1 : 0);
            var1 = Illl(-643386953, -1274282625) * var1 + (var3.IIIIIlI() ? 1 : 0);
            var1 = Illl(-643386954, 888097384) * var1 + var3.IIIlIII().hashCode();
            var1 = Illl(-643386955, 51814089) * var1 + var3.llll().hashCode();
         }
      }

      return var1;
   }

   public void lIlI(double var1, double var3) {
      double var5 = Double.MAX_VALUE;
      double var7 = Double.MAX_VALUE;
      class_310 var9 = class_310.method_1551();
      if (var9 != null && var9.method_22683() != null) {
         var5 = Math.max((double)0.0F, (double)var9.method_22683().method_4486() - this.llll());
         var7 = Math.max((double)0.0F, (double)var9.method_22683().method_4502() - this.lIIl());
      }

      this.Il.III(Math.max((double)0.0F, Math.min(var1, var5)));
      this.IIl.III(Math.max((double)0.0F, Math.min(var3, var7)));
   }

   public double lIIl() {
      this.IIll(class_310.method_1551());
      return this.lI.l * this.ll();
   }

   static {
      short var6 = 20593;
      String var7 = "隝盪죬ዣ⠩낵\ue05cㅗ䦊ไ辏묘묔\udfc5탷\uf82eẔ찿ⱍꉔ仂灊衸ᅉ눏蔜촱\ufdec☄⺖㰏撻툀옪\uea1e㜖俰汖뚏就\ue65e퐐鶹ꑻ钋葒암\udc51蟹㘛猬삫壻穣섉뒜䗷甡\udfc8뼶깉췁訄츛䇭㋖铴鰫屍\ue250Ǵ礼굪꽬ᓲ౷Ὗꆛ簬愓︨ল艾鸞쵫䝟漟瓙옗퉑朁܅狝ꛩᣱࢢ벯ᒮ潱꒔ઁ炮룫\ue88e\uee3a↧\udae0趵⩉屢勻楐᰷컈糡\ue6e8胥懰ꅇ\udf2c诲螧瑒鹥秛즸囸헉觚穎\ufae3湫\udd47틔楧\u2d9a⧾縰咻Ꞓ嬹쐒㹰껼ꏾ䛫톲薅";
      char[] var8 = "偡偹偡倱偹偵偵偵偩".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            llI = var9;
            lll = new Object[var9.length];
            int var2 = -133312501;
            byte[] var0 = "ªÆ\u000e\u0014hfè.|\u00066\u0085\u0092ÄÇ\u0095\u0095 \u009cÜ\u0015D+Ê\"½ÿh\u000b¿,\u0089pØÏ\u0080\u0097\u0095!öî7ê\u0095\u0081\u009aa\u0097/S\u007f\u0082f\u0007Ñ`øètÛ\u0092\u0018\"çl¨\u0095j&7Ç÷\u0004\u009fcÛ÷Ì\u0095fhÍr\u008c©\u0006\u009eáÕÈ*Iíoç\u008b7\u0094¨U \u001f\u0007\u0017iVÜÖ.\u00156½à5\nV?ün\u0081".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lIl = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lIl[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            I = new String[Illl(-643386956, 705973567)];
            lll();
            ll = null.III;
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public double llll() {
      this.IIll(class_310.method_1551());
      return this.lI.I * this.ll();
   }

   public boolean IIlI(double var1, double var3) {
      return var1 >= this.Il() && var1 <= this.Il() + this.llll() && var3 >= this.Ill() && var3 <= this.Ill() + this.lIIl();
   }

   private <undefinedtype> llI(class_310 var1, List<<undefinedtype>> var2) {
      if (var1 != null && var1.field_1772 != null) {
         double var3 = (double)118.0F;
         double var5 = (double)18.0F;

         for(<undefinedtype> var8 : var2) {
            double var9 = (double)(IIIIIIllI.IlIl(var1.field_1772, var8.I) + IIIIIIllI.IlIl(var1.field_1772, var8.II)) + (double)42.0F;
            var3 = Math.max(var3, var9);
         }

         double var11 = (double)16.0F + (double)Math.max(1, var2.size()) * var5;
         return new Record(Math.max((double)140.0F, var3), Math.max((double)38.0F, var11)) {
            private final double I;
            private final double l;

            public double I() {
               return this.I;
            }

            public double l() {
               return this.l;
            }

            private {
               this.I = var1;
               this.l = var3;
            }
         };
      } else {
         return new Record((double)150.0F, (double)42.0F) {
            private final double I;
            private final double l;

            public double I() {
               return this.I;
            }

            public double l() {
               return this.l;
            }

            private {
               this.I = var1;
               this.l = var3;
            }
         };
      }
   }

   private static void lll() {
      I[0] = IlI(lIII(38096, (short)31408, -1234758390).toCharArray(), 35342L, Illl(-643386949, 2123553461));
      I[1] = IlI(lIII(38097, (short)'﵆', -25153065).toCharArray(), 91064L, Illl(-643386950, 224819213));
      I[2] = IlI(lIII(38098, (short)'\udb87', -542804722).toCharArray(), 70524L, Illl(-643386951, 39230292));
      I[3] = IlI(lIII(38099, (short)3690, -862900429).toCharArray(), 5639L, Illl(-643386952, 1047254457));
      I[4] = IlI(lIII(38100, (short)'股', -1251733227).toCharArray(), 3197L, Illl(-643386945, -705951613));
      I[5] = IlI(lIII(38101, (short)'쐯', 2129809122).toCharArray(), 74360L, Illl(-643386946, -766612448));
      I[Illl(-643386947, -649915029)] = IlI(lIII(38102, (short)16405, 660606184).toCharArray(), 29015L, Illl(-643386948, -993860170));
      I[Illl(-643386973, 1292104901)] = IlI(lIII(38103, (short)'꺦', 687622839).toCharArray(), 1672L, Illl(-643386974, 975714296));
      I[Illl(-643386975, 624165497)] = IlI(lIII(38104, (short)'鶳', -364283048).toCharArray(), 4230L, Illl(-643386976, 297513795));
   }

   private List<<undefinedtype>> IIII() {
      ArrayList var1 = new ArrayList();

      for(IIIIIIIlI var3 : (List)this.III.get()) {
         if (var3 != this && var3.IIlllll() && (!(Boolean)this.IlI.III() || var3.IIIIIlI())) {
            var1.add(new Record(var3.llll(), IllllIlI.IIIlIl(var3.IIIlIII()), var3.IIIIIlI()) {
               private final String I;
               private final boolean l;
               private final String II;

               public String I() {
                  return this.II;
               }

               public boolean l() {
                  return this.l;
               }

               private {
                  this.I = var1;
                  this.II = var2;
                  this.l = var3;
               }

               public String II() {
                  return this.I;
               }
            });
         }
      }

      var1.sort(Comparator.comparing((var0) -> var0.I, String.CASE_INSENSITIVE_ORDER));
      return var1;
   }

   private void IIll(class_310 var1) {
      int var2 = this.lII();
      if (var2 != this.Ill) {
         this.l = this.IIII();
         this.lI = this.llI(var1, this.l);
         this.Ill = var2;
      }
   }

   public double Ill() {
      return (Double)this.IIl.III();
   }

   public lllIIII(Supplier<List<IIIIIIIlI>> var1, lIIIllll var2) {
      super((Object)lIlIII.l(I[0]), lIllII.IIl, (Object)lIlIII.l(I[3]));
      this.IlI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(I[2]), false));
      this.Il = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(I[Illl(-643386969, 1231426343)]), (double)24.0F, (double)0.0F, (double)4000.0F, (double)1.0F)).IIl(lIlIII.Il(I[5])));
      this.IIl = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(I[Illl(-643386970, -2001862838)]), (double)120.0F, (double)0.0F, (double)4000.0F, (double)1.0F)).IIl(lIlIII.Il(I[5])));
      this.lII = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(I[1]), (double)100.0F, (double)70.0F, (double)180.0F, (double)5.0F)).IIl(lIlIII.Il(I[4])));
      this.l = List.of();
      this.lI = new Record((double)150.0F, (double)42.0F) {
         private final double I;
         private final double l;

         public double I() {
            return this.I;
         }

         public double l() {
            return this.l;
         }

         private {
            this.I = var1;
            this.l = var3;
         }
      };
      this.Ill = Illl(-643386971, 1952664551);
      this.III = var1;
      this.II = var2;
   }

   private void IlIl(class_332 var1, boolean var2) {
      class_310 var3 = class_310.method_1551();
      if (var3.field_1772 != null) {
         this.IIll(var3);
         List var4 = this.l;
         <undefinedtype> var5 = this.lI;
         double var6 = this.Il();
         double var8 = this.Ill();
         double var10 = this.ll();
         IIIIIIllI.IIIllI(var1);
         IIIIIIllI.IlII(var1, var6, var8);
         IIIIIIllI.lllI(var1, var10, var10);
         Color var12 = lllIIlI.III();
         lllIIlI.lI(var1, ll, (double)0.0F, (double)0.0F, var5.I, var5.l, var2);
         double var13 = (double)16.0F;
         double var15 = (double)18.0F;
         double var17 = (double)9.0F;
         if (var4.isEmpty()) {
            IIIIIIllI.llIl(var1, var3.field_1772, lIlIII.Il(I[Illl(-643386972, -859535828)]), (double)10.0F, var17 + (double)2.0F, lllIIlI.IlII(Illl(-643386965, 373279017)));
         } else {
            for(<undefinedtype> var20 : var4) {
               IIIIIIllI.IllIll(var1, (double)6.0F, var17 - (double)2.0F, var5.I - (double)12.0F, var13, (double)4.0F, lllIIlI.Ill(Illl(-643386966, 28599814)));
               double var21 = var17 - (double)2.0F + Math.max((double)0.0F, (var13 - IIIIIIllI.lllIII(var3.field_1772)) * (double)0.5F);
               int var23 = var20.l ? lllIIlI.Illl(Illl(-643386967, 1224588683)) : lllIIlI.IlII(Illl(-643386968, 264132546));
               int var24 = var20.l ? IIIlllIII.lI(var12.getRGB(), Illl(-643386961, -1046582515)) : lllIIlI.IlII(Illl(-643386962, 509022200));
               IIIIIIllI.llIl(var1, var3.field_1772, var20.I, (double)10.0F, var21, var23);
               IIIIIIllI.lI(var1, var3.field_1772, var20.II, var5.I - (double)10.0F, var21, var24);
               var17 += var15;
            }
         }

         IIIIIIllI.lIIlIl(var1);
      }
   }

   private static int Illl(int var0, int var1) {
      return lIl[var0 ^ -643386957] ^ var1 ^ var0;
   }

   private static String lIII(int var0, short var1, int var2) {
      int var3 = var0 ^ '铐';
      char[] var4 = llI[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])lll[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         lll[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 17466;
      int var9 = 0;

      do {
         int var10 = var4[var9] + 16194;
         var10 -= 61046;
         var10 ^= 41933;
         var10 += 53956;
         var10 += 2307;
         var10 -= 30970;
         var4[var9] = (char)(var10 ^ var8 ^ var1 ^ var2 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
