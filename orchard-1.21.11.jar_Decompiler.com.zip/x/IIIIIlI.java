package x;

import java.util.Objects;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

@Environment(EnvType.CLIENT)
public final class IIIIIlI extends IIIIIIIlI implements llIlIIII {
   private final lIIIIl I = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIII(-947801045, 1272999104)), true));
   private static final <undefinedtype> l;
   private static final double II = (double)7.0F;
   private static final double Il = (double)18.0F;
   private final IIIllIIII lI = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IIII(-947801052, 1750794621)), (double)18.0F, (double)0.0F, (double)4000.0F, (double)1.0F)).IIIl(lIlIII.l(IIII(-947801051, 60260175))));
   private final lIlIlllI ll = (lIlIlllI)this.IIIlIll(new lIlIlllI(lIlIII.l(IIII(-947801041, 1812481675)), lIlIII.l(IIII(-947801048, -1847309927))));
   private final IIIllIIII III = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IIII(-947801050, -574464982)), (double)94.0F, (double)0.0F, (double)4000.0F, (double)1.0F)).IIIl(lIlIII.l(IIII(-947801049, 1568750749))));
   private final lIIIIl IIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIII(-947801047, -289664442)), true));
   private final IIIllIIII IlI = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IIII(-947801056, 715987311)), (double)100.0F, (double)75.0F, (double)200.0F, (double)5.0F)).IIIl(lIlIII.l(IIII(-947801055, -631810299))));
   private final lIIIIl Ill = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIII(-947801046, 1686258828)), true));
   private static final int[] lII;
   private static final String[] lIl;
   private static final Object[] llI;

   public double llll() {
      class_310 var1 = class_310.method_1551();
      return var1 != null && var1.field_1772 != null ? this.IlI(var1.field_1772, this.lII()) * this.II() : (double)42.0F * this.II();
   }

   public boolean IIlI(double var1, double var3) {
      return var1 >= this.Il() && var1 <= this.Il() + this.llll() && var3 >= this.Ill() && var3 <= this.Ill() + this.lIIl();
   }

   private double II() {
      return Math.max((double)0.75F, Math.min((double)2.0F, (Double)this.IlI.III() / (double)100.0F));
   }

   private void ll(class_332 var1, boolean var2) {
      class_310 var3 = class_310.method_1551();
      if (var1 != null && var3 != null && var3.field_1772 != null) {
         String var4 = this.lII();
         if (!var4.isEmpty() || var2) {
            if (var4.isEmpty()) {
               var4 = lIlIII.Il(IIII(-947801044, 2123050507));
            }

            double var5 = this.II();
            double var7 = this.Il();
            double var9 = this.Ill();
            class_327 var11 = var3.field_1772;
            double var12 = this.IlI(var11, var4);
            IIIIIIllI.IIIllI(var1);
            IIIIIIllI.IlII(var1, var7, var9);
            IIIIIIllI.lllI(var1, var5, var5);

            try {
               if ((Boolean)this.I.III() || var2) {
                  lllIIlI.lI(var1, l, (double)0.0F, (double)0.0F, var12, (double)18.0F, var2);
               }

               double var14 = (Boolean)this.I.III() ? (double)7.0F : (double)0.0F;
               Objects.requireNonNull(var11);
               double var16 = ((double)18.0F - (double)9.0F) * (double)0.5F;
               int var18 = lllIIlI.Illl(lll(116774476, 1660371672));
               boolean var19 = (Boolean)this.IIl.III();
               IIIIIIllI.IlIIll((Boolean)this.Ill.III(), () -> {
                  if (var19) {
                     IIIIIIllI.llII(var1, var11, var4, var14, var16, var18);
                  } else {
                     IIIIIIllI.llIl(var1, var11, var4, var14, var16, var18);
                  }

               });
            } finally {
               IIIIIIllI.lIIlIl(var1);
            }

         }
      }
   }

   public void IIl(class_332 var1, int var2, int var3, float var4) {
      this.ll(var1, false);
   }

   public double lIIl() {
      return (double)18.0F * this.II();
   }

   private double IlI(class_327 var1, String var2) {
      double var3 = (double)IIIIIIllI.IlIl(var1, var2);
      return (Boolean)this.I.III() ? (double)14.0F + var3 : var3;
   }

   public void lIlI(double var1, double var3) {
      this.lI.III(Math.max((double)0.0F, var1));
      this.III.III(Math.max((double)0.0F, var3));
   }

   static {
      short var6 = 17762;
      String var7 = "↼⇍↨ℕ⅌↉ⅹℕ\uf765\uf714\uf771\uf7cc\uf795\uf750\uf7a0\uf7cc繂縷縺细纴繠纏纆线繸绠縿總縭繶绣繍绱縞绥續纹縈繺縩縠縺縔线繖縁给繙縬繦绚纙繳纝纓纂繆红總縙繟繁继繌纎績绲绹绯縂繞縓繾縺縡纅繞縭络縆縴繯绖纴繊纡纂纴繅纶縦縿繀繲绺繎绰縠绦绑绣縘繟縯縬縈縚纹縱縸绮繘縼繮绚纈繊绫纅纖繳纮縵縕繲繂绻形弓彩忧従彇忀忈ꊈꊁꊙꈞꉺꊨꉹꉟꉲꊧꉾꊟꋴꊛꊔꈃꊃꉣꋏꉄ\uddd5\uddd8\udde3\udd48\udd23\uddf0\udd13\udd00埯埦埑坹圛埻圄圧圛埿圲垬垔埘埛圻碍磁碑砚硾碖砠硛硸碒确磱磶碔磷硙嬬孋孁寄ユわデ〈\ueeb5\ueec2\ueed8\uee5d滰溙滑渞ᧄᧉ᧮ᥙᤴ᧡\u192fᥭ\ue97c\ue957\ue94d\ue9c8";
      char[] var8 = "䕪䕪䔒䕪䕶䕪䕲䕲䕦䕦䕦䕦䕪䕦".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            lIl = var9;
            llI = new Object[var9.length];
            int var2 = -963556584;
            byte[] var0 = "¢\u0093ßy".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lII = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lII[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            l = null.ll;
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private String lII() {
      String var1 = this.ll.IlI();
      return var1 == null ? "" : var1;
   }

   public void IIIlI(class_332 var1, int var2, int var3, float var4) {
      this.ll(var1, false);
   }

   public IIIIIlI() {
      super((Object)lIlIII.l(IIII(-947801043, -1005819671)), lIllII.IIl, (Object)lIlIII.l(IIII(-947801042, 1294747555)));
   }

   public void III(class_332 var1, int var2, int var3, float var4, boolean var5) {
      this.ll(var1, var5);
   }

   public double Ill() {
      return (Double)this.III.III();
   }

   public double Il() {
      return (Double)this.lI.III();
   }

   private static int lll(int var0, int var1) {
      return lII[var0 ^ 116774476] ^ var1 ^ var0;
   }

   private static String IIII(int var0, int var1) {
      int var3 = var0 ^ -947801044;
      char[] var4 = lIl[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])llI[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         llI[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -1951228004;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 51;
               break;
            case 1:
               var9 = 122;
               break;
            case 2:
               var9 = 12;
               break;
            case 3:
               var9 = 137;
               break;
            case 4:
               var9 = 217;
               break;
            case 5:
               var9 = 37;
               break;
            case 6:
               var9 = 222;
               break;
            case 7:
               var9 = 214;
               break;
            case 8:
               var9 = 235;
               break;
            case 9:
               var9 = 46;
               break;
            case 10:
               var9 = 200;
               break;
            case 11:
               var9 = 96;
               break;
            case 12:
               var9 = 121;
               break;
            case 13:
               var9 = 30;
               break;
            case 14:
               var9 = 1;
               break;
            case 15:
               var9 = 175;
               break;
            case 16:
               var9 = 13;
               break;
            case 17:
               var9 = 207;
               break;
            case 18:
               var9 = 99;
               break;
            case 19:
               var9 = 182;
               break;
            case 20:
               var9 = 184;
               break;
            case 21:
               var9 = 209;
               break;
            case 22:
               var9 = 102;
               break;
            case 23:
               var9 = 58;
               break;
            case 24:
               var9 = 121;
               break;
            case 25:
               var9 = 18;
               break;
            case 26:
               var9 = 120;
               break;
            case 27:
               var9 = 68;
               break;
            case 28:
               var9 = 233;
               break;
            case 29:
               var9 = 96;
               break;
            case 30:
               var9 = 109;
               break;
            case 31:
               var9 = 138;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
