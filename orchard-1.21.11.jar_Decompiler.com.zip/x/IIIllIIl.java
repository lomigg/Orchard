package x;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;

@Environment(EnvType.CLIENT)
public final class IIIllIIl extends IIIIIIIlI implements llIlIIII {
   private final IIIllIIII I;
   private static final double l = (double)108.0F;
   private static final <undefinedtype> II;
   private final lIIIIl Il;
   private List<class_1309> lI;
   private static final double ll = (double)5.0F;
   private final IIIllIIII III;
   private final lIIIIl IIl;
   private final IIIllIIII IlI;
   private static String[] Ill;
   private final IIIllIIII lII;
   private final IIIllIIII lIl;
   private final lIIIIl llI;
   private static final int[] lll;
   private static final String[] IIII;
   private static final Object[] IIIl;

   public boolean IIlI(double var1, double var3) {
      return var1 >= this.Il() && var1 <= this.Il() + this.llll() && var3 >= this.Ill() && var3 <= this.Ill() + this.lIIl();
   }

   private void ll(class_332 var1, boolean var2, float var3) {
      class_310 var4 = class_310.method_1551();
      if (var1 != null && var4 != null && var4.field_1724 != null && var4.field_1687 != null && var4.field_1772 != null) {
         double var5 = this.lll();
         double var7 = (Double)this.I.III();
         double var9 = this.Il();
         double var11 = this.Ill();
         IIIIIIllI.IIIllI(var1);
         IIIIIIllI.IlII(var1, var9, var11);
         IIIIIIllI.lllI(var1, var5, var5);

         try {
            this.IIII(var1, var7, var2);
            this.IlII(var1, var7);
            this.llI(var1, var4, var7, var3);
         } finally {
            IIIIIIllI.lIIlIl(var1);
         }

      }
   }

   public double lIIl() {
      return (Double)this.I.III() * this.lll();
   }

   public double llll() {
      return (Double)this.I.III() * this.lll();
   }

   public double Il() {
      return (Double)this.IlI.III();
   }

   static {
      short var6 = 17285;
      String var7 = "쭺㫑⚰ⱡ\u2d68鴗츛쁙쐡왁杍㟏魊䗀ﳣ\u19ac났肂챗쫫줅ᴷ䕨䘫胀紛斊非蘚夰\ue17c뮰\udfba뢾ଲ劒뺌麾釕酎㧎\uaafe\u1ff0톕ᆞ斓嶀饞‧㈞ᥘ\uf01e\ue939淤倷驼燪厱\ue6c3ㄋ縴ዧ炌⬡ꯟ瞗ཀྵ鍘फ 력죺銵\u0cd1뎚줧⎒쒸鷘⠕筗獥蔇돛⯈棘し침낾䑲饶僗\ud94e藍\uf806놿㹅衩뗪㹧Lᚻ︌篘热냅\uf03e喰存듓餯좶\ue60a汗烚姄黢㭊\ue3f5ꈤ\uf211慻콦履৾ꏯ썆鋗쁜ᴟ◖\u1af9ꝙ矣ᓭ缼룂ᲅ턄ꏜ鋑㺶⸥ォ맚︺훛⚍";
      char[] var8 = "䎉䎁䎍䎍䎁䎁䎍䎁䎁䎍䎹䎕䎍".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IIII = var9;
            IIIl = new Object[var9.length];
            int var2 = -1775235656;
            byte[] var0 = "¥Ôù²O®\u008aæ\u009a¾ÀÇ¸¥àþwk©4Á#7ýdÂ4~}¤G\u008faî¼;·S\u0019\u0015%\u0095\u001d¨6\u0097¬*ÑÕ\u001biê\u001cTÇxj¼1LQàë&©nËç[«ÙxG\u008ePð\u0099þÞ\u0093\u009e~µ<d\u0092oÇy¬\u000e@ß¢\u008a\u0003?ff5Ñ\u0006°&#&¤BïSuÞ\u001aÃÌÇ¶ÿ$mêøK\u0017£\u0096°Ù, ú*+!\u0093*\u0000¸&".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lll = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lll[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            Ill = new String[Illl(405151208, 734194159)];
            IIll();
            II = null.III;
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public IIIllIIl() {
      super((Object)lIlIII.l(Ill[2]), lIllII.IIl, (Object)lIlIII.l(Ill[Illl(405151209, -1044866371)]));
      this.IlI = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(Ill[1]), (double)18.0F, (double)0.0F, (double)4000.0F, (double)1.0F)).IIl(lIlIII.Il(Ill[4])));
      this.lII = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(Ill[Illl(405151210, 346607762)]), (double)126.0F, (double)0.0F, (double)4000.0F, (double)1.0F)).IIl(lIlIII.Il(Ill[4])));
      this.I = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(Ill[Illl(405151211, 917762212)]), (double)108.0F, (double)72.0F, (double)180.0F, (double)2.0F)).IIl(lIlIII.Il(Ill[4])));
      this.III = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(Ill[Illl(405151212, -109201044)]), (double)36.0F, (double)8.0F, (double)128.0F, (double)1.0F)).IIl(lIlIII.Il(Ill[Illl(405151213, 1328883616)])));
      this.lIl = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(Ill[Illl(405151214, -355195858)]), (double)100.0F, (double)60.0F, (double)200.0F, (double)5.0F)).IIl(lIlIII.Il(Ill[5])));
      this.IIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(Ill[0]), true));
      this.llI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(Ill[3]), true));
      this.Il = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(Ill[Illl(405151215, -206415917)]), true));
      this.lI = List.of();
   }

   public void III(class_332 var1, int var2, int var3, float var4, boolean var5) {
      this.ll(var1, var5, var4);
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (var1 != null && var1.field_1687 != null && var1.field_1724 != null) {
         ArrayList var2 = new ArrayList();

         for(class_1297 var4 : var1.field_1687.method_18112()) {
            if (var4 instanceof class_1309) {
               class_1309 var5 = (class_1309)var4;
               if (this.IlIl(var1, var5)) {
                  var2.add(var5);
               }
            }
         }

         this.lI = var2.isEmpty() ? List.of() : List.copyOf(var2);
      } else {
         this.lI = List.of();
      }
   }

   private static String IlI(char[] var0, long var1, int var3) {
      int var4 = Illl(405151200, 903710642) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & Illl(405151201, 960825779);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   public void IIIlI(class_332 var1, int var2, int var3, float var4) {
      this.ll(var1, false, var4);
   }

   private Color lII() {
      return new Color(Illl(405151202, -1417474647), Illl(405151203, -1199457135), Illl(405151204, 1606618018));
   }

   private int llI(class_332 var1, class_310 var2, double var3, float var5) {
      double var6 = (double)0.0F;
      double var8 = (double)0.0F;
      double var12 = var6 + var3 * (double)0.5F;
      double var14 = var8 + var3 * (double)0.5F;
      double var16 = var3 * (double)0.5F - (double)5.0F;
      double var18 = Math.max((double)1.0F, (Double)this.III.III());
      double var20 = Math.toRadians((double)var2.field_1724.method_36454());
      double var22 = Math.sin(var20);
      double var24 = Math.cos(var20);
      float var26 = class_3532.method_15363(var5, 0.0F, 1.0F);
      class_243 var27 = var2.field_1724.method_30950(var26);
      int var28 = 0;

      for(class_1309 var30 : this.lI) {
         if (!var30.method_31481() && this.IlIl(var2, var30)) {
            class_243 var31 = var30.method_30950(var26);
            double var32 = var31.field_1352 - var27.field_1352;
            double var34 = var31.field_1350 - var27.field_1350;
            double var36 = Math.hypot(var32, var34);
            if (!(var36 > var18)) {
               double var38 = -(var32 * var24 + var34 * var22);
               double var40 = -var32 * var22 + var34 * var24;
               double var42 = var38 / var18 * var16;
               double var44 = -var40 / var18 * var16;
               var42 = class_3532.method_15350(var42, -var16, var16);
               var44 = class_3532.method_15350(var44, -var16, var16);
               int var46 = var30 instanceof class_1657 ? lllIIlI.IllI(lllIIlI.III(), Illl(405151205, 1678394484)) : IIIlllIII.lI(this.lII().getRGB(), Illl(405151206, -159601521));
               double var47 = var30 instanceof class_1657 ? 3.2 : 2.6;
               IIIIIIllI.IllIll(var1, var12 + var42 - var47 * (double)0.5F, var14 + var44 - var47 * (double)0.5F, var47, var47, 1.2, var46);
               ++var28;
            }
         }
      }

      return var28;
   }

   private double lll() {
      return (Double)this.lIl.III() / (double)100.0F;
   }

   private void IIII(class_332 var1, double var2, boolean var4) {
      if ((Boolean)this.Il.III() || var4) {
         lllIIlI.lI(var1, II, (double)0.0F, (double)0.0F, var2, var2, var4);
      }

   }

   public void IIl(class_332 var1, int var2, int var3, float var4) {
      this.ll(var1, false, var4);
   }

   public void lIlI(double var1, double var3) {
      class_310 var5 = class_310.method_1551();
      double var6 = Double.MAX_VALUE;
      double var8 = Double.MAX_VALUE;
      if (var5 != null && var5.method_22683() != null) {
         var6 = Math.max((double)0.0F, (double)var5.method_22683().method_4486() - this.llll());
         var8 = Math.max((double)0.0F, (double)var5.method_22683().method_4502() - this.lIIl());
      }

      this.IlI.III(Math.max((double)0.0F, Math.min(var1, var6)));
      this.lII.III(Math.max((double)0.0F, Math.min(var3, var8)));
   }

   public void lI() {
      this.lI = List.of();
   }

   public double Ill() {
      return (Double)this.lII.III();
   }

   private static void IIll() {
      Ill[0] = IlI(lIII(1504533891, 751857475).toCharArray(), 14650L, Illl(405151207, 572636198));
      Ill[1] = IlI(lIII(1504533890, 208030450).toCharArray(), 61706L, Illl(405151224, 834082571));
      Ill[2] = IlI(lIII(1504533889, 295249397).toCharArray(), 5155L, Illl(405151225, 1840756485));
      Ill[3] = IlI(lIII(1504533888, 1983541768).toCharArray(), 55081L, Illl(405151226, -68059033));
      Ill[4] = IlI(lIII(1504533895, 1295008704).toCharArray(), 42853L, Illl(405151227, -1655915587));
      Ill[5] = IlI(lIII(1504533894, -135525980).toCharArray(), 79462L, Illl(405151228, 1053628287));
      Ill[Illl(405151229, -1301118420)] = IlI(lIII(1504533893, -192126330).toCharArray(), 64954L, Illl(405151230, -459859876));
      Ill[Illl(405151231, -825642294)] = IlI(lIII(1504533892, 2024285409).toCharArray(), 67983L, Illl(405151216, 1125686547));
      Ill[Illl(405151217, -1144580367)] = IlI(lIII(1504533899, -469347377).toCharArray(), 29238L, Illl(405151218, 1023742148));
      Ill[Illl(405151219, -856079561)] = IlI(lIII(1504533898, 1035156960).toCharArray(), 24867L, Illl(405151220, -92324311));
      Ill[Illl(405151221, 1235283811)] = IlI(lIII(1504533897, 731197051).toCharArray(), 21316L, Illl(405151222, 1368220031));
      Ill[Illl(405151223, -1716156684)] = IlI(lIII(1504533896, 486556388).toCharArray(), 62288L, Illl(405151176, 1855445870));
      Ill[Illl(405151177, -1539493394)] = IlI(lIII(1504533903, 1786199540).toCharArray(), 96858L, Illl(405151178, 1565864387));
   }

   private void IlII(class_332 var1, double var2) {
      double var4 = (double)0.0F;
      double var6 = (double)0.0F;
      double var10 = var4 + var2 * (double)0.5F;
      double var12 = var6 + var2 * (double)0.5F;
      int var14 = lllIIlI.Il();
      IIIIIIllI.IlIlI(var1, var4 + (double)5.0F, var12, var4 + var2 - (double)5.0F, var12, (double)1.0F, var14);
      IIIIIIllI.IlIlI(var1, var10, var6 + (double)5.0F, var10, var6 + var2 - (double)5.0F, (double)1.0F, var14);
   }

   private boolean IlIl(class_310 var1, class_1309 var2) {
      if (var2 instanceof class_1657 var3) {
         return (Boolean)this.IIl.III() && IIlIIIIl.llIIl(var1, var3);
      } else {
         return (Boolean)this.llI.III() && var2 instanceof class_1308 && IIlIIIIl.IIllI(var1, var2);
      }
   }

   private static int Illl(int var0, int var1) {
      return lll[var0 ^ 405151208] ^ var1 ^ var0;
   }

   private static String lIII(int var0, int var1) {
      int var3 = var0 ^ 1504533891;
      char[] var4 = IIII[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IIIl[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IIIl[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -438410448;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 26;
               break;
            case 1:
               var9 = 191;
               break;
            case 2:
               var9 = 19;
               break;
            case 3:
               var9 = 169;
               break;
            case 4:
               var9 = 253;
               break;
            case 5:
               var9 = 67;
               break;
            case 6:
               var9 = 4;
               break;
            case 7:
               var9 = 161;
               break;
            case 8:
               var9 = 100;
               break;
            case 9:
               var9 = 144;
               break;
            case 10:
               var9 = 119;
               break;
            case 11:
               var9 = 16;
               break;
            case 12:
               var9 = 147;
               break;
            case 13:
               var9 = 240;
               break;
            case 14:
               var9 = 158;
               break;
            case 15:
               var9 = 23;
               break;
            case 16:
               var9 = 244;
               break;
            case 17:
               var9 = 66;
               break;
            case 18:
               var9 = 61;
               break;
            case 19:
               var9 = 98;
               break;
            case 20:
               var9 = 29;
               break;
            case 21:
               var9 = 249;
               break;
            case 22:
               var9 = 224;
               break;
            case 23:
               var9 = 180;
               break;
            case 24:
               var9 = 204;
               break;
            case 25:
               var9 = 78;
               break;
            case 26:
               var9 = 55;
               break;
            case 27:
               var9 = 213;
               break;
            case 28:
               var9 = 44;
               break;
            case 29:
               var9 = 225;
               break;
            case 30:
               var9 = 188;
               break;
            case 31:
               var9 = 143;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
