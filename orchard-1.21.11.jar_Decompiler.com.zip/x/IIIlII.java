package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1291;
import net.minecraft.class_1294;
import net.minecraft.class_6880;

@Environment(EnvType.CLIENT)
public final class IIIlII extends IIIIIIIlI {
   private static String[] I;
   private static final int[] l;
   private static final String[] II;
   private static final Object[] Il;

   private static String ll(char[] var0, long var1, int var3) {
      int var4 = llI(134295321, -459493355) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & llI(134295320, -1219872156);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   public boolean IlI(class_6880<class_1291> var1) {
      return this.IIIIIlI() && (class_1294.field_5919.equals(var1) || class_1294.field_38092.equals(var1) || class_1294.field_5916.equals(var1));
   }

   private static void lII() {
      I[0] = ll(lll(-822835251, -1406249136).toCharArray(), 58114L, llI(134295323, 1929997568));
      I[1] = ll(lll(-822835252, -1766628888).toCharArray(), 85844L, llI(134295322, 612965872));
   }

   static {
      short var6 = 31295;
      String var7 = "㇚笲脟ﬠ\ude1d\ue1d4혧氥瀚碴䒷\ueb64ᝌ鰧Ņ葅븿∞壕ႅೢꂅ怊單钺묣ᾎ춁蝇뙄耉峟\ue54f釅\uf46cⰙ쌪﹎雑돹云泫Ҡﰛ\uf48e瀠픔襅는贅䑑裣姍ퟵ鎇衃ꢮ麈ᚏ쫞섊꧟袶\ude7e\ue5d1簀톙괷\uf53cᰳ潔㒓璍늬\udcd2淠䖢\uf34b菞\ue5c7ꠣ콘֛ǭ";
      char[] var8 = "D\u0010".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            II = var9;
            Il = new Object[var9.length];
            int var2 = -670180370;
            byte[] var0 = "zü\u0016`gFÎm°ò nÓ÷á'".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            l = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               l[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            I = new String[2];
            lII();
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 116;
                     break;
                  case 1:
                     var10000 = 120;
                     break;
                  case 2:
                     var10000 = 17;
                     break;
                  case 3:
                     var10000 = 93;
                     break;
                  case 4:
                     var10000 = 33;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public IIIlII() {
      super((Object)lIlIII.l(I[1]), lIllII.ll, (Object)lIlIII.l(I[0]));
   }

   private static int llI(int var0, int var1) {
      return l[var0 ^ 134295321] ^ var1 ^ var0;
   }

   private static String lll(int var0, int var1) {
      int var3 = var0 ^ -822835251;
      char[] var4 = II[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])Il[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         Il[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 733308669;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 141;
               break;
            case 1:
               var9 = 2;
               break;
            case 2:
               var9 = 11;
               break;
            case 3:
               var9 = 85;
               break;
            case 4:
               var9 = 178;
               break;
            case 5:
               var9 = 161;
               break;
            case 6:
               var9 = 17;
               break;
            case 7:
               var9 = 161;
               break;
            case 8:
               var9 = 98;
               break;
            case 9:
               var9 = 208;
               break;
            case 10:
               var9 = 73;
               break;
            case 11:
               var9 = 124;
               break;
            case 12:
               var9 = 187;
               break;
            case 13:
               var9 = 166;
               break;
            case 14:
               var9 = 0;
               break;
            case 15:
               var9 = 109;
               break;
            case 16:
               var9 = 251;
               break;
            case 17:
               var9 = 188;
               break;
            case 18:
               var9 = 253;
               break;
            case 19:
               var9 = 60;
               break;
            case 20:
               var9 = 226;
               break;
            case 21:
               var9 = 78;
               break;
            case 22:
               var9 = 182;
               break;
            case 23:
               var9 = 237;
               break;
            case 24:
               var9 = 200;
               break;
            case 25:
               var9 = 255;
               break;
            case 26:
               var9 = 206;
               break;
            case 27:
               var9 = 68;
               break;
            case 28:
               var9 = 250;
               break;
            case 29:
               var9 = 103;
               break;
            case 30:
               var9 = 95;
               break;
            case 31:
               var9 = 119;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
