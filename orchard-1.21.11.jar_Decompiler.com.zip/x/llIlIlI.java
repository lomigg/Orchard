package x;

import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;

@Environment(EnvType.CLIENT)
public final class llIlIlI extends IIIIIIIlI {
   private static final int I = 9;
   private long II;
   private int Il;
   private final lIIIIl lI;
   private static final double ll = (double)0.5F;
   private static final long III = 180L;
   private final llllIlIl IIl;
   private long IlI;
   private int Ill;
   private boolean lII;
   private final IlIIIlIlI<<undefinedtype>> lIl;
   private long llI;
   private int lll;
   private int IIII;
   private int IIIl;
   private static final double IIlI = (double)25.0F;
   private float IIll;
   private final lIIIIl IlII;
   private static final <undefinedtype> IlIl;
   private static final double IllI = (double)3.0F;
   private final llllIlIl Illl;
   private class_243 lIII;
   private final lIIIIl lIIl;
   private long lIlI;
   private static final double lIll = (double)0.0F;
   private float llII;
   private class_3965 llIl;
   private static final <undefinedtype> lllI;
   private static final double llll = (double)0.25F;
   private boolean IIIII;
   private class_2338 IIIIl;
   private static final double IIIlI = 0.42;
   private boolean IIIll;
   private <undefinedtype> IIlII;
   private final lIIIIl IIlIl;
   private static final long IIllI = 650L;
   private static final double IIlll = 0.35;
   private final IlIIIlIlI<<undefinedtype>> IlIII;
   private static final double IlIIl = 0.12;
   private final llllIlIl IlIlI;
   private static final double IlIll = 0.55;
   private class_1309 IllII;
   private final IIIllIIII IllIl;
   private static final double IlllI = 0.001;
   private int Illll;
   private static final long lIIII = 175L;
   private static final double lIIIl = (double)1.25F;
   private final lIIIIl lIIlI;
   private long lIIll;
   private <undefinedtype> lIlII;
   private boolean lIlIl;
   private final IIIllIIII lIllI;
   private final IlIlIll lIlll;
   private static final double llIII = (double)9.0F;
   private final IlIIIlIlI<<undefinedtype>> llIIl;
   private static final int[] l;
   private static final String[] llIlI;
   private static final Object[] llIll;

   private static double ll(class_238 var0, class_2338 var1) {
      double var2 = Math.max((double)0.0F, Math.min(var0.field_1320, (double)var1.method_10263() + (double)1.0F) - Math.max(var0.field_1323, (double)var1.method_10263()));
      double var4 = Math.max((double)0.0F, Math.min(var0.field_1324, (double)var1.method_10260() + (double)1.0F) - Math.max(var0.field_1321, (double)var1.method_10260()));
      return var2 * var4;
   }

   private boolean IlI(class_310 var1, class_1309 var2) {
      return var1 != null && var1.field_1724 != null && var2 != null && IllllIlI.l(var2, var1.field_1724);
   }

   private <undefinedtype> lII(class_310 var1, List<class_2338> var2) {
      for(class_2338 var4 : var2) {
         <undefinedtype> var5 = this.IlII(var1, var4);
         if (var5 != null) {
            return var5;
         }
      }

      return null;
   }

   private void llI(class_310 var1, long var2) {
      if (!this.lIIII(var1, this.IllII)) {
         this.IIIll(var2);
      } else if (!IllllIlI.llI(var1, this.IllII)) {
         if (!this.lIIlI(var1, this.Ill)) {
            if (var2 - this.II > 650L) {
               this.IIIll(var2);
            } else {
               this.lIIll = var2;
            }

         } else {
            boolean var4 = this.IIIlIl(var1, this.IllII);
            if (var4 && var1.field_1724 != null) {
               this.Illll = var1.field_1724.field_6012;
            }

            if (!var4 || !this.lIII(var1, var2)) {
               this.IIIll(var2);
            }
         }
      }
   }

   private boolean lll() {
      double var1 = (Double)this.IllIl.III();
      if (var1 >= (double)100.0F) {
         return true;
      } else if (var1 <= (double)0.0F) {
         return false;
      } else {
         return ThreadLocalRandom.current().nextDouble((double)100.0F) < var1;
      }
   }

   private void IIII(class_310 var1) {
      if (this.IIlII != null.Ill) {
         if (var1 != null && var1.field_1724 != null) {
            long var2 = System.currentTimeMillis();
            if (this.IIlII == null.IIl) {
               if (!this.lIIII(var1, this.IllII)) {
                  this.IIIll(var2);
                  return;
               }

               if (!this.lIIlI(var1, this.Ill)) {
                  if (var2 - this.II > 650L) {
                     this.llII(var1);
                  }

                  return;
               }

               if (var2 >= this.lIIll) {
                  this.IIlII = null.l;
                  this.II = var2;
                  this.lIIll = var2 + this.IllII(this.IIl);
                  if (var2 >= this.lIIll) {
                     this.llI(var1, var2);
                  }
               }
            } else if (this.IIlII == null.l) {
               if (var2 >= this.lIIll) {
                  this.llI(var1, var2);
               }
            } else if (this.IIlII == null.II) {
               this.llI(var1, var2);
            } else if (this.IIlII == null.I) {
               if (var2 >= this.lIIll) {
                  this.IIIIlI(var1, var2);
               }
            } else if (this.IIlII == null.III) {
               if (var2 >= this.lIIll) {
                  if (!this.IlIIl(var1)) {
                     if (var2 - this.II > 650L) {
                        this.IIIll(var2);
                        return;
                     }

                     this.lIIll = var2;
                     return;
                  }

                  this.IIlII = null.IlI;
                  this.II = var2;
                  this.lIIll = var2 + this.IllII(this.IlIlI);
               }
            } else if (this.IIlII == null.IlI) {
               if (IllllIlI.lIIlI(var1.field_1724.method_31548()) != this.Il) {
                  this.IIlII = null.III;
                  this.II = var2;
                  this.lIIll = var2;
                  return;
               }

               if (this.IlIII.III() == null.I) {
                  if (var2 - this.II >= 1500L) {
                     this.IIlII = null.ll;
                     this.II = var2;
                     this.lIIll = var2 + this.IllII(this.IIl);
                     return;
                  }

                  float var4 = this.lIlll.IlIl(var1, this.lIII, ((Double)this.lIllI.III()).floatValue());
                  if (var4 <= 0.5F) {
                     this.IIlII = null.ll;
                     this.II = var2;
                     this.lIIll = var2 + this.IllII(this.IIl);
                  }
               } else if (var2 >= this.lIIll) {
                  if (!this.IIll(var1)) {
                     this.IIIll(var2);
                     return;
                  }

                  this.IIlII = null.ll;
                  this.II = var2;
                  this.lIIll = var2 + this.IllII(this.IIl);
               }
            } else if (this.IIlII == null.ll) {
               if (this.lII) {
                  if (var2 - this.II > 650L) {
                     this.IIIll(var2);
                  }

                  return;
               }

               if (IllllIlI.lIIlI(var1.field_1724.method_31548()) != this.Il) {
                  this.IIlII = null.III;
                  this.II = var2;
                  this.lIIll = var2 + this.IllII(this.IlIlI);
                  return;
               }

               if (var2 >= this.lIIll && !this.llIlI(var1, this.IllII)) {
                  if (var2 - this.II <= 650L) {
                     this.lIIll = var2;
                  } else {
                     this.IIIll(var2);
                  }
               }
            } else if (this.IIlII == null.Il && var2 >= this.lIIll) {
               if (!(Boolean)this.lI.III()) {
                  IllllIlI.IlII(var1, this, null.Il);
                  this.IIIIIl();
                  return;
               }

               this.IIlIll(var2);
               if (this.llIII(var1) && var2 - this.II <= 650L) {
                  this.lIIll = var2;
                  return;
               }

               this.llII(var1);
            }

         } else {
            this.IIIIIl();
         }
      }
   }

   private boolean IIll(class_310 var1) {
      if (!this.lIllI(var1)) {
         return false;
      } else if (this.IlIII.III() == null.II) {
         return true;
      } else {
         IllllIlI.IIIlIII(var1, this.llII, this.IIll);
         return true;
      }
   }

   private <undefinedtype> IlII(class_310 var1, class_2338 var2) {
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null && var2 != null && this.lllll(var1, var2)) {
         double var3 = Math.max((double)0.0F, var1.field_1724.method_55754() - 0.1);

         for(class_2350 var8 : class_2350.values()) {
            class_2338 var9 = var2.method_10093(var8);
            if (this.IlIIIl(var1, var9)) {
               class_2350 var10 = var8.method_10153();
               class_243 var11 = class_243.method_24953(var9).method_1019(class_243.method_24954(var10.method_62675()).method_1021((double)0.5F));
               if (!(var1.field_1724.method_33571().method_1025(var11) > var3 * var3)) {
                  class_243 var12 = var11.method_1020(class_243.method_24954(var10.method_62675()).method_1021(0.001));
                  class_3965 var13 = var1.field_1687.method_17742(new class_3959(var1.field_1724.method_33571(), var12, class_3960.field_17559, class_242.field_1348, var1.field_1724));
                  if (var13 != null && var13.method_17777().equals(var9) && var2.equals(var9.method_10093(var13.method_17780()))) {
                     return new Record(var2.method_10062(), var9.method_10062(), var11, var13) {
                        private final class_2338 I;
                        private final class_2338 l;
                        private final class_243 II;
                        private final class_3965 Il;

                        public class_3965 I() {
                           return this.Il;
                        }

                        public class_243 l() {
                           return this.II;
                        }

                        public class_2338 II() {
                           return this.I;
                        }

                        public class_2338 Il() {
                           return this.l;
                        }

                        private {
                           this.l = var1;
                           this.I = var2;
                           this.II = var3;
                           this.Il = var4;
                        }
                     };
                  }
               }
            }
         }

         return null;
      } else {
         return null;
      }
   }

   private boolean IlIl(class_310 var1, class_1309 var2) {
      lIllIIl var3 = lIllIIl.Il();
      if (var3 == null) {
         return false;
      } else {
         IIIIIIIIl var4 = var3.IIl().lIlll();
         return var4 != null && var4.IIIIIlI() && (var4.IIlll(var2) || var4.IlllII(var1, var2));
      }
   }

   public boolean Illl() {
      return this.IIlIlI();
   }

   private boolean lIII(class_310 var1, long var2) {
      if ((Boolean)this.IlII.III() && this.IIllIl(var1, this.IllII)) {
         this.IIIl = this.Ill;
         this.IIlII = null.I;
         this.II = var2;
         this.lIIll = var2 + this.IllII(this.IIl);
         this.llI = 0L;
         return true;
      } else {
         return false;
      }
   }

   private boolean lIIl(class_310 var1, class_1309 var2) {
      if (var1 != null && var1.field_1724 != null && var2 != null) {
         class_243 var3 = var1.field_1724.method_33571();
         class_238 var4 = var2.method_5829();
         double var5 = Math.max(var4.field_1323, Math.min(var3.field_1352, var4.field_1320));
         double var7 = Math.max(var4.field_1322, Math.min(var3.field_1351, var4.field_1325));
         double var9 = Math.max(var4.field_1321, Math.min(var3.field_1350, var4.field_1324));
         if (var3.method_1028(var5, var7, var9) > (double)9.0F) {
            return false;
         } else {
            class_3966 var11 = IllllIlI.IlIIllI(var1, (double)3.0F);
            return var11 != null && var11.method_17782() == var2;
         }
      } else {
         return false;
      }
   }

   static {
      short var6 = 4825;
      String var7 = "餤飕餐颠饮飸饷閮ạἿṹḳἢṤὮṕẓḮἣṻ贜超赡贾赊跄趿跤赮贱趝跅趪跶跟贵跗跃跘趍샙쁑섎삋삃섩샘샧섆셆쁉섏셠섻섍셁섖삻쀆샠삮쀻섕섙셒섻쁼셏섧삯셩샠삤셆쁄샊셥삕삵셛삜섁색섳삫셝삃섎셗삕샐삍섗삻삷섹삫쀦섫섒쀆섻섍쀢น\u0eee\u0e7dປโ\u0edb໐\u0e85枺栯柟枑某松朁杞杸朮架杦朌柩栆桝廜弁弔彞廵庽廂弻弋彑弣弜彮弁庭常鑤鏬鎫鑖鐮鏌鑥鐂鎬鏶鏥鎹鎲鏭鎠鎏蹎躇躕軅踆蹍蹋躪躉軒躠踉▄☌♷☬◈◾▁◎♃☜♐♙☨♱☴♯䠡䟉䡶䣏꼃꿪꿰꾨꽃꾸꼊꾠꿀꾇꾀꾤⧰\u2d6e\u2d28ⵢ\u2d73ⴵⴿⴄⴢ⵿\u2d72ⵊ蹴蹬跫蹺ҘԐՏԜӍլҍӊՇԘՔ՝ԔխԸգｻﺛ＜ﺕⅽ⃠₦⃥Å₵\u20ca₄₾\u20f5\u209d₺\u20ca℺⃝₆锣醭锓钹醠锍锹铉铧镌醡银镴铎锗钢ᒧᔷᑬᓊᓩᑧᒒᑒᑼᐷᑅᔄ\udca0\udd3e\udc78\udc32\udd23\udc65\udcae\udce9\udc6f\udc3f\udc5b\udc74\udc1a\udc5a\udd37\udd6cኄྷዺኡ\ue8ae\ue93e\ue861\ue884\ue8e4\ue86e\ue8af\ue8e8\ue87e\ue824\ue8e4\ue87f\ue811\ue84c\ue90e\ue821侽佌俜伡倽佳偱佊佼伱值侌俬却匿卤侠來俹來匫却匘匱卐匙卌北⏩❇✡✋❪✧⏗✓❐✉⎼❍❆✈❊✑✚⎬✼⎰⎛⏫❨❕\ue5f9\ue977\ue951\ue97b\ue97a\ue937\ue5e3\ue90b\ue93d\ue976\ue97b\ue94c\ue933\ue586\ue95a\ue901\ue90a\ue59c\ue92c\ue580\ue58b\ue5db\ue978\ue945厢听厒匸吡厌厠叇卽匽吩卼匃单叜厬厷吂匀卙";
      char[] var8 = "ዑዕውኙዑዉዉዉዕዉዝዕዕዝዉዝዉዉዕዉዝዉዕዉ\u12c1\u12c1ው".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            llIlI = var9;
            llIll = new Object[var9.length];
            int var2 = 268258090;
            byte[] var0 = "\u0013õLÞ³f\u009fã7·\u001f¢\u0007'å\u0000í¦öf3$;¦\u0095òYu¸ª`±N¡\u0001]D;EóT\u008f9þ".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            l = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               l[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            IlIl = lIlIII.l(IllIII('텨', (short)9363, 1360291280));
            lllI = lIlIII.l(IllIII('텩', (short)7183, -770633784));
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 119;
                     break;
                  case 1:
                     var10000 = 34;
                     break;
                  case 2:
                     var10000 = 19;
                     break;
                  case 3:
                     var10000 = 72;
                     break;
                  case 4:
                     var10000 = 53;
                     break;
                  case 5:
                     var10000 = 8;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public void lllIl(class_310 var1) {
      this.llIII(var1);
      if (this.IIIll) {
         if (!this.lIll(var1)) {
            this.llII(var1);
         } else {
            if (System.currentTimeMillis() >= this.IlI) {
               this.IlIlIl(var1);
            }

         }
      }
   }

   private boolean lIll(class_310 var1) {
      return var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1690 != null && var1.field_1755 == null && var1.field_1724.method_5805();
   }

   private void llII(class_310 var1) {
      <undefinedtype> var2 = (Boolean)this.lI.III() ? null.II : null.Il;
      IllllIlI.IlII(var1, this, var2);
      this.IlIIII();
      this.lIlII = null;
      this.IIIIIl();
   }

   private boolean lllI(class_310 var1) {
      return var1 != null && var1.field_1724 != null ? IllllIlI.lllllI(var1.field_1724) : true;
   }

   private <undefinedtype> IIIII(class_310 var1, class_1309 var2) {
      if ((Boolean)this.IIlIl.III()) {
         <undefinedtype> var3 = this.lII(var1, this.lIlII(var1, var2));
         if (var3 != null) {
            return var3;
         }
      }

      return this.lII(var1, List.of(var2.method_24515()));
   }

   private boolean IIIIl(class_310 var1, class_1309 var2, int var3) {
      if (!this.llIIl(var1, var2, var3)) {
         return false;
      } else {
         this.IIII(var1);
         return true;
      }
   }

   private void IIIll(long var1) {
      this.IIlIl();
      this.IIlII = null.Il;
      this.II = var1;
      this.lIIll = var1 + Math.max(50L, this.IllII(this.IlIlI));
   }

   public void IllI(class_310 var1) {
      if (this.IIIIIlI() && var1 != null && var1.field_1724 != null && var1.field_1690 != null) {
         if (this.lllI(var1)) {
            this.IIIIll(var1);
            this.lIlIl = var1.field_1690.field_1886 != null && var1.field_1690.field_1886.method_1434();
         } else if (this.IIlII != null.Ill) {
            this.IIII(var1);
            IllllIlI.IIIIllI(var1.field_1690.field_1886);
         } else if (!this.llIII(var1)) {
            if (!this.IIIll) {
               boolean var4 = var1.field_1690.field_1886.method_1434();
               boolean var5 = var4 && !this.lIlIl;
               this.lIlIl = var4;
               class_1309 var3;
               if ((var5 || IllllIlI.IllIlI(var1.field_1690.field_1886) > 0) && this.lIIII(var1, var3 = IllllIlI.lIIII(var1, IllllIlI.IlIIllI(var1, (double)3.0F)))) {
                  if (this.IlIl(var1, var3)) {
                     return;
                  }

                  int var6 = this.IIIlII(var1);
                  if (var6 != -1 && this.IIIIl(var1, var3, var6)) {
                     IllllIlI.IIIIllI(var1.field_1690.field_1886);
                  }
               }

            }
         }
      } else {
         this.lIlIl = false;
      }
   }

   private boolean IIlII(class_310 var1, class_2338 var2, class_243 var3) {
      if (var1 != null && var1.field_1724 != null && var1.field_1761 != null && var2 != null && var3 != null) {
         class_3965 var4 = this.llIl != null ? this.llIl : new class_3965(var3, class_2350.field_11036, var2, false);
         float[] var5 = IlIlIl.llIlI(var1, var3);
         return var5 == null ? false : IlIlIl.IIIIlI(var1, IlIlll(1269278842, 1471131462), var5[0], var5[1], () -> {
            IllllIlI.lIllll(var1);
            class_1269 var3 = IllllIlI.lIlII(var1, class_1268.field_5808, var4);
            boolean var4x = var3 != null && var3.method_23665();
            if (var4x) {
               var1.field_1724.method_6104(class_1268.field_5808);
            }

            this.lII = false;
            long var5 = System.currentTimeMillis();
            if (var4x) {
               this.IIIll(var5);
            } else if (this.IIlII == null.ll) {
               this.lIIll = var5;
            }

            return var4x;
         });
      } else {
         return false;
      }
   }

   private void IIlIl() {
      this.Il = -1;
      this.IIIIl = null;
      this.lIII = null;
      this.llIl = null;
      this.llII = 0.0F;
      this.IIll = 0.0F;
      this.lII = false;
   }

   private void IIllI(class_310 var1, class_1309 var2, long var3) {
      if ((Boolean)this.IlII.III() && var2 != null && this.lIIll(var1, var2)) {
         this.IllII = var2;
         boolean var5 = var1 != null && var1.field_1724 != null && IllllIlI.lIIlI(var1.field_1724.method_31548()) == this.Il;
         this.IIlII = var5 ? null.IlI : null.III;
         this.II = var3;
         long var6 = Math.max(50L, this.IllII(this.Illl));
         this.lIIll = var3 + var6;
      } else {
         this.IIIll(var3);
      }
   }

   public boolean IIlll(class_310 var1, class_1309 var2) {
      if (this.IlllI(var1) && this.lIIII(var1, var2)) {
         if (this.IlIl(var1, var2)) {
            return false;
         } else {
            int var3 = this.IIIlII(var1);
            return var3 != -1 ? this.IIIIl(var1, var2, var3) : false;
         }
      } else {
         return false;
      }
   }

   public void lIl() {
      this.IlIIII();
      this.IIIIIl();
      this.lIlll.IIlIIII();
   }

   private boolean IlIIl(class_310 var1) {
      if (!this.lIllI(var1)) {
         return false;
      } else if (IllllIlI.lIIlI(var1.field_1724.method_31548()) == this.Il) {
         return true;
      } else {
         lIlIllll.lll(var1);
         return this.lIIlI(var1, this.Il);
      }
   }

   private boolean IlIll(class_310 var1, class_243 var2, class_2338 var3) {
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null && var2 != null && var3 != null) {
         class_3965 var4 = var1.field_1687.method_17742(new class_3959(var1.field_1724.method_33571(), var2, class_3960.field_17559, class_242.field_1348, var1.field_1724));
         return var4 != null && var4.method_17777().equals(var3);
      } else {
         return false;
      }
   }

   private long IllII(llllIlIl var1) {
      double var4 = var1.IlII();
      double var2;
      return var4 == (var2 = var1.IlI()) ? Math.max(0L, Math.round(var4)) : Math.max(0L, Math.round(ThreadLocalRandom.current().nextDouble(var4, var2)));
   }

   private boolean IllIl(class_310 var1) {
      if (var1 != null && var1.field_1724 != null && this.IIII >= 0 && this.IIII < IlIlll(1269278843, -147030853)) {
         this.IIlIll(System.currentTimeMillis());
         return !this.llIII(var1);
      } else {
         return true;
      }
   }

   private boolean IlllI(class_310 var1) {
      return this.IIIIIlI() && var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var1.field_1690 != null && var1.field_1755 == null && var1.field_1724.method_5805() && !this.lllI(var1);
   }

   private boolean lIIII(class_310 var1, class_1309 var2) {
      return var2 instanceof class_1657 && var2 != var1.field_1724 && var2.method_5805() && IllllIlI.l(var2, var1.field_1724) && this.lIIl(var1, var2);
   }

   private boolean lIIlI(class_310 var1, int var2) {
      if (var1 != null && var1.field_1724 != null && var2 >= 0 && var2 < IlIlll(1269278840, 1944976633)) {
         if (IllllIlI.lIIlI(var1.field_1724.method_31548()) == var2) {
            this.lIlII = null;
            return true;
         } else {
            if (this.lIlII == null || this.lIlII.ll() != var2) {
               this.lIlII = IllllIlI.lIll(var1, this, var2, 1, true);
            }

            if (!IllllIlI.IlIllII(var1, this.lIlII)) {
               return false;
            } else {
               this.lIlII = null;
               return true;
            }
         }
      } else {
         return false;
      }
   }

   private boolean lIIll(class_310 var1, class_1309 var2) {
      if ((Boolean)this.IlII.III() && (Boolean)this.lIIlI.III() && var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var2 != null) {
         if (IllllIlI.ll(var2)) {
            return false;
         } else if (!this.lll()) {
            return false;
         } else {
            int var3 = this.IlIllI(var1);
            if (var3 < 0) {
               return false;
            } else {
               <undefinedtype> var4 = this.IIIII(var1, var2);
               if (var4 == null) {
                  return false;
               } else {
                  float[] var5 = IlIlIl.llIlI(var1, var4.l());
                  if (var5 == null) {
                     return false;
                  } else {
                     this.Il = var3;
                     this.IIIIl = var4.II();
                     this.lIII = var4.l();
                     this.llIl = var4.I();
                     this.llII = var5[0];
                     this.IIll = var5[1];
                     return true;
                  }
               }
            }
         }
      } else {
         return false;
      }
   }

   private List<class_2338> lIlII(class_310 var1, class_1309 var2) {
      class_238 var3 = var2.method_5829();
      int var4 = (int)Math.floor(var3.field_1322 + 1.0E-4);
      class_243 var5 = this.IIllll(var1, var2);
      if (var5.method_1027() < 1.0E-6) {
         return List.of(var2.method_24515());
      } else {
         class_243 var6 = new class_243(-var5.field_1350, (double)0.0F, var5.field_1352);
         double var7 = var3.method_17939() * (double)0.5F;
         double var9 = var3.method_17941() * (double)0.5F;
         double var11 = Math.abs(var5.field_1352) * var7 + Math.abs(var5.field_1350) * var9;
         double var13 = Math.abs(var6.field_1352) * var7 + Math.abs(var6.field_1350) * var9;
         double var15 = (double)0.5F * (Math.abs(var6.field_1352) + Math.abs(var6.field_1350));
         double var17 = var13 + var15 + 0.08;
         class_243 var19 = new class_243(var2.method_18798().field_1352, (double)0.0F, var2.method_18798().field_1350);
         double var20 = var19.method_1033();
         double var22 = Math.max((double)0.0F, Math.min((double)1.0F, var20 / 0.34));
         double var24 = Math.max((double)0.0F, var19.method_1026(var5));
         double var26 = Math.max((double)-0.25F, Math.min((double)0.25F, var19.method_1026(var6)));
         double var28 = var1.field_1724.method_5624() ? 0.28 : (double)0.0F;
         double var30 = 0.65 + var28;
         double var32 = Math.max(var30, var11 * 0.45);
         double var34 = Math.max((double)0.75F + var30 * (double)0.5F, var11 + 0.35) + Math.min(0.55, var24 * (double)1.5F);
         double var36 = var32 + (var34 - var32) * var22;
         class_243 var38 = var5.method_1021(var36).method_1019(var6.method_1021(var26 * (double)0.5F * var22));
         class_238 var39 = var3.method_989(var38.field_1352 * (double)0.5F, (double)0.0F, var38.field_1350 * (double)0.5F);
         class_238 var40 = var3.method_989(var38.field_1352, (double)0.0F, var38.field_1350);
         class_243 var41 = new class_243(var2.method_23317(), (double)var4 + (double)0.5F, var2.method_23321());
         class_243 var42 = var41.method_1019(var38.method_1021((double)0.5F));
         class_243 var43 = var41.method_1019(var38);
         double var44 = Math.max(1.0E-6, var3.method_17939() * var3.method_17941());
         int var46 = (int)Math.floor(Math.min(Math.min(var3.field_1323, var39.field_1323), var40.field_1323)) - 1;
         int var47 = (int)Math.floor(Math.max(Math.max(var3.field_1320, var39.field_1320), var40.field_1320) - 1.0E-7) + 1;
         int var48 = (int)Math.floor(Math.min(Math.min(var3.field_1321, var39.field_1321), var40.field_1321)) - 1;
         int var49 = (int)Math.floor(Math.max(Math.max(var3.field_1324, var39.field_1324), var40.field_1324) - 1.0E-7) + 1;
         ArrayList var50 = new ArrayList();
         int[] var51 = var2.method_24828() && !(Math.abs(var2.method_18798().field_1351) > 0.08) ? new int[]{var4} : new int[]{var4, var4 - 1, var4 + 1};

         for(int var55 : var51) {
            for(int var56 = var46; var56 <= var47; ++var56) {
               for(int var57 = var48; var57 <= var49; ++var57) {
                  class_2338 var58 = new class_2338(var56, var55, var57);
                  class_243 var59 = class_243.method_24953(var58).method_1020(var41);
                  double var60 = var59.method_1026(var5);
                  double var62 = Math.abs(var59.method_1026(var6));
                  double var64 = ll(var3, var58) / var44;
                  double var66 = ll(var39, var58) / var44;
                  double var68 = ll(var40, var58) / var44;
                  double var70 = Math.max(var68, Math.max(var66 * 0.94, var64 * 0.86));
                  if (var55 != var4) {
                     var70 *= 0.8;
                  }

                  boolean var72 = var60 >= var11 + 0.12 && var62 <= var17;
                  boolean var73 = var60 >= var11 * 0.35 && var62 <= var17 && var66 >= 0.1625;
                  boolean var74 = var22 < (double)0.25F && var64 >= (double)0.25F && var62 <= var17 + 0.35;
                  int var75 = var72 && var68 >= (double)0.25F ? 3 : (var73 ? 2 : (var74 ? 1 : 0));
                  class_243 var76 = var75 >= 3 ? var43 : (var75 == 2 ? var42 : var41);
                  var50.add(new Record(var58, var75, var70, class_243.method_24953(var58).method_1025(var76), var62, var60) {
                     private final double I;
                     private final double l;
                     private final int II;
                     private final class_2338 Il;
                     private final double lI;
                     private final double ll;

                     public int I() {
                        return this.II;
                     }

                     public double l() {
                        return this.l;
                     }

                     public double II() {
                        return this.lI;
                     }

                     public class_2338 Il() {
                        return this.Il;
                     }

                     private {
                        this.Il = var1;
                        this.II = var2;
                        this.I = var3;
                        this.ll = var5;
                        this.l = var7;
                        this.lI = var9;
                     }

                     public double lI() {
                        return this.I;
                     }

                     public double ll() {
                        return this.ll;
                     }
                  });
               }
            }
         }

         var50.sort(Comparator.comparingInt(<undefinedtype>::I).reversed().thenComparing(Comparator.comparingDouble(<undefinedtype>::lI).reversed()).thenComparingDouble(<undefinedtype>::ll).thenComparingDouble(<undefinedtype>::l).thenComparingDouble(<undefinedtype>::II));
         return var50.stream().map(<undefinedtype>::Il).toList();
      }
   }

   public boolean lIlIl(class_1309 var1) {
      return IllllIlI.lllllI(var1);
   }

   private boolean lIllI(class_310 var1) {
      return (Boolean)this.IlII.III() && (Boolean)this.lIIlI.III() && var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && this.Il >= 0 && this.Il < IlIlll(1269278841, 1132267098) && this.IIIIl != null && this.lIII != null;
   }

   public boolean lIlll(class_1309 var1) {
      return var1 != null && this.IllII == var1 && this.IIlII != null.Ill && this.IIlII != null.Il;
   }

   private boolean llIII(class_310 var1) {
      if (this.lll >= 0 && this.lll < IlIlll(1269278846, -1443097285)) {
         if (var1 != null && var1.field_1724 != null) {
            if (var1.field_1724.field_6012 <= this.Illll) {
               return true;
            } else {
               int var2 = IllllIlI.lIIlI(var1.field_1724.method_31548());
               if (!this.IIIII && var2 != this.lll) {
                  IllllIlI.llll(var1, this, this.lll, 1);
                  this.IIIII = true;
               }

               if (var2 == this.lll) {
                  IllllIlI.IlII(var1, this, null.II);
                  this.IlIIII();
                  return false;
               } else if (System.currentTimeMillis() >= this.lIlI) {
                  IllllIlI.IlII(var1, this, null.II);
                  this.IlIIII();
                  return false;
               } else {
                  return true;
               }
            }
         } else {
            return true;
         }
      } else {
         return false;
      }
   }

   private boolean llIIl(class_310 var1, class_1309 var2, int var3) {
      if (var1 != null && var1.field_1724 != null && var1.method_1562() != null && var2 != null && var3 >= 0 && var3 < IlIlll(1269278847, 2004801786)) {
         this.IllII = var2;
         this.Ill = var3;
         this.IIII = IllllIlI.lIIlI(var1.field_1724.method_31548());
         long var4 = System.currentTimeMillis();
         this.IIlII = null.IIl;
         this.II = var4;
         boolean var6 = IllllIlI.IIlIl(var1) != var3;
         this.lIIll = var6 ? var4 + Math.max(50L, this.IllII(this.IlIlI)) : var4;
         return true;
      } else {
         return false;
      }
   }

   private boolean llIlI(class_310 var1, class_1309 var2) {
      if (var2 != null && var1 != null && var1.field_1724 != null && var1.field_1761 != null) {
         if (this.Il >= 0 && IllllIlI.lIIlI(var1.field_1724.method_31548()) == this.Il) {
            <undefinedtype> var3 = this.IIIII(var1, var2);
            if (var3 != null) {
               this.IIIIl = var3.II();
               this.lIII = var3.l();
               this.llIl = var3.I();
            }

            if (this.IIIIl != null && this.lIII != null) {
               this.lII = this.IIlII(var1, this.IIIIl, this.lIII);
               return this.lII;
            } else {
               return false;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private class_2338 llIll(class_310 var1, class_1309 var2) {
      <undefinedtype> var3 = this.IIIII(var1, var2);
      return var3 != null ? var3.Il() : null;
   }

   public boolean lllII() {
      return this.IIlII != null.Ill || this.IIIll;
   }

   private boolean lllll(class_310 var1, class_2338 var2) {
      if (var1 != null && var1.field_1687 != null && var2 != null) {
         class_2680 var3 = var1.field_1687.method_8320(var2);
         return var3.method_26215() || var3.method_45474() || var3.method_27852(class_2246.field_10382) || var3.method_27852(class_2246.field_10164);
      } else {
         return false;
      }
   }

   public llIlIlI() {
      super((Object)lIlIII.l(IllIII('텪', (short)22076, 1264340730)), lIllII.I, (Object)lIlIII.l(IllIII('텫', (short)'쇽', -1915737835)));
      this.lIl = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IllIII('텬', (short)21581, -903531745)), <undefinedtype>.class, null.l));
      this.lIIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IllIII('텭', (short)'鲩', -1090070)), true));
      this.llIIl = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IllIII('텮', (short)'韰', -103609225)), <undefinedtype>.class, null.l));
      this.lI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IllIII('텯', (short)6651, 250827191)), true));
      this.IlII = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IllIII('텠', (short)'\udcf9', -1035254712)), false));
      this.IIl = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(IllIII('텡', (short)9487, 65478608)), (double)0.0F, (double)0.0F, (double)0.0F, (double)300.0F, (double)5.0F)).Ill(lIlIII.l(IllIII('텢', (short)'첪', 140658527))));
      this.lIIlI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IllIII('텣', (short)'ꨇ', 292045189)), false));
      this.Illl = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(IllIII('텤', (short)12224, 239558701)), (double)0.0F, (double)0.0F, (double)0.0F, (double)300.0F, (double)5.0F)).Ill(lIlIII.l(IllIII('텥', (short)12294, 786648644))));
      this.IlIlI = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(IllIII('텦', (short)2306, -2131854505)), (double)55.0F, (double)60.0F, (double)0.0F, (double)300.0F, (double)5.0F)).Ill(lIlIII.l(IllIII('텧', (short)'넎', 1058027428))));
      this.IIlIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IllIII('텸', (short)'툥', -31173190)), true));
      this.IlIII = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IllIII('텹', (short)'좽', -780861357)), <undefinedtype>.class, null.II));
      this.lIllI = (IIIllIIII)this.IIIlIll((IIIllIIII)(new IIIllIIII(lIlIII.l(IllIII('텺', (short)32318, -428772660)), (double)50.0F, (double)1.0F, (double)100.0F, (double)1.0F)).lIII(() -> (Boolean)this.IlII.III() && (Boolean)this.lIIlI.III() && this.IlIII.III() == null.I));
      this.lIlll = new IlIlIll();
      this.IllIl = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IllIII('텻', (short)'띗', 1728084402)), (double)100.0F, (double)0.0F, (double)100.0F, (double)1.0F)).IIIl(lIlIII.l(IllIII('텼', (short)12389, -1412478149))));
      this.IIlII = null.Ill;
      this.Ill = -1;
      this.IIIl = -1;
      this.Il = -1;
      this.IIII = -1;
      this.IIIIl = null;
      this.lIII = null;
      this.llIl = null;
      this.IllII = null;
      this.lIlIl = false;
      this.lll = -1;
      this.Illll = IlIlll(1269278844, 1370012195);
      IlIIIlIlI var10000 = this.llIIl;
      lIIIIl var10001 = this.lIIl;
      Objects.requireNonNull(var10001);
      var10000.lIII(var10001::III);
      llllIlIl var1 = this.IIl;
      var10001 = this.IlII;
      Objects.requireNonNull(var10001);
      var1.lIII(var10001::III);
      lIIIIl var2 = this.lIIlI;
      var10001 = this.IlII;
      Objects.requireNonNull(var10001);
      var2.lIII(var10001::III);
      this.Illl.lIII(() -> (Boolean)this.IlII.III() && (Boolean)this.lIIlI.III());
      this.IIlIl.lIII(() -> (Boolean)this.IlII.III() && (Boolean)this.lIIlI.III());
      this.IlIII.lIII(() -> (Boolean)this.IlII.III() && (Boolean)this.lIIlI.III());
      this.IllIl.lIII(() -> (Boolean)this.IlII.III() && (Boolean)this.lIIlI.III());
   }

   private boolean IIIIII(class_310 var1, class_1309 var2) {
      if (var1 != null && var1.field_1724 != null && var2 != null) {
         class_243 var3 = var2.method_5828(1.0F);
         class_243 var4 = new class_243(var3.field_1352, (double)0.0F, var3.field_1350);
         class_243 var5 = new class_243(var1.field_1724.method_23317() - var2.method_23317(), var1.field_1724.method_23318() - var2.method_23318(), var1.field_1724.method_23321() - var2.method_23321());
         class_243 var6 = new class_243(var5.field_1352, (double)0.0F, var5.field_1350);
         if (!(var4.method_1027() < 1.0E-6) && !(var6.method_1027() < 1.0E-6)) {
            return var4.method_1029().method_1026(var6.method_1029()) > (double)0.0F;
         } else {
            return true;
         }
      } else {
         return false;
      }
   }

   private void IIIIIl() {
      this.IIlII = null.Ill;
      this.II = 0L;
      this.lIIll = 0L;
      this.llI = 0L;
      this.IllII = null;
      this.Ill = -1;
      this.IIIl = -1;
      this.IIII = -1;
      this.IIlIl();
      this.IIIll = false;
      this.IlI = 0L;
      this.Illll = IlIlll(1269278845, 2096137190);
      this.lIlII = null;
   }

   private void IIIIlI(class_310 var1, long var2) {
      if (!this.IIllIl(var1, this.IllII)) {
         this.IIIll(var2);
      } else if (!IllllIlI.llI(var1, this.IllII)) {
         if (var2 - this.II > 1200L) {
            this.IIIll(var2);
         } else if (IllllIlI.lllllI(this.IllII)) {
            if (this.llI == 0L && var2 - this.II < 175L) {
               this.lIIll = var2;
            } else {
               this.IIIll(var2);
            }
         } else if (this.llI == 0L) {
            this.llI = var2;
            this.lIIll = var2;
         } else if (var2 - this.llI < 25L) {
            this.lIIll = var2;
         } else if (IllllIlI.lllllI(this.IllII)) {
            this.IIIll(var2);
         } else if (!this.lIIlI(var1, this.Ill)) {
            this.lIIll = var2;
         } else if (this.IIIlIl(var1, this.IllII)) {
            if (var1.field_1724 != null) {
               this.Illll = var1.field_1724.field_6012;
            }

            this.IIllI(var1, this.IllII, var2);
         } else {
            this.lIIll = var2;
         }
      }
   }

   private void IIIIll(class_310 var1) {
      this.llII(var1);
   }

   private int IIIlII(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         for(int var2 = 0; var2 < IlIlll(1269278834, 184279564); ++var2) {
            class_1799 var3 = var1.field_1724.method_31548().method_5438(var2);
            if (var3.method_7909() instanceof class_1743) {
               return var2;
            }
         }

         return -1;
      } else {
         return -1;
      }
   }

   private boolean IIIlIl(class_310 var1, class_1309 var2) {
      if (var1 != null && var1.field_1724 != null && var1.field_1761 != null && var1.method_1562() != null && var2 != null) {
         if (IllllIlI.llI(var1, var2)) {
            return false;
         } else {
            class_3966 var3 = this.IIllII(var1, var2);
            if (var3 == null) {
               return false;
            } else {
               IllllIlI.IlIIlI(true);
               IllllIlI.lIlIl();

               boolean var4;
               try {
                  IllllIlI.IlIIIll(var1);
                  var4 = IllllIlI.lllII(var1, var3);
               } finally {
                  IllllIlI.IIlllI();
                  IllllIlI.IlIIlI(false);
               }

               return var4;
            }
         }
      } else {
         return false;
      }
   }

   public void IIIllI(class_310 var1) {
   }

   public boolean IIlIIl(class_1309 var1) {
      return var1 != null && this.IllII == var1 && this.IIlII != null.Ill;
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      this.llIII(var1);
      if (this.IIIll) {
         if (!this.lIll(var1)) {
            this.llII(var1);
         } else {
            if (System.currentTimeMillis() >= this.IlI) {
               this.IlIlIl(var1);
            }

         }
      }
   }

   public boolean IIlIlI() {
      return this.IIIIIlI() && (Boolean)this.IlII.III() && (Boolean)this.lIIlI.III() && (this.IIlII == null.III || this.IIlII == null.IlI || this.IIlII == null.ll);
   }

   private void IIlIll(long var1) {
      if (this.IIII >= 0 && this.IIII < IlIlll(1269278835, 6399651)) {
         if (this.lll != this.IIII) {
            this.lll = this.IIII;
            this.lIlI = var1 + 180L;
            this.IIIII = false;
         }
      }
   }

   public void IIl(JsonObject var1) {
      super.IIl(var1);
      this.llIlIl(var1, IlIl.lIlI(), new llllIlIl[]{this.IlIlI, this.IIl});
      this.llIlIl(var1, lllI.lIlI(), new llllIlIl[]{this.IlIlI, this.IIl});
      this.llIlIl(var1, lIlIII.Il(IllIII('텽', (short)15088, -1292300562)), new llllIlIl[]{this.IlIlI});
      this.llIlIl(var1, lIlIII.Il(IllIII('텾', (short)'\uf1ff', 1189417406)), new llllIlIl[]{this.IIl});
      this.llIlIl(var1, lIlIII.Il(IllIII('텿', (short)21070, -444506197)), new llllIlIl[]{this.IIl});
      this.llIlIl(var1, lIlIII.Il(IllIII('텰', (short)13348, 2145724803)), new llllIlIl[]{this.IlIlI});
      this.llIlIl(var1, lIlIII.Il(IllIII('텱', (short)'\udfd1', 1442852120)), new llllIlIl[]{this.IIl});
      this.llIlIl(var1, lIlIII.Il(IllIII('텲', (short)'퓚', 1875652449)), new llllIlIl[]{this.IIl});
      if (this.IlIlI.IlII() == (double)55.0F && this.IlIlI.IlI() == (double)60.0F) {
         this.IlIlI.IIIl(new double[]{(double)0.0F, (double)0.0F});
      }

      if (this.IIl.IlII() == (double)10.0F && this.IIl.IlI() == (double)25.0F) {
         this.IIl.IIIl(new double[]{(double)0.0F, (double)0.0F});
      }

   }

   public void lI() {
      this.IIIIll(class_310.method_1551());
      this.lIlll.IIIlIll();
   }

   private class_3966 IIllII(class_310 var1, class_1309 var2) {
      if (var1 != null && var1.field_1724 != null && var2 != null && this.lIIl(var1, var2)) {
         class_239 var5 = var1.field_1765;
         class_3966 var3;
         class_3966 var4 = var5 instanceof class_3966 ? (var3 = (class_3966)var5) : null;
         if (!this.IIlllI(var1, var4, var2)) {
            var4 = IllllIlI.IlIIllI(var1, (double)3.0F);
         }

         return this.IIlllI(var1, var4, var2) ? var4 : null;
      } else {
         return null;
      }
   }

   private boolean IIllIl(class_310 var1, class_1309 var2) {
      return var2 instanceof class_1657 && var2 != var1.field_1724 && var2.method_5805() && this.lIIl(var1, var2) && this.IIIIII(var1, var2);
   }

   private boolean IIlllI(class_310 var1, class_3966 var2, class_1309 var3) {
      return var1 != null && var1.field_1724 != null && var2 != null && var2.method_17782() == var3 && var1.field_1724.method_33571().method_1025(var2.method_17784()) <= (double)9.0F;
   }

   private class_243 IIllll(class_310 var1, class_1309 var2) {
      float var3 = (float)Math.toRadians((double)var1.field_1724.method_36454());
      class_243 var4 = new class_243(-Math.sin((double)var3), (double)0.0F, Math.cos((double)var3));
      class_243 var5 = new class_243(var2.method_23317() - var1.field_1724.method_23317(), (double)0.0F, var2.method_23321() - var1.field_1724.method_23321());
      if (var4.method_1027() < 1.0E-6) {
         return var5.method_1027() < 1.0E-6 ? class_243.field_1353 : var5.method_1029();
      } else {
         var4 = var4.method_1029();
         return var5.method_1027() > 1.0E-6 && var4.method_1026(var5.method_1029()) <= (double)0.0F ? var5.method_1029() : var4;
      }
   }

   private void IlIIII() {
      this.lll = -1;
      this.lIlI = 0L;
      this.IIIII = false;
   }

   private boolean IlIIIl(class_310 var1, class_2338 var2) {
      if (var1 != null && var1.field_1687 != null && var2 != null) {
         class_2680 var3 = var1.field_1687.method_8320(var2);
         return var3 != null && !var3.method_26215() && var3.method_26227().method_15769() && !var3.method_26220(var1.field_1687, var2).method_1110();
      } else {
         return false;
      }
   }

   public boolean IlIIlI(class_1309 var1) {
      return var1 != null && this.IllII == var1 && (this.IIlII == null.IIl || this.IIlII == null.l);
   }

   private void IlIlIl(class_310 var1) {
      if ((Boolean)this.lI.III()) {
         this.IIlIll(System.currentTimeMillis());
      }

      this.llIII(var1);
      this.IIIll = false;
      this.IlI = 0L;
      this.IllII = null;
      this.IIlII = null.Ill;
   }

   private int IlIllI(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         for(int var2 = 0; var2 < IlIlll(1269278832, 282450605); ++var2) {
            class_1799 var3 = var1.field_1724.method_31548().method_5438(var2);
            if (var3 != null && var3.method_31574(class_1802.field_8786)) {
               return var2;
            }
         }

         return -1;
      } else {
         return -1;
      }
   }

   private static int IlIlll(int var0, int var1) {
      return l[var0 ^ 1269278842] ^ var1 ^ var0;
   }

   private static String IllIII(char var0, short var1, int var2) {
      int var3 = var0 ^ '텨';
      char[] var4 = llIlI[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])llIll[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         llIll[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 25837;
      int var9 = 0;

      do {
         int var10 = var4[var9] - '뻐';
         var10 += 43370;
         var10 ^= 18565;
         var10 ^= 63151;
         var10 -= 39072;
         var4[var9] = (char)(var10 ^ var8 ^ var1 ^ var2 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
