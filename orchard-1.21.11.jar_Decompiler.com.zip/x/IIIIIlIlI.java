package x;

import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_4081;
import net.minecraft.class_6880;
import net.minecraft.class_746;
import net.minecraft.class_9334;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_239.class_240;

@Environment(EnvType.CLIENT)
public final class IIIIIlIlI extends IIIIIIIlI {
   private long I;
   private static final <undefinedtype> l;
   private static final <undefinedtype> II;
   private static final <undefinedtype> Il;
   private final lIlllII lI;
   private boolean ll;
   private static final <undefinedtype> III;
   private long IIl;
   private long IlI;
   private final lIIIIl Ill;
   private final IIIllIIII lII;
   private static final double lIl = (double)1.0F;
   private final llllIlIl llI;
   private final IlIlIll lll;
   private <undefinedtype> IIII;
   private static final int IIIl = 40;
   private int IIlI;
   private static final <undefinedtype> IIll;
   private static final double IlII = 0.05;
   private static final <undefinedtype> IlIl;
   private int IllI;
   private final IIIIllIII Illl;
   private final lIIIIl lIII;
   private static final <undefinedtype> lIIl;
   private final IlIIIlIlI<<undefinedtype>> lIlI;
   private static final long lIll = 700L;
   private static final <undefinedtype> llII;
   private final lIIIIl llIl;
   private long lllI;
   private static final float llll = 0.5F;
   private int IIIII;
   private static final <undefinedtype> IIIIl;
   private static final long IIIlI = 2000L;
   private long IIIll;
   private long IIlII;
   private static final <undefinedtype> IIlIl;
   private final lIIIIl IIllI;
   private int IIlll;
   private float IlIII;
   private static final long IlIIl = 700L;
   private class_1799 IlIlI;
   private static final <undefinedtype> IlIll;
   private static final List<<undefinedtype>> IllII;
   private long IllIl;
   private final lIIIIl IlllI;
   private static final long Illll = 1000L;
   private boolean lIIII;
   private final IIIllIIII lIIIl;
   private static final double lIIlI = 1.0E-4;
   private class_243 lIIll;
   private static final double lIlII = (double)0.5F;
   private int lIlIl;
   private int lIllI;
   private static final <undefinedtype> lIlll;
   private static final long llIII = 500L;
   private float llIIl;
   private final IIIllIIII llIlI;
   private final List<class_1799> llIll;
   private final llllIlIl lllII;
   private static final <undefinedtype> lllIl;
   private long llllI;
   private static final long lllll = 2500L;
   private final IIIllIIII IIIIII;
   private static final int IIIIIl = 9;
   private static final long IIIIlI = 250L;
   private static final long IIIIll = 1400L;
   private float IIIlII;
   private static final <undefinedtype> IIIlIl;
   private static final int[] IIIllI;
   private static final String[] IIIlll;
   private static final Object[] IIlIII;

   private boolean ll(class_746 var1) {
      return var1 != null && this.IlIII < var1.method_6063() - 0.25F;
   }

   private boolean IlI(class_1799 var1) {
      for(class_1799 var3 : this.llIll) {
         if (class_1799.method_31577(var3, var1)) {
            return true;
         }
      }

      return false;
   }

   private void lII(class_310 var1, long var2) {
      if (this.IIII == null.I) {
         if (this.IllI >= 0 && this.IllI < IIIIll(1946225897, 104056447) && var2 - this.IIIll <= 500L) {
            if (IllllIlI.lIIlI(var1.field_1724.method_31548()) == this.IllI) {
               if (var2 >= this.IllIl) {
                  if (!(Boolean)this.Ill.III() || this.IIlIl(var1)) {
                     this.IIIIlI(var1, var2);
                  }
               }
            } else {
               this.Illl(var1, this.IllI);
            }
         } else {
            this.IIII();
         }
      } else if (this.IIII != null.lI) {
         if (this.IIII == null.Il) {
            if (var1.field_1724.field_6012 >= this.lIlIl) {
               ++this.IIl;
               this.lIII(var1);
            }

         } else {
            if (this.IIII == null.ll && var1.field_1724.field_6012 >= this.IIlll) {
               if (this.lll(var1, var2)) {
                  return;
               }

               this.lIlll(var1);
            }

         }
      } else if (var2 - this.I >= 2000L) {
         this.IIIIlI(var1, var2);
      } else if (this.lIIll == null) {
         this.IIIIlI(var1, var2);
      } else {
         float var4 = this.lll.IlIl(var1, this.lIIll, ((Double)this.IIIIII.III()).floatValue());
         ++this.IIIII;
         if (var4 <= 0.5F || this.IIIII >= IIIIll(1946225896, 1123612327)) {
            this.IIIIlI(var1, var2);
         }

      }
   }

   public boolean llI() {
      if (!this.IIIIIlI()) {
         return false;
      } else if (this.IIII != null.II) {
         return true;
      } else {
         return this.lllI > 0L && System.currentTimeMillis() - this.lllI < 250L;
      }
   }

   private boolean lll(class_310 var1, long var2) {
      if (this.lIIIl(var1) && this.lIllI(var1, var2)) {
         if (this.lIIII) {
            if (!(Boolean)this.Ill.III() || !this.IIlIl(var1)) {
               return false;
            }
         } else if ((double)var1.field_1724.method_36455() < (Double)this.lII.III() || !this.lllI(var1)) {
            return false;
         }

         boolean var4 = this.IlIl(var1, var2);
         <undefinedtype> var5 = this.IlIII(var1.field_1724, var2, var4);
         if (var5 != null && (!var4 || !(var5.Il() <= 0.0F))) {
            if (var2 < this.llllI) {
               return true;
            } else {
               this.IllI = var5.I();
               this.IIIlII = var5.Il();
               this.IlIlI = var5.II();
               this.IIIll(var1, this.IllI, var2);
               if (IllllIlI.lIIlI(var1.field_1724.method_31548()) == this.IllI && var2 >= this.IllIl) {
                  this.IIIIlI(var1, var2);
                  return true;
               } else {
                  this.IIII = null.I;
                  this.IIIll = var2;
                  return true;
               }
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private void IIII() {
      ++this.IIl;
      this.IIII = null.II;
      this.IIIll = 0L;
      this.IllIl = 0L;
      this.IIlll = IIIIll(1946225899, 872348525);
      this.lIllI = -1;
      this.IIIlII = 0.0F;
      this.IlIlI = class_1799.field_8037;
      this.IllI = -1;
      this.IIlI = -1;
      this.lIlIl = IIIIll(1946225898, -495097844);
      this.lIIII = false;
      this.ll = false;
      this.llIll.clear();
      this.lIIll = null;
      this.I = 0L;
      this.IIIII = 0;
   }

   private boolean IIll(class_310 var1) {
      return var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var1.field_1690 != null && var1.field_1690.field_1904 != null && var1.field_1755 == null && var1.field_1724.method_5805();
   }

   private boolean IlII(class_310 var1, class_1309 var2) {
      return var1 != null && var1.field_1724 != null && var2 != null && var2 != var1.field_1724 && var2.method_5805() && !var2.method_31481();
   }

   private boolean IlIl(class_310 var1, long var2) {
      if ((Boolean)this.IlllI.III() && this.IIll(var1)) {
         float var4 = var1.field_1724.method_6032();
         float var5 = var1.field_1724.method_6063();
         if (var4 >= var5 - 0.25F) {
            this.lIlII();
            return false;
         } else {
            float var6 = this.IIIIII(var1.field_1724, var2);
            boolean var7 = (double)var6 <= (Double)this.llIlI.III();
            if (var7) {
               this.IIlII = var2 + 1400L;
            }

            boolean var8 = var2 <= this.IIlII;
            boolean var9 = var8 && var6 < var5 - 0.25F;
            if ((var7 || var8) && this.IlI > 0L && (double)var6 > (Double)this.llIlI.III()) {
               return var9;
            } else {
               return var7 || var9;
            }
         }
      } else {
         return false;
      }
   }

   private void Illl(class_310 var1, int var2) {
      IllllIlI.lIIllI(var1, this, var2);
   }

   private void lIII(class_310 var1) {
      this.lIlll(var1);
   }

   private boolean llII(class_6880<class_1291> var1, class_1293 var2) {
      <undefinedtype> var3 = this.IIIIl(var1, var2);
      return var3 != null && this.Illl.IIII(var3);
   }

   private boolean lllI(class_310 var1) {
      class_239 var3 = var1.field_1765;
      boolean var10000;
      if (var3 instanceof class_3965 var2) {
         if (var2.method_17783() == class_240.field_1332) {
            var10000 = true;
            return var10000;
         }
      }

      var10000 = false;
      return var10000;
   }

   private class_1309 IIIII(class_310 var1, long var2) {
      class_1309 var4 = this.lI != null ? this.lI.llII() : null;
      if (this.IlII(var1, var4)) {
         return var4;
      } else {
         var4 = this.lI != null ? this.lI.Ill() : null;
         return this.lI != null && this.lI.I(var2) <= 2500L && this.IlII(var1, var4) ? var4 : null;
      }
   }

   private <undefinedtype> IIIIl(class_6880<class_1291> var1, class_1293 var2) {
      int var3 = var2.method_5578();
      if (var1.equals(class_1294.field_5904)) {
         return var3 >= 1 ? IIll : llII;
      } else if (var1.equals(class_1294.field_5910)) {
         return var3 >= 1 ? l : II;
      } else if (var1.equals(class_1294.field_5918)) {
         return IlIll;
      } else if (var1.equals(class_1294.field_5924)) {
         return var3 >= 1 ? III : IIIlIl;
      } else if (var1.equals(class_1294.field_5913)) {
         return var3 >= 1 ? lIIl : Il;
      } else if (var1.equals(class_1294.field_5923)) {
         return IlIl;
      } else if (var1.equals(class_1294.field_5925)) {
         return IIlIl;
      } else if (var1.equals(class_1294.field_5905)) {
         return lIlll;
      } else if (var1.equals(class_1294.field_5906)) {
         return IIIIl;
      } else {
         return var1.equals(class_1294.field_5926) ? lllIl : null;
      }
   }

   private void IIIll(class_310 var1, int var2, long var3) {
      if (this.lIllI != var2) {
         boolean var5 = IllllIlI.IIlIl(var1) != var2;
         this.IllIl = var3 + (var5 ? this.IIlII(this.lllII) : 0L);
         this.lIllI = var2;
      }

      this.Illl(var1, var2);
   }

   private long IIlII(llllIlIl var1) {
      double var2 = var1.IlII();
      double var4 = var1.IlI();
      return var2 == var4 ? Math.max(0L, Math.round(var2)) : Math.max(0L, Math.round(ThreadLocalRandom.current().nextDouble(var2, var4)));
   }

   private boolean IIlIl(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         class_746 var2 = var1.field_1724;
         if (var2.method_24828()) {
            return true;
         } else {
            return var2.method_18798().field_1351 < (double)0.0F;
         }
      } else {
         return false;
      }
   }

   private boolean IIllI(class_310 var1) {
      if (!this.IIll(var1)) {
         return false;
      } else {
         float var2 = this.llIIl(var1);
         float var3 = this.llIII(var1);
         long var4 = ++this.IIl;
         return IlIlIl.IlIll(var1, IIIIll(1946225901, -1055159500), var2, var3, () -> {
            if (this.IIII == null.Il && var4 == this.IIl) {
               IllllIlI.lIllll(var1);
               class_1269 var4x = IllllIlI.lllIlI(var1, class_1268.field_5808);
               boolean var5 = var4x != null && var4x.method_23665();
               this.Illll(var1, var5);
               return var5;
            } else {
               return false;
            }
         });
      }
   }

   private void IIlll(class_310 var1, Object var2, long var3, boolean var5) {
      if (var1.field_1690 != null && var1.field_1690.field_1904 != null) {
         if (this.lIIIl(var1)) {
            class_746 var6 = var1.field_1724;
            this.llIll.clear();
            this.IIlI = IllllIlI.lIIlI(var6.method_31548());
            this.IllI = var2.I();
            this.IIIlII = var2.Il();
            this.IlIlI = var2.II();
            this.lIIII = var5;
            this.IIIll(var1, this.IllI, var3);
            if (IllllIlI.lIIlI(var6.method_31548()) == this.IllI && var3 >= this.IllIl) {
               this.IIIIlI(var1, var3);
            } else {
               this.IIII = null.I;
               this.IIIll = var3;
            }
         }
      }
   }

   private <undefinedtype> IlIII(class_746 var1, long var2, boolean var4) {
      <undefinedtype> var5 = null;

      for(int var6 = 0; var6 < IIIIll(1946225900, 970502563); ++var6) {
         class_1799 var7 = var1.method_31548().method_5438(var6);
         <undefinedtype> var8 = this.IlIll(var1, var7, var6, var2, var4);
         if (var8 != null && var8.l() > 0 && (!(var8.Il() <= 0.0F) || !this.IlI(var8.II())) && (var5 == null || var8.l() > var5.l())) {
            var5 = var8;
         }
      }

      return var5;
   }

   private <undefinedtype> IlIll(class_746 var1, class_1799 var2, int var3, long var4, boolean var6) {
      if (!this.llIll(var2)) {
         return null;
      } else {
         class_1844 var7 = (class_1844)var2.method_58694(class_9334.field_49651);
         int var8 = 0;
         boolean var9 = false;
         float var10 = 0.0F;
         int var11 = Math.max(0, (int)Math.round((Double)this.lIIIl.III() * (double)20.0F));

         for(class_1293 var13 : var7.method_57397()) {
            class_6880 var14 = var13.method_5579();
            class_1291 var15 = (class_1291)var14.comp_349();
            if (var15.method_18792() == class_4081.field_18272) {
               return null;
            }

            if (var15.method_18792() == class_4081.field_18271) {
               if (var15.method_5561()) {
                  float var16 = this.lIlIl(var13);
                  if (var16 > 0.0F) {
                     var10 += var16;
                     var9 = true;
                  }
               } else if (this.llII(var14, var13)) {
                  var9 = true;
                  class_1293 var20 = var1.method_6112(var14);
                  if (var20 == null) {
                     var8 += 120;
                  } else if (var13.method_5578() > var20.method_5578()) {
                     var8 += IIIIll(1946225903, -1291226656) + (var13.method_5578() - var20.method_5578()) * IIIIll(1946225902, 817274554);
                  } else if (!var20.method_48559() && var20.method_5584() <= var11) {
                     var8 += 55;
                  }
               }
            }
         }

         if (!var9) {
            return null;
         } else {
            if (var10 > 0.0F) {
               float var17 = this.IIIIII(var1, var4);
               boolean var18 = (double)var17 <= (Double)this.llIlI.III() && var17 < var1.method_6063() - 0.25F;
               if (!(Boolean)this.IlllI.III() || !var6 && !var18) {
                  return var8 > 0 ? new Record(var3, var8, 0.0F, var2.method_7972()) {
                     private final float I;
                     private final int l;
                     private final class_1799 II;
                     private final int Il;

                     public int I() {
                        return this.l;
                     }

                     public int l() {
                        return this.Il;
                     }

                     private {
                        this.l = var1;
                        this.Il = var2;
                        this.I = var3;
                        this.II = var4;
                     }

                     public class_1799 II() {
                        return this.II;
                     }

                     public float Il() {
                        return this.I;
                     }
                  } : null;
               }

               float var19 = Math.max(0.0F, var1.method_6063() - var17);
               if (var19 <= 0.25F) {
                  return var8 > 0 ? new Record(var3, var8, 0.0F, var2.method_7972()) {
                     private final float I;
                     private final int l;
                     private final class_1799 II;
                     private final int Il;

                     public int I() {
                        return this.l;
                     }

                     public int l() {
                        return this.Il;
                     }

                     private {
                        this.l = var1;
                        this.Il = var2;
                        this.I = var3;
                        this.II = var4;
                     }

                     public class_1799 II() {
                        return this.II;
                     }

                     public float Il() {
                        return this.I;
                     }
                  } : null;
               }

               var8 += IIIIll(1946225889, -588862154) + Math.round(Math.min(var10, var19) * 20.0F);
            }

            return var8 > 0 ? new Record(var3, var8, var10, var2.method_7972()) {
               private final float I;
               private final int l;
               private final class_1799 II;
               private final int Il;

               public int I() {
                  return this.l;
               }

               public int l() {
                  return this.Il;
               }

               private {
                  this.l = var1;
                  this.Il = var2;
                  this.I = var3;
                  this.II = var4;
               }

               public class_1799 II() {
                  return this.II;
               }

               public float Il() {
                  return this.I;
               }
            } : null;
         }
      }
   }

   public void lIl() {
      this.IIII();
      this.lIlII();
      this.llllI = 0L;
      this.IllIl = 0L;
      this.lllI = 0L;
      this.lll.IIlIIII();
   }

   private boolean IllII(long var1) {
      return this.IlI == 0L || this.lllI <= 0L || var1 - this.lllI >= 700L;
   }

   private void IllIl(class_310 var1) {
      if (var1 != null && var1.field_1690 != null && var1.field_1690.field_1904 != null) {
         IllllIlI.IIIIllI(var1.field_1690.field_1904);
         var1.field_1690.field_1904.method_23481(false);
      }
   }

   public void IIl(JsonObject var1) {
      super.IIl(var1);
      this.llIlIl(var1, lIlIII.Il(IIIlII(2134432963, 305024577)), new llllIlIl[]{this.llI});
      this.llIlIl(var1, lIlIII.Il(IIIlII(2134432962, -2098240012)), new llllIlIl[]{this.llI});
   }

   private double IlllI(class_310 var1, class_1309 var2) {
      if (var1.field_1687 != null && var2 != null) {
         class_238 var3 = var2.method_5829();
         double var4 = var3.field_1322;
         double var6 = Math.min(var3.field_1323 + 0.05, (var3.field_1323 + var3.field_1320) * (double)0.5F);
         double var8 = Math.max(var3.field_1320 - 0.05, (var3.field_1323 + var3.field_1320) * (double)0.5F);
         double var10 = Math.min(var3.field_1321 + 0.05, (var3.field_1321 + var3.field_1324) * (double)0.5F);
         double var12 = Math.max(var3.field_1324 - 0.05, (var3.field_1321 + var3.field_1324) * (double)0.5F);
         double var14 = (var3.field_1323 + var3.field_1320) * (double)0.5F;
         double var16 = (var3.field_1321 + var3.field_1324) * (double)0.5F;
         double[] var18 = new double[]{var6, var14, var8};
         double[] var19 = new double[]{var10, var16, var12};
         int var20 = (int)Math.floor(var4 - 1.0E-4);
         int var21 = Math.max(var1.field_1687.method_31607(), (int)Math.floor(var4 - (double)1.0F - (double)1.0F));
         double var22 = Double.POSITIVE_INFINITY;

         for(double var27 : var18) {
            for(double var32 : var19) {
               for(int var34 = var20; var34 >= var21; --var34) {
                  class_2338 var35 = class_2338.method_49637(var27, (double)var34, var32);
                  class_2680 var36 = var1.field_1687.method_8320(var35);
                  if (!var36.method_26215()) {
                     class_265 var37 = var36.method_26220(var1.field_1687, var35);
                     if (!var37.method_1110()) {
                        double var38 = (double)var35.method_10264() + var37.method_1105(class_2351.field_11052);
                        double var40 = Math.max((double)0.0F, var4 - var38);
                        var22 = Math.min(var22, var40);
                        if (var22 < (double)1.0F) {
                           return var22;
                        }
                     }
                  }
               }
            }
         }

         return var22;
      } else {
         return Double.POSITIVE_INFINITY;
      }
   }

   public IIIIIlIlI(lIlllII var1) {
      super((Object)lIlIII.l(IIIlII(2134432961, 1019307926)), lIllII.I, (Object)lIlIII.l(IIIlII(2134432960, 1925516907)));
      this.Ill = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIIlII(2134432967, -107341284)), false));
      IlIIIlIlI var10002 = new IlIIIlIlI(lIlIII.l(IIIlII(2134432966, 1596415129)), <undefinedtype>.class, null.Il);
      lIIIIl var10003 = this.Ill;
      Objects.requireNonNull(var10003);
      this.lIlI = (IlIIIlIlI)this.IIIlIll((IlIIIlIlI)var10002.lIII(var10003::III));
      this.lII = (IIIllIIII)this.IIIlIll((IIIllIIII)(new IIIllIIII(lIlIII.l(IIIlII(2134432965, 975333220)), (double)75.0F, (double)30.0F, (double)90.0F, (double)1.0F)).IIIl(lIlIII.l(IIIlII(2134432964, 527269351))).lIII(() -> !(Boolean)this.Ill.III()));
      this.lllII = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(IIIlII(2134432971, 216823486)), (double)55.0F, (double)60.0F, (double)0.0F, (double)300.0F, (double)5.0F)).Ill(lIlIII.l(IIIlII(2134432970, 918358204))));
      this.llI = (llllIlIl)this.IIIlIll((llllIlIl)(new llllIlIl(lIlIII.l(IIIlII(2134432969, 1632188154)), (double)0.0F, (double)0.0F, (double)0.0F, (double)250.0F, (double)1.0F)).Ill(lIlIII.l(IIIlII(2134432968, -784527153))).lIII(() -> false));
      this.lIIIl = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IIIlII(2134432975, 1169912567)), (double)3.0F, (double)0.0F, (double)30.0F, (double)0.5F)).IIIl(lIlIII.l(IIIlII(2134432974, 1489452903))));
      this.IlllI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIIlII(2134432973, 1807100254)), true));
      IIIllIIII var2 = (new IIIllIIII(lIlIII.l(IIIlII(2134432972, -747355184)), (double)10.0F, (double)1.0F, (double)20.0F, (double)0.5F)).IIIl(lIlIII.l(IIIlII(2134432979, -1676511006)));
      var10003 = this.IlllI;
      Objects.requireNonNull(var10003);
      this.llIlI = (IIIllIIII)this.IIIlIll((IIIllIIII)var2.lIII(var10003::III));
      this.lIII = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIIlII(2134432978, -1689693488)), false));
      this.llIl = (lIIIIl)this.IIIlIll((lIIIIl)(new lIIIIl(lIlIII.l(IIIlII(2134432977, 1434274586)), false)).lIII(() -> false).llll());
      this.Illl = (IIIIllIII)this.IIIlIll(new IIIIllIII(lIlIII.l(IIIlII(2134432976, -1933411752)), IllII, Set.of(IIll, l, IlIll)));
      this.IIllI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIIlII(2134432983, -253026399)), true));
      this.IIIIII = (IIIllIIII)this.IIIlIll((IIIllIIII)(new IIIllIIII(lIlIII.l(IIIlII(2134432982, 110759107)), (double)50.0F, (double)1.0F, (double)100.0F, (double)1.0F)).lIII(() -> (Boolean)this.Ill.III() && this.lIlI.III() == null.II));
      this.lll = new IlIlIll();
      this.IIII = null.II;
      this.IlIlI = class_1799.field_8037;
      this.IllI = -1;
      this.IIlI = -1;
      this.IIlll = IIIIll(1946225888, -1181647844);
      this.lIllI = -1;
      this.lIlIl = IIIIll(1946225891, 240861407);
      this.llIll = new ArrayList();
      this.lI = var1;
   }

   private void Illll(class_310 var1, boolean var2) {
      this.lIlIl = IIIIll(1946225890, 195191899);
      if (var2 && this.IIll(var1)) {
         class_746 var3 = var1.field_1724;
         long var4 = System.currentTimeMillis();
         this.lllI = var4;
         if (this.IIIlII <= 0.0F) {
            this.llIll.add(this.IlIlI.method_7972());
         }

         this.llllI = var4 + this.IIlII(this.llI);
         if (this.IIIlII > 0.0F) {
            this.IlIII = Math.min(var3.method_6063(), Math.max(var3.method_6032(), this.IIIIII(var3, var4)) + this.IIIlII);
            this.IlI = var4 + 1000L;
            this.IIlII = var4 + 1400L;
            if (!this.ll(var3)) {
               this.llllI = Math.max(this.llllI, var4 + 700L);
            }
         }

         this.IIII = null.ll;
         this.IIIll = var4;
         this.IIlll = var3.field_6012 + 1;
      } else {
         this.lIlll(var1);
      }
   }

   private void lIIII(class_310 var1, long var2) {
      if ((Boolean)this.Ill.III()) {
         if (var2 >= this.llllI) {
            if (this.lIIIl(var1) && this.IIlIl(var1) && this.lIllI(var1, var2)) {
               <undefinedtype> var4 = this.IlIII(var1.field_1724, var2, false);
               if (var4 != null && !(var4.Il() > 0.0F)) {
                  this.IIlll(var1, var4, var2, true);
               }
            }
         }
      }
   }

   private boolean lIIIl(class_310 var1) {
      return !(Boolean)this.lIII.III() || var1.field_1724 != null && var1.field_1724.method_24828();
   }

   private boolean lIIlI(class_310 var1) {
      if (!this.IIll(var1)) {
         return false;
      } else {
         IllllIlI.lIllll(var1);
         class_1269 var2 = IllllIlI.lllIlI(var1, class_1268.field_5808);
         boolean var3 = var2 != null && var2.method_23665();
         if (var3) {
            this.IllIl(var1);
         }

         return var3;
      }
   }

   private boolean lIIll(class_310 var1) {
      if (!this.IIll(var1)) {
         return false;
      } else {
         if (!this.ll) {
            this.llIIl = var1.field_1724.method_36455();
         }

         this.ll = true;
         var1.field_1724.method_36457(90.0F);
         IllllIlI.lIllll(var1);
         class_1269 var2 = IllllIlI.lllIlI(var1, class_1268.field_5808);
         boolean var3 = var2 != null && var2.method_23665();
         if (var3) {
            this.IllIl(var1);
         }

         return var3;
      }
   }

   public void lI() {
      this.IIII();
      this.lIlII();
      this.llllI = 0L;
      this.IllIl = 0L;
      this.lllI = 0L;
      this.lll.IIIlIll();
   }

   public void lllIl(class_310 var1) {
      if (this.IIII != null.II) {
         if (!this.IIll(var1)) {
            this.IIII();
         } else if (lIlIllll.lIIl(var1)) {
            this.IIII();
         } else if (!this.lIIIl(var1)) {
            this.IIII();
         } else {
            this.lII(var1, System.currentTimeMillis());
         }
      }
   }

   private void lIlII() {
      this.IlI = 0L;
      this.IlIII = 0.0F;
      this.IIlII = 0L;
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (!this.IIll(var1)) {
         this.IIII();
         this.lIlII();
      } else if (lIlIllll.lIIl(var1)) {
         this.IIII();
      } else {
         long var2 = System.currentTimeMillis();
         this.llllI(var1.field_1724, var2);
         if (this.IIII == null.II) {
            this.lIIII(var1, var2);
         } else if (!this.lIIIl(var1)) {
            if (this.IIII != null.II) {
               this.IIII();
            }

         } else if (this.IIII != null.II) {
            this.lII(var1, var2);
         }
      }
   }

   private float lIlIl(class_1293 var1) {
      if (!var1.method_5579().equals(class_1294.field_5915)) {
         return 0.0F;
      } else {
         return var1.method_5578() >= 1 ? 7.0F : 3.0F;
      }
   }

   private boolean lIllI(class_310 var1, long var2) {
      class_1309 var4 = this.IIIII(var1, var2);
      return var4 == null || this.IlllI(var1, var4) < (double)1.0F;
   }

   private void lIlll(class_310 var1) {
      if (this.ll && var1 != null && var1.field_1724 != null) {
         IlIlIl.IllI(var1, var1.field_1724.method_36454(), this.llIIl);
         this.ll = false;
      }

      if ((Boolean)this.IIllI.III() && this.IIlI >= 0 && this.IIlI < IIIIll(1946225893, -1802884950) && this.IIlI != this.IllI) {
         this.Illl(var1, this.IIlI);
      } else {
         IllllIlI.IlII(var1, this, null.Il);
      }

      this.IIII();
   }

   private float llIII(class_310 var1) {
      return 90.0F;
   }

   private float llIIl(class_310 var1) {
      return var1.field_1724.method_36454();
   }

   private boolean llIll(class_1799 var1) {
      if (var1 != null && !var1.method_7960() && var1.method_31574(class_1802.field_8436)) {
         class_1844 var2 = (class_1844)var1.method_58694(class_9334.field_49651);
         if (var2 != null && var2.method_57405()) {
            for(class_1293 var4 : var2.method_57397()) {
               class_1291 var5 = (class_1291)var4.method_5579().comp_349();
               if (var5.method_18792() == class_4081.field_18272) {
                  return false;
               }
            }

            return true;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   static {
      // $FF: Couldn't be decompiled
   }

   public boolean lllII() {
      return this.IIIIIlI() && this.IIII != null.II;
   }

   private void llllI(class_746 var1, long var2) {
      if (var1.method_6032() >= var1.method_6063() - 0.25F) {
         this.lIlII();
      } else if (this.lllI > 0L && var2 - this.lllI >= 700L && (double)var1.method_6032() <= (Double)this.llIlI.III() && (double)this.IlIII <= (Double)this.llIlI.III()) {
         this.IlI = 0L;
         this.IlIII = 0.0F;
      } else {
         if (var2 > this.IlI) {
            this.IlI = 0L;
            this.IlIII = 0.0F;
         }

      }
   }

   public void IllI(class_310 var1) {
      if (!this.IIll(var1)) {
         this.IIII();
         this.lIlII();
      } else if (lIlIllll.lIIl(var1)) {
         this.IIII();
      } else {
         long var2 = System.currentTimeMillis();
         this.llllI(var1.field_1724, var2);
         if (this.IIII != null.II) {
            this.lII(var1, var2);
         } else if (this.lIIIl(var1)) {
            boolean var4 = (double)var1.field_1724.method_36455() >= (Double)this.lII.III() && this.lllI(var1);
            boolean var5 = (Boolean)this.Ill.III();
            boolean var6 = this.IlIl(var1, var2);
            if (var2 >= this.llllI || var6 && this.IllII(var2)) {
               if (var4 || var5) {
                  if (!var5 || this.IIlIl(var1)) {
                     if (this.lIllI(var1, var2)) {
                        <undefinedtype> var7 = this.IlIII(var1.field_1724, var2, var6);
                        if (var7 != null) {
                           if (!var6 || !(var7.Il() <= 0.0F)) {
                              boolean var8 = !var4 && var5;
                              this.IIlll(var1, var7, var2, var8);
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   public IIIIIlIlI() {
      this((lIlllII)null);
   }

   private float IIIIII(class_746 var1, long var2) {
      if (var2 <= this.IlI) {
         return Math.max(var1.method_6032(), this.IlIII);
      } else {
         this.IlI = 0L;
         this.IlIII = 0.0F;
         return var1.method_6032();
      }
   }

   private void IIIIlI(class_310 var1, long var2) {
      if (this.lIIII && !(Boolean)this.Ill.III()) {
         this.IIII();
      } else {
         boolean var4;
         if (this.lIIII) {
            if (this.lIlI.III() != null.II) {
               var4 = this.IIllI(var1);
               if (var4) {
                  this.IllIl(var1);
                  this.IIII = null.Il;
                  this.IIIll = var2;
                  this.lIlIl = var1.field_1724.field_6012 + 1;
               } else {
                  this.lIlll(var1);
               }

               return;
            }

            if (this.IIII != null.lI) {
               class_746 var5 = var1.field_1724;
               this.lIIll = var5.method_33571().method_1031((double)0.0F, (double)-2.0F, (double)0.0F);
               this.I = var2;
               this.IIIII = 0;
               this.IIII = null.lI;
               this.IIIll = var2;
               return;
            }

            var4 = this.lIIll(var1);
         } else {
            var4 = this.lIIlI(var1);
         }

         this.Illll(var1, var4);
      }
   }

   private static int IIIIll(int var0, int var1) {
      return IIIllI[var0 ^ 1946225897] ^ var1 ^ var0;
   }

   private static String IIIlII(int var0, int var1) {
      int var3 = var0 ^ 2134432963;
      char[] var4 = IIIlll[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IIlIII[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IIlIII[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 1423069829;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 163;
               break;
            case 1:
               var9 = 60;
               break;
            case 2:
               var9 = 184;
               break;
            case 3:
               var9 = 46;
               break;
            case 4:
               var9 = 61;
               break;
            case 5:
               var9 = 130;
               break;
            case 6:
               var9 = 135;
               break;
            case 7:
               var9 = 49;
               break;
            case 8:
               var9 = 99;
               break;
            case 9:
               var9 = 145;
               break;
            case 10:
               var9 = 165;
               break;
            case 11:
               var9 = 24;
               break;
            case 12:
               var9 = 96;
               break;
            case 13:
               var9 = 191;
               break;
            case 14:
               var9 = 134;
               break;
            case 15:
               var9 = 101;
               break;
            case 16:
               var9 = 198;
               break;
            case 17:
               var9 = 96;
               break;
            case 18:
               var9 = 68;
               break;
            case 19:
               var9 = 191;
               break;
            case 20:
               var9 = 102;
               break;
            case 21:
               var9 = 227;
               break;
            case 22:
               var9 = 223;
               break;
            case 23:
               var9 = 210;
               break;
            case 24:
               var9 = 176;
               break;
            case 25:
               var9 = 80;
               break;
            case 26:
               var9 = 127;
               break;
            case 27:
               var9 = 140;
               break;
            case 28:
               var9 = 116;
               break;
            case 29:
               var9 = 170;
               break;
            case 30:
               var9 = 78;
               break;
            case 31:
               var9 = 95;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
