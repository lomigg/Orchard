package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;

@Environment(EnvType.CLIENT)
public final class IIIllllll {
   private static double I;
   private static boolean l;
   private static double II;
   private static long Il;
   private static double lI;
   private static final long ll = 250L;
   private static boolean III;
   private static double IIl;

   public static void I() {
      l = true;
      III = false;
      II = Double.POSITIVE_INFINITY;
      IIl = Double.POSITIVE_INFINITY;
      lI = Double.NEGATIVE_INFINITY;
      I = Double.NEGATIVE_INFINITY;
   }

   public static boolean l(class_310 var0, llIlIIII var1) {
      if (Il(var0) && var1 != null) {
         double var2 = (double)2.0F;
         double var4 = var1.Il();
         double var6 = var1.Ill();
         double var8 = var4 + var1.llll();
         double var10 = var6 + var1.lIIl();
         return var8 > II - var2 && var4 < lI + var2 && var10 > IIl - var2 && var6 < I + var2;
      } else {
         return false;
      }
   }

   public static void II() {
      l = false;
      if (III) {
         Il = System.currentTimeMillis();
      }

   }

   private static boolean Il(class_310 var0) {
      if (III && var0 != null && var0.field_1690 != null && var0.field_1690.field_1907 != null) {
         if (System.currentTimeMillis() - Il > 250L) {
            return false;
         } else {
            return var0.field_1690.field_1907.method_1434() || IllllIlI.IIIll(var0, var0.field_1690.field_1907);
         }
      } else {
         return false;
      }
   }

   private IIIllllll() {
   }

   public static void lI(int var0, int var1, int var2, int var3) {
      if (l) {
         int var4 = Math.min(var0, var2);
         int var5 = Math.max(var0, var2);
         int var6 = Math.min(var1, var3);
         int var7 = Math.max(var1, var3);
         if (var5 > var4 && var7 > var6) {
            II = Math.min(II, (double)var4);
            IIl = Math.min(IIl, (double)var6);
            lI = Math.max(lI, (double)var5);
            I = Math.max(I, (double)var7);
            III = true;
         }
      }
   }
}
