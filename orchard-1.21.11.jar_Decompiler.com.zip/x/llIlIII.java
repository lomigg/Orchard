package x;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_746;
import net.minecraft.class_8956;
import y.IIlIl;

@Environment(EnvType.CLIENT)
public final class llIlIII extends IIIIIIIlI {
   private static String[] I;
   private Object l;
   private static final int II = 2;
   private static final double Il = 0.65;
   private static final double lI = 1.35;
   private final IIIllIIII ll;
   private static final int III = 30;
   private int IIl;
   private final Map<Integer, Integer> IlI;
   private static final int[] Ill;
   private static final String[] lII;
   private static final Object[] lIl;

   private void ll(int var1) {
      Iterator var2 = this.IlI.entrySet().iterator();

      while(var2.hasNext()) {
         if ((Integer)((Map.Entry)var2.next()).getValue() <= var1) {
            var2.remove();
         }
      }

   }

   static {
      short var6 = 18554;
      String var7 = "䨿⊦Ꞵ擺퍙鎄䱤뭠濌늧\ud8f4彅\ue669曽\uf67dꈔ焄㴫⬟藝眗猵픅踫䴓丿斪臆閤氤ⴼ쿠ዟ櫓\uee38䇱䷚瓍\uda87\u0e64ꁖ뭫\uef07ꢜ钇ᱚ㒫蛦\ufaee\uf4ea\udc5eﰃ網挝嘼⇃\uf4df㼡㌒業传介炌墋逌㺁秙섢ဗ굳롮줝훳鳟闒툴᩠켾많끂噶\ue1a2萬\u19cc\uddb9厡㰄쟡ꭜ踬妺뎆㿼ꉝ\uf52c\uf7ae䋟ᦀ수쿼碝\u2fe7壹댑⁗匮\uf1a7둴\ueee4뫇ꊞ鬛킸켆唊䠼鞲쉱\udc1a䱄댑⇥옆嵏崦\uf8c8⤲툈\uf430\uf642瞒䡑";
      char[] var8 = "䡢䠮䡮䡾".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            lII = var9;
            lIl = new Object[var9.length];
            int var2 = 223981151;
            byte[] var0 = ",\u007f1\u001a\u0084Ð)36´Ý¬Ú\t«/6\u0094\u009fð¹@\u0016\u0080\u009bÏ!ø".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            Ill = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               Ill[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            I = new String[4];
            llI();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private double IlI(class_243 var1, class_243 var2, class_243 var3) {
      class_243 var4 = var3.method_1020(var2);
      double var5 = var4.method_1027();
      if (var5 <= 1.0E-8) {
         return var1.method_1025(var2);
      } else {
         double var7 = var1.method_1020(var2).method_1026(var4) / var5;
         var7 = Math.max((double)0.0F, Math.min((double)1.0F, var7));
         return var1.method_1025(var2.method_1019(var4.method_1021(var7)));
      }
   }

   private class_8956 lII(class_310 var1) {
      double var2 = (Double)this.ll.III();
      double var4 = var2 * var2;
      class_746 var6 = var1.field_1724;
      class_243 var7 = new class_243(var6.method_23317(), var6.method_23318() + 0.05, var6.method_23321());
      class_8956 var8 = null;
      double var9 = Double.MAX_VALUE;

      for(class_1297 var12 : var1.field_1687.method_18112()) {
         if (var12 instanceof class_8956 var13) {
            if (!var13.method_31481() && var13.method_5805() && !this.IlI.containsKey(var13.method_5628())) {
               double var14 = Math.min(var13.method_23318(), var13.method_23318() + var13.method_18798().field_1351);
               double var16 = Math.max(var13.method_23318(), var13.method_23318() + var13.method_18798().field_1351);
               if (!(var14 > var6.method_23318() + 1.35) && !(var16 < var6.method_23318() - 0.65)) {
                  class_243 var18 = new class_243(var13.method_23317(), var13.method_23318(), var13.method_23321());
                  class_243 var19 = var18.method_1019(var13.method_18798());
                  double var20 = this.IlI(var7, var18, var19);
                  if (var20 <= var4 && var20 < var9) {
                     var9 = var20;
                     var8 = var13;
                  }
               }
            }
         }
      }

      return var8;
   }

   private static void llI() {
      I[0] = lll(lIIl(2098083616, 1614835173).toCharArray(), 72510L, lIII(-1158009534, -1237829127));
      I[1] = lll(lIIl(2098083617, -1691203169).toCharArray(), 37572L, lIII(-1158009533, 1807969575));
      I[2] = lll(lIIl(2098083618, -991285431).toCharArray(), 51441L, lIII(-1158009536, -1728812589));
      I[3] = lll(lIIl(2098083619, -1002095263).toCharArray(), 92390L, lIII(-1158009535, 1443537770));
   }

   private static String lll(char[] var0, long var1, int var3) {
      int var4 = lIII(-1158009530, -2146902799) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & lIII(-1158009529, 249795943);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private void IIII() {
      this.IlI.clear();
      this.IIl = 0;
      this.l = null;
   }

   public llIlIII() {
      super((Object)lIlIII.l(I[0]), lIllII.III, (Object)lIlIII.l(I[1]));
      this.ll = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(I[2]), 1.15, (double)0.5F, (double)2.5F, 0.05)).IIl(lIlIII.Il(I[3])));
      this.IlI = new HashMap();
   }

   public void lI() {
      this.IIII();
   }

   private void IIll(class_746 var1) {
      ((IIlIl)var1).ilovcats$setJumpingCooldown(0);
   }

   private void IlII(class_310 var1) {
      if (this.l != var1.field_1687) {
         this.l = var1.field_1687;
         this.IlI.clear();
         this.IIl = 0;
      }
   }

   public boolean IlIl(class_310 var1) {
      if (this.IIIIIlI() && this.Illl(var1) && var1.field_1724.method_24828()) {
         this.IlII(var1);
         this.ll(var1.field_1724.field_6012);
         if (this.IIl > 0) {
            --this.IIl;
            this.IIll(var1.field_1724);
            return true;
         } else {
            class_8956 var2 = this.lII(var1);
            if (var2 == null) {
               return false;
            } else {
               this.IlI.put(var2.method_5628(), var1.field_1724.field_6012 + lIII(-1158009532, 745317117));
               this.IIl = 1;
               this.IIll(var1.field_1724);
               return true;
            }
         }
      } else {
         this.IIl = 0;
         return false;
      }
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (!this.Illl(var1)) {
         this.IIII();
      } else {
         this.IlII(var1);
         this.ll(var1.field_1724.field_6012);
      }
   }

   private boolean Illl(class_310 var1) {
      return var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1690 != null && var1.field_1755 == null && var1.field_1724.method_5805() && !var1.field_1724.method_31549().field_7479 && !var1.field_1724.method_5799() && !var1.field_1724.method_5869() && !var1.field_1724.method_5771() && !var1.field_1724.method_6101();
   }

   private static int lIII(int var0, int var1) {
      return Ill[var0 ^ -1158009534] ^ var1 ^ var0;
   }

   private static String lIIl(int var0, int var1) {
      int var3 = var0 ^ 2098083616;
      char[] var4 = lII[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])lIl[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         lIl[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 875597744;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 32;
               break;
            case 1:
               var9 = 25;
               break;
            case 2:
               var9 = 176;
               break;
            case 3:
               var9 = 10;
               break;
            case 4:
               var9 = 37;
               break;
            case 5:
               var9 = 119;
               break;
            case 6:
               var9 = 174;
               break;
            case 7:
               var9 = 182;
               break;
            case 8:
               var9 = 235;
               break;
            case 9:
               var9 = 166;
               break;
            case 10:
               var9 = 239;
               break;
            case 11:
               var9 = 193;
               break;
            case 12:
               var9 = 168;
               break;
            case 13:
               var9 = 244;
               break;
            case 14:
               var9 = 233;
               break;
            case 15:
               var9 = 3;
               break;
            case 16:
               var9 = 229;
               break;
            case 17:
               var9 = 236;
               break;
            case 18:
               var9 = 71;
               break;
            case 19:
               var9 = 176;
               break;
            case 20:
               var9 = 188;
               break;
            case 21:
               var9 = 52;
               break;
            case 22:
               var9 = 4;
               break;
            case 23:
               var9 = 210;
               break;
            case 24:
               var9 = 74;
               break;
            case 25:
               var9 = 68;
               break;
            case 26:
               var9 = 253;
               break;
            case 27:
               var9 = 61;
               break;
            case 28:
               var9 = 152;
               break;
            case 29:
               var9 = 63;
               break;
            case 30:
               var9 = 249;
               break;
            case 31:
               var9 = 225;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
