package x;

import [Ljava.lang.Object;;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_2596;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3675;

@Environment(EnvType.CLIENT)
public abstract class IIIIIIIlI {
   private boolean IlIlIII;
   private boolean IlIlIIl;
   private static final long IlIlIlI;
   private class_3675.class_306 IlIlIll;
   private static final long IlIllII;
   private boolean IlIllIl;
   private final boolean IlIlllI;
   private final List<llllllI<?>> IlIllll;
   private boolean IllIIII;
   private List<Object> IllIIIl;
   private class_3675.class_306 IllIIlI;
   private final <undefinedtype> IllIIll;
   private final <undefinedtype> IllIlII;
   private static final long IllIlIl;
   private final lIllII IllIllI;
   private static final int[] IllIlll;
   private static final String[] IlllIII;
   private static final Object[] IlllIIl;

   public String l() {
      return null;
   }

   protected final void llIlIl(JsonObject var1, String var2, llllIlIl... var3) {
      if (var1 != null && var2 != null && var3 != null && var1.has(lIlIII.Il(IlIIIll(1197526460, -225166559)))) {
         JsonObject var4 = var1.getAsJsonObject(lIlIII.Il(IlIIIll(1197526461, -1547367262)));
         JsonElement var5 = IlIIIIl(var4, lIlIII.II(var2));
         if (var5 != null) {
            for(llllIlIl var9 : var3) {
               if (var9 != null && IIIIlIl(var4, var9.lllI()) == null) {
                  var9.II(var5);
               }
            }

         }
      }
   }

   public <undefinedtype> llIllI() {
      return IIlIlIlll.l(this.lllllI(), this.IllIlII);
   }

   final void llIlll() {
      if (!this.IlIllIl) {
         this.IllIIIl = new ArrayList(this.IlIllll.size());

         for(llllllI var2 : this.IlIllll) {
            this.IllIIIl.add(IIlIlII(var2.III()));
         }

         this.IlIlIll = this.IllIIlI;
         this.IllIIII = this.IlIlIII;
         this.IlIllIl = true;
      }

   }

   public int IlIlI() {
      return 0;
   }

   public String lllIII() {
      String var10000 = this.llll();
      String var10001 = lIlIII.Il(IlIIIll(1197526462, 1972521091));
      String var10002 = Ill.Il().l();
      String var4 = lIlIII.Il(IlIIIll(1197526463, -485274658));
      String var3 = var10002;
      String var2 = var10001;
      String var1 = var10000;
      return var1 + var2 + var3 + var4;
   }

   public boolean lllIIl(double var1, double var3, int var5) {
      return false;
   }

   public void III(class_1297 var1) {
   }

   protected final void lllIll(JsonObject var1, String var2) {
      if (!this.IIlllll() && var1 != null && var2 != null && var1.has(lIlIII.Il(IlIIIll(1197526456, -1432206326)))) {
         JsonObject var3 = var1.getAsJsonObject(lIlIII.Il(IlIIIll(1197526457, -671402488)));
         long var4 = lIlIII.II(var2);
         JsonElement var6 = IlIIIIl(var3, var4);
         if (var6 != null) {
            this.IllIIlI = IllllIlI.lIIIIl(var6);
         }

      }
   }

   public void llllII(class_2596<?> var1) {
   }

   protected IIIIIIIlI(Object var1, lIllII var2, Object var3, boolean var4) {
      this.IlIllll = new ArrayList();
      this.IlIlIll = class_3675.field_16237;
      this.IllIIlI = class_3675.field_16237;
      this.IllIIll = lIlIII.IIIl(var1);
      this.IllIllI = var2;
      this.IllIlII = lIlIII.IIIl(var3);
      this.IlIlllI = var4;
      this.IlIlIII = !var4;
   }

   protected boolean lIll() {
      return true;
   }

   public String llll() {
      return this.IIlllII();
   }

   public final void llllIl(boolean var1) {
      if (this.IlIlllI && this.IlIlIIl != var1) {
         boolean var2 = this.IIIIIlI();
         this.IlIlIIl = var1;
         this.IIlIIIl(var2);
      }
   }

   public <undefinedtype> lllllI() {
      return this.IllIIll;
   }

   public String llllll() {
      return this.llIllI().lIlI();
   }

   public boolean IIIIIII() {
      return true;
   }

   public boolean IIIIIIl() {
      return false;
   }

   public boolean IIIIIlI() {
      return this.IlIlIII || this.IlIlIIl;
   }

   public String Il() {
      return "";
   }

   static void IIIIIll(JsonObject var0, long var1, JsonElement var3) {
      if (var0 != null) {
         var0.add(IIIllII(var1), var3);
      }

   }

   private boolean IIIIlII(llllllI<?> var1) {
      return var1 != null && var1.lllI() == IlIlIlI;
   }

   public String I() {
      return this.Il();
   }

   public boolean IIlI(class_310 var1) {
      return false;
   }

   static JsonElement IIIIlIl(JsonObject var0, long var1) {
      if (var0 == null) {
         return null;
      } else {
         String var3 = IIIllII(var1);
         if (var0.has(var3)) {
            return var0.get(var3);
         } else {
            for(Map.Entry var5 : var0.entrySet()) {
               if (lIlIII.II((String)var5.getKey()) == var1) {
                  return (JsonElement)var5.getValue();
               }
            }

            return null;
         }
      }
   }

   public void IIIlI(class_332 var1, int var2, int var3, float var4) {
   }

   public void IIIIllI(class_2596<?> var1) {
   }

   protected IIIIIIIlI(String var1, lIllII var2, String var3) {
      this(var1, var2, var3, true);
   }

   public void IIIIlll(class_310 var1) {
   }

   public class_3675.class_306 IIIlIII() {
      return this.IllIIlI;
   }

   public void II(class_1297 var1, byte var2) {
   }

   public boolean IIIlIIl(class_310 var1) {
      if (var1 == null) {
         return false;
      } else if (this.IIIIIIl() && this.IIlllll() && IllllIlI.IlIII(var1, this.IIIlIII()) && IllllIlI.IIlIllI(var1, this.IIIlIII())) {
         return true;
      } else {
         for(llllllI var3 : this.IlIllll) {
            if (var3 instanceof lllIIlIl) {
               lllIIlIl var4 = (lllIIlIl)var3;
               class_3675.class_306 var5 = (class_3675.class_306)var4.III();
               if (!IllllIlI.IllllI(var5) && IllllIlI.IlIII(var1, var5) && IllllIlI.IIlIllI(var1, var5)) {
                  return true;
               }
            }
         }

         return false;
      }
   }

   private void IIIlIlI() {
      lIllIIl var1 = lIllIIl.Il();
      if (var1 != null) {
         var1.IIlI();
      }

   }

   protected <T extends llllllI<?>> T IIIlIll(T var1) {
      this.IlIllll.add(var1);
      return (T)var1;
   }

   static String IIIllII(long var0) {
      String var2 = Long.toUnsignedString(var0, IlIIIlI(298429911, -496425451));
      String var3 = lIlIII.Il(IlIIIll(1197526458, 1341926563)).substring(0, IlIIIlI(298429910, -1087545095) - var2.length());
      return var3 + var2;
   }

   public void IIIllIl(boolean var1) {
      if (!this.IlIlllI) {
         this.IlIlIII = true;
      } else if (this.IlIlIII != var1) {
         if (var1 && !this.IIIIIII()) {
            this.IIllIlI();
         } else if (!var1 || this.lIll()) {
            boolean var2 = this.IIIIIlI();
            this.IlIlIII = var1;
            this.IIlIIIl(var2);
            IIlllIlI.II().I(this, var1);
            this.IIIlIlI();
         }
      }
   }

   public void IIIlllI() {
      this.IIIllIl(!this.IlIlIII);
   }

   public void IIIllll() {
      if (this.IlIllIl) {
         int var4 = Math.min(this.IlIllll.size(), this.IllIIIl.size());

         for(int var5 = 0; var5 < var4; ++var5) {
            llllllI var3 = (llllllI)this.IlIllll.get(var5);
            if (!(var3 instanceof IlIIIIllI)) {
               IIlIIII(var3, this.IllIIIl.get(var5));
            }
         }

         for(int var6 = var4; var6 < this.IlIllll.size(); ++var6) {
            llllllI var7 = (llllllI)this.IlIllll.get(var6);
            if (!(var7 instanceof IlIIIIllI)) {
               var7.IIl();
            }
         }

         this.IIlIlll(this.IlIlIll);
         this.IIIllIl(this.IllIIII);
      } else {
         for(llllllI var2 : this.IlIllll) {
            if (!(var2 instanceof IlIIIIllI)) {
               var2.IIl();
            }
         }

         this.IIlIlll(class_3675.field_16237);
         this.IIIllIl(!this.IlIlllI);
      }
   }

   public List<llllllI<?>> IIIlll() {
      ArrayList var1 = new ArrayList(this.IlIllll.size());

      for(llllllI var3 : this.IlIllll) {
         if (var3.lIlI() && !this.IIlIIll(var3)) {
            var1.add(var3);
         }
      }

      var1.sort(Comparator.comparingInt((var1x) -> this.IIIIlII(var1x) ? 1 : 0));
      return Collections.unmodifiableList(var1);
   }

   public JsonObject IlIlII() {
      JsonObject var1 = new JsonObject();
      var1.addProperty(lIlIII.Il(IlIIIll(1197526459, 824720758)), this.IlIlIII);
      JsonElement var2 = IllllIlI.llIIl(this.IllIIlI);
      if (var2 != null) {
         var1.add(lIlIII.Il(IlIIIll(1197526452, 1331696908)), var2);
      }

      JsonObject var3 = new JsonObject();

      for(llllllI var5 : this.IlIllll) {
         if (!(var5 instanceof IlIIIIllI) && var5.llIl() && lIlllllI.IIll(var5.III(), var5.l())) {
            var3.add(IIIllII(var5.lllI()), var5.lI());
         }
      }

      var1.add(lIlIII.Il(IlIIIll(1197526453, -1147583131)), var3);
      return var1;
   }

   public void IIl(JsonObject var1) {
      this.IllIIlI = class_3675.field_16237;

      for(llllllI var3 : this.IlIllll) {
         if (!(var3 instanceof IlIIIIllI) && var3.llIl()) {
            var3.IIl();
         }
      }

      if (var1.has(lIlIII.Il(IlIIIll(1197526454, 1731094063)))) {
         this.IllIIlI = IllllIlI.lIIIIl(var1.get(lIlIII.Il(IlIIIll(1197526455, -1366203461))));
      }

      if (var1.has(lIlIII.Il(IlIIIll(1197526448, -1213522847)))) {
         JsonObject var6 = var1.getAsJsonObject(lIlIII.Il(IlIIIll(1197526449, -1293980172)));

         for(llllllI var4 : this.IlIllll) {
            if (!(var4 instanceof IlIIIIllI) && var4.llIl()) {
               JsonElement var5 = IlIIIIl(var6, var4.lllI());
               if (var5 != null) {
                  var4.II(var5);
               }
            }
         }

      }
   }

   private static void IIlIIII(llllllI var0, Object var1) {
      var0.Il(IIlIlII(var1));
   }

   private void IIlIIIl(boolean var1) {
      boolean var2 = this.IIIIIlI();
      if (var1 != var2) {
         if (var2) {
            this.lIl();
         } else {
            try {
               this.lI();
            } finally {
               IllllIlI.IlII(class_310.method_1551(), this, null.II);
            }

         }
      }
   }

   public void IIlIIlI(class_2596<?> var1) {
   }

   private boolean IIlIIll(llllllI<?> var1) {
      if (!(this instanceof llIlIIII)) {
         return false;
      } else {
         long var2 = var1.lllI();
         return var2 == IllIlIl || var2 == IlIllII;
      }
   }

   private static Object IIlIlII(Object var0) {
      if (var0 instanceof double[] var6) {
         return (([D)var6).clone();
      } else if (var0 instanceof int[] var5) {
         return (([I)var5).clone();
      } else if (var0 instanceof long[] var4) {
         return (([J)var4).clone();
      } else if (var0 instanceof byte[] var3) {
         return (([B)var3).clone();
      } else if (var0 instanceof Object[] var2) {
         return ((Object;)var2).clone();
      } else if (var0 instanceof List var1) {
         return new ArrayList(var1);
      } else {
         return var0;
      }
   }

   public boolean IIlIlIl() {
      return this.IlIlllI;
   }

   public void lllIl(class_310 var1) {
   }

   public long IIlIllI() {
      return this.IllIIll.lll();
   }

   public void IIlIlll(class_3675.class_306 var1) {
      class_3675.class_306 var2 = var1 == null ? class_3675.field_16237 : var1;
      if (!Objects.equals(this.IllIIlI, var2)) {
         if (!IllllIlI.IllllI(var2)) {
            lIllIIl var3 = lIllIIl.Il();
            if (var3 != null && var3.IIl() != null) {
               for(IIIIIIIlI var5 : var3.IIl().IIIIlII()) {
                  if (var5 != this && Objects.equals(var5.IIIlIII(), var2)) {
                     var5.IIlIlll(class_3675.field_16237);
                  }
               }
            }
         }

         this.IllIIlI = var2;
         this.IIIlIlI();
      }
   }

   static void IIllIII(JsonObject var0, long var1) {
      if (var0 != null) {
         var0.remove(IIIllII(var1));
         ArrayList var3 = new ArrayList();

         for(String var5 : var0.keySet()) {
            if (lIlIII.II(var5) == var1) {
               var3.add(var5);
            }
         }

         for(String var7 : var3) {
            var0.remove(var7);
         }

      }
   }

   public void IIllIIl(JsonObject var1) {
      if (this.IlIlllI && var1 != null && var1.has(lIlIII.Il(IlIIIll(1197526450, -1563268661)))) {
         boolean var2 = var1.get(lIlIII.Il(IlIIIll(1197526451, 2061306087))).getAsBoolean();
         if (var2 && !this.IIIIIII()) {
            this.IlIlIII = false;
         } else {
            this.IIIllIl(var2);
         }
      }
   }

   protected void IIllIlI() {
      IIlllIlI.II().III(null.l, lIlIII.Il(IlIIIll(1197526444, 883314048)), this.lllIII(), 3200L);
   }

   public void IIllIll(class_1297 var1, int var2) {
   }

   public String IIlllII() {
      return this.IllIIll.lIlI();
   }

   public String IIlllIl() {
      String var1 = this.llll();
      String var2 = this.I();
      if (var2 != null && !var2.isBlank()) {
         String var10001 = lIlIII.Il(IlIIIll(1197526445, 845490694));
         String var6 = lIlIII.Il(IlIIIll(1197526446, -349945221));
         String var4 = var10001;
         return var1 + var4 + var2 + var6;
      } else {
         return var1;
      }
   }

   static {
      short var6 = 20588;
      String var7 = "\uec8f\uec22\uecf6\uecb2\uecf4\uec8f\uec24\uec8a\uec52\uec22\uec9e\uec83뷞뵳붧뷣붥뷞뵵뷛봃뵳뷏뷒毝歔殈殲殧殆欋殀歟欚毖毲毵殢歾毂殚毷毀欌殦殀毴每毯殛歯殚ﵟﷸﴅ﵆뒶됛듏뒋듍뒶됝뒳둫됛뒧뒺짯쥂즖짒즔짯쥄짪줲쥂짾짣秷祗禙秎禟称祵秠礽票禤禎禛秇礎禳秲秿禶祹秀禷禘秖ᏲጷᎺᏟᎉᏟፊᏹጨ፮Ꮱᏹ涿洐淄涏淙涗洖涸浠洦涩涱饄駩餽饹餿饄駯饁香駩饕饈읖쟹윭읦윰읾쟿응잉쟏은의\u0ee9ๆຒ໙ຏແเ\u0eeeึ\u0e70\u0eff\u0ee7៑\u177cឨ\u17ecឪ៑\u177a។ᜌ\u177cៀ៝እለዜኘዞእሎአቸለኴኩ髲騷骺髟骉髟驊髹騨驮髡髹䋽䈸䊵䋐䊆䋐䉅䋶䈧䉡䋮䋶ಚృ\u0cceವ\u0cfaಒఄಖ\u0c52బಞ\u0cf4\u0cfeದళೕಔ಄ಠదಥೂಿ\u0cff೭\u0cd9౧\u0cfaਘઐ\u0a44ਂ팛폋팀퍃ﴵﶁﵜﴵﵖﴭﶴﴔ\ufde3ﶳﴲ﵋ﵕﵥﶽﴞ祆禙祂礁칽캲칹츺";
      char[] var8 = "偠偠偰偨偠偠側偠偠偠偠偠偠偠偠偠偰偨偨偼偨偨".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IlllIII = var9;
            IlllIIl = new Object[var9.length];
            int var2 = -1809223118;
            byte[] var0 = "g\u0089ùà:Í¿\f".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IllIlll = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IllIlll[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            IlIlIlI = lIlIII.l(IlIIIll(1197526447, -784309195)).lll();
            IllIlIl = lIlIII.l(IlIIIll(1197526440, 1429043997)).lll();
            IlIllII = lIlIII.l(IlIIIll(1197526441, -501855926)).lll();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   protected IIIIIIIlI(String var1, lIllII var2, String var3, boolean var4) {
      this((Object)var1, var2, (Object)var3, var4);
   }

   public void IllI(class_310 var1) {
   }

   public void lIlI(class_1297 var1) {
   }

   protected IIIIIIIlI(Object var1, lIllII var2, Object var3) {
      this(var1, var2, var3, true);
   }

   public <undefinedtype> IIllllI() {
      return this.IllIIll;
   }

   public boolean IIlllll() {
      return !IllllIlI.IllllI(this.IllIIlI);
   }

   public void llIl(llIIllI var1) {
   }

   public void IIIl(class_2596<?> var1) {
   }

   public void lIl() {
   }

   public void lI() {
   }

   public lIllII IlIIIII() {
      return this.IllIllI;
   }

   public void Ill() {
   }

   static JsonElement IlIIIIl(JsonObject var0, long var1) {
      if (var0 == null) {
         return null;
      } else {
         String var3 = IIIllII(var1);
         JsonElement var4 = var0.get(var3);
         ArrayList var5 = new ArrayList();

         for(Map.Entry var7 : var0.entrySet()) {
            String var8 = (String)var7.getKey();
            if (!var3.equals(var8) && lIlIII.II(var8) == var1) {
               if (var4 == null) {
                  var4 = (JsonElement)var7.getValue();
               }

               var5.add(var8);
            }
         }

         if (var4 != null) {
            var0.add(var3, var4);
         }

         for(String var10 : var5) {
            var0.remove(var10);
         }

         return var4;
      }
   }

   private static int IlIIIlI(int var0, int var1) {
      return IllIlll[var0 ^ 298429911] ^ var1 ^ var0;
   }

   private static String IlIIIll(int var0, int var1) {
      int var3 = var0 ^ 1197526460;
      char[] var4 = IlllIII[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IlllIIl[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IlllIIl[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -1007186579;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 0;
               break;
            case 1:
               var9 = 241;
               break;
            case 2:
               var9 = 86;
               break;
            case 3:
               var9 = 21;
               break;
            case 4:
               var9 = 123;
               break;
            case 5:
               var9 = 43;
               break;
            case 6:
               var9 = 128;
               break;
            case 7:
               var9 = 54;
               break;
            case 8:
               var9 = 226;
               break;
            case 9:
               var9 = 179;
               break;
            case 10:
               var9 = 64;
               break;
            case 11:
               var9 = 88;
               break;
            case 12:
               var9 = 82;
               break;
            case 13:
               var9 = 20;
               break;
            case 14:
               var9 = 168;
               break;
            case 15:
               var9 = 103;
               break;
            case 16:
               var9 = 52;
               break;
            case 17:
               var9 = 85;
               break;
            case 18:
               var9 = 103;
               break;
            case 19:
               var9 = 168;
               break;
            case 20:
               var9 = 36;
               break;
            case 21:
               var9 = 90;
               break;
            case 22:
               var9 = 97;
               break;
            case 23:
               var9 = 117;
               break;
            case 24:
               var9 = 87;
               break;
            case 25:
               var9 = 65;
               break;
            case 26:
               var9 = 202;
               break;
            case 27:
               var9 = 47;
               break;
            case 28:
               var9 = 66;
               break;
            case 29:
               var9 = 73;
               break;
            case 30:
               var9 = 13;
               break;
            case 31:
               var9 = 236;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
