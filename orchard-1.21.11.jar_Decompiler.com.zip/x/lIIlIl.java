package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2815;
import net.minecraft.class_310;

@Environment(EnvType.CLIENT)
public final class lIIlIl extends IIIIIIIlI {
   private boolean I;
   private static String[] l;
   private static final int[] II;
   private static final String[] Il;
   private static final Object[] lI;

   private static void ll() {
      l[0] = IlI(IIll('橁', 1277649258, (short)24346).toCharArray(), 88785L, IIII(-1966680586, 1488488312));
      l[1] = IlI(IIll('橀', -1176800263, (short)'켛').toCharArray(), 48249L, IIII(-1966680585, -958028991));
   }

   public void lIl() {
      this.I = false;
   }

   private static String IlI(char[] var0, long var1, int var3) {
      int var4 = IIII(-1966680588, -1407423832) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IIII(-1966680587, 208609762);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   public boolean lII(class_2815 var1) {
      class_310 var2 = class_310.method_1551();
      if (var2.field_1724 != null && var1 != null) {
         if (var1.method_36168() != var2.field_1724.field_7498.field_7763) {
            return false;
         } else if (this.I) {
            this.I = false;
            return false;
         } else {
            return this.IIIIIlI();
         }
      } else {
         return false;
      }
   }

   public void llI() {
      this.I = true;
   }

   public boolean lll() {
      return this.IIIIIlI();
   }

   public lIIlIl() {
      super((Object)lIlIII.l(l[0]), lIllII.l, (Object)lIlIII.l(l[1]));
   }

   static {
      short var6 = 13581;
      String var7 = "슂扼忯ᱎ\uf481\uec03៤葕핶모ᷖ鮱\uecee뺔짩諳㝛ꁉԦ↞淇瀉ᙳ꾜䱞\ued5d皜쳬ퟃ㏳ꪹ⍼㥧븶봪ඌ﨧㏊㘔凞諁얙盰㔈\u169d謭ǃꅗ榾祖ꉭว㮯㝳뭝ꡛ⸢觚藑즞အ壎\ue2d2⠡ᅆ䩗㱜뭟퀫㦫ꊩÔ쑢춻틯棜큗\uf774䅲⟗針꽿\ue62aﯓ恇⪉\ue768只幞굝큜\uf76dꕿ븬\udd73ᒰ";
      char[] var8 = "㔅㕕".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            Il = var9;
            lI = new Object[var9.length];
            int var2 = -1474728395;
            byte[] var0 = "7\u001dêÝ\u008c÷ôÎQ\u008b}B.°\u009aÝ".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            II = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               II[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            l = new String[2];
            ll();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public void lI() {
      class_310 var1 = class_310.method_1551();
      if (var1.field_1724 != null && var1.method_1562() != null) {
         this.I = true;
         var1.method_1562().method_52787(new class_2815(var1.field_1724.field_7498.field_7763));
      } else {
         this.I = false;
      }
   }

   private static int IIII(int var0, int var1) {
      return II[var0 ^ -1966680586] ^ var1 ^ var0;
   }

   private static String IIll(char var0, int var1, short var2) {
      int var3 = var0 ^ 27201;
      char[] var4 = Il[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])lI[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         lI[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 6779;
      int var9 = 0;

      do {
         int var10 = var4[var9] + 17804;
         var10 += 34936;
         var10 += 1077;
         var10 ^= 18638;
         var4[var9] = (char)(var10 ^ var8 ^ var2 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
