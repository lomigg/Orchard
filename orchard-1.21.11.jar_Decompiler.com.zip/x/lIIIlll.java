package x;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class lIIIlll extends llllllI<List<String>> {
   private final List<<undefinedtype>> I;
   private List<<undefinedtype>> l;
   private final <undefinedtype> II;
   private static final String[] Il;
   private static final Object[] lII;

   public void ll(List<String> var1) {
      this.IIlI(IlI(var1));
   }

   private static List<<undefinedtype>> IlI(Collection<?> var0) {
      if (var0 != null && !var0.isEmpty()) {
         ArrayList var1 = new ArrayList();

         for(Object var3 : var0) {
            <undefinedtype> var4;
            if (var3 instanceof <undefinedtype>) {
               <undefinedtype> var5 = (<undefinedtype>)var3;
               var4 = var5;
            } else {
               String var6 = Ill(var3 == null ? null : var3.toString());
               var4 = lIlIII.III(var6);
            }

            if (!var4.lIIl()) {
               var1.add(var4);
            }
         }

         return List.copyOf(var1);
      } else {
         return List.of();
      }
   }

   private static String Ill(String var0) {
      return var0 == null ? "" : var0.trim();
   }

   public List<<undefinedtype>> lII() {
      return this.l;
   }

   public void lIl(String var1) {
      if (var1 != null) {
         ArrayList var2 = new ArrayList(this.l);
         if (var2.removeIf((var1x) -> var1x.lllI(var1))) {
            this.IIlI(var2);
         }

      }
   }

   public lIIIlll(String var1, Collection<?> var2, String var3) {
      this((Object)var1, var2, (String)var3);
   }

   public void llI(int var1, String var2) {
      ArrayList var3 = new ArrayList(this.l);
      if (var1 >= 0 && var1 < var3.size()) {
         String var4 = Ill(var2);
         if (var4.isEmpty()) {
            var3.remove(var1);
         } else {
            var3.set(var1, lIlIII.III(var4));
         }

         this.IIlI(var3);
      }
   }

   public void lll(String var1) {
      String var2 = Ill(var1);
      if (!var2.isEmpty()) {
         ArrayList var3 = new ArrayList(this.l);
         var3.add(lIlIII.III(var2));
         this.IIlI(var3);
      }
   }

   public lIIIlll(Object var1, Collection<?> var2, String var3) {
      this((Object)var1, var2, (Object)var3);
   }

   public void IIl() {
      this.IIlI(this.I);
   }

   public List<String> IIII() {
      return IIll(this.I);
   }

   public List<String> IIIl() {
      return IIll(this.l);
   }

   public lIIIlll(Object var1, Collection<?> var2) {
      this((Object)var1, var2, (Object)lIlIII.l(IIIII(903301578, (short)19662, '聴')));
   }

   private void IIlI(List<<undefinedtype>> var1) {
      List var2 = var1 == null ? List.of() : List.copyOf(var1);
      if (!IlII(this.l, var2)) {
         this.l = var2;
         this.llII();
      }

   }

   private static List<String> IIll(List<<undefinedtype>> var0) {
      if (var0 != null && !var0.isEmpty()) {
         ArrayList var1 = new ArrayList(var0.size());

         for(<undefinedtype> var3 : var0) {
            var1.add(var3.lIlI());
         }

         return List.copyOf(var1);
      } else {
         return List.of();
      }
   }

   public lIIIlll(Object var1, Collection<?> var2, Object var3) {
      super((Object)var1, List.of());
      this.I = IlI(var2);
      this.l = this.I;
      <undefinedtype> var10001;
      if (var3 instanceof <undefinedtype> var4) {
         var10001 = var4;
      } else {
         var10001 = lIlIII.III(var3 != null && !var3.toString().isBlank() ? var3.toString() : lIlIII.Il(IIIII(-2056643979, (short)'菗', '聵')));
      }

      this.II = var10001;
   }

   private static boolean IlII(List<<undefinedtype>> var0, List<<undefinedtype>> var1) {
      if (var0 == var1) {
         return true;
      } else if (var0 != null && var1 != null && var0.size() == var1.size()) {
         for(int var2 = 0; var2 < var0.size(); ++var2) {
            if (!((<undefinedtype>)var0.get(var2)).lIII((<undefinedtype>)var1.get(var2))) {
               return false;
            }
         }

         return true;
      } else {
         return false;
      }
   }

   public JsonElement lI() {
      JsonArray var1 = new JsonArray();

      for(<undefinedtype> var3 : this.l) {
         var1.add(new JsonPrimitive(var3.lIlI()));
      }

      return var1;
   }

   public void II(JsonElement var1) {
      if (var1 != null && !var1.isJsonNull()) {
         if (var1.isJsonArray()) {
            ArrayList var2 = new ArrayList();

            for(JsonElement var4 : var1.getAsJsonArray()) {
               if (var4 != null && var4.isJsonPrimitive()) {
                  var2.add(var4.getAsString());
               }
            }

            this.ll(var2);
         } else {
            if (var1.isJsonPrimitive()) {
               this.ll(lIlllllI.llIl(var1.getAsString(), this.II.lIlI()));
            }

         }
      } else {
         this.ll(List.of());
      }
   }

   public void IlIl(String var1, int var2) {
      String var3 = Ill(var1);
      if (!var3.isEmpty()) {
         ArrayList var4 = new ArrayList(this.l);
         var4.add(0, lIlIII.III(var3));
         int var5 = Math.max(0, var2);

         while(var4.size() > var5) {
            var4.remove(var4.size() - 1);
         }

         this.IIlI(var4);
      }
   }

   public lIIIlll(String var1, Collection<?> var2) {
      this((Object)var1, var2, (Object)lIlIII.l(IIIII(-291434486, (short)'맢', '聶')));
   }

   public void IllI(int var1) {
      ArrayList var2 = new ArrayList(this.l);
      if (var1 >= 0 && var1 < var2.size()) {
         var2.remove(var1);
         this.IIlI(var2);
      }
   }

   static {
      short var0 = 11869;
      String var1 = "ꍲꍝꂠꃢၞၱფႦ䌔䌻䊦䋤";
      char[] var2 = "\u0004\u0004\u0004".toCharArray();
      String[] var3 = new String[var2.length];
      byte var7 = -1;

      while(true) {
         int var4 = 0;
         int var5 = 0;
         char var6 = '\u0000';
         if (var7 == 0) {
            Il = var3;
            lII = new Object[var3.length];
            return;
         }

         do {
            var6 = var2[var4];
            char[] var8 = var1.substring(var5, var5 + var6).toCharArray();
            int var9 = 0;

            do {
               byte var10000;
               switch (var9 % 6) {
                  case 0:
                  default:
                     var10000 = 88;
                     break;
                  case 1:
                     var10000 = 119;
                     break;
                  case 2:
                     var10000 = 60;
                     break;
                  case 3:
                     var10000 = 126;
                     break;
                  case 4:
                     var10000 = 122;
                     break;
                  case 5:
                     var10000 = 114;
               }

               byte var10 = var10000;
               var8[var9] = (char)(var8[var9] ^ var10 ^ var0);
               ++var9;
            } while(var9 < var8.length);

            var3[var4] = (new String(var8)).intern();
            var5 += var6;
            ++var4;
         } while(var4 < var2.length);

         var7 = 0;
      }
   }

   private static String IIIII(int var0, short var1, char var2) {
      int var3 = var2 ^ '聴';
      char[] var4 = Il[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])lII[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         lII[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 11390;
      int var9 = 0;

      do {
         int var10 = var4[var9] - '\ueb25';
         var10 ^= 61776;
         var10 += 11177;
         var10 -= 58386;
         var10 -= 1298;
         var10 -= 42201;
         var10 -= 13841;
         var10 -= 18813;
         var10 += 10064;
         var10 ^= 23898;
         var4[var9] = (char)(var10 ^ var8 ^ var1 ^ var0 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
