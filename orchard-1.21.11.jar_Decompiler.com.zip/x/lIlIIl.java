package x;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class lIlIIl implements ModInitializer {
   public static final Logger I;
   private static String[] l;
   public static final String II = "modid";
   private static final int[] Il;
   private static final String[] lI;
   private static final Object[] ll;

   public void onInitialize() {
      I.info(l[1]);
   }

   private static String I(char[] var0, long var1, int var3) {
      int var4 = II(287176580, -1207305166) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & II(287176581, 2078761737);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private static void l() {
      l[0] = I(Il((short)4361, 1679891778, '\ue642').toCharArray(), 13533L, II(287176582, -273486434));
      l[1] = I(Il((short)32343, -523478526, '\ue643').toCharArray(), 65293L, II(287176583, -613331645));
   }

   static {
      short var6 = 1530;
      String var7 = "\uddf5꼨ᦧ䠀흄㥒\udec9\ue1f5\uecde\ud8cc鑐\ue554ۉꄓ쁪䏝ꤓ⋧폃쮫霨裏묊껂";
      char[] var8 = "\u05ffש".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            lI = var9;
            ll = new Object[var9.length];
            int var2 = -1068240074;
            byte[] var0 = ">#\u0086ïª©gEã\u0096\u008b\u00827\u0010ä×".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            Il = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               Il[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            l = new String[2];
            l();
            I = LoggerFactory.getLogger(l[0]);
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static int II(int var0, int var1) {
      return Il[var0 ^ 287176580] ^ var1 ^ var0;
   }

   private static String Il(short var0, int var1, char var2) {
      int var3 = var2 ^ '\ue642';
      char[] var4 = lI[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])ll[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         ll[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 21677;
      int var9 = 0;

      do {
         int var10 = var4[var9] + '쐳';
         var10 -= 5618;
         var10 ^= 63520;
         var10 ^= 37412;
         var10 += 33591;
         var10 += 20396;
         var10 ^= 53871;
         var10 -= 11434;
         var10 -= 55435;
         var10 += 4732;
         var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
