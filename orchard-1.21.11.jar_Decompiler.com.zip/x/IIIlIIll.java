package x;

import java.awt.Color;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1109;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1676;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3414;

@Environment(EnvType.CLIENT)
public final class IIIlIIll extends IIIIIIIlI {
   private final lIIIIl I = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIII(-1623589584, 655830042)), true));
   private static final long l = 2500L;
   private final Map<Integer, <undefinedtype>> II = new HashMap();
   private final IIIllIIII Il = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IIII(-1623589582, 1352743707)), (double)220.0F, (double)60.0F, (double)1000.0F, (double)10.0F)).IIIl(lIlIII.l(IIII(-1623589581, -1832224334))));
   private long lI;
   private static final <undefinedtype> ll;
   private static final <undefinedtype> III;
   private final lIIIIl IIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIII(-1623589583, 140139462)), true));
   private static final double IlI = (double)16.0F;
   private static final int[] Ill;
   private static final String[] lII;
   private static final Object[] lIl;

   private void ll() {
      this.lI = System.currentTimeMillis();
      if ((Boolean)this.I.III()) {
         class_310 var1 = class_310.method_1551();
         if (var1 != null && var1.method_1483() != null) {
            var1.method_1483().method_4873(class_1109.method_4757(lII(), 1.0F, 1.0F));
         }

      }
   }

   private void IlI(class_310 var1) {
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null) {
         long var2 = System.currentTimeMillis();
         Iterator var4 = this.II.entrySet().iterator();

         while(var4.hasNext()) {
            if (var2 - ((<undefinedtype>)((Map.Entry)var4.next()).getValue()).I() > 2500L) {
               var4.remove();
            }
         }

         for(class_1297 var6 : var1.field_1687.method_18112()) {
            if (var6 instanceof class_1676) {
               class_1676 var7 = (class_1676)var6;
               if (var7.method_24921() == var1.field_1724) {
                  this.II.put(var6.method_5628(), new Record(new class_243(var6.method_23317(), var6.method_23318(), var6.method_23321()), var2) {
                     private final class_243 I;
                     private final long l;

                     private {
                        this.I = var1;
                        this.l = var2;
                     }

                     public long I() {
                        return this.l;
                     }

                     public class_243 l() {
                        return this.I;
                     }
                  });
               }
            }
         }

      } else {
         this.II.clear();
      }
   }

   public void IIIlI(class_332 var1, int var2, int var3, float var4) {
      if ((Boolean)this.IIl.III() && this.lI > 0L) {
         long var5 = System.currentTimeMillis();
         long var7 = Math.max(1L, Math.round((Double)this.Il.III()));
         long var9 = var5 - this.lI;
         if (var9 <= var7) {
            class_310 var11 = class_310.method_1551();
            if (var11 != null && var11.method_22683() != null) {
               double var12 = (double)var9 / (double)var7;
               int var14 = (int)Math.round(((double)1.0F - var12) * (double)255.0F);
               lIllIIl var15 = lIllIIl.Il();
               Color var16 = var15 != null && var15.IIl() != null && var15.IIl().IIII() != null ? var15.IIl().IIII().lllI() : Color.WHITE;
               int var17 = IIlIIllIl.I(var16, var14).getRGB();
               double var18 = (double)var11.method_22683().method_4486() * (double)0.5F;
               double var20 = (double)var11.method_22683().method_4502() * (double)0.5F;
               double var22 = (double)3.5F + var12 * (double)1.0F;
               double var24 = (double)5.0F;
               IIIIIIllI.IlIlI(var1, var18 - var22 - var24, var20 - var22 - var24, var18 - var22, var20 - var22, 0.9, var17);
               IIIIIIllI.IlIlI(var1, var18 + var22, var20 - var22, var18 + var22 + var24, var20 - var22 - var24, 0.9, var17);
               IIIIIIllI.IlIlI(var1, var18 - var22 - var24, var20 + var22 + var24, var18 - var22, var20 + var22, 0.9, var17);
               IIIIIIllI.IlIlI(var1, var18 + var22, var20 + var22, var18 + var22 + var24, var20 + var22 + var24, 0.9, var17);
            }
         }
      }
   }

   static {
      short var6 = 11414;
      String var7 = "ওधॖঢख़ঝ॒\u09ca\uf4d6\uf41c\uf43b\uf4c6\uf40a\uf4c1\uf41c\uf4f0ẎṛḲạṃẻḄẲṂṤẴẠ孷宠宐孍宣孃寸字宻宱孛孻嬧寭寄寁孱孃寪寬孻宓學嬨安宂寊孩嬖宀宋學孪宍宙孹完孃寡孍寝寓孏孑字寲寨寷孳孶寸对子宒孃嬜寨宆寞学嬪寮宼孉孬害审孎宥孥寣孖宿宐嬉孻嬥寮寪寘孡嬉寮寣孿寗嬸嬺宝寽家孾嬙寧宲孒嬴宻寅嬦䯧䭏䬜䯉䬰䯪䬷䮢撩摇搔撎摿撝搢撰㱖㲅㲘㱺㲃㱥㲀㱌㲐㲹㱍㰆︧\ufefeﻖ﹫";
      char[] var8 = "ⲞⲞⲚⳲⲞⲞⲚⲒ".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            lII = var9;
            lIl = new Object[var9.length];
            int var2 = 1378284099;
            byte[] var0 = "\u000bJ)\u001d9Ð\u007f\u0093vüõÁ".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            Ill = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               Ill[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            ll = lIlIII.l(IIII(-1623589580, -2059961577));
            III = lIlIII.l(IIII(-1623589579, 2020870022));
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public void lIlI(class_1297 var1) {
      if (var1 instanceof class_1309 var2) {
         if (!var2.method_31481()) {
            this.ll();
            return;
         }
      }

   }

   public void Ill() {
      this.IlI(class_310.method_1551());
   }

   public IIIlIIll() {
      super((Object)lIlIII.l(IIII(-1623589578, 1920736952)), lIllII.ll, (Object)lIlIII.l(IIII(-1623589577, 931615443)));
   }

   private static class_3414 lII() {
      return class_3414.method_47908(class_2960.method_60655(ll.lIlI(), III.lIlI()));
   }

   public void II(class_1297 var1, byte var2) {
      if (var1 instanceof class_1309 var3) {
         if (!var3.method_31481() && this.llI(var2)) {
            class_310 var4 = class_310.method_1551();
            if (var4 != null && var4.field_1724 != null && var1 != var4.field_1724) {
               long var5 = System.currentTimeMillis();
               class_243 var7 = new class_243(var1.method_23317(), var1.method_23318(), var1.method_23321());

               for(<undefinedtype> var9 : this.II.values()) {
                  if (var5 - var9.I() <= 2500L && var9.l().method_1025(var7) <= (double)16.0F) {
                     this.ll();
                     return;
                  }
               }

               return;
            }

            return;
         }
      }

   }

   public void lI() {
      this.lI = 0L;
      this.II.clear();
   }

   private boolean llI(byte var1) {
      return var1 == 2 || var1 == lll(-1274430026, -312121655) || var1 == lll(-1274430025, -536924093) || var1 == lll(-1274430028, -1865172461);
   }

   private static int lll(int var0, int var1) {
      return Ill[var0 ^ -1274430026] ^ var1 ^ var0;
   }

   private static String IIII(int var0, int var1) {
      int var3 = var0 ^ -1623589580;
      char[] var4 = lII[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])lIl[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         lIl[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -689938823;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 157;
               break;
            case 1:
               var9 = 113;
               break;
            case 2:
               var9 = 99;
               break;
            case 3:
               var9 = 128;
               break;
            case 4:
               var9 = 80;
               break;
            case 5:
               var9 = 137;
               break;
            case 6:
               var9 = 12;
               break;
            case 7:
               var9 = 148;
               break;
            case 8:
               var9 = 117;
               break;
            case 9:
               var9 = 124;
               break;
            case 10:
               var9 = 185;
               break;
            case 11:
               var9 = 134;
               break;
            case 12:
               var9 = 253;
               break;
            case 13:
               var9 = 47;
               break;
            case 14:
               var9 = 43;
               break;
            case 15:
               var9 = 15;
               break;
            case 16:
               var9 = 174;
               break;
            case 17:
               var9 = 171;
               break;
            case 18:
               var9 = 57;
               break;
            case 19:
               var9 = 33;
               break;
            case 20:
               var9 = 141;
               break;
            case 21:
               var9 = 60;
               break;
            case 22:
               var9 = 145;
               break;
            case 23:
               var9 = 230;
               break;
            case 24:
               var9 = 64;
               break;
            case 25:
               var9 = 44;
               break;
            case 26:
               var9 = 28;
               break;
            case 27:
               var9 = 191;
               break;
            case 28:
               var9 = 218;
               break;
            case 29:
               var9 = 77;
               break;
            case 30:
               var9 = 66;
               break;
            case 31:
               var9 = 128;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
