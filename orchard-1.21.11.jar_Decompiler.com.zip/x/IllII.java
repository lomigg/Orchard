package x;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2596;
import net.minecraft.class_2923;
import net.minecraft.class_2935;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_640;

@Environment(EnvType.CLIENT)
public final class IllII {
   private static final IllII I;
   private static final long l = 150L;
   private boolean II;
   private int Il;
   private long lI;
   private final Map<Long, <undefinedtype>> ll;
   private volatile boolean III;
   private static final long IIl = 2L;
   private volatile <undefinedtype> IlI;
   private volatile boolean Ill;
   private static final long lII = 1000L;
   private volatile boolean lIl;
   private double llI;
   private static final int lll = 5;
   private static final int IIII = 2;
   private volatile boolean IIIl;
   private volatile boolean IIlI;
   private static final double IIll = 0.07;
   private <undefinedtype> IlII;
   private long IlIl;
   private static final long IllI = 30000L;
   private int Illl;
   private final int[] lIII;
   private double lIIl;
   private volatile boolean lIlI;
   private volatile int lIll;
   private long llII;
   private static final double llIl = (double)25.0F;
   private static final int lllI = 32;
   private static final long llll = 1500L;
   private long IIIII;
   private int IIIIl;
   private static final int[] IIIlI;
   private static final String[] IIIll;
   private static final Object[] IIlII;

   public synchronized void I() {
      this.Illl(true);
   }

   private void l(class_634 var1, boolean var2) {
      long var3 = System.currentTimeMillis();
      this.IlIII(var3);
      if (!var2) {
         if (this.IIIl(var3)) {
            return;
         }

         if (this.II && var3 - this.IlIl < 1000L) {
            return;
         }
      }

      var1.method_52787(new class_2935(var3));
   }

   public void II(long var1, long var3) {
      <undefinedtype> var5 = (<undefinedtype>)this.ll.get(var1);
      if (var5 != null) {
         var5.Il = var3;
      }

   }

   public boolean Il() {
      return this.IIIl;
   }

   public boolean lI() {
      return this.III;
   }

   public int ll() {
      return this.IIllI();
   }

   public long III() {
      return this.lI / 2L;
   }

   public void IIl(class_310 var1) {
      if (!this.IIlI) {
         this.lI = 0L;
      } else if (this.IlI == null.II) {
         this.llI = (double)this.lIll;
         this.lI = lIII(this.llI);
      } else {
         if (var1 == null) {
            var1 = class_310.method_1551();
         }

         if (var1 != null && var1.field_1724 != null) {
            class_634 var2 = var1.method_1562();
            if (var2 != null) {
               long var3 = System.currentTimeMillis();
               this.l(var2, false);
               if (!this.IIIl(var3)) {
                  if (this.Illl > 0) {
                     return;
                  }

                  int var5 = this.IIIII(var1);
                  if (var5 <= 0) {
                     return;
                  }

                  this.IllII(var5);
               }

               int var8 = this.IIllI();
               long var6 = (long)Math.max(0, this.lIll - var8);
               this.Ill(var6);
               this.IIIIl(var3, lIII(this.llI));
            }
         }
      }
   }

   public void IlI(boolean var1) {
      this.III = var1;
   }

   private void Ill(long var1) {
      double var3 = (double)var1 - this.llI;
      double var5 = Math.abs(var3);
      if (var5 < 0.01) {
         this.llI = (double)var1;
      } else {
         boolean var7 = var3 < (double)0.0F;
         double var8 = var7 ? (double)0.25F : (double)0.5F;
         double var10 = var7 ? (double)16.0F : (double)60.0F;
         double var12 = Math.min(var5 / (double)20.0F, (double)1.0F);
         double var14 = var7 ? 0.15 + 0.45 * var12 : 0.3 + 0.7 * var12;
         double var16 = var5 * var14;
         var16 = Math.min(var5, Math.max(var8, Math.min(var16, var10)));
         this.llI += Math.copySign(var16, var3);
         if (Math.abs((double)var1 - this.llI) < (double)0.5F) {
            this.llI = (double)var1;
         }

      }
   }

   public static boolean lII(String var0) {
      if (var0 == null) {
         return false;
      } else {
         return var0.endsWith(lIlIII.Il(IlllI('ﴲ', -434025640, 'ⴁ'))) || var0.endsWith(lIlIII.Il(IlllI('ﴳ', -141948019, '\uf68f'))) || var0.endsWith(lIlIII.Il(IlllI('ﴰ', 1117262731, 'ṯ'))) || var0.endsWith(lIlIII.Il(IlllI('ﴱ', 1183460607, '楼'))) || var0.endsWith(lIlIII.Il(IlllI('ﴶ', 1760321930, '髏')));
      }
   }

   public int lIl() {
      return (int)this.lI;
   }

   public synchronized <undefinedtype> llI() {
      <undefinedtype> var1 = this.IlII;
      this.IlII = null.l;
      this.lIlI = false;
      return var1;
   }

   public boolean lll() {
      return this.lIl;
   }

   public void IIII(class_2923 var1) {
      if (var1 != null) {
         <undefinedtype> var2 = (<undefinedtype>)this.ll.remove(var1.comp_2201());
         if (var2 != null) {
            long var3 = System.currentTimeMillis();
            long var5 = var2.I > 0L ? var2.I : var3;
            long var7 = Math.max(0L, var5 - var1.comp_2201());
            long var9 = var2.l + var2.Il;
            long var11 = var9 > 0L ? var9 : var2.lI;
            long var13 = Math.max(0L, var7 - var11);
            int var15 = this.IIlIl((int)var13);
            if (var15 <= 0) {
               this.II = false;
            } else {
               this.Illl = var15;
               double var16 = (double)var15;
               if (this.lIIl > (double)0.0F) {
                  double var18 = this.lIIl - (double)25.0F;
                  double var20 = this.lIIl + (double)25.0F;
                  var16 = Math.max(var18, Math.min(var20, var16));
               }

               this.lIIl = this.lIIl == (double)0.0F ? var16 : this.lIIl * 0.9299999999999999 + var16 * 0.07;
               this.IIIII = var3;
               this.II = false;
            }
         }
      }
   }

   private boolean IIIl(long var1) {
      return this.Illl > 0 && var1 - this.IIIII <= 1500L;
   }

   public synchronized void IIlI(boolean var1, Object var2, int var3) {
      boolean var4 = this.IIlI;
      <undefinedtype> var5 = var2 == null ? null.I : var2;
      int var6 = Math.max(0, var3);
      boolean var7 = this.lIll != var6 || this.IlI != var5;
      this.IIlI = var1;
      this.IlI = var5;
      this.lIll = var6;
      if (!var1) {
         this.lI = 0L;
         this.llI = (double)0.0F;
      } else {
         if (!var4 || var7) {
            this.llII();
         }

         if (this.IlI == null.II) {
            this.llI = (double)this.lIll;
            this.lI = lIII(this.llI);
            this.llII = System.currentTimeMillis();
         } else {
            if (!var4 || var7) {
               class_310 var8 = class_310.method_1551();
               int var9 = this.IIIII(var8);
               if (var9 > 0) {
                  this.IllII(var9);
                  double var10 = (double)Math.max(0, this.lIll - var9);
                  this.llI = var10;
                  this.lI = lIII(this.llI);
                  this.llII = System.currentTimeMillis();
               }
            }

         }
      }
   }

   public void IIll(long var1, long var3) {
      <undefinedtype> var5 = (<undefinedtype>)this.ll.get(var1);
      if (var5 != null) {
         var5.l = var3;
      }

   }

   public synchronized void IlII() {
      this.IlII = this.IlII.I(this.IIIl, this.lIl);
      this.lIlI = !this.IlII.l();
   }

   public static boolean IlIl(String var0) {
      if (var0 == null) {
         return false;
      } else {
         return var0.endsWith(lIlIII.Il(IlllI('ﴷ', 1565729712, 'ᧄ'))) || var0.endsWith(lIlIII.Il(IlllI('ﴴ', -503353336, '큶'))) || var0.endsWith(lIlIII.Il(IlllI('ﴵ', 1490360132, '\uf681'))) || var0.endsWith(lIlIII.Il(IlllI('ﴺ', 670700929, '᥅'))) || var0.endsWith(lIlIII.Il(IlllI('ﴻ', 1096224357, '狊'))) || var0.endsWith(lIlIII.Il(IlllI('ﴸ', 1584662242, '上'))) || var0.endsWith(lIlIII.Il(IlllI('ﴹ', -2068619924, '怬'))) || var0.endsWith(lIlIII.Il(IlllI('﴾', 41045701, '륷')));
      }
   }

   static boolean IllI(class_2596<?> var0) {
      return var0 != null && IlIl(var0.getClass().getName());
   }

   public synchronized void Illl(boolean var1) {
      if (var1) {
         this.IlII = this.IlII.I(this.IIIl, this.lIl);
      }

      this.Ill = false;
      this.IIIl = true;
      this.lIl = true;
      this.III = false;
      this.IIlI = false;
      this.lIll = 0;
      this.lI = 0L;
      this.llI = (double)0.0F;
      this.llII();
      this.lIlI = !this.IlII.l();
   }

   private static long lIII(double var0) {
      if (var0 <= (double)0.0F) {
         return 0L;
      } else {
         long var2 = Math.round(var0);
         long var4 = 1L;
         long var6 = (var2 + var4) / 2L * 2L;
         return Math.max(0L, var6);
      }
   }

   private IllII() {
      this.IlI = null.I;
      this.IlII = null.l;
      this.IIIl = true;
      this.lIl = true;
      this.lIII = new int[5];
      this.ll = new ConcurrentHashMap();
   }

   public int lIIl() {
      return this.lIll;
   }

   public synchronized void lIlI(boolean var1, boolean var2) {
      this.IIIl = var1;
      this.lIl = var2;
   }

   public void lIll(long var1) {
      if (this.IIlI) {
         long var3 = System.currentTimeMillis();
         this.IlIII(var3);
         Object var5 = new Object() {
            private long I = -1L;
            private long l;
            private long II = -1L;
            private long Il;
            private long lI;
         };
         ((<undefinedtype>)var5).lI = this.lI;
         ((<undefinedtype>)var5).l = this.III();
         ((<undefinedtype>)var5).Il = this.IIIll();
         this.ll.put(var1, var5);
         this.IlIl = var3;
         this.II = true;
      }
   }

   private void llII() {
      this.ll.clear();
      this.II = false;
      this.IlIl = 0L;
      this.Illl = 0;
      this.lIIl = (double)0.0F;
      this.IIIII = 0L;
      this.IIIIl = 0;
      this.Il = 0;
   }

   public boolean lllI() {
      return this.lIlI;
   }

   public void llll(long var1) {
      <undefinedtype> var3 = (<undefinedtype>)this.ll.get(var1);
      if (var3 != null) {
         var3.II = System.currentTimeMillis();
      }

   }

   private int IIIII(class_310 var1) {
      int var2 = this.IIllI();
      if (var1 != null && var1.field_1724 != null && var1.method_1562() != null) {
         class_640 var3 = var1.method_1562().method_2871(var1.field_1724.method_5667());
         if (var3 != null && var3.method_2959() > 0) {
            var2 = Math.max(var2, var3.method_2959());
         }

         return var2;
      } else {
         return var2;
      }
   }

   static {
      short var6 = 31797;
      String var7 = "䗴䕙䗐䖾䖪䖮䘏䖝䗣䖂䕏䕗䗤䖔䗼䖿䖑䕊䖶䙴䗑䖺䖵䙲䗑䖷䖼䗞䖤䗃䔠䙽䗒䖏䗌䕌翖羢羜羳罋羟砊硲砇罓罊羀翘羥翖羷義羶翰羞缱硡羴羅翳羻羠翄\uda46\uda50\uda49\uda4d\uda3b\uda17\uda36\uda60\uda28\uda4e\udafe\uda5e\uda10\udaf1\uda1b\uda11\uda66\uda31\uda16\uda53\uda0f\uda58\uda30\uda34\uda78\uda50\uda4d\uda5e\uda0f\uda63\uda29\uda55褂襓襂襌褸褔褝襯襵褦褻襡褔襓覉襇襧襁褐襖襈襙褿襐褧觾褿襛褗褳襞褦䳰䳍䳟䲇䲨䲥䰸䲩䳜䲿䱊䲨䳓䲌䴁䲝䱗䲅䰢䲨䳒䳙䲆䲺쉂숼쉖숎싸술슋숍쉩쇋숵쇕쉮쉣숏숢쇖쉯쉯숏슀쇖숰숧辊輲辂輼迱輘轗輯轙軔輝輠躽輳辇輎輐軗轑輣轌輼軕輘轮軆輽轙ࣅ࣐ऊࣞࣄ࣪ࣆ࢛ࢪࢬࣄࣇࢪ࣓ࣈࣅࣛࣘ\u08e2࣌ࣃ\u0893ࣚ\u0897ࢥ࣭࣎ࢪ뾡렄롎룮렡련록렢롗뿕롧렩뢏렄뾴뿓렶렦뢏뿄롖렗뿉렦로렸롡롏赚贪責跠贃贂赫跳貰賐贝賏赬赹越赴贞赵赙质赗赵赮财費赦贒跥賋贁赗贬赎贺贇跹貼跴貮賗贷跻赆贾滿湇滯滵滦溻溚滥溔溊溠滶滌湇滷源滵滙滌溇溙湔溊滙溟滻溞溌托戭扼懊戆懍扛懘憲懖戧懈扖扻戗扪懎扷扗拷扸戎扨戟ᗲᕃᗒᖼᖨᖧᗵᖒᗜᖸᕍᖮᔡᖤᖽᖿᕗᖀᗃᖪᗕᖞᖑᕕᗙᖺᗅᕊᙼᖓᔢᙱᗎᕉᕉᖵᗙᖪᗁᖥ";
      char[] var8 = "$\u001c  \u0018\u0018\u001c\u001c\u001c,\u001c\u0018(".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            IIIll = var9;
            IIlII = new Object[var9.length];
            int var2 = 1765544989;
            byte[] var0 = "4C\u0094ø\u0002êÀÑ".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IIIlI = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IIIlI[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            I = new IllII();
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 57;
                     break;
                  case 1:
                     var10000 = 65;
                     break;
                  case 2:
                     var10000 = 54;
                     break;
                  case 3:
                     var10000 = 82;
                     break;
                  case 4:
                     var10000 = 76;
                     break;
                  case 5:
                     var10000 = 78;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private void IIIIl(long var1, long var3) {
      long var5 = Math.abs(var3 - this.lI);
      if (var5 != 0L) {
         boolean var7 = var5 >= 6L;
         boolean var8 = var5 >= 2L;
         boolean var9 = var1 - this.llII >= 150L;
         if (var7 || var8 && var9) {
            this.lI = var3;
            this.llII = var1;
         }

      }
   }

   public synchronized void IIIlI(boolean var1) {
      this.Ill = var1;
   }

   public long IIIll() {
      return this.lI - this.III();
   }

   public void IIlII(long var1) {
      <undefinedtype> var3 = (<undefinedtype>)this.ll.get(var1);
      if (var3 != null) {
         var3.I = System.currentTimeMillis();
      }

   }

   private int IIlIl(int var1) {
      if (var1 <= 0) {
         return -1;
      } else {
         this.lIII[this.Il] = var1;
         this.Il = (this.Il + 1) % 5;
         if (this.IIIIl < 5) {
            ++this.IIIIl;
         }

         int[] var2 = Arrays.copyOf(this.lIII, this.IIIIl);
         Arrays.sort(var2);
         return var2[this.IIIIl / 2];
      }
   }

   private int IIllI() {
      double var1 = this.lIIl > (double)0.0F ? this.lIIl : (double)this.Illl;
      return (int)Math.round(var1);
   }

   public boolean IIlll() {
      return this.IIlI;
   }

   private void IlIII(long var1) {
      this.ll.entrySet().removeIf((var2) -> var1 - (Long)var2.getKey() > 30000L);
      if (this.ll.size() > IllIl(1709877339, 949299358)) {
         List var10000 = this.ll.keySet().stream().sorted().limit((long)(this.ll.size() - IllIl(1709877338, 238845110))).toList();
         Map var10001 = this.ll;
         Objects.requireNonNull(var10001);
         var10000.forEach(var10001::remove);
      }
   }

   public synchronized boolean IlIIl() {
      return !this.llI().l();
   }

   public boolean IlIlI() {
      return this.Ill;
   }

   public static IllII IlIll() {
      return I;
   }

   private void IllII(int var1) {
      if (var1 > 0) {
         long var2 = System.currentTimeMillis();
         this.Illl = Math.max(this.Illl, var1);
         if (this.lIIl <= (double)0.0F) {
            this.lIIl = (double)var1;
         } else {
            this.lIIl = Math.max(this.lIIl, (double)var1);
         }

         this.IIIII = var2;
      }
   }

   private static int IllIl(int var0, int var1) {
      return IIIlI[var0 ^ 1709877339] ^ var1 ^ var0;
   }

   private static String IlllI(char var0, int var1, char var2) {
      int var3 = var0 ^ 'ﴲ';
      char[] var4 = IIIll[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])IIlII[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         IIlII[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 8840;
      int var9 = 0;

      do {
         int var10 = var4[var9] + 2164;
         var10 ^= 50928;
         var10 ^= 43346;
         var10 += 46903;
         var10 -= 55357;
         var10 -= 44674;
         var10 += 30997;
         var10 += 29416;
         var10 ^= 54562;
         var10 ^= 26651;
         var4[var9] = (char)(var10 ^ var8 ^ var2 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
