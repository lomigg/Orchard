package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_310;

@Environment(EnvType.CLIENT)
public final class llllIll extends IIIIIIIlI {
   private double I;
   private boolean l;
   private long II;
   private final IlIIIlIlI<<undefinedtype>> Il;
   private volatile boolean lI;
   private volatile long ll;
   private final IIIllIIII III;
   private volatile int IIl;
   private static String[] IlI;
   private volatile int Ill;
   private static final double lII = 0.35;
   private static final double lIl = (double)4.0F;
   private final lIlllII llI;
   private double lll;
   private volatile long IIII;
   private volatile int IIIl;
   private static final int[] IIlI;
   private static final String[] IIll;
   private static final Object[] IlII;

   private int ll(double var1) {
      return (int)Math.round(Math.max((double)0.0F, Math.min((double)1000.0F, var1)));
   }

   public void lI() {
      this.IIIII();
      IIIIIlIll.IIlllI();
   }

   private String IlI(double var1) {
      int var10000 = (int)Math.round(var1);
      String var4 = lIlIII.Il(IlI[1]);
      int var3 = var10000;
      return var3 + var4;
   }

   private void lII(int var1) {
      if (var1 > 0) {
         double var2 = Math.max((double)0.0F, (double)((long)var1 - this.II));
         if (!this.l) {
            this.lll = var2;
            this.l = true;
         } else {
            this.lll += (var2 - this.lll) * 0.35;
         }
      }
   }

   private static String llI(char[] var0, long var1, int var3) {
      int var4 = IIlII(482592670, 1188102121) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IIlII(482592671, 572622877);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   static {
      short var6 = 5850;
      String var7 = "鏄Ҥ躙앆麱浘囋\uf006嬿껯蒕瓮ӽ佇\uf286䖬핧ⳛ䟪㘢↉訋\udee4⋣畼\uea15쮇䢯礥䂗忽뱞ꐜ萱飉ᬮ鼿弝腽𥳐㚾\ue879ઓ㲊Ὗﲣ桃\ue635䣈鸻茆ᇂ粔⒲䥢㚒⯐孂\ueae7ꓩ㶼箪⚀쨦\uf8e2녡ཌ鎎毱\uf805闷⣐曆楏뇹鎩尤ꎝ혭溒菧ဟ⯤㸓盟䥡ㆭ\uf0fe䁨츕࡛\ue166菩槧뜐눴嶫\uefe5睅퀍钣鍬鏱愲蚝ԃ焛獢큻圫䣡ুﲤ쯎ࠩ琳ᐂ䂪杗博퐹瀥贎\uede4";
      char[] var8 = "ᛖᛞᚊᛖᛒᛒ".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IIll = var9;
            IlII = new Object[var9.length];
            int var2 = -287254283;
            byte[] var0 = "ï,Å\u0099Ð\u0002\u0097\u0088¹J\u009c¨·Húå\u001aï\ríò (,W§$%\u000f\u001a\u0002eÇ\u0087\u0094Ù".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IIlI = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IIlI[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            IlI = new String[IIlII(482592668, 1265206215)];
            lll();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static void lll() {
      IlI[0] = llI(IIlIl(760151974, -1366525203).toCharArray(), 77643L, IIlII(482592669, 480614650));
      IlI[1] = llI(IIlIl(760151975, 393108432).toCharArray(), 47542L, IIlII(482592666, -190338660));
      IlI[2] = llI(IIlIl(760151972, -1673041018).toCharArray(), 34926L, IIlII(482592667, -1005555171));
      IlI[3] = llI(IIlIl(760151973, 261818922).toCharArray(), 51758L, IIlII(482592664, -1203413921));
      IlI[4] = llI(IIlIl(760151970, 53425530).toCharArray(), 51585L, IIlII(482592665, -409313261));
      IlI[5] = llI(IIlIl(760151971, -1598526003).toCharArray(), 24169L, IIlII(482592662, 1722504621));
   }

   public long IIII() {
      return this.lI ? this.IIII : 0L;
   }

   public String Il() {
      String var10000;
      switch (((<undefinedtype>)this.Il.III()).ordinal()) {
         case 0 -> var10000 = this.IlI((Double)this.III.III());
         case 1 -> var10000 = lIlIII.Il(IlI[0]);
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   public int IIll() {
      return this.Ill;
   }

   private double IlII(int var1, int var2) {
      double var10000;
      switch (((<undefinedtype>)this.Il.III()).ordinal()) {
         case 0 -> var10000 = (double)this.ll((Double)this.III.III());
         case 1 -> var10000 = var2 > 0 ? (double)var2 : (double)Math.max(var1, this.lIII(var1));
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   public boolean IlIl() {
      return this.lI;
   }

   private void Illl() {
      boolean var1 = this.lI || this.ll != 0L || this.IIII != 0L;
      this.IIIII();
      if (var1) {
         IIIIIlIll.IIlllI();
      }

   }

   private int lIII(int var1) {
      return this.l ? this.ll(this.lll) : Math.max(0, var1);
   }

   private int llII(int var1) {
      int var2 = this.ll(this.I);
      return Math.max(var1, var2);
   }

   public void lIlI(class_1297 var1) {
      if (this.Il.III() == null.Il && var1 instanceof class_1309) {
         class_310 var2 = class_310.method_1551();
         if (var2.field_1724 != null && var2.method_1562() != null) {
            int var3 = Math.max(0, this.llI.lIII(var2));
            if (var3 > 0) {
               this.I = (double)var3;
            }

         }
      }
   }

   public int lllI() {
      return this.IIl;
   }

   private void IIIII() {
      this.IIl = 0;
      this.IIIl = 0;
      this.Ill = 0;
      this.ll = 0L;
      this.IIII = 0L;
      this.lI = false;
      this.I = (double)0.0F;
      this.lll = (double)0.0F;
      this.l = false;
      this.II = 0L;
   }

   public long IIIIl() {
      return this.lI ? this.ll : 0L;
   }

   public int IIIll() {
      return this.IIIl;
   }

   public llllIll(lIlllII var1) {
      super((Object)lIlIII.l(IlI[3]), lIllII.l, (Object)lIlIII.l(IlI[2]));
      this.Il = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IlI[5]), <undefinedtype>.class, null.II));
      this.III = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IlI[4]), (double)150.0F, (double)0.0F, (double)1000.0F, (double)5.0F)).IIl(lIlIII.Il(IlI[1])));
      this.llI = var1;
      this.III.lIII(() -> this.Il.III() == null.II);
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (var1.field_1724 != null && var1.field_1687 != null && var1.method_1562() != null) {
         if (!this.llI.IlII(var1, (double)4.0F)) {
            this.Illl();
         } else {
            int var2 = Math.max(0, this.llI.III(var1));
            int var3 = Math.max(0, this.llI.lIII(var1));
            this.lII(var2);
            this.I = this.IlII(var2, var3);
            int var4 = this.lIII(var2);
            int var5 = this.llII(var4);
            long var6 = Math.max(0L, (long)(var5 - var4));
            long var8 = 0L;
            boolean var12 = var6 > 0L;
            boolean var13 = this.ll != var8 || this.IIII != var6 || this.lI != var12;
            this.IIl = var2;
            this.IIIl = var3;
            this.Ill = var5;
            this.ll = var8;
            this.IIII = var6;
            this.lI = var12;
            this.II = var6;
            if (var13) {
               IIIIIlIll.IIlllI();
            }

         }
      } else {
         this.Illl();
      }
   }

   private static int IIlII(int var0, int var1) {
      return IIlI[var0 ^ 482592670] ^ var1 ^ var0;
   }

   private static String IIlIl(int var0, int var1) {
      int var3 = var0 ^ 760151974;
      char[] var4 = IIll[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IlII[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IlII[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 738615180;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 12;
               break;
            case 1:
               var9 = 74;
               break;
            case 2:
               var9 = 146;
               break;
            case 3:
               var9 = 91;
               break;
            case 4:
               var9 = 55;
               break;
            case 5:
               var9 = 22;
               break;
            case 6:
               var9 = 171;
               break;
            case 7:
               var9 = 153;
               break;
            case 8:
               var9 = 0;
               break;
            case 9:
               var9 = 218;
               break;
            case 10:
               var9 = 34;
               break;
            case 11:
               var9 = 131;
               break;
            case 12:
               var9 = 176;
               break;
            case 13:
               var9 = 83;
               break;
            case 14:
               var9 = 203;
               break;
            case 15:
               var9 = 150;
               break;
            case 16:
               var9 = 29;
               break;
            case 17:
               var9 = 216;
               break;
            case 18:
               var9 = 14;
               break;
            case 19:
               var9 = 168;
               break;
            case 20:
               var9 = 217;
               break;
            case 21:
               var9 = 232;
               break;
            case 22:
               var9 = 190;
               break;
            case 23:
               var9 = 112;
               break;
            case 24:
               var9 = 195;
               break;
            case 25:
               var9 = 76;
               break;
            case 26:
               var9 = 112;
               break;
            case 27:
               var9 = 36;
               break;
            case 28:
               var9 = 102;
               break;
            case 29:
               var9 = 70;
               break;
            case 30:
               var9 = 12;
               break;
            case 31:
               var9 = 27;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
