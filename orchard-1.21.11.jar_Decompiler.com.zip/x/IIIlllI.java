package x;

import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_6880;
import net.minecraft.class_746;
import net.minecraft.class_9304;
import net.minecraft.class_9334;
import y.lIIllll;

@Environment(EnvType.CLIENT)
public final class IIIlllI extends IIIIIIIlI {
   private final llllIlIl I;
   private boolean l;
   private final IIIllIIII II;
   private long Il;
   private int lI;
   private static String[] ll;
   private final llllIlIl III;
   private long IIl;
   private Runnable IlI;
   private class_746 Ill;
   private static final int lII = 9;
   private static final int lIl = 1;
   private int llI;
   private boolean lll;
   private <undefinedtype> IIII;
   private long IIIl;
   private final lIIIIl IIlI;
   private final IIIllIIII IIll;
   private int IlII;
   private Runnable IlIl;
   private boolean IllI;
   private int Illl;
   private static final int[] lIII;
   private static final String[] lIIl;
   private static final Object[] lIlI;

   public IIIlllI() {
      super((Object)lIlIII.l(ll[IllII(2134073754, 1592989608)]), lIllII.l, (Object)lIlIII.l(ll[IllII(2134073755, 1102121757)]));
      this.IIlI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(ll[IllII(2134073752, 597623749)]), false));
      this.III = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(ll[IllII(2134073753, -730530474)]), (double)1.0F, (double)4.0F, (double)1.0F, (double)4.0F, (double)1.0F)).IIII(lIlIII.Il(ll[2])));
      this.IIll = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(ll[IllII(2134073758, 1037927181)]), (double)65.0F, (double)1.0F, (double)100.0F, (double)1.0F)).IIl(lIlIII.Il(ll[IllII(2134073759, 1973836543)])));
      this.II = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(ll[IllII(2134073756, 728458091)]), (double)95.0F, (double)1.0F, (double)100.0F, (double)1.0F)).IIl(lIlIII.Il(ll[IllII(2134073757, -1918960575)])));
      this.I = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(ll[IllII(2134073746, 2120247985)]), (double)55.0F, (double)60.0F, (double)0.0F, (double)300.0F, (double)5.0F)).IIII(lIlIII.Il(ll[IllII(2134073747, 1016496532)])));
      this.Illl = -1;
      this.IlII = -1;
      this.IIII = null;
      this.lI = IllII(2134073744, 1398072461);
      this.IIll.lIII(this::IIllI);
      this.II.lIII(this::IIllI);
   }

   private int ll(class_746 var1) {
      if (var1 == null) {
         return 0;
      } else {
         int var2 = this.lII(var1.method_6047()) ? var1.method_6047().method_7947() : 0;
         if (this.lII(var1.method_6079())) {
            var2 += var1.method_6079().method_7947();
         }

         return var2;
      }
   }

   private boolean IlI(class_310 var1) {
      if (var1 != null && var1.field_1724 != null && this.IlII >= 0 && this.IlII < IllII(2134073745, 592405054)) {
         return IllllIlI.lIIlI(var1.field_1724.method_31548()) == this.IlII && this.lII(var1.field_1724.method_31548().method_5438(this.IlII));
      } else {
         return false;
      }
   }

   public String Il() {
      int var1 = (int)Math.round(this.III.IlII());
      int var2 = (int)Math.round(this.III.IlI());
      String var10000;
      if (var1 == var2) {
         var10000 = Integer.toString(var1);
      } else {
         String var5 = lIlIII.Il(ll[3]);
         var10000 = var1 + var5 + var2;
      }

      String var3 = var10000;
      if ((Boolean)this.IIlI.III()) {
         var10000 = lIlIII.Il(ll[4]);
         String var7 = lIlIII.Il(ll[5]);
         String var8 = var10000;
         var10000 = var8 + var3 + var7;
      } else {
         String var9 = lIlIII.Il(ll[2]);
         var10000 = var3 + var9;
      }

      return var10000;
   }

   private boolean lII(class_1799 var1) {
      return var1 != null && !var1.method_7960() && var1.method_31574(class_1802.field_8287);
   }

   private void llI(class_310 var1) {
      if (!this.IIllI()) {
         this.IlIll(var1);
         this.IIIII();
      } else if (!this.IlIl(var1)) {
         this.IlIll(var1);
         this.IIIII();
      } else if (!lIlIllll.lIIl(var1)) {
         class_746 var2 = var1.field_1724;
         if (this.IllI && this.Ill != var2) {
            this.IIIII();
         }

         double var3 = this.Illl(var2);
         double var5 = Math.max((Double)this.IIll.III(), (Double)this.II.III());
         if (!this.IllI) {
            if (!x.IlIllIl.IIIll(var3, (Double)this.IIll.III())) {
               return;
            }

            this.IlII = this.IIlll(var2);
            if (this.IlII < 0) {
               return;
            }

            this.Illl = IllllIlI.lIIlI(var2.method_31548());
            this.Ill = var2;
            this.IllI = true;
         }

         if (x.IlIllIl.III(var3, var5)) {
            this.IlIll(var1);
            this.IIIII();
         } else {
            if (!this.lII(var2.method_31548().method_5438(this.IlII))) {
               this.IlII = this.IIlll(var2);
               if (this.IlII < 0) {
                  this.IlIll(var1);
                  this.IIIII();
                  return;
               }
            }

            if (this.IIII == null || !this.IIII.III() || !IllllIlI.IIII(var1, this.IIII) || this.IIII.ll() != this.IlII) {
               boolean var7 = IllllIlI.IIlIl(var1) != this.IlII;
               int var8 = var7 ? this.lIII(this.I) : 0;
               this.IIII = IllllIlI.lIll(var1, this, this.IlII, var8, true);
               if (this.IIII == null || !this.IIII.III()) {
                  this.IIII = null;
                  this.IIl = 0L;
                  return;
               }

               this.IIl = Long.MAX_VALUE;
            }

            if (IllllIlI.IlIllII(var1, this.IIII)) {
               long var11 = System.currentTimeMillis();
               if (this.l) {
                  if (var2.field_6012 > this.lI) {
                     ++this.Il;
                     this.l = false;
                     this.lI = IllII(2134073750, 1734363659);
                     this.IlI = null;
                     this.IIl = 0L;
                  }

               } else {
                  if (this.IIl == Long.MAX_VALUE) {
                     this.IIl = var11;
                  }

                  if (var11 >= this.IIl) {
                     final long var9 = (long)this.llII() * 50L;
                     if (this.IIII(var1)) {
                        this.l = true;
                        this.lI = var2.field_6012 + 1;
                        this.IlI = new Runnable() {
                           public void run() {
                              IIIlllI.this.IIl = System.currentTimeMillis() + var9;
                           }
                        };
                     }

                  }
               }
            }
         }
      }
   }

   public void Ill() {
      this.IlIIl(class_310.method_1551(), false);
      this.llI(class_310.method_1551());
   }

   private void lll(long var1, boolean var3) {
      if (var1 == this.Il && this.l) {
         Runnable var4 = this.IlI;
         this.l = false;
         this.lI = IllII(2134073751, -617554002);
         this.IlI = null;
         if (var3 && var4 != null) {
            var4.run();
         } else {
            this.IIl = 0L;
         }

      }
   }

   private boolean IIII(class_310 var1) {
      if (this.IlIl(var1) && this.IlI(var1) && IllllIlI.lIllI(var1) <= 0) {
         float var2 = var1.field_1724.method_36454();
         long var3 = ++this.Il;
         return IlIlIl.IlIll(var1, IllII(2134073748, 586877508), var2, 90.0F, () -> {
            if (this.l && var3 == this.Il && this.IlI(var1)) {
               class_1269 var4 = var1.field_1761.method_2919(var1.field_1724, class_1268.field_5808);
               boolean var5 = var4 != null && var4.method_23665();
               this.lll(var3, var5);
               return var5;
            } else {
               return false;
            }
         });
      } else {
         return false;
      }
   }

   private boolean IlII(class_746 var1) {
      return var1 != null && (this.lII(var1.method_6047()) || this.lII(var1.method_6079()));
   }

   private boolean IlIl(class_310 var1) {
      return this.IIIIIlI() && var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var1.field_1755 == null && var1.field_1724.method_5805();
   }

   private double Illl(class_746 var1) {
      double var2 = (double)100.0F;
      boolean var4 = false;

      for(class_1304 var8 : new class_1304[]{class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166}) {
         class_1799 var9 = var1.method_6118(var8);
         if (var9 != null && !var9.method_7960() && x.IlIllIl.IIIl(var9.method_7963(), this.IIlII(var9))) {
            var4 = true;
            var2 = Math.min(var2, x.IlIllIl.IIII(var9.method_7936(), var9.method_7919()));
         }
      }

      return var4 ? var2 : (double)100.0F;
   }

   public void lllIl(class_310 var1) {
      if (this.lll) {
         boolean var2 = this.IlIl(var1) && (IllllIlI.lIllI(var1) > 0 || this.ll(var1.field_1724) < this.llI);
         Runnable var3 = this.IlIl;
         this.lIIl();
         if (var2 && var3 != null) {
            var3.run();
         }

      }
   }

   public void IllI(class_310 var1) {
      this.IlIIl(var1, false);
      if (this.IlIl(var1) && var1.field_1690 != null && var1.field_1690.field_1904 != null) {
         if (var1.field_1690.field_1904.method_1434() && this.IlII(var1.field_1724)) {
            if (!this.lll) {
               long var2 = System.currentTimeMillis();
               if (var2 < this.IIIl) {
                  IIlllllI.llIl(var1, 1);
               } else {
                  this.llI = this.ll(var1.field_1724);
                  this.lll = true;
                  final long var4 = (long)this.llII() * 50L;
                  this.IlIl = new Runnable() {
                     public void run() {
                        IIIlllI.this.IIIl = System.currentTimeMillis() + var4;
                     }
                  };
                  IllllIlI.lIllll(var1);
               }
            }
         } else {
            this.lIIl();
         }
      } else {
         this.IIIl = 0L;
         this.lIIl();
      }
   }

   private int lIII(llllIlIl var1) {
      return Math.max(0, (int)Math.ceil((double)this.IlIII(var1) / (double)50.0F));
   }

   private void lIIl() {
      this.lll = false;
      this.llI = 0;
      this.IlIl = null;
   }

   private int llII() {
      double var1 = Math.min(this.III.IlII(), this.III.IlI());
      double var3 = Math.max(this.III.IlII(), this.III.IlI());
      int var5 = (int)Math.round(var1);
      int var6 = (int)Math.round(var3);
      return var5 >= var6 ? Math.max(0, var5) : ThreadLocalRandom.current().nextInt(var5, var6 + 1);
   }

   private static String lllI(char[] var0, long var1, int var3) {
      int var4 = IllII(2134073749, -573472820) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IllII(2134073738, -715233134);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private void IIIII() {
      ++this.Il;
      this.IllI = false;
      this.Ill = null;
      this.Illl = -1;
      this.IlII = -1;
      this.IIl = 0L;
      this.IIII = null;
      this.l = false;
      this.lI = IllII(2134073739, -791554415);
      this.IlI = null;
   }

   private static void IIIll() {
      ll[0] = lllI(IllIl(2123842826, 958889670).toCharArray(), 2548L, IllII(2134073736, 420106269));
      ll[1] = lllI("".toCharArray(), 48613L, IllII(2134073737, -889157261));
      ll[2] = lllI(IllIl(2123842827, 1006914310).toCharArray(), 93025L, IllII(2134073742, -1531699200));
      ll[3] = lllI(IllIl(2123842824, -1712510461).toCharArray(), 2704L, IllII(2134073743, 3832506));
      ll[4] = lllI(IllIl(2123842825, 2033663135).toCharArray(), 24901L, IllII(2134073740, 2090777766));
      ll[5] = lllI(IllIl(2123842830, 1220479445).toCharArray(), 58432L, IllII(2134073741, -815144856));
      ll[IllII(2134073730, 1620287501)] = lllI(IllIl(2123842831, 671055870).toCharArray(), 94278L, IllII(2134073731, 126362001));
      ll[IllII(2134073728, 764750837)] = lllI(IllIl(2123842828, -1639156728).toCharArray(), 51680L, IllII(2134073729, -813441204));
      ll[IllII(2134073734, -1066398108)] = lllI(IllIl(2123842829, -1622854934).toCharArray(), 98439L, IllII(2134073735, 44383911));
      ll[IllII(2134073732, 74448388)] = lllI(IllIl(2123842818, 1928139190).toCharArray(), 98089L, IllII(2134073733, 14903484));
      ll[IllII(2134073786, 1259788066)] = lllI(IllIl(2123842819, -970248377).toCharArray(), 88297L, IllII(2134073787, 628436686));
      ll[IllII(2134073784, -696934895)] = lllI(IllIl(2123842816, 955854156).toCharArray(), 17655L, IllII(2134073785, 1647991581));
      ll[IllII(2134073790, -1307665338)] = lllI(IllIl(2123842817, -1192015448).toCharArray(), 60529L, IllII(2134073791, 1905687790));
      ll[IllII(2134073788, 1981206934)] = lllI(IllIl(2123842822, -824819418).toCharArray(), 29202L, IllII(2134073789, 804663382));
      ll[IllII(2134073778, 1828296375)] = lllI(IllIl(2123842823, -287808011).toCharArray(), 49934L, IllII(2134073779, -1760411495));
   }

   private boolean IIlII(class_1799 var1) {
      class_9304 var2 = (class_9304)var1.method_58695(class_9334.field_49633, class_9304.field_49385);

      for(class_6880 var4 : var2.method_57534()) {
         String var5 = (String)var4.method_40230().map((var0) -> var0.method_29177().method_12832()).orElse(ll[1]);
         if (lIlIII.Il(ll[0]).equals(var5)) {
            return true;
         }
      }

      return false;
   }

   public void lI() {
      this.IIIl = 0L;
      this.lIIl();
      this.IlIll(class_310.method_1551());
      this.IIIII();
   }

   public void IIlIl(class_310 var1) {
      if (this.lll) {
         this.IlIIl(var1, false);
      }
   }

   private boolean IIllI() {
      return (Boolean)this.IIlI.III();
   }

   private int IIlll(class_746 var1) {
      if (var1 == null) {
         return -1;
      } else {
         for(int var2 = 0; var2 < IllII(2134073776, 1061250251); ++var2) {
            if (this.lII(var1.method_31548().method_5438(var2))) {
               return var2;
            }
         }

         return -1;
      }
   }

   static {
      short var6 = 16052;
      String var7 = "눈㤙\ue3c9竂愉ꡄﰳ\uf7de\uf528媘▩咽♑ꎙ\uf660㞹鸋\ue390\ue3b0劔Ｉ䐜䪐熦ⰿ\ueadf疺엪閘㚱肻붾ﱞ稒㼅醢菶橦쥳⏓\ud924笱扛\ue6ad\ueb03삱㪻邑퓫ޟ擿㪏\uda0c\uede1\u0ba2寞嫈ᒼ\ue50f에\udd20覷귪率뚿爋ఖ类อ\uf06d骵\udcb4\ue73fԈ悢鉴їꕖ⌐郙窴\uea07로셿䓊篽탼滄Ӵ\uec62湙묓鐫䧷ุ蛫슂턻ପ뒘潋訩㑵ꋾ\ue105쮮滽㨾ᗎ忦⹘\ue702紤兼꒞䆊梶毠㠱䩟栮ႅꔁ畁\ue08d쮍觾鷈ﻦ䄪䊰ཙ䰻Ⳛ遻윞\udb17璚툈赪齞錛\uef78⬚簵劑昂\uf08d곟砈쭩聂ﶡ糲閷ᦴ䩕찬죤峠갿̒ꮂ庪꺌ꇹ惾⍪梕ធ✮밆\ue005\udbb1\uee33\uf08dࢊ媁줒ﳄ躌Ͼ\udf77ፐ\udc58\uef89\uea99韨៲㖱\uf1c8憻쌉\uf893⋚\uf3a6\uaacb\uf28aꍬ䣶篵갥鳰\ue0fb簟嗞滜胦拓ꃄ桍ﰨ㠇世輒샭㛬듨늿쫖";
      char[] var8 = "㺸㺰㺰㺼㺰㺸㺰㺬㻬㺰㺬㺼㺤㺼".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            lIIl = var9;
            lIlI = new Object[var9.length];
            int var2 = 603218198;
            byte[] var0 = "\u00024\u0017(\u001dv\u000b\u0099\u007fX\u0003M\u0088³ý×a\u001a\u0083\u008d)aZ|w¬cêÑYüÀ\"§j8`Q\u0081\u0016\u008f\u0093ä\u000b\u007f\u0088b°»§J\u008b\u0007÷ß/~<\u000bí~¨\rm\u0089\u0099hñ\f\u0016Ö\f´mÁCA^Ìî5v\"\u0007\u001dÅ\u0013ÿ\u0090\u0098\u008f}Ì:Z)<T \u009fýk\u001d\u008fqR+d\u001dÈP»\u009c·\u000eü_Åè,X¨þ\u009f\u0083\u008eö\u008c\u0017Ñ×\u0084\u001f\u0096sp\u008a²\u009e´\u0087oy´îÉ\u009câÊ\"7.*ÑÑ1¥PIb0>\u0096\u001dõÝ\u0092®c\u0086dd\u0012Å~1ÀøWf".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lIII = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lIII[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            ll = new String[IllII(2134073777, 1308786329)];
            IIIll();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 89;
                     break;
                  case 1:
                     var10000 = 63;
                     break;
                  case 2:
                     var10000 = 59;
                     break;
                  case 3:
                     var10000 = 74;
                     break;
                  case 4:
                     var10000 = 43;
                     break;
                  case 5:
                     var10000 = 30;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private long IlIII(llllIlIl var1) {
      double var2 = var1.IlII();
      double var4 = var1.IlI();
      return var2 == var4 ? Math.max(0L, Math.round(var2)) : Math.max(0L, Math.round(ThreadLocalRandom.current().nextDouble(var2, var4)));
   }

   private void IlIIl(class_310 var1, boolean var2) {
      if (this.IIIIIlI() && var1 != null && var1.field_1724 != null && this.IlII(var1.field_1724)) {
         lIIllll var3 = (lIIllll)var1;
         int var4 = this.llII();
         if (var2 || var3.ilovcats$getUseCd() > var4) {
            var3.ilovcats$setUseCd(var4);
         }

      }
   }

   private void IlIll(class_310 var1) {
      if (var1 != null && var1.field_1724 != null && var1.field_1724 == this.Ill && this.Illl >= 0 && this.Illl < IllII(2134073782, -1673570353)) {
         if (this.Illl != IllllIlI.lIIlI(var1.field_1724.method_31548())) {
            IllllIlI.llIIlI(var1, this, this.Illl);
         }

      }
   }

   private static int IllII(int var0, int var1) {
      return lIII[var0 ^ 2134073754] ^ var1 ^ var0;
   }

   private static String IllIl(int var0, int var1) {
      int var3 = var0 ^ 2123842826;
      char[] var4 = lIIl[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])lIlI[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         lIlI[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -106371090;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 105;
               break;
            case 1:
               var9 = 233;
               break;
            case 2:
               var9 = 130;
               break;
            case 3:
               var9 = 134;
               break;
            case 4:
               var9 = 191;
               break;
            case 5:
               var9 = 161;
               break;
            case 6:
               var9 = 138;
               break;
            case 7:
               var9 = 96;
               break;
            case 8:
               var9 = 153;
               break;
            case 9:
               var9 = 232;
               break;
            case 10:
               var9 = 213;
               break;
            case 11:
               var9 = 177;
               break;
            case 12:
               var9 = 0;
               break;
            case 13:
               var9 = 249;
               break;
            case 14:
               var9 = 184;
               break;
            case 15:
               var9 = 41;
               break;
            case 16:
               var9 = 217;
               break;
            case 17:
               var9 = 205;
               break;
            case 18:
               var9 = 89;
               break;
            case 19:
               var9 = 230;
               break;
            case 20:
               var9 = 158;
               break;
            case 21:
               var9 = 123;
               break;
            case 22:
               var9 = 195;
               break;
            case 23:
               var9 = 150;
               break;
            case 24:
               var9 = 140;
               break;
            case 25:
               var9 = 113;
               break;
            case 26:
               var9 = 73;
               break;
            case 27:
               var9 = 237;
               break;
            case 28:
               var9 = 117;
               break;
            case 29:
               var9 = 125;
               break;
            case 30:
               var9 = 11;
               break;
            case 31:
               var9 = 173;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
