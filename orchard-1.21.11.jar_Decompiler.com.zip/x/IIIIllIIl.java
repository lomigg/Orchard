package x;

import com.google.gson.JsonObject;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.BooleanSupplier;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1661;
import net.minecraft.class_1764;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_9278;
import net.minecraft.class_9334;
import net.minecraft.class_239.class_240;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;

@Environment(EnvType.CLIENT)
public final class IIIIllIIl extends IIIIIIIlI {
   private static final int I = 10;
   private float l;
   private int II;
   private int Il;
   private int lI;
   private final IlIlIll ll;
   private static final long III = 1500L;
   private boolean IIl;
   private static final double IlI = 1.6;
   private static final long Ill = 50L;
   private class_1268 lII;
   private int lIl;
   private float llI;
   private class_2338 lll;
   private static final double IIII = (double)0.125F;
   private float IIIl;
   private static final double IIlI = (double)0.0F;
   private static final double IIll = (double)20.25F;
   private <undefinedtype> IlII;
   private static final double IlIl = 0.22;
   private float IllI;
   private float Illl;
   private static final double lIII = 0.05;
   private static final int lIIl = 1;
   private static final double lIlI = 0.08;
   private static final long lIll = 50L;
   private final lIIIIl llII;
   private final IlIIIlIlI<<undefinedtype>> llIl;
   private static final long lllI = 1000L;
   private static final <undefinedtype> llll;
   private boolean IIIII;
   private <undefinedtype> IIIIl;
   private static final double IIIlI = 0.58;
   private static final double IIIll = (double)1.0F;
   private static final double IIlII = (double)0.0625F;
   private static final int IIlIl = 2;
   private int IIllI;
   private static final double IIlll = (double)0.0F;
   private final IlIIIlIlI<<undefinedtype>> IlIII;
   private static final <undefinedtype> IlIIl;
   private float IlIlI;
   private static final double IlIll = 3.15;
   private static final int IllII = 6;
   private static final double IllIl = (double)4.5F;
   private static final double IlllI = 0.99;
   private long Illll;
   private <undefinedtype> lIIII;
   private float lIIIl;
   private final llllIlIl lIIlI;
   private <undefinedtype> lIIll;
   private class_2338 lIlII;
   private static final int lIlIl = 70;
   private int lIllI;
   private static final double lIlll = 0.38;
   private int llIII;
   private final IIIllIIII llIIl;
   private static final int llIlI = 9;
   private boolean llIll;
   private float lllII;
   private long lllIl;
   private static final int[] llllI;
   private static final String[] lllll;
   private static final Object[] IIIIII;

   private class_243 ll(class_2338 var1) {
      return class_243.method_24955(var1).method_1031((double)0.0F, (double)0.125F, (double)0.0F);
   }

   private double IlI(class_243 var1, class_243 var2, class_243 var3) {
      if (var1 != null && var2 != null && var3 != null) {
         class_243 var4 = var2.method_1020(var1);
         double var5 = var4.method_1027();
         if (var5 < 1.0E-7) {
            return var1.method_1025(var3);
         } else {
            double var7 = var3.method_1020(var1).method_1026(var4) / var5;
            var7 = Math.max((double)0.0F, Math.min((double)1.0F, var7));
            return var1.method_1019(var4.method_1021(var7)).method_1025(var3);
         }
      } else {
         return Double.POSITIVE_INFINITY;
      }
   }

   public void Ill() {
   }

   private class_243 lII(class_2338 var1) {
      return class_243.method_24955(var1);
   }

   private <undefinedtype> llI(class_310 var1, class_1799 var2) {
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null) {
         <undefinedtype> var3 = this.lIII(var2);
         float var4 = var1.field_1724.method_36454();
         float var5 = var1.field_1724.method_36455();
         <undefinedtype> var6 = this.IIIIll(var1, var3, var4, var5);
         if (var6 != null) {
            return var6;
         } else {
            class_243 var7 = var1.field_1724.method_33571();
            class_243 var8 = this.lIlIlI(var4, var5).method_1021(var3.I()).method_1019(var1.field_1724.method_18798());
            class_2338 var9 = null;

            for(int var10 = 0; var10 < llIIII(2003201099, 1362756786); ++var10) {
               class_243 var11 = var7.method_1019(var8);
               class_3965 var12 = this.lIllll(var1, var7, var11);

               for(int var13 = 1; var13 <= llIIII(2003201098, -868964413); ++var13) {
                  double var14 = (double)var13 / (double)10.0F;
                  class_243 var16 = var7.method_35590(var11, var14);
                  class_2338 var17 = class_2338.method_49638(var16);
                  if (var9 != null && !var9.equals(var17)) {
                     <undefinedtype> var18 = this.lIIlI(var1, var3, var9, var17, var4, var5);
                     if (var18 != null) {
                        return var18;
                     }
                  }

                  var9 = var17;
               }

               if (this.IlllII(var12)) {
                  <undefinedtype> var19 = this.lIIIIl(var1, var3, var12, var4, var5);
                  return var19;
               }

               var7 = var11;
               var8 = var8.method_1021(var3.II()).method_1023((double)0.0F, var3.l(), (double)0.0F);
               if (var11.field_1351 < (double)var1.field_1687.method_31607() - (double)20.0F) {
                  return null;
               }
            }

            return null;
         }
      } else {
         return null;
      }
   }

   private void lll(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         if (!(Boolean)this.llII.III()) {
            IllllIlI.IlII(var1, this, null.Il);
         } else if (this.lIl >= 0 && this.lIl < llIIII(2003201097, -2008862826)) {
            IllllIlI.llIIlI(var1, this, this.lIl);
         } else {
            IllllIlI.IlII(var1, this, null.II);
         }
      }
   }

   private void IIII(class_310 var1, Object var2, Object var3, float var4, float var5, class_3965 var6, BooleanSupplier var7) {
      if (this.IlIII.III() == null.Il) {
         this.lIIII = var2;
         this.Il = var1.field_1724.field_6012 + 2;
         boolean var12 = IlIlIl.III(var1, var6);
         boolean var13 = IlIlIl.IIIIlI(var1, llIIII(2003201096, 2011927150), var12 ? var1.field_1724.method_36454() : var4, var12 ? var1.field_1724.method_36455() : var5, () -> this.IlIIl(var1, var2, var3, var7));
         if (!var13) {
            this.IIll();
            this.Illll = System.currentTimeMillis();
         }

      } else {
         boolean var8 = IlIlIl.III(var1, var6);
         float var9 = var8 ? 0.0F : this.ll.IlIl(var1, this.lIIll(var1, var4, var5), ((Double)this.llIIl.III()).floatValue());
         long var10 = System.currentTimeMillis();
         if (var8 || var9 <= 0.5F || var10 - this.lllIl >= 1500L) {
            if (!var8) {
               IllllIlI.IIIlIII(var1, var4, var5);
            }

            this.lIlll(var1);
            if (this.IIlII(var7)) {
               this.llIIl(var3, var1);
            } else {
               this.IIlll(var1);
            }
         }

      }
   }

   private void IIll() {
      this.lIIII = null.lI;
      this.Il = llIIII(2003201103, -2121687193);
   }

   private boolean IlII(class_3965 var1) {
      return this.IlllII(var1);
   }

   private boolean IlIl(class_310 var1, int var2) {
      if (var1 != null && var1.field_1724 != null && var2 >= 0 && var2 < llIIII(2003201102, 392261512)) {
         return this.llII(var1, var2);
      } else {
         this.IIlll(var1);
         return false;
      }
   }

   private boolean Illl(class_310 var1) {
      if (var1 != null && var1.field_1724 != null && var1.field_1761 != null) {
         if (this.lII == class_1268.field_5808 && (IllllIlI.IIlIl(var1) != this.II || !this.lIllIl(var1.field_1724.method_31548(), this.II))) {
            return false;
         } else {
            this.lIlll(var1);
            return this.IIlII(() -> {
               class_1269 var2 = IllllIlI.lllIlI(var1, this.lII);
               return var2 != null && var2.method_23665();
            });
         }
      } else {
         return false;
      }
   }

   private <undefinedtype> lIII(class_1799 var1) {
      class_9278 var2 = var1 == null ? null : (class_9278)var1.method_58694(class_9334.field_49649);
      boolean var3 = var2 != null && var2.method_57438(class_1802.field_8639);
      return var3 ? new Record(1.6, 0.99, (double)0.0F) {
         private final double I;
         private final double l;
         private final double II;

         private {
            this.I = var1;
            this.l = var3;
            this.II = var5;
         }

         public double I() {
            return this.I;
         }

         public double l() {
            return this.II;
         }

         public double II() {
            return this.l;
         }
      } : new Record(3.15, 0.99, 0.05) {
         private final double I;
         private final double l;
         private final double II;

         private {
            this.I = var1;
            this.l = var3;
            this.II = var5;
         }

         public double I() {
            return this.I;
         }

         public double l() {
            return this.II;
         }

         public double II() {
            return this.l;
         }
      };
   }

   private double lIIl(class_243 var1, class_243 var2, class_243 var3) {
      if (var3 == null) {
         return Double.NaN;
      } else {
         double var4 = var2.field_1352 - var1.field_1352;
         double var6 = var2.field_1351 - var1.field_1351;
         double var8 = var2.field_1350 - var1.field_1350;
         double var10 = Math.abs(var4);
         double var12 = Math.abs(var6);
         double var14 = Math.abs(var8);
         if (var10 >= var12 && var10 >= var14 && var10 > 1.0E-7) {
            return (var3.field_1352 - var1.field_1352) / var4;
         } else if (var12 >= var10 && var12 >= var14 && var12 > 1.0E-7) {
            return (var3.field_1351 - var1.field_1351) / var6;
         } else {
            return var14 > 1.0E-7 ? (var3.field_1350 - var1.field_1350) / var8 : Double.NaN;
         }
      }
   }

   private boolean llII(class_310 var1, int var2) {
      if (var1 != null && var1.field_1724 != null && var2 >= 0 && var2 < llIIII(2003201101, 414383723)) {
         if (this.IlII == null || !this.IlII.III() || this.IlII.ll() != var2) {
            boolean var3 = IllllIlI.IIlIl(var1) != var2;
            int var4 = var3 ? this.IllIlI(this.lIIlI) : 0;
            this.IlII = IllllIlI.lIll(var1, this, var2, var4, true);
         }

         if (!this.IlII.III()) {
            this.IlII = null;
            return false;
         } else if (!IllllIlI.IlIllII(var1, this.IlII)) {
            return false;
         } else {
            this.IlII = null;
            return true;
         }
      } else {
         return false;
      }
   }

   private boolean lllI(class_310 var1) {
      return var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var1.field_1690 != null;
   }

   private class_1799 IIIII(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         if (this.lII == class_1268.field_5810) {
            return var1.field_1724.method_6079();
         } else {
            return this.II >= 0 && this.II < llIIII(2003201100, 608502158) ? var1.field_1724.method_31548().method_5438(this.II) : class_1799.field_8037;
         }
      } else {
         return class_1799.field_8037;
      }
   }

   private boolean IIIIl(class_310 var1, class_2338 var2) {
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null && var2 != null) {
         class_2680 var3 = var1.field_1687.method_8320(var2);
         class_2680 var4 = var1.field_1687.method_8320(var2.method_10074());
         return (var3.method_26215() || var3.method_45474()) && var4 != null && !var4.method_26215() && var4.method_26227().method_15769() && !var4.method_26220(var1.field_1687, var2.method_10074()).method_1110() && var1.field_1724.method_33571().method_1025(this.IlIIIl(var2)) <= (double)20.25F && this.IllIll(var1, this.lllll(var2), var2.method_10074());
      } else {
         return false;
      }
   }

   public void IIl(JsonObject var1) {
      super.IIl(var1);
      this.lllIll(var1, IlIIl.lIlI());
      this.llIlIl(var1, llll.lIlI(), new llllIlIl[]{this.lIIlI});
      this.llIlIl(var1, lIlIII.Il(llIIIl(1315392246, '릖', '맛')), new llllIlIl[]{this.lIIlI});
   }

   private boolean IIIll(class_1799 var1) {
      return var1 != null && !var1.method_7960() && var1.method_7909() instanceof class_1764 && class_1764.method_7781(var1);
   }

   private boolean IIlII(BooleanSupplier var1) {
      boolean var2 = IllllIlI.lIlIl();

      boolean var3;
      try {
         var3 = var1.getAsBoolean();
      } finally {
         if (var2) {
            IllllIlI.IIlllI();
         }

      }

      return var3;
   }

   boolean IIlIl() {
      return this.IIIIIlI() && this.IIl && this.IIIIl != null.lI;
   }

   private boolean IIllI(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         if (!(Boolean)this.llII.III()) {
            IllllIlI.IlII(var1, this, null.Il);
            return true;
         } else if (this.lIl >= 0 && this.lIl < llIIII(2003201091, 1295399345)) {
            IllllIlI.llIIlI(var1, this, this.lIl);
            return true;
         } else {
            IllllIlI.IlII(var1, this, null.II);
            return true;
         }
      } else {
         return false;
      }
   }

   private void IIlll(class_310 var1) {
      if (this.IIllI(var1)) {
         this.lIIlIl();
         this.IlIllI();
      } else {
         this.IIIIl = null.II;
         this.lllIl = System.currentTimeMillis();
         this.Illll = this.lllIl;
      }
   }

   private boolean IlIIl(class_310 var1, Object var2, Object var3, BooleanSupplier var4) {
      if (this.IIIIl == var2 && this.lIIII == var2) {
         this.IIll();
         this.lIlll(var1);
         boolean var5 = this.IIlII(var4);
         if (var5) {
            this.llIIl(var3, var1);
         } else {
            this.IIlll(var1);
         }

         return var5;
      } else {
         return false;
      }
   }

   private class_2350 IllII(float var1) {
      return class_2350.method_10150((double)var1);
   }

   private int IllIl(class_1661 var1) {
      for(int var2 = 0; var2 < llIIII(2003201090, -1083460307); ++var2) {
         class_1799 var3 = var1.method_5438(var2);
         if (var3.method_31574(class_1802.field_8129) || var3.method_31574(class_1802.field_8848) || var3.method_31574(class_1802.field_8211) || var3.method_31574(class_1802.field_8655)) {
            return var2;
         }
      }

      return -1;
   }

   private boolean IlllI(class_310 var1) {
      IllllIlI.IIIlIII(var1, this.lIIIl, this.IlIlI);
      return this.Illl(var1);
   }

   private void Illll(class_310 var1) {
      if (!this.IIIII) {
         if (!this.IlIIlI(var1)) {
            this.IIlll(var1);
         } else if (!this.IllIII(var1)) {
            this.IIlll(var1);
         } else if (this.lII != class_1268.field_5808 || this.IlIl(var1, this.II)) {
            if (this.IlIII.III() == null.Il) {
               this.IIIII = true;
               this.lI = var1.field_1724.field_6012 + 1;
               boolean var6 = IlIlIl.IIIlll(var1, llIIII(2003201089, 1598571746), this.lIIIl, this.IlIlI, () -> this.llIlI(var1));
               if (!var6) {
                  this.IIIII = false;
                  this.lI = llIIII(2003201088, -1992597567);
                  this.Illll = System.currentTimeMillis();
               }

            } else {
               float var2 = this.ll.IlIl(var1, this.lIIll(var1, this.lIIIl, this.IlIlI), ((Double)this.llIIl.III()).floatValue());
               long var3 = System.currentTimeMillis();
               if (var2 <= 0.5F || var3 - this.lllIl >= 1500L) {
                  boolean var5 = this.IlllI(var1);
                  if (!var5) {
                     this.IIlll(var1);
                     return;
                  }

                  this.llIIl(null.II, var1);
               }

            }
         }
      }
   }

   private class_243 lIIII(class_2338 var1) {
      return new class_243((double)var1.method_10263() + (double)0.5F, (double)var1.method_10264() + 0.38, (double)var1.method_10260() + (double)0.5F);
   }

   private double[] lIIIl(double var1, double var3, double var5, double var7, double var9, double var11) {
      if (!(Math.abs(var3) < 1.0E-7)) {
         double var13 = (var5 - var1) / var3;
         double var15 = (var7 - var1) / var3;
         if (var13 > var15) {
            double var17 = var13;
            var13 = var15;
            var15 = var17;
         }

         var9 = Math.max(var9, var13);
         var11 = Math.min(var11, var15);
         return var9 <= var11 ? new double[]{var9, var11} : null;
      } else {
         return var1 >= var5 && var1 <= var7 ? new double[]{var9, var11} : null;
      }
   }

   private <undefinedtype> lIIlI(class_310 var1, Object var2, class_2338 var3, class_2338 var4, float var5, float var6) {
      if (!this.IIIIIl(var3, var4)) {
         return null;
      } else if (!this.llllI(var1, var3, var4)) {
         return null;
      } else {
         float[] var7 = this.lIlII(var1, var2, var3, var4, var5, var6);
         return var7 == null ? null : new Record(var3.method_10062(), var4.method_10062(), var7[0], var7[1]) {
            private final class_2338 I;
            private final float l;
            private final float II;
            private final class_2338 Il;

            public float I() {
               return this.l;
            }

            public class_2338 l() {
               return this.Il;
            }

            public class_2338 II() {
               return this.I;
            }

            private {
               this.Il = var1;
               this.I = var2;
               this.l = var3;
               this.II = var4;
            }

            public float Il() {
               return this.II;
            }
         };
      }
   }

   private class_243 lIIll(class_310 var1, float var2, float var3) {
      float var4 = var2 * ((float)Math.PI / 180F);
      float var5 = var3 * ((float)Math.PI / 180F);
      float var6 = class_3532.method_15362((double)var5);
      float var7 = class_3532.method_15374((double)var5);
      float var8 = class_3532.method_15362((double)var4);
      float var9 = class_3532.method_15374((double)var4);
      class_243 var10 = new class_243((double)(-var9 * var6), (double)(-var7), (double)(var8 * var6));
      return var1.field_1724.method_33571().method_1019(var10.method_1021((double)5.0F));
   }

   private float[] lIlII(class_310 var1, Object var2, class_2338 var3, class_2338 var4, float var5, float var6) {
      if (var1 != null && var1.field_1724 != null && var2 != null && var3 != null && var4 != null) {
         class_243 var7 = this.lIIII(var4);
         float[] var8 = IlIlIl.llIlI(var1, var7);
         if (var8 == null) {
            return null;
         } else {
            float var9 = var8[0];
            float var10 = var8[1];
            float[] var11 = new float[]{var5, var9};
            float[] var10000 = new float[llIIII(2003201095, -579082972)];
            var10000[0] = var6;
            var10000[1] = var10;
            var10000[2] = var10 + 1.0F;
            var10000[3] = var10 + 2.0F;
            var10000[4] = var10 - 1.0F;
            var10000[5] = var10 - 2.0F;
            var10000[llIIII(2003201094, -23505814)] = var10 + 3.5F;
            var10000[llIIII(2003201093, 299528678)] = var10 - 3.5F;
            float[] var12 = var10000;
            float[] var13 = null;
            double var14 = Double.POSITIVE_INFINITY;
            double var16 = this.lIIIlI(var1, var2, var3, var4, var5, var6);
            if (!Double.isNaN(var16)) {
               return new float[]{var5, var6};
            } else {
               for(float var21 : var11) {
                  for(float var25 : var12) {
                     double var26 = this.lIIIlI(var1, var2, var3, var4, var21, var25);
                     if (!Double.isNaN(var26) && var26 < var14) {
                        var14 = var26;
                        var13 = new float[]{var21, var25};
                     }
                  }
               }

               for(double var28 = (double)-4.0F; var28 <= 4.001; ++var28) {
                  for(double var31 = (double)-8.0F; var31 <= 10.001; ++var31) {
                     float var33 = (float)((double)var9 + var28);
                     float var35 = (float)((double)var10 + var31);
                     double var36 = this.lIIIlI(var1, var2, var3, var4, var33, var35);
                     if (!Double.isNaN(var36) && var36 < var14) {
                        var14 = var36;
                        var13 = new float[]{var33, var35};
                     }
                  }
               }

               if (var13 != null) {
                  float var29 = var13[0];
                  float var30 = var13[1];

                  for(double var32 = (double)-1.0F; var32 <= 1.001; var32 += (double)0.25F) {
                     for(double var34 = (double)-1.0F; var34 <= 1.001; var34 += (double)0.25F) {
                        float var37 = (float)((double)var29 + var32);
                        float var38 = (float)((double)var30 + var34);
                        double var39 = this.lIIIlI(var1, var2, var3, var4, var37, var38);
                        if (!Double.isNaN(var39) && var39 < var14) {
                           var14 = var39;
                           var13 = new float[]{var37, var38};
                        }
                     }
                  }
               }

               return var13;
            }
         }
      } else {
         return null;
      }
   }

   private <undefinedtype> lIlIl(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         class_1661 var2 = var1.field_1724.method_31548();
         int var3 = IllllIlI.lIIlI(var2);
         class_1799 var4 = var1.field_1724.method_6047();
         if (this.IIIll(var4)) {
            return new Record(class_1268.field_5808, var3, var4) {
               private final class_1268 I;
               private final int l;
               private final class_1799 II;

               public class_1268 I() {
                  return this.I;
               }

               public class_1799 l() {
                  return this.II;
               }

               public int II() {
                  return this.l;
               }

               private {
                  this.I = var1;
                  this.l = var2;
                  this.II = var3;
               }
            };
         } else {
            class_1799 var5 = var1.field_1724.method_6079();
            if (this.IIIll(var5)) {
               return new Record(class_1268.field_5810, -1, var5) {
                  private final class_1268 I;
                  private final int l;
                  private final class_1799 II;

                  public class_1268 I() {
                     return this.I;
                  }

                  public class_1799 l() {
                     return this.II;
                  }

                  public int II() {
                     return this.l;
                  }

                  private {
                     this.I = var1;
                     this.l = var2;
                     this.II = var3;
                  }
               };
            } else {
               for(int var6 = 0; var6 < llIIII(2003201092, 1042481756); ++var6) {
                  class_1799 var7 = var2.method_5438(var6);
                  if (this.IIIll(var7)) {
                     return new Record(class_1268.field_5808, var6, var7) {
                        private final class_1268 I;
                        private final int l;
                        private final class_1799 II;

                        public class_1268 I() {
                           return this.I;
                        }

                        public class_1799 l() {
                           return this.II;
                        }

                        public int II() {
                           return this.l;
                        }

                        private {
                           this.I = var1;
                           this.l = var2;
                           this.II = var3;
                        }
                     };
                  }
               }

               return null;
            }
         }
      } else {
         return null;
      }
   }

   static {
      short var6 = 3707;
      String var7 = "ⰵⲹⱻⰳⰴⰆⱵⱃⰒⰑⰭⱖⱯⰕⳠⰅ㘽㙛㙅㘊㘽㘢㙛㙳㘖㘕㛾㙬㙻㙛㙚㛵럏랩랷뜘럏런랩랁럤럧럛랰띩럣뜖뜃\uddcb\udd44\udd9f\udde5\uddd1\uddfa\udd85\udd98\uddf1\uddde\udd0d\udd4cϾΛΤωϱϻΠεϺψϜΟιςϜϝΌͪϸϝϩΈ̨ϻυ̿;ηϺψϒή̫ϢωϯΜ\u0382ϱφ́;ΛϑϿύοΊϕϔϫίβϑϋϒΧΎϴϺ̀ͻΥϺϱ̾̃ΛϽ͛ϧΝΈϖϣϏΓΠϿπϐ·\u03a2Ϻϳ̾γ\u038bϗϵ̶ͷᛚᚚᚾᛱᛔ\u16faᙛᚯᘘ\u16faᛯᙂᚘᘚᛰᛇᚩᚭᘅᘇ⫛⩃⪇⫒⫕⫹⩘⪬⨛⫹⫬⩁⪛⨙⫳⫄⪪⪮⨆⨄\uf810\uf88c\uf82a\uf825\uf80d\uf833\uf85c\uf859\uf828\uf85a\uf830\uf885삮섲샰삊사삡샺샌삊삔삜샑샋삕셳셪帷幋帩廽核梴桦栾栩栋桸桎栟栜棷桗档棯栁棼";
      char[] var8 = "\u0010\u0010\u0010\f\\\u0014\u0014\f\u0010\u0004\u0010".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            lllll = var9;
            IIIIII = new Object[var9.length];
            int var2 = -1613624897;
            byte[] var0 = "¹\u008ea\u0000$\u0080Â<`÷Ji\u009f_÷Qé=ú\u0097ÿÕ\npð\u0006\u009b\u0090Ìñdt¥\u0082\\DWßÐÙ·ü!Ôá\u008f:>5Ï\u0080Ô\u0016-1\u0095ùn\u0014\u001bÖ\u0097g®Q\u008c&U\u008b\u0082ñ ýÕ\u0012É+å\u0086\u0095\u0004ñúòæT\u001e|½\u009dê©'\u0085ÕÒÜãy\u0083ùv1\nÂA\u0015äoMë2Í\u00826{".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            llllI = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               llllI[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            IlIIl = lIlIII.l(llIIIl(-1102026125, '릗', '⿷'));
            llll = lIlIII.l(llIIIl(604770013, '릔', '㓙'));
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 119;
                     break;
                  case 1:
                     var10000 = 54;
                     break;
                  case 2:
                     var10000 = 30;
                     break;
                  case 3:
                     var10000 = 108;
                     break;
                  case 4:
                     var10000 = 110;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private void lIllI(class_310 var1) {
      if (!this.lIIIll(var1, this.lll)) {
         this.IIlll(var1);
      } else if (!this.IIlllI(var1.field_1687.method_8320(this.lll))) {
         long var2 = System.currentTimeMillis();
         if (var2 - this.lllIl <= 1000L) {
            this.Illll = var2 + 50L;
         } else {
            this.IIlll(var1);
         }
      } else if (this.IlIl(var1, this.llIII)) {
         this.lIIlll(var1);
      }
   }

   private void lIlll(class_310 var1) {
      if (var1 != null && var1.field_1690 != null && var1.field_1690.field_1904 != null) {
         IllllIlI.IIIIllI(var1.field_1690.field_1904);
         var1.field_1690.field_1904.method_23481(false);
      }
   }

   private void llIII() {
      this.IIll();
      this.Illll = System.currentTimeMillis() + 50L;
   }

   private void llIIl(Object var1, class_310 var2) {
      this.IlII = null;
      this.IIIIl = var1;
      long var3 = System.currentTimeMillis();
      this.lllIl = var3;
      this.Illll = var3 + Math.max(0L, this.lIIllI(var1) - 50L);
   }

   private boolean llIlI(class_310 var1) {
      this.IIIII = false;
      this.lI = llIIII(2003201115, 959988657);
      if (!this.IlIIlI(var1)) {
         this.IIlll(var1);
         return false;
      } else {
         boolean var2 = this.Illl(var1);
         if (var2) {
            this.llIIl(null.II, var1);
         } else {
            this.IIlll(var1);
         }

         return var2;
      }
   }

   private class_3965 llIll(class_2338 var1) {
      return var1 == null ? null : new class_3965(this.ll(var1), class_2350.field_11036, var1, false);
   }

   private boolean llllI(class_310 var1, class_2338 var2, class_2338 var3) {
      return this.IIIIl(var1, var2) && this.lIlIII(var1, var3) && this.lIIIll(var1, var3);
   }

   private class_243 lllll(class_2338 var1) {
      return this.IlIIIl(var1).method_1023((double)0.0F, (double)0.0625F, (double)0.0F);
   }

   public IIIIllIIl() {
      super((Object)lIlIII.l(llIIIl(52101174, '릕', '榌')), lIllII.I, (Object)lIlIII.l(llIIIl(-817162675, '릒', '毧')));
      this.IlIII = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(llIIIl(-1888727323, '릓', 'Ứ')), <undefinedtype>.class, null.Il));
      this.llIl = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(llIIIl(-1995154598, '릐', 'ᒓ')), <undefinedtype>.class, null.II));
      this.llIIl = (IIIllIIII)this.IIIlIll((IIIllIIII)(new IIIllIIII(lIlIII.l(llIIIl(-1956904630, '릑', '쒂')), (double)50.0F, (double)1.0F, (double)100.0F, (double)1.0F)).lIII(() -> this.IlIII.III() == null.l));
      this.ll = new IlIlIll();
      this.lIIlI = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(llIIIl(-1641661166, '릞', '\uf85e')), (double)55.0F, (double)60.0F, (double)0.0F, (double)300.0F, (double)5.0F)).Ill(lIlIII.l(llIIIl(-1191754234, '릟', '儋'))));
      this.llII = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(llIIIl(-2109321765, '릜', '嶠')), true));
      this.IIIIl = null.lI;
      this.lIl = -1;
      this.lIllI = -1;
      this.lIIll = null.l;
      this.IIllI = -1;
      this.llIII = -1;
      this.II = -1;
      this.lII = class_1268.field_5808;
      this.lIIII = null.lI;
      this.Il = llIIII(2003201114, -482962363);
      this.lI = llIIII(2003201113, -1788774609);
   }

   private boolean IIIIIl(class_2338 var1, class_2338 var2) {
      if (var1 != null && var2 != null && var1.method_10264() == var2.method_10264()) {
         int var3 = Math.abs(var1.method_10263() - var2.method_10263());
         int var4 = Math.abs(var1.method_10260() - var2.method_10260());
         return var3 + var4 == 1;
      } else {
         return false;
      }
   }

   private class_243 IIIIlI(class_2338 var1) {
      return this.lII(var1).method_1023((double)0.0F, (double)0.0625F, (double)0.0F);
   }

   private <undefinedtype> IIIIll(class_310 var1, Object var2, float var3, float var4) {
      class_239 var5 = var1.field_1765;
      if (var5 instanceof class_3965 var6) {
         if (var6.method_17783() == class_240.field_1332) {
            return this.lIIIIl(var1, var2, var6, var3, var4);
         }
      }

      return null;
   }

   private class_3965 IIIlII(class_2338 var1) {
      return new class_3965(this.lII(var1), class_2350.field_11036, var1.method_10074(), false);
   }

   private boolean IIIlIl(class_1799 var1) {
      return var1 != null && !var1.method_7960() && var1.method_31574(class_1802.field_8069);
   }

   private class_2338[] IIIllI(class_3965 var1, class_2350 var2) {
      class_2338 var3 = var1.method_17777();
      class_2350 var4 = var1.method_17780();
      if (var4 == class_2350.field_11036) {
         return new class_2338[]{var3.method_10084(), var3.method_10093(var2).method_10084(), var3.method_10093(var2.method_10153()).method_10084()};
      } else {
         return var4.method_10166().method_10179() ? new class_2338[]{var3.method_10093(var4), var3.method_10084(), var3.method_10093(var2).method_10084()} : new class_2338[]{var3.method_10084()};
      }
   }

   private int IIlIII(class_1661 var1, class_1792 var2) {
      for(int var3 = 0; var3 < llIIII(2003201112, -1018043525); ++var3) {
         if (var1.method_5438(var3).method_31574(var2)) {
            return var3;
         }
      }

      return -1;
   }

   private void IIlIIl(class_310 var1) {
      if (this.lIlIII(var1, this.lll) && this.lIIIll(var1, this.lll)) {
         if (this.IlIl(var1, this.IIllI)) {
            class_3965 var2 = this.IIIlII(this.lll);
            this.IIII(var1, null.III, null.l, this.lllII, this.llI, var2, () -> {
               class_1269 var2x = IllllIlI.lIlII(var1, class_1268.field_5808, var2);
               return var2x != null && var2x.method_23665();
            });
         }
      } else {
         this.IIlll(var1);
      }
   }

   private <undefinedtype> IIllII(class_1661 var1) {
      int var2 = this.IIlIII(var1, class_1802.field_8884);
      int var3 = this.IIlIII(var1, class_1802.field_8187);
      Record var10000;
      switch (((<undefinedtype>)this.llIl.III()).ordinal()) {
         case 0 -> var10000 = var2 < 0 ? null : new Record(var2, null.l) {
   private final int I;
   private final <undefinedtype> l;

   public int I() {
      return this.I;
   }

   public <undefinedtype> l() {
      return this.l;
   }

   private {
      this.I = var1;
      this.l = var2;
   }
};
         case 1 -> var10000 = var3 < 0 ? null : new Record(var3, null.I) {
   private final int I;
   private final <undefinedtype> l;

   public int I() {
      return this.I;
   }

   public <undefinedtype> l() {
      return this.l;
   }

   private {
      this.I = var1;
      this.l = var2;
   }
};
         case 2 -> var10000 = var2 >= 0 ? new Record(var2, null.l) {
   private final int I;
   private final <undefinedtype> l;

   public int I() {
      return this.I;
   }

   public <undefinedtype> l() {
      return this.l;
   }

   private {
      this.I = var1;
      this.l = var2;
   }
} : (var3 < 0 ? null : new Record(var3, null.I) {
   private final int I;
   private final <undefinedtype> l;

   public int I() {
      return this.I;
   }

   public <undefinedtype> l() {
      return this.l;
   }

   private {
      this.I = var1;
      this.l = var2;
   }
});
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   private boolean IIllIl(class_310 var1, Object var2, class_2338 var3, class_2338 var4, float var5, float var6) {
      return !Double.isNaN(this.lIIIlI(var1, var2, var3, var4, var5, var6));
   }

   private boolean IIlllI(class_2680 var1) {
      return var1 != null && (var1.method_27852(class_2246.field_10167) || var1.method_27852(class_2246.field_10425) || var1.method_27852(class_2246.field_10025) || var1.method_27852(class_2246.field_10546));
   }

   private boolean IlIIII(class_1661 var1, int var2, Object var3) {
      if (var1 != null && var2 >= 0 && var2 < llIIII(2003201119, -330981605) && var3 != null) {
         class_1799 var4 = var1.method_5438(var2);
         return var3 == null.l ? var4.method_31574(class_1802.field_8884) : var4.method_31574(class_1802.field_8187);
      } else {
         return false;
      }
   }

   private class_243 IlIIIl(class_2338 var1) {
      return class_243.method_24955(var1);
   }

   private boolean IlIIlI(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         return this.lII == class_1268.field_5810 ? this.IIIll(var1.field_1724.method_6079()) : this.lIllIl(var1.field_1724.method_31548(), this.II);
      } else {
         return false;
      }
   }

   public void lI() {
      this.lll(class_310.method_1551());
      this.IIl = false;
      this.llIll = false;
      this.lIIlIl();
      this.ll.IIIlIll();
   }

   private boolean IlIIll(class_3965 var1, class_243 var2, class_243 var3, double var4) {
      if (!this.IlllII(var1)) {
         return false;
      } else {
         double var6 = this.lIIl(var2, var3, var1.method_17784());
         return Double.isNaN(var6) || var6 < var4;
      }
   }

   private double IlIlIl(class_243 var1, class_243 var2, class_2338 var3, double var4, double var6, double var8) {
      double var10 = (double)var3.method_10263() - var4;
      double var12 = (double)var3.method_10263() + (double)1.0F + var4;
      double var14 = (double)var3.method_10264() + var6 - var4;
      double var16 = (double)var3.method_10264() + var8 + var4;
      double var18 = (double)var3.method_10260() - var4;
      double var20 = (double)var3.method_10260() + (double)1.0F + var4;
      double var22 = var2.field_1352 - var1.field_1352;
      double var24 = var2.field_1351 - var1.field_1351;
      double var26 = var2.field_1350 - var1.field_1350;
      double var28 = (double)0.0F;
      double var30 = (double)1.0F;
      double[] var32 = this.lIIIl(var1.field_1352, var22, var10, var12, var28, var30);
      if (var32 == null) {
         return Double.NaN;
      } else {
         var28 = var32[0];
         var30 = var32[1];
         var32 = this.lIIIl(var1.field_1351, var24, var14, var16, var28, var30);
         if (var32 == null) {
            return Double.NaN;
         } else {
            var28 = var32[0];
            var30 = var32[1];
            var32 = this.lIIIl(var1.field_1350, var26, var18, var20, var28, var30);
            return var32 == null ? Double.NaN : var32[0];
         }
      }
   }

   private void IlIllI() {
      this.IIl = false;
      if (!this.IIlllll() && this.IIIIIlI()) {
         this.IIIllIl(false);
      }

   }

   private boolean IlIlll(class_310 var1, class_2338 var2) {
      return var1 != null && var1.field_1687 != null && var2 != null && this.IIlllI(var1.field_1687.method_8320(var2)) && this.lIIIll(var1, var2);
   }

   private boolean IllIII(class_310 var1) {
      if (var1 != null && var1.field_1724 != null && this.lIlII != null && this.lll != null) {
         class_1799 var2 = this.IIIII(var1);
         if (!this.IIIll(var2)) {
            return false;
         } else {
            <undefinedtype> var3 = this.lIII(var2);
            float[] var4 = this.lIlII(var1, var3, this.lIlII, this.lll, this.lIIIl, this.IlIlI);
            if (var4 == null) {
               return false;
            } else {
               this.lIIIl = var4[0];
               this.IlIlI = var4[1];
               return this.IIllIl(var1, var3, this.lIlII, this.lll, this.lIIIl, this.IlIlI);
            }
         }
      } else {
         return false;
      }
   }

   private class_2338[] IllIIl(class_2338 var1, class_2350 var2) {
      class_2350 var3 = var2.method_10153();
      return new class_2338[]{var1.method_10093(var3), var1.method_10093(var3).method_10093(var3), var1.method_10093(var3.method_10170()), var1.method_10093(var3.method_10160())};
   }

   public void lIl() {
      this.IIl = false;
      this.llIll = false;
      this.lIIlIl();
      this.ll.IIlIIII();
   }

   private int IllIlI(llllIlIl var1) {
      return Math.max(0, (int)Math.ceil((double)this.IllllI(var1) / (double)50.0F));
   }

   private boolean IllIll(class_310 var1, class_243 var2, class_2338 var3) {
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null && var2 != null && var3 != null) {
         class_3965 var4 = var1.field_1687.method_17742(new class_3959(var1.field_1724.method_33571(), var2, class_3960.field_17559, class_242.field_1348, var1.field_1724));
         return var4 != null && var4.method_17777().equals(var3);
      } else {
         return false;
      }
   }

   private boolean IlllII(class_3965 var1) {
      return var1 != null && var1.method_17783() == class_240.field_1332;
   }

   public void IllI(class_310 var1) {
      if (!this.lllI(var1)) {
         this.lIIlIl();
         this.IlIllI();
      } else {
         if (this.IIIIl == null.lI) {
            if (this.IIlllll()) {
               boolean var2 = IllllIlI.IlIII(var1, this.IIIlIII());
               boolean var3 = var2 && !this.llIll;
               this.llIll = var2;
               if (!var2) {
                  this.IIl = false;
               }

               if (!var3 || this.IIl) {
                  return;
               }
            } else if (this.IIl) {
               return;
            }

            this.IIl = true;
            if (!this.lIlIll(var1)) {
               this.IlIllI();
               return;
            }
         }

         int var6 = 0;

         while(var6 < llIIII(2003201118, 249592731)) {
            long var7 = System.currentTimeMillis();
            if (var7 - this.lllIl > 1500L) {
               this.IIlll(var1);
               return;
            }

            if (!this.lIllII(var1) && var7 >= this.Illll) {
               <undefinedtype> var5 = this.IIIIl;
               switch (var5.ordinal()) {
                  case 0:
                  default:
                     break;
                  case 1:
                     this.IIlIIl(var1);
                     break;
                  case 2:
                     this.lIllI(var1);
                     break;
                  case 3:
                     this.lIlIIl(var1);
                     break;
                  case 4:
                     this.Illll(var1);
                     break;
                  case 5:
                     if (this.IIllI(var1)) {
                        this.lIIlIl();
                        this.IlIllI();
                     }
               }

               if (this.IIIIl != var5 && this.IIIIl != null.lI && this.IIIIIlI()) {
                  ++var6;
                  continue;
               }

               return;
            }

            return;
         }

      }
   }

   private long IllllI(llllIlIl var1) {
      double var2 = var1.IlII();
      double var4 = var1.IlI();
      return var2 >= var4 ? Math.max(0L, Math.round(var2)) : Math.max(0L, Math.round(ThreadLocalRandom.current().nextDouble(var2, var4)));
   }

   private class_3965 Illlll(class_2338 var1) {
      return new class_3965(this.IlIIIl(var1), class_2350.field_11036, var1.method_10074(), false);
   }

   private <undefinedtype> lIIIIl(class_310 var1, Object var2, class_3965 var3, float var4, float var5) {
      if (var3 != null && var3.method_17783() == class_240.field_1332) {
         class_2350 var6 = this.IllII(var4);

         for(class_2338 var10 : this.IIIllI(var3, var6)) {
            for(class_2338 var14 : this.IllIIl(var10, var6)) {
               <undefinedtype> var15 = this.lIIlI(var1, var2, var14, var10, var4, var5);
               if (var15 != null) {
                  return var15;
               }
            }
         }

         return null;
      } else {
         return null;
      }
   }

   private double lIIIlI(class_310 var1, Object var2, class_2338 var3, class_2338 var4, float var5, float var6) {
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null && var2 != null && var3 != null && var4 != null) {
         class_243 var7 = var1.field_1724.method_33571();
         class_243 var8 = this.lIlIlI(var5, var6).method_1021(var2.I()).method_1019(var1.field_1724.method_18798());
         boolean var9 = false;
         class_243 var10 = this.lIIII(var4);

         for(int var11 = 0; var11 < llIIII(2003201117, 1428786957); ++var11) {
            class_243 var12 = var7.method_1019(var8);
            class_3965 var13 = this.lIllll(var1, var7, var12);
            double var14 = this.IlIlIl(var7, var12, var3, 0.08, (double)0.0F, (double)1.0F);
            double var16 = this.IlIlIl(var7, var12, var4, 0.08, 0.22, 0.58);
            if (!Double.isNaN(var16)) {
               if (this.IlIIll(var13, var7, var12, var16)) {
                  return Double.NaN;
               }

               if (var9 || !Double.isNaN(var14) && !(var14 > var16)) {
                  return this.IlI(var7, var12, var10);
               }

               return Double.NaN;
            }

            if (!Double.isNaN(var14)) {
               var9 = true;
            }

            if (this.IlII(var13)) {
               return Double.NaN;
            }

            var7 = var12;
            var8 = var8.method_1021(var2.II()).method_1023((double)0.0F, var2.l(), (double)0.0F);
            if (var12.field_1351 < (double)var1.field_1687.method_31607() - (double)20.0F) {
               return Double.NaN;
            }
         }

         return Double.NaN;
      } else {
         return Double.NaN;
      }
   }

   private boolean lIIIll(class_310 var1, class_2338 var2) {
      return var1 != null && var1.field_1724 != null && var2 != null && var1.field_1724.method_33571().method_1025(this.ll(var2)) <= (double)20.25F;
   }

   private int lIIlII(class_1661 var1) {
      for(int var2 = 0; var2 < llIIII(2003201116, -818827208); ++var2) {
         if (this.IIIll(var1.method_5438(var2))) {
            return var2;
         }
      }

      return -1;
   }

   private void lIIlIl() {
      this.IIIIl = null.lI;
      this.lIlII = null;
      this.lll = null;
      this.lIl = -1;
      this.lIllI = -1;
      this.lIIll = null.l;
      this.IIllI = -1;
      this.llIII = -1;
      this.II = -1;
      this.lII = class_1268.field_5808;
      this.lllIl = 0L;
      this.Illll = 0L;
      this.IIIl = 0.0F;
      this.l = 0.0F;
      this.lllII = 0.0F;
      this.llI = 0.0F;
      this.Illl = 0.0F;
      this.IllI = 0.0F;
      this.lIIIl = 0.0F;
      this.IlIlI = 0.0F;
      this.IIll();
      this.IIIII = false;
      this.lI = llIIII(2003201107, -1269359505);
      this.IlII = null;
   }

   private long lIIllI(Object var1) {
      return 50L;
   }

   private void lIIlll(class_310 var1) {
      if (this.IlIII.III() == null.Il) {
         this.lIIII = null.l;
         this.Il = var1.field_1724.field_6012 + 2;
         boolean var7 = IlIlIl.III(var1, this.llIll(this.lll));
         boolean var8 = IlIlIl.IIIIlI(var1, llIIII(2003201106, 297948207), var7 ? var1.field_1724.method_36454() : this.Illl, var7 ? var1.field_1724.method_36455() : this.IllI, () -> this.lIlllI(var1));
         if (!var8) {
            this.IIll();
            this.Illll = System.currentTimeMillis();
         }

      } else {
         boolean var2 = IlIlIl.III(var1, this.llIll(this.lll));
         float var3 = var2 ? 0.0F : this.ll.IlIl(var1, this.lIIll(var1, this.Illl, this.IllI), ((Double)this.llIIl.III()).floatValue());
         long var4 = System.currentTimeMillis();
         if (var2 || var3 <= 0.5F || var4 - this.lllIl >= 1500L) {
            this.lIIII = null.l;
            this.Il = var1.field_1724.field_6012 + 2;
            boolean var6 = IlIlIl.IIIIlI(var1, llIIII(2003201105, 720728258), var2 ? var1.field_1724.method_36454() : this.Illl, var2 ? var1.field_1724.method_36455() : this.IllI, () -> this.lIlllI(var1));
            if (!var6) {
               this.IIll();
               this.Illll = System.currentTimeMillis();
            }
         }

      }
   }

   public boolean IIIIIIl() {
      return this.IIlllll();
   }

   private boolean lIlIII(class_310 var1, class_2338 var2) {
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null && var2 != null) {
         class_2680 var3 = var1.field_1687.method_8320(var2);
         class_2680 var4 = var1.field_1687.method_8320(var2.method_10074());
         return (var3.method_26215() || var3.method_45474()) && var4 != null && !var4.method_26215() && var4.method_26227().method_15769() && !var4.method_26220(var1.field_1687, var2.method_10074()).method_1110() && var1.field_1724.method_33571().method_1025(this.lII(var2)) <= (double)20.25F && this.IllIll(var1, this.IIIIlI(var2), var2.method_10074());
      } else {
         return false;
      }
   }

   private void lIlIIl(class_310 var1) {
      if (this.IIIIl(var1, this.lIlII) && this.IIlllI(var1.field_1687.method_8320(this.lll)) && this.lIIIll(var1, this.lll)) {
         if (this.IlIIII(var1.field_1724.method_31548(), this.lIllI, this.lIIll) && this.IlIl(var1, this.lIllI)) {
            class_3965 var2 = this.Illlll(this.lIlII);
            this.IIII(var1, null.I, null.Il, this.IIIl, this.l, var2, () -> {
               class_1269 var2x = IllllIlI.lIlII(var1, class_1268.field_5808, var2);
               return var2x != null && var2x.method_23665();
            });
         }
      } else {
         this.IIlll(var1);
      }
   }

   private class_243 lIlIlI(float var1, float var2) {
      double var3 = Math.toRadians((double)var1);
      double var5 = Math.toRadians((double)var2);
      double var7 = Math.cos(var5);
      return (new class_243(-Math.sin(var3) * var7, -Math.sin(var5), Math.cos(var3) * var7)).method_1029();
   }

   private boolean lIlIll(class_310 var1) {
      if (var1.field_1755 != null) {
         return false;
      } else {
         class_1661 var2 = var1.field_1724.method_31548();
         <undefinedtype> var3 = this.IIllII(var2);
         int var4 = this.IllIl(var2);
         int var5 = this.IIlIII(var2, class_1802.field_8069);
         <undefinedtype> var6 = this.lIlIl(var1);
         if (var3 != null && var4 >= 0 && var5 >= 0 && var6 != null) {
            <undefinedtype> var7 = this.llI(var1, var6.l());
            if (var7 != null && this.llllI(var1, var7.l(), var7.II())) {
               float[] var8 = IlIlIl.llIlI(var1, this.IlIIIl(var7.l()));
               float[] var9 = IlIlIl.llIlI(var1, this.lII(var7.II()));
               float[] var10 = IlIlIl.llIlI(var1, this.ll(var7.II()));
               if (var8 != null && var9 != null && var10 != null) {
                  this.lIl = IllllIlI.lIIlI(var2);
                  this.lIllI = var3.I();
                  this.lIIll = var3.l();
                  this.IIllI = var4;
                  this.llIII = var5;
                  this.II = var6.II();
                  this.lII = var6.I();
                  this.lIlII = var7.l();
                  this.lll = var7.II();
                  this.IIIl = var8[0];
                  this.l = var8[1];
                  this.lllII = var9[0];
                  this.llI = var9[1];
                  this.Illl = var10[0];
                  this.IllI = var10[1];
                  this.lIIIl = var7.I();
                  this.IlIlI = var7.Il();
                  this.IIIIl = null.III;
                  this.lllIl = System.currentTimeMillis();
                  this.Illll = this.lllIl + Math.max(0L, this.lIIllI(null.III) - 50L);
                  return true;
               } else {
                  return false;
               }
            } else {
               return false;
            }
         } else {
            return false;
         }
      }
   }

   private boolean lIllII(class_310 var1) {
      if (this.lIIII != null.lI) {
         if (var1.field_1724.field_6012 <= this.Il) {
            return true;
         }

         this.IIll();
         this.Illll = System.currentTimeMillis();
      }

      if (this.IIIII) {
         if (var1.field_1724.field_6012 <= this.lI) {
            return true;
         }

         this.IIIII = false;
         this.lI = llIIII(2003201104, 133795549);
         this.Illll = System.currentTimeMillis();
      }

      return false;
   }

   private boolean lIllIl(class_1661 var1, int var2) {
      return var1 != null && var2 >= 0 && var2 < llIIII(2003201111, 624317338) && this.IIIll(var1.method_5438(var2));
   }

   private boolean lIlllI(class_310 var1) {
      int var2 = IllllIlI.IIlIl(var1);
      if (this.IIIIl == null.l && this.IlIlll(var1, this.lll) && var2 == this.llIII && this.IIIlIl(var1.field_1724.method_31548().method_5438(this.llIII))) {
         this.IIll();
         this.lIlll(var1);
         boolean var3 = this.IIlII(() -> {
            class_1269 var2 = IllllIlI.lIlII(var1, class_1268.field_5808, this.llIll(this.lll));
            return var2 != null && var2.method_23665();
         });
         if (var3) {
            this.llIIl(null.I, var1);
         } else {
            this.llIII();
         }

         return var3;
      } else {
         this.llIII();
         return false;
      }
   }

   private class_3965 lIllll(class_310 var1, class_243 var2, class_243 var3) {
      return var1 != null && var1.field_1687 != null ? var1.field_1687.method_17742(new class_3959(var2, var3, class_3960.field_17558, class_242.field_1348, var1.field_1724)) : null;
   }

   private static int llIIII(int var0, int var1) {
      return llllI[var0 ^ 2003201099] ^ var1 ^ var0;
   }

   private static String llIIIl(int var0, char var1, char var2) {
      int var3 = var1 ^ '릖';
      char[] var4 = lllll[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])IIIIII[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         IIIIII[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 1737;
      int var9 = 0;

      do {
         int var10 = var4[var9] ^ '빰';
         var10 -= 31916;
         var10 -= 64348;
         var10 += 25766;
         var10 -= 9716;
         var10 -= 53056;
         var10 += 17408;
         var10 -= 17190;
         var10 ^= 19188;
         var4[var9] = (char)(var10 ^ var8 ^ var2 ^ var0 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
