package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1802;
import net.minecraft.class_310;

@Environment(EnvType.CLIENT)
public final class IIIllIIll extends IIIIIIIlI {
   private static final String[] I;
   private static final Object[] l;

   public String l() {
      return lIlIII.Il(ll(1111016227, 1073237140));
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var1.field_1690 != null && var1.field_1690.field_1904 != null && var1.field_1755 == null && var1.method_1569()) {
         boolean var2 = IllllIlI.IIIll(var1, var1.field_1690.field_1904) || var1.field_1690.field_1904.method_1434();
         if (var2) {
            class_1268 var3 = this.II(var1);
            if (var3 != null) {
               IllllIlI.IllIIl(var1, var3);
            }

         }
      }
   }

   public IIIllIIll() {
      super((Object)lIlIII.l(ll(1111016226, -1904590649)), lIllII.I, (Object)lIlIII.l(ll(1111016225, 2008551216)));
   }

   private class_1268 II(class_310 var1) {
      if (var1.field_1724.method_6047().method_31574(class_1802.field_8399)) {
         return class_1268.field_5808;
      } else {
         return var1.field_1724.method_6079().method_31574(class_1802.field_8399) ? class_1268.field_5810 : null;
      }
   }

   static {
      short var0 = 27751;
      String var1 = "ᦝ\u19adᥰ᧓\u1977ᦣᥭ᧙ᤚᦼ\u192c᧭᧚᧷\u19ceᤢ\u196e᥅᧦᧱᧱ᥩᤎᦿᦏᦹᤗ᧲ᤫ᧘᥎᧕ᦃᦶᥥ᧥᥋᧥ᥳ᧠\u192cᦴᤂ᧹ᦩ᧸ᧄ\u192cᥩ\u1977᧣᧨ᦆ\u192cᥬᦌᦷᦡᤗ᧗ᤋ᧗ᥔ᧓ᦃ᧒\u1978᧮\u1975ᧄᥭ᧻ᤓᦼᤫ᧶᧙᧧\u19caᤢᥩ᥅᧐᧵᧱ᥩᥪᦌᦉᧃᤔ᧩\u192d\u19db\u197f᧒ᦈ᧗ᥡ᧰᥋᧺ᥰ᧭ᤸᦎᤳ᧷᧳᧻᧔\u192eᥩᤀ᧫\u19dc쑆쐏쒎쐉쒫쐹쒭쐲쓆쑯쓯쐪쐈쐸쐙쓮쒲쓔쐌쐽쑷쒢쓄쐌㶀㷌㵐㷈㵮㷍㵰㷾㴉㶌㴢㷥㷁㷓㷽㴭㵹㵡㷼㷵㶵㵣㵒㶱㶒㷜㴒㷷㴴㷨㵗㷡㶚㶞㵁㷹㵗㷙㴰㷱㴥㶐㴮㷻㷬㷱㷬㴯㵴㵩㷦㷅㶄㵎㵺㶲㶬㶅㴫㷦㴉㶻㵳㷦㶟㶝㵄㷍㵩㶽㵳㷀㴊㶈㴘㷤";
      char[] var2 = "氓汿氫".toCharArray();
      String[] var3 = new String[var2.length];
      byte var7 = -1;

      while(true) {
         int var4 = 0;
         int var5 = 0;
         int var6 = 0;
         if (var7 == 0) {
            I = var3;
            l = new Object[var3.length];
            return;
         }

         do {
            var6 = var2[var4] ^ var0;
            var3[var4] = var1.substring(var5, var5 + var6);
            var5 += var6;
            ++var4;
         } while(var4 < var2.length);

         var7 = 0;
      }
   }

   private static String ll(int var0, int var1) {
      int var3 = var0 ^ 1111016227;
      char[] var4 = I[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])l[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         l[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -47166123;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 100;
               break;
            case 1:
               var9 = 108;
               break;
            case 2:
               var9 = 131;
               break;
            case 3:
               var9 = 60;
               break;
            case 4:
               var9 = 150;
               break;
            case 5:
               var9 = 25;
               break;
            case 6:
               var9 = 138;
               break;
            case 7:
               var9 = 51;
               break;
            case 8:
               var9 = 201;
               break;
            case 9:
               var9 = 79;
               break;
            case 10:
               var9 = 206;
               break;
            case 11:
               var9 = 37;
               break;
            case 12:
               var9 = 19;
               break;
            case 13:
               var9 = 54;
               break;
            case 14:
               var9 = 42;
               break;
            case 15:
               var9 = 243;
               break;
            case 16:
               var9 = 164;
               break;
            case 17:
               var9 = 186;
               break;
            case 18:
               var9 = 33;
               break;
            case 19:
               var9 = 50;
               break;
            case 20:
               var9 = 73;
               break;
            case 21:
               var9 = 146;
               break;
            case 22:
               var9 = 174;
               break;
            case 23:
               var9 = 102;
               break;
            case 24:
               var9 = 85;
               break;
            case 25:
               var9 = 124;
               break;
            case 26:
               var9 = 235;
               break;
            case 27:
               var9 = 56;
               break;
            case 28:
               var9 = 247;
               break;
            case 29:
               var9 = 22;
               break;
            case 30:
               var9 = 147;
               break;
            case 31:
               var9 = 61;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
