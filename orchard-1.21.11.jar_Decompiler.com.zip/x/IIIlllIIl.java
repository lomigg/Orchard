package x;

import com.google.gson.JsonObject;
import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_12125;
import net.minecraft.class_1268;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_6880;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

@Environment(EnvType.CLIENT)
public final class IIIlllIIl extends IIIIIIIlI {
   private boolean I;
   private boolean l;
   private boolean II;
   private final lIIIIl Il = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIlIl(922516341, '㲜', (short)15114)), false));
   private int lI;
   private static final int ll = 1;
   private final llllIlIl III = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(IIlIl(1594312354, '㲝', (short)'퓺')), (double)150.0F, (double)300.0F, (double)0.0F, (double)300.0F, (double)5.0F)).Ill(lIlIII.l(IIlIl(63198247, '㲞', (short)9677))));
   private boolean IIl;
   private static final class_1792[] IlI;
   private boolean Ill;
   private int lII;
   private boolean lIl;
   private int llI = -1;
   private int lll;
   private static final int IIII = 9;
   private int IIIl;
   private final lIIIIl IIlI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIlIl(-1996863172, '㲟', (short)20376)), true));
   private static final <undefinedtype> IIll;
   private static final int[] IlII;
   private static final String[] IlIl;
   private static final Object[] IllI;

   public boolean IIlI(class_310 var1) {
      return this.lllI();
   }

   private void IlI() {
      if (!this.IIlllll() && this.IIIIIlI()) {
         this.IIIllIl(false);
      }

   }

   private int lII(class_1799 var1) {
      if (var1 != null && !var1.method_7960()) {
         class_9304 var2 = (class_9304)var1.method_58695(class_9334.field_49633, class_9304.field_49385);

         for(class_6880 var4 : var2.method_57534()) {
            String var5 = (String)var4.method_40230().map((var0) -> var0.method_29177().method_12832()).orElse("");
            if (lIlIII.Il(IIlIl(-151442435, '㲘', (short)15582)).equals(var5)) {
               return var2.method_57536(var4);
            }
         }

         return 0;
      } else {
         return 0;
      }
   }

   private void llI(class_310 var1) {
      IllllIlI.IlII(var1, this, null.II);
      this.IlIl(true);
      this.IlI();
   }

   private boolean lll() {
      lIllIIl var1 = lIllIIl.Il();
      if (var1 != null && var1.IIl() != null) {
         for(IIIIIIIlI var3 : var1.IIl().IIIIlII()) {
            if (var3 instanceof IlIIll) {
               IlIIll var4 = (IlIIll)var3;
               if (var4.IIIIIlI() && var4.llI()) {
                  return true;
               }
            }
         }
      }

      return false;
   }

   private boolean IIII(class_310 var1) {
      return this.IIlllll() && var1 != null ? IllllIlI.IlIII(var1, this.IIIlIII()) : false;
   }

   public boolean IIIIIIl() {
      return this.IIlllll();
   }

   static {
      short var6 = 32102;
      String var7 = "쁋샄쁽삜쁈삗쁲쀸翲砡翠翹翥砖翳硶砟翦硓硴翢硙秕秕深垺湴湴渀湑渗渮渮渡渝測渪埕渃垍䚵䘩䘈䘁䘿䙮䙔䘻䙔䘤䘻䙕䘧䘌䙀䘸䘈䚶䙖䙃䘼䙜仴䙗䘻仚仚䙕䙔䘤䘁䙪仑䙮䚵䙖䘎䘁仛䘤䘠䚶䙟䙀䘽䘢䙃䘌䘻䘸䘌䘥䘎䙜䘌䘹䘠䘈䙕䘋件䙀䘎䚅䘢仵䘹䙕䘠䘸䘢䘸䙔䘱䚙䘊䘤仵䘥䚭洖浒浇洪洀泳海洨洭洝洖浘\uaaceꬪ\uaafe꭛ꫦꭓꫣ듗䂘䀧䂉䂫❦✥⟓➕❎⟷❁❻⟚⟵✋➨⟴✊⟆❂᫈᭙\u1afb᭴\u1af3ᬡ᭙᭙᭘᭛ᫌᭆ᭑ᭉ⒈᭴鼋齤齮齔鼳龚鼈齖龷龴鼳龅龚龒齧龛";
      char[] var8 = "絮絶絶紶絪絮絢絶絶絶".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IlIl = var9;
            IllI = new Object[var9.length];
            int var2 = -1913571204;
            byte[] var0 = "êI=\u009dÕH\fEh`\u0007ë\u0097\u0096 +\u0018ÛqË\u009eLâ\u007f\nÆ£\u0016\u0000\u0013]5".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IlII = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IlII[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            IIll = lIlIII.l(IIlIl(-1559022184, '㲙', (short)7584));
            class_1792[] var10000 = new class_1792[IIlII(-1072885334, -1481305012)];
            var10000[0] = class_1802.field_63390;
            var10000[1] = class_1802.field_63389;
            var10000[2] = class_1802.field_63387;
            var10000[3] = class_1802.field_63388;
            var10000[4] = class_1802.field_63386;
            var10000[5] = class_1802.field_63385;
            var10000[IIlII(-1072885333, -1733024364)] = class_1802.field_63384;
            IlI = var10000;
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public void IllI(class_310 var1) {
      if (!this.IIIII(var1)) {
         this.llI(var1);
      } else if (!lIlIllll.lIIl(var1) && !this.lll()) {
         if (this.Ill) {
            if (var1.field_1724.field_6012 - this.IIIl > IIlII(-1072885336, 630992407)) {
               this.llI(var1);
            } else {
               if (var1.field_1724.field_6012 >= this.lII) {
                  this.Illl(var1);
               }

            }
         } else if (this.I) {
            if (var1.field_1724.field_6012 >= this.lll) {
               this.IIll(var1);
            }

         } else if (!this.IIlllll()) {
            this.lIl = true;
            if (!this.IIl && !this.I && !this.Ill) {
               this.IIl = true;
               if (!this.llII(var1)) {
                  this.IlI();
               }

            }
         } else {
            boolean var2 = this.IIII(var1);
            boolean var3 = var2 && !this.II;
            this.II = var2;
            if ((Boolean)this.Il.III()) {
               if (!var2) {
                  this.lIl = true;
               } else if (var1.field_1724.field_6012 >= this.lI) {
                  if (this.lIl && !this.I && !this.Ill) {
                     if (this.llII(var1)) {
                        this.lIl = false;
                     }

                  }
               }
            } else {
               if (!var2) {
                  this.lIl = true;
               }

               if (var3 && !this.I && !this.Ill) {
                  if (this.llII(var1)) {
                     this.lIl = false;
                  }

               }
            }
         }
      } else {
         this.llI(var1);
      }
   }

   private void IIll(class_310 var1) {
      boolean var2 = (Boolean)this.Il.III();
      <undefinedtype> var3 = !var2 && !(Boolean)this.IIlI.III() ? null.Il : null.II;
      IllllIlI.IlII(var1, this, var3);
      this.IlIl(false);
      this.lIl = true;
      if (!this.IIlllll() && this.IIIIIlI()) {
         this.IIIllIl(false);
      }

   }

   private int IlII(llllIlIl var1) {
      return Math.max(1, (int)Math.ceil((double)this.lIII(var1) / (double)50.0F));
   }

   private void IlIl(boolean var1) {
      this.I = false;
      this.Ill = false;
      this.lII = -1;
      this.lll = -1;
      this.IIIl = -1;
      this.llI = -1;
      if (var1) {
         this.lI = -1;
         this.l = false;
      }

   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (!this.IIIII(var1)) {
         IllllIlI.IlII(var1, this, null.II);
         this.IlIl(true);
         this.IlI();
      }

   }

   public IIIlllIIl() {
      super((Object)lIlIII.l(IIlIl(283797949, '㲚', (short)25625)), lIllII.I, (Object)lIlIII.l(IIlIl(-489000586, '㲛', (short)'컉')));
      this.IIlI.lIII(() -> !(Boolean)this.Il.III());
   }

   private void Illl(class_310 var1) {
      if (var1 != null && var1.field_1724 != null && this.llI >= 0 && this.llI < IIlII(-1072885335, -630552073) && this.lII(var1.field_1724.method_31548().method_5438(this.llI)) > 0) {
         if (!IllllIlI.llI(var1, IllllIlI.llIII(var1))) {
            class_1799 var2 = var1.field_1724.method_31548().method_5438(this.llI);
            if (var2 != null && !var1.field_1724.method_75202(var2, 5)) {
               boolean var4 = IllllIlI.lIlIl();

               boolean var3;
               try {
                  var3 = IllllIlI.llIll(var1, this, this.llI, () -> {
                     class_1799 var2 = var1.field_1724.method_31548().method_5438(this.llI);
                     class_12125 var3 = var2 == null ? null : (class_12125)var2.method_58694(class_9334.field_63631);
                     if (var3 != null && this.lII(var2) > 0) {
                        IllllIlI.IlIIIll(var1);
                        var1.field_1761.method_75407(var3);
                        var1.field_1724.method_6104(class_1268.field_5808);
                        return true;
                     } else {
                        return false;
                     }
                  });
               } finally {
                  if (var4) {
                     IllllIlI.IIlllI();
                  }

               }

               if (!var3) {
                  this.llI(var1);
               } else {
                  this.Ill = false;
                  this.I = true;
                  this.lll = var1.field_1724.field_6012 + 1;
                  this.IIll(var1);
                  if ((Boolean)this.Il.III()) {
                     this.lI = var1.field_1724.field_6012 + this.IlII(this.III);
                     this.l = true;
                  }

               }
            }
         }
      } else {
         this.llI(var1);
      }
   }

   private long lIII(llllIlIl var1) {
      double var2 = var1.IlII();
      double var4 = var1.IlI();
      return var2 == var4 ? Math.max(0L, Math.round(var2)) : Math.max(0L, Math.round(ThreadLocalRandom.current().nextDouble(var2, var4)));
   }

   public void IIl(JsonObject var1) {
      super.IIl(var1);
      this.lllIll(var1, IIll.lIlI());
      this.llIlIl(var1, lIlIII.Il(IIlIl(538406319, '㲐', (short)30632)), new llllIlIl[]{this.III});
      this.llIlIl(var1, lIlIII.Il(IIlIl(-1675689406, '㲑', (short)20325)), new llllIlIl[]{this.III});
   }

   public void lI() {
      class_310 var1 = class_310.method_1551();
      IllllIlI.IlII(var1, this, null.II);
      this.lIl = true;
      this.IIl = false;
      this.II = false;
      this.IlIl(true);
   }

   public void lllIl(class_310 var1) {
      if (this.I) {
         if (!this.IIIII(var1)) {
            this.llI(var1);
         } else if (lIlIllll.lIIl(var1)) {
            this.llI(var1);
         } else if (var1.field_1724.field_6012 >= this.lll) {
            this.IIll(var1);
         }
      }
   }

   public void lIl() {
      this.lIl = true;
      this.IIl = false;
      this.II = false;
      this.IlIl(true);
   }

   private boolean llII(class_310 var1) {
      class_1661 var2 = var1.field_1724.method_31548();
      int var3 = this.IIIIl(var2);
      if (var3 < 0) {
         return false;
      } else {
         this.llI = var3;
         if (lIlIllll.lIIl(var1)) {
            this.IlIl(false);
            return false;
         } else {
            this.Ill = true;
            this.I = false;
            this.IIIl = var1.field_1724.field_6012;
            this.lII = var1.field_1724.field_6012;
            this.Illl(var1);
            return true;
         }
      }
   }

   public boolean lllI() {
      return this.Ill || this.I;
   }

   public int IlIlI() {
      return IIlII(-1072885330, 1428640701);
   }

   private boolean IIIII(class_310 var1) {
      return var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var1.field_1690 != null && var1.field_1755 == null && var1.field_1724.method_5805();
   }

   private int IIIIl(class_1661 var1) {
      if (var1 == null) {
         return -1;
      } else {
         int var2 = IllllIlI.lIIlI(var1);
         int var3 = -1;
         int var4 = IIlII(-1072885329, 1404095404);

         for(class_1792 var8 : IlI) {
            for(int var9 = 0; var9 < IIlII(-1072885332, 1195018959); ++var9) {
               class_1799 var10 = var1.method_5438(var9);
               if (var10 != null && var10.method_31574(var8)) {
                  int var11 = this.lII(var10);
                  if (var11 > 0) {
                     int var12 = var11 * IIlII(-1072885331, 1307538560) + (var9 == var2 ? 1 : 0);
                     if (var12 > var4) {
                        var4 = var12;
                        var3 = var9;
                     }
                  }
               }
            }
         }

         return var3;
      }
   }

   private static int IIlII(int var0, int var1) {
      return IlII[var0 ^ -1072885334] ^ var1 ^ var0;
   }

   private static String IIlIl(int var0, char var1, short var2) {
      int var3 = var1 ^ 15512;
      char[] var4 = IlIl[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])IllI[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         IllI[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 16969;
      int var9 = 0;

      do {
         int var10 = var4[var9] ^ 'ﯩ';
         var10 -= 45369;
         var10 ^= 7235;
         var10 ^= 10315;
         var10 += 19109;
         var10 -= 52112;
         var10 ^= 11051;
         var10 += 52441;
         var4[var9] = (char)(var10 ^ var8 ^ var2 ^ var0 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
