package x;

import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3532;

@Environment(EnvType.CLIENT)
final class IIlIlllIl {
   private final Map<IIIIlllIl, class_243> I = new IlII(this, Ill(-464688043, 1442403885), 0.75F, true);
   private static final int[] l;

   private static double I(double var0, double var2, double var4) {
      double var6 = var4 - var2;
      return var6 <= 1.0E-6 ? (double)0.5F : class_3532.method_15350((var0 - var2) / var6, (double)0.0F, (double)1.0F);
   }

   private static class_243 l(class_238 var0, class_243 var1) {
      return new class_243(class_3532.method_16436(var1.field_1352, var0.field_1323, var0.field_1320), class_3532.method_16436(var1.field_1351, var0.field_1322, var0.field_1325), class_3532.method_16436(var1.field_1350, var0.field_1321, var0.field_1324));
   }

   private static <undefinedtype> II(Object var0) {
      return var0 == null ? null.I : var0;
   }

   class_243 Il(int var1, Object var2, class_238 var3) {
      if (var3 == null) {
         return null;
      } else {
         class_243 var4 = (class_243)this.I.get(new IIIIlllIl(var1, II(var2)));
         return var4 == null ? null : l(var3, var4);
      }
   }

   private static class_243 lI(class_238 var0, class_243 var1) {
      return new class_243(I(var1.field_1352, var0.field_1323, var0.field_1320), I(var1.field_1351, var0.field_1322, var0.field_1325), I(var1.field_1350, var0.field_1321, var0.field_1324));
   }

   void ll(int var1, Object var2, class_238 var3, class_243 var4) {
      if (var3 != null && IlIlIll.lIlIll(var4)) {
         this.I.put(new IIIIlllIl(var1, II(var2)), lI(var3, var4));
      }
   }

   int III() {
      return this.I.size();
   }

   void IIl(int var1, Object var2) {
      this.I.remove(new IIIIlllIl(var1, II(var2)));
   }

   void IlI() {
      this.I.clear();
   }

   private static int Ill(int var0, int var1) {
      return l[var0 ^ -464688043] ^ var1 ^ var0;
   }

   static {
      int var2 = 265648815;
      byte[] var0 = "¾a@÷".getBytes("ISO-8859-1");
      int var1 = var0.length / 4;
      l = new int[var1];
      int var3 = 0;
      int var4 = 0;

      do {
         int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
         var5 ^= var2;
         l[var4] = var5;
         var3 += 4;
         ++var4;
      } while(var4 < var1);

   }
}
