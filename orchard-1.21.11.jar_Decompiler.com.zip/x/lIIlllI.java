package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class lIIlllI extends IIIIIIIlI {
   private static volatile lIIlllI I;
   private static final String[] l;
   private static final Object[] II;

   static lIIlllI ll() {
      lIIlllI var0 = I;
      if (var0 == null) {
         synchronized(lIIlllI.class) {
            var0 = I;
            if (var0 == null) {
               var0 = new lIIlllI();
               I = var0;
            }
         }
      }

      return var0;
   }

   private lIIlllI() {
      super((Object)lIlIII.l(IlI(-1316513202, 85153014)), lIllII.lI, (Object)lIlIII.l(IlI(-1316513201, -2083631860)));
   }

   static {
      short var0 = 19040;
      String var1 = "糉籨籝糺粄粔簹簫类糜簝粴粴簤籩簒塚犯\ufaf7﨧度喙瀞\ufaf6直暴變縉頻醙\ufae1磌瞧甆暴直頻磌戴勇難杖隷﨩";
      char[] var2 = "\u0010\u001c".toCharArray();
      String[] var3 = new String[var2.length];
      byte var7 = -1;

      while(true) {
         int var4 = 0;
         int var5 = 0;
         char var6 = '\u0000';
         if (var7 == 0) {
            l = var3;
            II = new Object[var3.length];
            return;
         }

         do {
            var6 = var2[var4];
            char[] var8 = var1.substring(var5, var5 + var6).toCharArray();
            int var9 = 0;

            do {
               byte var10000;
               switch (var9 % 5) {
                  case 0:
                  default:
                     var10000 = 104;
                     break;
                  case 1:
                     var10000 = 118;
                     break;
                  case 2:
                     var10000 = 92;
                     break;
                  case 3:
                     var10000 = 112;
                     break;
                  case 4:
                     var10000 = 110;
               }

               byte var10 = var10000;
               var8[var9] = (char)(var8[var9] ^ var10 ^ var0);
               ++var9;
            } while(var9 < var8.length);

            var3[var4] = (new String(var8)).intern();
            var5 += var6;
            ++var4;
         } while(var4 < var2.length);

         var7 = 0;
      }
   }

   private static String IlI(int var0, int var1) {
      int var3 = var0 ^ -1316513202;
      char[] var4 = l[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])II[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         II[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -1050762395;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 232;
               break;
            case 1:
               var9 = 120;
               break;
            case 2:
               var9 = 12;
               break;
            case 3:
               var9 = 236;
               break;
            case 4:
               var9 = 229;
               break;
            case 5:
               var9 = 132;
               break;
            case 6:
               var9 = 53;
               break;
            case 7:
               var9 = 24;
               break;
            case 8:
               var9 = 111;
               break;
            case 9:
               var9 = 207;
               break;
            case 10:
               var9 = 48;
               break;
            case 11:
               var9 = 173;
               break;
            case 12:
               var9 = 147;
               break;
            case 13:
               var9 = 15;
               break;
            case 14:
               var9 = 6;
               break;
            case 15:
               var9 = 123;
               break;
            case 16:
               var9 = 78;
               break;
            case 17:
               var9 = 82;
               break;
            case 18:
               var9 = 230;
               break;
            case 19:
               var9 = 66;
               break;
            case 20:
               var9 = 143;
               break;
            case 21:
               var9 = 76;
               break;
            case 22:
               var9 = 3;
               break;
            case 23:
               var9 = 190;
               break;
            case 24:
               var9 = 181;
               break;
            case 25:
               var9 = 87;
               break;
            case 26:
               var9 = 211;
               break;
            case 27:
               var9 = 216;
               break;
            case 28:
               var9 = 156;
               break;
            case 29:
               var9 = 241;
               break;
            case 30:
               var9 = 108;
               break;
            case 31:
               var9 = 173;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
