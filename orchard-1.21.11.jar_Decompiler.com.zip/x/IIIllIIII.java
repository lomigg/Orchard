package x;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import java.math.BigDecimal;
import java.math.RoundingMode;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class IIIllIIII extends llllllI<Double> {
   private <undefinedtype> I;
   private final double l;
   private double II;
   private double Il;
   private static final int[] lII;

   public double I() {
      return this.l;
   }

   private double l(double var1) {
      if (this.l <= (double)0.0F) {
         return var1;
      } else {
         long var3 = Math.round(var1 / this.l);
         return BigDecimal.valueOf(this.l).multiply(BigDecimal.valueOf(var3)).setScale(this.llI(), RoundingMode.HALF_UP).doubleValue();
      }
   }

   public void II(JsonElement var1) {
      if (var1 != null && var1.isJsonPrimitive()) {
         this.III(var1.getAsDouble());
      }

   }

   public double ll() {
      return this.II;
   }

   public void III(Double var1) {
      double var2 = Math.max(this.Il, Math.min(this.II, var1));
      super.Il(this.l(var2));
   }

   public IIIllIIII IIl(String var1) {
      return this.IIIl(var1);
   }

   public IIIllIIII IlI(double var1) {
      this.II = var1;
      this.III((Double)this.III());
      return this;
   }

   public IIIllIIII Ill(double var1) {
      this.Il = var1;
      this.III((Double)this.III());
      return this;
   }

   public String lII() {
      return this.I.lIlI();
   }

   public double lIl() {
      return this.Il;
   }

   public IIIllIIII(Object var1, double var2, double var4, double var6, double var8) {
      super((Object)var1, var2);
      this.I = lIlIII.III("");
      this.Il = var4;
      this.II = var6;
      this.l = var8;
   }

   public JsonElement lI() {
      return new JsonPrimitive((Number)this.III());
   }

   public IIIllIIII(String var1, double var2, double var4, double var6, double var8) {
      this((Object)var1, var2, var4, var6, var8);
   }

   private int llI() {
      double var1 = Math.abs(this.l);

      int var3;
      for(var3 = 0; var3 < IIlI(1866193749, -622534333) && Math.abs(var1 - Math.rint(var1)) > 1.0E-6; ++var3) {
         var1 *= (double)10.0F;
      }

      return var3;
   }

   public <undefinedtype> lll() {
      return this.I;
   }

   public IIIllIIII IIII(double var1, double var3) {
      this.Il = var1;
      this.II = var3;
      this.III((Double)this.III());
      return this;
   }

   public IIIllIIII IIIl(Object var1) {
      <undefinedtype> var10001;
      if (var1 instanceof <undefinedtype> var2) {
         var10001 = var2;
      } else {
         var10001 = lIlIII.III(var1 == null ? "" : var1.toString());
      }

      this.I = var10001;
      return this;
   }

   private static int IIlI(int var0, int var1) {
      return lII[var0 ^ 1866193749] ^ var1 ^ var0;
   }

   static {
      int var2 = -301955892;
      byte[] var0 = "[ß¾Ü".getBytes("ISO-8859-1");
      int var1 = var0.length / 4;
      lII = new int[var1];
      int var3 = 0;
      int var4 = 0;

      do {
         int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
         var5 ^= var2;
         lII[var4] = var5;
         var3 += 4;
         ++var4;
      } while(var4 < var1);

   }
}
