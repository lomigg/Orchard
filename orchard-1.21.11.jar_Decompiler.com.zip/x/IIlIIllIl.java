package x;

import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class IIlIIllIl {
   private static final double I = 0.0042;
   private static final double l = 0.0027;
   private static final double II = 1.6E-4;
   private static final int[] Il;

   public static Color I(Color var0, int var1) {
      Color var2 = var0 == null ? Color.WHITE : var0;
      return new Color(var2.getRed(), var2.getGreen(), var2.getBlue(), l(var1));
   }

   private static int l(int var0) {
      return Math.max(0, Math.min(lll(1809772500, -1006337143), var0));
   }

   public static Color II(Color var0, Color var1, double var2) {
      Color var4 = var0 == null ? Color.WHITE : var0;
      Color var5 = var1 == null ? Color.WHITE : var1;
      double var6 = Math.max((double)0.0F, Math.min((double)1.0F, var2));
      return new Color(l((int)Math.round((double)var4.getRed() + (double)(var5.getRed() - var4.getRed()) * var6)), l((int)Math.round((double)var4.getGreen() + (double)(var5.getGreen() - var4.getGreen()) * var6)), l((int)Math.round((double)var4.getBlue() + (double)(var5.getBlue() - var4.getBlue()) * var6)), l((int)Math.round((double)var4.getAlpha() + (double)(var5.getAlpha() - var4.getAlpha()) * var6)));
   }

   public static Color Il(Color var0, double var1) {
      Color var3 = var0 == null ? Color.WHITE : var0;
      return new Color(l((int)Math.round((double)var3.getRed() * var1)), l((int)Math.round((double)var3.getGreen() * var1)), l((int)Math.round((double)var3.getBlue() * var1)), var3.getAlpha());
   }

   private static Color lI(double var0, int var2) {
      float var3 = (float)(((double)System.currentTimeMillis() * 1.6E-4 + var0 * 0.173) % (double)1.0F);
      return llI(var3, 0.78F, 1.0F, var2);
   }

   public static Color ll(Color var0, Object var1, double var2, int var4) {
      Color var5 = var0 == null ? new Color(lll(1809772501, 769650745), lll(1809772502, -689684321), lll(1809772503, -76172312), var4) : I(var0, var4);
      Color var10000;
      switch ((var1 == null ? null.III : var1).ordinal()) {
         case 0 -> var10000 = var5;
         case 1 -> var10000 = lI(var2, var4);
         case 2 -> var10000 = lII(var5, var2, var4);
         case 3 -> var10000 = IIl(var5, var2, var4);
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   private IIlIIllIl() {
   }

   public static double III(double var0) {
      return (double)0.5F + (double)0.5F * Math.sin((double)System.currentTimeMillis() * 0.0042 + var0 * (double)5.0F);
   }

   private static Color IIl(Color var0, double var1, int var3) {
      double var4 = (double)System.currentTimeMillis() * 0.0027 + var1 * 2.2;
      Color var6 = I(new Color(lll(1809772496, -323663667), lll(1809772497, -2033373601), lll(1809772498, 24858878)), var3);
      Color var7 = I(new Color(lll(1809772499, -1337193334), lll(1809772508, -774003618), lll(1809772509, 853684452)), var3);
      Color var8 = I(Il(var0, 1.18), var3);
      Color var9 = II(var6, var7, (double)0.5F + (double)0.5F * Math.sin(var4));
      return I(II(var8, var9, 0.42 + 0.28 * Math.cos(var4 * 0.7)), var3);
   }

   public static Color IlI(Color var0, double var1) {
      Color var3 = var0 == null ? Color.WHITE : var0;
      return I(var3, (int)Math.round((double)var3.getAlpha() * Math.max((double)0.0F, var1)));
   }

   public static Color Ill(Color var0, Object var1, double var2) {
      int var4 = var0 == null ? lll(1809772510, -916403091) : var0.getAlpha();
      return ll(var0, var1, var2, var4);
   }

   private static Color lII(Color var0, double var1, int var3) {
      double var4 = III(var1);
      Color var6 = Il(var0, 0.72);
      Color var7 = Il(var0, 1.28);
      return I(II(var6, var7, var4), var3);
   }

   public static Color lIl(Color var0, Object var1, double var2) {
      return Ill(var0, var1, var2 + 0.19);
   }

   private static Color llI(float var0, float var1, float var2, int var3) {
      int var4 = Color.HSBtoRGB(var0, var1, var2);
      return new Color(var4 >> lll(1809772511, -1369909032) & lll(1809772504, -692926939), var4 >> lll(1809772505, 1978331828) & lll(1809772506, 1658504545), var4 & lll(1809772507, 122882183), l(var3));
   }

   private static int lll(int var0, int var1) {
      return Il[var0 ^ 1809772500] ^ var1 ^ var0;
   }

   static {
      int var2 = -2124621508;
      byte[] var0 = ".\u0086µ\u009eÇ]Æ/<fv\u008a\u0011÷\u0085ü\u00067~}lO\u0018^ëùfïZÎ:Ê;_\u0092ÊØ`\u0006ú#âúpDÚî+<0ð>\u009fhÄY\u0088XóxíÑ>\u009f".getBytes("ISO-8859-1");
      int var1 = var0.length / 4;
      Il = new int[var1];
      int var3 = 0;
      int var4 = 0;

      do {
         int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
         var5 ^= var2;
         Il[var4] = var5;
         var3 += 4;
         ++var4;
      } while(var4 < var1);

   }
}
