package x;

public final class IlIll {
   public static final double I = (double)3.0F;
   public static final double l = 2.35;

   public static boolean I(boolean var0, boolean var1, boolean var2) {
      return var0 && !var1 && !var2;
   }

   public static <undefinedtype> l(double var0, boolean var2, boolean var3, boolean var4, double var5, double var7, boolean var9) {
      return Il(var0, var2, var3, var4, var4, var5, var7, var7, var9);
   }

   public static <undefinedtype> II(double var0, boolean var2, boolean var3, boolean var4) {
      return l(var0, var2, var3, var4, 2.35, (double)3.0F, true);
   }

   private IlIll() {
   }

   public static <undefinedtype> Il(double var0, boolean var2, boolean var3, boolean var4, boolean var5, double var6, double var8, double var10, boolean var12) {
      if (Double.isFinite(var0) && !(var0 < (double)0.0F)) {
         double var13 = Double.isFinite(var6) && var6 >= (double)0.0F ? var6 : 2.35;
         double var15 = Double.isFinite(var8) && var8 >= (double)0.0F ? Math.max(var13, var8) : Math.max(var13, (double)3.0F);
         double var17 = Double.isFinite(var10) && var10 >= (double)0.0F ? Math.max(var15, var10) : var15;
         if (var2) {
            return new Record(false, false, var12 && var3) {
               private static final <undefinedtype> I = new <anonymous constructor>(false, false, false);
               private final boolean l;
               private final boolean II;
               private final boolean Il;

               public boolean I() {
                  return this.Il;
               }

               public boolean l() {
                  return this.II;
               }

               public {
                  this.II = var1;
                  this.l = var2;
                  this.Il = var3;
               }

               public boolean II() {
                  return this.l;
               }
            };
         } else {
            boolean var19 = var0 > var13;
            boolean var20 = var19 && var0 > var15 && var4;
            boolean var21 = var19 && var0 > var17 && var5;
            return new Record(var19, var20 || var21, var21 && var3) {
               private static final <undefinedtype> I = new <anonymous constructor>(false, false, false);
               private final boolean l;
               private final boolean II;
               private final boolean Il;

               public boolean I() {
                  return this.Il;
               }

               public boolean l() {
                  return this.II;
               }

               public {
                  this.II = var1;
                  this.l = var2;
                  this.Il = var3;
               }

               public boolean II() {
                  return this.l;
               }
            };
         }
      } else {
         return null.I;
      }
   }
}
