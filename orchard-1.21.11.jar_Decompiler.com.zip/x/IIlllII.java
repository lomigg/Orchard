package x;

import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_490;
import net.minecraft.class_5134;
import net.minecraft.class_6880;
import net.minecraft.class_746;
import net.minecraft.class_9285;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

@Environment(EnvType.CLIENT)
public final class IIlllII extends IIIIIIIlI {
   private static final int I = 8;
   private boolean l;
   private static String[] II;
   private static final int Il = 5;
   private int lI;
   private final lIIIIl ll;
   private long III;
   private long IIl;
   private static final int IlI = 7;
   private final lIIIIl Ill;
   private boolean lII;
   private int lIl;
   private final IlIIIlIlI<IIlllIllI> llI;
   private final llllIlIl lll;
   private static final int IIII = 6;
   private int IIIl;
   private static final int[] IIlI;
   private static final String[] IIll;
   private static final Object[] IlII;

   private boolean ll(class_310 var1) {
      if (this.IIlIl()) {
         return !this.lllI(var1) ? false : this.IIll(var1);
      } else {
         return !lIlIllll.IIIl(var1) ? false : lIlIllll.III(var1);
      }
   }

   private static void IlI() {
      II[0] = lIIl(IlIIl(1734239652, 1457408594).toCharArray(), 18814L, IlIII(279979088, 666615745));
      II[1] = lIIl(IlIIl(1734239653, 1536563100).toCharArray(), 88282L, IlIII(279979089, 805063917));
      II[2] = lIIl(IlIIl(1734239654, 2095723777).toCharArray(), 98475L, IlIII(279979090, -244154069));
      II[3] = lIIl(IlIIl(1734239655, 976500506).toCharArray(), 97743L, IlIII(279979091, 1083298081));
      II[4] = lIIl(IlIIl(1734239648, -1878033629).toCharArray(), 47005L, IlIII(279979092, 730261654));
      II[5] = lIIl(IlIIl(1734239649, 1722580565).toCharArray(), 8861L, IlIII(279979093, 831854479));
      II[IlIII(279979094, -115292128)] = lIIl(IlIIl(1734239650, -1281336497).toCharArray(), 34318L, IlIII(279979095, -973283013));
      II[IlIII(279979096, -1113462131)] = lIIl(IlIIl(1734239651, -583241896).toCharArray(), 93038L, IlIII(279979097, -1488311142));
      II[IlIII(279979098, 504089922)] = lIIl(IlIIl(1734239660, 286873229).toCharArray(), 26486L, IlIII(279979099, 1271497957));
      II[IlIII(279979100, 520516799)] = lIIl("".toCharArray(), 81201L, IlIII(279979101, 414871424));
      II[IlIII(279979102, -1163938181)] = lIIl(IlIIl(1734239661, 2003462605).toCharArray(), 35564L, IlIII(279979103, -175935448));
      II[IlIII(279979072, 1151162538)] = lIIl(IlIIl(1734239662, -1962056347).toCharArray(), 50775L, IlIII(279979073, 1337489875));
      II[IlIII(279979074, 1150857453)] = lIIl(IlIIl(1734239663, -1723898504).toCharArray(), 21122L, IlIII(279979075, -1068071121));
      II[IlIII(279979076, -1355236262)] = lIIl(IlIIl(1734239656, -454918313).toCharArray(), 70698L, IlIII(279979077, -1318910628));
      II[IlIII(279979078, -827194325)] = lIIl(IlIIl(1734239657, 1796236568).toCharArray(), 53948L, IlIII(279979079, 3455032));
      II[IlIII(279979080, 1524202253)] = lIIl(IlIIl(1734239658, -1424284217).toCharArray(), 98287L, IlIII(279979081, 1712256569));
      II[IlIII(279979082, 85824082)] = lIIl(IlIIl(1734239659, 97521582).toCharArray(), 14075L, IlIII(279979083, 1535659491));
   }

   private boolean lII(class_310 var1, class_746 var2, int var3, int var4) {
      if (var1.field_1755 instanceof class_490) {
         if (!this.ll(var1)) {
            return false;
         } else {
            this.lIII(var3, var4, var2, var1);
            return true;
         }
      } else if ((Boolean)this.ll.III()) {
         return false;
      } else if (!this.ll(var1)) {
         return false;
      } else {
         this.lIII(var3, var4, var2, var1);
         return true;
      }
   }

   private boolean llI(class_1799 var1) {
      return var1 != null && !var1.method_7960() && var1.method_31574(class_1802.field_8833);
   }

   private void lll() {
      this.lI = -1;
      this.IIIl = -1;
      this.lIl = IlIII(279979084, 1053129385);
      this.lII = false;
      this.l = false;
   }

   public void lIl() {
      this.III = 0L;
      this.IIl = this.llII();
      this.lll();
   }

   static {
      short var6 = 17986;
      String var7 = "ฟ佺舄ു퐦薋䰄\u0ba2\ud830ⲙ茹⚼㠊징䈢邐\ueb62ꮨ訯ϱ谶\uebbe襁ᆕᖗᳬိ㿳Д犖㻪됍⡤⼏\udf58兯壼᪢克쀵蹯ख焮厱溑\udb09躮\udd82䞽剈톟톊淯ᯖЬ睕\udffd뽏▷縆讓\u202d\ue3ae\uf757俣‴뻼ၤ푶攉≄縲蓥︆儽䆩鳁添盩ҁ凞侊Ⲕ\ue239Ⱃ\ue15c\uec70傠㎳◯\ue674㉊ᶜ懕烟ꥩ\ue65eᥜ짶璺풌ᘡ䎆鳹年৯Ữ⮑ₓ⭳軦ⓓ\ue3bc鉜\uf1c1ढ泌諗㛸ﹻ쎢ꪖ舂ᢎ轓┏\ue5a3㕌뉭㩼떘\ue208꽻⎭ᇃ\ud915ᚚ鳜\ue867\u197f霏\uec01ὐ余\uec11䲚\ue2b9䎟엮孌ጪ벜菠䃕썲篁쨞堺햻ᅲ⻐⒑㽔䴞꺶珥♐\uf205\udd1f栋꣣⤜웩뷿帑煸ᐳ㭪쯡䴪鳌蒚턥㡬笈嶬嶦厡鈓㌢犒車阈ᡣ猴碀詻詨榿ᗖ칞滻㏟㖮⻅ﳐ\r\ue032揔䷄\ue18d硥\uf8ad䔨ꟲ\udb2a癸乳돑ᣇ\u0ade鼭異ま牥は앉ꛛ\udebd픕㗓\udb95䃼퐩㓤闝誼䋪鍪侫\ue6ef봽㘸\uee33㋙Ꮛ龍䩊켇얞䢇溝瞑寓䆇ᤶ䫗癁\uf2e0줚忖䔖杇潠㣂˸튉漲혶鸾႙澴維ฦ㪑䶧̋楂葠뽹ٰഝ䖩שּׁ布米鄠䴜⾰\uf61d\uef48ᷣ揵妎褆¿鹫\uec19\ue2ebᇨ";
      char[] var8 = "䙞䙎䘎䙊䙆䙖䙎䙒䙎䙒䙖䙒䙒䙒䙊䙖".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IIll = var9;
            IlII = new Object[var9.length];
            int var2 = -1681355781;
            byte[] var0 = "-ec\u0013\u0011\u008c8øv\u000bb^êë\u001bz\u001c hNÁ\u001b\u0014frXg\u008b3Æ»\u008c6ÙE)×\u0082p\u0081\u0095sbë³ù$\u0083\u0094~Û\u0011vµ\u008af1ç\u0019ÔQàØ$Ïå÷\u001a\u0097Õ$8Ïà\u001fX\r\u0091\u008bd$@\u0013èfª\u0019}EÊ«\u0098îÖØnÑ¡Ô±Õ ¥\u0095\u008ee=ó\u0019\u0088æ@5½Õ\u001e\fb+\u001fßBdä ºÃ21zdH\u0097%Ò\u0014TÜØ×\u00adGLY8i\u0091´\u001d\u0081ÂòÂgH\u0005(¥{³¯D'Ë\u001ek:äÊÿ\u00adç«\u0084º-´\u0004\u00941<\u0013³²¾Ì\u0012\u000f\u0085ØëËÇ\u0018\u0000^\u0014`Öâ×\u0001M\u0001T5á\u0093;h¦ÿ".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IIlI = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IIlI[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            II = new String[IlIII(279979085, -2028305224)];
            IlI();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private boolean IIll(class_310 var1) {
      boolean var10000;
      switch ((IIlllIllI)this.llI.III()) {
         case I -> var10000 = lIlIllll.IIll(var1);
         case ll -> var10000 = lIlIllll.IIl(var1);
         case Il -> var10000 = lIlIllll.llII(var1);
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   private void IlII(class_310 var1) {
      if (this.l) {
         if (var1 != null && var1.field_1755 instanceof class_490) {
            var1.method_1507((class_437)null);
         }

         this.l = false;
      }
   }

   private boolean IlIl(class_310 var1) {
      lIllIIl var2 = lIllIIl.Il();
      if (var2 != null && var2.IIl() != null) {
         IlIIIIl var3 = var2.IIl().IIIl();
         return var3 != null && var3.IIIll(var1);
      } else {
         return false;
      }
   }

   private double Illl(class_1799 var1) {
      return !var1.method_7960() && var1.method_7963() && var1.method_7936() > 0 ? (double)(var1.method_7936() - var1.method_7919()) / (double)var1.method_7936() : (double)1.0F;
   }

   private void lIII(int var1, int var2, class_746 var3, class_310 var4) {
      this.lI = var1;
      this.IIIl = var2;
      this.lIl = var3.field_6012 + 1;
      this.lII = true;
      if (this.llI.III() == IIlllIllI.Il) {
         lIlIllll.IlI(var4);
      } else if (this.llI.III() == IIlllIllI.I) {
         lIlIllll.lll(var4);
      }

   }

   private static String lIIl(char[] var0, long var1, int var3) {
      int var4 = IlIII(279979086, 409360971) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IlIII(279979087, 734162041);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private int lIll(class_1799 var1) {
      if (var1.method_7960()) {
         return -1;
      } else {
         int var2 = 0;
         class_9285 var3 = (class_9285)var1.method_58695(class_9334.field_49636, class_9285.field_49326);

         for(class_9285.class_9287 var5 : var3.comp_2393()) {
            if (var5.comp_2395().equals(class_5134.field_23724)) {
               var2 += (int)(var5.comp_2396().comp_2449() * (double)10.0F);
            } else if (var5.comp_2395().equals(class_5134.field_23725)) {
               var2 += (int)(var5.comp_2396().comp_2449() * (double)5.0F);
            }
         }

         if (var2 == 0) {
            return -1;
         } else {
            class_9304 var9 = (class_9304)var1.method_58695(class_9334.field_49633, class_9304.field_49385);

            for(class_6880 var6 : var9.method_57534()) {
               String var7 = (String)var6.method_40230().map((var0) -> var0.method_29177().method_12832()).orElse(II[IlIII(279979120, -1174221878)]);
               int var8 = var9.method_57536(var6);
               if (var7.equals(lIlIII.Il(II[IlIII(279979121, 475889044)]))) {
                  var2 += var8 * 3;
               } else if (var7.contains(lIlIII.Il(II[IlIII(279979122, -542869676)]))) {
                  var2 += var8 * 2;
               } else if (var7.equals(lIlIII.Il(II[IlIII(279979123, 641721308)]))) {
                  var2 += var8;
               } else if (var7.equals(lIlIII.Il(II[IlIII(279979124, -1290715597)]))) {
                  var2 += 2;
               } else if (var7.equals(lIlIII.Il(II[IlIII(279979125, -1762038420)]))) {
                  var2 += var8 * 2;
               } else if (var7.equals(lIlIII.Il(II[IlIII(279979126, 1226827655)]))) {
                  var2 += var8;
               } else if (var7.equals(lIlIII.Il(II[IlIII(279979127, -1545743304)]))) {
                  var2 += var8 * 2;
               } else if (var7.equals(lIlIII.Il(II[IlIII(279979128, 607946819)])) || var7.equals(lIlIII.Il(II[IlIII(279979129, -1793878678)])) || var7.equals(lIlIII.Il(II[IlIII(279979130, 1099367016)]))) {
                  var2 += var8;
               }
            }

            return var2;
         }
      }
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (var1.field_1724 != null && var1.field_1761 != null && var1.field_1687 != null) {
         boolean var2 = this.l && var1.field_1755 instanceof class_490;
         if ((Boolean)this.ll.III() && !(var1.field_1755 instanceof class_490)) {
            this.lll();
         } else if ((Boolean)this.ll.III() || var1.field_1755 == null || var2 || var1.field_1755 instanceof class_490) {
            if (!this.IlIl(var1)) {
               class_746 var3 = var1.field_1724;
               if (this.IIIll()) {
                  if (this.lII) {
                     if (var3.field_6012 < this.lIl) {
                        return;
                     }

                     if (!this.ll(var1)) {
                        return;
                     }
                  } else if (!(var1.field_1755 instanceof class_490)) {
                     this.lll();
                     return;
                  }

                  if (this.lII || this.ll(var1)) {
                     this.IIlll(var1, var3, this.lI, this.IIIl);
                     this.III = System.currentTimeMillis();
                     this.IIl = this.llII();
                     if (this.l) {
                        this.IlII(var1);
                     }

                     this.lll();
                  }
               } else if (var3.field_7498.method_34255().method_7960()) {
                  if (System.currentTimeMillis() - this.III >= this.IIl) {
                     this.IIIII(var1, var3, 5);
                     if (!this.IIIll()) {
                        this.IIIII(var1, var3, IlIII(279979131, 553391531));
                        if (!this.IIIll()) {
                           this.IIIII(var1, var3, IlIII(279979132, 1065106353));
                           if (!this.IIIll()) {
                              this.IIIII(var1, var3, IlIII(279979133, -1217717188));
                           }
                        }
                     }
                  }
               }
            }
         }
      } else {
         this.lll();
      }
   }

   private long llII() {
      double var1 = this.lll.IlII();
      double var3 = this.lll.IlI();
      return var1 == var3 ? Math.round(var1) : Math.round(ThreadLocalRandom.current().nextDouble(var1, var3));
   }

   public IIlllII() {
      super((Object)lIlIII.l(II[1]), lIllII.l, (Object)lIlIII.l(II[2]));
      this.lll = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(II[3]), (double)75.0F, (double)75.0F, (double)0.0F, (double)500.0F, (double)5.0F)).IIII(lIlIII.Il(II[4])));
      this.llI = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(II[IlIII(279979134, 901037452)]), IIlllIllI.class, IIlllIllI.I));
      this.ll = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(II[0]), false));
      this.Ill = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(II[5]), false));
      this.lI = -1;
      this.IIIl = -1;
      this.lIl = IlIII(279979135, -1902099377);
      this.llI.lIII(() -> !(Boolean)this.ll.III());
   }

   private boolean lllI(class_310 var1) {
      boolean var10000;
      switch ((IIlllIllI)this.llI.III()) {
         case I -> var10000 = lIlIllll.IlIl(var1);
         case ll -> var10000 = lIlIllll.lIl(var1);
         case Il -> var10000 = lIlIllll.IIIII(var1);
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   private void IIIII(class_310 var1, class_746 var2, int var3) {
      class_1735 var4 = (class_1735)var2.field_7498.field_7761.get(var3);
      class_1799 var5 = var4.method_7677();
      if (var3 == IlIII(279979104, 1281404867) && (Boolean)this.Ill.III()) {
         if (this.llI(var5)) {
            return;
         }

         int var6 = this.IIlII(var2, var4);
         if (var6 >= 0) {
            this.lII(var1, var2, var6, var3);
            return;
         }
      }

      int var16 = this.lIll(var5);
      int var7 = -1;
      int var8 = var16;
      double var9 = (double)-1.0F;

      for(int var11 = IlIII(279979105, -1625785999); var11 < IlIII(279979106, 1551491765); ++var11) {
         class_1799 var12 = ((class_1735)var2.field_7498.field_7761.get(var11)).method_7677();
         if (!var12.method_7960() && var4.method_7680(var12)) {
            int var13 = this.lIll(var12);
            if (var13 > 0 && var13 > var16) {
               double var14 = this.Illl(var12);
               if (var13 > var8 || var13 == var8 && var14 > var9) {
                  var8 = var13;
                  var9 = var14;
                  var7 = var11;
               }
            }
         }
      }

      if (var7 >= 0) {
         this.lII(var1, var2, var7, var3);
      }
   }

   private void IIIIl(class_310 var1, class_746 var2) {
      if (var1.field_1755 instanceof class_490) {
         this.l = false;
      } else {
         var1.method_1507(new class_490(var2));
         this.l = true;
      }
   }

   private boolean IIIll() {
      return this.lI >= 0 && this.IIIl >= 0;
   }

   private int IIlII(class_746 var1, class_1735 var2) {
      int var3 = -1;
      double var4 = (double)-1.0F;

      for(int var6 = IlIII(279979107, -548581886); var6 < IlIII(279979108, -1341126323); ++var6) {
         class_1799 var7 = ((class_1735)var1.field_7498.field_7761.get(var6)).method_7677();
         if (this.llI(var7) && var2.method_7680(var7)) {
            double var8 = this.Illl(var7);
            if (var3 < 0 || var8 > var4) {
               var3 = var6;
               var4 = var8;
            }
         }
      }

      return var3;
   }

   private boolean IIlIl() {
      return !(Boolean)this.ll.III();
   }

   public void lI() {
      this.IlII(class_310.method_1551());
      this.lll();
   }

   private void IIlll(class_310 var1, class_746 var2, int var3, int var4) {
      int var5 = var2.field_7498.field_7763;
      var1.field_1761.method_2906(var5, var3, 0, class_1713.field_7790, var2);
      var1.field_1761.method_2906(var5, var4, 0, class_1713.field_7790, var2);
      if (!var2.field_7498.method_34255().method_7960()) {
         var1.field_1761.method_2906(var5, var3, 0, class_1713.field_7790, var2);
      }

   }

   private static int IlIII(int var0, int var1) {
      return IIlI[var0 ^ 279979088] ^ var1 ^ var0;
   }

   private static String IlIIl(int var0, int var1) {
      int var3 = var0 ^ 1734239652;
      char[] var4 = IIll[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IlII[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IlII[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -526828401;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 97;
               break;
            case 1:
               var9 = 89;
               break;
            case 2:
               var9 = 121;
               break;
            case 3:
               var9 = 48;
               break;
            case 4:
               var9 = 189;
               break;
            case 5:
               var9 = 231;
               break;
            case 6:
               var9 = 121;
               break;
            case 7:
               var9 = 241;
               break;
            case 8:
               var9 = 134;
               break;
            case 9:
               var9 = 64;
               break;
            case 10:
               var9 = 65;
               break;
            case 11:
               var9 = 71;
               break;
            case 12:
               var9 = 147;
               break;
            case 13:
               var9 = 2;
               break;
            case 14:
               var9 = 127;
               break;
            case 15:
               var9 = 63;
               break;
            case 16:
               var9 = 132;
               break;
            case 17:
               var9 = 169;
               break;
            case 18:
               var9 = 211;
               break;
            case 19:
               var9 = 148;
               break;
            case 20:
               var9 = 110;
               break;
            case 21:
               var9 = 199;
               break;
            case 22:
               var9 = 201;
               break;
            case 23:
               var9 = 143;
               break;
            case 24:
               var9 = 78;
               break;
            case 25:
               var9 = 167;
               break;
            case 26:
               var9 = 253;
               break;
            case 27:
               var9 = 102;
               break;
            case 28:
               var9 = 24;
               break;
            case 29:
               var9 = 36;
               break;
            case 30:
               var9 = 222;
               break;
            case 31:
               var9 = 212;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
