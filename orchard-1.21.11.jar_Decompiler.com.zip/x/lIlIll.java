package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_746;
import net.minecraft.class_2350.class_2351;

@Environment(EnvType.CLIENT)
final class lIlIll {
   private static final double I = 0.025;
   private static final double l = 0.05;
   private static final double II = 0.65;
   private static final double Il = 0.02;
   private static final double lI = 0.035;
   private static final double ll = 0.74;
   static final double III = 0.1;
   private static final int IIl = 5;
   private static final double IlI = 0.15;
   private static final double Ill = 0.42;
   private static final double lII = 1.15;
   private static final double lIl = 0.05;
   private static final int[] llI;

   private lIlIll() {
   }

   static <undefinedtype> I(class_310 var0, class_746 var1, double var2) {
      if (var0 != null && var0.field_1690 != null && var0.field_1687 != null && var1 != null) {
         <undefinedtype> var4 = Ill(var0, var1);
         if (var4 == null) {
            return null.l();
         } else {
            double var5 = ll(var1.method_18798().field_1352, var1.method_18798().field_1350, var4.I(), var4.l(), var2);
            <undefinedtype> var7 = Il(var0.field_1687, var1, var4.I(), var4.l(), var5);
            boolean var8 = !IlI(var0.field_1687, var1, (double)0.0F, (double)0.0F);
            boolean var9 = IlI(var0.field_1687, var1, var4.I() * var5, var4.l() * var5);
            boolean var10 = var8 && var9;
            boolean var11 = var0.field_1690.field_1894.method_1434() || var0.field_1690.field_1881.method_1434() || var0.field_1690.field_1913.method_1434() || var0.field_1690.field_1849.method_1434();
            return new Record(var11, var10, var7.I(), var4.I(), var4.l(), var5) {
               private final boolean I;
               private final double l;
               private final double II;
               private final boolean Il;
               private final double lI;
               private final boolean ll;

               public boolean I() {
                  return this.ll;
               }

               static <undefinedtype> l() {
                  return new <anonymous constructor>(false, false, true, (double)0.0F, (double)0.0F, (double)0.0F);
               }

               public double II() {
                  return this.lI;
               }

               public double Il() {
                  return this.l;
               }

               {
                  this.Il = var1;
                  this.ll = var2;
                  this.I = var3;
                  this.II = var4;
                  this.lI = var6;
                  this.l = var8;
               }

               public double lI() {
                  return this.II;
               }

               public boolean ll() {
                  return this.Il;
               }

               public boolean III() {
                  return this.I;
               }
            };
         }
      } else {
         return null.l();
      }
   }

   static boolean l(class_1937 var0, class_746 var1, double var2, double var4) {
      return var0 != null && var1 != null && !IlI(var0, var1, var2, var4);
   }

   private static double II(double var0, double var2, int var4, int var5) {
      return var5 <= 1 ? (var0 + var2) * (double)0.5F : var0 + (var2 - var0) * ((double)var4 / (double)(var5 - 1));
   }

   private static <undefinedtype> Il(class_1937 var0, class_746 var1, double var2, double var4, double var6) {
      class_238 var8 = var1.method_5829();
      double var9 = var8.field_1322 - 0.05;
      double var11 = var8.field_1323 + 0.02;
      double var13 = var8.field_1320 - 0.02;
      double var15 = var8.field_1321 + 0.02;
      double var17 = var8.field_1324 - 0.02;
      double var19 = (var11 + var13) * (double)0.5F;
      double var21 = (var15 + var17) * (double)0.5F;
      double var23 = -var4;
      double var25 = var2;
      double var27 = (double)0.0F;
      double var29 = (double)0.0F;

      for(double var34 : new double[]{var11, var13}) {
         for(double var39 : new double[]{var15, var17}) {
            double var41 = var34 - var19;
            double var43 = var39 - var21;
            var27 = Math.max(var27, var41 * var2 + var43 * var4);
            var29 = Math.max(var29, Math.abs(var41 * var23 + var43 * var25));
         }
      }

      int var45 = 0;
      int var46 = lIl(-764106756, -1207584976);

      for(int var47 = 0; var47 < 5; ++var47) {
         double var49 = II(var11, var13, var47, 5);

         for(int var51 = 0; var51 < 5; ++var51) {
            double var54 = II(var15, var17, var51, 5);
            if (lI(var0, var49, var9, var54, var8.field_1322)) {
               ++var45;
            }
         }
      }

      int var48 = 0;
      double var50 = var27 + var6;

      for(int var52 = 0; var52 < 5; ++var52) {
         double var55 = II(-var29, var29, var52, 5);
         double var56 = var19 + var2 * var50 + var23 * var55;
         double var57 = var21 + var4 * var50 + var25 * var55;
         if (lI(var0, var56, var9, var57, var8.field_1322)) {
            ++var48;
         }
      }

      boolean var53 = lI(var0, var19, var9, var21, var8.field_1322);
      return new Record(var53, (double)var45 / (double)var46, (double)var48 / (double)5.0F) {
         private final double I;
         private final double l;
         private final boolean II;

         private boolean I() {
            return this.II && this.l >= 0.74 && this.I >= 0.65;
         }

         public double l() {
            return this.I;
         }

         private {
            this.II = var1;
            this.l = var2;
            this.I = var4;
         }

         public double II() {
            return this.l;
         }

         public boolean Il() {
            return this.II;
         }
      };
   }

   private static boolean lI(class_1937 var0, double var1, double var3, double var5, double var7) {
      class_2338 var9 = class_2338.method_49637(var1, var3, var5);
      class_2680 var10 = var0.method_8320(var9);
      if (!var10.method_26215() && var10.method_26227().method_15769()) {
         class_265 var11 = var10.method_26220(var0, var9);
         if (var11.method_1110()) {
            return false;
         } else {
            double var12 = (double)var9.method_10264() + var11.method_1105(class_2351.field_11052);
            return var12 >= var7 - 0.15;
         }
      } else {
         return false;
      }
   }

   static double ll(double var0, double var2, double var4, double var6, double var8) {
      double var10 = Math.max((double)0.0F, var0 * var4 + var2 * var6);
      double var12 = var10 * 1.15 + 0.035;
      return Math.min(0.42, Math.max(Math.max(0.025, var8), var12));
   }

   static <undefinedtype> III(class_746 var0, float var1, float var2) {
      if (var0 == null) {
         return null;
      } else {
         double var3 = Math.sqrt((double)(var1 * var1 + var2 * var2));
         if (var3 < 0.001) {
            float var16 = (float)Math.toRadians((double)var0.method_36454());
            double var17 = -Math.sin((double)var16);
            double var18 = Math.cos((double)var16);
            double var19 = Math.sqrt(var17 * var17 + var18 * var18);
            return var19 < 0.001 ? null : new Record(var17 / var19, var18 / var19) {
               private final double I;
               private final double l;

               public double I() {
                  return this.I;
               }

               {
                  this.I = var1;
                  this.l = var3;
               }

               public double l() {
                  return this.l;
               }
            };
         } else {
            if (var3 > (double)1.0F) {
               var1 /= (float)var3;
               var2 /= (float)var3;
            }

            float var5 = (float)Math.toRadians((double)var0.method_36454());
            double var6 = Math.sin((double)var5);
            double var8 = Math.cos((double)var5);
            double var10 = -var6 * (double)var1 - var8 * (double)var2;
            double var12 = var8 * (double)var1 - var6 * (double)var2;
            double var14 = Math.sqrt(var10 * var10 + var12 * var12);
            return var14 < 0.001 ? null : new Record(var10 / var14, var12 / var14) {
               private final double I;
               private final double l;

               public double I() {
                  return this.I;
               }

               {
                  this.I = var1;
                  this.l = var3;
               }

               public double l() {
                  return this.l;
               }
            };
         }
      }
   }

   static <undefinedtype> IIl(class_310 var0, class_746 var1) {
      return I(var0, var1, 0.1);
   }

   private static boolean IlI(class_1937 var0, class_746 var1, double var2, double var4) {
      class_238 var6 = var1.method_5829().method_989(var2, var1.field_6017 - (double)var1.method_49476(), var4).method_35580(0.05, (double)0.0F, 0.05);
      return var0.method_8587(var1, var6);
   }

   static <undefinedtype> Ill(class_310 var0, class_746 var1) {
      if (var0 != null && var0.field_1690 != null && var1 != null) {
         float var2 = 0.0F;
         float var3 = 0.0F;
         if (var0.field_1690.field_1894.method_1434()) {
            ++var2;
         }

         if (var0.field_1690.field_1881.method_1434()) {
            --var2;
         }

         if (var0.field_1690.field_1913.method_1434()) {
            ++var3;
         }

         if (var0.field_1690.field_1849.method_1434()) {
            --var3;
         }

         return III(var1, var2, var3);
      } else {
         return null;
      }
   }

   static double lII(class_1937 var0, class_746 var1) {
      if (var0 != null && var1 != null) {
         class_238 var2 = var1.method_5829();
         double var3 = var2.field_1322 - 0.05;
         double var5 = var2.field_1323 + 0.02;
         double var7 = var2.field_1320 - 0.02;
         double var9 = var2.field_1321 + 0.02;
         double var11 = var2.field_1324 - 0.02;
         int var13 = 0;
         int var14 = lIl(-764106755, -1584297598);

         for(int var15 = 0; var15 < 5; ++var15) {
            double var16 = II(var5, var7, var15, 5);

            for(int var18 = 0; var18 < 5; ++var18) {
               double var19 = II(var9, var11, var18, 5);
               if (lI(var0, var16, var3, var19, var2.field_1322)) {
                  ++var13;
               }
            }
         }

         return (double)var13 / (double)var14;
      } else {
         return (double)1.0F;
      }
   }

   private static int lIl(int var0, int var1) {
      return llI[var0 ^ -764106756] ^ var1 ^ var0;
   }

   static {
      int var2 = -1984810229;
      byte[] var0 = "ãÃ#ÞúW\u001dm".getBytes("ISO-8859-1");
      int var1 = var0.length / 4;
      llI = new int[var1];
      int var3 = 0;
      int var4 = 0;

      do {
         int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
         var5 ^= var2;
         llI[var4] = var5;
         var3 += 4;
         ++var4;
      } while(var4 < var1);

   }
}
