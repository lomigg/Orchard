package x;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
final class IlllII {
   double I;
   double l;
   lIllII II;
   private final Set<Long> Il;
   double lI;
   double ll;
   double III;
   private boolean IIl;
   private static final double IlI = (double)620.0F;
   double Ill;
   double lII;
   IIIlIlIII lIl;
   private boolean llI;
   <undefinedtype> lll;
   private static final double IIII = (double)1.75F;
   private static final double IIIl = 0.36;
   double IIlI;
   private static final double IIll = (double)420.0F;
   private long IlII;
   double IlIl;
   double IllI;
   IIllIIlII Illl;
   private long lIII;
   private static final double lIIl = (double)382.0F;
   double lIlI;
   double lIll;
   private static final double llII = (double)382.0F;
   private boolean llIl;
   private final EnumMap<lIllII, Double> lllI;
   private static final int[] llll;
   private static final String[] IIIII;
   private static final Object[] IIIIl;

   private static String I(long var0) {
      String var2 = Long.toUnsignedString(var0, lllI(-68174602, -2055416058));
      StringBuilder var3 = (new StringBuilder(lllI(-68174601, 255314677))).append((char)lllI(-68174604, 313014483));

      for(int var4 = var2.length(); var4 < lllI(-68174603, 1754340887); ++var4) {
         var3.append((char)lllI(-68174606, 825413947));
      }

      return var3.append(var2).toString();
   }

   void l(lIllII var1, double var2) {
      this.lllI.put(var1, Math.max((double)0.0F, var2));
   }

   JsonObject II() {
      JsonObject var1 = new JsonObject();
      var1.addProperty(lIlIII.Il(llll(1338470859, -163043113)), this.IIlI);
      var1.addProperty(lIlIII.Il(llll(1338470858, 417008204)), this.lIll);
      var1.addProperty(lIlIII.Il(llll(1338470857, -1349769945)), this.IlIl);
      var1.addProperty(lIlIII.Il(llll(1338470856, 42549569)), this.III);
      var1.addProperty(lIlIII.Il(llll(1338470863, 173546940)), this.ll);
      var1.addProperty(lIlIII.Il(llll(1338470862, 1971531553)), this.lI);
      var1.addProperty(lIlIII.Il(llll(1338470861, -300661663)), this.II.ordinal());
      var1.addProperty(lIlIII.Il(llll(1338470860, -1009823487)), this.Illl.ordinal());
      var1.addProperty(lIlIII.Il(llll(1338470851, 599541763)), this.lll.ordinal());
      var1.addProperty(lIlIII.Il(llll(1338470850, -1088674076)), this.Ill);
      var1.addProperty(lIlIII.Il(llll(1338470849, 472743092)), this.I);
      var1.addProperty(lIlIII.Il(llll(1338470848, 1374639349)), this.l);
      var1.addProperty(lIlIII.Il(llll(1338470855, -87675714)), this.IllI);
      var1.addProperty(lIlIII.Il(llll(1338470854, 1615807651)), this.lII);
      var1.addProperty(lIlIII.Il(llll(1338470853, 767458474)), this.lIlI);
      if (this.llIl) {
         var1.addProperty(lIlIII.Il(llll(1338470852, 1808734329)), I(this.IlII));
      }

      if (this.IIl) {
         var1.addProperty(lIlIII.Il(llll(1338470875, -424663192)), I(this.lIII));
      }

      JsonArray var2 = new JsonArray();

      for(lIllII var6 : lIllII.values()) {
         var2.add(this.IIII(var6));
      }

      var1.add(lIlIII.Il(llll(1338470874, -813620540)), var2);
      JsonArray var7 = new JsonArray();

      for(long var9 : this.Il) {
         var7.add(I(var9));
      }

      var1.add(lIlIII.Il(llll(1338470873, 756616450)), var7);
      return var1;
   }

   IlllII() {
      this.II = lIllII.I;
      this.lIl = IIIlIlIII.IIl;
      this.Illl = IIllIIlII.lIl;
      this.lll = null.l;
      this.lllI = new EnumMap(lIllII.class);
      this.Il = new HashSet();

      for(lIllII var4 : lIllII.values()) {
         this.lllI.put(var4, (double)0.0F);
      }

   }

   void Il(int var1, int var2) {
      this.IlIl = lI(this.IlIl, (double)420.0F, Math.max((double)420.0F, (double)var1 - (double)12.0F));
      this.III = lI(this.III, (double)382.0F, Math.max((double)382.0F, (double)var2 - (double)48.0F));
      this.IIlI = lI(this.IIlI, (double)4.0F, Math.max((double)4.0F, (double)var1 - this.IlIl - (double)4.0F));
      this.lIll = lI(this.lIll, (double)4.0F, Math.max((double)4.0F, (double)var2 - this.III - (double)8.0F));
      this.ll = lI(this.ll, (double)4.0F, Math.max((double)4.0F, (double)var1 - (double)356.0F));
      this.lI = lI(this.lI, (double)4.0F, Math.max((double)4.0F, (double)var2 - (double)34.0F));
   }

   private static double lI(double var0, double var2, double var4) {
      return Math.max(var2, Math.min(var4, var0));
   }

   void ll(IIIIIIIlI var1) {
      this.llIl = var1 != null;
      this.IlII = var1 == null ? 0L : var1.IIlIllI();
   }

   void III(IIIIIIIlI var1) {
      if (var1 != null) {
         this.Il.remove(var1.IIlIllI());
      }

   }

   void IIl() {
      this.IIl = false;
   }

   private static String IlI(JsonObject var0, String var1, String var2) {
      if (var0.has(var1) && var0.get(var1).isJsonPrimitive()) {
         try {
            return var0.get(var1).getAsString();
         } catch (RuntimeException var4) {
            return var2;
         }
      } else {
         return var2;
      }
   }

   private static <E extends Enum<E>> E Ill(JsonObject var0, String var1, E[] var2, E var3) {
      JsonElement var4 = var0.get(var1);
      if (var4 != null && var4.isJsonPrimitive()) {
         try {
            int var5 = var4.getAsInt();
            if (var5 >= 0 && var5 < var2.length) {
               return (E)var2[var5];
            }
         } catch (RuntimeException var10) {
         }

         String var11 = var4.getAsString();

         for(Enum var9 : var2) {
            if (llllIIlI.l(var9, var11)) {
               return (E)var9;
            }
         }

         return (E)var3;
      } else {
         return (E)var3;
      }
   }

   private double lII(int var1) {
      return lI((double)620.0F, (double)420.0F, Math.max((double)420.0F, (double)var1 - (double)16.0F));
   }

   private void lIl(int var1, int var2) {
      double var3 = Math.max((double)420.0F, (double)var1 - (double)12.0F);
      double var5 = Math.max((double)382.0F, (double)var2 - (double)48.0F);
      this.IlIl = Math.min((double)620.0F, var3);
      this.III = Math.min((double)382.0F, var5);
      if (!(this.III <= (double)0.0F) && !(this.IlIl / this.III <= (double)1.75F)) {
         this.IlIl = lI(this.III * (double)1.75F, (double)420.0F, var3);
         if (this.IlIl / this.III > (double)1.75F) {
            this.III = lI(this.IlIl / (double)1.75F, (double)382.0F, var5);
         }

      }
   }

   boolean llI(long var1) {
      return this.IIl && this.lIII == var1;
   }

   private double lll(int var1) {
      return lI((double)382.0F, (double)382.0F, Math.max((double)382.0F, (double)var1 - (double)54.0F));
   }

   double IIII(lIllII var1) {
      return (Double)this.lllI.getOrDefault(var1, (double)0.0F);
   }

   void IIIl(int var1, int var2) {
      this.IlIl = lI(this.IlIl <= (double)0.0F ? this.lII(var1) : this.IlIl, (double)420.0F, Math.max((double)420.0F, (double)var1 - (double)12.0F));
      this.III = lI(this.III <= (double)0.0F ? this.lll(var2) : this.III, (double)382.0F, Math.max((double)382.0F, (double)var2 - (double)48.0F));
      this.lIl(var1, var2);
      this.IIlI = Math.max((double)4.0F, ((double)var1 - this.IlIl) * (double)0.5F);
      this.lIll = Math.max((double)4.0F, ((double)var2 - this.III) * 0.36);
      this.ll = Math.max((double)4.0F, ((double)var1 - (double)348.0F) * (double)0.5F);
      this.lI = Math.max((double)4.0F, (double)var2 - (double)42.0F);
      this.llI = true;
      this.Il(var1, var2);
   }

   void IIlI(long var1) {
      this.IIl = true;
      this.lIII = var1;
   }

   boolean IIll(IIIIIIIlI var1) {
      return var1 != null && this.llIl && this.IlII == var1.IIlIllI();
   }

   private static double IlII(JsonObject var0, String var1, double var2) {
      if (var0.has(var1) && var0.get(var1).isJsonPrimitive()) {
         try {
            return var0.get(var1).getAsDouble();
         } catch (RuntimeException var5) {
            return var2;
         }
      } else {
         return var2;
      }
   }

   void IlIl() {
      this.Il.clear();
      this.llIl = false;
   }

   private static Long IllI(String var0) {
      if (var0 != null && !var0.isBlank()) {
         if (var0.length() == lllI(-68174605, 63882807) && var0.charAt(0) == lllI(-68174608, 130200864)) {
            try {
               return Long.parseUnsignedLong(var0.substring(1), lllI(-68174607, -1241155227));
            } catch (NumberFormatException var2) {
            }
         }

         return lIlIII.II(var0);
      } else {
         return null;
      }
   }

   private static <undefinedtype> Illl(JsonObject var0, String var1, Object var2) {
      JsonElement var3 = var0.get(var1);
      if (var3 != null && var3.isJsonPrimitive()) {
         try {
            int var4 = var3.getAsInt();
            <undefinedtype>[] var5 = null.values();
            if (var4 >= 0 && var4 < var5.length) {
               return var5[var4];
            }
         } catch (RuntimeException var6) {
         }

         return null.l(var3.getAsString());
      } else {
         return var2;
      }
   }

   boolean lIII(IIIIIIIlI var1) {
      return var1 != null && this.Il.contains(var1.IIlIllI());
   }

   void lIIl(IIIIIIIlI var1) {
      if (var1 != null) {
         long var2 = var1.IIlIllI();
         if (!this.Il.remove(var2)) {
            this.Il.add(var2);
            this.IlII = var2;
            this.llIl = true;
         }

      }
   }

   void lIlI(int var1, int var2) {
      if (!this.llI) {
         this.IlIl = this.lII(var1);
         this.III = this.lll(var2);
         this.IIlI = Math.max((double)8.0F, ((double)var1 - this.IlIl) * (double)0.5F);
         this.lIll = Math.max((double)10.0F, ((double)var2 - this.III) * 0.36);
         this.ll = Math.max((double)8.0F, ((double)var1 - (double)348.0F) * (double)0.5F);
         this.lI = Math.max((double)8.0F, (double)var2 - (double)42.0F);
         this.llI = true;
      }

      this.Il(var1, var2);
   }

   private static Long lIll(JsonObject var0, String var1) {
      JsonElement var2 = var0.get(var1);
      return var2 != null && var2.isJsonPrimitive() ? IllI(var2.getAsString()) : null;
   }

   private static double llII(JsonObject var0, Enum<?> var1, double var2) {
      if (var1 instanceof llllIIlI var4) {
         long var5 = var4.I();

         for(Map.Entry var8 : var0.entrySet()) {
            if (lIlIII.II((String)var8.getKey()) == var5 && ((JsonElement)var8.getValue()).isJsonPrimitive()) {
               try {
                  return ((JsonElement)var8.getValue()).getAsDouble();
               } catch (RuntimeException var10) {
                  return var2;
               }
            }
         }

         return var2;
      } else {
         return IlII(var0, var1.name(), var2);
      }
   }

   void llIl(JsonObject var1) {
      if (var1 != null) {
         this.llI = var1.has(lIlIII.Il(llll(1338470872, 1632108751)));
         this.IIlI = IlII(var1, lIlIII.Il(llll(1338470879, -952431408)), this.IIlI);
         this.lIll = IlII(var1, lIlIII.Il(llll(1338470878, -1838211185)), this.lIll);
         this.IlIl = IlII(var1, lIlIII.Il(llll(1338470877, -385984272)), this.IlIl);
         this.III = IlII(var1, lIlIII.Il(llll(1338470876, -1647097652)), this.III);
         this.ll = IlII(var1, lIlIII.Il(llll(1338470867, 203428888)), this.ll);
         this.lI = IlII(var1, lIlIII.Il(llll(1338470866, -410580806)), this.lI);
         this.Ill = IlII(var1, lIlIII.Il(llll(1338470865, -1668858726)), this.Ill);
         this.I = IlII(var1, lIlIII.Il(llll(1338470864, 242306891)), this.I);
         this.l = IlII(var1, lIlIII.Il(llll(1338470871, 1188701972)), this.l);
         this.IllI = IlII(var1, lIlIII.Il(llll(1338470870, -73783253)), this.IllI);
         this.lII = IlII(var1, lIlIII.Il(llll(1338470869, -1687354888)), this.lII);
         this.lIlI = IlII(var1, lIlIII.Il(llll(1338470868, -1064940180)), this.lIlI);
         Long var2 = lIll(var1, lIlIII.Il(llll(1338470891, 259138397)));
         this.llIl = var2 != null;
         this.IlII = var2 == null ? 0L : var2;
         Long var3 = lIll(var1, lIlIII.Il(llll(1338470890, -922545987)));
         this.IIl = var3 != null;
         this.lIII = var3 == null ? 0L : var3;
         this.II = (lIllII)Ill(var1, lIlIII.Il(llll(1338470889, -311333680)), lIllII.values(), this.II);
         this.Illl = (IIllIIlII)Ill(var1, lIlIII.Il(llll(1338470888, 1518302556)), IIllIIlII.values(), this.Illl);
         this.lll = Illl(var1, lIlIII.Il(llll(1338470895, 111558001)), this.lll);
         JsonElement var4 = var1.get(lIlIII.Il(llll(1338470894, 569649412)));
         if (var4 != null && var4.isJsonArray()) {
            JsonArray var11 = var4.getAsJsonArray();
            lIllII[] var13 = lIllII.values();

            for(int var15 = 0; var15 < var13.length && var15 < var11.size(); ++var15) {
               try {
                  this.l(var13[var15], var11.get(var15).getAsDouble());
               } catch (RuntimeException var10) {
               }
            }
         } else if (var4 != null && var4.isJsonObject()) {
            JsonObject var5 = var4.getAsJsonObject();

            for(lIllII var9 : lIllII.values()) {
               this.l(var9, llII(var5, var9, this.IIII(var9)));
            }
         }

         if (var1.has(lIlIII.Il(llll(1338470893, 1049502655))) && var1.get(lIlIII.Il(llll(1338470892, 774193309))).isJsonArray()) {
            this.Il.clear();

            for(JsonElement var14 : var1.getAsJsonArray(lIlIII.Il(llll(1338470883, -1061874970)))) {
               if (var14 != null && var14.isJsonPrimitive()) {
                  Long var16 = IllI(var14.getAsString());
                  if (var16 != null) {
                     this.Il.add(var16);
                  }
               }
            }
         }

      }
   }

   private static int lllI(int var0, int var1) {
      return llll[var0 ^ -68174602] ^ var1 ^ var0;
   }

   static {
      short var6 = 5110;
      String var7 = "蒠蒓蒭萢蒅萔蓫蓥樳樀樾檱樖檇橸橵\udd64\udd57\udd69\udde6\udd41\uddd0\udd2f\udd30灡灒灬烣灄烕瀪災碷碃碟砋碔砯磨碾ݬݘ݄ߐݏߴܷݥ鳸鲰鳱鱞鳙鱈鳔鲖鲰鰡鰑鱠네넔넄놖넄놓녍넩兗內具凥具几儱償儞冼冯冱冤冯凓兿췱췗췛쵆췕쵀춿추춰촶쵧촓촂쵣촍춴滁滌溯湇滠湠溨溣溉渗渲渆渳渦湏滮⌃⍋⌨⎅⌢⎉⍘⍥⍃⏅⎔⏠⏱⎐⏾⍇蠭蠝蠍袟蠍袚衋衶衦裣袠裖裘裆裔蠅እኗኺሕኝሹዊዒዢብቜቤ归弚役忔彷忱弿弼弓徯得徠徠径徑弖忾彌弗徖归徠弬彑ᤧᥫ᤺ᦝᤂᦓ᥊ᥐᥬ\u19cf᧶ᦰ᧑ᦰ᧤\u197cᦞ᥊\u197bᦗ鑘鐔鑅铢鑽铬鐵鐯鐓钰钉铖钤钠钜鑳뵩봥뵖뷍뵊뷷봢봸봥붤뷬뷵忶忑忒彗志彅很徖徺弙弮彭᎒Ꭱ\u139fጐᎷጦᏙᏗ뗡뗒뗬땣뗄땕떪떤\ue0b5\ue086\ue0b8\ue037\ue090\ue001\ue0fe\ue0f3騤騗騩骦騁骐驯驰\uef09\uef3a\uef04\uef8b\uef2c\uefbd\uef42\uef15绽绉绕繁绞繥红维镚镮镲闦镹闂锁镓\uee58\uee7e\uee72\ueeef\uee7c\ueee9\uee16\uee3d\uee19\uee9f\ueece\ueeba\ueeab\ueeca\ueea4\uee1d粯粢糁簩粎簎糆糍糧籹籜籨籝籈簡粀㐄㑌㐯㒂㐥㒎㑟㑢㑄㓂㒓㓧㓶㒗㓹㑀襃襳襣觱襣觴褥褘褈覍觎覸覶覨覺襫\ue9b5\ue987\ue9aa\ue905\ue98d\ue929\ue9da\ue9c2\ue9f2\ue975\ue94c\ue974뉘눐뉳닞뉽닻눵눶눙능늝늪늪늎늛눜담뉆눝늜뉘늪눦뉛綨緤綵紒綍紜緅緟緣絀絹紿絞紿絫緳紑緅練紘믙뮕믄뭣민뭭뮴뮮뮒묱묈뭗묥묡묝믲龯鿧龦鼉龎鼟龃鿁鿧齶齆鼷⢦⢖⢆⠔⢆⠑⣏⢫瑿瑏瑟瓍瑟瓈琙琷琶璔璇璙璌璇瓻瑗匮卢匑厊匍厰卥卿卢口厫厲䱓䱴䱷䳲䱲䳠䰭䰳䰟䲼䲋䳈峸峟峜屙峙屋岆岘岴尗尠屣뉨뉏뉌닉뉉닛눖눈눤늇늰닳";
      char[] var8 = "\u13fe\u13fe\u13fe\u13fe\u13fe\u13feᏺ\u13feᏦᏦᏦᏦᏦᏺᏮᏢᏦᏺᏺ\u13fe\u13fe\u13fe\u13fe\u13fe\u13fe\u13feᏦᏦᏦᏦᏺᏮᏢᏦᏺ\u13feᏦᏺᏺᏺᏺ".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IIIII = var9;
            IIIIl = new Object[var9.length];
            int var2 = -1400099175;
            byte[] var0 = "Ò\u001fEyXTX\u008aEËªÖ?ò\u008ckfQC`T\u00adTLP¡'!áfë\u001d".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            llll = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               llll[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static String llll(int var0, int var1) {
      int var3 = var0 ^ 1338470859;
      char[] var4 = IIIII[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IIIIl[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IIIIl[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 1668990801;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 114;
               break;
            case 1:
               var9 = 98;
               break;
            case 2:
               var9 = 64;
               break;
            case 3:
               var9 = 248;
               break;
            case 4:
               var9 = 83;
               break;
            case 5:
               var9 = 253;
               break;
            case 6:
               var9 = 6;
               break;
            case 7:
               var9 = 40;
               break;
            case 8:
               var9 = 6;
               break;
            case 9:
               var9 = 161;
               break;
            case 10:
               var9 = 163;
               break;
            case 11:
               var9 = 186;
               break;
            case 12:
               var9 = 175;
               break;
            case 13:
               var9 = 185;
               break;
            case 14:
               var9 = 172;
               break;
            case 15:
               var9 = 13;
               break;
            case 16:
               var9 = 227;
               break;
            case 17:
               var9 = 79;
               break;
            case 18:
               var9 = 30;
               break;
            case 19:
               var9 = 150;
               break;
            case 20:
               var9 = 116;
               break;
            case 21:
               var9 = 183;
               break;
            case 22:
               var9 = 50;
               break;
            case 23:
               var9 = 69;
               break;
            case 24:
               var9 = 76;
               break;
            case 25:
               var9 = 220;
               break;
            case 26:
               var9 = 209;
               break;
            case 27:
               var9 = 151;
               break;
            case 28:
               var9 = 60;
               break;
            case 29:
               var9 = 225;
               break;
            case 30:
               var9 = 22;
               break;
            case 31:
               var9 = 32;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
