package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import net.minecraft.class_2350.class_2351;

@Environment(EnvType.CLIENT)
public final class lIlIlIIl {
   private static final int I = 6;
   private static final double l = 1.05;
   private static final int[] II;

   private lIlIlIIl() {
   }

   public static double I(class_1937 var0, double var1, double var3, double var5, double var7) {
      double var9 = Math.max((double)0.0F, var7 - 0.05);
      double var11 = Double.NEGATIVE_INFINITY;
      var11 = Math.max(var11, II(var0, var1, var3, var5));
      var11 = Math.max(var11, II(var0, var1 - var9, var3, var5 - var9));
      var11 = Math.max(var11, II(var0, var1 - var9, var3, var5 + var9));
      var11 = Math.max(var11, II(var0, var1 + var9, var3, var5 - var9));
      var11 = Math.max(var11, II(var0, var1 + var9, var3, var5 + var9));
      return var11;
   }

   public static class_243 l(class_1937 var0, class_1309 var1, class_243 var2, class_243 var3, double var4) {
      if (var0 != null && var1 != null && var3 != null) {
         double var6 = I(var0, var3.field_1352, var3.field_1351, var3.field_1350, (double)(var1.method_17681() / 2.0F));
         if (Double.isFinite(var6) && var6 != Double.NEGATIVE_INFINITY) {
            double var8 = var6 - var3.field_1351;
            if (!(var8 <= (double)0.0F) && !(var4 > 0.08)) {
               if (var8 <= 0.2) {
                  return new class_243(var3.field_1352, var6, var3.field_1350);
               } else {
                  return var8 <= 0.45 && var2 != null && Math.abs(var2.field_1351 - var6) <= 0.3 && var4 <= 0.02 ? new class_243(var3.field_1352, var6, var3.field_1350) : var3;
               }
            } else {
               return var3;
            }
         } else {
            return var3;
         }
      } else {
         return var3;
      }
   }

   private static double II(class_1937 var0, double var1, double var3, double var5) {
      int var7 = class_3532.method_15357(var3 + (double)1.0F);
      double var8 = Double.NEGATIVE_INFINITY;

      for(int var10 = 0; var10 < lI(-91923077, -1832238214); ++var10) {
         class_2338 var11 = class_2338.method_49637(var1, (double)(var7 - var10), var5);
         class_2680 var12 = var0.method_8320(var11);
         class_265 var13 = var12.method_26220(var0, var11);
         if (!var13.method_1110()) {
            double var14 = (double)var11.method_10264() + var13.method_1105(class_2351.field_11052);
            if (var14 <= var3 + 1.05) {
               var8 = Math.max(var8, var14);
            }
         }
      }

      return var8;
   }

   public static class_243 Il(class_1937 var0, class_243 var1, double var2) {
      if (var0 != null && var1 != null) {
         double var4 = I(var0, var1.field_1352, var1.field_1351, var1.field_1350, var2);
         return var4 != Double.NEGATIVE_INFINITY && var1.field_1351 < var4 ? new class_243(var1.field_1352, var4, var1.field_1350) : var1;
      } else {
         return var1;
      }
   }

   private static int lI(int var0, int var1) {
      return II[var0 ^ -91923077] ^ var1 ^ var0;
   }

   static {
      int var2 = -1551831313;
      byte[] var0 = "ËÏðè".getBytes("ISO-8859-1");
      int var1 = var0.length / 4;
      II = new int[var1];
      int var3 = 0;
      int var4 = 0;

      do {
         int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
         var5 ^= var2;
         II[var4] = var5;
         var3 += 4;
         ++var4;
      } while(var4 < var1);

   }
}
