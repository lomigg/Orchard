package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_745;

@Environment(EnvType.CLIENT)
public final class III extends IIIIIIIlI {
   private float I;
   private float l;
   private float II;
   private class_1297 Il;
   private static String[] lI;
   private final IIIllIIII ll;
   private class_745 III;
   private class_243 IIl;
   private class_243 IlI;
   private float Ill;
   private static final int[] lII;
   private static final String[] lIl;
   private static final Object[] llI;

   static {
      short var6 = 4633;
      String var7 = "쾿\u0a64\ue3d3䴚禘꥓鼢\ue309\uf881鲅绹\uf46a榲苫℃ⷻ㧯镛꘥핛\ue7c5멬\udee6槗붳嵂櫅┷ⷲ꿭뀾蓎ㄊᑴ⽭攤៣흥괋ꌕ咄쇼궈鱗\u0e72围틇㸍ꭐ鳣㑾蘓せ덶㥾\ued0e뇞ꚤ蛹욐鉛ꔙ㮣躥⩘뀄䐪権볕埻겶冚\ue4fa侖몀ㆬꕢ邧珍ꔜし벣픿俑頫썩\udf8f퀷";
      char[] var8 = "ሑቝሕ".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            lIl = var9;
            llI = new Object[var9.length];
            int var2 = -2031415034;
            byte[] var0 = "\u0015[Öp_ÆÁËká'\u0093º\\7MêÈ-²".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lII = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lII[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            lI = new String[3];
            llI();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 32;
                     break;
                  case 1:
                     var10000 = 39;
                     break;
                  case 2:
                     var10000 = 111;
                     break;
                  case 3:
                     var10000 = 69;
                     break;
                  case 4:
                     var10000 = 97;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public void I(float var1, float var2, float var3, float var4) {
      if (this.IIIIIlI() && this.III != null) {
         float var5 = class_3532.method_15393(var3 - var1);
         float var6 = var4 - var2;
         this.l = this.I;
         this.II = this.Ill;
         this.I += var5;
         this.Ill = class_3532.method_15363(this.Ill + var6, -90.0F, 90.0F);
         this.III.method_36456(this.I);
         this.III.method_36457(this.Ill);
      }
   }

   public boolean l(class_1297 var1) {
      return this.IIIIIlI() && var1 != null && this.IlI != null;
   }

   public class_243 II(float var1) {
      if (this.IlI == null) {
         return class_243.field_1353;
      } else {
         return this.IIl == null ? this.IlI : this.IIl.method_35590(this.IlI, (double)class_3532.method_15363(var1, 0.0F, 1.0F));
      }
   }

   private class_243 Il(double var1, double var3, double var5, float var7) {
      double var8 = Math.toRadians((double)var7);
      double var10 = Math.sin(var8);
      double var12 = Math.cos(var8);
      double var14 = var1 * -var10 + var3 * var12;
      double var16 = var1 * var12 + var3 * var10;
      return new class_243(var14, var5, var16);
   }

   public III() {
      super((Object)lIlIII.l(lI[2]), lIllII.ll, (Object)lIlIII.l(lI[1]));
      this.ll = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(lI[0]), (double)1.0F, 0.1, (double)10.0F, 0.1));
   }

   private void ll(class_310 var1) {
      if (var1 != null && this.III != null && IllllIlI.IlIllI(var1) == this.III) {
         Object var2 = this.Il != null ? this.Il : var1.field_1724;
         IllllIlI.lIlIII(var1, (class_1297)var2);
      }

      this.III = null;
      this.Il = null;
   }

   public float III(float var1) {
      return class_3532.method_17821(class_3532.method_15363(var1, 0.0F, 1.0F), this.l, this.I);
   }

   private static String IIl(char[] var0, long var1, int var3) {
      int var4 = lll(545276824, -1467720546) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & lll(545276825, -106064981);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   public void lI() {
      class_310 var1 = class_310.method_1551();
      this.ll(var1);
      this.IlI = null;
      this.IIl = null;
   }

   private double IlI(class_310 var1, class_304 var2, class_304 var3) {
      return (IllllIlI.IIIll(var1, var2) ? (double)1.0F : (double)0.0F) - (IllllIlI.IIIll(var1, var3) ? (double)1.0F : (double)0.0F);
   }

   public void lIl() {
      class_310 var1 = class_310.method_1551();
      this.ll(var1);
      if (var1 != null && var1.field_1724 != null) {
         this.IlI = var1.field_1724.method_5836(1.0F);
         this.IIl = this.IlI;
         this.I = var1.field_1724.method_36454();
         this.l = this.I;
         this.Ill = var1.field_1724.method_36455();
         this.II = this.Ill;
         this.Il = IllllIlI.IlIllI(var1);
         this.III = new class_745(var1.field_1687, var1.field_1724.method_7334());
         this.III.method_5719(var1.field_1724);
         this.III.field_5960 = true;
         IllllIlI.lIlIII(var1, this.III);
      } else {
         this.IlI = null;
         this.IIl = null;
      }
   }

   public float lII(float var1) {
      return class_3532.method_16439(class_3532.method_15363(var1, 0.0F, 1.0F), this.II, this.Ill);
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (var1 != null && var1.field_1724 != null) {
         if (this.IlI != null && this.III != null) {
            this.IIl = this.IlI;
            this.l = this.I;
            this.II = this.Ill;
            this.I = this.III.method_36454();
            this.Ill = this.III.method_36455();
            double var2 = this.IlI(var1, var1.field_1690.field_1894, var1.field_1690.field_1881);
            double var4 = this.IlI(var1, var1.field_1690.field_1913, var1.field_1690.field_1849);
            double var6 = this.IlI(var1, var1.field_1690.field_1903, var1.field_1690.field_1832);
            class_243 var8 = this.Il(var2, var4, var6, this.I);
            if (!(var8.method_1027() <= 1.0E-6)) {
               double var9 = (Double)this.ll.III() * (IllllIlI.IIIll(var1, var1.field_1690.field_1867) ? 0.42 : 0.18);
               this.IlI = this.IlI.method_1019(var8.method_1029().method_1021(var9));
               this.III.method_5814(this.IlI.field_1352, this.IlI.field_1351, this.IlI.field_1350);
            }
         } else {
            this.lIl();
         }
      } else {
         this.ll(var1);
         this.IlI = null;
         this.IIl = null;
      }
   }

   private static void llI() {
      lI[0] = IIl(IIII(-861846049, '钟', 713).toCharArray(), 18375L, lll(545276826, -1977268049));
      lI[1] = IIl(IIII(-442104088, '㋛', 712).toCharArray(), 66937L, lll(545276827, -45005718));
      lI[2] = IIl(IIII(1199323120, '잀', 715).toCharArray(), 56938L, lll(545276828, -1294889746));
   }

   private static int lll(int var0, int var1) {
      return lII[var0 ^ 545276824] ^ var1 ^ var0;
   }

   private static String IIII(int var0, char var1, int var2) {
      int var3 = var2 ^ 713;
      char[] var4 = lIl[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])llI[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         llI[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 27568;
      int var9 = 0;

      do {
         int var10 = var4[var9] - 6805;
         var10 += 55506;
         var10 += 33640;
         var10 -= 26011;
         var10 ^= 51761;
         var10 += 50129;
         var10 ^= 47910;
         var4[var9] = (char)(var10 ^ var8 ^ var1 ^ var0 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
