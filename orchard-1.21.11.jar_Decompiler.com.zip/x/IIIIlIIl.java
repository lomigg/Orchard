package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_310;
import net.minecraft.class_746;

@Environment(EnvType.CLIENT)
public final class IIIIlIIl extends IIIIIIIlI {
   private boolean I;
   private static String[] l;
   private static final int II = 2;
   private int Il;
   private static final int[] lI;
   private static final String[] ll;
   private static final Object[] III;

   public void lI() {
      this.IlI();
   }

   public float II() {
      return 0.0F;
   }

   public boolean ll(class_310 var1) {
      if (this.IIIIIlI() && var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1755 == null) {
         class_746 var2 = var1.field_1724;
         if (!this.IIll(var1, var2)) {
            this.IlI();
            return false;
         } else if (this.IlII(var1, var2)) {
            this.I = true;
            this.Il = 2;
            return true;
         } else if (this.I && this.Il > 0) {
            --this.Il;
            return true;
         } else {
            this.IlI();
            return false;
         }
      } else {
         this.IlI();
         return false;
      }
   }

   private void IlI() {
      this.I = false;
      this.Il = 0;
   }

   private static void lII() {
      l[0] = IlIl(lIII(-1040364897, 279538584).toCharArray(), 55335L, Illl(-673940103, -1376549250));
      l[1] = IlIl(lIII(-1040364898, 662375294).toCharArray(), 87585L, Illl(-673940104, 1397951559));
   }

   private boolean llI(class_310 var1) {
      return var1.field_1690.field_1894.method_1434() || var1.field_1690.field_1881.method_1434() || var1.field_1690.field_1849.method_1434() || var1.field_1690.field_1913.method_1434();
   }

   static {
      short var6 = 18643;
      String var7 = "謐ᩈ㔜᧽㕭鬒ꨠ杤缋疹㢉웴衾ꝁ毾\uf139Ὠ宀궃萺ᢸ⽾谱螚걺ﹹ枀䷼⪉풣呲ប\uf5cb荅遨㼌⌲눻ꚨ逘鱲ꞷ㗴꿑尜袂荏蓍臧ꋕ뷧檿⮺욍仍舽\udb37\uf443悜\uf513㗌홅灃栜\uf105湠唻ʙ㼫횬☰둒ڻ﮼㷶ߤ鴹❒\u0ba2煡뀨ퟀ꺡\ue60e얢洛蹛狲";
      char[] var8 = "䣟䢟".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            ll = var9;
            III = new Object[var9.length];
            int var2 = 2117634993;
            byte[] var0 = "c¿\u008cnçH\u0091N°\u009f]l¼º\u008dç".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lI = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lI[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            l = new String[2];
            lII();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public boolean lll() {
      return false;
   }

   public boolean IIII(class_310 var1) {
      if (this.IIIIIlI() && var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1690 != null && var1.field_1755 == null) {
         class_746 var2 = var1.field_1724;
         return var2.method_5805() && !var2.method_31549().field_7479 && !var2.method_5715() && !var2.method_6115() && !var2.method_6101() && !var2.method_5799() && !var2.method_5869() && !IllllIlI.IIllIII(var2) && var1.field_1690.field_1894.method_1434() && !var1.field_1690.field_1881.method_1434();
      } else {
         return false;
      }
   }

   private boolean IIll(class_310 var1, class_746 var2) {
      return var2.method_5805() && !var2.method_31549().field_7479 && !var2.method_5715() && !var1.field_1690.field_1903.method_1434() && !var2.method_6101() && !var2.method_5799() && !var2.method_5869() && !IllllIlI.IIllIII(var2) && this.llI(var1);
   }

   public IIIIlIIl() {
      super((Object)lIlIII.l(l[0]), lIllII.III, (Object)lIlIII.l(l[1]));
   }

   private boolean IlII(class_310 var1, class_746 var2) {
      if (!var2.method_24828()) {
         return false;
      } else {
         class_2338 var3 = class_2338.method_49637(var2.method_23317(), var2.method_23318() - (double)0.5F, var2.method_23321());
         if (var1.field_1687.method_8320(var3).method_26215()) {
            return true;
         } else {
            float var4 = 0.0F;
            float var5 = 0.0F;
            if (var1.field_1690.field_1894.method_1434()) {
               ++var4;
            }

            if (var1.field_1690.field_1881.method_1434()) {
               --var4;
            }

            if (var1.field_1690.field_1913.method_1434()) {
               ++var5;
            }

            if (var1.field_1690.field_1849.method_1434()) {
               --var5;
            }

            if (var4 == 0.0F && var5 == 0.0F) {
               return false;
            } else {
               double var6 = Math.sqrt((double)(var4 * var4 + var5 * var5));
               var4 /= (float)var6;
               var5 /= (float)var6;
               float var8 = (float)Math.toRadians((double)var2.method_36454());
               double var9 = Math.sin((double)var8);
               double var11 = Math.cos((double)var8);
               double var13 = -var9 * (double)var4 - var11 * (double)var5;
               double var15 = var11 * (double)var4 - var9 * (double)var5;

               for(double var20 : new double[]{0.05, 0.15, (double)0.25F, 0.35}) {
                  double var22 = var2.method_23317() + var13 * var20;
                  double var24 = var2.method_23321() + var15 * var20;
                  class_2338 var26 = class_2338.method_49637(var22, var2.method_23318() - (double)0.5F, var24);
                  if (var1.field_1687.method_8320(var26).method_26215()) {
                     return true;
                  }

                  class_238 var27 = var2.method_5829().method_989(var13 * var20, (double)-0.5F, var15 * var20);
                  if (!var1.field_1687.method_20812(var2, var27).iterator().hasNext()) {
                     return true;
                  }
               }

               <undefinedtype> var30 = lIlIll.IIl(var1, var2);
               return var30.ll() && var30.I();
            }
         }
      }
   }

   private static String IlIl(char[] var0, long var1, int var3) {
      int var4 = Illl(-673940101, -1170675411) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & Illl(-673940102, 357989331);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private static int Illl(int var0, int var1) {
      return lI[var0 ^ -673940103] ^ var1 ^ var0;
   }

   private static String lIII(int var0, int var1) {
      int var3 = var0 ^ -1040364897;
      char[] var4 = ll[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])III[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         III[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -962524465;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 160;
               break;
            case 1:
               var9 = 50;
               break;
            case 2:
               var9 = 81;
               break;
            case 3:
               var9 = 144;
               break;
            case 4:
               var9 = 118;
               break;
            case 5:
               var9 = 156;
               break;
            case 6:
               var9 = 197;
               break;
            case 7:
               var9 = 233;
               break;
            case 8:
               var9 = 221;
               break;
            case 9:
               var9 = 124;
               break;
            case 10:
               var9 = 247;
               break;
            case 11:
               var9 = 75;
               break;
            case 12:
               var9 = 222;
               break;
            case 13:
               var9 = 151;
               break;
            case 14:
               var9 = 91;
               break;
            case 15:
               var9 = 14;
               break;
            case 16:
               var9 = 86;
               break;
            case 17:
               var9 = 141;
               break;
            case 18:
               var9 = 214;
               break;
            case 19:
               var9 = 17;
               break;
            case 20:
               var9 = 93;
               break;
            case 21:
               var9 = 228;
               break;
            case 22:
               var9 = 162;
               break;
            case 23:
               var9 = 213;
               break;
            case 24:
               var9 = 21;
               break;
            case 25:
               var9 = 146;
               break;
            case 26:
               var9 = 15;
               break;
            case 27:
               var9 = 135;
               break;
            case 28:
               var9 = 95;
               break;
            case 29:
               var9 = 178;
               break;
            case 30:
               var9 = 21;
               break;
            case 31:
               var9 = 86;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
