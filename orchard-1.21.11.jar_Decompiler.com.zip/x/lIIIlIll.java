package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_268;
import net.minecraft.class_310;
import net.minecraft.class_5251;
import net.minecraft.class_746;
import net.minecraft.class_9334;

@Environment(EnvType.CLIENT)
public final class lIIIlIll extends IIIIIIIlI {
   private static String[] I;
   private static final class_1304[] l;
   private final lIIIIl II;
   private final lIIIIl Il;
   private final lIIIIl lI;
   private static final int[] ll;
   private static final String[] III;
   private static final Object[] IIl;

   private boolean I(class_1657 var1, class_1657 var2) {
      Integer var3 = this.ll(var1.method_5476());
      Integer var4 = this.ll(var2.method_5476());
      if (var3 == null) {
         var3 = this.III(var1.method_5781());
      }

      if (var4 == null) {
         var4 = this.III(var2.method_5781());
      }

      return var3 != null && var3.equals(var4);
   }

   public lIIIlIll() {
      super((Object)lIlIII.l(I[1]), lIllII.l, (Object)lIlIII.l(I[2]));
      this.Il = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(I[5]), true));
      this.lI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(I[3]), true));
      this.II = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(I[4]), true));
   }

   private boolean l(class_1657 var1, class_1657 var2) {
      for(class_1304 var6 : l) {
         String var7 = this.llI(var1.method_6118(var6));
         if (!var7.isEmpty()) {
            String var8 = this.llI(var2.method_6118(var6));
            if (var7.equals(var8)) {
               return true;
            }
         }
      }

      return false;
   }

   private boolean II(class_1657 var1, class_1657 var2) {
      class_268 var3 = var1.method_5781();
      class_268 var4 = var2.method_5781();
      if (var3 != null && var4 != null) {
         Integer var5 = this.III(var3);
         Integer var6 = this.III(var4);
         return var5 != null && var5.equals(var6);
      } else {
         return false;
      }
   }

   public boolean Il(class_1657 var1) {
      if (this.IIIIIlI() && var1 != null) {
         class_310 var2 = class_310.method_1551();
         if (var2 != null && var2.field_1724 != null && var1 != var2.field_1724) {
            class_746 var3 = var2.field_1724;
            return (Boolean)this.Il.III() && this.l(var3, var1) || (Boolean)this.lI.III() && this.II(var3, var1) || (Boolean)this.II.III() && this.I(var3, var1);
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private Integer ll(class_2561 var1) {
      if (var1 == null) {
         return null;
      } else {
         class_5251 var2 = var1.method_10866().method_10973();
         if (var2 != null) {
            return var2.method_27716();
         } else {
            for(class_2561 var4 : var1.method_10855()) {
               Integer var5 = this.ll(var4);
               if (var5 != null) {
                  return var5;
               }
            }

            return null;
         }
      }
   }

   static {
      short var6 = 6655;
      String var7 = "쭆쩄㓋ᑮ\uea04\ue583햝∜縟竂ᛸ쐎ฅ뇢圮\ue262⟜䄉횅ꙣ볥ㅑ␑뵆樃颰豛䇸ﺢ\u05cb휈\uf885\uf58b拷\uf435믱君\ue7de㷗円歧乊麈ﾄℏ殐㳐豬▐⦓쒦䂭潥캽积慞\uf66f\uf3ee餬롳㩂햩\ueb38ፋछ悡罻苲荢辇ꏈ竾\u0e71\uec38ᥞ\u0ff2仜̋ﺇ뿉誛㑊\uecd4㦳⮓佱ﰕ圴昡목鰲ꮩᖣ뮵䬢툜婪\uf017ᵇ쎦逡쭐ᱝ⍪襎◠瓈蒹熗풔㰑\uf79bꘞ\ue707㥌獹⠌鮥鋑썰\ue1ec쪡●ࣿ\uddd0瀴씇姭スȃ䟺櫏迏怱賅槙襛䴑懀ὖ䞡\uef7f\ue002䌟赦罹氟陆堺릂⨰悒\ue8a0㌘\uf7bc䷰";
      char[] var8 = "᧻᧷ᦧ᧯᧯᧯᧷".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            III = var9;
            IIl = new Object[var9.length];
            int var2 = 1937341955;
            byte[] var0 = "[Ç§&ê>À;´ê\u0017:òëû³\u0093Î(bÒ\u009bxG$Ðåe\"à:É¦p\u0004Ó&ç\bÚ`\u0095\u009eð¶\u001ekq-F\u0096¦\u0015ÃÑ\u0002¢ø\u008e{âÂ°7".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            ll = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               ll[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            I = new String[lll(-1755994553, -1075085462)];
            lII();
            l = new class_1304[]{class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166};
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 91;
                     break;
                  case 1:
                     var10000 = 45;
                     break;
                  case 2:
                     var10000 = 58;
                     break;
                  case 3:
                     var10000 = 77;
                     break;
                  case 4:
                     var10000 = 120;
                     break;
                  case 5:
                     var10000 = 116;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private Integer III(class_268 var1) {
      return var1 != null && var1.method_1202() != null ? var1.method_1202().method_532() : null;
   }

   private static String IIl(char[] var0, long var1, int var3) {
      int var4 = lll(-1755994554, 1431250413) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & lll(-1755994555, 1355206531);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private Integer IlI(class_1799 var1) {
      Object var2 = var1.method_58694(class_9334.field_49644);
      if (var2 == null) {
         return null;
      } else {
         try {
            Object var3 = var2.getClass().getMethod(lIlIII.Il(I[0])).invoke(var2);
            Integer var10000;
            if (var3 instanceof Number) {
               Number var4 = (Number)var3;
               var10000 = var4.intValue();
            } else {
               var10000 = null;
            }

            return var10000;
         } catch (ReflectiveOperationException var5) {
            return null;
         }
      }
   }

   private static void lII() {
      I[0] = IIl(IIII(1285317073, -1225044597).toCharArray(), 42019L, lll(-1755994556, -2080993910));
      I[1] = IIl(IIII(1285317072, 1568162659).toCharArray(), 96330L, lll(-1755994557, 1087592968));
      I[2] = IIl(IIII(1285317075, 1386885316).toCharArray(), 62791L, lll(-1755994558, -563940414));
      I[3] = IIl(IIII(1285317074, 723652373).toCharArray(), 12293L, lll(-1755994559, -1559538882));
      I[4] = IIl(IIII(1285317077, 1761881305).toCharArray(), 63594L, lll(-1755994560, 393980733));
      I[5] = IIl(IIII(1285317076, 2022524220).toCharArray(), 64797L, lll(-1755994545, -224455124));
      I[lll(-1755994546, -1026830191)] = IIl(IIII(1285317079, 2074504332).toCharArray(), 29120L, lll(-1755994547, 960220968));
      I[lll(-1755994548, 1379054393)] = IIl("".toCharArray(), 36107L, lll(-1755994549, -587955076));
   }

   private String llI(class_1799 var1) {
      if (var1 != null && !var1.method_7960()) {
         Integer var2 = this.IlI(var1);
         if (var2 != null) {
            String var3 = lIlIII.Il(I[lll(-1755994551, 1188320823)]);
            return var3 + var2;
         } else {
            return I[lll(-1755994552, 116287611)];
         }
      } else {
         return I[lll(-1755994550, -235992756)];
      }
   }

   private static int lll(int var0, int var1) {
      return ll[var0 ^ -1755994553] ^ var1 ^ var0;
   }

   private static String IIII(int var0, int var1) {
      int var3 = var0 ^ 1285317073;
      char[] var4 = III[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IIl[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IIl[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -144630163;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 218;
               break;
            case 1:
               var9 = 90;
               break;
            case 2:
               var9 = 132;
               break;
            case 3:
               var9 = 51;
               break;
            case 4:
               var9 = 90;
               break;
            case 5:
               var9 = 225;
               break;
            case 6:
               var9 = 225;
               break;
            case 7:
               var9 = 26;
               break;
            case 8:
               var9 = 160;
               break;
            case 9:
               var9 = 35;
               break;
            case 10:
               var9 = 201;
               break;
            case 11:
               var9 = 48;
               break;
            case 12:
               var9 = 183;
               break;
            case 13:
               var9 = 59;
               break;
            case 14:
               var9 = 140;
               break;
            case 15:
               var9 = 79;
               break;
            case 16:
               var9 = 200;
               break;
            case 17:
               var9 = 147;
               break;
            case 18:
               var9 = 130;
               break;
            case 19:
               var9 = 16;
               break;
            case 20:
               var9 = 228;
               break;
            case 21:
               var9 = 64;
               break;
            case 22:
               var9 = 179;
               break;
            case 23:
               var9 = 192;
               break;
            case 24:
               var9 = 237;
               break;
            case 25:
               var9 = 189;
               break;
            case 26:
               var9 = 154;
               break;
            case 27:
               var9 = 64;
               break;
            case 28:
               var9 = 68;
               break;
            case 29:
               var9 = 50;
               break;
            case 30:
               var9 = 189;
               break;
            case 31:
               var9 = 179;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
