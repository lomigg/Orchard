package x;

import java.util.Locale;
import java.util.Objects;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2596;
import net.minecraft.class_2886;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;

@Environment(EnvType.CLIENT)
public final class lIlllI extends IIIIIIIlI {
   private final lIIIIl I;
   private static final int l = 5;
   private final lIIIIl II;
   private final lIlllII Il;
   private final IIIllIIII lI;
   private static final int ll = 20;
   private static final int III = 5;
   private final lIIIIl IIl;
   private final IIIllIIII IlI;
   private static final int Ill = 26;
   private int lII;
   private final IIIllIIII lIl;
   private final IIIllIIII llI;
   private int lll;
   private boolean IIII;
   private boolean IIIl;
   private static final double IIlI = (double)8.0F;
   private final IIIllIIII IIll;
   private int IlII;
   private static final double IlIl = (Math.PI * 2D);
   private static String[] IllI;
   private static final int[] Illl;
   private static final String[] lIII;
   private static final Object[] lIIl;

   private static void ll() {
      IllI[0] = lllI(llIII(1216854308, -586851699).toCharArray(), 70448L, lIlll(1478253620, 1921959012));
      IllI[1] = lllI(llIII(1216854309, 1877822451).toCharArray(), 87931L, lIlll(1478253621, 1188929857));
      IllI[2] = lllI(llIII(1216854310, -447120714).toCharArray(), 76984L, lIlll(1478253622, 1876914692));
      IllI[3] = lllI(llIII(1216854311, -519676048).toCharArray(), 90203L, lIlll(1478253623, -83779470));
      IllI[4] = lllI(llIII(1216854304, 572525352).toCharArray(), 22732L, lIlll(1478253616, 107962456));
      IllI[5] = lllI(llIII(1216854305, -1308002497).toCharArray(), 49531L, lIlll(1478253617, -1431167834));
      IllI[lIlll(1478253618, 1345099611)] = lllI(llIII(1216854306, 1530218629).toCharArray(), 31798L, lIlll(1478253619, -539268138));
      IllI[lIlll(1478253628, -462690036)] = lllI(llIII(1216854307, -1071247576).toCharArray(), 4418L, lIlll(1478253629, -990278348));
      IllI[lIlll(1478253630, 914919666)] = lllI(llIII(1216854316, 2072731772).toCharArray(), 86966L, lIlll(1478253631, 859903505));
      IllI[lIlll(1478253624, 1340986884)] = lllI(llIII(1216854317, 2032618319).toCharArray(), 1193L, lIlll(1478253625, -883825209));
      IllI[lIlll(1478253626, -1354588535)] = lllI(llIII(1216854318, -123529707).toCharArray(), 91936L, lIlll(1478253627, -688955032));
      IllI[lIlll(1478253604, 1628907540)] = lllI(llIII(1216854319, -353756490).toCharArray(), 40147L, lIlll(1478253605, -1456940792));
      IllI[lIlll(1478253606, -494012418)] = lllI(llIII(1216854312, -210041759).toCharArray(), 84716L, lIlll(1478253607, 1051590322));
      IllI[lIlll(1478253600, 891346075)] = lllI(llIII(1216854313, 1881161422).toCharArray(), 13671L, lIlll(1478253601, -1583727999));
      IllI[lIlll(1478253602, -506904881)] = lllI(llIII(1216854314, 949832787).toCharArray(), 87231L, lIlll(1478253603, 278328592));
      IllI[lIlll(1478253612, -1725638439)] = lllI(llIII(1216854315, 250230980).toCharArray(), 86870L, lIlll(1478253613, 1972993530));
   }

   private long IlI() {
      return Math.max(50L, Math.min(300L, Math.round((Double)this.lIl.III())));
   }

   private int lII(class_310 var1) {
      return var1 != null && var1.field_1724 != null && this.IlII >= 0 ? Math.max(0, var1.field_1724.field_6012 - this.IlII) : 0;
   }

   private boolean llI(class_1309 var1) {
      return var1 != null && this.lll != lIlll(1478253614, 341071728) && var1.method_5628() != this.lll;
   }

   private class_1309 lll(class_310 var1) {
      class_1309 var2 = this.Il == null ? null : this.Il.Ill();
      if ((Boolean)this.II.III()) {
         if (this.IlllI(var1, var2) && var1.field_1724.method_5858(var2) <= (double)64.0F) {
            return var2;
         } else {
            class_1309 var13 = this.Il == null ? null : this.Il.llII();
            return this.IlllI(var1, var13) && var1.field_1724.method_5858(var13) <= (double)64.0F ? var13 : null;
         }
      } else if (this.IlllI(var1, var2) && var1.field_1724.method_5858(var2) <= (double)64.0F) {
         return var2;
      } else {
         class_1309 var3 = this.Il == null ? null : this.Il.llII();
         if (this.IlllI(var1, var3) && var1.field_1724.method_5858(var3) <= (double)64.0F) {
            return var3;
         } else {
            class_1657 var4 = null;
            double var5 = Double.POSITIVE_INFINITY;
            double var7 = (double)64.0F;

            for(class_1657 var10 : var1.field_1687.method_18456()) {
               if (this.IlllI(var1, var10)) {
                  double var11 = var1.field_1724.method_5858(var10);
                  if (var11 <= var7 && var11 < var5) {
                     var4 = var10;
                     var5 = var11;
                  }
               }
            }

            return var4;
         }
      }
   }

   private boolean IIII(class_310 var1) {
      if (IllllIlI.IIlIIll(var1)) {
         return true;
      } else {
         return var1 != null && var1.field_1690 != null && (var1.field_1690.field_1894.method_1434() || var1.field_1690.field_1881.method_1434() || var1.field_1690.field_1913.method_1434() || var1.field_1690.field_1849.method_1434());
      }
   }

   private void IIll(class_310 var1, class_1309 var2) {
      if (IIIIIlIll.IlIIIII(null.lI, null.II)) {
         this.IIIl = true;
         this.IlII = var1.field_1724.field_6012;
         this.lll = var2 == null ? lIlll(1478253615, 272715305) : var2.method_5628();
         IIIIIlIll.IIIlII();
      }
   }

   public lIlllI(lIlllII var1) {
      super((Object)lIlIII.l(IllI[lIlll(1478253608, 1025782013)]), lIllII.I, (Object)lIlIII.l(IllI[lIlll(1478253609, -1906283448)]));
      this.llI = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IllI[lIlll(1478253610, 445837821)]), (double)4.5F, (double)4.0F, (double)6.0F, 0.05)).IIl(lIlIII.Il(IllI[2])));
      this.lI = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IllI[lIlll(1478253611, -161966957)]), (double)15.0F, (double)5.0F, (double)20.0F, (double)1.0F)).IIl(lIlIII.Il(IllI[lIlll(1478253588, -756079638)])));
      this.lIl = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IllI[lIlll(1478253589, -731490549)]), (double)180.0F, (double)50.0F, (double)300.0F, (double)5.0F)).IIl(lIlIII.Il(IllI[lIlll(1478253590, -130186151)])));
      this.II = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IllI[lIlll(1478253591, -1191914707)]), false));
      this.IIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IllI[lIlll(1478253584, -1052086505)]), true));
      this.I = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IllI[lIlll(1478253585, -1880794803)]), true));
      this.IIll = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IllI[3]), (double)9.0F, (double)5.0F, (double)16.0F, (double)1.0F)).IIl(lIlIII.Il(IllI[4])));
      this.IlI = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(IllI[5]), (double)215.0F, (double)80.0F, (double)255.0F, (double)5.0F));
      this.IlII = lIlll(1478253586, -271966687);
      this.lll = lIlll(1478253587, 805355018);
      this.Il = var1;
      IIIllIIII var10000 = this.IIll;
      lIIIIl var10001 = this.I;
      Objects.requireNonNull(var10001);
      var10000.lIII(var10001::III);
      var10000 = this.IlI;
      var10001 = this.I;
      Objects.requireNonNull(var10001);
      var10000.lIII(var10001::III);
   }

   private void IlII() {
      this.IIIl = false;
      this.IlII = lIlll(1478253596, -868453431);
      this.IIII = false;
      this.lll = lIlll(1478253597, -735570155);
      this.lII = 0;
      IIIIIlIll.IIIlII();
   }

   private boolean IlIl(class_310 var1) {
      return var1 != null && var1.field_1724 != null && var1.field_1724.field_6012 >= this.lII;
   }

   public void IIIIllI(class_2596<?> var1) {
      if (this.IIIl && var1 instanceof class_2886 var2) {
         class_310 var3 = class_310.method_1551();
         if (var3 != null && var3.field_1724 != null && var3.field_1724.method_6128()) {
            class_1799 var4 = var3.field_1724.method_5998(var2.method_12551());
            if (var4.method_31574(class_1802.field_8639)) {
               this.IIllI(true);
               this.lIII(var3);
            }

         }
      }
   }

   public void III(class_1297 var1) {
      this.lIIll(var1);
   }

   public void Illl(class_310 var1) {
      this.lIlIl(var1);
      if (this.IIIl) {
         IIIIIlIll.IlIIIII(null.lI, null.II);
      }

   }

   private void lIII(class_310 var1) {
      this.IlII = var1 != null && var1.field_1724 != null ? var1.field_1724.field_6012 : lIlll(1478253598, 643976017);
      this.lII = var1 != null && var1.field_1724 != null ? var1.field_1724.field_6012 + 5 : 0;
   }

   private double lIIl(class_310 var1, class_1309 var2) {
      if (var1 != null && var1.field_1724 != null) {
         double var3 = var1.field_1724.method_18798().method_37267();
         if (var2 != null) {
            double var5 = var2.method_23317() - var1.field_1724.method_23317();
            double var7 = var2.method_23321() - var1.field_1724.method_23321();
            double var9 = Math.sqrt(var5 * var5 + var7 * var7);
            if (var9 > 1.0E-4) {
               double var11 = var5 / var9;
               double var13 = var7 / var9;
               double var15 = var1.field_1724.method_18798().field_1352 - var2.method_18798().field_1352;
               double var17 = var1.field_1724.method_18798().field_1350 - var2.method_18798().field_1350;
               double var19 = var15 * var11 + var17 * var13;
               if (var19 > (double)0.0F) {
                  var3 = var19;
               }
            }
         }

         return x.IlIllIl.lIl(var3);
      } else {
         return (double)3.0F;
      }
   }

   public void Ill() {
      this.lIlIl(class_310.method_1551());
   }

   private int llII() {
      return Math.max(5, Math.min(lIlll(1478253599, -1796383136), (int)Math.round((Double)this.lI.III())));
   }

   private static String lllI(char[] var0, long var1, int var3) {
      int var4 = lIlll(1478253592, 808522845) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & lIlll(1478253593, -208738669);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private boolean IIIII(class_310 var1, class_1309 var2) {
      double var3 = var1.field_1724.method_23317() - var2.method_23317();
      double var5 = var1.field_1724.method_23321() - var2.method_23321();
      double var7 = var1.field_1724.method_23320() - var2.method_23320();
      double var9 = Math.sqrt(var3 * var3 + var5 * var5);
      float var11 = (float)(Math.toDegrees(Math.atan2(var5, var3)) - (double)90.0F);
      float var12 = (float)(-Math.toDegrees(Math.atan2(var7, var9)));
      float var13 = Math.abs(class_3532.method_15393(var2.method_36454() - var11));
      float var14 = Math.abs(class_3532.method_15393(var2.method_36455() - var12));
      return var13 <= 12.0F && var14 <= 20.0F;
   }

   private String IIIIl(double var1) {
      return String.format(Locale.ROOT, lIlIII.Il(IllI[0]), var1);
   }

   private boolean IIIll(class_310 var1, class_1309 var2) {
      if (var2 == null) {
         return false;
      } else {
         double var3 = (double)var1.field_1724.method_5739(var2);
         return this.IIII(var1) && !this.lIIIl(var1, var2) && var3 > this.lIIl(var1, var2) && var3 <= this.Illll();
      }
   }

   private boolean IIlII(class_310 var1) {
      return this.IIIIIlI() && var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1755 == null && var1.field_1724.method_5805() && !var1.field_1724.method_6128() && var1.method_1562() != null;
   }

   private int IIlIl() {
      return 5;
   }

   static {
      short var6 = 1151;
      String var7 = "蚜鉵鯝䂉Ὓ잃\uda1e稬⿺겁뷦ꕦꌼ㘾诩\uf64c輺蘦왨ﵥ짆刞缟詣ᱩ\ue272ᨌ孼䶲䖭\udae9ꆭ棿窵茫嬤腷安勇ⲉ쇓닪㽊䃑፯躑㟠䱲釨昗梺뀿螧䑰ᢞ觢靴㫜繑ꌻ\uf3ca畳㟃항姐䳛Ƚ⃛䎭萾哱꘥\ue89d离͈\u0af6豝\ue8d8ꔷݛ㹜ᒓ㶡㨰\udc52䡊ᩮ搱ꜥȽ硞ⶠ얹녒జ嬙楎\udac3鸲Ꜭꮥ턒䑍ꅵ䥒푅㵾餞ᶍ紛䟩㱃䓥ᬎ脷昙⨁ꘖ駱튄\udbc5䗅닒栤\uea0aគ\ue425醭䵌(賎♺℉媝甃㞡\uf70d欳캽沬⼔塟땑㫯ﴩ\uf8c4꼠ﷷ\ue99c䋓绑儭뵆쥋懶ㄺ淀㚰ﵧ沖㈉燻\ue82e쾄雜䣿큨龮䘁\udf3cꀄ㈲㩅ᆯ簾䫐앺枠ᕦ\uf3bd빧欰䇷告瘐卂汌ⅱ徊縴\udd93跎ֿ㫂偁粌䛂坪\ue100\uffc0ꎇ\uea32贺蓬䬏\ue87d愇逻䕀嫱\uef5d\uf89a峅≮\ue1ce䈕푤㥚鉦兊幥䱕슪溉ʸ䀶踔䕴黺欎퍻珴䵘\u0ba6ꭲ\ue997⪆復鱱㝡켺垡\ud833췏쇻ⵤ\udcca✞碐ᛞᄵ츫覱祪ꩯ℃፸웕쎐푢雎\ue097ߡ걤壚㖦\uf238뒍⇘㒌\uf50f箽";
      char[] var8 = "\b\f\u0004\u0014\u0004\u0018\u0018\u0004\u0004\u0010\fX\f\b\f\u0014".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            lIII = var9;
            lIIl = new Object[var9.length];
            int var2 = 1045297769;
            byte[] var0 = "\u0081Ë\u0013@)ÕæÅw\u009eÑB}Sxº#\u0084é®\u008b¸\u0095®6}1\u0006æ\u0007³Ó\u0082:O^\u009cÑZIPÙ6\u00adÁe1T)¼p\\\u009c°îíÉ\u00138ÐÔ\u008d\u0014\u0094\u0007F\u008eRÅý`@\u0084ÜQ½!\u0083¼ZSqzßÞ\u001f\u0002Á\u0087\u0098\u0098\u008a\u0093½\t¼ÿu~\u0093ãÒ\u0011jò\u0005ñ7ö\u0010èo[u\u0096¶è1Ê\u0003|ÃW·\u0090\t2Ü´¾\u0085\u009f²7ñ{\u009el\"!Þ¥uU§\u001bÉaé´ÿ;\t\u009b¸ZÖQ\u0018p*mÕ¼2y±aÀ3í&ò¼ø\u0002¡7Q{\u0095ß@\u001cì5÷¬\u0097\u0011²9\u009e\u001e\u009eÙ\rO/C\u0004ÀL\u0092î8%ðÖë\u0080(".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            Illl = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               Illl[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            IllI = new String[lIlll(1478253594, -1973136945)];
            ll();
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 93;
                     break;
                  case 1:
                     var10000 = 79;
                     break;
                  case 2:
                     var10000 = 37;
                     break;
                  case 3:
                     var10000 = 117;
                     break;
                  case 4:
                     var10000 = 121;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private void IIllI(boolean var1) {
      if (this.IIIl) {
         IIIIIlIll.IIIlIIl(null.lI, var1);
      }

      this.IIIl = false;
      this.IIII = true;
   }

   private boolean IIlll(class_310 var1, class_1297 var2) {
      return var2 instanceof class_1657 && var1 != null && var1.field_1724 != null && var2 != var1.field_1724;
   }

   public void lIl() {
      this.IlII();
   }

   private boolean IlIII(class_310 var1) {
      if (this.IIIl && var1 != null && var1.field_1687 != null && this.lll != lIlll(1478253595, 1900024907)) {
         class_1297 var2 = var1.field_1687.method_8469(this.lll);
         boolean var10000;
         if (var2 instanceof class_1309) {
            class_1309 var3 = (class_1309)var2;
            if (IlIII.l(var3)) {
               var10000 = true;
               return var10000;
            }
         }

         var10000 = false;
         return var10000;
      } else {
         return false;
      }
   }

   public String Il() {
      if (this.IIIl) {
         String var5 = lIlIII.Il(IllI[1]);
         int var4 = this.lII(class_310.method_1551());
         String var1 = var5;
         return var1 + var4;
      } else {
         String var10000 = this.IIIIl(this.Illll());
         String var3 = lIlIII.Il(IllI[2]);
         String var2 = var10000;
         return var2 + var3;
      }
   }

   public boolean IlIIl() {
      return this.IIIIIlI() && this.IIIl;
   }

   private void IlIll(class_332 var1, double var2, double var4) {
      double var6 = (Double)this.IIll.III();
      double var8 = Math.max(1.6, var6 * 0.22);
      double var10 = (double)System.nanoTime() / (double)1.0E9F * (Math.PI * 2D) * 1.35;
      int var12 = Math.max(0, Math.min(lIlll(1478253572, -129025973), (int)Math.round((Double)this.IlI.III())));
      int var13 = lllIIlI.III().getRGB();

      for(int var14 = 0; var14 < lIlll(1478253573, 1797163317); ++var14) {
         double var15 = (double)var14 / (double)26.0F;
         double var17 = (double)(var14 + 1) / (double)26.0F;
         double var19 = var10 + var15 * Math.PI;
         double var21 = var10 + var17 * Math.PI;
         double var23 = 0.35 + 0.65 * var17;
         int var25 = Math.max(lIlll(1478253574, 1653730025), Math.min(lIlll(1478253575, -2006351007), (int)Math.round((double)var12 * var23)));
         int var26 = IIIlllIII.lI(var13, var25);
         double var27 = var2 + Math.cos(var19) * var6;
         double var29 = var4 + Math.sin(var19) * var6;
         double var31 = var2 + Math.cos(var21) * var6;
         double var33 = var4 + Math.sin(var21) * var6;
         IIIIIIllI.IlIlI(var1, var27, var29, var31, var33, var8, var26);
         if (var14 == 0 || var14 == lIlll(1478253568, -1329977768)) {
            IIIIIIllI.lIIII(var1, var14 == 0 ? var27 : var31, var14 == 0 ? var29 : var33, var8 * (double)0.5F, var26);
         }
      }

   }

   private boolean IllII(class_310 var1) {
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null) {
         for(class_1657 var3 : var1.field_1687.method_18456()) {
            if (this.IlllI(var1, var3)) {
               double var4 = var1.field_1724.method_18798().method_37267();
               double var6 = var3.method_23317() - var1.field_1724.method_23317();
               double var8 = var3.method_23321() - var1.field_1724.method_23321();
               double var10 = Math.sqrt(var6 * var6 + var8 * var8);
               if (var10 > 1.0E-4) {
                  double var12 = var6 / var10;
                  double var14 = var8 / var10;
                  double var16 = var1.field_1724.method_18798().field_1352 - var3.method_18798().field_1352;
                  double var18 = var1.field_1724.method_18798().field_1350 - var3.method_18798().field_1350;
                  double var20 = var16 * var12 + var18 * var14;
                  if (var20 > (double)0.0F) {
                     var4 = var20;
                  }
               }

               if (x.IlIllIl.IIlIl((double)var1.field_1724.method_5739(var3), var4)) {
                  return true;
               }
            }
         }

         return false;
      } else {
         return false;
      }
   }

   private boolean IllIl(class_310 var1, class_1309 var2) {
      int var3 = this.lII(var1);
      if (var3 >= this.lIlII()) {
         return true;
      } else if (this.IllII(var1)) {
         return true;
      } else if (this.IIII(var1) && var2 != null) {
         if (this.lIIIl(var1, var2)) {
            return true;
         } else {
            double var4 = (double)var1.field_1724.method_5739(var2);
            if (!(var4 > (double)8.0F) && !(var4 <= this.lIIl(var1, var2))) {
               if (var3 < this.IIlIl()) {
                  return false;
               } else {
                  return var3 >= this.llII() && !this.IIIII(var1, var2);
               }
            } else {
               return true;
            }
         }
      } else {
         return true;
      }
   }

   private boolean IlllI(class_310 var1, class_1309 var2) {
      return var1 != null && var1.field_1724 != null && var2 != null && var2 != var1.field_1724 && var2.method_5805() && !var2.method_31481() && !IlIII.l(var2);
   }

   private double Illll() {
      return class_3532.method_15350((Double)this.llI.III(), (double)4.0F, (double)6.0F);
   }

   public void lI() {
      this.IIllI(true);
      this.IlII();
   }

   private boolean lIIII(class_310 var1, boolean var2) {
      if ((Boolean)this.IIl.III() && this.IIIl) {
         this.IIllI(true);
         if (var2) {
            this.lIII(var1);
         }

         return true;
      } else {
         return false;
      }
   }

   private boolean lIIIl(class_310 var1, class_1309 var2) {
      if (var1 != null && var1.field_1724 != null && var1.field_1690 != null && var2 != null) {
         double var3 = (double)0.0F;
         double var5 = (double)0.0F;
         if (var1.field_1690.field_1894.method_1434()) {
            var3 += -Math.sin(Math.toRadians((double)var1.field_1724.method_36454()));
            var5 += Math.cos(Math.toRadians((double)var1.field_1724.method_36454()));
         }

         if (var1.field_1690.field_1881.method_1434()) {
            var3 -= -Math.sin(Math.toRadians((double)var1.field_1724.method_36454()));
            var5 -= Math.cos(Math.toRadians((double)var1.field_1724.method_36454()));
         }

         if (var1.field_1690.field_1913.method_1434()) {
            var3 += -Math.cos(Math.toRadians((double)var1.field_1724.method_36454()));
            var5 += -Math.sin(Math.toRadians((double)var1.field_1724.method_36454()));
         }

         if (var1.field_1690.field_1849.method_1434()) {
            var3 -= -Math.cos(Math.toRadians((double)var1.field_1724.method_36454()));
            var5 -= -Math.sin(Math.toRadians((double)var1.field_1724.method_36454()));
         }

         double var7 = Math.sqrt(var3 * var3 + var5 * var5);
         if (var7 < 1.0E-4) {
            return false;
         } else {
            double var9 = var2.method_23317() - var1.field_1724.method_23317();
            double var11 = var2.method_23321() - var1.field_1724.method_23321();
            double var13 = Math.sqrt(var9 * var9 + var11 * var11);
            if (var13 < 1.0E-4) {
               return false;
            } else {
               double var15 = var3 / var7 * (var9 / var13) + var5 / var7 * (var11 / var13);
               return var15 < -0.15;
            }
         }
      } else {
         return false;
      }
   }

   public void IIIlI(class_332 var1, int var2, int var3, float var4) {
      if ((Boolean)this.I.III() && this.IlIIl()) {
         class_310 var5 = class_310.method_1551();
         if (var5 != null && var5.method_22683() != null && var5.field_1724 != null && !var5.field_1690.field_1842) {
            double var6 = (double)var5.method_22683().method_4486() * (double)0.5F;
            double var8 = (double)var5.method_22683().method_4502() * (double)0.5F;
            this.IlIll(var1, var6, var8);
         }
      }
   }

   private double lIIlI(class_310 var1) {
      return this.lIIl(var1, (class_1309)null);
   }

   public boolean lIIll(class_1297 var1) {
      if (!this.IIIl) {
         return false;
      } else {
         class_310 var2 = class_310.method_1551();
         if (this.IIlll(var2, var1) && var2 != null && var2.field_1724 != null) {
            this.IIllI(true);
            this.lIII(var2);
            return true;
         } else {
            return false;
         }
      }
   }

   private int lIlII() {
      return this.llII();
   }

   private void lIlIl(class_310 var1) {
      if (!this.IIlII(var1)) {
         this.IIllI(false);
         this.IlII();
      } else if (!this.lIllI(var1)) {
         if (this.IlIII(var1)) {
            this.IIllI(false);
            this.lIII(var1);
         } else {
            class_1309 var2 = this.lll(var1);
            if (this.IIIl) {
               IIIIIlIll.llIll(null.lI, this.IlI());
               if (this.IllIl(var1, var2)) {
                  this.IIllI(false);
                  this.lIII(var1);
               }

            } else if (!IIIIIlIll.IlIIII()) {
               boolean var3 = this.IIIll(var1, var2);
               if (!var3 || this.llI(var2)) {
                  this.IIII = false;
               }

               if (!this.IIII && var3 && this.IlIl(var1)) {
                  this.IIll(var1, var2);
               }

            }
         }
      }
   }

   private boolean lIllI(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         return var1.field_1724.field_6235 >= 2 && this.lIIII(var1, true);
      } else {
         return false;
      }
   }

   private static int lIlll(int var0, int var1) {
      return Illl[var0 ^ 1478253620] ^ var1 ^ var0;
   }

   private static String llIII(int var0, int var1) {
      int var3 = var0 ^ 1216854308;
      char[] var4 = lIII[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])lIIl[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         lIIl[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -645908204;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 218;
               break;
            case 1:
               var9 = 255;
               break;
            case 2:
               var9 = 161;
               break;
            case 3:
               var9 = 28;
               break;
            case 4:
               var9 = 152;
               break;
            case 5:
               var9 = 36;
               break;
            case 6:
               var9 = 130;
               break;
            case 7:
               var9 = 203;
               break;
            case 8:
               var9 = 101;
               break;
            case 9:
               var9 = 86;
               break;
            case 10:
               var9 = 48;
               break;
            case 11:
               var9 = 161;
               break;
            case 12:
               var9 = 254;
               break;
            case 13:
               var9 = 185;
               break;
            case 14:
               var9 = 202;
               break;
            case 15:
               var9 = 9;
               break;
            case 16:
               var9 = 67;
               break;
            case 17:
               var9 = 217;
               break;
            case 18:
               var9 = 158;
               break;
            case 19:
               var9 = 133;
               break;
            case 20:
               var9 = 97;
               break;
            case 21:
               var9 = 231;
               break;
            case 22:
               var9 = 138;
               break;
            case 23:
               var9 = 150;
               break;
            case 24:
               var9 = 62;
               break;
            case 25:
               var9 = 107;
               break;
            case 26:
               var9 = 81;
               break;
            case 27:
               var9 = 238;
               break;
            case 28:
               var9 = 24;
               break;
            case 29:
               var9 = 36;
               break;
            case 30:
               var9 = 80;
               break;
            case 31:
               var9 = 56;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
