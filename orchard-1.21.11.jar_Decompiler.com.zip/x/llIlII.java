package x;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_490;
import net.minecraft.class_5134;
import net.minecraft.class_6880;
import net.minecraft.class_746;
import net.minecraft.class_7923;
import net.minecraft.class_9285;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

@Environment(EnvType.CLIENT)
public final class llIlII extends IIIIIIIlI {
   private static final int I = 36;
   private final llllIlIl l;
   private static final int II = 8;
   private static final int Il = 6;
   private final lIIIIl lI;
   private final lIIIIl ll;
   private static String[] III;
   private final lIIIIl IIl;
   private final lIIIIl IlI;
   private static final int Ill = 9;
   private long lII;
   private static final int lIl = 7;
   private static final int[] llI;
   private final IlIIIlIlI<IIlllIllI> lll;
   private static final int IIII = 45;
   private final lIIIIl IIIl;
   private static final int IIlI = 5;
   private long IIll;
   private static final Set<String> IlII;
   private static final int[] IlIl;
   private static final String[] IllI;
   private static final Object[] Illl;

   private boolean ll(class_310 var1) {
      boolean var10000;
      switch ((IIlllIllI)this.lll.III()) {
         case I -> var10000 = lIlIllll.IlIl(var1);
         case ll -> var10000 = lIlIllll.lIl(var1);
         case Il -> var10000 = lIlIllll.IIIII(var1);
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   private <undefinedtype> IlI(class_746 var1) {
      HashMap var2 = new HashMap();

      for(int var6 : llI) {
         class_1799 var7 = this.Illll(var1, var6);
         if (!var7.method_7960() && !this.IIlll(var7)) {
            String var8 = this.lIIII(var7);
            if (var8 != null) {
               Record var9 = new Record(var6, this.IIIIl(var7), this.IIlIl(var6)) {
                  private final double I;
                  private final int l;
                  private final int II;

                  public double I() {
                     return this.I;
                  }

                  public int l() {
                     return this.l;
                  }

                  public int II() {
                     return this.II;
                  }

                  private {
                     this.l = var1;
                     this.I = var2;
                     this.II = var4;
                  }

                  boolean Il(Object var1) {
                     if (this.I > var1.I + 1.0E-4) {
                        return true;
                     } else if (Math.abs(this.I - var1.I) <= 1.0E-4 && this.II > var1.II) {
                        return true;
                     } else {
                        return Math.abs(this.I - var1.I) <= 1.0E-4 && this.II == var1.II && this.l < var1.l;
                     }
                  }
               };
               <undefinedtype> var10 = (<undefinedtype>)var2.get(var8);
               if (var10 == null || ((<undefinedtype>)var9).Il(var10)) {
                  var2.put(var8, var9);
               }
            }
         }
      }

      HashMap var12 = new HashMap();

      for(int var19 : llI) {
         class_1799 var21 = this.Illll(var1, var19);
         if (!var21.method_7960() && !this.IIlll(var21) && !var21.method_7946() && this.lIIII(var21) == null && !this.lll(var21) && !this.IIll(var21)) {
            String var23 = this.IlIII(var21);
            Record var25 = new Record(var19, this.IIIIl(var21), this.IIlIl(var19)) {
               private final double I;
               private final int l;
               private final int II;

               public double I() {
                  return this.I;
               }

               public int l() {
                  return this.l;
               }

               public int II() {
                  return this.II;
               }

               private {
                  this.l = var1;
                  this.I = var2;
                  this.II = var4;
               }

               boolean Il(Object var1) {
                  if (this.I > var1.I + 1.0E-4) {
                     return true;
                  } else if (Math.abs(this.I - var1.I) <= 1.0E-4 && this.II > var1.II) {
                     return true;
                  } else {
                     return Math.abs(this.I - var1.I) <= 1.0E-4 && this.II == var1.II && this.l < var1.l;
                  }
               }
            };
            <undefinedtype> var11 = (<undefinedtype>)var12.get(var23);
            if (var11 == null || ((<undefinedtype>)var25).Il(var11)) {
               var12.put(var23, var25);
            }
         }
      }

      Object var14 = new Object() {
         private final Set<Integer> I = new HashSet();

         void I(int var1) {
            this.I.add(var1);
         }

         boolean l() {
            return !this.I.isEmpty();
         }

         boolean II(int var1) {
            return this.I.contains(var1);
         }
      };

      for(int var22 : llI) {
         class_1799 var24 = this.Illll(var1, var22);
         if (!var24.method_7960() && !IIII(var22) && !this.IIlll(var24)) {
            if ((Boolean)this.IIl.III() && this.IIll(var24)) {
               ((<undefinedtype>)var14).I(var22);
            } else {
               String var26 = this.lIIII(var24);
               if (var26 != null) {
                  <undefinedtype> var27 = (<undefinedtype>)var2.get(var26);
                  if (var27 != null && var27.l != var22) {
                     ((<undefinedtype>)var14).I(var22);
                  }
               } else if (!var24.method_7946() && !this.lll(var24)) {
                  <undefinedtype> var28 = (<undefinedtype>)var12.get(this.IlIII(var24));
                  if (var28 != null && var28.l != var22) {
                     ((<undefinedtype>)var14).I(var22);
                  }
               }
            }
         }
      }

      return (<undefinedtype>)(((<undefinedtype>)var14).l() ? var14 : null);
   }

   private double llI(class_1799 var1) {
      class_9304 var2 = (class_9304)var1.method_58695(class_9334.field_49633, class_9304.field_49385);
      double var3 = (double)0.0F;

      for(class_6880 var6 : var2.method_57534()) {
         String var7 = (String)var6.method_40230().map((var0) -> var0.method_29177().method_12832()).orElse(III[lIlII(-1051482740, -2102253464)]);
         int var8 = var2.method_57536(var6);
         var3 += (double)var8 * this.llII(var7);
      }

      return var3;
   }

   private boolean lll(class_1799 var1) {
      if (var1.method_7960()) {
         return true;
      } else {
         String var2 = lIIll(var1);
         boolean var10000;
         if (!var2.contains(lIlIII.Il(III[lIlII(-1051482739, -969656610)])) && !var2.equals(lIlIII.Il(III[lIlII(-1051482738, -309294667)])) && !var2.equals(lIlIII.Il(III[lIlII(-1051482737, -1298370566)])) && !var2.equals(lIlIII.Il(III[lIlII(-1051482744, 254147601)])) && !var2.equals(lIlIII.Il(III[lIlII(-1051482743, -1163499913)])) && !var2.equals(lIlIII.Il(III[lIlII(-1051482742, -609067671)]))) {
            String var10001 = lIlIII.Il(III[lIlII(-1051482741, -1394203033)]);
            String var4 = lIlIII.Il(III[lIlII(-1051482748, 1327456951)]);
            String var3 = var10001;
            if (!var2.equals(var3 + var4) && !var2.equals(lIlIII.Il(III[lIlII(-1051482747, 849691354)])) && !var2.equals(lIlIII.Il(III[lIlII(-1051482746, -1397146061)])) && !var2.equals(lIlIII.Il(III[lIlII(-1051482745, -59107045)])) && !var2.equals(lIlIII.Il(III[lIlII(-1051482752, 396751768)])) && !var2.equals(lIlIII.Il(III[lIlII(-1051482751, 1803839878)])) && !var2.equals(lIlIII.Il(III[lIlII(-1051482750, -384367134)])) && !var2.equals(lIlIII.Il(III[lIlII(-1051482749, 361545590)])) && !var2.equals(lIlIII.Il(III[lIlII(-1051482724, -1449953420)])) && !var2.equals(lIlIII.Il(III[lIlII(-1051482723, 508224472)])) && !var2.equals(lIlIII.Il(III[lIlII(-1051482722, -755977001)])) && !var2.equals(lIlIII.Il(III[lIlII(-1051482721, 1264029996)])) && !var2.equals(lIlIII.Il(III[lIlII(-1051482728, -618849715)])) && !var2.endsWith(lIlIII.Il(III[lIlII(-1051482727, -256384929)])) && !var2.endsWith(lIlIII.Il(III[lIlII(-1051482726, -1405711948)])) && !var2.endsWith(lIlIII.Il(III[lIlII(-1051482725, 737441450)])) && !var2.endsWith(lIlIII.Il(III[lIlII(-1051482732, 1546089646)])) && !var2.endsWith(lIlIII.Il(III[lIlII(-1051482731, 515391475)])) && !var2.endsWith(lIlIII.Il(III[lIlII(-1051482730, 2050989773)])) && !var2.startsWith(lIlIII.Il(III[lIlII(-1051482729, -1552262547)])) && !var2.endsWith(lIlIII.Il(III[lIlII(-1051482736, -807491278)])) && !var2.endsWith(lIlIII.Il(III[lIlII(-1051482735, -727585750)]))) {
               var10000 = false;
               return var10000;
            }
         }

         var10000 = true;
         return var10000;
      }
   }

   private static boolean IIII(int var0) {
      return var0 >= 5 && var0 <= lIlII(-1051482734, 1554071526) || var0 == lIlII(-1051482733, -658579653);
   }

   private boolean IIll(class_1799 var1) {
      return !var1.method_7960() && IlII.contains(lIIll(var1));
   }

   private double IlII(String var1) {
      if (var1.startsWith(lIlIII.Il(III[lIlII(-1051482708, -460336242)]))) {
         return (double)700.0F;
      } else if (var1.startsWith(lIlIII.Il(III[lIlII(-1051482707, -1153600714)]))) {
         return (double)600.0F;
      } else if (var1.startsWith(lIlIII.Il(III[lIlII(-1051482706, 2040349343)]))) {
         return (double)500.0F;
      } else if (var1.startsWith(lIlIII.Il(III[lIlII(-1051482705, 1097681969)]))) {
         return (double)440.0F;
      } else if (var1.startsWith(lIlIII.Il(III[lIlII(-1051482712, -1163845296)]))) {
         return (double)420.0F;
      } else if (var1.startsWith(lIlIII.Il(III[lIlII(-1051482711, -596414171)]))) {
         return (double)310.0F;
      } else if (var1.startsWith(lIlIII.Il(III[lIlII(-1051482710, -2039841267)]))) {
         return (double)180.0F;
      } else if (var1.startsWith(lIlIII.Il(III[lIlII(-1051482709, 1258789768)]))) {
         return (double)700.0F;
      } else if (var1.startsWith(lIlIII.Il(III[lIlII(-1051482716, -1355687046)]))) {
         return (double)600.0F;
      } else if (var1.startsWith(lIlIII.Il(III[lIlII(-1051482715, -1485685886)]))) {
         return (double)500.0F;
      } else if (var1.startsWith(lIlIII.Il(III[lIlII(-1051482714, 952259860)]))) {
         return (double)440.0F;
      } else if (var1.startsWith(lIlIII.Il(III[lIlII(-1051482713, 558415244)]))) {
         return (double)420.0F;
      } else if (var1.startsWith(lIlIII.Il(III[lIlII(-1051482720, -530547782)]))) {
         return (double)350.0F;
      } else if (var1.startsWith(lIlIII.Il(III[lIlII(-1051482719, 1831647855)]))) {
         return (double)310.0F;
      } else if (var1.startsWith(lIlIII.Il(III[lIlII(-1051482718, -1091991314)]))) {
         return (double)220.0F;
      } else {
         return var1.startsWith(lIlIII.Il(III[lIlII(-1051482717, 335136319)])) ? (double)180.0F : (double)300.0F;
      }
   }

   private long IlIl() {
      double var1 = this.l.IlII();
      double var3 = this.l.IlI();
      return var1 == var3 ? Math.round(var1) : Math.round(ThreadLocalRandom.current().nextDouble(var1, var3));
   }

   private boolean Illl(class_310 var1) {
      return var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var1.field_1724.field_7498 != null && var1.field_1724.method_5805();
   }

   public boolean lIII(class_746 var1, class_1799 var2) {
      if (var1 != null && var2 != null && !var2.method_7960()) {
         if (this.IIlll(var2)) {
            return false;
         } else if ((Boolean)this.IIl.III() && this.IIll(var2)) {
            return true;
         } else {
            String var3 = this.lIIII(var2);
            Record var4 = new Record(-1, this.IIIIl(var2), lIlII(-1051482692, -2076101727)) {
               private final double I;
               private final int l;
               private final int II;

               public double I() {
                  return this.I;
               }

               public int l() {
                  return this.l;
               }

               public int II() {
                  return this.II;
               }

               private {
                  this.l = var1;
                  this.I = var2;
                  this.II = var4;
               }

               boolean Il(Object var1) {
                  if (this.I > var1.I + 1.0E-4) {
                     return true;
                  } else if (Math.abs(this.I - var1.I) <= 1.0E-4 && this.II > var1.II) {
                     return true;
                  } else {
                     return Math.abs(this.I - var1.I) <= 1.0E-4 && this.II == var1.II && this.l < var1.l;
                  }
               }
            };
            if (var3 != null) {
               <undefinedtype> var6 = this.IlIIl(var1, var3);
               return var6 != null && var6.Il(var4);
            } else if (!var2.method_7946() && !this.lll(var2)) {
               <undefinedtype> var5 = this.IIllI(var1, this.IlIII(var2));
               return var5 != null && var5.Il(var4);
            } else {
               return false;
            }
         }
      } else {
         return false;
      }
   }

   private static void lIIl() {
      III[0] = IIIll(lIlIl(1885538336, 37246, 4612).toCharArray(), 47314L, lIlII(-1051482691, 1811531460));
      III[1] = IIIll(lIlIl(399323554, 46412, 4613).toCharArray(), 7234L, lIlII(-1051482690, 1688180378));
      III[2] = IIIll(lIlIl(-2050075117, 21791, 4614).toCharArray(), 31113L, lIlII(-1051482689, -509775527));
      III[3] = IIIll(lIlIl(333341056, 8334, 4615).toCharArray(), 58391L, lIlII(-1051482696, -1085352764));
      III[4] = IIIll(lIlIl(59378613, 34434, 4608).toCharArray(), 66711L, lIlII(-1051482695, 1970283707));
      III[5] = IIIll(lIlIl(-437179893, 36803, 4609).toCharArray(), 9335L, lIlII(-1051482694, -769808576));
      III[lIlII(-1051482693, 1677142807)] = IIIll(lIlIl(1710454581, 33542, 4610).toCharArray(), 81557L, lIlII(-1051482700, 15744829));
      III[lIlII(-1051482699, -977273641)] = IIIll(lIlIl(-839419207, 39186, 4611).toCharArray(), 35456L, lIlII(-1051482698, -1335179627));
      III[lIlII(-1051482697, -433472218)] = IIIll(lIlIl(-1389010938, 7135, 4620).toCharArray(), 77827L, lIlII(-1051482704, 289534510));
      III[lIlII(-1051482703, -366230385)] = IIIll(lIlIl(-390388010, 35741, 4621).toCharArray(), 331L, lIlII(-1051482702, -1595087421));
      III[lIlII(-1051482701, -1522516008)] = IIIll(lIlIl(-1291184216, 8839, 4622).toCharArray(), 58982L, lIlII(-1051482676, -1625260910));
      III[lIlII(-1051482675, 639694763)] = IIIll(lIlIl(240387399, 26499, 4623).toCharArray(), 54861L, lIlII(-1051482674, -1569802949));
      III[lIlII(-1051482673, -514840409)] = IIIll(lIlIl(598703787, 15802, 4616).toCharArray(), 17062L, lIlII(-1051482680, -1585229172));
      III[lIlII(-1051482679, 1264575655)] = IIIll(lIlIl(-1291315874, 16253, 4617).toCharArray(), 93590L, lIlII(-1051482678, 1929953443));
      III[lIlII(-1051482677, -1412609510)] = IIIll(lIlIl(-1458629326, 32025, 4618).toCharArray(), 73672L, lIlII(-1051482684, -436190469));
      III[lIlII(-1051482683, 1588929802)] = IIIll(lIlIl(1330457051, 31586, 4619).toCharArray(), 3012L, lIlII(-1051482682, -782959658));
      III[lIlII(-1051482681, -37197800)] = IIIll(lIlIl(1808883926, 38339, 4628).toCharArray(), 64339L, lIlII(-1051482688, -1850594334));
      III[lIlII(-1051482687, 72452137)] = IIIll(lIlIl(658972064, 1794, 4629).toCharArray(), 78970L, lIlII(-1051482686, -52441614));
      III[lIlII(-1051482685, 2007572563)] = IIIll(lIlIl(1137656635, 7996, 4630).toCharArray(), 20306L, lIlII(-1051482660, 1145592087));
      III[lIlII(-1051482659, 1687953727)] = IIIll(lIlIl(-1338289397, 2261, 4631).toCharArray(), 6623L, lIlII(-1051482658, -1110658930));
      III[lIlII(-1051482657, -1455503362)] = IIIll(lIlIl(303250170, 62726, 4624).toCharArray(), 45103L, lIlII(-1051482664, 105467268));
      III[lIlII(-1051482663, -980382931)] = IIIll(lIlIl(-936886518, 60600, 4625).toCharArray(), 27259L, lIlII(-1051482662, 1384745430));
      III[lIlII(-1051482661, -98621782)] = IIIll(lIlIl(1859089041, 52144, 4626).toCharArray(), 9913L, lIlII(-1051482668, -1399101520));
      III[lIlII(-1051482667, 933209148)] = IIIll(lIlIl(-673626625, 31600, 4627).toCharArray(), 40762L, lIlII(-1051482666, -859237324));
      III[lIlII(-1051482665, 722436766)] = IIIll(lIlIl(1222469254, 21906, 4636).toCharArray(), 12849L, lIlII(-1051482672, 901890689));
      III[lIlII(-1051482671, 79088351)] = IIIll(lIlIl(-1805224561, 52567, 4637).toCharArray(), 78261L, lIlII(-1051482670, -1697897504));
      III[lIlII(-1051482669, 275338925)] = IIIll(lIlIl(-619639426, 53085, 4638).toCharArray(), 82695L, lIlII(-1051482644, -1283048175));
      III[lIlII(-1051482643, -115056857)] = IIIll(lIlIl(-143977915, 32451, 4639).toCharArray(), 63896L, lIlII(-1051482642, -812577063));
      III[lIlII(-1051482641, 800466916)] = IIIll(lIlIl(1683173773, 24131, 4632).toCharArray(), 96499L, lIlII(-1051482648, 414162138));
      III[lIlII(-1051482647, 1560815573)] = IIIll(lIlIl(2009693298, 42752, 4633).toCharArray(), 10158L, lIlII(-1051482646, 1493267593));
      III[lIlII(-1051482645, -304085240)] = IIIll(lIlIl(-1918487586, 45827, 4634).toCharArray(), 46048L, lIlII(-1051482652, -1236170284));
      III[lIlII(-1051482651, 1747703981)] = IIIll(lIlIl(1012488050, 13145, 4635).toCharArray(), 54273L, lIlII(-1051482650, -1323729479));
      III[lIlII(-1051482649, -236378583)] = IIIll(lIlIl(-2129844433, 24707, 4644).toCharArray(), 92109L, lIlII(-1051482656, -802682656));
      III[lIlII(-1051482655, 1820148733)] = IIIll(lIlIl(-920041251, 59704, 4645).toCharArray(), 62928L, lIlII(-1051482654, -1694795617));
      III[lIlII(-1051482653, 1867482845)] = IIIll(lIlIl(-1888657938, 44544, 4646).toCharArray(), 20109L, lIlII(-1051482628, 910554203));
      III[lIlII(-1051482627, -563006649)] = IIIll(lIlIl(1572034770, 37134, 4647).toCharArray(), 67689L, lIlII(-1051482626, 263049027));
      III[lIlII(-1051482625, 993302178)] = IIIll(lIlIl(750678969, 6424, 4640).toCharArray(), 52398L, lIlII(-1051482632, 80312883));
      III[lIlII(-1051482631, 1343169698)] = IIIll(lIlIl(-805146395, 11641, 4641).toCharArray(), 42339L, lIlII(-1051482630, 805259759));
      III[lIlII(-1051482629, 1487185485)] = IIIll(lIlIl(-397393350, 25419, 4642).toCharArray(), 60925L, lIlII(-1051482636, -742438434));
      III[lIlII(-1051482635, -554422458)] = IIIll(lIlIl(797378284, 41144, 4643).toCharArray(), 10860L, lIlII(-1051482634, 1881961183));
      III[lIlII(-1051482633, 896705813)] = IIIll(lIlIl(-984154041, 20556, 4652).toCharArray(), 35627L, lIlII(-1051482640, -1511328149));
      III[lIlII(-1051482639, -549843760)] = IIIll(lIlIl(-1484369863, 15876, 4653).toCharArray(), 94043L, lIlII(-1051482638, 1646519361));
      III[lIlII(-1051482637, 773652276)] = IIIll(lIlIl(880364711, 917, 4654).toCharArray(), 89374L, lIlII(-1051482868, -797343121));
      III[lIlII(-1051482867, 833976347)] = IIIll(lIlIl(-1134347524, 42087, 4655).toCharArray(), 27812L, lIlII(-1051482866, 236172037));
      III[lIlII(-1051482865, -73277472)] = IIIll(lIlIl(1671247201, 60624, 4648).toCharArray(), 61506L, lIlII(-1051482872, 147332851));
      III[lIlII(-1051482871, 1149450306)] = IIIll(lIlIl(-1729949927, 42317, 4649).toCharArray(), 81871L, lIlII(-1051482870, -270779913));
      III[lIlII(-1051482869, -2035286047)] = IIIll(lIlIl(1979850193, 15265, 4650).toCharArray(), 31026L, lIlII(-1051482876, -1040792854));
      III[lIlII(-1051482875, -674657917)] = IIIll(lIlIl(-723690073, 23051, 4651).toCharArray(), 65103L, lIlII(-1051482874, -1822019824));
      III[lIlII(-1051482873, -206766037)] = IIIll(lIlIl(-839176259, 25767, 4660).toCharArray(), 16429L, lIlII(-1051482880, -1520839927));
      III[lIlII(-1051482879, 633607861)] = IIIll(lIlIl(913451426, 24441, 4661).toCharArray(), 82774L, lIlII(-1051482878, 1919007347));
      III[lIlII(-1051482877, -697895146)] = IIIll(lIlIl(-286962362, 9513, 4662).toCharArray(), 52114L, lIlII(-1051482852, -942213157));
      III[lIlII(-1051482851, 353135571)] = IIIll(lIlIl(-944370288, 49933, 4663).toCharArray(), 92573L, lIlII(-1051482850, -373577240));
      III[lIlII(-1051482849, 71906429)] = IIIll(lIlIl(1949661138, 190, 4656).toCharArray(), 76402L, lIlII(-1051482856, 848272893));
      III[lIlII(-1051482855, -2000715591)] = IIIll(lIlIl(955725392, 24818, 4657).toCharArray(), 91774L, lIlII(-1051482854, -452568765));
      III[lIlII(-1051482853, -1654963298)] = IIIll(lIlIl(-349091582, 51208, 4658).toCharArray(), 81771L, lIlII(-1051482860, -1890124800));
      III[lIlII(-1051482859, 1200057083)] = IIIll(lIlIl(853161224, 28655, 4659).toCharArray(), 70914L, lIlII(-1051482858, 1060522193));
      III[lIlII(-1051482857, 474832376)] = IIIll(lIlIl(705570679, 19263, 4668).toCharArray(), 97264L, lIlII(-1051482864, 1933773172));
      III[lIlII(-1051482863, -513740947)] = IIIll(lIlIl(-1656414676, 37050, 4669).toCharArray(), 47404L, lIlII(-1051482862, 1040378361));
      III[lIlII(-1051482861, 1794311033)] = IIIll(lIlIl(-141403704, 63648, 4670).toCharArray(), 52995L, lIlII(-1051482836, 137285430));
      III[lIlII(-1051482835, 312971254)] = IIIll(lIlIl(605753709, 56093, 4671).toCharArray(), 46534L, lIlII(-1051482834, -887463972));
      III[lIlII(-1051482833, 581077807)] = IIIll(lIlIl(-1050517622, 49270, 4664).toCharArray(), 52035L, lIlII(-1051482840, 1428317760));
      III[lIlII(-1051482839, -642130048)] = IIIll(lIlIl(2028043840, 42735, 4665).toCharArray(), 18141L, lIlII(-1051482838, -328974237));
      III[lIlII(-1051482837, 512162171)] = IIIll(lIlIl(-36161152, 55270, 4666).toCharArray(), 44454L, lIlII(-1051482844, 1945530211));
      III[lIlII(-1051482843, -55326866)] = IIIll(lIlIl(1387024331, 11458, 4667).toCharArray(), 81788L, lIlII(-1051482842, 805586405));
      III[lIlII(-1051482841, 1263474529)] = IIIll(lIlIl(-1928519260, 10777, 4676).toCharArray(), 56081L, lIlII(-1051482848, 1729278665));
      III[lIlII(-1051482847, -1575793636)] = IIIll(lIlIl(349974310, 3711, 4677).toCharArray(), 96098L, lIlII(-1051482846, 920289132));
      III[lIlII(-1051482845, -97142418)] = IIIll(lIlIl(-212899665, 64493, 4678).toCharArray(), 82659L, lIlII(-1051482820, -2109369716));
      III[lIlII(-1051482819, 1127757055)] = IIIll(lIlIl(1046951863, 50113, 4679).toCharArray(), 45769L, lIlII(-1051482818, -1621638508));
      III[lIlII(-1051482817, 882102428)] = IIIll(lIlIl(-1417926543, 55668, 4672).toCharArray(), 67671L, lIlII(-1051482824, 501670528));
      III[lIlII(-1051482823, 1163059300)] = IIIll(lIlIl(219095504, 56240, 4673).toCharArray(), 96058L, lIlII(-1051482822, -556530508));
      III[lIlII(-1051482821, -693460242)] = IIIll(lIlIl(1852134815, 25594, 4674).toCharArray(), 90568L, lIlII(-1051482828, 722012982));
      III[lIlII(-1051482827, -1440612482)] = IIIll(lIlIl(-1482485146, 10015, 4675).toCharArray(), 40501L, lIlII(-1051482826, -1238350152));
      III[lIlII(-1051482825, -1019521982)] = IIIll(lIlIl(650184418, 51785, 4684).toCharArray(), 44293L, lIlII(-1051482832, -655013705));
      III[lIlII(-1051482831, -1892862860)] = IIIll(lIlIl(-703917390, 60537, 4685).toCharArray(), 85594L, lIlII(-1051482830, 1495651209));
      III[lIlII(-1051482829, 250728878)] = IIIll(lIlIl(1225869439, 42013, 4686).toCharArray(), 59336L, lIlII(-1051482804, 1115794675));
      III[lIlII(-1051482803, 867918092)] = IIIll(lIlIl(-1845009160, 61130, 4687).toCharArray(), 56234L, lIlII(-1051482802, 559272195));
      III[lIlII(-1051482801, 238906112)] = IIIll(lIlIl(1502180752, 61130, 4680).toCharArray(), 25213L, lIlII(-1051482808, -1678370932));
      III[lIlII(-1051482807, -90557183)] = IIIll(lIlIl(-1407746772, 35490, 4681).toCharArray(), 28285L, lIlII(-1051482806, 1910986445));
      III[lIlII(-1051482805, 1367905441)] = IIIll(lIlIl(802374647, 50273, 4682).toCharArray(), 8344L, lIlII(-1051482812, 997724800));
      III[lIlII(-1051482811, -1731763099)] = IIIll(lIlIl(-578534578, 38004, 4683).toCharArray(), 55914L, lIlII(-1051482810, 1913091835));
      III[lIlII(-1051482809, -477077768)] = IIIll(lIlIl(544943653, 60355, 4692).toCharArray(), 85252L, lIlII(-1051482816, -1330332814));
      III[lIlII(-1051482815, 707678638)] = IIIll(lIlIl(2071136063, 44831, 4693).toCharArray(), 20079L, lIlII(-1051482814, -1727469913));
      III[lIlII(-1051482813, 2124536425)] = IIIll(lIlIl(2138460843, 59088, 4694).toCharArray(), 56256L, lIlII(-1051482788, -649526449));
      III[lIlII(-1051482787, -1051154381)] = IIIll(lIlIl(1918852710, 51302, 4695).toCharArray(), 30565L, lIlII(-1051482786, -1885567229));
      III[lIlII(-1051482785, 2119138248)] = IIIll(lIlIl(-1801173024, 31642, 4688).toCharArray(), 7985L, lIlII(-1051482792, -373582775));
      III[lIlII(-1051482791, 1274488773)] = IIIll(lIlIl(-2035063035, 56510, 4689).toCharArray(), 92352L, lIlII(-1051482790, -29388594));
      III[lIlII(-1051482789, 1568350055)] = IIIll(lIlIl(598096569, 61696, 4690).toCharArray(), 44442L, lIlII(-1051482796, -712564689));
      III[lIlII(-1051482795, -1029310268)] = IIIll("".toCharArray(), 87617L, lIlII(-1051482794, -1865064867));
      III[lIlII(-1051482793, -1774099446)] = IIIll(lIlIl(1208514062, 45721, 4691).toCharArray(), 21271L, lIlII(-1051482800, 1161205807));
      III[lIlII(-1051482799, -319128268)] = IIIll(lIlIl(986917426, 27642, 4700).toCharArray(), 58261L, lIlII(-1051482798, 1071685556));
      III[lIlII(-1051482797, -679897209)] = IIIll(lIlIl(1805733669, 42405, 4701).toCharArray(), 55490L, lIlII(-1051482772, 654604329));
      III[lIlII(-1051482771, -996681447)] = IIIll(lIlIl(-801344699, 11482, 4702).toCharArray(), 26460L, lIlII(-1051482770, -1645177642));
      III[lIlII(-1051482769, -1760060471)] = IIIll(lIlIl(400832450, 47613, 4703).toCharArray(), 23622L, lIlII(-1051482776, -56644644));
      III[lIlII(-1051482775, 1296719456)] = IIIll(lIlIl(-1299036023, 59262, 4696).toCharArray(), 4413L, lIlII(-1051482774, 1591312914));
      III[lIlII(-1051482773, -427603760)] = IIIll(lIlIl(-1480584144, 52285, 4697).toCharArray(), 38310L, lIlII(-1051482780, -1816788141));
      III[lIlII(-1051482779, -259884423)] = IIIll(lIlIl(1551567442, 50047, 4698).toCharArray(), 37006L, lIlII(-1051482778, -293535373));
      III[lIlII(-1051482777, -463592902)] = IIIll(lIlIl(2058231183, 9061, 4699).toCharArray(), 44660L, lIlII(-1051482784, -139381467));
      III[lIlII(-1051482783, -2016351455)] = IIIll(lIlIl(-1684390246, 44333, 4708).toCharArray(), 64642L, lIlII(-1051482782, 780658779));
      III[lIlII(-1051482781, 872107377)] = IIIll(lIlIl(-1876818768, 19469, 4709).toCharArray(), 23421L, lIlII(-1051482756, -1515230021));
      III[lIlII(-1051482755, 525593596)] = IIIll(lIlIl(2105872489, 6856, 4710).toCharArray(), 6304L, lIlII(-1051482754, 1686946874));
      III[lIlII(-1051482753, -224242415)] = IIIll(lIlIl(-436984594, 34096, 4711).toCharArray(), 90319L, lIlII(-1051482760, 12917486));
      III[lIlII(-1051482759, -1612050832)] = IIIll(lIlIl(576262781, 47398, 4704).toCharArray(), 76903L, lIlII(-1051482758, 759149762));
      III[lIlII(-1051482757, -769005443)] = IIIll(lIlIl(-1654100834, 53363, 4705).toCharArray(), 7747L, lIlII(-1051482764, 1208934558));
      III[lIlII(-1051482763, 1016190274)] = IIIll(lIlIl(1687756313, 51065, 4706).toCharArray(), 36355L, lIlII(-1051482762, 2017032330));
      III[lIlII(-1051482761, 1963787635)] = IIIll(lIlIl(409542187, 17499, 4707).toCharArray(), 36826L, lIlII(-1051482768, -883406515));
      III[lIlII(-1051482767, -140320657)] = IIIll(lIlIl(1456097185, 40134, 4716).toCharArray(), 98006L, lIlII(-1051482766, 2000663601));
      III[lIlII(-1051482765, -1079380837)] = IIIll(lIlIl(-980393385, 31448, 4717).toCharArray(), 66745L, lIlII(-1051482996, -132401140));
      III[lIlII(-1051482995, 1950443094)] = IIIll(lIlIl(720918041, 27105, 4718).toCharArray(), 33433L, lIlII(-1051482994, 46166154));
      III[lIlII(-1051482993, -687549463)] = IIIll(lIlIl(962731111, 3482, 4719).toCharArray(), 38899L, lIlII(-1051483000, -30095313));
      III[lIlII(-1051482999, -1846228505)] = IIIll(lIlIl(-1499824326, 54731, 4712).toCharArray(), 78780L, lIlII(-1051482998, -1881555338));
      III[lIlII(-1051482997, 222961560)] = IIIll(lIlIl(-978123654, 8600, 4713).toCharArray(), 65114L, lIlII(-1051483004, -822308666));
      III[lIlII(-1051483003, -469995850)] = IIIll(lIlIl(-172394581, 33093, 4714).toCharArray(), 9146L, lIlII(-1051483002, -546071572));
      III[lIlII(-1051483001, 1446787672)] = IIIll(lIlIl(1547062029, 23663, 4715).toCharArray(), 65051L, lIlII(-1051483008, -658956718));
      III[lIlII(-1051483007, -1705967424)] = IIIll(lIlIl(1973833612, 37995, 4724).toCharArray(), 3667L, lIlII(-1051483006, 1127357069));
      III[lIlII(-1051483005, -929563825)] = IIIll(lIlIl(77618257, 30096, 4725).toCharArray(), 48773L, lIlII(-1051482980, -545327756));
      III[lIlII(-1051482979, 1480393477)] = IIIll(lIlIl(1477391725, 46727, 4726).toCharArray(), 6935L, lIlII(-1051482978, -766779953));
      III[lIlII(-1051482977, 1998770374)] = IIIll(lIlIl(240478268, 33418, 4727).toCharArray(), 16568L, lIlII(-1051482984, -1653931441));
      III[lIlII(-1051482983, 2088522624)] = IIIll(lIlIl(2101959054, 21778, 4720).toCharArray(), 32654L, lIlII(-1051482982, -1506788669));
      III[lIlII(-1051482981, 599118032)] = IIIll(lIlIl(-1805552648, 2500, 4721).toCharArray(), 46563L, lIlII(-1051482988, 1585328367));
      III[lIlII(-1051482987, 2142022060)] = IIIll(lIlIl(603337832, 30945, 4722).toCharArray(), 20212L, lIlII(-1051482986, -1599979458));
      III[lIlII(-1051482985, 1735776947)] = IIIll(lIlIl(1844206751, 11007, 4723).toCharArray(), 87655L, lIlII(-1051482992, 1545609350));
      III[lIlII(-1051482991, 370497066)] = IIIll(lIlIl(685866371, 30062, 4732).toCharArray(), 26755L, lIlII(-1051482990, -729850409));
      III[lIlII(-1051482989, 707200664)] = IIIll(lIlIl(1731556040, 20252, 4733).toCharArray(), 79638L, lIlII(-1051482964, -441668016));
      III[lIlII(-1051482963, 1792806845)] = IIIll(lIlIl(-395217333, 33662, 4734).toCharArray(), 99083L, lIlII(-1051482962, 1393937990));
      III[lIlII(-1051482961, -1533521368)] = IIIll(lIlIl(-1228599149, 43734, 4735).toCharArray(), 64847L, lIlII(-1051482968, -1489230940));
      III[lIlII(-1051482967, -1169135269)] = IIIll(lIlIl(1053363318, 1555, 4728).toCharArray(), 23389L, lIlII(-1051482966, -1138499329));
      III[lIlII(-1051482965, -377680069)] = IIIll(lIlIl(166356384, 37564, 4729).toCharArray(), 81993L, lIlII(-1051482972, 1776007795));
      III[lIlII(-1051482971, 1334699810)] = IIIll(lIlIl(-2118706434, 25694, 4730).toCharArray(), 78267L, lIlII(-1051482970, -356146980));
   }

   private double llII(String var1) {
      int var3 = -1;
      switch (var1.hashCode()) {
         case -1684858151:
            if (var1.equals(III[lIlII(-1051482975, 1907427983)])) {
               var3 = 2;
            }
            break;
         case -1571105471:
            if (var1.equals(III[lIlII(-1051482974, 785197817)])) {
               var3 = 3;
            }
            break;
         case -1380923823:
            if (var1.equals(III[lIlII(-1051482935, -194029187)])) {
               var3 = lIlII(-1051482934, -807990241);
            }
            break;
         case -1056264474:
            if (var1.equals(III[lIlII(-1051482931, 130498342)])) {
               var3 = lIlII(-1051482930, -1708877719);
            }
            break;
         case -720514431:
            if (var1.equals(III[lIlII(-1051482955, -1900183684)])) {
               var3 = lIlII(-1051482954, -1378376308);
            }
            break;
         case -677216191:
            if (var1.equals(III[lIlII(-1051482947, -1022183491)])) {
               var3 = lIlII(-1051482946, 1511579548);
            }
            break;
         case 97513267:
            if (var1.equals(III[lIlII(-1051482953, 825037484)])) {
               var3 = lIlII(-1051482960, -1826124604);
            }
            break;
         case 106858757:
            if (var1.equals(III[lIlII(-1051482948, 412080717)])) {
               var3 = 5;
            }
            break;
         case 107028782:
            if (var1.equals(III[lIlII(-1051482959, 1494351135)])) {
               var3 = lIlII(-1051482958, 1522529496);
            }
            break;
         case 173173288:
            if (var1.equals(III[lIlII(-1051482949, -715359521)])) {
               var3 = lIlII(-1051482956, -2099931717);
            }
            break;
         case 350056506:
            if (var1.equals(III[lIlII(-1051482945, -1083103043)])) {
               var3 = lIlII(-1051482952, 394460523);
            }
            break;
         case 620514517:
            if (var1.equals(III[lIlII(-1051482951, 722612113)])) {
               var3 = lIlII(-1051482950, 630658293);
            }
            break;
         case 949868500:
            if (var1.equals(III[lIlII(-1051482969, -818381988)])) {
               var3 = 0;
            }
            break;
         case 961218153:
            if (var1.equals(III[lIlII(-1051482973, -1646607487)])) {
               var3 = 4;
            }
            break;
         case 976288699:
            if (var1.equals(III[lIlII(-1051482957, -783457445)])) {
               var3 = lIlII(-1051482932, 185399630);
            }
            break;
         case 1386075689:
            if (var1.equals(III[lIlII(-1051482933, -235239097)])) {
               var3 = lIlII(-1051482940, -1522514031);
            }
            break;
         case 1552717032:
            if (var1.equals(III[lIlII(-1051482929, -35265024)])) {
               var3 = lIlII(-1051482936, -381458568);
            }
            break;
         case 1603571740:
            if (var1.equals(III[lIlII(-1051482976, -1440282756)])) {
               var3 = 1;
            }
      }

      double var10000;
      switch (var3) {
         case 0:
            var10000 = (double)36.0F;
            break;
         case 1:
            var10000 = (double)22.0F;
            break;
         case 2:
            var10000 = (double)26.0F;
            break;
         case 3:
         case 4:
         case 5:
            var10000 = (double)24.0F;
            break;
         case 6:
         case 7:
         case 8:
         case 9:
            var10000 = (double)20.0F;
            break;
         case 10:
         case 11:
         case 12:
         case 13:
         case 14:
         case 15:
         case 16:
         case 17:
            var10000 = (double)14.0F;
            break;
         default:
            var10000 = (double)8.0F;
      }

      return var10000;
   }

   public llIlII() {
      super((Object)lIlIII.l(III[lIlII(-1051482939, 808204568)]), lIllII.l, (Object)lIlIII.l(III[lIlII(-1051482938, 1711904711)]));
      this.lll = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(III[lIlII(-1051482937, 779063192)]), IIlllIllI.class, IIlllIllI.ll));
      this.l = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(III[lIlII(-1051482944, 162006294)]), (double)70.0F, (double)120.0F, (double)0.0F, (double)1000.0F, (double)5.0F)).IIII(lIlIII.Il(III[lIlII(-1051482943, 318345036)])));
      this.IIIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(III[lIlII(-1051482942, 567303119)]), false));
      this.IIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(III[lIlII(-1051482941, 178401495)]), true));
      this.lI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(III[lIlII(-1051482916, 1195811565)]), true));
      this.IlI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(III[lIlII(-1051482915, 285433380)]), true));
      this.ll = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(III[lIlII(-1051482914, -2047081981)]), false));
      this.lll.lIII(() -> !(Boolean)this.IIIl.III());
   }

   private boolean lllI(class_310 var1) {
      return var1.field_1755 == null;
   }

   private double IIIII(class_1799 var1) {
      double var2 = (double)0.0F;
      class_9285 var4 = (class_9285)var1.method_58695(class_9334.field_49636, class_9285.field_49326);

      for(class_9285.class_9287 var6 : var4.comp_2393()) {
         if (var6.comp_2395().equals(class_5134.field_23724)) {
            var2 += var6.comp_2396().comp_2449() * (double)80.0F;
         } else if (var6.comp_2395().equals(class_5134.field_23725)) {
            var2 += var6.comp_2396().comp_2449() * (double)45.0F;
         } else if (var6.comp_2395().equals(class_5134.field_23721)) {
            var2 += var6.comp_2396().comp_2449() * (double)65.0F;
         } else if (var6.comp_2395().equals(class_5134.field_23723)) {
            var2 += var6.comp_2396().comp_2449() * (double)10.0F;
         }
      }

      return var2;
   }

   private double IIIIl(class_1799 var1) {
      String var2 = lIIll(var1);
      double var3 = this.IlII(var2) + this.IIIII(var1) + this.llI(var1);
      if (var1.method_7963() && var1.method_7936() > 0) {
         var3 += (double)100.0F * ((double)(var1.method_7936() - var1.method_7919()) / (double)var1.method_7936());
      } else {
         var3 += (double)100.0F;
      }

      if (var2.equals(lIlIII.Il(III[lIlII(-1051482913, 1916974823)]))) {
         var3 += (double)450.0F;
      }

      return var3;
   }

   private static String IIIll(char[] var0, long var1, int var3) {
      int var4 = lIlII(-1051482920, -78524710) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & lIlII(-1051482919, -1232405520);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private boolean IIlII(class_310 var1, class_746 var2, int var3) {
      if (!IIII(var3) && var3 >= 0 && var3 < var2.field_7498.field_7761.size()) {
         if (((class_1735)var2.field_7498.field_7761.get(var3)).method_7677().method_7960()) {
            return false;
         } else {
            var1.field_1761.method_2906(var2.field_7498.field_7763, var3, 1, class_1713.field_7795, var2);
            return var2.field_7498.method_34255().method_7960();
         }
      } else {
         return false;
      }
   }

   public void lI() {
      this.IIll = 0L;
      this.lII = 0L;
   }

   private int IIlIl(int var1) {
      if (var1 >= 5 && var1 <= lIlII(-1051482918, 299825526)) {
         return lIlII(-1051482917, 998248176);
      } else if (var1 >= lIlII(-1051482924, -1943819924) && var1 < lIlII(-1051482923, -1366934379)) {
         return lIlII(-1051482922, -946718276) - (var1 - lIlII(-1051482921, 695408578));
      } else {
         return var1 == lIlII(-1051482928, -195820307) ? lIlII(-1051482927, 1971214971) : lIlII(-1051482926, 431636661) - var1;
      }
   }

   private <undefinedtype> IIllI(class_746 var1, String var2) {
      Record var3 = null;

      for(int var7 : llI) {
         class_1799 var8 = this.Illll(var1, var7);
         if (!var8.method_7960() && !this.IIlll(var8) && !var8.method_7946() && this.lIIII(var8) == null && !this.lll(var8) && !this.IIll(var8) && var2.equals(this.IlIII(var8))) {
            Record var9 = new Record(var7, this.IIIIl(var8), this.IIlIl(var7)) {
               private final double I;
               private final int l;
               private final int II;

               public double I() {
                  return this.I;
               }

               public int l() {
                  return this.l;
               }

               public int II() {
                  return this.II;
               }

               private {
                  this.l = var1;
                  this.I = var2;
                  this.II = var4;
               }

               boolean Il(Object var1) {
                  if (this.I > var1.I + 1.0E-4) {
                     return true;
                  } else if (Math.abs(this.I - var1.I) <= 1.0E-4 && this.II > var1.II) {
                     return true;
                  } else {
                     return Math.abs(this.I - var1.I) <= 1.0E-4 && this.II == var1.II && this.l < var1.l;
                  }
               }
            };
            if (var3 == null || ((<undefinedtype>)var9).Il(var3)) {
               var3 = var9;
            }
         }
      }

      return var3;
   }

   private boolean IIlll(class_1799 var1) {
      if (!(Boolean)this.ll.III() && var1 != null && !var1.method_7960()) {
         return var1.method_57380().method_57845(class_9334.field_49637) != null || var1.method_57380().method_57845(class_9334.field_54199) != null;
      } else {
         return false;
      }
   }

   private String IlIII(class_1799 var1) {
      return class_7923.field_41178.method_10221(var1.method_7909()).toString();
   }

   public void lIl() {
      this.IIll = 0L;
      this.lII = this.IlIl();
   }

   private <undefinedtype> IlIIl(class_746 var1, String var2) {
      Record var3 = null;

      for(int var7 : llI) {
         class_1799 var8 = this.Illll(var1, var7);
         if (!var8.method_7960() && !this.IIlll(var8) && var2.equals(this.lIIII(var8))) {
            Record var9 = new Record(var7, this.IIIIl(var8), this.IIlIl(var7)) {
               private final double I;
               private final int l;
               private final int II;

               public double I() {
                  return this.I;
               }

               public int l() {
                  return this.l;
               }

               public int II() {
                  return this.II;
               }

               private {
                  this.l = var1;
                  this.I = var2;
                  this.II = var4;
               }

               boolean Il(Object var1) {
                  if (this.I > var1.I + 1.0E-4) {
                     return true;
                  } else if (Math.abs(this.I - var1.I) <= 1.0E-4 && this.II > var1.II) {
                     return true;
                  } else {
                     return Math.abs(this.I - var1.I) <= 1.0E-4 && this.II == var1.II && this.l < var1.l;
                  }
               }
            };
            if (var3 == null || ((<undefinedtype>)var9).Il(var3)) {
               var3 = var9;
            }
         }
      }

      return var3;
   }

   private boolean IlIll(class_310 var1) {
      lIllIIl var2 = lIllIIl.Il();
      if (var2 != null && var2.IIl() != null) {
         IlIIIIl var3 = var2.IIl().IIIl();
         return var3 != null && var3.IIIll(var1);
      } else {
         return false;
      }
   }

   private static int[] IllII() {
      int var0 = lIlII(-1051482925, 545032891);
      int[] var1 = new int[var0];
      int var2 = 0;
      var1[var2++] = 5;
      var1[var2++] = lIlII(-1051482900, 2145036022);
      var1[var2++] = lIlII(-1051482899, -1045237404);
      var1[var2++] = lIlII(-1051482898, -963973058);

      for(int var3 = lIlII(-1051482897, -931709953); var3 < lIlII(-1051482904, -1319535471); var1[var2++] = var3++) {
      }

      for(int var8 = 0; var8 < lIlII(-1051482903, 1551134732); ++var8) {
         var1[var2++] = lIlII(-1051482902, -428064010) + var8;
      }

      var1[var2] = lIlII(-1051482901, -919324342);
      return var1;
   }

   private boolean IllIl(class_310 var1) {
      boolean var10000;
      switch ((IIlllIllI)this.lll.III()) {
         case I -> var10000 = lIlIllll.IIll(var1);
         case ll -> var10000 = lIlIllll.IIl(var1);
         case Il -> var10000 = lIlIllll.llII(var1);
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   static {
      short var6 = 27583;
      String var7 = "毑뭘뀨苤\ue886럋ꩤ\udf7c齅艵\uf293鼀鸱⠽ﴖ縀鰽钠ᝅ鸄\uebd7\ue5a0㶢菻\uf4be\ueecf\udfad殮䙀ｭᯝ䯚殯\ued9cꙌᗣ嘇켠Ѽꙿϋﶥ䉖̜\udc6c䵌\ue3cc\ueb62稽獱詩爫烼\uf051汞錶ぞ픀\udecbﵯ縣\ua634꓾萅巓麳㽑䛐諨천弟㥫댇䴫穝ᗁʖ陙⒆姪硰ᶵ꽙靆甁\udf86쩺腥\ue393ﱩ\u0e61著趛鋐\uf183䒛\ue6dd䠴ᘐ윣넰꪿霖흮팋㩌䆇斖ꀏᗄ\u07fc╻蘖\uea2e\uefcb陓賛\ued69ᛏﬨእ뛏⾅ｆᰯ좃놥\uab1aᴀ韻\u0eef⊇Ⅹ\uf27a\ue5a7䘖抜壽\uda24㦭◢Ҍ⬠\uedef綃\u0ace糋퉛ꫲ撳⩑\ue654粬僀良庞奞Ę⠢갵弳郕ꎟ뿆ࢱ\uf246藧啤\uebfc轰ꏦ䴆勹ͫ㍒\u206f\uf1f1襇㠼콹㫥㱵 拈敒ڑ굖嚵℉北늲ᄯ拮㻓ጅ髝롢们濬놼뭧沞靴ᔭ⭝痘≥枟❏ꢆꝯ徻퀟쳒듩➶ꈩ㼾柉끌턅\u0ee2潻ⴊ瘠龰鍀暩ྜ\uf02aꫳ적\u2efa橱ꩀΙ鈼뱦㱺\u137d䇒텪\ue300땀\uf197⼜䢐曃⳼썏쌸竱牎툢琣跱↬嗜摝狣၊烐\uee4c뮓퇘雛놀焤썞\u0af4獅⡆硩됙簒ᾏ䂑ꔧ\uedc6ഌ\u1ad8穓ᚕ䲮왜⽭㉐낆ᛧܾ⥪䁳\udc2aܪ葬傳ꦡ쾪\ue2c2胎藛㴢ጄᨆ旱욽ẇӔ阻를찺㶆쐛纴晾ઐ́遖敹\u0a0e\u2dd7扝惟\ue8ab◢\uf74e⤌쏇ｐఖ\uf44c죩쐓㿸ౢﷅꎸ릮䒂\uf8bd쭐ꉫ⤴픨瀳쇡Ⓞꟁ毲స膟렩\u1bf7叞\ueabd⍪\uf006서\ue5f7祽䄺诣䷃喘뾞ⁿ\udbd1\ue36a㧏惡㖶斑㘬슍䪟騈酩૾쵼覲\u20c9┐ꯜꫢ㌌㓥际؟\uee91崕肋ʰ\uedb1\uf7d9ꪍ\ue563÷곓먋ꪎ滼㘾᷹둟쯠\uda6e월麩敒坂ᎈ摭𢡊ᚖ\ue929姭嗦亮ꎙ耤⸊\uaad3ἐ\ue08e\uf69a瑆梋\uea05㉪\ue99c㦠ꗋ᭾좬Ⱍᮦ踻앣\uf8ea㩫琝賽\ue064뚟䲓톃⃥劖\uf4a8咜\uf346梱硼쥿鮸⢾\ue8dd㍏\udee1⨄莧攫羌\uda17ꐭ鸀₉ﳽ배柶퀙锅걈ỿ䝓\ude75榝耉┨\uf2feᏯ况ඌ⩷\ue3fb㲸姖❾歷洘䑾\uf3bc⡽갔믎횮闪蘬ᵭ榌툜ጅ읁ф禎\udc23鯜雬䍖\udbfc념ᝨᪧૣ絎녓\uedaaᙰ氒\ude97\uf66e搪\uebcf㋼᳅谬\uf85bᬔ\uece4梫Ὅ冔䕖䖶蘘鞙ᇧ晔懵㊔陑见㝣\uf440\ue51c⌑丒ᛕ⽻ḯ傡臽䣴\uea5c⮯㺝氖놌샠䷤潑䁱⟠ॢ큫\ue2e5ị㈊\uf3b7ᾪ唧\uf544ꚤ\ue2c5瓃蛎\uf092섕唬谀폑️ꪖ\ue0c8䋑픢⃤껁聆滗隓퇨봧릍쑉옕磌楰\ue395〸⌼ꭄꔞ蟪쏸歖乄៙嶢覢咮즴鴫\udc52䵻貜\uf855陋릮\uf6ad窸\ue334\ud87b\uda11搈崨偵ꛘ逺䄱홶㱋욍搡ᴸ䶙鶽옜駺랪䩊呫骢뉏ꥵ\udd1c榭ᠪ為䅭\udccd皎㤞崍苣턃㽗씶\ue6f4が뒢跹\uf08c计蝯ଔ飃ऄ\u0b5b\uea6b린첲\udd32⵰缸椎ޫᗅ藧\uf7e7媋\ue004蚨☬\ua7ee⢀ꢄ\uef27ୖ⟵㕎쯡朇覇\uf6b6蚠\uecde륜㋈ධ࿊ि㺄\ued2e\uda06ᨼᯬ鿜괚隝\ue3e4䆳丹ꄑ뗋╇峾믴↭ˉ蚫앬睢熿\ued5a뮻鵬\ue802蹻拨矱\uf3db륑놪芇ᰵ실홈䮑䀁뽾⮠캏\ue2f6ᖊ蚠ꚰⶾ尗⭭적薨幒\ueb98럮ꋻੋ\ueef6繭铝쨂\ue86f䱵鰟㶏\uf632녤훼갯ㄱ采\u1ade╤ရ化䂐阇惴\u1c8bᆴਣ狁\ua8dd㫐跓\ufe1b퀽\uf6b5ꁔ漠\ud964㽄銒嘍\ue21bꨡࡃ騱\uda2e\uefb3녆\uee50繦ᇄ븡靘\ue187멖닏中ᢵ哼\udcf8븦虃譄딼ȩ点\ue1adᛧ賐㲊萀ᆮ꒩竻㖚\uf496◢讇\uf474\ued0d뺅뒈藄\u0efc鴫只拮趴贯臋媣躂\udd97\u0003釐溝숺鯌ꦗ㥑慥橕鋰彷宲䓭쬤䔜慉賄Ꮔ큙ꜟ쉵풬ꉙ荑ｮ瘘角↭겧詎⌟並꾗ជ궤᳘ꀲ㊂駋ퟄ贩᧙籠遃鶒\uee61\ue0ac飅鼕꡶▇▇檻ၫ琠溔鶑\ue9c1ﵗ\ue3b6쳨ߵ⎌\uf531꽇瓢ᥣ䢒儧\u208f祁觰撜㐵롹\ue53a䟤弁諨ゅ㉲句㍄뱇䉿\uf12f䣄㰴肐녧醼頙뼔띑衲\ue4a5腯癰䲋\udce7쌨ª᥍볤ꕙ弫\ue437숿篩潤\u0bbb\uef70ꯔ瑷\ue031㰠쿡ӊ퍷馫鄈\uf330㱊䢴魫㮤鉩㮙⯓禍ړ痵㪑딑▌\uef10㨲緿\ud9aeᆹ⋩묻౨캢\udcc6\uf67c嬄㌂땲就瀕ﱭ\ud8b5郒桸绘ꩀ\udec6믿\ue1d9酂⩋順봅쨾Ɂ䷢⡢눶㟈\uf025误ᕡ䂴䥑ᦛᥔ뚗蛶\ue617恚ଷ똄ﭖ\u0e7fç⭔ㅎꑓ\ue2a0紸ࡈ\uda32귲莍䈙湱\udf67籕ꐩ\uf741潨붶绀諭ć\u0f6d澧⩨\uec69ሁ\uf07f൶缃燐ꡈ䎨蠿\u001c\uefde璫涉黉쁍࡛묽䯯\udb22⻩䚻盓ꋊ毮쉹尗췿㦐春㈓ቛ堂쳗稽ମꝸ栤⢍啅ꫥ\udd00覗状역动\uf4baᬓ葹\udac6\uf483嗅\u0bc9斟ở㳒祡뱷\udd72भ\ue47a\ue883㸽슦\ue766㜦狹\uf8e3콭ی뗏䗇驃㞲鯛쏋篳뀺ࣈ鼇摻Аﾆ︐ᾷ긃칮м獮킃챤젶젵순힛馞\ude93\u1ad1엋鴏뀀\uf5e0홎갞욽춐䟿榜髮翬ᝒ컶鲳绩㗿ᓇ詰蓻晩扗\u2e71⡤\u2d99訶\ue1ff\ufafe耋쨜㜚ﭵ뱄轣抿\uebdf蘰\u2cf7湑壼㍩\ue6df梾\udfe7\uefdc⤶毗譟鉈菀Ⓙ⍼胙ừ䌟➜ꢼ動ꃗ휫럪\uf8fdﷄ쿺ᒐ㾬틗힔乙啶扎ㇼﻓ觔➁\ue856ᚻ\uf02b\u2e6cЬ嗻뙌뽑⸻襚ᒱዾ공逬籋됩ꄿퟝ즺一䱰퐌\udbb8즢טּ᷉횬\ue6cb叐\uf48d尉ᔒ\uf452䟓쵆녛뎭灦袳䙾蝞偦唃\uf067쀐큩\uf6d6ᕜ룦\ueae0霪䃯\ued43\u1c8e\uebab鸎ⶹ蒤\uecfc濹펴ৡ瞫Ė嗦用\ue939艱\udecdࢠ쳃Ⳗ鎽姶\uf0af햀녌ɶ⬾瘩\ud9ee錋䤋ꄬ㎼茚鰴ᔽ휣䜔\ud897\u197bᘽ\u128e嘃\ue68f平뗢䱈뤲瑍ࠜ㤏ꆡ\uec42홵\uf062\ue864鉋㚉ᴿᦰ蓯骘춴\udc57釃뒜䛥풩撏셱쓰텿\udcbf䜐턑\uf304鵚븩退㡊嚰㖌仼쑄㼹鑢\u0bffៗ峢粞\ue8fb\ud88b䁠ˣ㉰èᘏ镬\ud883ሉ㎥ᨈ䥼䘻饄\ud85d\udb0b\udeae⣢ኟݺ炋\ue789ꤋ珝\udc87컎攡㣘槺識⫖ꇻ啄헅瘾屃燌｜\ueb92\udacc籷蒒ﮱ㱖ڜﻞ뜳뼍㽆뒒뼖⽉鐃憘ᶙő䈢➲嶼樗䫛⧏Ò俇\uf2ba⸋\uf7e8\u2b96菒儕\udb84꾴⁏䃏穳Ņ碼㝘唝簑膢匪\ue7c1\ue293\uf839ᚫ셩࿘ᰳ퉡엩ꝕ泜ᓽ\ue338ᧇ赍뫘㒹쒨핧\uee03仯\uf72f婱㚟ⶲ褘븪讆Â⦕基ᵮ\u0c74廠눍爘ꢐ傽\uf11eד飨뱫彟\uec49\ue6f1⛔쮢옟\ue29cỏ硿乭ཌ\uf428\uf75c\ue972\udde5☝箇㥼ᘥҌ\ueedc㡆愙⡣腈湁硵ﶤ郻꒘礤ᆑᕊ㪰굛쯙錼묛뉼釃\ude8b듄쭕蹁㓘\ue5a2돡朅늜Żව⎝璉廅럘諨\uf1c4鼲\ud8d2ヤ\udf79¾譼ᇠ駖⯡稘껼⣆㩏䒌㛊씘\ue629䈤涽ꆘ죁恵溑撮펦Ⲷ\ue21c\uf0d6廬鶙\udc03㜧鍔脔ಬ籁逵ٞ膯뭬巐ᦵ剄뙧⊆놻\udbc4繓ᴂ椤廊Ʉⷓ▀㉪渺閉逩໌⽒\uedfe\uffdfꂥ쾸吟♽㇑嚪◕ﯸʋ\ue4d5뻼\uf09e嗓ꀻꀉ菩Ֆﯜ濙ṣ\ue095\uf444̳ᴀ៤捦䳉텈ɜ芖巸\udf51톹웓쒈歩㡏혃꓂띓藞崓\udb97줕ꦕ볘哫皰\ue04f\uf7dd을傸ೃᶺᤲᗤ刁튝\uf283떲狷㤍遇\udda7岸ቖ軸៎혳랿䏊辄ﵼ䙢蘱\uefda鸙Ȧ\u0d0d느⾩䳭䰧僝礽\ueba9㽶熛몕貁䌶䜂廡ㄢ崉ᙘꎄ狺浹\ue118쩾ᚪ嵥࿙\uee18ˣ碝⒙⊮ֺ섴\udf20\uef4c켨廢㕋쪋眩闷濭멒⤊䪁\ue0c6≸ᕿ淊\udc42⤜淘䪓앑圫⬿\uea10ㆶ\uf82c䙦ⷽ\ue74a儭溱樼뷮瘉믣딟빓웈\ued0c⟲潊꺙깆检톲⢔䠏\ue24d●詒霐Ӱ\ud90c\uf063㼖橓쀵륦\ue69fᙙ\ue9c3캁簒閪ᇈ\ufaf8榽\udad2Ꭰ꧅ᬝາ퇻偳䠘躥У疏\uf73d䆣䄳\ue4d6裱Ⳳ\udc0aⰅȴ퇝雾";
      char[] var8 = "殫殳殯殯殳殯殯殯殷殷殯殳殯殟殫殷殯殳殫殷殷殫殳殯殷殯殯殯殯殷殷殳殫殻殫殯殻殧殫殫殯殷殳殯殳殷殳殳殳殷殸殴殹段殶殸段段殺殲段殸殺殶殸殺段殯殫殯殷殯殯殧殳殯殷殯殯殳殧殫殯殳殯殯殷殯殯殳殷殳殳殳殯殯殯殫殯殳殷殷殷殯殳殳殷殷殷殯殳殷殫殻殣殧殯殣殳殯毇殣殧殯殻殷殷".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IllI = var9;
            Illl = new Object[var9.length];
            int var2 = 1252280159;
            byte[] var0 = "\tEÊìMÃÔ\u001ffgkq9k\u008d0\u0084Ò\u001eÈ1Q\u0084¸PE¿\u009d'\u0011Ä\u0097Äè\u0080J¹R \u001c'NÜÏw\u008dûÏ\u009cR\u0011Jàs\u008b\u007fbàç/\u009e{]¼\"d\u0095£\u0095½\u0001:Y\u0007V\u0004À sûPêø¨{@\u0002\u0088'ÁkR \u0003\u0094e×Ð\u0096x\u0095OÝ6ñÈ|\u001b(\u008d¸¾D)Kå_V\u000eú×VÝ#SI=Úox1V0Ê\u0091îòj CÊ\u009a®í1VÃ\u0089W\u0084\u0093ú\r\u009d\u009c×ÀðyW$Æ9«,\u0085ÙU³5·Åª¿_Zk\u0097\u0099læÛX½5\u001ej<\u0098\u000e$ó\u008f¶ÑB¥ÚÜsèJ1:_Ä\u0097Í\u0001\u0016\u000b~¬\u000f<\tá\u0089ëÁè\u0000Éõs¼rJNH\u001e:\u008fôVðmÞ_Æ\u008e©è\u0080aÜ&h\u001a\u0004í·.·Ý>\u0007Í\u0082B\u00ad×\u00152 \u008bÝüj§Ê;\u0081?\níÀ¨\u0006<WOT> :¨\u0080A@\u008döÕBÇ\u009f\u0083Xæ\tv?\u008a\u0090ÕÎÞ\u0001\u008f¦j¦æ¹àiü^ÂÝ3°ChïkÃ®ÐpÈÙ\"É%j\u009fáÑ+Ngi¾}õ-&qèÄ8q\u008csÇ¼hF¡\u0002ÒÌ¸ ø`\u000e\rÈ\u0006c\u008fA(H\u0013\u001ef\u0001\u009b\u009e´;òÞ\u0013ºrÓ½\u008eka3x¤AÅH·\u0019|ÞÖÿÅ~ÆìçÎf\u0017å¢6¢yÔãÜ:\b*Å\u001b\u0014z\u001eÄ±ipZ\u0099ç\u008a¡b9céÃä¸dC\u0086Þ\u0080¥U\u0086ÑÆ*\u009a³4°Ãt&ùjCkÛøÆ!^®ZÍÓSDÏG¿ZäU\u0003ÍË\u0013jù\u00ad¾\u0085G\u0095*ë²\u0010TÍîW\u000fî.¡¥ë\u001d²}íñ\u0015ºB\u009ab!4Í\u009fpV=\u009c×\u0083ÆÑÏtÚ9%\u0005\u007fÉ\rX\u001d\u009b ò£C\\>kö\u008fn\u0095\u008bxZâCí\u001d\u0093¨®3ôÚâYØ¨]\u0091\u0015x·wù÷\u009eû\u0089¢ë\t2]\u008f¾Ö\to9\u0095=\u0003HbÊÅI\u000fE\u0016¬¡ì°\u0013ªÖÌp\u0088\u0086áaÌö\u0097º¿\u0088ÿ\u00ad¡ÿj\u0097\r\u001aT\u000e\u0085Ðá\u0004á\u000fÇa¾ý\u0099Pm¿\u009d0°\t©Uic=cAéRN=ËØe*ÿ\u0095q\u001b1Sc\\\u007fwD%+\u009bÐW!À¸õYqÆ/é)ä®#¨4jÎqÂ[PLðÑÿÈÏÖÞY-Ô4¿d2¸\u000eC\u0086ÖÎ¥\u0002GV\u0010Ø´]]@Ì\u0017FT\u0011!Ö\u001dSr\u0080'¬HÌ¶b!®\u0001\f\u0004ÚÖSj\u008d#b\u0085\u00063\u0088áH§\u008c¸L\u0083U3|K\u0087\u0085Ê\u0089\\ÒâW¶qm×ZYÜÔ9Ú\u007fvû\u0091\u0087«\u007f\u00130\u00860Û\u000bì\u0010hg¼°+\u0089ìb¡Ù³á\u001d\u0083àfõV8'Äñj\u0086J¯Jb\u001f*\u0011Jõ¸\u0099\u009cö¬½\u0016À\u0000Å\u0096¸?hXÖ\u008cý5ßy¼ÚIR\u001a\u0099\u007fÄ\u0013Ó\u001d¶\u0086Z\u0012\u0098÷\u001ag\r\u009fcw\t\u009fø\\\u008euÑr¥RÝO`;pôYÇ)\u001cày¥YPÎ\u0083Æ½¼\u000b2)]\u0012mtªº\u0090~¼j{u\u0098\u001cª\u0081þjo©ÀbEq¸.\f'\t~\tÜ,?¸\f¯/C9¯F\u0094¤\t½\u008dR}ÃyU·U\u008e\u00077Ò\u0014\u001dì3\u0014%Ï±YÞ\n?8n\u001dà·f7\u000f\u0098\u0017c\tþúç3d [\u0083|U\u0002(/c\u0005Ì4^\u0016Ý\u009foªâÿ¶\u0085ï§\"ºö\\ó0UÞ\u001e)¦\u001a\u0003*\\Bé \u009e\u0086½ü\"öµÅ>h\u000b\u008d\u0003N\u00178\u0080ÝËÙðYA\u0084¼\u0011¦ão}¨,¯C`\u0018áó\u0089\u007frÓÊà´ºc\"\u0016üÕ3riZ\u007fÉ÷\u008b°3\u001d\n¾\u008f¨B3b¬IÉXô[J\u0011u3Õsì\u00829\u0003¯ì«\u0004\u009dâµ\u009d\u0088[¤Á¡Ðå.Ë\u0015Crá+ì4\u008eá\u0084¢/o±¤òûä\u00041§\u008aÐX\u000f\u009f)b\u008aì±ÝfÓ\u0083Äz\u0004§\u0013fKnDÏ\u0098\u0099!Ðä¿úFéH¥:É;\u0016- H\u0093x9\u0090HåT\u001fÑï<{4\u0086Ëo\u009cu\u001e\u008b åÌO®`÷\u0018^«\u0099\n\t\"vY\u0005J\u009c¥& FoºÚñ~\u0018Ðo Òæ\u001e°ÑH\u00179Zº\u0080\u0081\u0080û\u001aÐ\u008c0Ü\u008f\u0011Ó{öv\u0012\u0005§b´\u0084à\u007f\u0098ºßD ï\u009az\rj\u0091.·¤\u001b»ÛÚùíþt'¥\u0098l\u007f\u0082_æ÷\u0099\u000el¯ª'¸$\u0081UÓ<Ì±A\u0012\u009aô½Þ\u000e\u000báøùµUn½\u009d\u001b»=}\u0018\u0089\u009a)\u001aû°wìä\u0007ÔJÃ%qß2LeÛ\u0019¢\u0084ôn\u007f£çOþ\u0089¹\u000f\u0092M£\\«\u008bi\u001eô-ECJE\u0012ÑM}\u0013\u0087C\u0080ØF:®\u009f\u0002×\u0083\u0093³m\u008b¡gBÃÚÓVâË¨Ô\u0002 GbÄÌÞF7]íú\r\b\u0086\\wîéx¡A\u008cgs7Q<\u0088\u0017ôÚ\u000f÷\u009aOA:Ê\u001a\u0088Ë\u007f½æ~h\u009a½+\u0092¯¾ü,qÅúûêóU\"(Þß\"üóO<tÿ\u0017\u0083û\u0010\u0089\u0090Ó^3\u0014©yáãå\u0012\u0092~ê½Uæ&\u009dZ\u0080l0&ü@ë~2\f\u001e\u008a\u0098L\u0082Wûo\u001f´Ä\u0013<¶T¾âü¢\u0013ì\u0018w\u0014\u0011ÏSÁÅ\u007f\u0004(\u0088\u0083DYW\u0000\u0087É5¬Û[<\u0089Özfsv¢1¢\u0013\fCÅ»\u0098ixÜ\n`Ëx4ÇåÅé\u0090]jS\u008cù\u0003¼\u0016øÓ\u0005E\u00ad-f\u001eMöÝeà\u0094}¥»:x?+Ý\u0099¸öÀÇ \u009cÄ\u0016òEâºKu\u0015Î<V,sF\u0099\u0011ÁÝ·äòb\u0007Kri!=ó53\u008c:\u0087R~C¹\u008f\u008eï\u0012{}à\u008bÀ\"p\u0013\u00024{Î\u0001è2V|ûj\u009b\u001bt¨c!ôª\u0000\u001c¬ÚìÓú\u008c\u008b\u009d°¹\u009b6òd¦\u000f-MÝçù\u0091\u009d\u0083Î\u0002#\\\\v±§7\u000e5¤pãa«CÁ\u0096Ø©þÊ\u00adeo\u0099_\u0019U'Ñn\u0000éÚ\u0003".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IlIl = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IlIl[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            III = new String[lIlII(-1051482908, -585815917)];
            lIIl();
            llI = IllII();
            String[] var19 = new String[lIlII(-1051482907, 1609909225)];
            var19[0] = lIlIII.Il(III[lIlII(-1051482906, -382521553)]);
            var19[1] = lIlIII.Il(III[lIlII(-1051482905, -843006436)]);
            var19[2] = lIlIII.Il(III[lIlII(-1051482912, 1912269682)]);
            var19[3] = lIlIII.Il(III[lIlII(-1051482911, -679473919)]);
            var19[4] = lIlIII.Il(III[lIlII(-1051482910, -212426121)]);
            var19[5] = lIlIII.Il(III[lIlII(-1051482909, -326839134)]);
            var19[lIlII(-1051482884, -1216351151)] = lIlIII.Il(III[lIlII(-1051482883, 1375212667)]);
            var19[lIlII(-1051482882, -994649748)] = lIlIII.Il(III[lIlII(-1051482881, -1853937522)]);
            var19[lIlII(-1051482888, 907124167)] = lIlIII.Il(III[lIlII(-1051482887, 290113638)]);
            var19[lIlII(-1051482886, 608771968)] = lIlIII.Il(III[lIlII(-1051482885, -97380069)]);
            var19[lIlII(-1051482892, 1627698819)] = lIlIII.Il(III[lIlII(-1051482891, -1557578533)]);
            var19[lIlII(-1051482890, 1996795038)] = lIlIII.Il(III[lIlII(-1051482889, -16190361)]);
            var19[lIlII(-1051482896, 1894214195)] = lIlIII.Il(III[lIlII(-1051482895, 1487524078)]);
            var19[lIlII(-1051482894, 579732035)] = lIlIII.Il(III[lIlII(-1051482893, 1860530567)]);
            var19[lIlII(-1051483124, 1632286395)] = lIlIII.Il(III[lIlII(-1051483123, -1385514603)]);
            var19[lIlII(-1051483122, -406338142)] = lIlIII.Il(III[lIlII(-1051483121, -887317198)]);
            var19[lIlII(-1051483128, -2014746145)] = lIlIII.Il(III[lIlII(-1051483127, -948587293)]);
            var19[lIlII(-1051483126, -454535296)] = lIlIII.Il(III[lIlII(-1051483125, -1731504827)]);
            var19[lIlII(-1051483132, 890576875)] = lIlIII.Il(III[lIlII(-1051483131, -1742996633)]);
            var19[lIlII(-1051483130, -1612305383)] = lIlIII.Il(III[lIlII(-1051483129, 1244830737)]);
            IlII = Set.of(var19);
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 15;
                     break;
                  case 1:
                     var10000 = 79;
                     break;
                  case 2:
                     var10000 = 123;
                     break;
                  case 3:
                     var10000 = 63;
                     break;
                  case 4:
                     var10000 = 65;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private String IlllI(String var1) {
      if (var1.equals(lIlIII.Il(III[lIlII(-1051483136, -1551933422)]))) {
         return lIlIII.Il(III[5]);
      } else if (!var1.equals(lIlIII.Il(III[0])) && !var1.endsWith(lIlIII.Il(III[4]))) {
         if (var1.endsWith(lIlIII.Il(III[3]))) {
            return lIlIII.Il(III[lIlII(-1051483135, -761207842)]);
         } else if (var1.endsWith(lIlIII.Il(III[1]))) {
            return lIlIII.Il(III[lIlII(-1051483134, 1120030592)]);
         } else {
            return var1.endsWith(lIlIII.Il(III[lIlII(-1051483133, -791975294)])) ? lIlIII.Il(III[lIlII(-1051483108, -242118593)]) : null;
         }
      } else {
         return lIlIII.Il(III[2]);
      }
   }

   private class_1799 Illll(class_746 var1, int var2) {
      return var1 != null && var2 >= 0 && var2 < var1.field_7498.field_7761.size() ? ((class_1735)var1.field_7498.field_7761.get(var2)).method_7677() : class_1799.field_8037;
   }

   private String lIIII(class_1799 var1) {
      if (var1.method_7960()) {
         return null;
      } else {
         String var2 = lIIll(var1);
         if ((Boolean)this.lI.III()) {
            String var3 = this.IlllI(var2);
            if (var3 != null) {
               return var3;
            }
         }

         if (!(Boolean)this.IlI.III()) {
            return null;
         } else if (var2.endsWith(lIlIII.Il(III[lIlII(-1051483107, 700858634)]))) {
            return lIlIII.Il(III[lIlII(-1051483106, -2018236766)]);
         } else if (var2.endsWith(lIlIII.Il(III[lIlII(-1051483105, 329161719)]))) {
            return lIlIII.Il(III[lIlII(-1051483112, -2120800176)]);
         } else if (var2.endsWith(lIlIII.Il(III[lIlII(-1051483111, -1087371553)]))) {
            return lIlIII.Il(III[lIlII(-1051483110, 1650966095)]);
         } else if (var2.endsWith(lIlIII.Il(III[lIlII(-1051483109, -663021011)]))) {
            return lIlIII.Il(III[lIlII(-1051483116, 937499591)]);
         } else if (var2.endsWith(lIlIII.Il(III[lIlII(-1051483115, -1900917246)]))) {
            return lIlIII.Il(III[lIlII(-1051483114, -303452447)]);
         } else if (var2.endsWith(lIlIII.Il(III[lIlII(-1051483113, 1452409786)]))) {
            return lIlIII.Il(III[lIlII(-1051483120, -162375660)]);
         } else if (var2.equals(lIlIII.Il(III[lIlII(-1051483119, -204945183)]))) {
            return lIlIII.Il(III[lIlII(-1051483118, 307172823)]);
         } else if (var2.equals(lIlIII.Il(III[lIlII(-1051483117, 1280802796)]))) {
            return lIlIII.Il(III[lIlII(-1051483092, -1660574008)]);
         } else if (var2.equals(lIlIII.Il(III[lIlII(-1051483091, 834442766)]))) {
            return lIlIII.Il(III[lIlII(-1051483090, 1170978111)]);
         } else if (var2.endsWith(lIlIII.Il(III[lIlII(-1051483089, -122586566)]))) {
            return lIlIII.Il(III[lIlII(-1051483096, 1244288203)]);
         } else if (var2.endsWith(lIlIII.Il(III[lIlII(-1051483095, 2039866454)]))) {
            return lIlIII.Il(III[lIlII(-1051483094, -107036121)]);
         } else if (var2.endsWith(lIlIII.Il(III[lIlII(-1051483093, 2026033316)]))) {
            return lIlIII.Il(III[lIlII(-1051483100, -1318014619)]);
         } else if (var2.endsWith(lIlIII.Il(III[lIlII(-1051483099, -934384482)]))) {
            return lIlIII.Il(III[lIlII(-1051483098, 1692768347)]);
         } else if (var2.endsWith(lIlIII.Il(III[lIlII(-1051483097, 1803297599)]))) {
            return lIlIII.Il(III[lIlII(-1051483104, -68886251)]);
         } else if (var2.endsWith(lIlIII.Il(III[lIlII(-1051483103, -264641808)]))) {
            return lIlIII.Il(III[lIlII(-1051483102, -1180590105)]);
         } else if (var2.equals(lIlIII.Il(III[lIlII(-1051483101, -512952220)]))) {
            return lIlIII.Il(III[lIlII(-1051483076, 596951754)]);
         } else if (var2.equals(lIlIII.Il(III[lIlII(-1051483075, 569900988)]))) {
            return lIlIII.Il(III[lIlII(-1051483074, 1360736449)]);
         } else if (var2.equals(lIlIII.Il(III[lIlII(-1051483073, 125599417)]))) {
            return lIlIII.Il(III[lIlII(-1051483080, 845993463)]);
         } else if (var2.equals(lIlIII.Il(III[lIlII(-1051483079, -279843793)]))) {
            return lIlIII.Il(III[lIlII(-1051483078, -970324795)]);
         } else if (var2.equals(lIlIII.Il(III[lIlII(-1051483077, 443179226)]))) {
            return lIlIII.Il(III[lIlII(-1051483084, -1982546092)]);
         } else if (var2.equals(lIlIII.Il(III[lIlII(-1051483083, -45726667)]))) {
            return lIlIII.Il(III[lIlII(-1051483082, -2050865299)]);
         } else if (var2.equals(lIlIII.Il(III[lIlII(-1051483081, 1754679366)]))) {
            return lIlIII.Il(III[lIlII(-1051483088, 1247886248)]);
         } else if (var2.equals(lIlIII.Il(III[lIlII(-1051483087, 1966952058)]))) {
            return lIlIII.Il(III[lIlII(-1051483086, -462504953)]);
         } else {
            return var2.equals(lIlIII.Il(III[lIlII(-1051483085, -556780955)])) ? lIlIII.Il(III[lIlII(-1051483060, -1960953499)]) : null;
         }
      }
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (this.Illl(var1)) {
         boolean var2 = var1.field_1755 instanceof class_490;
         if (!(Boolean)this.IIIl.III() || var2) {
            if ((Boolean)this.IIIl.III() || var1.field_1755 == null || var2) {
               if (var2 || this.lllI(var1)) {
                  if (!this.IlIll(var1)) {
                     if (var1.field_1724.field_7498.method_34255().method_7960()) {
                        long var3 = System.currentTimeMillis();
                        if (var3 - this.IIll >= this.lII) {
                           <undefinedtype> var5 = this.IlI(var1.field_1724);
                           if (var5 != null) {
                              for(int var9 : llI) {
                                 if (var5.II(var9)) {
                                    if (!this.lIIlI(var1, var2)) {
                                       return;
                                    }

                                    if (this.IIlII(var1, var1.field_1724, var9)) {
                                       this.IIll = System.currentTimeMillis();
                                       this.lII = this.IlIl();
                                       lIlIllll.IllI(var1);
                                    }

                                    return;
                                 }
                              }

                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private boolean lIIlI(class_310 var1, boolean var2) {
      if (!var2 && !this.ll(var1)) {
         return false;
      } else if (!this.IllIl(var1)) {
         return false;
      } else {
         lIlIllll.IllI(var1);
         return true;
      }
   }

   private static String lIIll(class_1799 var0) {
      return class_7923.field_41178.method_10221(var0.method_7909()).method_12832();
   }

   private static int lIlII(int var0, int var1) {
      return IlIl[var0 ^ -1051482740] ^ var1 ^ var0;
   }

   private static String lIlIl(int var0, int var1, int var2) {
      int var3 = var2 ^ 4612;
      char[] var4 = IllI[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])Illl[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         Illl[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 2583;
      int var9 = 0;

      do {
         int var10 = var4[var9] ^ 29737;
         var10 += 17383;
         var10 += 52828;
         var10 += 25414;
         var4[var9] = (char)(var10 ^ var8 ^ var1 ^ var0 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
