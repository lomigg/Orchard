package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;

@Environment(EnvType.CLIENT)
public final class IllIIll {
   public static float I(Object var0, float var1) {
      IIIllIlII var2 = IIl();
      if (var0 == null.I && var2 != null) {
         return var2.IlllIl(var1);
      } else {
         IIIIIIIl var3 = lI();
         return var0 == null.II && var3 != null ? var3.IlIIIl(var1) : 0.0F;
      }
   }

   public static boolean l(Object var0, class_1297 var1) {
      IIIllIlII var2 = IIl();
      if (var0 == null.I && var2 != null) {
         return var2.IIlII(var1);
      } else {
         IIIIIIIl var3 = lI();
         return var0 == null.II && var3 != null && var3.IlIl(var1);
      }
   }

   public static void II(Object var0, float var1, float var2, float var3, float var4) {
      IIIllIlII var5 = IIl();
      if (var0 == null.I && var5 != null) {
         var5.IIlIlI(var1, var2, var3, var4);
      } else {
         IIIIIIIl var6 = lI();
         if (var0 == null.II && var6 != null) {
            var6.llI(var1, var2, var3, var4);
         }

      }
   }

   public static <undefinedtype> Il() {
      IIIllIlII var0 = IIl();
      if (var0 != null && var0.lll()) {
         return null.I;
      } else {
         IIIIIIIl var1 = lI();
         return var1 != null && var1.IIlIl() ? null.II : null.l;
      }
   }

   private static IIIIIIIl lI() {
      lIllIIl var0 = lIllIIl.Il();
      return var0 != null && var0.IIl() != null ? var0.IIl().lIIl() : null;
   }

   static <undefinedtype> ll(boolean var0, boolean var1) {
      return var0 ? null.I : (var1 ? null.II : null.l);
   }

   private IllIIll() {
   }

   public static float III(Object var0, float var1) {
      IIIllIlII var2 = IIl();
      if (var0 == null.I && var2 != null) {
         return var2.lIIII(var1);
      } else {
         IIIIIIIl var3 = lI();
         return var0 == null.II && var3 != null ? var3.IlIIll(var1) : 0.0F;
      }
   }

   private static IIIllIlII IIl() {
      lIllIIl var0 = lIllIIl.Il();
      return var0 != null && var0.IIl() != null ? var0.IIl().llIlII() : null;
   }
}
