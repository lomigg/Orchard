package x;

import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_9112;

@Environment(EnvType.CLIENT)
public final class IlIIllIl {
   public static class_9112 I() {
      return new class_9112(Map.of(), Map.of(), false);
   }

   private IlIIllIl() {
   }
}
