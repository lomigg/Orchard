package x;

import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2611;
import net.minecraft.class_2614;
import net.minecraft.class_2627;
import net.minecraft.class_2636;
import net.minecraft.class_2818;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3719;
import net.minecraft.class_3866;

@Environment(EnvType.CLIENT)
public final class IIllIIlIl extends IIIIIIIlI {
   private static String[] I;
   private final IlIIIlIlI<<undefinedtype>> l;
   private final lIIIIl II;
   private final IIllIlIII Il;
   private final IIllIlIII lI;
   private final IIllIlIII ll;
   private static final Color III;
   private static final Color IIl;
   private final lIIIIl IlI;
   private static final Color Ill;
   private final IIllIlIII lII;
   private final lIIIIl lIl;
   private static final Color llI;
   private final lIIIIl lll;
   private static final int IIII = 8;
   private static final Color IIIl;
   private final lIIIIl IIlI;
   private final IIllIlIII IIll;
   private final lIIIIl IlII;
   private static final Color IlIl;
   private final IIIllIIII IllI;
   private final lIIIIl Illl;
   private final IIllIlIII lIII;
   private static final Color lIIl;
   private final lIIIIl lIlI;
   private final IIllIlIII lIll;
   private final lIIIIl llII;
   private static final int[] llIl;
   private static final String[] lllI;
   private static final Object[] llll;

   private Color ll(class_2586 var1) {
      if (var1 instanceof class_2595 && (Boolean)this.IlI.III()) {
         return (Color)this.lII.III();
      } else if (var1 instanceof class_3719 && (Boolean)this.IIlI.III()) {
         return (Color)this.ll.III();
      } else if (var1 instanceof class_2614 && (Boolean)this.Illl.III()) {
         return (Color)this.lI.III();
      } else if (var1 instanceof class_3866 && (Boolean)this.lll.III()) {
         return (Color)this.IIll.III();
      } else if (var1 instanceof class_2627 && (Boolean)this.II.III()) {
         return (Color)this.Il.III();
      } else if (var1 instanceof class_2611 && (Boolean)this.lIl.III()) {
         return (Color)this.lIII.III();
      } else {
         return var1 instanceof class_2636 && (Boolean)this.IlII.III() ? (Color)this.lIll.III() : null;
      }
   }

   public void llIl(llIIllI var1) {
      this.lII(var1);
   }

   public IIllIIlIl() {
      super((Object)lIlIII.l(I[IIll(-830950924, -2062122363)]), lIllII.ll, (Object)lIlIII.l(I[IIll(-830950923, -1346365020)]));
      this.llII = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(I[0]), true));
      this.lIlI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(I[IIll(-830950922, -643306782)]), true));
      this.IllI = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(I[IIll(-830950921, 1020288343)]), (double)30.0F, (double)0.0F, (double)100.0F, (double)1.0F)).IIl(lIlIII.Il(I[IIll(-830950928, 181522135)])));
      this.l = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(I[IIll(-830950927, 1691061529)]), <undefinedtype>.class, null.II));
      this.IlI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(I[IIll(-830950926, 1122962078)]), true));
      this.lII = (IIllIlIII)this.IIIlIll(new IIllIlIII(lIlIII.l(I[IIll(-830950925, 704399803)]), Ill));
      this.IIlI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(I[IIll(-830950916, -805718238)]), true));
      this.ll = (IIllIlIII)this.IIIlIll(new IIllIlIII(lIlIII.l(I[IIll(-830950915, 641849725)]), IIIl));
      this.Illl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(I[1]), true));
      this.lI = (IIllIlIII)this.IIIlIll(new IIllIlIII(lIlIII.l(I[5]), IIl));
      this.lll = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(I[IIll(-830950914, -115010406)]), true));
      this.IIll = (IIllIlIII)this.IIIlIll(new IIllIlIII(lIlIII.l(I[4]), llI));
      this.II = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(I[IIll(-830950913, -1548924068)]), true));
      this.Il = (IIllIlIII)this.IIIlIll(new IIllIlIII(lIlIII.l(I[3]), III));
      this.lIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(I[IIll(-830950920, 969941560)]), true));
      this.lIII = (IIllIlIII)this.IIIlIll(new IIllIlIII(lIlIII.l(I[IIll(-830950919, -1920319610)]), IlIl));
      this.IlII = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(I[IIll(-830950918, 1795430102)]), true));
      this.lIll = (IIllIlIII)this.IIIlIll(new IIllIlIII(lIlIII.l(I[2]), lIIl));
   }

   public void lI() {
   }

   private Color IlI(Color var1, class_2338 var2) {
      double var3 = (double)var2.method_10263() * 0.061 + (double)var2.method_10264() * 0.021 + (double)var2.method_10260() * 0.043;
      Color var10000;
      switch (((<undefinedtype>)this.l.III()).ordinal()) {
         case 0 -> var10000 = var1;
         case 1 -> var10000 = IIlIIllIl.Ill(var1, null.l, var3);
         case 2 -> var10000 = IIlIIllIl.Ill(var1, null.ll, var3);
         case 3 -> var10000 = IIlIIllIl.Ill(var1, null.II, var3);
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   public void lII(Object var1) {
      if (this.IIIIIlI() && ((Boolean)this.llII.III() || (Boolean)this.lIlI.III()) && IIlIIIIl.IlIII(var1)) {
         class_310 var2 = class_310.method_1551();
         if (var2.field_1724 != null && var2.field_1687 != null) {
            double var3 = (Double)this.IllI.III() / (double)100.0F * (double)255.0F;
            int var5 = (Integer)var2.field_1690.method_42503().method_41753();
            int var6 = Math.max(1, Math.min(var5, IIll(-830950917, -1225954851)));
            int var7 = var2.field_1724.method_24515().method_10263() >> 4;
            int var8 = var2.field_1724.method_24515().method_10260() >> 4;

            for(int var9 = var7 - var6; var9 <= var7 + var6; ++var9) {
               for(int var10 = var8 - var6; var10 <= var8 + var6; ++var10) {
                  class_2818 var11 = var2.field_1687.method_2935().method_21730(var9, var10);
                  if (var11 != null) {
                     class_238 var12 = new class_238((double)(var9 << 4), (double)var2.field_1687.method_31607(), (double)(var10 << 4), (double)(var9 << 4) + (double)16.0F, (double)var2.field_1687.method_31600() + (double)1.0F, (double)(var10 << 4) + (double)16.0F);
                     if (IIlIIIIl.IIIl(var1, var12)) {
                        for(class_2586 var14 : var11.method_12214().values()) {
                           class_2338 var15 = var14.method_11016();
                           class_238 var16 = new class_238((double)var15.method_10263(), (double)var15.method_10264(), (double)var15.method_10260(), (double)var15.method_10263() + (double)1.0F, (double)var15.method_10264() + (double)1.0F, (double)var15.method_10260() + (double)1.0F);
                           if (IIlIIIIl.IIIl(var1, var16)) {
                              Color var17 = this.ll(var14);
                              if (var17 != null) {
                                 Color var18 = this.IlI(var17, var15);
                                 this.llI(var1, var16, var18, var3);
                              }
                           }
                        }
                     }
                  }
               }
            }

         }
      }
   }

   public void IIIlI(class_332 var1, int var2, int var3, float var4) {
   }

   private void llI(Object var1, class_238 var2, Color var3, double var4) {
      if ((Boolean)this.llII.III()) {
         if (this.l.III() == null.lI) {
            IIlIIIIl.IIll(var1, var2.method_1014(0.035), IIlIIllIl.IlI(var3, 0.78), var4 * 0.78);
         }

         IIlIIIIl.IIll(var1, var2, var3, var4);
      }

      if ((Boolean)this.lIlI.III()) {
         if (this.l.III() == null.lI) {
            IIlIIIIl.I(var1, var2.method_1014(0.035), IIlIIllIl.IlI(var3, 0.72), (double)165.0F, 3.0F);
         }

         IIlIIIIl.I(var1, var2, var3, (double)255.0F, this.l.III() == null.lI ? 2.4F : 2.0F);
      }

   }

   private static String lll(char[] var0, long var1, int var3) {
      int var4 = IIll(-830950940, -40224334) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IIll(-830950939, 211565443);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   static {
      short var6 = 28976;
      String var7 = "鿗铼蛓炙䀛䎭蛒㎞泠絾͒惷込魢麃숉歷뱫ᴥ稬∾ﶁ㐏䏏烱捧篘埫ᗈꦑ뱲뺓鶍擎\ue558ꃚ誌箞逖鑴ꏣ䔍륽䊮ꔴ㷚၊钦䣭\ud870\ue117湢欪䯉뢼庿ᮁೱᢒ妵셎\uf6de\uf281뛀ⶄ\ue41b㖚躃ퟶ\uf891\uf3ec볽퐑\udfd2ࣶ怴\ue8e8櫒넔ےధ汖<䣙辌𢡄⚹抓鰨齨∁䋚\ue6ba쯴즁此\uf308菱䗘슽\ud81a\ue7af鉯슫瀃ĕ⚸थ烺絵皥〉긓輪⪏萗\u2e6cฉ侜ꠇ\ue47c\ue38e撣➛鄔蟗ᎍ\ueceb뺳ᔪ\udd34\ueb79嚹騌ꉢম뒹洌嘚䚤횚栜炄訷樥ၣ㇛ꌇ뜢炀\udccb肗䱞땗银䝗柯潐뭹筸ö近;鈒쁜溌唺먙乎ӆ묣㤳鐚劾졚\ud7a9ᙪᣆ霯䧳Ⲷ\ud987⍿\uda52◮ᰮ쒆黻㪕\ued40㏡繿慘\uf47d\ue3c3鷎ำ驶︊桶䬯ᅎ璑잾琌믦춪잕\u17eb擡鼬\uead5筄⮝찚툫\udd7b\udd11ഘ险밭좠ꮻ\ue007齘迯\uf434☬퉆蛳ᾇ吏\udd68膞\u1777ಿ\ue745깢痘慨Ⲑﹺ쁇（超㟨䇕軌⧱캖嵲纖駸都\udad4峵졔컃\udcd0콆ԇ覷잲㑣\ud901銋鸘ြ㥟스跶0Ξ锧\ue50d쫅懨㟭\u0c52\ue5e6\ud8db\ue951뮂댓\uf0e2\uefe3둛솨\udb86쩲\uda6bⓃ鰸唕쭀闘潲ӕ焏⩠牀ꨥ\udd4f쁡셷鳉՟尛儜䬊尃氡ᦞ⁔\ue01a꣮쇳䢿鵪喎ര玓匨緎ⱴ쨶璇誋ퟺᬙ棉良俳\u2d6c\ud927爛ਇ\uf632轚馈롋帄\uf653ⅱⒺ濳葑觢";
      char[] var8 = "焸焼焤焤焤焠焠焼焸焸焼焼焸焼焼煴焠焼焠焠焨".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            lllI = var9;
            llll = new Object[var9.length];
            int var2 = -295121176;
            byte[] var0 = "¥\u0006ý\u009f\u008fÐf¶ù·\u0095ñ\u001cÀ\"Y*Á±ÇDÛò\tbÿu\u0088\tì6³ïéÈ8\u0006Q¦zÙ5k\u0087\u0083½4A\u0019À]8\u00ad\u009a@\u0083K\u0014iÃ\u0096ý\u0016Æ\u0001s\u009eî,\u008cDqåÜuö*\u001c¦\u001b\u001e\u0082:6\u00ad\u0012ã·Ã\u0084ª>vPFíqîQ\u009e1Y¨wÄ\u000e1-Ã\u009fmc°£ç×òðÚo\u008a\u0096ø\u0091ð\u0098p\u0096\u009d[\u0012·þºä¾±ÉU\u0083\u008cÃ\u0092<T\f+¿É¥@[\u0090£½è\u0081h\u0004Gt\u008c\u0081É*zWµ¨BNP\u00ad?ë\u0018\u00018\u008e<I\t9ì\u0014\u001b\u0094hi\u0015»ê\u0091Ú\u0081PÀ5V\u0083b&µN,¾åRÑ8#©¸\u009cã%+øâjµ½¡\u000eZ±\u000e\u001a¡ï½vª~\u0090çtÔ%Á³¸\u009b ²â\u0017¥Q®9©ã)»Âû\u001fwGA)\u0019Ò\u001bØ.-\u0090=\u0005\u0086>%ßåùEmÞ%\u0010\u0007d\u001b¨ëIKÉ\u0001ç\u0007\u009d\u001e\u0096\u008fr>ÚáÃL\u0017".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            llIl = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               llIl[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            I = new String[IIll(-830950938, -976483603)];
            IIII();
            Ill = new Color(IIll(-830950937, 168614379), IIll(-830950944, 1049773538), IIll(-830950943, -1929208692));
            IIIl = new Color(IIll(-830950942, -476785205), IIll(-830950941, 1447049542), IIll(-830950932, 1375612594));
            IIl = new Color(IIll(-830950931, 290052050), IIll(-830950930, -467775861), IIll(-830950929, -477162812));
            llI = new Color(IIll(-830950936, -1867278217), IIll(-830950935, -757029426), IIll(-830950934, -1434024141));
            III = new Color(IIll(-830950933, -796389526), IIll(-830950956, -1119130139), IIll(-830950955, -559244489));
            IlIl = new Color(IIll(-830950954, -1848038863), IIll(-830950953, -1395397327), IIll(-830950960, 1948013647));
            lIIl = new Color(IIll(-830950959, -373997818), IIll(-830950958, -1330396646), IIll(-830950957, -1585939581));
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static void IIII() {
      I[0] = lll(IlII(-210226158, -303411781).toCharArray(), 61674L, IIll(-830950948, 673687082));
      I[1] = lll(IlII(-210226157, -1036642491).toCharArray(), 34604L, IIll(-830950947, -1265718177));
      I[2] = lll(IlII(-210226160, -484365571).toCharArray(), 42615L, IIll(-830950946, -572066969));
      I[3] = lll(IlII(-210226159, -112967691).toCharArray(), 35619L, IIll(-830950945, 1560913563));
      I[4] = lll(IlII(-210226154, 1678706406).toCharArray(), 22128L, IIll(-830950952, 1043956573));
      I[5] = lll(IlII(-210226153, 1007961717).toCharArray(), 44814L, IIll(-830950951, -587285913));
      I[IIll(-830950950, 873196380)] = lll(IlII(-210226156, 2127245583).toCharArray(), 81305L, IIll(-830950949, -1647868629));
      I[IIll(-830950972, -1312096645)] = lll(IlII(-210226155, 2034594491).toCharArray(), 8968L, IIll(-830950971, -816831001));
      I[IIll(-830950970, 1110887016)] = lll(IlII(-210226150, -1152050546).toCharArray(), 66237L, IIll(-830950969, -2038616956));
      I[IIll(-830950976, -249013112)] = lll(IlII(-210226149, -603973467).toCharArray(), 75342L, IIll(-830950975, -1100533570));
      I[IIll(-830950974, 199793994)] = lll(IlII(-210226152, -662882414).toCharArray(), 52411L, IIll(-830950973, 1222259769));
      I[IIll(-830950964, 2057400629)] = lll(IlII(-210226151, -1790158874).toCharArray(), 57916L, IIll(-830950963, 1203034937));
      I[IIll(-830950962, -1972441139)] = lll(IlII(-210226146, -1735450224).toCharArray(), 68255L, IIll(-830950961, -737628976));
      I[IIll(-830950968, -1817647987)] = lll(IlII(-210226145, 520632228).toCharArray(), 7903L, IIll(-830950967, -1208857226));
      I[IIll(-830950966, 1908295301)] = lll(IlII(-210226148, 62153645).toCharArray(), 32250L, IIll(-830950965, 1799304666));
      I[IIll(-830950988, -619771884)] = lll(IlII(-210226147, 327292566).toCharArray(), 2457L, IIll(-830950987, -607888235));
      I[IIll(-830950986, 1002983779)] = lll(IlII(-210226174, -902751851).toCharArray(), 72511L, IIll(-830950985, 304240281));
      I[IIll(-830950992, 506831020)] = lll(IlII(-210226173, -1237503893).toCharArray(), 62003L, IIll(-830950991, 1831825594));
      I[IIll(-830950990, 83916844)] = lll(IlII(-210226176, -107269421).toCharArray(), 39847L, IIll(-830950989, -1267233348));
      I[IIll(-830950980, 1809415840)] = lll(IlII(-210226175, -1474335004).toCharArray(), 65614L, IIll(-830950979, 1689805331));
      I[IIll(-830950978, -1352515176)] = lll(IlII(-210226170, 558774672).toCharArray(), 84333L, IIll(-830950977, 1477823643));
   }

   private static int IIll(int var0, int var1) {
      return llIl[var0 ^ -830950924] ^ var1 ^ var0;
   }

   private static String IlII(int var0, int var1) {
      int var3 = var0 ^ -210226158;
      char[] var4 = lllI[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])llll[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         llll[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 664316916;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 35;
               break;
            case 1:
               var9 = 68;
               break;
            case 2:
               var9 = 35;
               break;
            case 3:
               var9 = 246;
               break;
            case 4:
               var9 = 234;
               break;
            case 5:
               var9 = 124;
               break;
            case 6:
               var9 = 6;
               break;
            case 7:
               var9 = 107;
               break;
            case 8:
               var9 = 245;
               break;
            case 9:
               var9 = 240;
               break;
            case 10:
               var9 = 37;
               break;
            case 11:
               var9 = 121;
               break;
            case 12:
               var9 = 101;
               break;
            case 13:
               var9 = 176;
               break;
            case 14:
               var9 = 92;
               break;
            case 15:
               var9 = 102;
               break;
            case 16:
               var9 = 86;
               break;
            case 17:
               var9 = 80;
               break;
            case 18:
               var9 = 253;
               break;
            case 19:
               var9 = 254;
               break;
            case 20:
               var9 = 236;
               break;
            case 21:
               var9 = 254;
               break;
            case 22:
               var9 = 43;
               break;
            case 23:
               var9 = 139;
               break;
            case 24:
               var9 = 86;
               break;
            case 25:
               var9 = 146;
               break;
            case 26:
               var9 = 123;
               break;
            case 27:
               var9 = 236;
               break;
            case 28:
               var9 = 180;
               break;
            case 29:
               var9 = 162;
               break;
            case 30:
               var9 = 61;
               break;
            case 31:
               var9 = 208;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
