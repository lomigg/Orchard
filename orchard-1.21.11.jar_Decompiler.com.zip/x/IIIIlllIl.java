package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
record IIIIlllIl(int entityId, <undefinedtype> part) {
   private final int I;
   private final <undefinedtype> l;

   public <undefinedtype> I() {
      return this.l;
   }

   public int l() {
      return this.I;
   }

   private IIIIlllIl(int var1, Object var2) {
      this.I = var1;
      this.l = var2;
   }
}
