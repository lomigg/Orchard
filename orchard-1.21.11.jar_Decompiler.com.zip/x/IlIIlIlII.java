package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_310;

@Environment(EnvType.CLIENT)
public final class IlIIlIlII extends IIIIIIIlI {
   private final lIIIIl I = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(llI(-1377488291, -1650506377)), true));
   private static volatile IlIIlIlII l;
   private final lIIIIl II = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(llI(-1377488292, 1889621539)), true));
   private static final String[] Il;
   private static final Object[] lI;

   public IlIIlIlII() {
      super((Object)lIlIII.l(llI(-1377488290, -1386848017)), lIllII.ll, (Object)lIlIII.l(llI(-1377488289, 1136200474)));
      l = this;
   }

   public static boolean ll(class_1297 var0) {
      IlIIlIlII var1 = l;
      if (var1 != null && var1.IIIIIlI() && (Boolean)var1.I.III() && var0 instanceof class_1657 var2) {
         class_310 var3 = class_310.method_1551();
         return var3.field_1724 != null && var2 != var3.field_1724;
      } else {
         return false;
      }
   }

   public static boolean IlI(class_1297 var0) {
      IlIIlIlII var1 = l;
      if (var1 != null && var1.IIIIIlI() && (Boolean)var1.II.III() && var0 instanceof class_1657 var2) {
         class_310 var3 = class_310.method_1551();
         return var3.field_1724 != null && var2 != var3.field_1724;
      } else {
         return false;
      }
   }

   public static void lII() {
      l = null;
   }

   static {
      short var0 = 15677;
      String var1 = "꾳꽑꾻꼡꾲꽇꽓꽼꾩꾵꼑꾇꿢꽄꼼꿠䅞䆾䄍䇉䅘䆫䆫䆍䅖䅌䇮䅯䄚䆫䇡䄍䆜䆄䆚䇮䅑䅙䅯䇔䄈䅔䇞䆡䄥䆁䆶䄸䅆䆦䅍䇉䅣䆿䇫䆞䄳䅇䇘䅆䅸䆧䇊䄗䆙䇑䆢䇀䄺䅿䅃䇏䄳䅦䆾䆀牆犦爕狑牀犴犰犣牃牄犇牚爕犠犊爐齸龘鼫鿯齾龊龎鿆齰齪鿌齸鼧龍龰鼀龰鿚鿣龸";
      char[] var2 = "㴭㴁㴭㴩".toCharArray();
      String[] var3 = new String[var2.length];
      byte var7 = -1;

      while(true) {
         int var4 = 0;
         int var5 = 0;
         int var6 = 0;
         if (var7 == 0) {
            Il = var3;
            lI = new Object[var3.length];
            return;
         }

         do {
            var6 = var2[var4] ^ var0;
            var3[var4] = var1.substring(var5, var5 + var6);
            var5 += var6;
            ++var4;
         } while(var4 < var2.length);

         var7 = 0;
      }
   }

   private static String llI(int var0, int var1) {
      int var3 = var0 ^ -1377488290;
      char[] var4 = Il[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])lI[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         lI[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 1636175107;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 255;
               break;
            case 1:
               var9 = 38;
               break;
            case 2:
               var9 = 238;
               break;
            case 3:
               var9 = 74;
               break;
            case 4:
               var9 = 231;
               break;
            case 5:
               var9 = 40;
               break;
            case 6:
               var9 = 22;
               break;
            case 7:
               var9 = 7;
               break;
            case 8:
               var9 = 209;
               break;
            case 9:
               var9 = 204;
               break;
            case 10:
               var9 = 127;
               break;
            case 11:
               var9 = 223;
               break;
            case 12:
               var9 = 155;
               break;
            case 13:
               var9 = 51;
               break;
            case 14:
               var9 = 113;
               break;
            case 15:
               var9 = 145;
               break;
            case 16:
               var9 = 12;
               break;
            case 17:
               var9 = 111;
               break;
            case 18:
               var9 = 42;
               break;
            case 19:
               var9 = 113;
               break;
            case 20:
               var9 = 176;
               break;
            case 21:
               var9 = 228;
               break;
            case 22:
               var9 = 212;
               break;
            case 23:
               var9 = 95;
               break;
            case 24:
               var9 = 140;
               break;
            case 25:
               var9 = 223;
               break;
            case 26:
               var9 = 89;
               break;
            case 27:
               var9 = 16;
               break;
            case 28:
               var9 = 165;
               break;
            case 29:
               var9 = 6;
               break;
            case 30:
               var9 = 42;
               break;
            case 31:
               var9 = 137;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
