package x;

import java.util.IdentityHashMap;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
final class IIllIlll {
   private static <undefinedtype> I;
   private static long l;
   private static long II;
   private static final IdentityHashMap<Object, Long> Il;
   private static int lI;
   private static final int[] ll;

   static synchronized boolean I(Object var0, long var1, long var3) {
      if (llI(var0, var1) && I.I() == null.II && var3 > I.lI()) {
         I = IIll(null.I);
         return true;
      } else {
         return false;
      }
   }

   private IIllIlll() {
   }

   static synchronized <undefinedtype> l(Object var0, int var1) {
      Long var2 = (Long)Il.remove(var0);
      if (var2 == null) {
         return null.II;
      } else if (var2 == l && lI == var1) {
         l = 0L;
         lI = -1;
         return null.ll;
      } else {
         return null.Il;
      }
   }

   static synchronized void II(int var0) {
      if (lI == var0) {
         lI = -1;
      }

   }

   static synchronized boolean Il(Object var0, long var1, int var3, int var4) {
      return llI(var0, var1) && I.I() == null.I && I.l() == var3 && I.Il() == var4;
   }

   static synchronized boolean lI(int var0, int var1) {
      return lI < 0 && var0 == var1;
   }

   static synchronized boolean ll(Object var0, long var1, int var3) {
      if (!llI(var0, var1)) {
         return false;
      } else {
         boolean var10000;
         switch (I.I().ordinal()) {
            case 0 -> var10000 = var3 == I.l();
            case 3 -> var10000 = var3 == I.Il();
            default -> var10000 = false;
         }

         return var10000;
      }
   }

   static synchronized boolean III(Object var0, long var1, int var3) {
      if (llI(var0, var1) && I.I() == null.I && I.Il() == var3) {
         I = IIll(null.lI);
         return true;
      } else {
         return false;
      }
   }

   static synchronized boolean IIl(Object var0, int var1, int var2, long var3, long var5) {
      if (var0 == null || var1 < 0 || var1 > IlII(-1079038933, 951128240) || var2 < 0 || var2 > IlII(-1079038934, 1558746724) || var1 == var2 || I != null && I.ll() != var3) {
         return false;
      } else {
         I = new Record(var0, var1, var2, var3, var5, null.l) {
            private final long I;
            private final int l;
            private final Object II;
            private final int Il;
            private final long lI;
            private final <undefinedtype> ll;

            public <undefinedtype> I() {
               return this.ll;
            }

            public int l() {
               return this.Il;
            }

            {
               this.II = var1;
               this.Il = var2;
               this.l = var3;
               this.lI = var4;
               this.I = var6;
               this.ll = var8;
            }

            public Object II() {
               return this.II;
            }

            public int Il() {
               return this.l;
            }

            public long lI() {
               return this.I;
            }

            public long ll() {
               return this.lI;
            }
         };
         return true;
      }
   }

   static {
      int var2 = 13550623;
      byte[] var0 = "\u0087Ðø\u008cã\u0089~Y".getBytes("ISO-8859-1");
      int var1 = var0.length / 4;
      ll = new int[var1];
      int var3 = 0;
      int var4 = 0;

      do {
         int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
         var5 ^= var2;
         ll[var4] = var5;
         var3 += 4;
         ++var4;
      } while(var4 < var1);

      lI = -1;
      Il = new IdentityHashMap();
   }

   static synchronized void IlI(Object var0, long var1) {
      if (llI(var0, var1)) {
         I = null;
      }

   }

   static synchronized void Ill(int var0) {
      lI = var0;
   }

   static synchronized int lII() {
      return lI;
   }

   static synchronized boolean lIl(Object var0, long var1, int var3) {
      if (!ll(var0, var1, var3)) {
         return false;
      } else {
         <undefinedtype> var4 = I.I() == null.l ? null.II : null.Il;
         I = IIll(var4);
         return true;
      }
   }

   private static boolean llI(Object var0, long var1) {
      return I != null && I.II() == var0 && I.ll() == var1;
   }

   static synchronized boolean lll(long var0) {
      return I != null && I.ll() == var0;
   }

   static synchronized boolean IIII(Object var0, int var1) {
      Long var2 = (Long)Il.remove(var0);
      if (var2 != null && var2 == l && lI == var1) {
         l = 0L;
         lI = -1;
         return true;
      } else {
         return false;
      }
   }

   static synchronized void IIIl(Object var0, int var1) {
      if (var0 != null && !Il.containsKey(var0)) {
         long var2 = ++II;
         Il.put(var0, var2);
         l = var2;
         lI = var1;
      }
   }

   static synchronized void IIlI() {
      l = 0L;
      lI = -1;
      Il.clear();
      I = null;
   }

   private static <undefinedtype> IIll(Object var0) {
      return new Record(I.II(), I.l(), I.Il(), I.ll(), I.lI(), var0) {
         private final long I;
         private final int l;
         private final Object II;
         private final int Il;
         private final long lI;
         private final <undefinedtype> ll;

         public <undefinedtype> I() {
            return this.ll;
         }

         public int l() {
            return this.Il;
         }

         {
            this.II = var1;
            this.Il = var2;
            this.l = var3;
            this.lI = var4;
            this.I = var6;
            this.ll = var8;
         }

         public Object II() {
            return this.II;
         }

         public int Il() {
            return this.l;
         }

         public long lI() {
            return this.I;
         }

         public long ll() {
            return this.lI;
         }
      };
   }

   private static int IlII(int var0, int var1) {
      return ll[var0 ^ -1079038933] ^ var1 ^ var0;
   }
}
