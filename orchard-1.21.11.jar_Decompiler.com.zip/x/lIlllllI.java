package x;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class lIlllllI {
   public static final double I = 0.01;
   public static final double l = 0.01;
   private static final double II = (double)32.0F;
   private static final double Il = (double)3.0F;
   public static final boolean lI = true;
   private static final double ll = (double)620.0F;
   private static final double III = (double)64.0F;
   private static final double IIl = (double)382.0F;
   private static final String[] IlI;
   private static final Object[] Ill;

   public static <undefinedtype> I(boolean var0, boolean var1, boolean var2, boolean var3, float var4, float var5) {
      float var6 = (var0 ? 1.0F : 0.0F) - (var1 ? 1.0F : 0.0F);
      float var7 = (var2 ? 1.0F : 0.0F) - (var3 ? 1.0F : 0.0F);
      float var8 = (float)Math.sqrt((double)(var6 * var6 + var7 * var7));
      if (var8 <= 1.0E-4F) {
         return new Record(0.0F, 0.0F) {
            private final float I;
            private final float l;

            public {
               this.I = var1;
               this.l = var2;
            }

            public float I() {
               return this.I;
            }

            public float l() {
               return this.l;
            }
         };
      } else {
         if (var8 > 1.0F) {
            var6 /= var8;
            var7 /= var8;
         }

         float var9 = Illl(var4 - var5);
         float var10 = (float)Math.toRadians((double)var9);
         float var11 = (float)Math.sin((double)var10);
         float var12 = (float)Math.cos((double)var10);
         float var13 = var7 * var12 + var6 * var11;
         float var14 = var6 * var12 - var7 * var11;
         float var15 = (float)Math.sqrt((double)(var14 * var14 + var13 * var13));
         if (var15 > 1.0F) {
            var14 /= var15;
            var13 /= var15;
         }

         return new Record(var14, var13) {
            private final float I;
            private final float l;

            public {
               this.I = var1;
               this.l = var2;
            }

            public float I() {
               return this.I;
            }

            public float l() {
               return this.l;
            }
         };
      }
   }

   public static boolean l(boolean var0, int var1, boolean var2) {
      return !var2 && (var0 || var1 > 0);
   }

   public static boolean II(boolean var0, String var1) {
      return var0 && var1 != null && !var1.isBlank();
   }

   public static int Il(int var0, int var1) {
      return var0 + 1 + Math.max(0, var1);
   }

   public static double lI(double var0) {
      double var2 = Double.isFinite(var0) ? Math.max((double)0.0F, var0) : (double)0.0F;
      double var4 = Math.min((double)1.0F, var2 / (double)30.0F);
      double var6 = var4 * var4 * ((double)3.0F - (double)2.0F * var4);
      return 0.14 + var6 * 0.86;
   }

   public static boolean ll(boolean var0, boolean var1, double var2, double var4) {
      return var0 && !var1 && (var2 >= (double)0.0F || var4 <= (double)0.0F);
   }

   private static boolean III(double var0, double var2, double var4, double var6, double[] var8) {
      if (!(Math.abs(var2) < 1.0E-9)) {
         double var9 = (var4 - var0) / var2;
         double var11 = (var6 - var0) / var2;
         if (var9 > var11) {
            double var13 = var9;
            var9 = var11;
            var11 = var13;
         }

         var8[0] = Math.max(var8[0], var9);
         var8[1] = Math.min(var8[1], var11);
         return var8[0] <= var8[1];
      } else {
         return var0 >= var4 && var0 <= var6;
      }
   }

   public static boolean IIl(double var0, double var2, double var4, double var6, double var8) {
      double var10 = Math.max((double)0.0F, var4);
      double var12 = var6 - var0;
      double var14 = var8 - var2;
      return var12 * var12 + var14 * var14 <= var10 * var10;
   }

   public static double IlI(double var0) {
      return IlII(var0, 0.85);
   }

   public static String Ill(String var0, int var1) {
      String var2 = var0 != null && !var0.isBlank() ? var0.trim() : lIlIII.Il(llll((short)'껇', 1528177841, 19190));
      int var4 = Math.max(1, var1);
      return var2 + var4;
   }

   public static boolean lII(double var0, double var2, double var4, double var6, double var8, double var10, double var12, double var14, double var16, double var18, double var20, double var22) {
      double[] var24 = new double[]{(double)0.0F, (double)1.0F};
      if (III(var0, var6 - var0, Math.min(var12, var18), Math.max(var12, var18), var24) && III(var2, var8 - var2, Math.min(var14, var20), Math.max(var14, var20), var24) && III(var4, var10 - var4, Math.min(var16, var22), Math.max(var16, var22), var24)) {
         return var24[0] < 0.999999 && var24[1] >= (double)0.0F;
      } else {
         return false;
      }
   }

   public static boolean lIl(long var0, long var2) {
      return var0 < var2;
   }

   public static boolean llI(double var0, double var2) {
      return var0 < lIII(var2);
   }

   public static double lll(double var0) {
      double var2 = Double.isFinite(var0) ? Math.max((double)0.0F, var0) : (double)0.0F;
      double var4 = Math.max((double)0.0F, Math.min((double)1.0F, (var2 - (double)0.5F) / (double)11.5F));
      return var4 * var4 * ((double)3.0F - (double)2.0F * var4);
   }

   private lIlllllI() {
   }

   public static boolean IIII(double var0, double var2) {
      return var0 >= lIII(var2);
   }

   public static double IIIl(double var0, int var2, int var3) {
      double var4 = Double.isFinite(var0) ? Math.max((double)1.0F, var0) : (double)1.0F;
      double var6 = (double)Math.max(1, var2) / (double)652.0F;
      double var8 = (double)Math.max(1, var3) / (double)446.0F;
      double var10 = Math.max((double)1.0F, Math.min(var6, var8));
      return Math.min(var4, Math.min((double)3.0F, var10));
   }

   public static long IIlI(long var0, long var2, long var4) {
      return Math.max(var0, var2 + Math.max(0L, var4));
   }

   public static boolean IIll(Object var0, Object var1) {
      return !Objects.deepEquals(var0, var1);
   }

   public static double IlII(double var0, double var2) {
      double var4 = Double.isFinite(var0) ? Math.max((double)0.0F, Math.min(var0, 0.1)) : (double)0.0F;
      double var6 = Double.isFinite(var2) ? Math.max((double)0.0F, Math.min(var2, (double)1.0F)) : 0.85;
      double var8 = (double)12.0F - var6 * (double)9.5F;
      return (double)1.0F - Math.exp(-var4 * var8);
   }

   public static double IlIl(boolean var0, boolean var1) {
      if (var0 && !var1) {
         return 0.86;
      } else {
         return var1 && !var0 ? 0.58 : 0.73;
      }
   }

   public static boolean IllI(boolean var0, boolean var1) {
      return var0 && var1;
   }

   public static float Illl(float var0) {
      float var1 = var0 % 360.0F;
      if (var1 >= 180.0F) {
         var1 -= 360.0F;
      }

      if (var1 < -180.0F) {
         var1 += 360.0F;
      }

      return var1;
   }

   private static double lIII(double var0) {
      return Math.max((double)0.0F, Math.min((double)100.0F, var0));
   }

   public static double lIIl(double var0, double var2, double var4) {
      double var6 = Double.isFinite(var0) ? var0 : (double)0.0F;
      double var8 = Double.isFinite(var2) ? var2 : (double)0.0F;
      double var10 = Double.isFinite(var4) ? Math.max((double)0.0F, var4) : (double)0.0F;
      return Math.max(var6 - var10, Math.min(var6 + var10, var8));
   }

   public static String lIlI(long var0, long var2) {
      return Long.toString(var0 + Math.max(1L, var2));
   }

   public static double lIll(int var0, int var1) {
      if (var0 <= 0) {
         return (double)100.0F;
      } else {
         int var2 = Math.max(0, Math.min(var0, var1));
         return (double)(var0 - var2) * (double)100.0F / (double)var0;
      }
   }

   public static boolean llII(double var0, double var2, double var4, double var6, double var8, double var10, double var12) {
      double var14 = Math.max((double)0.0F, var4);
      double var16 = Math.max(Math.min(var6, var10), Math.min(var0, Math.max(var6, var10)));
      double var18 = Math.max(Math.min(var8, var12), Math.min(var2, Math.max(var8, var12)));
      double var20 = var16 - var0;
      double var22 = var18 - var2;
      return var20 * var20 + var22 * var22 <= var14 * var14;
   }

   public static List<String> llIl(String var0, String var1) {
      if (var0 != null && !var0.isBlank()) {
         String var2 = var1 != null && !var1.isBlank() ? var1 : lIlIII.Il(llll((short)4942, 1945069095, 19191));
         String[] var3 = var0.split(var2);
         ArrayList var4 = new ArrayList();

         for(String var8 : var3) {
            if (var8 != null) {
               String var9 = var8.trim();
               if (!var9.isEmpty()) {
                  var4.add(var9);
               }
            }
         }

         return List.copyOf(var4);
      } else {
         return List.of();
      }
   }

   public static boolean lllI(long var0, long var2, long var4) {
      return var4 <= 0L || var0 >= var2;
   }

   static {
      short var0 = 32144;
      String var1 = "ꚁꤦꚈꤪꚈꤞꙸꤺ双双厂厂";
      char[] var2 = "綘綔".toCharArray();
      String[] var3 = new String[var2.length];
      byte var7 = -1;

      while(true) {
         int var4 = 0;
         int var5 = 0;
         int var6 = 0;
         if (var7 == 0) {
            IlI = var3;
            Ill = new Object[var3.length];
            return;
         }

         do {
            var6 = var2[var4] ^ var0;
            var3[var4] = var1.substring(var5, var5 + var6);
            var5 += var6;
            ++var4;
         } while(var4 < var2.length);

         var7 = 0;
      }
   }

   private static String llll(short var0, int var1, int var2) {
      int var3 = var2 ^ 19190;
      char[] var4 = IlI[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])Ill[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         Ill[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 16601;
      int var9 = 0;

      do {
         int var10 = var4[var9] - '蓎';
         var10 += 56040;
         var10 ^= 5743;
         var10 ^= 36631;
         var10 -= 19782;
         var10 ^= 56257;
         var10 += 42444;
         var10 += 59908;
         var10 -= 55926;
         var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
