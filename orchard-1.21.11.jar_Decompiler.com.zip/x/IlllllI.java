package x;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Objects;
import java.util.UUID;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_640;
import net.minecraft.class_327.class_6415;
import org.joml.Matrix4f;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Environment(EnvType.CLIENT)
public final class IlllllI {
   private static Method I;
   private static Class<?> l;
   private static Field II;
   private static boolean Il;
   private static Field lI;
   private static Method ll;
   private static boolean III;
   private static final float IIl = 2.0F;
   private static final float IlI = -0.1F;
   private static Field Ill;
   private static Class<?> lII;
   private static Method lIl;
   private static Method llI;
   private static final float lll = 3.0F;
   private static Method IIII;
   private static Method IIIl;
   private static final Logger IIlI;
   private static Field IIll;
   private static Class<?> IlII;
   private static Field IlIl;
   private static final int[] IllI;
   private static final String[] Illl;
   private static final Object[] lIII;

   public static <undefinedtype> I(UUID var0) {
      IIIIIl var1 = lI();
      return var1 != null && var1.I(var0) ? var1.III() : null;
   }

   private static boolean l(UUID var0) {
      IIIIIl var1 = lI();
      return var1 != null && var1.I(var0);
   }

   private static String II(class_2561 var0) {
      return var0 == null ? "" : var0.getString().trim();
   }

   public static <undefinedtype> Il(class_1657 var0) {
      return var0 == null ? null : I(var0.method_5667());
   }

   private static IIIIIl lI() {
      lIllIIl var0 = lIllIIl.Il();
      if (var0 == null) {
         return null;
      } else {
         IIIIIl var1 = var0.IIl().IIlIlII();
         return var1 != null && var1.IIIIIlI() ? var1 : null;
      }
   }

   public static void ll(Object var0, class_2561 var1) {
      if (var0 != null && var1 != null && lll(var0)) {
         class_310 var2 = class_310.method_1551();
         if (var2.field_1772 != null) {
            try {
               int var3 = var2.field_1772.method_27525(var1);
               <undefinedtype> var4 = I(III(var0));
               if (var4 != null) {
                  var3 += var4.Il();
               }

               Ill.setInt(var0, var3);
            } catch (Exception var5) {
               lIlI(lIlIII.Il(lllI(117802997, -1176958148)), var5);
            }

         }
      }
   }

   private static UUID III(Object var0) {
      if (var0 != null && lll(var0)) {
         try {
            Object var1 = II.get(var0);
            UUID var10000;
            if (var1 instanceof class_1297) {
               class_1297 var2 = (class_1297)var1;
               var10000 = var2.method_5667();
            } else {
               var10000 = null;
            }

            return var10000;
         } catch (Exception var3) {
            lIlI(lIlIII.Il(lllI(117802996, 46671049)), var3);
            return null;
         }
      } else {
         return null;
      }
   }

   public static int IIl(class_332 var0, class_640 var1, class_327 var2, int var3, int var4) {
      if (var0 != null && var1 != null) {
         <undefinedtype> var5 = I(IIIIlII.I(var1.method_2966()));
         if (var5 == null) {
            return 0;
         } else {
            float var6 = var5.IIIl();
            float var7 = var5.IlI();
            float var10000 = (float)var4;
            Objects.requireNonNull(var2);
            float var8 = var10000 + (9.0F - var6) / 2.0F;
            IIIIIIllI.lIIIII(var0, var5.lI(), (double)var3, (double)var8, (double)var7, (double)var6, var5.lII(), var5.llI());
            return var5.Ill();
         }
      } else {
         return 0;
      }
   }

   private static boolean IlI(Object var0) {
      if (var0 != null && lll(var0)) {
         try {
            Object var1 = II.get(var0);
            if (!(var1 instanceof class_1297)) {
               return false;
            } else {
               return !IIll.getBoolean(var0) && lI.getBoolean(var0) && IlIl.get(var0) == null;
            }
         } catch (Exception var2) {
            lIlI(lIlIII.Il(lllI(117802999, -1719834490)), var2);
            return false;
         }
      } else {
         return false;
      }
   }

   public static class_2561 Ill(class_2561 var0) {
      return IllI(var0) ? x.Il.Il(var0) : var0;
   }

   private static boolean lII(UUID var0) {
      return x.Il.IllI(var0);
   }

   public static void lIl(class_2561 var0, class_327 var1, class_4587 var2, class_4597 var3, float var4, float var5, class_327.class_6415 var6, int var7) {
      <undefinedtype> var8 = IllI(var0) ? IlIl() : null;
      if (var8 != null && var1 != null && var2 != null && var3 != null) {
         float var9 = var4 - (float)var8.Il();
         Objects.requireNonNull(var1);
         float var10 = var5 + (9.0F - var8.lll()) / 2.0F;
         llI(var8, var2, var3, var9, var10, var6 == class_6415.field_33994, var7);
      }
   }

   private static void llI(Object var0, class_4587 var1, class_4597 var2, float var3, float var4, boolean var5, int var6) {
      Matrix4f var7 = var1.method_23760().method_23761();
      class_1921 var8 = lIIl(var0.lI());
      if (var8 != null) {
         class_4588 var9 = var2.method_73477(var8);
         float var10 = var0.lIl();
         float var11 = var0.lll();
         var9.method_22918(var7, var3, var4 + var11, 0.0F).method_22913(0.0F, 1.0F).method_39415(-1).method_60803(var6);
         var9.method_22918(var7, var3 + var10, var4 + var11, 0.0F).method_22913(1.0F, 1.0F).method_39415(-1).method_60803(var6);
         var9.method_22918(var7, var3 + var10, var4, 0.0F).method_22913(1.0F, 0.0F).method_39415(-1).method_60803(var6);
         var9.method_22918(var7, var3, var4, 0.0F).method_22913(0.0F, 0.0F).method_39415(-1).method_60803(var6);
      }
   }

   private static boolean lll(Object var0) {
      return false;
   }

   static void IIII() {
      IIIl = null;
      I = null;
      lIl = null;
      IIII = null;
      llI = null;
      ll = null;
      II = null;
      IIll = null;
      lI = null;
      IlIl = null;
      Ill = null;
      l = null;
      lII = null;
      IlII = null;
      Il = false;
      III = false;
   }

   public static <undefinedtype> IIIl(UUID var0, int var1, int var2) {
      <undefinedtype> var3 = I(var0);
      if (var3 != null && Illl()) {
         try {
            Method var10000 = IIIl;
            Object[] var10002 = new Object[llIl(-74663891, 406480094)];
            var10002[0] = var3.lI();
            var10002[1] = (float)var1;
            var10002[2] = (float)var2;
            var10002[3] = var3.IlI();
            var10002[4] = var3.IIIl();
            var10002[5] = 0;
            var10002[llIl(-74663892, -1271731471)] = 0;
            var10002[llIl(-74663889, 1687734297)] = var3.lII();
            var10002[llIl(-74663890, 472581213)] = var3.llI();
            var10002[llIl(-74663895, 2135707544)] = (float)var3.lII();
            var10002[llIl(-74663896, -365394984)] = (float)var3.llI();
            var10002[llIl(-74663893, -1116680159)] = -1;
            var10000.invoke((Object)null, var10002);
            return new Record(true, var3.Ill()) {
               private final int I;
               private final boolean l;
               private static final <undefinedtype> II = new <anonymous constructor>(false, 0);

               public int I() {
                  return this.I;
               }

               public {
                  this.l = var1;
                  this.I = var2;
               }

               public boolean l() {
                  return this.l;
               }
            };
         } catch (Exception var5) {
            lIlI(lIlIII.Il(lllI(117802998, 108543473)), var5);
            return null.II;
         }
      } else {
         return null.II;
      }
   }

   static {
      short var6 = 20084;
      String var7 = "拌扊抙扛抓托抽抋扽戊拮执抅戒扏抶抙扂拁扈戏抽抇拆戢戌戕抈戛戽手拴拈扴抲扆抨托抱拥\ud9df\ud973\ud99d\ud94c\ud980\ud95f\ud9f0\ud9b0\ud97e\ud90c\ud9bd\ud960\ud997\ud911\ud95b\ud9b8\ud99e\ud918\ud9a5\ud95b\ud91f\ud9d2\ud9c8\ud9cd\ud931\ud91f\ud916\ud99b\ud90c\ud92a\ud94b\ud9cc\ud9d1\ud974\ud9eb\ud927䉨䋬䈞䋧䈲䋮䉑䈨䋏䊭䉃䋩䈧䊴䊫䈏䈽䊭䉁䋅䋲䈢䈮䉯䊅䊪䊼䈺䊽䊶䋋䉾䉫䋴䈗䋊䈌䋽䉆䉀\udd4c\udde0\udd0e\udde8\udd13\uddc8\udd77\udd1d\uddfe\udd8f\udd6d\udde0\udd04\uddfd\uddd7\udd3d\udd1d\uddfc\udd2a\uddf6\udd8a\udd41\udd08\udd5e\uddb2\udd9f\udd96\udd0b\udd9b\uddae\uddc8\udd5e\udd49\uddf7\udd31\uddd0\udd26\uddcb\udd32\udd66ẢḋỵḸỸḰổủḆṟẸḾỬḖḻớ띕럹뜗럱뜊럑띮뜄럧랐띴럽뜟랈럕뜬뜃럘띛럒랕뜧뜝띜랸랖랏뜒랁랧럑띇띐럮뜨량뜿럒뜫띿ꠝꢱꡟꢐꡄꢣꠈꡈꢼ\ua8ca꠴ꢧꡖꢭ꣘ꡠꡋ꣖ꠄꢜ꣘ꠐꡁꠚ꣰꣣꣗ꡕ\ua8ca\ua8c6ꢳ꠰ꠜꢐꠤ꣥쳨찆청챫첬챫쳔첨챊찭첔챇첢찊챯첖첲챵쳜챁착첍첋첁浉涧洌淊洍淊浵洉淫涎洣消㱱㲟㰴㳲㰱㳇㱍㰄㳛㲵㱋㳝㰷㲻㳲㰑㰠㳼㱜㲩⤗⧹⥒⦔⥗⦄⤷⥃⦰⧀⤩⦤⥉⧝⧕⥢⥄⦍⤝⦡⧒⤝⥀⤑⧿⧥⧊⤳䣿䡓䢽䡲䢦䡁䣪䢪䡞䠨䣖䡅䢴䡏䠺䢂䢩䠴䣦䡾䠺䣲䢣䣸䠒䠁䠵䢷䠨䠤䡑䣒䣾䡲䣆䠇ㅧ㇔ㄪ㇙ㄡㇼㅃㄻ㇊ㆸㅁ㇚ㄢㆵ㇞ㄖㄹㆿㅩ㇈ㆹㄎㄴㅒ㆖ㆸㆦㄅㆿㇻㇰㅞㅿ㇃ㅎ\u31efㄞ\u31ebㄔㄽㆼ㇌ㅙ\u31e5ㄚㆮ㇟ㄜㄥ㇀ㅝ㇏㆔ㄙㄈㅩㆫㆴㇱㅛ";
      char[] var8 = "乜乐乜乜乤乜乐乬乸习乨乐么".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            Illl = var9;
            lIII = new Object[var9.length];
            int var2 = -1422143147;
            byte[] var0 = "H\u008d\rªä\u0085\u0083\u008e4/¡dL\u009cm./û&íº\u008fê¯íÇ¹TóGc\\*1\u001a\u009d³£iSN+Ö×".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IllI = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IllI[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            IIlI = LoggerFactory.getLogger(IlllllI.class);
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public static <undefinedtype> IIlI(UUID var0) {
      return (<undefinedtype>)(l(var0) ? new Record(true, (Integer)null) {
         private static final <undefinedtype> I = new <anonymous constructor>(false, (Integer)null);
         private final Integer l;
         private final boolean II;

         public Integer I() {
            return this.l;
         }

         public {
            this.II = var1;
            this.l = var2;
         }

         public boolean l() {
            return this.II;
         }
      } : null.I);
   }

   public static <undefinedtype> IIll(class_2561 var0) {
      return IllI(var0) ? IlIl() : null;
   }

   public static int IlII(class_2561 var0) {
      <undefinedtype> var1 = IIll(var0);
      return var1 == null ? 0 : var1.Il();
   }

   private static <undefinedtype> IlIl() {
      IIIIIl var0 = lI();
      return var0 == null ? null : var0.III();
   }

   private IlllllI() {
   }

   private static boolean IllI(class_2561 var0) {
      IIIIIl var1 = lI();
      class_310 var2 = class_310.method_1551();
      if (var1 != null && var2.field_1724 != null && var0 != null) {
         String var3 = II(x.Il.Il(var0));
         if (var3.isBlank()) {
            return false;
         } else {
            String var4 = II(x.Il.Il(var2.field_1724.method_5476()));
            if (!var4.isBlank() && var3.equalsIgnoreCase(var4)) {
               return true;
            } else {
               String var5 = IIIIlII.II(var2.field_1724.method_7334());
               return var5 != null && var3.equalsIgnoreCase(var5);
            }
         }
      } else {
         return false;
      }
   }

   private static boolean Illl() {
      return false;
   }

   public static boolean lIII(Object var0, Object var1, float var2, float var3, Object var4) {
      <undefinedtype> var5 = I(III(var1));
      if (var5 != null && IlI(var1) && lIll(var0, var1, var4)) {
         try {
            Object var6 = lIl.invoke(IIII.invoke(var0), lIlIII.Il(lllI(117802993, -981252204)), var5.lI(), var4);
            int var7 = (Integer)llI.invoke(var0, -1, var1);
            float var8 = (float)(-Ill.getInt(var1)) / 2.0F + var2;
            float var9 = var3 - var5.lll() / 2.0F;
            Method var10000 = I;
            Object[] var10002 = new Object[llIl(-74663894, -1544549846)];
            var10002[0] = var6;
            var10002[1] = var8;
            var10002[2] = var9;
            var10002[3] = -0.1F;
            var10002[4] = var5.lIl();
            var10002[5] = var5.lll();
            var10002[llIl(-74663899, 2055631851)] = (float)var5.lII();
            var10002[llIl(-74663900, -485228507)] = (float)var5.llI();
            var10002[llIl(-74663897, 513589165)] = var7;
            var10000.invoke((Object)null, var10002);
            return true;
         } catch (Exception var10) {
            lIlI(lIlIII.Il(lllI(117802992, 1819377461)), var10);
            return false;
         }
      } else {
         return false;
      }
   }

   private static class_1921 lIIl(class_2960 var0) {
      if (ll != null) {
         try {
            return (class_1921)ll.invoke((Object)null, var0);
         } catch (Exception var6) {
            lIlI(lIlIII.Il(lllI(117802995, 1933126606)), var6);
            return null;
         }
      } else {
         String[] var1 = new String[]{lIlIII.Il(lllI(117802994, 399198009)), lIlIII.Il(lllI(117803005, -1234535001)), lIlIII.Il(lllI(117803004, -414024813)), lIlIII.Il(lllI(117803007, -231464871))};
         int var2 = var1.length;
         int var3 = 0;

         while(var3 < var2) {
            String var4 = var1[var3];

            try {
               Method var5 = class_1921.class.getMethod(var4, class_2960.class);
               ll = var5;
               return (class_1921)var5.invoke((Object)null, var0);
            } catch (NoSuchMethodException var7) {
               ++var3;
            } catch (Exception var8) {
               lIlI(lIlIII.Il(lllI(117803006, -1814346283)), var8);
               return null;
            }
         }

         return null;
      }
   }

   private static void lIlI(String var0, Exception var1) {
      if (!III) {
         III = true;
         IIlI.warn(lIlIII.Il(lllI(117803001, -363054732)), var0, var1);
      }
   }

   private static boolean lIll(Object var0, Object var1, Object var2) {
      return false;
   }

   public static boolean llII() {
      return lI() != null;
   }

   private static int llIl(int var0, int var1) {
      return IllI[var0 ^ -74663891] ^ var1 ^ var0;
   }

   private static String lllI(int var0, int var1) {
      int var3 = var0 ^ 117802997;
      char[] var4 = Illl[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])lIII[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         lIII[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 515777822;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 192;
               break;
            case 1:
               var9 = 117;
               break;
            case 2:
               var9 = 173;
               break;
            case 3:
               var9 = 108;
               break;
            case 4:
               var9 = 155;
               break;
            case 5:
               var9 = 111;
               break;
            case 6:
               var9 = 234;
               break;
            case 7:
               var9 = 190;
               break;
            case 8:
               var9 = 94;
               break;
            case 9:
               var9 = 40;
               break;
            case 10:
               var9 = 249;
               break;
            case 11:
               var9 = 82;
               break;
            case 12:
               var9 = 160;
               break;
            case 13:
               var9 = 45;
               break;
            case 14:
               var9 = 93;
               break;
            case 15:
               var9 = 130;
               break;
            case 16:
               var9 = 188;
               break;
            case 17:
               var9 = 87;
               break;
            case 18:
               var9 = 224;
               break;
            case 19:
               var9 = 75;
               break;
            case 20:
               var9 = 2;
               break;
            case 21:
               var9 = 145;
               break;
            case 22:
               var9 = 140;
               break;
            case 23:
               var9 = 250;
               break;
            case 24:
               var9 = 17;
               break;
            case 25:
               var9 = 51;
               break;
            case 26:
               var9 = 20;
               break;
            case 27:
               var9 = 183;
               break;
            case 28:
               var9 = 40;
               break;
            case 29:
               var9 = 25;
               break;
            case 30:
               var9 = 108;
               break;
            case 31:
               var9 = 222;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
