package x;

import java.util.List;
import java.util.Random;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;
import net.minecraft.class_310;

@Environment(EnvType.CLIENT)
public final class IllIIII extends IIIIIIIlI {
   private int I;
   private final lIIIlll l;
   private String II;
   private final Random Il;
   private final IlIIIlIlI<<undefinedtype>> lI;
   private int ll;
   private long III;
   private long IIl;
   private final lIlllII IlI;
   private int Ill;
   private final IIIllIIII lII;
   private class_1309 lIl;
   private static String[] llI;
   private static final long lll = 10000L;
   private static final int[] IIII;
   private static final String[] IIIl;
   private static final Object[] IIlI;

   public void Ill() {
      if (this.IIIIIlI()) {
         class_310 var1 = class_310.method_1551();
         if (var1.field_1724 != null && var1.method_1562() != null) {
            long var2 = System.currentTimeMillis();
            if (this.II != null && var2 >= this.III) {
               this.lII(var1, this.II);
               this.II = null;
               this.III = 0L;
               this.I = lll(1199293344, -1717960219);
            }

            class_1309 var4 = this.IlI.llII();
            if (var4 != null) {
               this.lIl = var4;
            } else if (this.lIl != null) {
               if ((!this.lIl.method_5805() || this.lIl.method_31481()) && var1.field_1724.method_5739(this.lIl) < 20.0F) {
                  this.ll(this.lIl);
               }

               this.lIl = null;
            }

         }
      }
   }

   private void ll(class_1309 var1) {
      long var2 = System.currentTimeMillis();
      int var4 = var1 == null ? lll(1199293345, 570544028) : var1.method_5628();
      if (var4 != lll(1199293346, 1019499979)) {
         if (this.II != null && this.I == var4) {
            return;
         }

         if (this.Ill == var4 && var2 - this.IIl < 10000L) {
            return;
         }
      }

      List var5 = (List)this.l.III();
      if (!var5.isEmpty()) {
         String var6;
         if (this.lI.III() == null.I) {
            var6 = (String)var5.get(this.Il.nextInt(var5.size()));
         } else {
            if (this.ll >= var5.size()) {
               this.ll = 0;
            }

            var6 = (String)var5.get(this.ll);
            this.ll = (this.ll + 1) % var5.size();
         }

         if (var6 != null && !var6.isBlank()) {
            this.II = var6.trim();
            this.III = var2 + (long)(Double)this.lII.III();
            this.I = var4;
            this.Ill = var4;
            this.IIl = var2;
         }

      }
   }

   static {
      short var6 = 9254;
      String var7 = "둣塚ኀ㊶韄生\ue842૫槙萓এ焿키羈\ue993媷隩㖬랉㤰魹ﺮ윞᭢过燿R릟홻Ĺ軨\ue439⽥沿쪹嘤緙Ǌቈꆷ뤺뇬윔뇌镕﹙쒄\u0adbꚴ尷㹿赲⋑䨆\udaea锄夌\uecca卛昁᳞櫖蠚ᯅૻ؞\uf2df䦈腖ﲌ\ue4ec\uec33쿁㻪叭⾱쪮ꖘ착軻麨\udd86\udae8궾ⵙ\uee49ॆ蝗骰讁\udbf0\ueb77嗲偩춃垩\ue4e1虬⦏槅ﳭ斅ᨛ걾ʐ缠ꥳ锺贜\udc46桘ꦇ\ue046揄䄅䦾饰ᖸ聛侠❻ᵒ\ue4d7̰拝䉶镜ﶙ鵬䕉흟뱔胜\uec17磵㏻鹿㜉ᇙ\uf60dኛ:륋ご웗爀虎穾爾濡샋鿓\uf51c讋嘒衂⢍嘑㒤怜ꍴ먫摫婔ᓀ믧\uf63f\uddda롮緑硴\uf6b9\uf2f5쪎㺒칶ྗ\uebfc콯\u31ec";
      char[] var8 = "␢⑶\u242e␞␢\u242e\u242e\u242a".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IIIl = var9;
            IIlI = new Object[var9.length];
            int var2 = 1269482476;
            byte[] var0 = "\u0015K\u0001©®ÐÏÑ°\u0015U\u0085\u0095Ù\u0007\u009aÆ>]wúe\f\u0003é\t\u0097}\u0080ê³\u0094ª+Î7ªh\u0003¡\u0019\bòÍ~ÇS¯-»\u009b2Àæ\u0012Í©\u0011\u0095\u0005U\u009f;#£{GÛ\u0083L\u0092\u008dpË;~´\u0098¯o;V¨Ú<c>m".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IIII = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IIII[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            llI = new String[lll(1199293347, -1727526947)];
            IlI();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static void IlI() {
      llI[0] = llI(IIII(-1395108223, 994066604).toCharArray(), 16570L, lll(1199293348, 436958331));
      llI[1] = llI(IIII(-1395108224, 911293341).toCharArray(), 50977L, lll(1199293349, -2079474234));
      llI[2] = llI(IIII(-1395108221, 1359557129).toCharArray(), 91546L, lll(1199293350, -1473286180));
      llI[3] = llI(IIII(-1395108222, -1482947036).toCharArray(), 63480L, lll(1199293351, -1353396491));
      llI[4] = llI(IIII(-1395108219, 32309613).toCharArray(), 71680L, lll(1199293352, -1269886512));
      llI[5] = llI(IIII(-1395108220, -1574432174).toCharArray(), 1145L, lll(1199293353, 106676419));
      llI[lll(1199293354, 366604941)] = llI(IIII(-1395108217, -537000509).toCharArray(), 65068L, lll(1199293355, 1905516734));
      llI[lll(1199293356, 560634741)] = llI(IIII(-1395108218, 1356209330).toCharArray(), 39333L, lll(1199293357, 1112800774));
   }

   public IllIIII(lIlllII var1) {
      super((Object)lIlIII.l(llI[2]), lIllII.l, (Object)lIlIII.l(llI[1]));
      this.l = (lIIIlll)this.IIIlIll(new lIIIlll(lIlIII.l(llI[lll(1199293358, -1514105536)]), x.IlIllIl.llll(lIlIII.Il(llI[3]), lIlIII.Il(llI[0])), lIlIII.Il(llI[0])));
      this.lII = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(llI[5]), (double)500.0F, (double)0.0F, (double)5000.0F, (double)50.0F)).IIl(lIlIII.Il(llI[4])));
      this.lI = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(llI[lll(1199293359, 1498299238)]), <undefinedtype>.class, null.I));
      this.Il = new Random();
      this.II = null;
      this.III = 0L;
      this.I = lll(1199293360, 799688583);
      this.Ill = lll(1199293361, 261984976);
      this.IIl = 0L;
      this.ll = 0;
      this.IlI = var1;
   }

   private void lII(class_310 var1, String var2) {
      try {
         var1.method_1562().method_45729(var2);
      } catch (Exception var4) {
      }

   }

   private static String llI(char[] var0, long var1, int var3) {
      int var4 = lll(1199293362, 1232524028) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & lll(1199293363, -1203130417);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   public void lI() {
      this.lIl = null;
      this.II = null;
      this.III = 0L;
      this.I = lll(1199293364, -1215846270);
      this.Ill = lll(1199293365, -1330495948);
      this.IIl = 0L;
   }

   private static int lll(int var0, int var1) {
      return IIII[var0 ^ 1199293344] ^ var1 ^ var0;
   }

   private static String IIII(int var0, int var1) {
      int var3 = var0 ^ -1395108223;
      char[] var4 = IIIl[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IIlI[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IIlI[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 1847922479;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 182;
               break;
            case 1:
               var9 = 84;
               break;
            case 2:
               var9 = 41;
               break;
            case 3:
               var9 = 86;
               break;
            case 4:
               var9 = 233;
               break;
            case 5:
               var9 = 147;
               break;
            case 6:
               var9 = 60;
               break;
            case 7:
               var9 = 88;
               break;
            case 8:
               var9 = 113;
               break;
            case 9:
               var9 = 108;
               break;
            case 10:
               var9 = 192;
               break;
            case 11:
               var9 = 134;
               break;
            case 12:
               var9 = 89;
               break;
            case 13:
               var9 = 86;
               break;
            case 14:
               var9 = 134;
               break;
            case 15:
               var9 = 198;
               break;
            case 16:
               var9 = 0;
               break;
            case 17:
               var9 = 198;
               break;
            case 18:
               var9 = 22;
               break;
            case 19:
               var9 = 148;
               break;
            case 20:
               var9 = 211;
               break;
            case 21:
               var9 = 18;
               break;
            case 22:
               var9 = 11;
               break;
            case 23:
               var9 = 94;
               break;
            case 24:
               var9 = 60;
               break;
            case 25:
               var9 = 48;
               break;
            case 26:
               var9 = 202;
               break;
            case 27:
               var9 = 208;
               break;
            case 28:
               var9 = 210;
               break;
            case 29:
               var9 = 188;
               break;
            case 30:
               var9 = 249;
               break;
            case 31:
               var9 = 14;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
