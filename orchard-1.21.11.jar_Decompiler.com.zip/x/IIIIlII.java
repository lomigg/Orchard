package x;

import com.google.common.collect.ArrayListMultimap;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import com.mojang.authlib.properties.PropertyMap;
import java.lang.reflect.Method;
import java.util.UUID;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class IIIIlII {
   private static final Method I;
   private static String[] l;
   private static final Method II;
   private static final Method Il;
   private static final int[] lI;
   private static final String[] ll;
   private static final Object[] III;

   public static UUID I(GameProfile var0) {
      return (UUID)III(var0, II, UUID.class);
   }

   private static void l() {
      l[0] = Il(Ill(-1921424386, '䁍', 3291).toCharArray(), 93583L, IlI(896925298, 1087627435));
      l[1] = Il(Ill(-171179229, '⨸', 3290).toCharArray(), 86833L, IlI(896925299, -420700757));
      l[2] = Il(Ill(-2040959328, '\ue42c', 3289).toCharArray(), 4212L, IlI(896925296, -1819976324));
      l[3] = Il(Ill(-1877267676, '䘿', 3288).toCharArray(), 95554L, IlI(896925297, 1732669610));
      l[4] = Il(Ill(-631503843, '\udd7f', 3295).toCharArray(), 60868L, IlI(896925302, -638238932));
      l[5] = Il(Ill(1089632702, '릉', 3294).toCharArray(), 46372L, IlI(896925303, 58133724));
   }

   public static String II(GameProfile var0) {
      return (String)III(var0, I, String.class);
   }

   private IIIIlII() {
   }

   static {
      short var6 = 15086;
      String var7 = "\uf1e6쵏祥\uf141\ue4d8ቨ\uf0d8㥼謯䛮\ue2f2嵥ꭡ遌４ལ䊴纘䄊亭ጪ纹⦄ꋎ磈飉⍢鹟⻣閭늟䲌▐瑙\ufaf6៸䈞⼫ն嚴턵乒じጽ킝\ue94fꤿ펭횾▮\ude1a谚淯ﭰ鷟왩휪牫ꦶꉌ籓㭽兄앥戴⧲쵃䉤";
      char[] var8 = "㫪㫾㫦㫦㫺㫢".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            ll = var9;
            III = new Object[var9.length];
            int var2 = 528220562;
            byte[] var0 = "T6¿CT\u0083\u008a\f+V\u0007Ö\f+ÀyÕ\u008eSj8Â\u0090\u0017\td=¦7\u001d22\u0087I¼ü".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lI = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lI[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            l = new String[IlI(896925300, 594395718)];
            l();
            II = ll(lIlIII.Il(l[0]), lIlIII.Il(l[2]));
            I = ll(lIlIII.Il(l[3]), lIlIII.Il(l[5]));
            Il = ll(lIlIII.Il(l[1]), lIlIII.Il(l[4]));
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 17;
                     break;
                  case 1:
                     var10000 = 48;
                     break;
                  case 2:
                     var10000 = 5;
                     break;
                  case 3:
                     var10000 = 93;
                     break;
                  case 4:
                     var10000 = 117;
                     break;
                  case 5:
                     var10000 = 5;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static String Il(char[] var0, long var1, int var3) {
      int var4 = IlI(896925301, 392235253) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IlI(896925306, -1388297237);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   public static PropertyMap lI(GameProfile var0) {
      return (PropertyMap)III(var0, Il, PropertyMap.class);
   }

   private static Method ll(String... var0) {
      for(String var4 : var0) {
         try {
            Method var5 = GameProfile.class.getMethod(var4);
            var5.setAccessible(true);
            return var5;
         } catch (ReflectiveOperationException var6) {
         }
      }

      return null;
   }

   private static <T> T III(GameProfile var0, Method var1, Class<T> var2) {
      if (var0 != null && var1 != null) {
         try {
            Object var3 = var1.invoke(var0);
            return (T)(var2.isInstance(var3) ? var2.cast(var3) : null);
         } catch (ReflectiveOperationException var4) {
            return null;
         }
      } else {
         return null;
      }
   }

   public static GameProfile IIl(GameProfile var0, String var1, Property var2) {
      if (var0 != null && var1 != null && !var1.isBlank() && var2 != null) {
         ArrayListMultimap var3 = ArrayListMultimap.create();
         PropertyMap var4 = lI(var0);
         if (var4 != null) {
            var3.putAll(var4);
         }

         var3.put(var1, var2);
         return new GameProfile(I(var0), II(var0), new PropertyMap(var3));
      } else {
         return var0;
      }
   }

   private static int IlI(int var0, int var1) {
      return lI[var0 ^ 896925298] ^ var1 ^ var0;
   }

   private static String Ill(int var0, char var1, int var2) {
      int var3 = var2 ^ 3291;
      char[] var4 = ll[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])III[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         III[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 16280;
      int var9 = 0;

      do {
         int var10 = var4[var9] + '鯖';
         var10 ^= 61768;
         var10 -= 54697;
         var10 -= 59822;
         var10 ^= 51843;
         var4[var9] = (char)(var10 ^ var8 ^ var1 ^ var0 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
