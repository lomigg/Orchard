package x;

import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_332;

@Environment(EnvType.CLIENT)
public final class lllIIlI {
   private static final Color I;
   public static final double l = (double)8.0F;
   private static final Color II;
   private static final Color Il;
   public static final double lI = (double)10.0F;
   private static final Color ll;
   public static final double III = (double)6.0F;
   private static final Color IIl;
   public static final double IlI = (double)5.0F;
   public static final double Ill = (double)999.0F;
   private static final Color lII;
   private static final Color lIl;
   public static final double llI = (double)7.0F;
   private static final int[] lll;

   public static int I() {
      return IllI(Il, lIlI(2033983874, 1838399525));
   }

   public static Color l() {
      lIIIllll var0 = ll();
      return var0 == null ? lIl : var0.IIlIII();
   }

   public static void II(class_332 var0, Object var1, double var2, double var4, double var6, double var8, boolean var10, double var11) {
      if (var0 != null && !(var6 <= (double)0.0F) && !(var8 <= (double)0.0F)) {
         <undefinedtype> var13 = var1 == null ? null.III : var1;
         double var14 = IIIIlI.Il(var11);
         if (!(var14 <= (double)0.0F)) {
            double var16 = Math.min(var13.I, Math.min(var6, var8) * (double)0.5F);
            int var18 = var13.l + (var10 ? lIlI(2033983875, -1863281860) : 0);
            if (var10) {
               var18 = Math.min(lIlI(2033983872, -387102061), var18);
            }

            IIIIIIllI.IllIll(var0, var2, var4, var6, var8, var16, lIlIIIIl.IIlI(Ill(var18), var14));
         }
      }
   }

   public static int Il() {
      return IllI(Il, lIlI(2033983873, 458017937));
   }

   public static void lI(class_332 var0, Object var1, double var2, double var4, double var6, double var8, boolean var10) {
      II(var0, var1, var2, var4, var6, var8, var10, (double)1.0F);
   }

   private static lIIIllll ll() {
      lIllIIl var0 = lIllIIl.Il();
      return var0 != null && var0.IIl() != null ? var0.IIl().llI() : null;
   }

   public static Color III() {
      lIIIllll var0 = ll();
      return var0 == null ? lII : var0.lIIII();
   }

   public static int IIl() {
      return Ill(lIlI(2033983878, -652552300));
   }

   public static int IlI(int var0) {
      return IllI(l(), var0);
   }

   public static int Ill(int var0) {
      return IllI(I, var0);
   }

   private lllIIlI() {
   }

   static {
      int var2 = -2128885300;
      byte[] var0 = "\u0095´(yh×{\u007f\u0010Ê¢ ãk$ð!=?®´-bË-òa6Úo\u0006d\u000e\u0097míà\u0088wyyäj\u0005*\u0084À4a3&¨`ú\u0000\u009eûµ+\u001b,ÝJÃxóÚ~nN$çU\u0001li÷¤\u0004\u0003Ö\u0089\u0086äý\u009f7ªa;)\u009fâÁî\b8¥Ò,ª\\Þ\u008cQ\u0083NU&éÕûÔ¢@g¯Ô áDâñ-\u009f¬\u009e!\nVUÈ«ð\u00ad\u007fr\u009dæ?".getBytes("ISO-8859-1");
      int var1 = var0.length / 4;
      lll = new int[var1];
      int var3 = 0;
      int var4 = 0;

      do {
         int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
         var5 ^= var2;
         lll[var4] = var5;
         var3 += 4;
         ++var4;
      } while(var4 < var1);

      lII = new Color(lIlI(2033983879, 1275759183), 0, lIlI(2033983876, -707425919), lIlI(2033983877, 575205074));
      II = new Color(lIlI(2033983882, -156203612), lIlI(2033983883, 414162735), lIlI(2033983880, -2117893546), lIlI(2033983881, -761059177));
      lIl = new Color(lIlI(2033983886, -1726689565), lIlI(2033983887, -1730287401), lIlI(2033983884, 59949899), lIlI(2033983885, -721771918));
      ll = new Color(lIlI(2033983890, -2133576995), lIlI(2033983891, -1771451315), lIlI(2033983888, -1389984566), lIlI(2033983889, 260304033));
      IIl = new Color(lIlI(2033983894, 783183371), lIlI(2033983895, 96001884), lIlI(2033983892, -1726168819), lIlI(2033983893, 451282606));
      I = new Color(lIlI(2033983898, -1065207194), lIlI(2033983899, 1383806661), lIlI(2033983896, -1448827355), lIlI(2033983897, -556909231));
      Il = new Color(lIlI(2033983902, 746956940), lIlI(2033983903, 1475594254), lIlI(2033983900, -1127933505), lIlI(2033983901, 1737193103));
   }

   public static int lII(Color var0) {
      Color var1 = var0 == null ? Color.WHITE : var0;
      return var1.getRGB();
   }

   public static void lIl(class_332 var0, double var1, double var3, double var5, double var7, double var9) {
      IIIIIIllI.IllIll(var0, var1, var3, var5, var7, var9, IIIl());
   }

   public static Color llI() {
      lIIIllll var0 = ll();
      return var0 == null ? IIl : var0.IIlIl();
   }

   public static int lll(int var0) {
      lIIIllll var1 = ll();
      Color var2 = var1 == null ? lII : var1.lllI();
      return IllI(var2, var0);
   }

   public static int IIII() {
      return IllI(Il, lIlI(2033983906, -227426940));
   }

   public static int IIIl() {
      return IllI(Il, lIlI(2033983907, 1406616890));
   }

   public static int IIlI() {
      return IllI(Il, lIlI(2033983904, -1967518137));
   }

   public static Color IIll() {
      lIIIllll var0 = ll();
      return var0 == null ? ll : var0.lllII();
   }

   public static int IlII(int var0) {
      return IllI(llI(), var0);
   }

   public static int IlIl(int var0) {
      return IllI(III(), var0);
   }

   public static int IllI(Color var0, int var1) {
      Color var2 = var0 == null ? Color.WHITE : var0;
      return IIIlllIII.lI(var2.getRGB(), var1);
   }

   public static int Illl(int var0) {
      return IllI(IIll(), var0);
   }

   public static Color lIII() {
      lIIIllll var0 = ll();
      return var0 == null ? II : var0.IIIIIl();
   }

   public static Color lIIl() {
      lIIIllll var0 = ll();
      return var0 == null ? IIIlllIII.l(lII, 0.18) : var0.llIII();
   }

   private static int lIlI(int var0, int var1) {
      return lll[var0 ^ 2033983874] ^ var1 ^ var0;
   }
}
