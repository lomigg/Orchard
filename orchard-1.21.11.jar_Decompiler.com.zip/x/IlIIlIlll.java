package x;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.Objects;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_3532;

@Environment(EnvType.CLIENT)
public final class IlIIlIlll extends IIIIIIIlI {
   private final IIIllIIII I;
   private final IIIllIIII l;
   private final IIIllIIII II;
   private final IIIllIIII Il;
   private final IIIllIIII lI;
   private final IlIIIlIlI<<undefinedtype>> ll;
   private final IIIllIIII III;
   private float IIl;
   private final IIIllIIII IlI;
   private final IIIllIIII Ill;
   private final IIIllIIII lII;
   private float lIl;
   private final IIIllIIII llI;
   private final IIIllIIII lll;
   private final IIIllIIII IIII;
   private final IIIllIIII IIIl;
   private final lIIIIl IIlI;
   private final IIIllIIII IIll;
   private final IIIllIIII IlII;
   private static String[] IlIl;
   private final IIIllIIII IllI;
   private final lIIIIl Illl;
   private final IIIllIIII lIII;
   private final lIIIIl lIIl;
   private final IIIllIIII lIlI;
   private final IIIllIIII lIll;
   private final IIIllIIII llII;
   private final IlIIIlIlI<<undefinedtype>> llIl;
   private final IIIllIIII lllI;
   private final IIIllIIII llll;
   private final IlIIIlIlI<<undefinedtype>> IIIII;
   private final IlIIIlIlI<<undefinedtype>> IIIIl;
   private final IIIllIIII IIIlI;
   private final IIIllIIII IIIll;
   private final IIIllIIII IIlII;
   private final lIIIIl IIlIl;
   private final IIIllIIII IIllI;
   private final IIIllIIII IIlll;
   private long IlIII;
   private final IIIllIIII IlIIl;
   private final IIIllIIII IlIlI;
   private final IlIIIlIlI<<undefinedtype>> IlIll;
   private static final int[] IllII;
   private static final String[] IllIl;
   private static final Object[] IlllI;

   private void ll(JsonObject var1) {
      if (var1 != null && var1.has(lIlIII.Il(IlIl[lIIlI(770936806, -1661779198)]))) {
         JsonObject var2 = var1.getAsJsonObject(lIlIII.Il(IlIl[lIIlI(770936807, -2094133547)]));
         JsonElement var3 = var2.get(lIlIII.Il(IlIl[lIIlI(770936804, 514070602)]));
         if (var3 != null && var3.getAsBoolean()) {
            JsonElement var4 = var2.get(lIlIII.Il(IlIl[lIIlI(770936805, -1236629231)]));
            double var5 = var4 == null ? (double)12.0F : Math.max((double)1.0F, var4.getAsDouble());
            this.IIIl.III((double)6.0F * (Double)this.IIIl.III() / var5);
         }
      }
   }

   public void lI() {
      this.IlIII = 0L;
      this.IIl = 0.0F;
      this.lIl = 0.0F;
   }

   public float lll(class_1268 var1) {
      return this.llII(var1).Ill();
   }

   public float IIII(class_1268 var1) {
      this.lIIII();
      return this.IIIII() && var1 == class_1268.field_5810 ? this.lIl : this.IIl;
   }

   public float IIll(class_1268 var1, float var2) {
      return this.llII(var1).ll(var2);
   }

   public boolean IlII() {
      return this.IIIIIlI() && Math.abs((Double)this.IIIl.III() - (double)1.0F) > 1.0E-4;
   }

   public boolean lIIl() {
      return this.IIIIIlI();
   }

   public <undefinedtype> llII(class_1268 var1) {
      boolean var2 = this.IIIII() && var1 == class_1268.field_5810;
      <undefinedtype> var3 = var2 ? (<undefinedtype>)this.llIl.III() : (<undefinedtype>)this.IIIIl.III();
      <undefinedtype> var4 = var2 ? (<undefinedtype>)this.ll.III() : (<undefinedtype>)this.IlIll.III();
      <undefinedtype> var5 = var4 == null.Il ? null.ll : (<undefinedtype>)this.IIIII.III();
      return new Record(var3, var4, var5, this.IlllI(var2, this.IIlll, this.llll), this.IlllI(var2, this.IlIlI, this.IlI), this.IlllI(var2, this.lIlI, this.lllI), this.IlllI(var2, this.I, this.IlII), this.IlllI(var2, this.IIlII, this.llI), this.IlllI(var2, this.II, this.III), this.IlllI(var2, this.lI, this.lIll), this.IlllI(var2, this.lII, this.lIII), this.IlllI(var2, this.IIll, this.IIIll), this.IlllI(var2, this.Il, this.IIllI), this.IlllI(var2, this.IIII, this.Ill), this.IlllI(var2, this.llII, this.IllI), this.IlllI(var2, this.IIIlI, this.IlIIl), this.IlllI(var2, this.lll, this.l)) {
         private final <undefinedtype> I;
         private final <undefinedtype> l;
         private final float II;
         private final float Il;
         private final float lI;
         private final float ll;
         private final float III;
         private final float IIl;
         private final float IlI;
         private final <undefinedtype> Ill;
         private final float lII;
         private final float lIl;
         private final float llI;
         private final float lll;
         private final float IIII;
         private final float IIIl;
         private final float IIlI;

         public {
            this.I = var1;
            this.Ill = var2;
            this.l = var3;
            this.IIlI = var4;
            this.IlI = var5;
            this.ll = var6;
            this.IIl = var7;
            this.lI = var8;
            this.llI = var9;
            this.lIl = var10;
            this.Il = var11;
            this.IIII = var12;
            this.IIIl = var13;
            this.III = var14;
            this.lII = var15;
            this.lll = var16;
            this.II = var17;
         }

         public float I() {
            return this.IIII;
         }

         public float l() {
            return this.lIl;
         }

         public float II() {
            return this.IIl;
         }

         public float Il() {
            return this.lI;
         }

         public float lI() {
            return this.III;
         }

         public float ll(float var1) {
            return this.l.l(class_3532.method_15363(var1, 0.0F, 1.0F));
         }

         public <undefinedtype> III() {
            return this.l;
         }

         public float IIl() {
            return this.llI;
         }

         public float IlI() {
            return this.Il;
         }

         public float Ill() {
            return this.IIlI;
         }

         public float lII() {
            return this.IlI;
         }

         public float lIl() {
            return this.IIIl;
         }

         public float llI(float var1) {
            return this.l.I(class_3532.method_15363(var1, 0.0F, 1.0F));
         }

         public float lll() {
            return this.II;
         }

         public float IIII() {
            return this.lll;
         }

         public float IIIl() {
            return this.lII;
         }

         public float IIlI() {
            return this.ll;
         }

         public <undefinedtype> IIll() {
            return this.Ill;
         }

         public <undefinedtype> IlII() {
            return this.I;
         }
      };
   }

   public void lIl() {
      this.IlIII = System.nanoTime();
   }

   public float lllI(class_1268 var1, float var2) {
      return this.llII(var1).llI(var2);
   }

   public boolean IIIII() {
      return (Boolean)this.IIlI.III();
   }

   public <undefinedtype> IIIIl(class_1268 var1) {
      return this.llII(var1).IIll();
   }

   public void IIl(JsonObject var1) {
      super.IIl(var1);
      this.ll(var1);
   }

   static {
      short var6 = 31951;
      String var7 = "죲蒂\ue977ⷾ˚㵧蚧䚥乄蠆\u2eff䚱貭퐀跈\udbfc䃼쒛⠬䅵惼観抌℺ਇ㍜丂洭ᓛ㾫봪ꊵ≱ⓓ綅䜮࡚吃砺빐\uee22\ue3d5䒌팮淌姼氙컎䢤녕镅燂ꍃܷ货\ue331ꕦᩖ鎿벩ᴋ\uf582璙滑ḭ㩃ꗛ홪♄鹵䆮藒缗术䛦꽴凶\udba2順쾉蚆ꖇ㠭ᑤ덧껬\u12bf鳆\ueb12婦\u0a60땼豇⠚石\ue50a촐⧄惪뤳嫰倪赋춈ܯ랞潻\uef62\uf237⒔혗˕牷䇴໋⣭ế槠q棏ᰁ¿\ude8b䵾땶퇃褜\uee7c샹‑诩䣺㫫\udd65㖤鵼ˏ㥭㮫齮\u17fb猤\u180e쮮ԅ䬑嗄峂ᜄꛝﻡ셫ꪽ\uf18c댌牣쩖兜䊃幾꜄ᮛ⊡䕠\u0d84솝좩㿐뗕簯䎍̷ଫ\ue890힖蹡ꝉ뵪껉箦끓ㄙ脇욄咸渄衎\ue724\udf2dዜ\ueba2挨觵霍撇딐聖歉鷤⇚扮橩ꈬ䦲쌶ҕ\ue730\ue9c9Ⰽ꺗蠮밣蘦瑎镵⎇\ufb0b蟍褼쭰䑸쭀移哑¤箭\udf4d榤飙ᣒ싗῎\ue358碞ꚙ⦴팅ฐ缗遑ϊ\ue54b戰길\udaf7廜\u0cdbↂ\udf66鸦◥늨∶ᔋ뼢翅⭝쬹\ud9b9㺈࿐쏉䩠嘽\ufb07늽ឭ沑趉䙮殲恴ܘ❳ଋ붴沗騉\uea04蛪椛庝詘볖荎瀅戤屾ﮚ솝쿺헳\u2ef5䆆圧ۮ⅑﷾ᆔ陕膀啈ᇡﭾ迁䲩蜙ꌆ孖顫ᬗ浫誀䓎핅\u2065\u2efd깎턙죥嬪漺ꛘ㛌퐸⓹伸짎甚삙횰䆙攰瞞憨첞맗テ\uea74仐\ue53b줞え迩᳤ࡅ⦾뿨㑋㾍춪簔乚䱫\uddfc紫揳軶ꦈ\uf59a怐ꚋ宩௶柈\u0cf7躪䚒⬜嫩\uf018甕䧢ꈴ䎢\ud813Ἓ凓剄ᴅ邜⿈\uda0d⢮ᾱ門ꛣ⬞ꑻ駾걺뉋ⴝ嚴ⴓ䯔ᤤ汆羓譪\ueb0c针溧⬉獌郞\uf653⚕乀佅鿎톑癤\udaceᕇ焑㷫ς䄩产캅䙲虵ꕛׂ⊢⋥枟͵垐䙾㯶ꕼ귩慪㦧퀝ٳ䫙\udd3f߯ᎉ틖サꩀ뵰덪鑕\ue285졬⣵ऱ㇢皥ᾐ㪩ي뗯\uf83d뮎\udfb9\uf400쬶䔑捈Ꮙ叒\uedfc\udf20끉뫒᚛㙝ྲ뷂茰ꛍ牼\ue3de\ueb60쨽죝\ue417䤐턋\ue3d1羼架ឦ岓퓔鄪ꅟ銵鰐꺃靆㋈闦ᶋ愥츷煓\ud991卼\ue2cf䧑瑲츹輕\uee4e\uf710涕ﮑ屹\uda7a\ue92a䅖ᚱ展ꚃ棇筤夦烌\uf634ꖗ呌胫洷谋㏏栄ཫ竇쭾琍槊籤Ɫￄ述ᑡ\ude63奉켃ᒵ\ue1b0䂳\uf7cc䝡횞堖슳奔꺟ῒ刢垉ⳏ溍辦癞뵠\u2d9a귉瑷\ude1b쳲嶢\uf421뷀硗\ud9a4Ꮈ護˪ⶡ变艧⑷掜\ue5c9ｸ袏ፙ氿斞壺貥溆븬榸쳁蘒琫\uec35쀈࢞\uf2d8犮◟뗠컩\ud94c죿省损跏㳣䰾臬⳼ᝁ䏵뒙늝쥔낲퉴ꥵɯ붗믘頮\u1ad7\uaa38㟒갍줃얫힔\ue04a\ue42cǅ奔몛\ud9a6\ufb07\ua7dc\ud82d\ueafd駷质뾪쬥砙Т刼瘁咐껦㿔얧槿逫迶ꘪ꼩樻伍픚喅쁸䁐䝍꽺鹇㉾䐹\u2fdf衮唜圠칸\ue5af徑\ud9d0ⓥ阋ၤ\uf8b1衚ﻟ៰ڭ쬕顋뛐桯\ue788\ue720瓁烣詞콤䭅줮伔䯻\uf58f蜳踂똛⑇趪ꗱ臼칣ǩ\ue394쥿鴘朗庡ꄹ觴葮֓凑\ueb29䫟璸楝筛㦵퉠虉숴笀마ᔚ旙䷳猀ᄦꔴꌯ༇䇼麘\ue36d겊Ấ꽅ꋧ儇飸ᗰ⒵閘ⷹ뫳穤姄ⷨ혐\ud85e龶\uedf6ㆍ\uee7e쏺쨼⨨⚻氃癌嚳⧟࿐ꆺ¥Ⳑ\ude58憶櫤\ue676㎬㓞\udd0c\u0aa9¡ྫྷ燏\u0efeꨝ摤\udbd6ꉊ蟔砍댦赸厭診舚\uf4e8操戔ꈆ\uddae◥엃ኪ\uede4葵䡳許ᔧ䄈뻏䛠仐ꊡ푯\ue669ถ\ue00f帘\uf4a8ᰟ鷫\ude23\udc24쐇\ud8b7ᓄᚳ乨⤵䜳\ue3f5递\uda77㓲ⵊୌ팢㵣稿쭔賟ጨ罚乄\ud8f2쭎䩈䰯팪䟌\uddc6甧⤗\uf4fa\uf89c㎶꺊뻙ⵏ绑ᖘ퇳稲让縔⾱\u2451鄕㒑뙘濍쒝풌튂殅龊䯃趵镗\ud9ecꎹ㤔ㅄ呻탻\uee4e䪤ᴾ춧\ud9da㫮蝆㾈ⲙㅼ靂䴿鳵駐ﲓ誾捻踶㤭脎\uf703媝\ue46c켢ӏ\uecaa攱ꅢ벢委嘈崒彧";
      char[] var8 = "糋糗糗糗糟糗糇糗糗糟糯糟糟糟糯糗糃糛糓糗糯糗糃糗糗糋糟糇糟糛糃糟糛糓糟糿糯糗糗糗糟糟糟糃糟糇糋".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IllIl = var9;
            IlllI = new Object[var9.length];
            int var2 = -1497895450;
            byte[] var0 = "\u0017·!)\bjlÿ\u0095àzd=\u000eë8ì6/ç\u00ad%3S>\u0088pÿÞs?úûþÊW±Ð\u0096ªa¤BèOÆ½a&â\u0091\u0011pÁ\u0004ËS\u008eì\u0096\u009e\u0082\u0001\u007fâ\u0081Ë\u001b\u008e\u008f**¥\"Kµ\u008f7°\u009f\u0099\u008cñ\u009fNÒÊõ3º\u008bþÆÇÙI\u001f+M\u001f\u0006ù²ôÕ\u0092¼Â:©x\u0089!>3þ®EÂäúß<óÔ³2!\u001f\u009bÞó×ÏíUv`\u0001\u000e¸H\u0088ÞE£\u0016\u009b\u008eº£¨ Ã4¾[F\u009d£êM3¥Ñ½\u009eVu>Û\u007f¯N·éUîåÜ½í!Û¾©\u009fs¸Ù¼HD·\u009c¢¬\u0003SÚ\u008aGí¼f\u008dw\u001e\fêi\u0010fP³\u009d[º.È8Êl.%\u0081á\"ïs+CþãÙd'Æ BÈ\u0084\u0092\u0010\u0089Ï¼òã\u008e\u000eç<\u001a5/¦\u0019\u007f\u0098~\u0004\u001e´¼á°Û¢h2Þº¹\u001a\u0097bå\u0004\u009b\rXi\tV±\u0094DG8M§aÑK\u0011g»\u009e?z\u0016\u001e-\r|¯¾´\u0012º;+\u0099Æ¸Qç\u001bÓÖ\u0098¸yî$\u0004\u00924ú\u0085¾\u000b\u0097Â3\t¯e II«\u0013´ªSvB%YµÊL\u0091~Ð\u0012Å\u0088ÏVw%ÎòI\u009fÀ\u008d\u0081L/ë\u001cÔ9ô\u0095r\u0086\u0092îºI\f£þæ£1\u008f\u001f\u000e\u0095º\u0089®\u0002\u008a°1¤\u0090@ Ì\u008c²\u0007»©c\u0080K.!Û\u0094¤BL`ÄR.îè\u008b/z\u0097\u008aÛùv\u0015J ç¯DJì\u008e×ú\u0089îÛj\u0081\\\u009aíàR\u0003í°\tÑÜ\u008649\u0083*\bµ\u0095ÐÓ¦\u009dS,ÍÓû¨\u001e\u0088ÒR\u0084AX@4\u0081\u0098\u0092?ÊÞ2´hjx|\u000f\u0087V¢Bª\u0001Sâ\u0014\n\u008e\u009bUqxt\u0007\u0003ÎÂ\u008a²ps,y\u0099º\u0095".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IllII = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IllII[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            IlIl = new String[lIIlI(770936802, 1735544268)];
            IIlIl();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public int IIlII(int var1) {
      return Math.max(1, (int)Math.round((double)Math.max(1, var1) / (Double)this.IIIl.III()));
   }

   private static void IIlIl() {
      IlIl[0] = IllIl(lIIll(-122627984, 1548769189).toCharArray(), 18254L, lIIlI(770936803, 130256598));
      IlIl[1] = IllIl(lIIll(-122627983, -512490090).toCharArray(), 35761L, lIIlI(770936800, -1275910073));
      IlIl[2] = IllIl(lIIll(-122627982, -481073315).toCharArray(), 62985L, lIIlI(770936801, -1031655865));
      IlIl[3] = IllIl(lIIll(-122627981, -1400626979).toCharArray(), 54977L, lIIlI(770936814, 716756620));
      IlIl[4] = IllIl(lIIll(-122627980, -1391065837).toCharArray(), 69649L, lIIlI(770936815, -2068203158));
      IlIl[5] = IllIl(lIIll(-122627979, -1904986496).toCharArray(), 6772L, lIIlI(770936812, -1765316755));
      IlIl[lIIlI(770936813, -998056084)] = IllIl(lIIll(-122627978, 115099882).toCharArray(), 79155L, lIIlI(770936810, 1920109686));
      IlIl[lIIlI(770936811, -75143487)] = IllIl(lIIll(-122627977, 1444089695).toCharArray(), 1972L, lIIlI(770936808, 882139028));
      IlIl[lIIlI(770936809, 365323128)] = IllIl(lIIll(-122627976, -1987162871).toCharArray(), 36324L, lIIlI(770936822, 482959122));
      IlIl[lIIlI(770936823, 97208370)] = IllIl(lIIll(-122627975, -345939730).toCharArray(), 82815L, lIIlI(770936820, 837417591));
      IlIl[lIIlI(770936821, 74699398)] = IllIl(lIIll(-122627974, -1164095488).toCharArray(), 21246L, lIIlI(770936818, -1702493531));
      IlIl[lIIlI(770936819, -979982101)] = IllIl(lIIll(-122627973, -895609139).toCharArray(), 67397L, lIIlI(770936816, -899256173));
      IlIl[lIIlI(770936817, 1300478802)] = IllIl(lIIll(-122627972, -284013031).toCharArray(), 44111L, lIIlI(770936830, -1051695367));
      IlIl[lIIlI(770936831, -1916940064)] = IllIl(lIIll(-122627971, -139755658).toCharArray(), 94998L, lIIlI(770936828, -472831963));
      IlIl[lIIlI(770936829, -1309861220)] = IllIl(lIIll(-122627970, -909556611).toCharArray(), 46994L, lIIlI(770936826, -295356269));
      IlIl[lIIlI(770936827, 620863734)] = IllIl(lIIll(-122627969, 1671134729).toCharArray(), 10189L, lIIlI(770936824, -387835130));
      IlIl[lIIlI(770936825, 1610043438)] = IllIl(lIIll(-122628000, 1936392202).toCharArray(), 99402L, lIIlI(770936774, -326327202));
      IlIl[lIIlI(770936775, 1552650085)] = IllIl(lIIll(-122627999, 404124883).toCharArray(), 37801L, lIIlI(770936772, 319291456));
      IlIl[lIIlI(770936773, 856484591)] = IllIl(lIIll(-122627998, -1249680276).toCharArray(), 33812L, lIIlI(770936770, 688236603));
      IlIl[lIIlI(770936771, 100581790)] = IllIl(lIIll(-122627997, -104062520).toCharArray(), 70658L, lIIlI(770936768, 63871584));
      IlIl[lIIlI(770936769, -805109872)] = IllIl(lIIll(-122627996, -1610349325).toCharArray(), 21741L, lIIlI(770936782, -2080467567));
      IlIl[lIIlI(770936783, 1526332522)] = IllIl(lIIll(-122627995, -834113819).toCharArray(), 7899L, lIIlI(770936780, 2108588404));
      IlIl[lIIlI(770936781, 604689876)] = IllIl(lIIll(-122627994, -35570139).toCharArray(), 61672L, lIIlI(770936778, -703094301));
      IlIl[lIIlI(770936779, 917062625)] = IllIl(lIIll(-122627993, -1374336763).toCharArray(), 16714L, lIIlI(770936776, -1249087569));
      IlIl[lIIlI(770936777, 865984127)] = IllIl(lIIll(-122627992, -1172874534).toCharArray(), 75298L, lIIlI(770936790, 554118891));
      IlIl[lIIlI(770936791, 658977266)] = IllIl(lIIll(-122627991, 700653407).toCharArray(), 82974L, lIIlI(770936788, -787145447));
      IlIl[lIIlI(770936789, -305588937)] = IllIl(lIIll(-122627990, 1323896781).toCharArray(), 89277L, lIIlI(770936786, 722444531));
      IlIl[lIIlI(770936787, -317402701)] = IllIl(lIIll(-122627989, -755218783).toCharArray(), 2178L, lIIlI(770936784, 277956155));
      IlIl[lIIlI(770936785, -1282535931)] = IllIl(lIIll(-122627988, 1712466662).toCharArray(), 84785L, lIIlI(770936798, 424313046));
      IlIl[lIIlI(770936799, 1681344871)] = IllIl(lIIll(-122627987, -1364778351).toCharArray(), 5075L, lIIlI(770936796, -755118842));
      IlIl[lIIlI(770936797, -1400749465)] = IllIl(lIIll(-122627986, 800655039).toCharArray(), 13024L, lIIlI(770936794, -1163029380));
      IlIl[lIIlI(770936795, 42720976)] = IllIl(lIIll(-122627985, 107160527).toCharArray(), 8712L, lIIlI(770936792, 1484831313));
      IlIl[lIIlI(770936793, -1218554064)] = IllIl(lIIll(-122628016, 340088936).toCharArray(), 13994L, lIIlI(770936742, 475981430));
      IlIl[lIIlI(770936743, -180323116)] = IllIl(lIIll(-122628015, -1913294473).toCharArray(), 19311L, lIIlI(770936740, -195275557));
      IlIl[lIIlI(770936741, 690770111)] = IllIl(lIIll(-122628014, -1033828381).toCharArray(), 66364L, lIIlI(770936738, 2026189133));
      IlIl[lIIlI(770936739, -375298307)] = IllIl(lIIll(-122628013, -1025689978).toCharArray(), 90L, lIIlI(770936736, -1343192673));
      IlIl[lIIlI(770936737, -571083225)] = IllIl(lIIll(-122628012, -513071145).toCharArray(), 55529L, lIIlI(770936750, -257689044));
      IlIl[lIIlI(770936751, -359323267)] = IllIl(lIIll(-122628011, -2070341035).toCharArray(), 9614L, lIIlI(770936748, -640416764));
      IlIl[lIIlI(770936749, -246252480)] = IllIl(lIIll(-122628010, 243417327).toCharArray(), 14424L, lIIlI(770936746, -2144261126));
      IlIl[lIIlI(770936747, 1062656081)] = IllIl(lIIll(-122628009, 155446).toCharArray(), 3347L, lIIlI(770936744, 604707067));
      IlIl[lIIlI(770936745, -626820684)] = IllIl(lIIll(-122628008, -1566297980).toCharArray(), 29014L, lIIlI(770936758, -1681397266));
      IlIl[lIIlI(770936759, 1700816618)] = IllIl(lIIll(-122628007, -698929040).toCharArray(), 32314L, lIIlI(770936756, 1156247367));
      IlIl[lIIlI(770936757, -2133614518)] = IllIl(lIIll(-122628006, 255796067).toCharArray(), 54986L, lIIlI(770936754, 777511021));
      IlIl[lIIlI(770936755, -1039283859)] = IllIl(lIIll(-122628005, 497750963).toCharArray(), 53335L, lIIlI(770936752, -1450553117));
      IlIl[lIIlI(770936753, -916374578)] = IllIl(lIIll(-122628004, 83447615).toCharArray(), 18585L, lIIlI(770936766, 1381544020));
      IlIl[lIIlI(770936767, 1532405756)] = IllIl(lIIll(-122628003, 231214596).toCharArray(), 79649L, lIIlI(770936764, -600377929));
      IlIl[lIIlI(770936765, 1169566698)] = IllIl(lIIll(-122628002, -389783934).toCharArray(), 84104L, lIIlI(770936762, -954066479));
   }

   public IlIIlIlll() {
      super((Object)lIlIII.l(IlIl[lIIlI(770936763, -1532002684)]), lIllII.ll, (Object)lIlIII.l(IlIl[lIIlI(770936760, -1297025265)]));
      this.IIIIl = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IlIl[lIIlI(770936761, 232164556)]), <undefinedtype>.class, null.ll));
      this.IlIll = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IlIl[lIIlI(770936710, -1035419210)]), <undefinedtype>.class, null.Il));
      this.IIIl = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IlIl[lIIlI(770936711, 1843876852)]), (double)1.0F, 0.05, (double)6.0F, 0.01)).IIl(lIlIII.Il(IlIl[lIIlI(770936708, -1807026239)])));
      this.IIIII = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IlIl[lIIlI(770936709, 48914635)]), <undefinedtype>.class, null.I));
      this.IIlI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IlIl[lIIlI(770936706, 997574377)]), false));
      this.IIlIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IlIl[lIIlI(770936707, -874205458)]), true));
      this.Illl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IlIl[lIIlI(770936704, 960747991)]), true));
      this.lIIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IlIl[2]), true));
      this.IIlll = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(IlIl[lIIlI(770936705, -389797568)]), 0.65, (double)0.0F, (double)1.0F, 0.05));
      this.IlIlI = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(IlIl[lIIlI(770936718, -1432357155)]), (double)1.0F, (double)0.25F, (double)2.0F, 0.05));
      this.lIlI = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IlIl[5]), (double)0.0F, (double)-180.0F, (double)180.0F, (double)1.0F)).IIl(lIlIII.Il(IlIl[0])));
      this.I = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IlIl[lIIlI(770936719, -922221890)]), (double)90.0F, (double)-180.0F, (double)180.0F, (double)1.0F)).IIl(lIlIII.Il(IlIl[0])));
      this.IIlII = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IlIl[lIIlI(770936716, -647328604)]), (double)10.0F, (double)-180.0F, (double)180.0F, (double)1.0F)).IIl(lIlIII.Il(IlIl[0])));
      this.II = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IlIl[lIIlI(770936717, 7018723)]), (double)180.0F, (double)30.0F, (double)1080.0F, (double)15.0F)).IIl(lIlIII.Il(IlIl[0])));
      this.lI = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(IlIl[lIIlI(770936714, 27237121)]), (double)1.0F, 0.7, 1.4, 0.01));
      this.lII = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(IlIl[lIIlI(770936715, -1643199844)]), (double)0.0F, (double)-2.0F, 0.4, 0.01));
      this.IIll = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(IlIl[lIIlI(770936712, 603990172)]), (double)0.0F, (double)-2.0F, 0.4, 0.01));
      this.Il = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(IlIl[lIIlI(770936713, 93559030)]), (double)0.0F, (double)-2.0F, 0.4, 0.01));
      this.IIII = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IlIl[lIIlI(770936726, 1704921335)]), (double)0.0F, (double)-45.0F, (double)45.0F, (double)1.0F)).IIl(lIlIII.Il(IlIl[0])));
      this.llII = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IlIl[lIIlI(770936727, -673280102)]), (double)0.0F, (double)-180.0F, (double)180.0F, (double)1.0F)).IIl(lIlIII.Il(IlIl[0])));
      this.IIIlI = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IlIl[4]), (double)0.0F, (double)-180.0F, (double)180.0F, (double)1.0F)).IIl(lIlIII.Il(IlIl[0])));
      this.lll = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IlIl[lIIlI(770936724, -649621554)]), (double)0.0F, (double)-180.0F, (double)180.0F, (double)1.0F)).IIl(lIlIII.Il(IlIl[0])));
      this.llIl = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IlIl[lIIlI(770936725, -2104115500)]), <undefinedtype>.class, null.ll));
      this.ll = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IlIl[lIIlI(770936722, -1082269367)]), <undefinedtype>.class, null.Il));
      this.llll = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(IlIl[lIIlI(770936723, -2081294409)]), 0.65, (double)0.0F, (double)1.0F, 0.05));
      this.IlI = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(IlIl[lIIlI(770936720, 1491271471)]), (double)1.0F, (double)0.25F, (double)2.0F, 0.05));
      this.lllI = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IlIl[lIIlI(770936721, -1484148328)]), (double)0.0F, (double)-180.0F, (double)180.0F, (double)1.0F)).IIl(lIlIII.Il(IlIl[0])));
      this.IlII = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IlIl[lIIlI(770936734, 593160868)]), (double)90.0F, (double)-180.0F, (double)180.0F, (double)1.0F)).IIl(lIlIII.Il(IlIl[0])));
      this.llI = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IlIl[lIIlI(770936735, -641719547)]), (double)10.0F, (double)-180.0F, (double)180.0F, (double)1.0F)).IIl(lIlIII.Il(IlIl[0])));
      this.III = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IlIl[lIIlI(770936732, -881794105)]), (double)180.0F, (double)30.0F, (double)1080.0F, (double)15.0F)).IIl(lIlIII.Il(IlIl[0])));
      this.lIll = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(IlIl[lIIlI(770936733, 427534469)]), (double)1.0F, 0.7, 1.4, 0.01));
      this.lIII = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(IlIl[lIIlI(770936730, -1175451087)]), (double)0.0F, (double)-2.0F, 0.4, 0.01));
      this.IIIll = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(IlIl[lIIlI(770936731, -214405649)]), (double)0.0F, (double)-2.0F, 0.4, 0.01));
      this.IIllI = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(IlIl[1]), (double)0.0F, (double)-2.0F, 0.4, 0.01));
      this.Ill = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IlIl[lIIlI(770936728, -572120888)]), (double)0.0F, (double)-45.0F, (double)45.0F, (double)1.0F)).IIl(lIlIII.Il(IlIl[0])));
      this.IllI = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IlIl[lIIlI(770936729, -1978171292)]), (double)0.0F, (double)-180.0F, (double)180.0F, (double)1.0F)).IIl(lIlIII.Il(IlIl[0])));
      this.IlIIl = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IlIl[3]), (double)0.0F, (double)-180.0F, (double)180.0F, (double)1.0F)).IIl(lIlIII.Il(IlIl[0])));
      this.l = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IlIl[lIIlI(770936678, -2117404195)]), (double)0.0F, (double)-180.0F, (double)180.0F, (double)1.0F)).IIl(lIlIII.Il(IlIl[0])));
      this.IIIII.lIII(() -> this.IlIll.III() != null.Il || (Boolean)this.IIlI.III() && this.ll.III() != null.Il);
      this.IlIlI.lIII(() -> ((<undefinedtype>)this.IlIll.III()).II());
      this.lIlI.lIII(() -> this.IlIll.III() == null.III);
      this.I.lIII(() -> this.IlIll.III() == null.III);
      this.IIlII.lIII(() -> this.IlIll.III() == null.III);
      this.II.lIII(() -> this.IIIIl.III() == null.Il);
      IlIIIlIlI var10000 = this.llIl;
      lIIIIl var10001 = this.IIlI;
      Objects.requireNonNull(var10001);
      var10000.lIII(var10001::III);
      var10000 = this.ll;
      var10001 = this.IIlI;
      Objects.requireNonNull(var10001);
      var10000.lIII(var10001::III);
      IIIllIIII var2 = this.llll;
      var10001 = this.IIlI;
      Objects.requireNonNull(var10001);
      var2.lIII(var10001::III);
      this.IlI.lIII(() -> (Boolean)this.IIlI.III() && ((<undefinedtype>)this.ll.III()).II());
      this.lllI.lIII(() -> (Boolean)this.IIlI.III() && this.ll.III() == null.III);
      this.IlII.lIII(() -> (Boolean)this.IIlI.III() && this.ll.III() == null.III);
      this.llI.lIII(() -> (Boolean)this.IIlI.III() && this.ll.III() == null.III);
      this.III.lIII(() -> (Boolean)this.IIlI.III() && this.llIl.III() == null.Il);
      var2 = this.lIll;
      var10001 = this.IIlI;
      Objects.requireNonNull(var10001);
      var2.lIII(var10001::III);
      var2 = this.lIII;
      var10001 = this.IIlI;
      Objects.requireNonNull(var10001);
      var2.lIII(var10001::III);
      var2 = this.IIIll;
      var10001 = this.IIlI;
      Objects.requireNonNull(var10001);
      var2.lIII(var10001::III);
      var2 = this.IIllI;
      var10001 = this.IIlI;
      Objects.requireNonNull(var10001);
      var2.lIII(var10001::III);
      var2 = this.Ill;
      var10001 = this.IIlI;
      Objects.requireNonNull(var10001);
      var2.lIII(var10001::III);
      var2 = this.IllI;
      var10001 = this.IIlI;
      Objects.requireNonNull(var10001);
      var2.lIII(var10001::III);
      var2 = this.IlIIl;
      var10001 = this.IIlI;
      Objects.requireNonNull(var10001);
      var2.lIII(var10001::III);
      var2 = this.l;
      var10001 = this.IIlI;
      Objects.requireNonNull(var10001);
      var2.lIII(var10001::III);
   }

   public String Il() {
      if ((Boolean)this.IIlI.III()) {
         return lIlIII.Il(IlIl[lIIlI(770936679, -96725333)]);
      } else {
         <undefinedtype> var1 = (<undefinedtype>)this.IIIIl.III();
         <undefinedtype> var2 = (<undefinedtype>)this.IlIll.III();
         if (var1 == null.ll && var2 == null.Il) {
            return null.ll.toString();
         } else if (var2 == null.Il) {
            return var1.toString();
         } else if (var1 == null.ll) {
            return var2.toString();
         } else {
            String var10000 = String.valueOf(var1);
            String var10001 = lIlIII.Il(IlIl[lIIlI(770936676, -2004180954)]);
            String var5 = String.valueOf(var2);
            String var4 = var10001;
            String var3 = var10000;
            return var3 + var4 + var5;
         }
      }
   }

   public boolean IIlll() {
      return (Boolean)this.IIlIl.III();
   }

   public boolean IlIIl(class_1268 var1) {
      return this.IIIIIlI() && var1 == class_1268.field_5810 ? (Boolean)this.lIIl.III() : (Boolean)this.Illl.III();
   }

   public <undefinedtype> IllII(class_1268 var1) {
      return this.llII(var1).IlII();
   }

   private static String IllIl(char[] var0, long var1, int var3) {
      int var4 = lIIlI(770936677, -1808742326) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & lIIlI(770936674, -220342034);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private float IlllI(boolean var1, IIIllIIII var2, IIIllIIII var3) {
      IIIllIIII var4 = var1 ? var3 : var2;
      return ((Double)var4.III()).floatValue();
   }

   public float Illll(class_1268 var1, class_1306 var2) {
      float var3 = this.llII(var1).IlI();
      return !this.IIIII() && var2 == class_1306.field_6182 ? -var3 : var3;
   }

   private void lIIII() {
      long var1 = System.nanoTime();
      if (this.IlIII == 0L) {
         this.IlIII = var1;
      } else {
         float var3 = Math.min((float)(var1 - this.IlIII) / 1.0E9F, 0.1F);
         this.IlIII = var1;
         this.IIl = (this.IIl + var3 * ((Double)this.II.III()).floatValue()) % 360.0F;
         float var4 = this.IIIII() ? ((Double)this.III.III()).floatValue() : ((Double)this.II.III()).floatValue();
         this.lIl = (this.lIl + var3 * var4) % 360.0F;
      }
   }

   private static int lIIlI(int var0, int var1) {
      return IllII[var0 ^ 770936806] ^ var1 ^ var0;
   }

   private static String lIIll(int var0, int var1) {
      int var3 = var0 ^ -122627984;
      char[] var4 = IllIl[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IlllI[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IlllI[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 43112934;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 59;
               break;
            case 1:
               var9 = 110;
               break;
            case 2:
               var9 = 148;
               break;
            case 3:
               var9 = 182;
               break;
            case 4:
               var9 = 247;
               break;
            case 5:
               var9 = 250;
               break;
            case 6:
               var9 = 139;
               break;
            case 7:
               var9 = 87;
               break;
            case 8:
               var9 = 2;
               break;
            case 9:
               var9 = 108;
               break;
            case 10:
               var9 = 25;
               break;
            case 11:
               var9 = 208;
               break;
            case 12:
               var9 = 32;
               break;
            case 13:
               var9 = 137;
               break;
            case 14:
               var9 = 210;
               break;
            case 15:
               var9 = 159;
               break;
            case 16:
               var9 = 238;
               break;
            case 17:
               var9 = 12;
               break;
            case 18:
               var9 = 84;
               break;
            case 19:
               var9 = 128;
               break;
            case 20:
               var9 = 211;
               break;
            case 21:
               var9 = 109;
               break;
            case 22:
               var9 = 43;
               break;
            case 23:
               var9 = 228;
               break;
            case 24:
               var9 = 66;
               break;
            case 25:
               var9 = 201;
               break;
            case 26:
               var9 = 118;
               break;
            case 27:
               var9 = 188;
               break;
            case 28:
               var9 = 69;
               break;
            case 29:
               var9 = 237;
               break;
            case 30:
               var9 = 245;
               break;
            case 31:
               var9 = 24;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
