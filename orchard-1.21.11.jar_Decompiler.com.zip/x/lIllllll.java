package x;

import com.google.gson.JsonObject;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;

@Environment(EnvType.CLIENT)
public final class lIllllll extends IIIIIIIlI {
   private static final String[] I;
   private static final Object[] l;

   public void lIl() {
      lIllIIl var1 = lIllIIl.Il();
      IlIllIII.I(class_310.method_1551(), var1 == null ? null : var1.IIl());
   }

   public void IIllIIl(JsonObject var1) {
   }

   public lIllllll(IIllIlII var1) {
      super((Object)lIlIII.l(ll((short)10541, 'ⷄ', -1151768562)), lIllII.lI, (Object)lIlIII.l(ll((short)21810, 'ⷅ', 1145532957)));
   }

   public lIllllll() {
      this((IIllIlII)null);
   }

   static {
      short var0 = 12003;
      String var1 = "\uf31e\uf4b6\uf31c\uf4b7\uf319\uf314\uf304\uf4c8\uf4ab\uf4b8\uf4a5\uf4aa\uf4a1\uf4db\uf318\uf4b7\uf4a4\uf318\uf301\uf4d3ḝᾹ\u1fdcᾧḅᾱḛḁ᾽ᾼῂᾷᾹΊ\u1fdcḌᾡ\u1fd4ᾣᾰḐḛḄ᾽ᾺḟḇΈᾱ᾽ῈᾼḆḊḐᾰᾷᾡḔΆ\u1fdcΊḜᾣ\u1fdcᾸḌᾹᾭ῟ᾥΈᾸΈᾹᾤḃ\u1fdcᾴᾬῑᾰ῞ḘḙΈḟᾬḃᾱῈᾷḍᾱᾺΈᾫΈḗᾣᾫḛᾷᾦ῞ḂḜᾱᾱΊḊᾴᾱῈᾼ᾿ῑᾼṠṠ";
      char[] var2 = "\u2ef7⺇".toCharArray();
      String[] var3 = new String[var2.length];
      byte var7 = -1;

      while(true) {
         int var4 = 0;
         int var5 = 0;
         int var6 = 0;
         if (var7 == 0) {
            I = var3;
            l = new Object[var3.length];
            return;
         }

         do {
            var6 = var2[var4] ^ var0;
            var3[var4] = var1.substring(var5, var5 + var6);
            var5 += var6;
            ++var4;
         } while(var4 < var2.length);

         var7 = 0;
      }
   }

   private static String ll(short var0, char var1, int var2) {
      int var3 = var1 ^ 11716;
      char[] var4 = I[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])l[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         l[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 20467;
      int var9 = 0;

      do {
         int var10 = var4[var9] ^ 20616;
         var10 += 51614;
         var10 ^= 60742;
         var10 -= 62321;
         var10 ^= 19444;
         var10 += 13485;
         var10 += 59693;
         var10 -= 26730;
         var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var2 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
