package x;

import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_746;

@Environment(EnvType.CLIENT)
public final class llIIl extends IIIIIIIlI {
   private static final long I = 1000L;
   private final llllIlIl l;
   private long II;
   private <undefinedtype> Il;
   private static final int lI = 9;
   private long ll;
   private static final int III = 3;
   private long IIl;
   private int IlI;
   private int Ill;
   private static String[] lII;
   private static final int[] lIl;
   private static final String[] llI;
   private static final Object[] lll;

   public llIIl() {
      super((Object)lIlIII.l(lII[3]), lIllII.I, (Object)lIlIII.l(lII[2]));
      this.l = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(lII[1]), (double)55.0F, (double)60.0F, (double)0.0F, (double)300.0F, (double)5.0F)).IIII(lIlIII.Il(lII[0])));
      this.IlI = IIIII(1138413500, 228995851);
      this.IIl = Long.MIN_VALUE;
      this.ll = Long.MIN_VALUE;
      this.II = Long.MIN_VALUE;
      this.Ill = -1;
   }

   public void II(class_1297 var1, byte var2) {
      class_310 var3 = class_310.method_1551();
      if (this.IIIIIlI() && var3 != null && var3.field_1724 != null && var3.field_1761 != null && var3.field_1755 == null && var2 == IIIII(1138413501, -639224558) && var1 != null && var1.method_5628() == var3.field_1724.method_5628()) {
         if (this.IlI != var3.field_1724.field_6012) {
            this.IlI = var3.field_1724.field_6012;
            if (this.lll(var3.field_1724)) {
               this.lIII(var3);
            } else if (!this.IlIl(var3.field_1724)) {
               this.lIII(var3);
            } else {
               long var4 = System.currentTimeMillis();
               this.II = var4;
               this.IIl = var4;
               this.ll = Long.MIN_VALUE;
               this.Ill = -1;
               this.Il = null;
            }
         }
      }
   }

   private void ll(class_310 var1) {
      IllllIlI.IlII(var1, this, null.II);
      this.Il = null;
   }

   private static String IlI(char[] var0, long var1, int var3) {
      int var4 = IIIII(1138413502, 2040939028) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IIIII(1138413503, -738533509);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   public void Ill() {
      if (!this.IIIIIlI()) {
         this.lIII(class_310.method_1551());
      } else if (this.IIl != Long.MIN_VALUE) {
         class_310 var1 = class_310.method_1551();
         long var2 = System.currentTimeMillis();
         if (var2 - this.II > 1000L) {
            this.lIII(var1);
         } else if (var2 >= this.IIl) {
            if (var1 != null && var1.field_1724 != null && var1.field_1761 != null && var1.field_1755 == null) {
               if (!this.IlIl(var1.field_1724)) {
                  this.lIII(var1);
               } else {
                  if (this.IlII(var1, var1.field_1724, var2)) {
                     this.lIll();
                  }

               }
            }
         }
      }
   }

   private static void lII() {
      lII[0] = IlI(IIIIl(1703756063, 2085756347).toCharArray(), 20761L, IIIII(1138413496, -635655759));
      lII[1] = IlI(IIIIl(1703756062, 71191527).toCharArray(), 10705L, IIIII(1138413497, -1330255849));
      lII[2] = IlI(IIIIl(1703756061, 727318710).toCharArray(), 93378L, IIIII(1138413498, 2057443247));
      lII[3] = IlI(IIIIl(1703756060, -1707468144).toCharArray(), 75609L, IIIII(1138413499, 687871124));
   }

   private boolean llI(class_310 var1, class_746 var2, int var3) {
      int var4 = this.IIII(var2);
      if (var4 >= 0 && var2.field_7498.method_34255().method_7960()) {
         lIlIllll.IllI(var1);
         lIlIllll.Il(var1, 3);
         var1.field_1761.method_2906(var2.field_7498.field_7763, var4, var3, class_1713.field_7791, var2);
         return true;
      } else {
         return true;
      }
   }

   static {
      short var6 = 26293;
      String var7 = "\ue2d9㥅ㅽ셡鉶ꢔ☭\ue7e0廍\ue1e3\ud94e\ue71c\ueb8eퟢ넀譫靠ꨝﳡ鴬氺皮鷶柛켍붤숔餮罽䋖Ḅ\ud80cŷ뷇摥ϺԚ骗\ufdef꽐ꯓ\uf5f4籪뱍滄삾গ㔒\uf0f7ỉ\ue740綱甇佋绷㙤仾⾴៳ᖦ냣\ue612⫂둍蓣쥕\ue726┦省◔㫂隱擳勫㗕쪅\uf432읐匣\ue5e6丒জꛮ䲶졹풬튼軡盋쿂\ue20aᮥ얰䞖⸄浀\ue937馇Ὠ\ua7d2\uf24a\ueab6컂ꋦᲕ灵燹헥턣檷䣚粰ᙸ\uf874侷견";
      char[] var8 = "暱暥曡暹".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            llI = var9;
            lll = new Object[var9.length];
            int var2 = 340625380;
            byte[] var0 = "Ú1{S\u008eq}hIB²/\u0084m\u0097ßµ\u0099Ò\u0082UuÔpíõÈ\b\u009fÛêQcÅ\u009a¯õ5)ÏN!NôXùez¼L%¿Ç\u001a¼ø".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lIl = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lIl[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            lII = new String[4];
            lII();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private boolean lll(class_746 var1) {
      if (var1 == null) {
         return false;
      } else {
         int var2 = IIlllllI.IIIl(var1.method_31548());
         return var2 >= 0 && var2 < IIIII(1138413492, 877843190) && this.Illl(var1.method_31548().method_5438(var2));
      }
   }

   private int IIII(class_746 var1) {
      int var2 = var1.field_7498.field_7761.size();

      for(int var3 = IIIII(1138413493, -1566416489); var3 < Math.min(IIIII(1138413494, 431359627), var2); ++var3) {
         class_1799 var4 = ((class_1735)var1.field_7498.field_7761.get(var3)).method_7677();
         if (this.Illl(var4)) {
            return var3;
         }
      }

      return -1;
   }

   private int IIll(class_746 var1, int var2) {
      for(int var3 = 0; var3 < IIIII(1138413495, 258878752); ++var3) {
         if (var3 != var2 && this.Illl(var1.method_31548().method_5438(var3))) {
            return var3;
         }
      }

      return -1;
   }

   public void lI() {
      this.IlI = IIIII(1138413488, 1809542635);
      this.lIII(class_310.method_1551());
   }

   private boolean IlII(class_310 var1, class_746 var2, long var3) {
      int var5 = IIlllllI.IIIl(var2.method_31548());
      if (this.Illl(var2.method_31548().method_5438(var5))) {
         return true;
      } else {
         int var6 = this.lIIl(var2, var5);
         if (this.Ill >= 0) {
            if (var3 < this.ll) {
               return false;
            } else if (var6 >= 0) {
               return this.llII(var1, var6);
            } else {
               this.ll(var1);
               return this.llI(var1, var2, var5);
            }
         } else if (var6 >= 0) {
            this.Ill = var6;
            this.ll = var3 + this.lllI(this.l);
            return var3 < this.ll ? false : this.llII(var1, var6);
         } else {
            return this.llI(var1, var2, var5);
         }
      }
   }

   private boolean IlIl(class_746 var1) {
      if (var1 == null) {
         return false;
      } else {
         int var2 = IIlllllI.IIIl(var1.method_31548());
         return this.Illl(var1.method_31548().method_5438(var2)) || this.IIll(var1, var2) >= 0 || this.IIII(var1) >= 0;
      }
   }

   private boolean Illl(class_1799 var1) {
      return var1 != null && !var1.method_7960() && var1.method_31574(class_1802.field_8288);
   }

   private void lIII(class_310 var1) {
      this.ll(var1);
      this.lIll();
   }

   private int lIIl(class_746 var1, int var2) {
      return this.Ill >= 0 && this.Ill < IIIII(1138413489, -1869744988) && this.Ill != var2 && this.Illl(var1.method_31548().method_5438(this.Ill)) ? this.Ill : this.IIll(var1, var2);
   }

   private void lIll() {
      this.IIl = Long.MIN_VALUE;
      this.ll = Long.MIN_VALUE;
      this.II = Long.MIN_VALUE;
      this.Ill = -1;
      this.Il = null;
   }

   private boolean llII(class_310 var1, int var2) {
      if (this.Il == null || !this.Il.III() || this.Il.ll() != var2) {
         this.Il = IllllIlI.lIll(var1, this, var2, 0, true);
      }

      if (this.Il != null && this.Il.III()) {
         if (!IllllIlI.IIII(var1, this.Il)) {
            this.ll(var1);
            return false;
         } else if (IllllIlI.IlIllII(var1, this.Il) && IllllIlI.IIlIIlI(var1, var2)) {
            this.Il = null;
            IllllIlI.IlII(var1, this, null.Il);
            return IIlllllI.IIIl(var1.field_1724.method_31548()) == var2;
         } else {
            return false;
         }
      } else {
         this.ll(var1);
         return false;
      }
   }

   private long lllI(llllIlIl var1) {
      double var2 = Math.max((double)0.0F, Math.min(var1.IlII(), var1.IlI()));
      double var4 = Math.max(var2, Math.max(var1.IlII(), var1.IlI()));
      return var2 == var4 ? Math.round(var2) : Math.round(ThreadLocalRandom.current().nextDouble(var2, var4));
   }

   private static int IIIII(int var0, int var1) {
      return lIl[var0 ^ 1138413500] ^ var1 ^ var0;
   }

   private static String IIIIl(int var0, int var1) {
      int var3 = var0 ^ 1703756063;
      char[] var4 = llI[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])lll[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         lll[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -529405776;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 175;
               break;
            case 1:
               var9 = 90;
               break;
            case 2:
               var9 = 65;
               break;
            case 3:
               var9 = 190;
               break;
            case 4:
               var9 = 161;
               break;
            case 5:
               var9 = 63;
               break;
            case 6:
               var9 = 56;
               break;
            case 7:
               var9 = 100;
               break;
            case 8:
               var9 = 80;
               break;
            case 9:
               var9 = 104;
               break;
            case 10:
               var9 = 226;
               break;
            case 11:
               var9 = 166;
               break;
            case 12:
               var9 = 221;
               break;
            case 13:
               var9 = 11;
               break;
            case 14:
               var9 = 250;
               break;
            case 15:
               var9 = 35;
               break;
            case 16:
               var9 = 131;
               break;
            case 17:
               var9 = 211;
               break;
            case 18:
               var9 = 96;
               break;
            case 19:
               var9 = 77;
               break;
            case 20:
               var9 = 33;
               break;
            case 21:
               var9 = 160;
               break;
            case 22:
               var9 = 144;
               break;
            case 23:
               var9 = 214;
               break;
            case 24:
               var9 = 68;
               break;
            case 25:
               var9 = 76;
               break;
            case 26:
               var9 = 4;
               break;
            case 27:
               var9 = 50;
               break;
            case 28:
               var9 = 120;
               break;
            case 29:
               var9 = 189;
               break;
            case 30:
               var9 = 94;
               break;
            case 31:
               var9 = 61;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
