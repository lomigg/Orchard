package x;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import javax.imageio.ImageIO;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1060;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

@Environment(EnvType.CLIENT)
public final class lIIIllIl extends class_437 {
   private static final double I = (double)190.0F;
   private double l;
   private <undefinedtype> II;
   private <undefinedtype> Il;
   private double lI;
   private boolean ll;
   private static final double III = 0.95;
   private static final double IIl = (double)8.0F;
   private llllIlIl IlI;
   private static final double Ill = (double)4.0F;
   private IIIllIIII lII;
   private static final double lIl = (double)24.0F;
   private static final long llI = 524288L;
   private boolean lll;
   private static final double IIII = (double)184.0F;
   private static final double IIIl = 0.82;
   private static final int IIlI = 16;
   private double IIll;
   private double IlII;
   private static final double IlIl = (double)18.0F;
   private long IllI;
   private double Illl;
   private final class_437 lIII;
   private static final double lIIl = 0.58;
   private double lIlI;
   private IIllIlIII lIll;
   private double llII;
   private static final double llIl = (double)10.0F;
   private final Map<Long, Double> lllI;
   private static final double llll = 0.015;
   private double IIIII;
   private final lIllIIl IIIIl;
   private <undefinedtype> IIIlI;
   private boolean IIIll;
   private static final int IIlII = 4096;
   private static final double IIlIl = (double)12.0F;
   private boolean IIllI;
   private <undefinedtype> IIlll;
   private String IlIII;
   private double IlIIl;
   private final Map<Long, Double> IlIlI;
   private double IlIll;
   private static final double IllII = (double)8.0F;
   private final Map<llllllI<?>, <undefinedtype>> IllIl;
   private static final double IlllI = (double)5.0F;
   private double Illll;
   private double lIIII;
   private double lIIIl;
   private double lIIlI;
   private llIlIIII lIIll;
   private static final double lIlII = (double)31.0F;
   private static final double lIlIl = (double)8.5F;
   private static final IIIlIlIII[] lIllI;
   private static final double lIlll = (double)360.0F;
   private double llIII;
   private double llIIl;
   private <undefinedtype> llIlI;
   private static final double llIll = (double)6.0F;
   private static final int lllII = -15395044;
   private static final double lllIl = (double)22.0F;
   private final EnumMap<IIllIIlII, Double> llllI;
   private static final lIllII[] lllll;
   private static final double IIIIII = (double)6.0F;
   private boolean IIIIIl;
   private static final double IIIIlI = (double)28.0F;
   private String IIIIll;
   private final EnumMap<IIllIIlII, Double> IIIlII;
   private boolean IIIlIl = false;
   private static final double IIIllI = (double)14.0F;
   private final IIllIIIIl IIIlll;
   private String IIlIII;
   private double IIlIIl;
   private final Map<Enum<?>, Double> IIlIlI;
   private lIllII IIlIll;
   private double IIllII;
   private String IIllIl;
   private double IIlllI;
   private double IIllll;
   private static final double IlIIII = (double)39.0F;
   private static final long IlIIIl = 750000000L;
   private static final <undefinedtype> IlIIlI;
   private static final <undefinedtype> IlIIll;
   private double IlIlII;
   private static final <undefinedtype> IlIlIl;
   private final IlIIlIll IlIllI = new IlIIlIll();
   private boolean IlIlll;
   private static final <undefinedtype> IllIII;
   private class_332 IllIIl;
   private double IllIlI;
   private String IllIll;
   private double IlllII;
   private static final double IlllIl = (double)44.0F;
   private double IllllI;
   private long Illlll;
   private String lIIIII = "";
   private static final Set<Long> lIIIIl;
   private static final int lIIIlI = 8388608;
   private final Map<Long, Double> lIIIll;
   private boolean lIIlII;
   private final IIIlIIIll lIIlIl = new IIIlIIIll();
   private boolean lIIllI;
   private final IlllII lIIlll = new IlllII();
   private String lIlIII;
   private static final double lIlIIl = 0.92;
   private <undefinedtype> lIlIlI;
   private String lIlIll;
   private double lIllII;
   private <undefinedtype> lIllIl;
   private double lIlllI;
   private double lIllll;
   private double llIIII;
   private static final Set<Long> llIIIl;
   private double llIIlI;
   private double llIIll;
   private boolean llIlII;
   private <undefinedtype> llIlIl;
   private boolean llIllI;
   private static final int[] llIlll;
   private static final String[] lllIII;
   private static final Object[] lllIIl;

   private boolean I(class_11909 var1) {
      if (!this.lIlIIll()) {
         return false;
      } else {
         <undefinedtype> var2 = this.IIIIl.II().ll();
         double var3 = this.IIIlllI();
         double var5 = (double)112.0F;
         double var7 = ((double)this.Il.I() - var3) * (double)0.5F;
         double var9 = ((double)this.Il.lI() - var5) * (double)0.5F;
         double var11 = var9 + var5 - (double)28.0F;
         double var13 = var7 + var3 * (double)0.5F - (double)92.0F;
         double var15 = var7 + var3 * (double)0.5F + (double)8.0F;
         if (llIlII(var1.comp_4798(), var1.comp_4799(), var13, var11, (double)84.0F, (double)20.0F)) {
            this.lIIlII = true;
            return true;
         } else if (llIlII(var1.comp_4798(), var1.comp_4799(), var15, var11, (double)84.0F, (double)20.0F)) {
            this.lllI(var2.lI());
            this.lIIlII = true;
            return true;
         } else {
            return true;
         }
      }
   }

   private void l() {
      if (this.field_22787 != null) {
         this.field_22787.field_1774.method_1455(this.IIIlll.ll(this.IIIIl.IIl()));
         this.IIIIll = x.lIlIII.Il(llIIlII(481449204, 852629493));
      }

   }

   private void II(class_332 var1) {
      if (this.IlllII < (double)0.0F) {
         this.IlllII = this.llIIlI;
         this.IIlllI = this.IIIII;
         this.IllllI = this.IlIll;
      }

      double var2 = Math.sin(this.IIllII * 6.28 * (double)1.5F) * (double)0.5F + (double)0.5F;
      int var4 = (int)(var2 * (double)255.0F);
      int var5 = this.IlIllI.IllIl() & llIIIll(-1645453238, 13693147) | var4 << llIIIll(-1645453237, 1676216182);
      IIIIIIllI.IllIll(var1, this.IlllII, this.IIlllI, (double)1.5F, this.IllllI, (double)0.75F, var5);
   }

   private void lI(IIIIIIIlI var1, double var2, double var4, double var6) {
      String var8 = x.lIlIII.Il(llIIlII(481449205, -1544673789));
      double var9 = this.llll(var8, var2, var6);
      double var11 = Math.max((double)0.0F, var2 + var6 - var9);
      double var13 = var4 + Math.max((double)0.0F, ((double)24.0F - IIIIIIllI.lllIII(this.field_22793) * 0.82) * (double)0.5F);
      this.IlIllI.IIIllI(var8, var2, var13, Math.max((double)0.0F, var9 - var2 - (double)8.0F), -1, 0.82);
      this.IlIllI.IlIII(var9, var4 + (double)2.0F, var11, (double)20.0F, var8, false, 0.82);
      this.lIIlIl.III(var9, var4, var11, (double)24.0F, (var2x, var3) -> {
         var1.IIIllll();
         this.IlIll();
         return true;
      });
   }

   private void ll(class_310 var1, String var2) {
      CompletableFuture.runAsync(() -> {
         byte[] var3 = IIllIIl(var2);
         class_1011 var4 = var3 == null ? null : lIllI(var3);
         if (var1 == null) {
            if (var4 != null) {
               try {
                  var4.close();
               } catch (Throwable var6) {
               }
            }

         } else {
            var1.execute(() -> {
               if (!var2.equals(this.lIIIII)) {
                  if (var4 != null) {
                     try {
                        var4.close();
                     } catch (Throwable var6) {
                     }
                  }

               } else {
                  this.IllllI(var1);
                  if (var4 != null && var1.method_1531() != null) {
                     try {
                        class_2960 var4x = IlIIll();
                        class_1060 var10000 = var1.method_1531();
                        Objects.requireNonNull(var4x);
                        var10000.method_4616(var4x, new class_1043(var4x::toString, var4));
                        this.IIIlIl = true;
                     } catch (Throwable var8) {
                        try {
                           var4.close();
                        } catch (Throwable var7) {
                        }
                     }
                  }

               }
            });
         }
      });
   }

   private void IIl(double var1, double var3) {
      double var5 = this.IIIIlI(this.IIIIl.IIl().llIlI().size());
      this.lIIlll.ll = Math.max((double)8.0F, Math.min(var1 - this.lIIlI, (double)this.Il.I() - (double)190.0F - (double)8.0F));
      this.lIIlll.lI = Math.max((double)8.0F, Math.min(var3 - this.l, (double)this.Il.lI() - var5 - (double)8.0F));
      this.IIllI();
   }

   private void IlI(boolean var1) {
      String var2 = IlllIll(this.IllIll);
      if (var2.isBlank()) {
         this.IIIIll = x.lIlIII.Il(llIIlII(481449206, -1639754554));
      } else {
         if (var2.length() > llIIIll(-1645453240, -1950435514)) {
            var2 = var2.substring(0, llIIIll(-1645453239, 276172498));
         }

         if (!var1 && this.IIIlll.IllI().contains(var2)) {
            this.IIIIll = x.lIlIII.Il(llIIlII(481449207, 1728208467));
         } else {
            boolean var3 = this.IIIlll.lIIl(var2, this.IIIIl.IIl());
            String var10001;
            if (var3) {
               String var4 = x.lIlIII.Il(llIIlII(481449200, -1788454805));
               var10001 = var4 + var2;
            } else {
               var10001 = x.lIlIII.Il(llIIlII(481449201, 1677544914));
            }

            this.IIIIll = var10001;
         }
      }
   }

   private List<IIIIIIIlI> lII(List<IIIIIIIlI> var1) {
      if (this.IIIlI != null.II && var1 != null && !var1.isEmpty()) {
         if (this.lIIlll.II != x.lIllII.ll && this.lIIlll.II != x.lIllII.IIl) {
            ArrayList var2 = new ArrayList();

            for(IIIIIIIlI var4 : var1) {
               boolean var5 = this.IlIl(var4);
               if (this.IIIlI == null.I && var5 || this.IIIlI == null.Il && !var5) {
                  var2.add(var4);
               }
            }

            return var2;
         } else {
            return var1;
         }
      } else {
         return var1;
      }
   }

   private static String llI(double var0) {
      return Math.abs(var0 - Math.rint(var0)) < 1.0E-4 ? Integer.toString((int)Math.rint(var0)) : String.format(Locale.ROOT, x.lIlIII.Il(llIIlII(481449202, -1507574749)), var0);
   }

   private class_11909 IIII(class_11909 var1) {
      return new class_11909(this.Il.Il(var1.comp_4798()), this.Il.l(var1.comp_4799()), var1.comp_4800());
   }

   public boolean method_25402(class_11909 var1, boolean var2) {
      if (this.IIIIIl) {
         return true;
      } else {
         this.llIIIII();
         class_11909 var3 = this.IIII(var1);
         if (this.II != null) {
            if (this.IIllI) {
               this.IIllI = false;
               return true;
            } else {
               this.II.ll(IllllIlI.IllII(var3.method_74245()));
               this.II = null;
               this.IlIll();
               return true;
            }
         } else if (this.lIllIl != null) {
            this.llllIl(var3);
            return true;
         } else if (this.lIlIIll()) {
            this.I(var3);
            return true;
         } else {
            class_11909 var4 = this.lIIII(var3);
            if (!this.lIlIIl(var4.comp_4798(), var4.comp_4799())) {
               this.lll = false;
            }

            if (!this.IlIlI(var4.comp_4798(), var4.comp_4799())) {
               this.IlIlII();
               return true;
            } else {
               if (this.llIlI != null) {
                  this.IllIlII();
               }

               if (this.lIIlIl.lI(var4, var2)) {
                  return true;
               } else {
                  this.IlIlII();
                  return true;
               }
            }
         }
      }
   }

   private void IIIl(String var1, String var2, double var3, double var5, double var7) {
      double var9 = var5 + (double)6.0F;
      String var11 = var2 == null ? "" : var2;
      double var12 = var11.isBlank() ? (double)0.0F : Math.min(var7 * 0.48, Math.max((double)24.0F, (double)this.IlIllI.IIl(var11) * 0.82 + (double)2.0F));
      double var14 = Math.max((double)0.0F, var7 - var12 - (var12 > (double)0.0F ? (double)7.0F : (double)0.0F));
      this.IlIllI.IIIllI(var1, var3, var9, var14, -1, 0.82);
      if (!var11.isBlank()) {
         String var16 = this.IlIllI.IIlll(var11, Math.max((double)0.0F, var12 / 0.82));
         double var17 = (double)this.IlIllI.IIl(var16) * 0.82;
         this.IlIllI.Il(var16, var3 + var7 - var17, var9, -1, 0.82);
      }

   }

   private static <undefinedtype> IIll(llIlIIII var0) {
      if (var0 instanceof IIIIIIIlI var1) {
         return var1.lllllI();
      } else {
         return var0 == null ? x.lIlIII.l("") : x.lIlIII.III(var0.getClass().getSimpleName());
      }
   }

   private void IlII(IIIIIIIlI var1, double var2, double var4, double var6, boolean var8, double var9) {
      <undefinedtype> var11 = this.IlIllI.lIIl(var1.lllllI(), var6 / 0.92);
      int var12 = var8 ? this.IlIllI.lI() : -1;
      var12 = this.IlllII(var12, var9);
      Runnable var14 = () -> {
         IIIIIIllI.IIIllI(this.lIIIIl());

         try {
            IIIIIIllI.IlII(this.lIIIIl(), var2, var4);
            IIIIIIllI.lllI(this.lIIIIl(), 0.92, 0.92);
            this.IlIllI.IIIll(var11, (double)0.0F, (double)0.0F, var12);
         } finally {
            IIIIIIllI.lIIlIl(this.lIIIIl());
         }

      };
      if (var8 && this.llllI(var1)) {
         IIIIIIllI.IlIIll(true, var14);
      } else {
         var14.run();
      }

   }

   private boolean IlIl(IIIIIIIlI var1) {
      if (var1 == null) {
         return false;
      } else if (var1.IlIIIII() != x.lIllII.ll && var1.IlIIIII() != x.lIllII.IIl) {
         if (!(var1 instanceof IIIIIlIlI) && !(var1 instanceof llIIIllI)) {
            long var2 = var1.IIllllI().lII();
            return lIIIIl.contains(var2) ? false : llIIIl.contains(var2);
         } else {
            return true;
         }
      } else {
         return true;
      }
   }

   private void Illl(double var1, double var3, double var5) {
      int var7 = this.IIIlIl ? IlIIlIll.IIlIIl(new Color(llIIIll(-1645453234, 1032260269), llIIIll(-1645453233, 520312183), llIIIll(-1645453236, 562487636)), llIIIll(-1645453235, -1811274990)) : llIIIll(-1645453246, -1466970649);
      IIIIIIllI.IllIll(this.lIIIIl(), var1 + (double)6.0F, var3 + (double)6.0F, (double)100.0F, var5 - (double)12.0F, (double)7.0F, var7);
      double var8 = var3 + (double)52.0F;

      for(lIllII var13 : lllll) {
         boolean var14 = this.lIIlll.lIl == IIIlIlIII.IIl && this.lIIlll.II == var13;
         double var15 = (Double)this.IIlIlI.getOrDefault(var13, (double)0.0F);
         double var17 = var14 ? (double)2.0F : (double)0.0F;
         double var19 = this.IlIllIl(var15, var17, (double)18.0F);
         this.IIlIlI.put(var13, var19);
         double var21 = var1 + (double)18.0F + var19;
         double var23 = var8 - (double)6.0F;
         double var25 = (double)24.0F;
         double var27 = (double)92.0F;
         double var29 = 0.85;
         double var31 = IIIIIIllI.lllIII(this.field_22793);
         double var33 = var23 + (var25 - var31 * var29) * (double)0.5F;
         String var35 = IIIIIII(var13);
         double var36 = lIllIIl(var23, var25);
         double var38 = var21 + (double)20.0F;
         double var40 = var17 <= (double)0.0F ? (double)0.0F : var19 / var17;
         if (var40 > 0.01) {
            int var42 = this.lIlllIl(this.IlIllI.lI(), var1 + (double)10.0F, var23, 0);
            int var43 = (int)(var40 * (double)150.0F);
            int var44 = var42 & llIIIll(-1645453245, -1811990412) | var43 << llIIIll(-1645453248, 2116373528);
            IIIIIIllI.IllIll(this.lIIIIl(), var1 + (double)10.0F, var23, var27, var25, (double)6.0F, var44);
         }

         byte var48 = -1;
         byte var49 = -1;
         IIIIIIllI.IIIllI(this.lIIIIl());

         try {
            IIIIIIllI.IlII(this.lIIIIl(), var38, var33);
            IIIIIIllI.lllI(this.lIIIIl(), var29, var29);
            this.IlIllI.llIII(var35, (double)0.0F, (double)0.0F, var48);
         } finally {
            IIIIIIllI.lIIlIl(this.lIIIIl());
         }

         this.IlIllI.lllI(var13, var21, var36, var49);
         this.lIIlIl.III(var1 + (double)10.0F, var23, var27, var25, (var2, var3x) -> {
            this.IIIIIlI();
            this.IlllI(var13);
            this.lIIlll.lIl = IIIlIlIII.IIl;
            this.lll = false;
            this.IIllI();
            return true;
         });
         var8 += (double)28.0F;
      }

      this.lIIIlIl(var1, var3, var5);
   }

   private void lIII(class_310 var1, lIIIllll var2) {
      String var3 = var2 == null ? "" : var2.IIlll().trim();
      if (!var3.equals(this.lIIIII)) {
         this.lIIIII = var3;
         if (!var3.isEmpty() && llIIII(var3)) {
            this.ll(var1, var3);
         } else {
            this.IllllI(var1);
         }
      }

   }

   private double lIIl(IIIIIIIlI var1, llllllI<?> var2, double var3) {
      return this.IIlII(var1, var2, "", var3);
   }

   private void lIlI(IIIIIIIlI var1, double var2, double var4, double var6) {
      String var8 = x.lIlIII.Il(llIIlII(481449203, 659435247));
      double var9 = this.llll(var8, var2, var6);
      double var11 = Math.max((double)0.0F, var2 + var6 - var9);
      double var13 = var4 + Math.max((double)0.0F, ((double)24.0F - IIIIIIllI.lllIII(this.field_22793) * 0.82) * (double)0.5F);
      this.IlIllI.IIIllI(var8, var2, var13, Math.max((double)0.0F, var9 - var2 - (double)8.0F), -1, 0.82);
      this.IlIllI.IlIII(var9, var4 + (double)2.0F, var11, (double)20.0F, IllllIlI.IIIlIl(var1.IIIlIII()), false, 0.82);
      this.lIIlIl.III(var9, var4, var11, (double)24.0F, (var2x, var3) -> {
         this.IlIlIII(null.l(var1));
         return true;
      });
   }

   private void llII(IIIIIIIlI var1, double var2, double var4, double var6, boolean var8, double var9) {
      String var11 = var1 == null ? "" : var1.llllll();
      if (var11 != null && !var11.isBlank() && !(var6 <= (double)0.0F)) {
         double var12 = var6 / 0.58;
         List var14 = this.IlllIII(var11, var12);
         int var15 = this.IlllII(llIIIll(-1645453247, 1424436086), var9);
         if (!var14.isEmpty()) {
            String var16 = (String)var14.get(0);
            if (var14.size() > 1 || (double)IIIIIIllI.IlIl(this.field_22793, var16) > var12) {
               IlIIlIll var10000 = this.IlIllI;
               String var19 = x.lIlIII.Il(llIIlII(481449212, 219945964));
               var16 = var10000.IIlll(var16 + var19, var12);
            }

            if (var16.length() > llIIIll(-1645453242, -1235519323)) {
               IlIIlIll var24 = this.IlIllI;
               String var10001 = var16.substring(0, llIIIll(-1645453241, 388315598));
               String var20 = x.lIlIII.Il(llIIlII(481449213, 1980775438));
               String var23 = var10001;
               var16 = var24.IIlll(var23 + var20, var12);
            }

            IIIIIIllI.IIIllI(this.lIIIIl());

            try {
               IIIIIIllI.IlII(this.lIIIIl(), var2, var4);
               IIIIIIllI.lllI(this.lIIIIl(), 0.58, 0.58);
               this.IlIllI.IIllI(var16, (double)0.0F, (double)0.0F, var12, var15);
            } finally {
               IIIIIIllI.lIIlIl(this.lIIIIl());
            }

         }
      }
   }

   public void llIl(IIIlIlIII var1) {
      this.lIIlll.lIl = var1 == null ? IIIlIlIII.IIl : var1;
      this.IIllI();
   }

   private void lllI(Object var1) {
      if (var1 != null) {
         String var2 = this.llIllI(var1);
         if (!var2.isBlank()) {
            try {
               class_156.method_668().method_670(var2);
            } catch (RuntimeException var4) {
            }

         }
      }
   }

   static {
      short var6 = 1948;
      String var7 = "᭠ᬅ᭠\u1bf4ᯀᮌᬷᮞᬍ᭓ᬘ\u1b4e᭣ᯕᮑ\u1bfbᬦᯀ\u1bfbᬸ詜言詀諢諼誉詹誘訁詫訒詳評誇諚諵런랕런띤띐뜜랧뜎랝럃랈럑럲뜫띲띙랡뜜띀럷띺띷랈랞럃럎럶띤亱仔亱严丑九仦乏仜亂仉亝亲乹么丘仰丑丯亜乢乲仉件予亦令丏乍乤丞乜볕볌볙뱠뱵밃볰밑䩎䩗䩂䫻䫮䪜䨷䪀䨠䩹䨘䩗䩋䪕䫵䪹迕迟辢輦輷轴辿輶໊ຒລ๙\u0e6eซ\u0ee6\u0e6fⓜⓄ⒩␋忐忈徥弇뽃뼀뼷뿳뿼뾉뽴뿽䮠䯑䮑䬔䬃䭢䯳䬆갵걄간겁겖곷걦곶걑강걤갌갻곲곇곅㔷㔊㔐㖼㏑㎸㏑㍺㍫㌱㎊㌆㎣㏐㎧㎋\udb67\udb0c\udb76\udbd4\udbda\udbaf\udb1f\udba7\udb14\udb4e\udb0c\udb3cꂪꃀꃝꀚꀕꁣꃓꁯꃚꂂꂜꂉ㕨㔖㕳㗡㗓㖏㕓㖼㔙㕾㕄㕑㕺㖳㖆㖄ㆢ㇣㆑ㄭㄙㅜ㆛ㅰ㇕ㆲㆌ㆑ㆶㅿㅊㅈ\uf8a1\uf8a2\uf8a2\uf81a\uf81d\uf87f\uf892\uf81b뫣몢뫐멚멞먒뫒먱몐뫬몖뫇뫾먥멆멻ᴏᵖᴉᶹᶲ᷐ᵴᷚᵿᴈᵹᴪ⟟⟚⟱❑❠✿➜✗➮⟴⟰⟾⟀✃✶✴䪰䫎䪴䨈䨏䩄䫫䩡䫆䪜䫀䪆䪨䩨䩝䩟᭘᭝᭶ᯖᯧ᮸ᬛᮐᬪ᭙᭷᭻ᭆᯰᯯ᮳醤醡醴鄉鄜酾釅酡釒醥釮醆醱酸配酏椌楥椌榧榶槣椰槛楳椷楲楖ꌰꍱꌃꎾꎉꏻꍪꏹꍀꌊꍁꌴꌯꏵꎼꏚ㨙㩧㨝㪰㪡㫭㩬㫈㩨㨥㩵㨟㨂㫰㪽㪪㩆㫬㪵㨩㪌㫨㩻㨶䍋䍋䍛䏢䏲䎅䌢䎋䌹䍞䌿䍭䍖䎋䏨䎤䰏䰏䰟䲦䲶䳁䱦䳏哊哋哸呲呵吗哶吙咸哶哮咔䕄䔭䕄䗯䗾䖫䕼䖝䔻䕅䔘䔞\uf567\uf562\uf549\uf5e9\uf5d8\uf587\uf524\uf5a2\uf517\uf54c\uf53d\uf543\uf578\uf5b0\uf586\uf5ff\uf53c\uf5db\uf5f9\uf54f\uf5f1\uf599\uf50c\uf54cꈒꉻꈿꊵꊩꋈꉬꋆꉧꈟꉹꈡꈋꋍꋸꋺ냵낶냦끔끎뀯낓뀔낄냝냀냂ոռդל׃֗Հ֯ԇՃԪ\u0557խ֯\u05f6\u05fbԣ׃טգ\u05ee֖ԓՓ\u09dbয়েॿॠऴৣऌতৠউ৴ৎऌॕक़ঀॠ॑ী्वরৰ㌕㍔㌦㎤㎩㏝㍭㏑㍥㌯㍤㌑㌊㏐㎙㏿늪닱늡눓눉뉪닾뉟䃫䂰䃠䁒䁈䀬䂉䀧䂆䃮䂊䂪뉗뉗뉇닫달늚눮늱눦뉸눅뉥뉊늟늺늸\uf241\uf258\uf263\uf2d3\uf2e1\uf297\uf202\uf289\uf219\uf243\uf276\uf269\uf243\uf29a\uf2db\uf2e8\uf20c\uf2c4\uf284\uf219蓫蒷蓴葦葔萢蒅萼蒞蓦蓈蒲ᢓᢐᢕᠱᠮᡵᣞᡴᣠᢾᣋᢥᢀᡂ\u181b᠔ᣍᠾᠰᣑ叶压叱卍卋匸厗卌ꬨꭋꬃꮍꮍ\uabefꭔꯣꭃ\uab1aꭻꬴꬨ꯶ꮖꮣꭼꮎꯨꭵ驨驵驂髸髊骪驈骩騅驱騡驏驽骧髀髪騪髋髐驞髧骅驵騷맋맖맡륛륩뤉맫뤊릦맒릇릉淔淉淾浄浶洖淴洕涹淍涝淳淙洛浼浖涖海浬淢浛洹淉涋회횑횦혜혮홎횬홍훡횕훀훎椋楔椄榹榩槞極槂楤椿楊椖椁槀榙槿菤莣菳荎荞茩莂茵莓菈莽菡菶茷荮茈湣湾湕滵滀溡渆溢渉湓湐湈湵溬滵滸渪溊滥湏滮溠湄渾湐湳湟滁溜溟溤溊ꚩꛝꚝꘘ꘍Ꙙꛊ꙳ꛆꚜꛀꚈꚮꙣꙒ\ua636ꛦꙇꘃꚬ꘦ꙬꚈ\ua6f9ꚝꛐꚏ\ua63dꙝꙓꙚꙆ\ua97fꤝꥸꧬ꧟ꦽ꤁ꦷꤕ\ua95b꤀ꥑꥸꦣꧾ꧑ꤩꦔ꧔ꥻ꧲ꦯ\ua95bꤓꥎ꤂\ua97d꧒ꦀꦄꦫꧥꥡ꤅ꥇ꧔ꧠꦽꤽ꦳쓱쓬쓛쑁쑓쐳쓐쐱쒖쓸쒻쓊쓧쐾쑧쑪쒸쐘쑷쓝쑼쐲쓖쒮쓆쓋쓕쑏쐉쑐쐲쑼쒵쒮쒙쑔쑮쐠쒏쑔⑿␎\u244eⓋⓜⒽ\u242cⓙ➭⟜➜✙✎❯⟾✋◙◅◝╹╾┈◹┒ㄳㄪㄿㆆ㆓\u31e6ㄛ㆒ジャゑ【〟べヒづ猽獤猑玛玟珄獅珦獕猏獓猛猾珰珁玥獾玈玲猎玵玿猄獧猍猬猾玆翫羈翀罎罎缫翆罏㇡㆓㇄ㅕㅀㄕㆇㄾ\ue6ac\ue6cd\ue6b7\ue604\ue60b\ue67e\ue68f\ue664\udc0b\udc51\udc6d\udcc1뀃뀞뀆남낧냀끻냜끫뀢뀺끀甃畢甘疫疤痑甠痋畩甧畲畂戩扈戲抁抎拻戊拡扐戉扞戂戮拵抨抇扨抍拫扶遱适遨郣郐邡遜郕\uef58\uef00\uef37\uefcb\ueffc\uef99\uef74\ueffd쓈쒭쓈쑬쑯쐴쒥쐐쒰쓁쒾쒎ɒȦɺ˥˰ʆȡʈȳɂɧɤɂʘʡ˖Ȗ˷ˬɗ˙ʌɩɧ䛃䚦䛃䙧䙤䘿䚮䘛\ue745\ue720\ue745\ue7e1\ue7e2\ue7b9\ue728\ue79d暝曄暱昻昿晝曹晗曲暅更暧暞普晭景倈倪偃傃ꆟꇼꆴꄺꄺꅟꆲꄻꁐꀈꀿꃃꃴꂑꁼꃵ醟醢醸鄔十卝卅叡另厐卡厊匨卦匳匃☋☖☡⚻⚩⛉☪⛋♬☂♁☰☝⛄⚿⚉♉⚯⚻☡⚂⚅☬♀☼☱☉⚴⛴⛰⛌⛢囖嚻囧噝噫嘡嚂嘐嚮囏囱嚋陃陦阀隴隡雖陃雈陾阤阼陆ឮ៏឵\u173eᜎ\u1755\u17fe\u1771េរ្ឋុᝤᝐᜯ\u17efᜉ\u171dឨᜥ\u177d\u17deឞ\ueeb9\ueea4\uee93\uee2a\uee19\uee78\ueedc\uee78\ueede\uee9e\ueec5\ueea8\ueebf\uee66\uee33\uee14\ueef9\uee1e\uee78\ueee5䉙䈬䉰䋵䋼䊦䈧䊒䈤䉻䈔䉧䉘䋮䋶䋉䈗䋪䋁䈂\u0c74౩\u0c71\u0cdf\u0cd0ಷఌಫజ\u0c52ఉ\u0c3a\u0c72\u0cbaೣ\u0cd8వೆ೬\u0c71\u0cf8\u0cf6\u0c52పె౦౻ೢಙ\u0cd4ದ೪౬\u0c3a౬\u0cd3೫\u0cb4\u0c57ಋ౸ౣ్ష䯇䯛䯟䭲䭤䬯䮮䬅䮪䯣䮠䯠㰖㱵㰟㲤㲳㳆㱶㳋㱫㰚㱥㱕뫨몉뫁멝멉먃몬먪몁뫘몄뫌뫦먤멃멆몾먂머뫬멦먬몗몭뫟뫯뫵멽먐먗먖멮뫵뫳뫜멕면먀뫕먲몭뫺뫅뫖몟먨멂멱몬멾멳뫘멌먖몑몮뫥몐뫺멝㛬㚏㛥㙞㙉㘼㚏㙈Ͷ̗͟σϗΝ̲δ̷̟̗͆㑏㑊㑟㓤㓴㒠㑻㓲垐埭垗地圯坎埦坑埦垿垥垩垎圾圳圐域圑圷垢圁坡垸埣垽垤垫圙坳坳坔圃垑埥垠圬園坎埖坏\ue4df\ue4c2\ue4e9\ue449\ue47b\ue40d\ue4aa\ue403地坉圳垊垌基坂埑坆國圓坩ᷗᶲᷗᵳᵰᴫᶺᴏぁ〵ふヰュグ〢゛〮ぴ〨だぁヷヅヘ『ギンぴネツへ〘ついすヿズゑよヅた〘〩よ먁먜먷몗몢뫃멤뫀멫먱먲먪먗뫎몗몚멈뫨몇먭몌뫂먦멜먲먑먽몣뫾뫽뫆뫨\uf4e7\uf48a\uf4d6\uf46c\uf45a\uf410\uf4b3\uf421\uf49f\uf4fe\uf4c0\uf4ba╥╀┦▒▇◰╥◮╘│┚╠獠猟獢珍珝玿猀玨猉献猶猼노넇녺뇕뇅놣넺놧넑녰녞네\ue08e\ue0b3\ue0a9\ue005뫸몓몎멲\ue006\ue06d\ue017\ue0a0掸揉掉挌挛捺揫挞\uf492\uf4f4\uf4a0\uf432\uf437\uf444\uf4ff\uf448\uee49\uee54\uee63\ueee1\ueeee\ueea1\uee30\uee95⍛⌨⍰⏫⏾⎈⌙⎑⌽⍜⌸⌘닣늿닿뉴뉃눥늎눹ꚱꛖꚯꘔ⚈⛼⚠☽☪♟⛫♄⛤⚽⚠⚢紧絆紬綷綀緜絍緺絃紲経紞紲緭緝綼絢緛緯紣綪緉紺絿紗紴絵綞緖緘綊綣乧乺乯仴什亟与亝煓煎煹燀燷熻焀熍焴煣煫焑\uee70\uee15\uee70\ueee2\ueed6\ueea6\uee0d\ueeaa\uee18\uee43\uee08\uee5e\uee73\ueec4\ueef6\ueeed\uee3d\ueef5\ueeb5\uee28ꋯꋶꋳꉁꉉꈓꊞꈧꊁꋛꋘꋛꋽꈤꉟꉲꊫꈂꉭꋇ蒶蓓蒨萵葊葴蓳葱蓙蒐蓘蒭蒱葬萋葃骽髜骦騕騚驯骞驵髗骙髌髼莿菞莤茗茘荭莜荷菆莟菈莔莸荣茾茑菾茛荽菠\uf171\uf114\uf171\uf1d5\uf1d6\uf182\uf10b\uf1b5\uf11f\uf142\uf109\uf169\uf174\uf1a9\uf1e0\uf1e1\uf135\uf1e8\uf1ce\uf171\uf1fa\uf1f7\uf15e\uf139\uf142\uf10a\uf170\uf1db\uf189\uf1b0\uf1b6\uf1e8\uf167\uf12a\uf14e\uf1d5籯簝籖糆糋粽簑粧簛籋簐簢籪粳糘糱簥糱糀籫糦粁簑簻籏籬籈糔粀糏粫糢籴簳簀糒糽粩籒粥籣籽簜籉籁粂糃粟ﰾﰣﰔﲭﲞﳿﱛﳿﱙﰙﱂﰯﰸﳡﲴﲓﱾﲙﳿﱢ㈡㈼㈋㊔㊅㋷㉜㋘㉆㈷㉕㈍㈦㋾㊝㊷㉧㋄㋶㈥㊯㋜㉝㉎㈑㈡㈣㊙㋓㋝㊃㊗㉦㈹㈖㊄㊾㋙\u321f㋾㉧㈴㈒㈒㈊㋲㊀㊥㉦㊧㊇㈅㊃㋌㈈㉨㉴㈓㈣㊚㊸㋕㋅㊐㈺㉓㈓㊁㊂㋉㈅㋪㉆㈨㈏㈑㈷㋮㊕㊸㉡㊒㊻㈍㊮㋌㈼㉧\ue672\ue62b\ue65e\ue6d4\ue6d1\ue6a1\ue638\ue6bf\ue61e\ue640\ue635\ue65f\ue671\ue6cf\ue686\ue6ec\ue633\ue6f9\ue6c2\ue62f㉴㈭㉘㋒㋗㊧㈌㊩\u321f㉬㈣㉙㉷㋉㊀㋝㈵㋨㋎㉱핕핉핎헃䧟䦩䧢䥸䥻䤴䦛䥲䦱䧁䦰䧽䧕䤜䤩䤫뾊뿹뾡뼶뼮뽙뿌뽱뿡뾼뿞뾷뾜뽽뽿뼟뿘뽰뼣뾲뼄뽶뾼뿧뾿뿵뿛뼥뽄뽌뽏뼼뾆뿏뾿뼫뼁뽝뿉뽇뾂뾰뿫뾣뾹뽩뼃뼍뿝뼎뽏뾭뼼뽲뿰뿌뾘뾪뾉뼙뼒뼢뽨뼯뾐뿹뾏뽖뼮뽚뾪뽊뿶뾿뾡뾵뾜뽽뼰뼕뿞뽮뼁뿛뼛뽍뾼뾰뾋뾏뾠뼥뽶뼪뽶뼇뾕뿈뾼뽍뼚뽊뿠뽊뾄뾎뿨뾭뾺뼿뼾뼊뿌뼷뼇뾼뼺뼄뾟뿤뾔뾓뾆뼙뽏뽂뼪뼎뾇뿭뾇뼗뼬뽙뾣뽄뿥뾂뿖뾭뾖뽭뼰뼊뿛뼂뼴뾣㯨㮚㯒㭂㭌㬹㮕㬴⟬➀⟀❖❖✊➔✳➘⟂➆⟨⟳✃❰❭➲❖❂⟉❻❼⟙➸⟂⟢➯❌✟❓✏❴⟫➽➇❡❽✕⟔✮⟽⟙➙⟘⟙✡❓❘➻❎❇⟵❒❱⟹➬➦⟽⟞❅❫❗✯❾⟫➀⟺❔❖✤➺✎➅⟕➕⟔⟦✄❬❵➦❍❁⟂❮✢➁⟁揔掷揿捿捲挄揵挨掲揌掙掗녭넒녯뇀뇐놲넍놥넄넣넻넱㦗㧨㦕㤺㤪㥌㧕㥈㧾㦟㦱㧋鮙鯼鮙鬽鬾魥鯴魁\udba2\udbd0\udb87\udb16\udb03\udb56\udbc4\udb7d\udbc8\udb92\udbce\udb86㢕㣧㢰㠡㠴㡡㣳㡊㣬㢵㣢㢾㢒㡉㠔㠻㣔㠱㡗㣊擗擹擳摟鑡鑏鑅铩팵팱팁포폖폼퍰폠퍘팟퍈팘팸평펹펌퍿펥펜팚펤폯퍜팜枩柳柏杣瓁璾瓃瑬瑼琞璡琉璨璏璗璝斈旷斊攥攵敓旊敗旡斀斮旔ᡏᠾᡐᣚᣬᢎ᠇ᢒ佑佈位俱俶侽伴侫㩪㩷㩜㫼㫍㪒㨲㪪㨶㩳㨠㩏㩫㪟㫼㫨㨪㫊㫆㩀㫥㪹㩍㨲㩝㩩㩴㫈㪔㪒㪽㫷㩱㨵㩳㫕㫤㪸㨁㪥㨬㩤㨞㩇㩂㪃㫶㫷㦃㦞㦎㤢㤠㥪㧫㥎㧸㦢㧾㦻㦅㤲㤢㤝㧂㥫㤟㦆㤋㥿㦩㧕㦲㦂㦀㤺饑餲饺駴駴馒餹馜餪饰饨餒\uf436\uf455\uf41d\uf493\uf493\uf4f1\uf44a\uf4fd\uf45d\uf404\uf465\uf42a\uf436\uf4e8\uf488\uf4c4솯쇚솆섃섊셐쇑셤쇒속쇢솑솮섘섀섿쇡서성솬섢섪솇쇷솋솨솦섍셐셾셻섙솰쇷쇅센섹셪쇗셧쇭솀쇋솎솁셻섁섯쇬섽섒솟섔셕솉쇮솠쇒솶섘섳셗셻셁";
      char[] var8 = "ވތހ\u07bcޔތޔޔޘޘޔޔތޘސސސތތޔތސތތތތސތބތޔސސބތސބބތޔސތވސވޔވބސބސތތ\u07bc\u07bc\u07b4\u07b4ޔޔޔޔޔހޔޔޔޘސސވޔޔސބޔޔތޘޔޔޘސ\u07bcސސބވވްސސޠޔސޔ\u07b4ޔސޔ\u07b8\u07bcސސސސޘޘޘޔޔޔސޔޘސ\u07bcޔސވވތސވ\u07b8ެވ߄ވވޘތ܈ޔ߄ސސސޔސވޘޘބޘސސޔޔެހސތߜ".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            lllIII = var9;
            lllIIl = new Object[var9.length];
            int var2 = 794682524;
            byte[] var0 = "²\u009e\u008bòÑX\u0083¹9\u000f3\u0086¢Ç\u008a\u0013\u008f6\u008ej\u00ad²Ñ³\u00937e\u0098&»§\u0011å+^%!±CTÌ\u0094ÈÜLÚ<\u0003\u0004êü\u001f¥\u0094½u,Æ-\u001f\u000eø&(\f»à·O¹H'\u009eN\u001bBÆ×¡EÝ\u000b\u008f\u0005Ý\u00adâ§m\u009c\u0001Öi\u001eÛzÜ\u001e\u0007\u008d\u0086¼Ø÷Ë´Q\u009aÑ\u0007NépÌ|\u0090K\u001eY6eì\u000fE\u0015\u0001j\u001bÃp\u0007\u00929ò!«\u0083\"\u0087~\u007fþJ5\u0000\u001cÃ\u0087Ï_ÎUv{\u0012\\c\u0092ÊUåm\u0089U%Mh\u0014GTAG\u008að\u0013Ó³\u0013?ä¦îPÊ\u0000}{\"êÙ¦\u0087\u0081Q\f6Z7\u0094Ó\u008e \u008b7\u0081ÆtO\u001e\u0014\u0084\u009aÎüAÎés\u0012ü\u0002\u009cf%ó,\t÷D\u001d÷f«¿D¿.¦\nÈYöX`kát\u0084rúÌo¡\u001e\u0089\u009fÖHqÞ\u001aÓm-\n\t\u0019\u0016\f*\u0019\u009dè\u0090¾Å]Ï\u0093\u00160®'ÎÌé\u00ad!\u008cªÅÂá:,<Eà\u001e\ruÛ[ÁðEú¾ªð,\u0001\n_×&\u0011·i²Æ7\u00927Ã«\u009e¼`ï\u0013\tG#¿\u007fQ\u00808>§LO\u0095\u0080È µ\u00046\u000b<7ïoOX\u0011\u009bq¹§¯\u0011\u001e B\u0089cn\u000bªÖ¨\u007fÂ\u0019!ª5y\u0019(\u0012\u0016|û\u0013\u0086\r\u0084ö'\u0089w\u0093.&ÈyÞ\u0089\u0081ÏbÀêÍý\u009cÃS=þA\u0002\u0014\f\u000e\u0015£Ü`ôï¿¢T\u0004\u00142!øÃyzØ\u001c9\u0082\u0006-²Å½\u0019½\u000eÎ\u008aà°UÔ§\u008c\u0013ä\u000f\u0001óh]û\u0084s£\u0001³4\u0016>£b\u0088\u0088Ùé§I\u000e \u0013Õ\u0081CXÓUü¸>¼ã\u008aûÒywr\u0012\u0087/\u0081Eìæ\u0017\u0093%cÆgÛ»ö+÷\u008d+}uø0,ºÌ´^Ï9\u0084í¬\u001e\u009a¸´\u000e ö\u0019t×\r\u0013hÿ\u008cþ\u007f\u009d\u0018P\u000f\u0088±\u0011PJ\u001e\u0087\u008eÆ\u0010Ý\u008dÑ<xÇE#%s\u008cx>h\u00ad\u009a3\u0093ÿvV\n\u0083\u0005Ù;ÕÎrc¤c\u001e¨\u007fx\u0003ñâ\b\u0005v\u0090\u0006Y!a\u0086\u000e|R!êTW\u0083â%,éH\u009b<¼ Ýd²\u001blÿ\u0000ÿ=>6ù\u0010ü\u008fSì\u0001ù9&ðcÃ<àûà\u0085\u001dêiÈeïO\"lõ;Ä\u008cc¯Ç¹JÝ\u0097@0þÍïÛYg\u007fk Ç\u0080´+¨E\u0017\u0003Y>Ç\u0084Ð\u0093O\u0086¢½qt\u000bÄJ\u0092\u0016ølúð\u0003k\u0095Aw\u0099ºbÂcw\u0001Am\u008cÙÈc$g\u0093\u0080n\u00ad\u0090\u001eòV\u0087\u007fôÏ<\u0089\u0083_Ü\u0097þ\u007f ".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            llIlll = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               llIlll[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            IllIII = x.lIlIII.l(llIIlII(481449214, 452476702));
            IlIlIl = x.lIlIII.l(llIIlII(481449215, -301790466));
            IlIIlI = x.lIlIII.l(llIIlII(481449208, 160856146));
            IlIIll = x.lIlIII.l(llIIlII(481449209, -1865192226));
            lllll = new lIllII[]{x.lIllII.I, x.lIllII.III, x.lIllII.l, x.lIllII.ll, x.lIllII.IIl};
            lIllI = new IIIlIlIII[]{IIIlIlIII.l, IIIlIlIII.II, IIIlIlIII.I, IIIlIlIII.lI};
            lIIIIl = Set.of(x.lIlIII.l(llIIlII(481449210, -1771486848)).lII(), x.lIlIII.l(llIIlII(481449211, 2128491159)).lII());
            Long[] var10000 = new Long[llIIIll(-1645453244, -1636324903)];
            var10000[0] = x.lIlIII.l(llIIlII(481449188, 85093285)).lII();
            var10000[1] = x.lIlIII.l(llIIlII(481449189, -1864938792)).lII();
            var10000[2] = x.lIlIII.l(llIIlII(481449190, -1810168999)).lII();
            var10000[3] = x.lIlIII.l(llIIlII(481449191, 1562277080)).lII();
            var10000[4] = x.lIlIII.l(llIIlII(481449184, 526019492)).lII();
            var10000[5] = x.lIlIII.l(llIIlII(481449185, -1196358462)).lII();
            var10000[llIIIll(-1645453243, -1136024841)] = x.lIlIII.l(llIIlII(481449186, -2107150417)).lII();
            var10000[llIIIll(-1645453222, -1106615178)] = x.lIlIII.l(llIIlII(481449187, -284395006)).lII();
            var10000[llIIIll(-1645453221, -49754904)] = x.lIlIII.l(llIIlII(481449196, -1092597742)).lII();
            var10000[llIIIll(-1645453224, 754950031)] = x.lIlIII.l(llIIlII(481449197, 874269328)).lII();
            var10000[llIIIll(-1645453223, 1952851338)] = x.lIlIII.l(llIIlII(481449198, -860595294)).lII();
            var10000[llIIIll(-1645453218, 1874463692)] = x.lIlIII.l(llIIlII(481449199, 109662642)).lII();
            var10000[llIIIll(-1645453217, 1864132200)] = x.lIlIII.l(llIIlII(481449192, -1616551595)).lII();
            var10000[llIIIll(-1645453220, -550664933)] = x.lIlIII.l(llIIlII(481449193, -420000675)).lII();
            var10000[llIIIll(-1645453219, -609263691)] = x.lIlIII.l(llIIlII(481449194, -374125012)).lII();
            var10000[llIIIll(-1645453230, 1856996172)] = x.lIlIII.l(llIIlII(481449195, -243911653)).lII();
            var10000[llIIIll(-1645453229, 873290792)] = x.lIlIII.l(llIIlII(481449172, -520333584)).lII();
            var10000[llIIIll(-1645453232, 2030425415)] = x.lIlIII.l(llIIlII(481449173, 1356802470)).lII();
            var10000[llIIIll(-1645453231, 1672923702)] = x.lIlIII.l(llIIlII(481449174, 128538480)).lII();
            var10000[llIIIll(-1645453226, -1031931831)] = x.lIlIII.l(llIIlII(481449175, 357453059)).lII();
            var10000[llIIIll(-1645453225, -105914903)] = x.lIlIII.l(llIIlII(481449168, -1598005500)).lII();
            var10000[llIIIll(-1645453228, -681735272)] = x.lIlIII.l(llIIlII(481449169, -1402785007)).lII();
            var10000[llIIIll(-1645453227, -1481576764)] = x.lIlIII.l(llIIlII(481449170, -1767112619)).lII();
            var10000[llIIIll(-1645453206, 1908507507)] = x.lIlIII.l(llIIlII(481449171, 386492587)).lII();
            var10000[llIIIll(-1645453205, -1958501052)] = x.lIlIII.l(llIIlII(481449180, -448239801)).lII();
            var10000[llIIIll(-1645453208, 831718291)] = x.lIlIII.l(llIIlII(481449181, 401296598)).lII();
            var10000[llIIIll(-1645453207, -850407718)] = x.lIlIII.l(llIIlII(481449182, 1474630796)).lII();
            var10000[llIIIll(-1645453202, -1297266834)] = x.lIlIII.l(llIIlII(481449183, 558917927)).lII();
            var10000[llIIIll(-1645453201, 2112768698)] = x.lIlIII.l(llIIlII(481449176, -1121094105)).lII();
            var10000[llIIIll(-1645453204, -993356111)] = x.lIlIII.l(llIIlII(481449177, -162959674)).lII();
            llIIIl = Set.of(var10000);
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private double llll(String var1, double var2, double var4) {
      double var6 = Math.max((double)48.0F, Math.min((double)92.0F, var4 * 0.34));
      double var8 = var2 + var4 * 0.42;
      return Math.min(var8, var2 + var4 - var6);
   }

   private double IIIII(double var1) {
      if (this.lIIlll.lIl == IIIlIlIII.l) {
         return var1;
      } else {
         double var3 = this.lIIlll.IIlI + this.lIIlll.IlIl * (double)0.5F;
         return var3 + (var1 - var3) / this.Illll();
      }
   }

   private static class_1011 IIIIl(BufferedImage var0) {
      if (var0 == null) {
         return null;
      } else {
         int var1 = var0.getWidth();
         int var2 = var0.getHeight();
         if (var1 >= llIIIll(-1645453203, -786215244) && var1 <= llIIIll(-1645453214, 1474043307) && var2 >= llIIIll(-1645453213, -1745031941) && var2 <= llIIIll(-1645453216, -169486917)) {
            class_1011 var3 = new class_1011(var1, var2, true);

            for(int var4 = 0; var4 < var2; ++var4) {
               for(int var5 = 0; var5 < var1; ++var5) {
                  var3.method_61941(var5, var4, var0.getRGB(var5, var4));
               }
            }

            return var3;
         } else {
            return null;
         }
      }
   }

   private double IIlII(IIIIIIIlI var1, llllllI<?> var2, String var3, double var4) {
      long var6 = IIlIIlI(var1.IIlIllI(), var2.lllI(), x.lIlIII.II(var3));
      double var8 = (Double)this.lllI.getOrDefault(var6, var4);
      double var10 = this.IlIllIl(var8, var4, (double)18.0F);
      this.lllI.put(var6, var10);
      return var10;
   }

   private <undefinedtype> IIlIl(double var1, double var3, double var5, double var7, String var9, Runnable var10) {
      double var11 = (double)this.IlIllI.IIl(var9) + (double)20.0F;
      if (var1 + var11 > var5 + var7 && var1 > var5) {
         var1 = var5;
         var3 += (double)28.0F;
      }

      this.lI = var3;
      this.IlIllI.IllI(var1, var3, var11, (double)22.0F, var9, false);
      this.lIIlIl.III(var1, var3, var11, (double)22.0F, (var1x, var2) -> {
         var10.run();
         return true;
      });
      return new Record(var1 + var11 + (double)6.0F) {
         private final double I;

         public double I() {
            return this.I;
         }

         private {
            this.I = var1;
         }
      };
   }

   private void IIllI() {
      this.IIIIl.lI().IIllII(this.lIIlll.II());
   }

   private boolean IIlll() {
      return this.lIIlIlI(llIIIll(-1645453215, 943822458)) || this.lIIlIlI(llIIIll(-1645453210, 27441734));
   }

   private double IlIII() {
      return (double)23.0F;
   }

   private String IlIIl(llllllI<?> var1, String var2, double var3) {
      if (var2 != null && !var2.isBlank()) {
         String var5 = var2.replace(x.lIlIII.Il(llIIlII(481449179, -1209514511)), x.lIlIII.Il(llIIlII(481449156, -1806996506)));
         var5 = var5.replace(x.lIlIII.Il(llIIlII(481449157, 1079267867)), x.lIlIII.Il(llIIlII(481449158, -83092113)));
         var5 = var5.replace(x.lIlIII.Il(llIIlII(481449159, 1150045339)), x.lIlIII.Il(llIIlII(481449152, -1367659962)));
         return var5;
      } else {
         return "";
      }
   }

   private boolean IlIlI(double var1, double var3) {
      if (this.lIIlll.lIl == IIIlIlIII.l) {
         return true;
      } else {
         double var5 = (double)208.0F;
         double var7 = (double)26.0F;
         double var9 = this.lIIlll.IIlI + (this.lIIlll.IlIl - var5) * (double)0.5F;
         double var11 = this.lIIlll.lIll + this.lIIlll.III + (double)6.0F;
         return llIlII(var1, var3, this.lIIlll.IIlI, this.lIIlll.lIll, this.lIIlll.IlIl, this.lIIlll.III) || llIlII(var1, var3, var9, var11, var5, var7);
      }
   }

   private void IlIll() {
      this.IIllI();
      this.IIIIl.lll();
   }

   public void method_29638(List<Path> var1) {
      if (var1 != null && !var1.isEmpty()) {
         if (this.lIIlll.lIl == IIIlIlIII.II) {
            try {
               if (Files.size((Path)var1.get(0)) > 524288L) {
                  this.IIIIll = x.lIlIII.Il(llIIlII(481449153, 212745796));
                  return;
               }

               String var2 = Files.readString((Path)var1.get(0));
               boolean var3 = this.IIIlll.IIl(var2, this.IIIIl.IIl());
               this.IIIIll = var3 ? x.lIlIII.Il(llIIlII(481449154, -1000206028)) : x.lIlIII.Il(llIIlII(481449155, -877582266));
               if (var3) {
                  this.IIIIl.lll();
               }
            } catch (Exception var4) {
               this.IIIIll = x.lIlIII.Il(llIIlII(481449164, -1505993843));
            }

         }
      }
   }

   private double IllII(IIIIIIIlI var1, llllllI<?> var2) {
      if (var2 instanceof IIIIllIII var5) {
         return (double)24.0F + (double)Math.max(1, var5.lIl().size()) * (double)21.0F;
      } else if (var2 instanceof lIIIlll var3) {
         int var4 = Math.max(1, var3.IIIl().size());
         if (this.llIlI != null && this.llIlI.III(var3, var3.IIIl().size())) {
            var4 = Math.max(var4, var3.IIIl().size() + 1);
         }

         return (double)31.0F + (double)var4 * (double)21.0F;
      } else {
         return !(var2 instanceof IIIllIIII) && !(var2 instanceof llllIlIl) && !(var2 instanceof IIllIlIII) ? (double)27.0F : (double)44.0F;
      }
   }

   private void IllIl(class_332 var1, double var2, double var4, double var6, double var8) {
      double var10 = Math.max((double)90.0F, Math.min(var6, (double)180.0F));
      double var12 = (double)22.0F;
      double var14 = var4 + (double)5.0F;
      boolean var16 = this.llIlI != null && this.llIlI.I;
      String var17 = var16 ? this.lIlIII : this.IllIll;
      if (var16) {
         int var18 = llIIIll(-1645453209, -345642633);
         int var19 = llIIIll(-1645453212, 1300936328);
         double var20 = Math.min((double)4.5F, var12 * (double)0.5F);
         IIIIIIllI.IllIll(this.lIIIIl(), var2, var14, var10, var12, var20, var19);
         IIIIIIllI.IllIll(this.lIIIIl(), var2 + (double)1.0F, var14 + (double)1.0F, var10 - (double)2.0F, var12 - (double)2.0F, Math.max((double)1.0F, var20 - (double)1.0F), var18);
         double var22 = (double)6.0F;
         double var24 = Math.max((double)10.0F, var10 - var22 * (double)2.0F);
         String var26 = var17 != null && !var17.isBlank() ? var17 : x.lIlIII.Il(llIIlII(481449165, 167603891));
         double var27 = (double)this.IlIllI.IIl(var26);
         double var29 = Math.max((double)0.0F, var27 - var24);
         double var31 = var2 + var22 - var29;
         double var33 = var14 + (var12 - IIIIIIllI.lllIII(this.field_22793)) * (double)0.5F;
         IIIIIIllI.IllIII(this.lIIIIl(), var2 + (double)3.0F, var14 + (double)1.0F, var2 + var10 - (double)3.0F, var14 + var12 - (double)1.0F);

         try {
            if (this.llIlII && !var26.isEmpty()) {
               int var35 = lllIIlI.III().getRGB();
               IIIIIIllI.IllIll(this.lIIIIl(), var31 - (double)1.0F, var33 - (double)1.0F, var27 + (double)2.0F, IIIIIIllI.lllIII(this.field_22793) + (double)2.0F, (double)2.0F, var35 & llIIIll(-1645453211, 1486347649) | llIIIll(-1645453190, -1277130544));
            }

            this.IlIllI.llIII(var26, var31, var33, -1);
         } finally {
            IIIIIIllI.lIII(this.lIIIIl());
         }

         double var60 = Math.min(var2 + var10 - (double)5.0F, var31 + var27);
         double var37 = var14 + (var12 - (double)12.0F) * (double)0.5F;
         this.lIlllI(var60, var37, (double)12.0F);
         this.II(var1);
      } else {
         this.IlIllI.IllI(var2, var14, var10, var12, var17 != null && !var17.isBlank() ? var17 : x.lIlIII.Il(llIIlII(481449166, 170874554)), false);
      }

      this.lIIlIl.III(var2, var14, var10, var12, (var1x, var2x) -> {
         this.IlIlllI(null.II(), this.IllIll);
         return true;
      });
      double var47 = var2 + var10 + (double)8.0F;
      double var52 = var4 + (double)5.0F;
      double var55 = (double)6.0F;
      double var56 = var2 + var6 - var47;
      double var57 = (var56 - var55 * (double)2.0F) / (double)3.0F;
      String var28 = x.lIlIII.Il(llIIlII(481449167, 140016392));
      String var58 = x.lIlIII.Il(llIIlII(481449160, 481708789));
      String var30 = x.lIlIII.Il(llIIlII(481449161, 490353699));
      Runnable var59 = this::lIlIlII;
      double var32 = (double)Math.max(this.IlIllI.IIl(var28), Math.max(this.IlIllI.IIl(var58), this.IlIllI.IIl(var30))) + (double)20.0F;
      if (var57 >= var32) {
         this.IllIll(var47, var52, var57, var28, () -> this.IlI(false));
         var47 += var57 + var55;
         this.IllIll(var47, var52, var57, var58, () -> this.IlI(true));
         var47 += var57 + var55;
         this.IllIll(var47, var52, var57, var30, var59);
         this.lI = var52;
      } else {
         var47 = this.IIlIl(var47, var52, var2, var6, var28, () -> this.IlI(false)).I();
         var52 = this.lI;
         var47 = this.IIlIl(var47, var52, var2, var6, var58, () -> this.IlI(true)).I();
         var52 = this.lI;
         this.IIlIl(var47, var52, var2, var6, var30, var59);
      }

      double var34 = this.lI + (double)30.0F;
      double var36 = this.IIIIIIl(2L, this.lIIlll.l);
      double var38 = var34 + (double)4.0F - var36;
      this.lIIlIl.ll(var2, var34, var6, var8 - (var34 - var4), null, (var1x, var3, var5, var7) -> {
         this.lIIlll.l = Math.max((double)0.0F, this.lIIlll.l - var7 * (double)28.0F);
         this.IIllI();
         return true;
      });
      IIIIIIllI.IllIII(this.lIIIIl(), var2, var34, var2 + var6, var4 + var8);
      List var40 = this.IIIlll.IllI();
      if (var40.isEmpty()) {
         this.IlIllI.llII(x.lIlIII.Il(llIIlII(481449162, 1589446207)), var2 + var6 * (double)0.5F, var4 + var8 * 0.48, this.IlIllI.IIIlII(), var6 - (double)20.0F);
      }

      for(String var42 : var40) {
         this.IlIllI.lIll(var2, var38, var6, false, false);
         this.IlIllI.llII(var42, var2 + Math.max((double)0.0F, var6 - (double)170.0F) * (double)0.5F, this.IIllllI(var38, (double)23.0F), this.IlIllI.IllIl(), Math.max((double)20.0F, var6 - (double)175.0F));
         this.IlIllI.IllI(var2 + var6 - (double)156.0F, var38 + (double)4.0F, (double)48.0F, (double)16.0F, x.lIlIII.Il(llIIlII(481449163, 1382776329)), false);
         this.IlIllI.IllI(var2 + var6 - (double)104.0F, var38 + (double)4.0F, (double)50.0F, (double)16.0F, x.lIlIII.Il(llIIlII(481449140, 476263858)), false);
         this.IlIllI.IllI(var2 + var6 - (double)50.0F, var38 + (double)4.0F, (double)48.0F, (double)16.0F, x.lIlIII.Il(llIIlII(481449141, -886175115)), false);
         this.lIIlIl.III(var2, var38, var6 - (double)162.0F, (double)23.0F, (var2x, var3) -> {
            this.IllIll = var42;
            this.llIlI = null;
            return true;
         });
         this.lIIlIl.III(var2 + var6 - (double)156.0F, var38 + (double)3.0F, (double)48.0F, (double)18.0F, (var2x, var3) -> {
            boolean var4 = this.IIIlll.IIlI(var42, this.IIIIl.IIl());
            String var10001;
            if (var4) {
               String var5 = x.lIlIII.Il(llIIlII(481449058, 1664102538));
               var10001 = var5 + var42;
            } else {
               var10001 = x.lIlIII.Il(llIIlII(481449059, 240589884));
            }

            this.IIIIll = var10001;
            if (var4) {
               this.IIIIl.lll();
            }

            return true;
         });
         this.lIIlIl.III(var2 + var6 - (double)104.0F, var38 + (double)3.0F, (double)50.0F, (double)18.0F, (var2x, var3) -> {
            boolean var4 = this.IIIlll.l(var42);
            String var10001;
            if (var4) {
               String var5 = x.lIlIII.Il(llIIlII(481449086, 638597092));
               var10001 = var5 + var42;
            } else {
               var10001 = x.lIlIII.Il(llIIlII(481449087, -987270335));
            }

            this.IIIIll = var10001;
            return true;
         });
         this.lIIlIl.III(var2 + var6 - (double)50.0F, var38 + (double)3.0F, (double)48.0F, (double)18.0F, (var2x, var3) -> {
            boolean var4 = this.IIIlll.Illl(var42);
            String var10001;
            if (var4) {
               String var5 = x.lIlIII.Il(llIIlII(481449101, 725952399));
               var10001 = var5 + var42;
            } else {
               var10001 = x.lIlIII.Il(llIIlII(481449102, 843519749));
            }

            this.IIIIll = var10001;
            return true;
         });
         var38 += (double)29.0F;
      }

      IIIIIIllI.lIII(this.lIIIIl());
   }

   private void IlllI(lIllII var1) {
      if (var1 != null) {
         if (var1 != this.lIIlll.II) {
            this.lIIlll.IlIl();
            this.lIlIll(var1);
         }

         this.lIIlll.II = var1;
      }
   }

   private double Illll() {
      return (0.82 + this.lIllIl(this.lIllll) * 0.18) * 0.95;
   }

   private class_11909 lIIII(class_11909 var1) {
      return this.lIIlll.lIl == IIIlIlIII.l ? var1 : new class_11909(this.IIIII(var1.comp_4798()), this.IIIIIll(var1.comp_4799()), var1.comp_4800());
   }

   private String lIIIl(Enum<?> var1) {
      if (var1 == null) {
         return "";
      } else {
         String var2 = var1.toString();
         if (IIllIll(var2) && var1.getDeclaringClass() != <undefinedtype>.class) {
            String[] var3 = var2.toLowerCase(Locale.ROOT).split(x.lIlIII.Il(llIIlII(481449142, -206817506)));
            StringBuilder var4 = new StringBuilder(var2.length());

            for(String var8 : var3) {
               if (!var8.isEmpty()) {
                  if (!var4.isEmpty()) {
                     var4.append((char)llIIIll(-1645453189, -393867244));
                  }

                  var4.append(Character.toUpperCase(var8.charAt(0))).append(var8.substring(1));
               }
            }

            return var4.toString();
         } else {
            return var2;
         }
      }
   }

   private double lIlII(IIIIIIIlI var1, double var2, double var4, double var6) {
      if (var1 == null) {
         return var4;
      } else {
         double var8 = (double)48.0F;
         boolean var10 = var1.IIIIIlI();
         this.IlIllI.II(var2, var4, var6, var8, false, false, (double)1.0F);
         double var11 = IIIIIIllI.I();
         double var13 = IIIIIIllI.Il();
         double var15 = var2 + var6 - (double)10.0F - var11;
         double var17 = var4 + (var8 - var13) * (double)0.5F;
         double var19 = Math.max((double)0.0F, var15 - var2 - (double)20.0F);
         this.IlIllI.IlII(var1.lllllI(), var2 + (double)10.0F, var4 + (double)8.0F, var19, this.IlIllI.IllIl());
         this.IlIllI.lIlIl(var1.llIllI(), var2 + (double)10.0F, var4 + (double)26.0F, var19, this.IlIllI.IIIlII(), 0.68);
         this.IlIllI.IIIlI(var15, var17, var10);
         this.lIIlIl.III(var2, var4, var6, var8, (var2x, var3) -> {
            this.IIlIIII(var1);
            this.IlIll();
            return true;
         });
         return var4 + var8 + (double)8.0F;
      }
   }

   private static class_1011 lIllI(byte[] var0) {
      if (var0 != null && var0.length >= llIIIll(-1645453192, 1007751135) && var0.length <= llIIIll(-1645453191, 871887018)) {
         class_1011 var1 = null;

         try {
            ByteArrayInputStream var2 = new ByteArrayInputStream(var0);

            try {
               var1 = class_1011.method_4309(var2);
            } catch (Throwable var8) {
               try {
                  var2.close();
               } catch (Throwable var7) {
                  var8.addSuppressed(var7);
               }

               throw var8;
            }

            var2.close();
         } catch (Throwable var9) {
            var1 = null;
         }

         if (var1 == null) {
            try {
               ByteArrayInputStream var13 = new ByteArrayInputStream(var0);

               try {
                  BufferedImage var3 = ImageIO.read(var13);
                  if (var3 != null) {
                     var1 = IIIIl(var3);
                  }
               } catch (Throwable var10) {
                  try {
                     var13.close();
                  } catch (Throwable var6) {
                     var10.addSuppressed(var6);
                  }

                  throw var10;
               }

               var13.close();
            } catch (Throwable var11) {
               var1 = null;
            }
         }

         if (var1 == null) {
            return null;
         } else {
            int var14 = var1.method_4307();
            int var15 = var1.method_4323();
            if (var14 >= llIIIll(-1645453186, -1398472600) && var14 <= llIIIll(-1645453185, 2085475629) && var15 >= llIIIll(-1645453188, 1539479052) && var15 <= llIIIll(-1645453187, -1339166012) && (long)var14 * (long)var15 <= 16777216L) {
               return var1;
            } else {
               try {
                  var1.close();
               } catch (Throwable var5) {
               }

               return null;
            }
         }
      } else {
         return null;
      }
   }

   private static long lIlll(llIlIIII var0) {
      if (var0 instanceof IIIIIIIlI var1) {
         return var1.IIlIllI();
      } else {
         return var0 == null ? 0L : x.lIlIII.II(var0.getClass().getSimpleName());
      }
   }

   private void llIIl(class_332 var1, int var2, int var3, float var4) {
      double var5 = this.lIIlll.IIlI;
      double var7 = this.lIIlll.lIll;
      double var9 = this.lIIlll.IlIl;
      double var11 = this.lIIlll.III;
      lIIIllll var13 = this.IIIIl.IIl().IIII();
      class_310 var14 = this.field_22787 != null ? this.field_22787 : class_310.method_1551();
      this.lIII(var14, var13);
      this.IlIllI.IIlI(var5, var7, var9, var11, true);
      IIIIIIllI.IllIll(this.lIIIIl(), var5 + (double)6.0F, var7 + (double)6.0F, var9 - (double)12.0F, var11 - (double)12.0F, (double)7.0F, llIIIll(-1645453198, -1098343931));
      if (this.IIIlIl) {
         double var15 = var13 == null ? (double)1.0F : var13.IIIlII();
         int var17 = (int)Math.round((double)255.0F * var15);
         if (var17 > 0) {
            double var18 = var5 + (double)6.0F;
            double var20 = var7 + (double)6.0F;
            double var22 = var9 - (double)12.0F;
            double var24 = var11 - (double)12.0F;
            double var26 = (double)7.0F;
            int var28 = var17 << llIIIll(-1645453197, -156470383) | llIIIll(-1645453200, 435240876);
            IIIIIIllI.lllll(this.lIIIIl(), IlIIll(), var18, var20, var22, var24, var26, var28);
         }
      }

      this.lIIlIl.III(var5, var7, var9, (double)31.0F, (var1x, var2x) -> {
         this.IIlll = null.Il;
         this.lIIlI = var1x.comp_4798() - this.lIIlll.IIlI;
         this.l = var1x.comp_4799() - this.lIIlll.lIll;
         return true;
      });
      this.Illl(var5, var7, var11);
      double var57 = IIIIIIllI.lllIII(this.field_22793);
      double var58 = 1.42;
      double var19 = 0.7;
      String var21 = x.lIlIII.Il(llIIlII(481449143, -1617951492));
      String var59 = this.IIIIl.II().l();
      double var23 = (double)this.IlIllI.IIl(var21) * var58;
      double var25 = (double)this.IlIllI.IIl(var59) * var19;
      double var27 = (double)2.0F;
      double var29 = var23 + var27 + var25;
      double var31 = var5 + ((double)112.0F - var29) * (double)0.5F;
      double var33 = var7 + (double)6.0F;
      double var35 = var7 + (double)46.0F;
      double var37 = var33 + (var35 - var33 - var57 * var58) * (double)0.5F;
      double var39 = var31 + var23 + var27;
      double var41 = var37 + var57 * var58 - var57 * var19;
      IIIIIIllI.IIIllI(this.lIIIIl());

      try {
         IIIIIIllI.IlII(this.lIIIIl(), var31, var37);
         IIIIIIllI.lllI(this.lIIIIl(), var58, var58);
         this.IlIllI.llIII(var21, (double)0.0F, (double)0.0F, this.IlIllI.IllIl());
      } finally {
         IIIIIIllI.lIIlIl(this.lIIIIl());
      }

      IIIIIIllI.IIIllI(this.lIIIIl());

      try {
         IIIIIIllI.IlII(this.lIIIIl(), var39, var41);
         IIIIIIllI.lllI(this.lIIIIl(), var19, var19);
         this.IlIllI.llIII(var59, (double)0.0F, (double)0.0F, llIIIll(-1645453199, 1670065567));
      } finally {
         IIIIIIllI.lIIlIl(this.lIIIIl());
      }

      double var43 = var5 + (double)112.0F + (double)14.0F;
      double var45 = var7 + (double)8.0F;
      double var47 = var9 - (double)112.0F - (double)28.0F;
      double var49 = var11 - (double)16.0F;
      if (this.lIIlll.lIl == IIIlIlIII.IIl) {
         this.IIlllll(var1, var43, var45, var47, var49);
      } else if (this.lIIlll.lIl == IIIlIlIII.ll) {
         this.IIllIII(var1, var43, var45, var47, var49);
      } else if (this.lIIlll.lIl == IIIlIlIII.II) {
         this.IllIl(var1, var43, var45, var47, var49);
      } else if (this.lIIlll.lIl == IIIlIlIII.I) {
         this.lllII(var43, var45, var47, var49);
      } else if (this.lIIlll.lIl == IIIlIlIII.lI) {
         this.IIIlIlI(var43, var45, var47, var49);
      }

      this.IIlIIl(var2, var3, var5, var7, var9, var11);
      IIIIIIllI.IIIII(var1);
   }

   private static boolean llIlI(llIlIIII var0) {
      IIIIIIIlI var1 = lllllI(var0);
      return var1 == null || var1.IIIIIlI() || !var1.IIlIlIl();
   }

   private void lllII(double var1, double var3, double var5, double var7) {
      double var9 = this.IIIIIIl(3L, this.lIIlll.I);
      double var11 = var3 + (double)8.0F - var9;
      this.lIIlIl.ll(var1, var3, var5, var7, null, (var1x, var3x, var5x, var7x) -> {
         this.lIIlll.I = Math.max((double)0.0F, this.lIIlll.I - var7x * (double)28.0F);
         this.IIllI();
         return true;
      });
      IIIIIIllI.IllIII(this.lIIIIl(), var1, var3, var1 + var5, var3 + var7);
      this.IlIlIIl(x.lIlIII.l(llIIlII(481449138, -1075676042)), IllllIlI.IIIlIl(this.IIIIl.lI().lIlIl()), var1, var11, var5, () -> this.IlIlIII(null.I(this.IIIIl)));
      var11 += (double)30.0F;

      for(IIIIIIIlI var14 : this.IIIIl.IIl().IIIIlII()) {
         this.IlIlIIl(var14.lllllI(), IllllIlI.IIIlIl(var14.IIIlIII()), var1, var11, var5, () -> this.IlIlIII(null.l(var14)));
         var11 += (double)27.0F;
      }

      llIIIlII var18 = this.IIIIl.IIl().lIIlIl();
      if (var18 != null) {
         for(<undefinedtype> var15 : var18.IIIIII()) {
            String var16 = var15.II() != null && !var15.II().isBlank() ? var15.II() : x.lIlIII.Il(llIIlII(481449139, -1060471514));
            this.IlIlIIl(x.lIlIII.l(llIIlII(481449148, -346140369)).IIII(x.lIlIII.III(var15.I())), var16, var1, var11, var5, () -> this.IlIlIII(null.IIl(var18, var15.Il())));
            var11 += (double)27.0F;
         }
      }

      IIIIIIllI.lIII(this.lIIIIl());
   }

   private void lllIl(class_332 var1, llIIIlII var2, double var3, double var5, double var7) {
      List var9 = var2.IIIIII();
      this.IlIllI.IIllI(x.lIlIII.Il(llIIlII(481449149, 767982940)), var3, var5 + (double)5.0F, Math.max((double)0.0F, var7 * 0.56), this.IlIllI.IIIlII());
      this.IlIllI.IIllI(var2.llIII(), var3 + var7 * 0.58, var5 + (double)5.0F, Math.max((double)0.0F, var7 * 0.42), this.IlIllI.IIIlII());
      double var10 = Math.max((double)48.0F, var7 - (double)31.0F);
      double var12 = (double)20.0F;
      double var14 = var5 + (double)25.0F;
      boolean var16 = this.llIlI != null && this.llIlI.II;
      String var17 = var16 ? this.lIlIII : this.IlIII;
      if (var16) {
         int var18 = llIIIll(-1645453194, 343794124);
         int var19 = llIIIll(-1645453193, 639023421);
         double var20 = Math.min((double)4.5F, var12 * (double)0.5F);
         IIIIIIllI.IllIll(this.lIIIIl(), var3, var14, var10, var12, var20, var19);
         IIIIIIllI.IllIll(this.lIIIIl(), var3 + (double)1.0F, var14 + (double)1.0F, var10 - (double)2.0F, var12 - (double)2.0F, Math.max((double)1.0F, var20 - (double)1.0F), var18);
         double var22 = (double)6.0F;
         double var24 = Math.max((double)10.0F, var10 - var22 * (double)2.0F);
         String var26 = var17 != null && !var17.isBlank() ? var17 : x.lIlIII.Il(llIIlII(481449150, 1767208933));
         double var27 = (double)this.IlIllI.IIl(var26);
         double var29 = Math.max((double)0.0F, var27 - var24);
         double var31 = var3 + var22 - var29;
         double var33 = var14 + (var12 - IIIIIIllI.lllIII(this.field_22793)) * (double)0.5F;
         IIIIIIllI.IllIII(this.lIIIIl(), var3 + (double)3.0F, var14 + (double)1.0F, var3 + var10 - (double)3.0F, var14 + var12 - (double)1.0F);

         try {
            if (this.llIlII && !var26.isEmpty()) {
               int var35 = lllIIlI.III().getRGB();
               IIIIIIllI.IllIll(this.lIIIIl(), var31 - (double)1.0F, var33 - (double)1.0F, var27 + (double)2.0F, IIIIIIllI.lllIII(this.field_22793) + (double)2.0F, (double)2.0F, var35 & llIIIll(-1645453196, -1061898376) | llIIIll(-1645453195, -1817244298));
            }

            this.IlIllI.llIII(var26, var31, var33, -1);
         } finally {
            IIIIIIllI.lIII(this.lIIIIl());
         }

         double var49 = Math.min(var3 + var10 - (double)5.0F, var31 + var27);
         double var37 = var14 + (var12 - (double)12.0F) * (double)0.5F;
         this.lIlllI(var49, var37, (double)12.0F);
         this.II(var1);
      } else {
         this.IlIllI.IllI(var3, var14, var10, var12, var17 != null && !var17.isBlank() ? var17 : x.lIlIII.Il(llIIlII(481449151, -925691719)), false);
      }

      this.IlIllI.IllI(var3 + var10 + (double)7.0F, var14, (double)24.0F, (double)20.0F, "", false);
      this.IlIIlll(var1, var3 + var10 + (double)19.0F, var14 + (double)10.0F, (double)7.0F, -1);
      this.lIIlIl.III(var3, var14, var10, var12, (var1x, var2x) -> {
         this.IlIlllI(null.ll(), this.IlIII);
         return true;
      });
      this.lIIlIl.III(var3 + var10 + (double)7.0F, var5 + (double)23.0F, (double)24.0F, (double)24.0F, (var2x, var3x) -> {
         try {
            var2.III(this.IlIII);
            String var10001 = x.lIlIII.Il(llIIlII(481449125, 2094208158));
            String var6 = this.IlIII;
            String var5 = var10001;
            this.IIIIll = var5 + var6;
            this.IlIll();
         } catch (Exception var7) {
            this.IIIIll = x.lIlIII.Il(llIIlII(481449126, 161053958));
         }

         return true;
      });
      double var44 = var5 + (double)53.0F;
      if (var9.isEmpty()) {
         this.IlIllI.IIllI(x.lIlIII.Il(llIIlII(481449144, 1225664662)), var3 + (double)6.0F, this.IIllllI(var44, (double)23.0F), Math.max((double)0.0F, var7 - (double)12.0F), this.IlIllI.IIIlII());
      } else {
         for(<undefinedtype> var21 : var9) {
            this.IlIllI.lIll(var3, var44, var7, false, false);
            double var46 = (double)38.0F;
            double var47 = (double)46.0F;
            double var48 = (double)24.0F;
            double var28 = Math.max((double)40.0F, var7 - var46 - var47 - var48 - (double)42.0F);
            IlIIlIll var10000 = this.IlIllI;
            String var10001 = var21.I();
            String var10002 = x.lIlIII.Il(llIIlII(481449145, 2145278237));
            int var41 = var21.l();
            String var40 = var10002;
            String var39 = var10001;
            var10000.IIllI(var39 + var40 + var41, var3 + (double)7.0F, this.IIllllI(var44, (double)23.0F), var28, this.IlIllI.IllIl());
            double var30 = var3 + var7 - var46 - var47 - var48 - (double)24.0F;
            double var32 = var3 + var7 - var47 - var48 - (double)17.0F;
            double var34 = var3 + var7 - var48 - (double)8.0F;
            this.IlIllI.IllI(var30, var44 + (double)4.0F, var46, (double)16.0F, x.lIlIII.Il(llIIlII(481449146, -1911785544)), false);
            this.IlIllI.IllI(var32, var44 + (double)4.0F, var47, (double)16.0F, var21.II() != null && !var21.II().isBlank() ? var21.II() : x.lIlIII.Il(llIIlII(481449147, -1883098586)), false);
            this.IlIllI.IllI(var34, var44 + (double)4.0F, var48, (double)16.0F, x.lIlIII.Il(llIIlII(481449124, -1102508211)), false);
            this.lIIlIl.III(var30, var44 + (double)2.0F, var46, (double)20.0F, (var3x, var4) -> {
               try {
                  var2.IIll(var21.Il());
                  this.IIIIll = "";
               } catch (Exception var8) {
                  String var10001 = x.lIlIII.Il(llIIlII(481449178, -2034743629));
                  String var7 = var8.getMessage();
                  String var6 = var10001;
                  this.IIIIll = var6 + var7;
               }

               return true;
            });
            this.lIIlIl.III(var32, var44 + (double)2.0F, var47, (double)20.0F, (var3x, var4) -> {
               this.IlIlIII(null.IIl(var2, var21.Il()));
               return true;
            });
            this.lIIlIl.III(var34, var44 + (double)2.0F, var48, (double)20.0F, (var3x, var4) -> {
               try {
                  var2.lIIlI(var21.Il());
                  String var10001 = x.lIlIII.Il(llIIlII(481449136, 1519547798));
                  String var7 = var21.I();
                  String var6 = var10001;
                  this.IIIIll = var6 + var7;
                  this.IlIll();
               } catch (Exception var8) {
                  this.IIIIll = x.lIlIII.Il(llIIlII(481449137, 1303928867));
               }

               return true;
            });
            var44 += (double)25.0F;
         }

      }
   }

   private boolean llllI(IIIIIIIlI var1) {
      return var1 != null && var1.IIIIIlI();
   }

   private boolean IIIIII(class_11908 var1) {
      int var2 = var1.comp_4795();
      int var3 = var1.comp_4797();
      return var2 == llIIIll(-1645453302, 1694102795) && ((var3 & llIIIll(-1645453301, -1469912656)) != 0 || this.llIIIlI());
   }

   public void method_25410(int var1, int var2) {
      super.method_25410(var1, var2);
      this.llIIIII();
      if (this.lIIlll.lIl != IIIlIlIII.l) {
         this.lIIlll.IIIl(this.Il.I(), this.Il.lI());
         this.IIllI();
      }

   }

   private static boolean IIIIIl(Object var0, String var1) {
      if (var0 != null && var1 != null && !var1.isEmpty()) {
         int var2 = var1.length();
         int[] var3 = new int[]{0};
         boolean[] var4 = new boolean[]{false};
         var0.Ill((var4x) -> {
            if (!var4[0]) {
               int var5 = Character.toLowerCase(var4x);
               if (var5 == var1.charAt(var3[0])) {
                  int var10002 = var3[0]++;
                  if (var3[0] == var2) {
                     var4[0] = true;
                  }
               } else {
                  var3[0] = var5 == var1.charAt(0) ? 1 : 0;
               }

            }
         });
         return var4[0];
      } else {
         return false;
      }
   }

   private double IIIIlI(int var1) {
      double var2 = this.IlIIllI();
      double var4 = (double)Math.max(0, var1) * this.IlIII();
      double var6 = Math.min(Math.max((double)184.0F, (double)this.Il.lI() - (double)44.0F), (double)360.0F);
      return Math.min(var6, Math.max(var2 + (double)7.0F, var2 + (double)7.0F + var4));
   }

   private String IIIIll(Object var1) {
      if (var1 == null) {
         return x.lIlIII.Il(llIIlII(481449127, -3735397));
      } else {
         String var10000 = llllIIll.lI(var1.ll(), var1.lI());
         String var10001 = x.lIlIII.Il(llIIlII(481449120, 1057644234));
         int var4 = var1.l();
         String var3 = var10001;
         String var2 = var10000;
         return var2 + var3 + var4;
      }
   }

   private double IIIlIl(IIIIIIIlI var1) {
      double var2 = (double)39.0F;
      if (this.llIIIl(var1)) {
         var2 += this.lIIIlll(var1) * this.IIIllIl(var1, this.lIIlll.lIII(var1), true);
      }

      return var2;
   }

   private double IIIllI(class_332 var1, IIIIIIIlI var2, double var3, double var5, double var7, double var9, double var11, double var13) {
      boolean var15 = this.llIIIl(var2);
      boolean var16 = var15 && this.lIIlll.lIII(var2);
      if (!var15) {
         this.lIIlll.III(var2);
         this.IlIlI.remove(var2.IIlIllI());
      }

      boolean var17 = var2.IIlIlIl();
      boolean var18 = !var17 || var2.IIIIIlI();
      this.lIIlll.IIll(var2);
      double var20 = var3 + var7 - (double)10.0F;
      double var22 = Math.max((double)0.0F, var20 - (var3 + (double)10.0F) - (double)10.0F);
      this.IlIllI.II(var3, var5, var7, (double)39.0F, false, false, var13);
      this.IlII(var2, var3 + (double)10.0F, var5 + (double)6.0F, var22, var18, var13);
      this.llII(var2, var3 + (double)10.0F, var5 + (double)22.0F, var22, var18, var13);
      boolean var24 = var5 + (double)39.0F > var9 && var5 < var11;
      if (var24) {
         this.lIIlIl.III(var3, var5, var7, (double)37.0F, (var3x, var4) -> {
            this.lIIlll.ll(var2);
            if (var3x.method_74245() == 1) {
               if (var15) {
                  this.lIIlll.lIIl(var2);
                  this.IIllI();
               }
            } else if (var2.IIlIlIl()) {
               this.IIlIIII(var2);
               this.IlIll();
            }

            return true;
         });
      }

      double var25 = (double)39.0F;
      double var27 = var15 ? this.IIIllIl(var2, var16, false) : (double)0.0F;
      if (var27 > 0.01) {
         double var29 = var5 + (double)39.0F;
         double var31 = this.lIIIlll(var2);
         double var33 = (double)2.0F + var31 * var27;
         int var35 = IlIIlIll.IIlIIl(new Color(llIIIll(-1645453304, -1195860578), llIIIll(-1645453303, -1097097962), llIIIll(-1645453298, 1512127093)), (int)((double)255.0F * var13));
         IIIIIIllI.IllIll(var1, var3, var29 - (double)2.0F, var7, var33, (double)5.0F, var35);
         if (var16 && var27 > 0.92) {
            double var36 = (double)27.0F;
            if (var29 + var36 > var9 && var29 < var11) {
               this.lI(var2, var3 + (double)7.0F, var29, var7 - (double)14.0F);
            }

            var29 += var36;
            if (var2.IIlIlIl()) {
               double var38 = (double)27.0F;
               if (var29 + var38 > var9 && var29 < var11) {
                  this.lIlI(var2, var3 + (double)7.0F, var29, var7 - (double)14.0F);
               }

               var29 += var38;
            }

            for(llllllI var39 : var2.IIIlll()) {
               double var40 = this.IllII(var2, var39);
               if (var29 + var40 > var9 && var29 < var11) {
                  var40 = this.llIlll(var1, var2, var39, var3 + (double)7.0F, var29, var7 - (double)14.0F);
               }

               var29 += var40;
            }

            if (var2 instanceof llIIIlII) {
               llIIIlII var44 = (llIIIlII)var2;
               double var45 = this.lIllII(var44);
               if (var29 + var45 > var9 && var29 < var11) {
                  this.lllIl(var1, var44, var3 + (double)7.0F, var29 + (double)2.0F, var7 - (double)14.0F);
               }

               double var10000 = var29 + var45;
            }
         }

         var25 += var31 * var27;
      }

      return var25;
   }

   private boolean IIIlll(llllllI<?> var1) {
      return var1 instanceof IIIllIIII && var1.lllI() == x.lIlIII.l(llIIlII(481449121, -1096666609)).lll();
   }

   private void IIlIIl(int var1, int var2, double var3, double var5, double var7, double var9) {
      double var11 = (double)100.0F;
      double var13 = (double)100.0F;
      double var15 = (double)8.0F;
      double var17 = var11 + var15 + var13;
      double var19 = (double)20.0F;
      double var21 = var3 + (var7 - var17) * (double)0.5F;
      double var23 = var5 + var9 + (double)6.0F;
      boolean var27 = this.lIIlll.lIl == IIIlIlIII.ll;
      boolean var28 = llIlII((double)var1, (double)var2, var21, var23, var11, var19);
      int var29 = var27 ? llIIIll(-1645453297, 525613745) : (var28 ? llIIIll(-1645453300, 1916634738) : llIIIll(-1645453299, -1841220976));
      int var30 = var27 ? llIIIll(-1645453310, -1051846086) : (var28 ? llIIIll(-1645453309, -1395727625) : llIIIll(-1645453312, 140878547));
      IIIIIIllI.llI(this.lIIIIl(), var21, var23, var11, var19, (double)6.0F, llIIIll(-1645453311, 1198186332), (double)6.0F, 4, 0.45);
      IIIIIIllI.lllII(this.lIIIIl(), var21, var23, var11, var19, (double)6.0F, var30);
      IIIIIIllI.IllIll(this.lIIIIl(), var21 + (double)1.0F, var23 + (double)1.0F, var11 - (double)2.0F, var19 - (double)2.0F, (double)5.0F, var29);
      double var31 = 0.72;
      <undefinedtype> var33 = x.lIlIII.l(llIIlII(481449122, 1204255735));
      double var34 = (double)this.IlIllI.lIII(var33) * var31;
      double var36 = var21 + (var11 - var34) * (double)0.5F;
      double var38 = var23 + (var19 - IIIIIIllI.lllIII(this.field_22793) * var31) * (double)0.5F;
      this.IlIllI.llIl(var33, var36, var38, -1, var31);
      this.lIIlIl.III(var21 - (double)2.0F, var23 - (double)2.0F, var11 + (double)4.0F, var19 + (double)4.0F, (var1x, var2x) -> {
         this.IIIIIlI();
         this.lIIlll.lIl = IIIlIlIII.ll;
         this.lll = false;
         this.llIlI = null;
         this.IIllI();
         return true;
      });
      double var40 = var21 + var11 + var15;
      boolean var42 = llIlII((double)var1, (double)var2, var40, var23, var13, var19);
      int var43 = var42 ? llIIIll(-1645453306, -234136570) : llIIIll(-1645453305, 1755820672);
      int var44 = var42 ? llIIIll(-1645453308, 1192302586) : llIIIll(-1645453307, 1556795145);
      int var45 = var42 ? llIIIll(-1645453286, -1957023593) : llIIIll(-1645453285, -1901918681);
      IIIIIIllI.llI(this.lIIIIl(), var40, var23, var13, var19, (double)6.0F, var43, (double)8.0F, 4, 0.65);
      IIIIIIllI.lllII(this.lIIIIl(), var40, var23, var13, var19, (double)6.0F, var44);
      IIIIIIllI.IllIll(this.lIIIIl(), var40 + (double)1.0F, var23 + (double)1.0F, var13 - (double)2.0F, var19 - (double)2.0F, (double)5.0F, var45);
      <undefinedtype> var46 = x.lIlIII.l(llIIlII(481449123, -350198248));
      double var47 = 0.74;
      double var49 = (double)this.IlIllI.lIII(var46) * var47;
      double var51 = var40 + (var13 - var49) * (double)0.5F;
      double var53 = var23 + (var19 - IIIIIIllI.lllIII(this.field_22793) * var47) * (double)0.5F;
      this.IlIllI.llIl(var46, var51, var53, -1, var47);
      this.lIIlIl.III(var40 - (double)2.0F, var23 - (double)2.0F, var13 + (double)4.0F, var19 + (double)4.0F, (var2x, var3x) -> {
         this.IlllIIl(var46, x.lIlIII.l(llIIlII(481449068, 1002965249)).lIlI(), () -> this.IIIIl.IIl().lIlIl().IIIllIl(true));
         return true;
      });
   }

   public boolean method_25406(class_11909 var1) {
      this.IIlll = null.l;
      this.lIIll = null;
      this.lII = null;
      this.IlI = null;
      this.lIll = null;
      return true;
   }

   private void IIllII(lIIIllll var1, IIllIlIII var2, String var3, double var4, double var6, double var8) {
      Color var10 = (Color)var2.III();
      this.IIIl(var3, "", var4, var6, Math.max((double)0.0F, var8 - (double)19.0F));
      IIIIIIllI.IllIll(this.lIIIIl(), var4 + var8 - (double)16.0F, var6 + (double)2.0F, (double)14.0F, (double)14.0F, (double)4.0F, IlIIlIll.IIlIIl(var10, var10.getAlpha()));
      double var11 = (double)Color.RGBtoHSB(var10.getRed(), var10.getGreen(), var10.getBlue(), (float[])null)[0];
      this.IlIllI.lIIlI(var4, var6 + (double)8.0F, var8, var11, "", 0.82);
      this.lIIlIl.III(var4, var6 + (double)12.0F, var8, (double)28.0F, (var7, var8x) -> {
         var1.lII(IIllIIlII.lIl);
         this.lIIlll.Illl = IIllIIlII.lIl;
         this.lIll = var2;
         this.IIllll = var4;
         this.IIll = var8;
         this.lIlIlll(var2, var7.comp_4798(), var7.method_74245() == 1);
         return true;
      });
   }

   private void IIllll(String var1, double var2, double var4, double var6, double var8, int var10) {
      double var11 = this.IIllllI(var4 + var8, (double)24.0F);
      this.IlIllI.llIII(this.IlIllI.IIlll(var1, Math.max((double)0.0F, var6 - (double)16.0F)), var2 + (double)8.0F, var11, var10);
   }

   private static double IlIIII(double var0, double var2, double var4) {
      double var6 = (var2 - var4) * (double)0.5F;
      double var8 = Math.max((double)0.0F, var2 - var4);
      if (Math.abs(var0 - var6) <= (double)5.0F) {
         return var6;
      } else if (Math.abs(var0) <= (double)4.0F) {
         return (double)0.0F;
      } else {
         return Math.abs(var0 - var8) <= (double)4.0F ? var8 : var0;
      }
   }

   private void IlIIIl(class_332 var1) {
      if (this.lIlIIll()) {
         <undefinedtype> var2 = this.IIIIl.II().ll();
         double var3 = this.IIIlllI();
         double var5 = (double)112.0F;
         double var7 = ((double)this.Il.I() - var3) * (double)0.5F;
         double var9 = ((double)this.Il.lI() - var5) * (double)0.5F;
         double var11 = var9 + var5 - (double)28.0F;
         double var13 = var7 + var3 * (double)0.5F - (double)92.0F;
         double var15 = var7 + var3 * (double)0.5F + (double)8.0F;
         this.IlIllI.IIlI(var7, var9, var3, var5, true);
         this.IlIllI.lIl(x.lIlIII.l(llIIlII(481449132, -1486454884)), var7 + var3 * (double)0.5F, var9 + (double)11.0F, this.IlIllI.IllIl(), var3 - (double)18.0F);
         IlIIlIll var10000 = this.IlIllI;
         String var10001 = x.lIlIII.Il(llIIlII(481449133, -522969978));
         String var18 = this.lIlIlI(var2.III());
         String var17 = var10001;
         var10000.llII(var17 + var18, var7 + var3 * (double)0.5F, var9 + (double)32.0F, this.IlIllI.IIIlII(), var3 - (double)18.0F);
         var10000 = this.IlIllI;
         var10001 = x.lIlIII.Il(llIIlII(481449134, -1761328763));
         String var19 = this.IIIIll(var2.lI());
         var18 = var10001;
         var10000.llII(var18 + var19, var7 + var3 * (double)0.5F, var9 + (double)46.0F, this.IlIllI.IIIlII(), var3 - (double)18.0F);
         this.IlIllI.llII(x.lIlIII.Il(llIIlII(481449135, 301481022)), var7 + var3 * (double)0.5F, var9 + (double)63.0F, -1, var3 - (double)18.0F);
         this.IlIllI.IllI(var13, var11, (double)84.0F, (double)20.0F, x.lIlIII.Il(llIIlII(481449128, -1644270425)), false);
         this.IlIllI.IllI(var15, var11, (double)84.0F, (double)20.0F, x.lIlIII.Il(llIIlII(481449129, -1469685578)), true);
         this.lIIlIl.III(var13, var11, (double)84.0F, (double)20.0F, (var1x, var2x) -> {
            this.lIIlII = true;
            return true;
         });
         this.lIIlIl.III(var15, var11, (double)84.0F, (double)20.0F, (var2x, var3x) -> {
            this.lllI(var2.lI());
            this.lIIlII = true;
            return true;
         });
      }
   }

   private static class_2960 IlIIll() {
      return class_2960.method_60655(x.lIlIII.Il(llIIlII(481449130, -1622916353)), x.lIlIII.Il(llIIlII(481449131, -56875100)));
   }

   private void IlIlII() {
      this.IllIlII();
      this.lll = false;
   }

   private void IllIll(double var1, double var3, double var5, String var7, Runnable var8) {
      this.IlIllI.IllI(var1, var3, var5, (double)22.0F, var7, false);
      this.lIIlIl.III(var1, var3, var5, (double)22.0F, (var1x, var2) -> {
         var8.run();
         return true;
      });
   }

   private int IlllII(int var1, double var2) {
      double var4 = Math.max((double)0.0F, Math.min((double)1.0F, var2));
      int var6 = (int)Math.round((double)(var1 >>> llIIIll(-1645453288, -765552747) & llIIIll(-1645453287, -174966011)) * var4);
      return var6 << llIIIll(-1645453282, -483279708) | var1 & llIIIll(-1645453281, 352466153);
   }

   private void IllllI(class_310 var1) {
      if (this.IIIlIl && var1 != null && var1.method_1531() != null) {
         try {
            var1.method_1531().method_4615(IlIIll());
         } catch (Throwable var3) {
         }

         this.IIIlIl = false;
      }

   }

   public boolean method_25421() {
      return false;
   }

   public lIIIllIl(lIllIIl var1, IIIlIlIII var2) {
      super(class_2561.method_43470(x.lIlIII.Il(llIIlII(481449108, -1590199866))));
      this.IIlll = null.l;
      this.lIlIII = "";
      this.IllIll = x.lIlIII.Il(llIIlII(481449109, 314784632));
      this.IlIII = x.lIlIII.Il(llIIlII(481449110, 1480285117));
      this.IIIIll = "";
      this.IIllIl = "";
      this.IlIlII = Double.NaN;
      this.llIIll = Double.NaN;
      this.ll = true;
      this.IIlIIl = 0.016666666666666666;
      this.IlIlI = new HashMap();
      this.lllI = new HashMap();
      this.lIIIll = new HashMap();
      this.IIIlII = new EnumMap(IIllIIlII.class);
      this.llllI = new EnumMap(IIllIIlII.class);
      this.IllIl = new HashMap();
      this.llII = Double.NaN;
      this.Illl = Double.NaN;
      this.llIII = Double.NaN;
      this.llIIl = Double.NaN;
      this.lIlllI = Double.NaN;
      this.IIlIlI = new HashMap();
      this.Il = new Record(1, 1, (double)1.0F, (double)1.0F) {
         private final int I;
         private final double l;
         private final int II;
         private final double Il;

         public int I() {
            return this.I;
         }

         double l(double var1) {
            return this.Il > (double)0.0F ? var1 / this.Il : var1;
         }

         public double II() {
            return this.Il;
         }

         private {
            this.I = var1;
            this.II = var2;
            this.l = var3;
            this.Il = var5;
         }

         double Il(double var1) {
            return this.l > (double)0.0F ? var1 / this.l : var1;
         }

         public int lI() {
            return this.II;
         }

         public double ll() {
            return this.l;
         }
      };
      this.IIIlI = null.II;
      this.IIlIll = null;
      this.llIlIl = null;
      this.lIlI = (double)1.0F;
      this.IlllII = (double)-1.0F;
      this.IIlllI = (double)-1.0F;
      this.IllllI = (double)-1.0F;
      this.llIIlI = (double)-1.0F;
      this.IIIII = (double)-1.0F;
      this.IlIll = (double)-1.0F;
      this.lIIllI = false;
      this.IIllII = (double)0.0F;
      this.IIIIl = var1;
      this.IIIlll = new IIllIIIIl(var1.lI());
      this.IIIIl.II().I();
      this.lIIlll.lIl = var2 == null ? IIIlIlIII.IIl : var2;
      this.lIIlll.llIl(var1.lI().IIll());
      this.lIlIll(this.lIIlll.II);
      class_310 var3 = class_310.method_1551();
      class_437 var4 = var3 != null ? var3.field_1755 : null;
      if (var4 instanceof lIIIllIl) {
         this.lIII = null;
      } else {
         this.lIII = var4;
      }

   }

   private void lIIIII(IIIIIIIlI var1, lIIIIl var2, boolean var3) {
      var2.Il(var3);
      this.IlIll();
   }

   private class_332 lIIIIl() {
      return this.IllIIl;
   }

   private static String lIIIlI(String var0) {
      if (var0 != null && !var0.isEmpty()) {
         int var1 = var0.length();

         int var2;
         for(var2 = var1 - 1; var2 >= 0 && Character.isWhitespace(var0.charAt(var2)); --var2) {
         }

         while(var2 >= 0 && !Character.isWhitespace(var0.charAt(var2))) {
            --var2;
         }

         return var0.substring(0, Math.max(0, var2 + 1));
      } else {
         return "";
      }
   }

   private double lIIIll(double var1) {
      double var3 = (double)1.25F;
      double var5 = var3 + (double)1.0F;
      double var7 = var1 - (double)1.0F;
      return (double)1.0F + var5 * var7 * var7 * var7 + var3 * var7 * var7;
   }

   private void lIIlIl(double var1, double var3) {
      if (this.lIIll != null) {
         double var5 = var1 - this.llIIII;
         double var7 = var3 - this.lIllII;
         var5 = IlIIII(var5, (double)this.Il.I(), this.lIIll.llll());
         var7 = IlIIII(var7, (double)this.Il.lI(), this.lIIll.lIIl());
         this.lIIll.lIlI(var5, var7);
         this.IlIll();
      }
   }

   private double lIIlll(IIIIIIIlI var1) {
      if (var1 == null) {
         return (double)0.0F;
      } else {
         double var2 = (double)0.0F;

         for(llllllI var5 : var1.IIIlll()) {
            var2 += this.IllII(var1, var5);
         }

         return (double)34.0F + var2 + (var1 instanceof IIIll ? (double)27.0F : (double)0.0F);
      }
   }

   private void lIlIII() {
      String var1 = this.field_22787 == null ? "" : this.field_22787.field_1774.method_1460();
      boolean var2 = this.IIIlll.IIl(var1, this.IIIIl.IIl());
      this.IIIIll = var2 ? x.lIlIII.Il(llIIlII(481449111, -1519159362)) : x.lIlIII.Il(llIIlII(481449104, 792024105));
      if (var2) {
         this.IIIIl.lll();
      }

   }

   private boolean lIlIIl(double var1, double var3) {
      return !Double.isNaN(this.IlIlII) && var1 >= this.IlIlII && var3 >= this.llIIll && var1 <= this.IlIlII + this.IlIIl && var3 <= this.llIIll + this.lIIII;
   }

   private String lIlIlI(Object var1) {
      if (var1 == null) {
         return x.lIlIII.Il(llIIlII(481449105, 1640780038));
      } else {
         String var10000 = llllIIll.lI(var1.I(), var1.l());
         String var10001 = x.lIlIII.Il(llIIlII(481449106, -1340719844));
         int var4 = var1.II();
         String var3 = var10001;
         String var2 = var10000;
         return var2 + var3 + var4;
      }
   }

   private void lIlIll(lIllII var1) {
      if (var1 != null) {
         this.lIIlll.l(var1, (double)0.0F);
         this.lIIIll.put(this.lIlIIlI(var1), (double)0.0F);
      }
   }

   private double lIllII(llIIIlII var1) {
      return (double)56.0F + (double)Math.max(1, var1.IIIIII().size()) * (double)25.0F;
   }

   private double lIllIl(double var1) {
      double var3 = Math.max((double)0.0F, Math.min((double)1.0F, var1));
      double var5 = (double)1.0F - var3;
      return (double)1.0F - var5 * var5 * var5;
   }

   private void lIlllI(double var1, double var3, double var5) {
      this.lIIllI = true;
      this.llIIlI = var1;
      this.IIIII = var3;
      this.IlIll = var5;
   }

   public boolean method_25403(class_11909 var1, double var2, double var4) {
      this.llIIIII();
      class_11909 var6 = this.lIIII(this.IIII(var1));
      double var7 = var6.comp_4798();
      double var9 = var6.comp_4799();
      if (this.IIlll == null.Il) {
         this.lIIlll.IIlI = var7 - this.lIIlI;
         this.lIIlll.lIll = var9 - this.l;
         this.lIIlll.Il(this.Il.I(), this.Il.lI());
         this.IIllI();
         return true;
      } else if (this.IIlll == null.II) {
         this.IIl(var7, var9);
         return true;
      } else if (this.lIIll != null) {
         this.lIIlIl(var7, var9);
         return true;
      } else if (this.lII != null) {
         this.IlIIIll(this.lII, var7);
         return true;
      } else if (this.IlI != null) {
         this.IllllIl(this.IlI, var7, this.IlIlll);
         return true;
      } else if (this.lIll != null) {
         this.lIlIlll(this.lIll, var7, var6.method_74245() == 1);
         return true;
      } else {
         return true;
      }
   }

   private static boolean llIIII(String var0) {
      if (var0 == null) {
         return false;
      } else {
         String var1 = var0.trim();
         if (!var1.isEmpty() && var1.length() <= llIIIll(-1645453284, 846801973)) {
            if (!var1.startsWith(x.lIlIII.Il(llIIlII(481449107, -459858492))) && !var1.startsWith(x.lIlIII.Il(llIIlII(481449116, 646908458)))) {
               try {
                  return IllIII.lIlI().equalsIgnoreCase(URI.create(var1).getScheme());
               } catch (IllegalArgumentException var3) {
                  return false;
               }
            } else {
               return true;
            }
         } else {
            return false;
         }
      }
   }

   private boolean llIIIl(IIIIIIIlI var1) {
      return var1 != null;
   }

   public boolean method_25400(class_11905 var1) {
      if (this.lIlIIll()) {
         return true;
      } else if (this.llIlI != null) {
         if (!var1.method_74227()) {
            return false;
         } else {
            if (this.llIlI.I) {
               if (this.llIlII) {
                  this.lIlIII = var1.method_74226();
                  this.llIlII = false;
                  return true;
               }

               if (this.lIlIII.length() >= llIIIll(-1645453283, -1232629847)) {
                  return true;
               }
            }

            if (this.llIlII) {
               this.lIlIII = var1.method_74226();
               this.llIlII = false;
            } else {
               String var6 = this.lIlIII;
               String var5 = var1.method_74226();
               String var2 = var6;
               this.lIlIII = var2 + var5;
            }

            return true;
         }
      } else if (this.lll) {
         if (!var1.method_74227()) {
            return false;
         } else {
            if (this.llIlII) {
               this.IIllIl = var1.method_74226();
               this.llIlII = false;
            } else {
               String var10001 = this.IIllIl;
               String var4 = var1.method_74226();
               String var3 = var10001;
               this.IIllIl = var3 + var4;
            }

            this.lIIlll.l(this.lIIlll.II, (double)0.0F);
            return true;
         }
      } else {
         return false;
      }
   }

   private static boolean llIlII(double var0, double var2, double var4, double var6, double var8, double var10) {
      return var0 >= var4 && var0 <= var4 + var8 && var2 >= var6 && var2 <= var6 + var10;
   }

   private String llIllI(Object var1) {
      if (this.IllllII(var1.I())) {
         return var1.I().trim();
      } else {
         return this.IllllII(var1.Il()) ? var1.Il().trim() : "";
      }
   }

   private double llIlll(class_332 var1, IIIIIIIlI var2, llllllI<?> var3, double var4, double var6, double var8) {
      String var10 = var3.Illl();
      String var11 = this.IlIIl(var3, var10, var8);
      boolean var12 = var3 instanceof lIIIIl;
      boolean var13 = var3 instanceof IIIllIIII || var3 instanceof llllIlIl || var3 instanceof IIllIlIII;
      double var14 = var12 ? var4 + var8 - (double)4.0F - IIIIIIllI.I() : this.llll(var11, var4, var8);
      double var16 = Math.max((double)0.0F, var4 + var8 - var14);
      double var18 = var6 + Math.max((double)0.0F, ((double)24.0F - IIIIIIllI.lllIII(this.field_22793) * 0.82) * (double)0.5F);
      if (!var13) {
         this.IlIllI.IIIllI(var11, var4, var18, Math.max((double)0.0F, var14 - var4 - (double)8.0F), -1, 0.82);
      }

      if (var3 instanceof lIIIIl var87) {
         double var96 = var6 + ((double)24.0F - IIIIIIllI.Il()) * (double)0.5F;
         this.IlIllI.IIIlI(var14, var96, (Boolean)var87.III());
         this.lIIlIl.III(var4, var6, var8, (double)24.0F, (var3x, var4x) -> {
            this.lIIIII(var2, var87, !(Boolean)var87.III());
            return true;
         });
         return (double)27.0F;
      } else if (var3 instanceof IIIllIIII var86) {
         String var131 = llI((Double)var86.III());
         String var130 = var86.lll().lIlI();
         String var62 = var131;
         String var94 = var62 + var130;
         this.IIIl(var11, var94, var4, var6, var8);
         double var102 = ((Double)var86.III() - var86.lIl()) / Math.max(1.0E-4, var86.ll() - var86.lIl());
         this.IlIllI.l(var4, var6 + (double)8.0F, var8, this.lIIl(var2, var3, var102), "", !this.IIIlll(var3), 0.82);
         this.lIIlIl.III(var4, var6 + (double)12.0F, var8, (double)28.0F, (var6x, var7) -> {
            this.lII = var86;
            this.IIllll = var4;
            this.IIll = var8;
            this.IlIIIll(var86, var6x.comp_4798());
            return true;
         });
         return (double)44.0F;
      } else if (var3 instanceof llllIlIl var85) {
         String var10000 = llI(var85.IlII());
         String var10001 = x.lIlIII.Il(llIIlII(481449117, 1998332686));
         String var10002 = llI(var85.IlI());
         String var66 = var85.lll().lIlI();
         String var65 = var10002;
         String var64 = var10001;
         String var63 = var10000;
         String var93 = var63 + var64 + var65 + var66;
         this.IIIl(var11, var93, var4, var6, var8);
         double var101 = (var85.IlII() - var85.ll()) / Math.max(1.0E-4, var85.lIl() - var85.ll());
         double var104 = (var85.IlI() - var85.ll()) / Math.max(1.0E-4, var85.lIl() - var85.ll());
         this.IlIllI.lIIIl(var4, var6 + (double)8.0F, var8, this.IIlII(var2, var3, x.lIlIII.Il(llIIlII(481449118, 758594273)), var101), this.IIlII(var2, var3, x.lIlIII.Il(llIIlII(481449119, 2009691429)), var104), "", 0.82);
         this.lIIlIl.III(var4, var6 + (double)12.0F, var8, (double)28.0F, (var10x, var11x) -> {
            this.IlI = var85;
            this.IlIlll = Math.abs(var10x.comp_4798() - (var4 + var8 * var101)) < Math.abs(var10x.comp_4798() - (var4 + var8 * var104));
            this.IIllll = var4;
            this.IIll = var8;
            this.IllllIl(var85, var10x.comp_4798(), this.IlIlll);
            return true;
         });
         return (double)44.0F;
      } else if (var3 instanceof IlIIIlIlI var84) {
         String var92 = this.lIIIl((Enum)var84.III());
         this.lIlllll(var3, var14, var6 + (double)2.0F, var16, var92);
         this.lIIlIl.III(var14, var6, var16, (double)24.0F, (var2x, var3x) -> {
            var84.lII();
            this.IlIll();
            return true;
         });
         return (double)27.0F;
      } else if (var3 instanceof IIIIllIII var83) {
         double var91 = var6 + (double)23.0F;

         for(<undefinedtype> var97 : var83.lIl()) {
            boolean var98 = var83.ll(var97);
            this.IlIllI.IlIl(var4, var91, var8, (double)18.0F, var97.l(), var98, 0.82);
            this.lIIlIl.III(var4, var91, var8, (double)18.0F, (var3x, var4x) -> {
               var83.IIl(var97);
               this.IlIll();
               return true;
            });
            var91 += (double)21.0F;
         }

         return (double)24.0F + (double)Math.max(1, var83.lIl().size()) * (double)21.0F;
      } else if (var3 instanceof IIllIlIII var82) {
         Color var90 = (Color)var82.III();
         this.IIIl(var11, "", var4, var6, Math.max((double)0.0F, var8 - (double)19.0F));
         IIIIIIllI.IllIll(var1, var4 + var8 - (double)16.0F, var6 + (double)2.0F, (double)14.0F, (double)14.0F, (double)4.0F, IlIIlIll.IIlIIl(var90, var90.getAlpha()));
         double var100 = (double)Color.RGBtoHSB(var90.getRed(), var90.getGreen(), var90.getBlue(), (float[])null)[0];
         this.IlIllI.lIIlI(var4, var6 + (double)8.0F, var8, this.lIIl(var2, var3, var100), "", 0.82);
         this.lIIlIl.III(var4, var6 + (double)12.0F, var8, (double)28.0F, (var6x, var7) -> {
            this.lIll = var82;
            this.IIllll = var4;
            this.IIll = var8;
            this.lIlIlll(var82, var6x.comp_4798(), var6x.method_74245() == 1);
            return true;
         });
         return (double)44.0F;
      } else if (var3 instanceof lllIIlIl var81) {
         String var89 = IllllIlI.IIIlIl((class_3675.class_306)var81.III());
         this.IlIllI.IlIII(var14, var6 + (double)2.0F, var16, (double)20.0F, var89, false, 0.82);
         this.lIIlIl.III(var14, var6, var16, (double)24.0F, (var2x, var3x) -> {
            this.IlIlIII(null.II(var81));
            return true;
         });
         return (double)27.0F;
      } else if (var3 instanceof lIlIlllI var80) {
         boolean var88 = this.llIlI != null && this.llIlI.l == var80;
         double var22 = var6 + (double)2.0F;
         double var24 = (double)20.0F;
         if (var88) {
            String var26 = this.lIlIII;
            int var103 = llIIIll(-1645453294, 2053428871);
            int var28 = llIIIll(-1645453293, 367417004);
            double var105 = Math.min((double)4.5F, var24 * (double)0.5F);
            IIIIIIllI.IllIll(this.lIIIIl(), var14, var22, var16, var24, var105, var28);
            IIIIIIllI.IllIll(this.lIIIIl(), var14 + (double)1.0F, var22 + (double)1.0F, var16 - (double)2.0F, var24 - (double)2.0F, Math.max((double)1.0F, var105 - (double)1.0F), var103);
            double var107 = (double)6.0F;
            double var108 = Math.max((double)10.0F, var16 - var107 * (double)2.0F);
            double var111 = 0.82;
            String var112 = var26 != null && !var26.isBlank() ? var26 : IlIlIl.lIlI();
            double var114 = (double)this.IlIllI.IIl(var112) * var111;
            double var116 = Math.max((double)0.0F, var114 - var108);
            double var118 = var14 + var107 - var116;
            double var120 = var22 + (var24 - IIIIIIllI.lllIII(this.field_22793) * var111) * (double)0.5F;
            IIIIIIllI.IllIII(this.lIIIIl(), var14 + (double)3.0F, var22 + (double)1.0F, var14 + var16 - (double)3.0F, var22 + var24 - (double)1.0F);

            try {
               if (this.llIlII && !var112.isEmpty()) {
                  int var121 = lllIIlI.III().getRGB();
                  IIIIIIllI.IllIll(this.lIIIIl(), var118 - (double)1.0F, var120 - (double)1.0F, var114 + (double)2.0F, IIIIIIllI.lllIII(this.field_22793) * var111 + (double)2.0F, (double)2.0F, var121 & llIIIll(-1645453296, 199873634) | llIIIll(-1645453295, 739362308));
               }

               this.IlIllI.Il(var112, var118, var120, -1, var111);
            } finally {
               IIIIIIllI.lIII(this.lIIIIl());
            }

            double var122 = Math.min(var14 + var16 - (double)5.0F, var118 + var114);
            double var123 = var22 + (var24 - (double)12.0F) * (double)0.5F;
            this.lIlllI(var122, var123, (double)12.0F);
            this.II(var1);
         } else {
            <undefinedtype> var99 = var80.lII();
            this.IlIllI.IlIl(var14, var22, var16, var24, var99.lIIl() ? IlIlIl : var99, false, 0.82);
         }

         this.lIIlIl.III(var14, var6, var16, (double)24.0F, (var2x, var3x) -> {
            this.IlIlllI(null.lI(var80), var80.IlI());
            return true;
         });
         return (double)27.0F;
      } else if (!(var3 instanceof lIIIlll var20)) {
         if (var3 instanceof IlIIIIllI var79) {
            this.IlIllI.IlIII(var14, var6 + (double)2.0F, var16, (double)20.0F, var79.IIl(), false, 0.82);
            this.lIIlIl.III(var14, var6, var16, (double)24.0F, (var2x, var3x) -> {
               var79.l();
               this.IlIll();
               return true;
            });
            return (double)27.0F;
         } else {
            this.IlIllI.IIIllI(String.valueOf(var3.III()), var14, var6 + (double)5.0F, var16, -1, 0.82);
            return (double)27.0F;
         }
      } else {
         double var21 = var4;
         double var23 = var8;
         double var25 = (double)24.0F;
         this.IlIllI.IlIII(var4 + var8 - var25, var6 + (double)2.0F, var25, (double)20.0F, "", false, 0.82);
         this.IlIIlll(var1, var4 + var8 - var25 * (double)0.5F, var6 + (double)12.0F, (double)7.0F, -1);
         this.lIIlIl.III(var4 + var8 - var25, var6, var25, (double)24.0F, (var2x, var3x) -> {
            this.IlIlllI(null.I(var20, var20.lII().size()), "");
            return true;
         });
         double var27 = var6 + (double)27.0F;
         List var29 = var20.lII();
         boolean var30 = this.llIlI != null && this.llIlI.III(var20, var29.size());
         if (var29.isEmpty() && !var30) {
            this.IlIllI.lIlIl(IlIIlI, var4, var27 + (double)4.0F, var8, -1, 0.82);
            var27 += (double)21.0F;
         }

         for(int var31 = 0; var31 < var29.size(); ++var31) {
            <undefinedtype> var33 = (<undefinedtype>)var29.get(var31);
            boolean var34 = this.llIlI != null && this.llIlI.III(var20, var31);
            double var35 = Math.max((double)28.0F, var23 - (double)24.0F - (double)5.0F);
            if (var34) {
               String var37 = this.lIlIII;
               int var38 = llIIIll(-1645453290, 786805350);
               int var39 = llIIIll(-1645453289, -1688227301);
               double var40 = Math.min((double)4.5F, (double)9.0F);
               IIIIIIllI.IllIll(this.lIIIIl(), var21, var27, var35, (double)18.0F, var40, var39);
               IIIIIIllI.IllIll(this.lIIIIl(), var21 + (double)1.0F, var27 + (double)1.0F, var35 - (double)2.0F, (double)16.0F, Math.max((double)1.0F, var40 - (double)1.0F), var38);
               double var42 = (double)6.0F;
               double var44 = Math.max((double)10.0F, var35 - var42 * (double)2.0F);
               double var46 = 0.82;
               String var48 = var37 != null && !var37.isBlank() ? var37 : IlIlIl.lIlI();
               double var49 = (double)this.IlIllI.IIl(var48) * var46;
               double var51 = Math.max((double)0.0F, var49 - var44);
               double var53 = var21 + var42 - var51;
               double var55 = var27 + ((double)18.0F - IIIIIIllI.lllIII(this.field_22793) * var46) * (double)0.5F;
               IIIIIIllI.IllIII(this.lIIIIl(), var21 + (double)3.0F, var27 + (double)1.0F, var21 + var35 - (double)3.0F, var27 + (double)17.0F);

               try {
                  if (this.llIlII && !var48.isEmpty()) {
                     int var57 = lllIIlI.III().getRGB();
                     IIIIIIllI.IllIll(this.lIIIIl(), var53 - (double)1.0F, var55 - (double)1.0F, var49 + (double)2.0F, IIIIIIllI.lllIII(this.field_22793) * var46 + (double)2.0F, (double)2.0F, var57 & llIIIll(-1645453292, -1418735294) | llIIIll(-1645453291, 1269345435));
                  }

                  this.IlIllI.Il(var48, var53, var55, -1, var46);
               } finally {
                  IIIIIIllI.lIII(this.lIIIIl());
               }

               double var129 = Math.min(var21 + var35 - (double)5.0F, var53 + var49);
               double var59 = var27 + (double)3.0F;
               this.lIlllI(var129, var59, (double)12.0F);
               this.II(var1);
            } else {
               this.IlIllI.IlIl(var21, var27, var35, (double)18.0F, var33.lIIl() ? IlIlIl : var33, false, 0.82);
            }

            this.IlIllI.IlIl(var21 + var35 + (double)5.0F, var27, (double)24.0F, (double)18.0F, IlIIll, false, 0.82);
            this.lIIlIl.III(var21, var27, var35, (double)18.0F, (var4x, var5) -> {
               this.IlIlllI(null.I(var20, var31), var33.lIlI());
               return true;
            });
            this.lIIlIl.III(var21 + var35 + (double)5.0F, var27, (double)24.0F, (double)18.0F, (var3x, var4x) -> {
               this.llIlI = null;
               var20.IllI(var31);
               this.IlIll();
               return true;
            });
            var27 += (double)21.0F;
         }

         if (var30) {
            String var106 = this.lIlIII;
            double var32 = Math.max((double)28.0F, var23 - (double)24.0F - (double)5.0F);
            int var109 = llIIIll(-1645453270, 1542931171);
            int var110 = llIIIll(-1645453269, -872789741);
            double var36 = Math.min((double)4.5F, (double)9.0F);
            IIIIIIllI.IllIll(this.lIIIIl(), var21, var27, var32, (double)18.0F, var36, var110);
            IIIIIIllI.IllIll(this.lIIIIl(), var21 + (double)1.0F, var27 + (double)1.0F, var32 - (double)2.0F, (double)16.0F, Math.max((double)1.0F, var36 - (double)1.0F), var109);
            double var113 = (double)6.0F;
            double var115 = Math.max((double)10.0F, var32 - var113 * (double)2.0F);
            double var117 = 0.82;
            String var119 = var106.isBlank() ? x.lIlIII.Il(llIIlII(481449112, -194162780)) : var106;
            double var45 = (double)this.IlIllI.IIl(var119) * var117;
            double var47 = Math.max((double)0.0F, var45 - var115);
            double var124 = var21 + var113 - var47;
            double var125 = var27 + ((double)18.0F - IIIIIIllI.lllIII(this.field_22793) * var117) * (double)0.5F;
            IIIIIIllI.IllIII(this.lIIIIl(), var21 + (double)3.0F, var27 + (double)1.0F, var21 + var32 - (double)3.0F, var27 + (double)17.0F);

            try {
               if (this.llIlII && !var119.isEmpty()) {
                  int var126 = lllIIlI.III().getRGB();
                  IIIIIIllI.IllIll(this.lIIIIl(), var124 - (double)1.0F, var125 - (double)1.0F, var45 + (double)2.0F, IIIIIIllI.lllIII(this.field_22793) * var117 + (double)2.0F, (double)2.0F, var126 & llIIIll(-1645453272, -1782117160) | llIIIll(-1645453271, 479677644));
               }

               this.IlIllI.Il(var119, var124, var125, -1, var117);
            } finally {
               IIIIIIllI.lIII(this.lIIIIl());
            }

            double var127 = Math.min(var21 + var32 - (double)5.0F, var124 + var45);
            double var128 = var27 + (double)3.0F;
            this.lIlllI(var127, var128, (double)12.0F);
            this.II(var1);
            this.IlIllI.IlIl(var21 + var32 + (double)5.0F, var27, (double)24.0F, (double)18.0F, IlIIll, false, 0.82);
            this.lIIlIl.III(var21, var27, var32, (double)18.0F, (var3x, var4x) -> {
               this.IlIlllI(null.I(var20, var29.size()), this.lIlIII);
               return true;
            });
            this.lIIlIl.III(var21 + var32 + (double)5.0F, var27, (double)24.0F, (double)18.0F, (var1x, var2x) -> {
               this.llIlI = null;
               return true;
            });
         }

         return this.IllII(var2, var20);
      }
   }

   private void lllIII(int var1) {
      int var2 = 0;

      for(int var3 = 0; var3 < lllll.length; ++var3) {
         if (lllll[var3] == this.lIIlll.II) {
            var2 = var3;
            break;
         }
      }

      int var4 = (var2 + var1 + lllll.length) % lllll.length;
      this.IlllI(lllll[var4]);
      this.lIIlll.lIl = IIIlIlIII.IIl;
      this.lll = false;
      this.IIllI();
   }

   private void lllIIl(class_332 var1, lIIIllll var2) {
   }

   private List<IIIIIIIlI> lllIlI(List<IIIIIIIlI> var1) {
      String var2 = this.IIllIl == null ? "" : this.IIllIl.trim().toLowerCase(Locale.ROOT);
      if (var2.isEmpty()) {
         return var1;
      } else {
         ArrayList var3 = new ArrayList();

         for(IIIIIIIlI var5 : var1) {
            if (IIIIIl(var5.lllllI(), var2) || IIIIIl(var5.IIllllI(), var2)) {
               var3.add(var5);
            }
         }

         return var3;
      }
   }

   private static <undefinedtype> llllII(int var0, int var1, int var2, int var3) {
      int var4 = Math.max(1, var0);
      int var5 = Math.max(1, var1);
      int var6 = var2 > 0 ? var2 : var4;
      int var7 = var3 > 0 ? var3 : var5;
      double var8 = (double)var6 / (double)var4;
      double var10 = (double)var7 / (double)var5;
      double var12 = Math.max((double)1.0F, Math.min(var8, var10));
      double var14 = lIlllllI.IIIl(var12, var6, var7);
      int var16 = Math.max(1, (int)Math.ceil((double)var6 / var14));
      int var17 = Math.max(1, (int)Math.ceil((double)var7 / var14));
      return new Record(var16, var17, (double)var4 / (double)var16, (double)var5 / (double)var17) {
         private final int I;
         private final double l;
         private final int II;
         private final double Il;

         public int I() {
            return this.I;
         }

         double l(double var1) {
            return this.Il > (double)0.0F ? var1 / this.Il : var1;
         }

         public double II() {
            return this.Il;
         }

         private {
            this.I = var1;
            this.II = var2;
            this.l = var3;
            this.Il = var5;
         }

         double Il(double var1) {
            return this.l > (double)0.0F ? var1 / this.l : var1;
         }

         public int lI() {
            return this.II;
         }

         public double ll() {
            return this.l;
         }
      };
   }

   private boolean llllIl(class_11909 var1) {
      double var2 = this.IIllIlI();
      double var4 = this.IIlIIll(this.lIIlIll(var2).size(), (double)11.0F);
      double var6 = ((double)this.Il.I() - var2) * (double)0.5F;
      double var8 = ((double)this.Il.lI() - var4) * (double)0.5F;
      double var10 = var8 + var4 - (double)27.0F;
      double var12 = var6 + var2 * (double)0.5F - (double)80.0F;
      double var14 = var6 + var2 * (double)0.5F + (double)10.0F;
      if (!llIlII(var1.comp_4798(), var1.comp_4799(), var6, var8, var2, var4)) {
         this.IllIIIl();
         return true;
      } else if (llIlII(var1.comp_4798(), var1.comp_4799(), var12, var10, (double)70.0F, (double)19.0F)) {
         this.IllIIIl();
         return true;
      } else if (llIlII(var1.comp_4798(), var1.comp_4799(), var14, var10, (double)70.0F, (double)19.0F)) {
         this.lIllIl.I();
         this.IllIIIl();
         this.IlIll();
         return true;
      } else {
         return true;
      }
   }

   private static IIIIIIIlI lllllI(llIlIIII var0) {
      IIIIIIIlI var10000;
      if (var0 instanceof IIIIIIIlI var1) {
         var10000 = var1;
      } else {
         var10000 = null;
      }

      return var10000;
   }

   private static String IIIIIII(lIllII var0) {
      String var10000;
      switch (null.I[var0.ordinal()]) {
         case 1 -> var10000 = x.lIlIII.Il(llIIlII(481449113, 1266641295));
         case 2 -> var10000 = x.lIlIII.Il(llIIlII(481449114, 1369455957));
         case 3 -> var10000 = x.lIlIII.Il(llIIlII(481449115, -1665987321));
         case 4 -> var10000 = x.lIlIII.Il(llIIlII(481449092, 219023020));
         case 5 -> var10000 = x.lIlIII.Il(llIIlII(481449093, 425614882));
         case 6 -> var10000 = x.lIlIII.Il(llIIlII(481449094, -1721292984));
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   private double IIIIIIl(long var1, double var3) {
      double var5 = (Double)this.lIIIll.getOrDefault(var1, var3);
      if (Double.isFinite(var5) && !(Math.abs(var5 - var3) < 0.35)) {
         var5 = this.IlIllIl(var5, var3, (double)18.0F);
      } else {
         var5 = var3;
      }

      this.lIIIll.put(var1, var5);
      return var5;
   }

   private void IIIIIlI() {
      this.IlIlII();
      this.IIlll = null.l;
      this.lIIll = null;
      this.lII = null;
      this.IlI = null;
      this.lIll = null;
      this.II = null;
      this.IllIIIl();
   }

   private double IIIIIll(double var1) {
      if (this.lIIlll.lIl == IIIlIlIII.l) {
         return var1;
      } else {
         double var3 = this.lIIlll.lIll + this.lIIlll.III * (double)0.5F;
         return var3 + (var1 - var3) / this.Illll();
      }
   }

   private void IIIIlII() {
      if (!this.IIIll) {
         try {
            this.IlIll();
         } catch (RuntimeException var5) {
         } finally {
            this.IIIll = true;
         }

      }
   }

   private boolean IIIIllI(class_11908 var1) {
      int var2 = var1.comp_4795();
      int var3 = var1.comp_4797();
      return var2 == llIIIll(-1645453266, 1815610684) && ((var3 & llIIIll(-1645453265, -797872524)) != 0 || this.llIIIlI());
   }

   private void IIIIlll(class_332 var1) {
      if (this.lIllIl != null) {
         double var2 = this.IIllIlI();
         List var4 = this.lIIlIll(var2);
         double var5 = (double)11.0F;
         double var7 = this.IIlIIll(var4.size(), var5);
         double var9 = ((double)this.Il.I() - var2) * (double)0.5F;
         double var11 = ((double)this.Il.lI() - var7) * (double)0.5F;
         double var13 = var11 + var7 - (double)27.0F;
         this.IlIllI.IIlI(var9, var11, var2, var7, true);
         this.IlIllI.lIl(this.lIlIlI == null ? x.lIlIII.l(llIIlII(481449095, -1024300596)) : this.lIlIlI, var9 + var2 * (double)0.5F, var11 + (double)10.0F, this.IlIllI.IllIl(), var2 - (double)18.0F);
         double var15 = var11 + (double)29.0F;

         for(String var18 : var4) {
            this.IlIllI.llII(var18, var9 + var2 * (double)0.5F, var15, this.IlIllI.IIIlII(), var2 - (double)18.0F);
            var15 += var5;
         }

         this.IlIllI.IllI(var9 + var2 * (double)0.5F - (double)80.0F, var13, (double)70.0F, (double)19.0F, x.lIlIII.Il(llIIlII(481449088, -240044720)), false);
         this.IlIllI.IllI(var9 + var2 * (double)0.5F + (double)10.0F, var13, (double)70.0F, (double)19.0F, x.lIlIII.Il(llIIlII(481449089, -830113522)), true);
         this.lIIlIl.III(var9 + var2 * (double)0.5F - (double)80.0F, var13, (double)70.0F, (double)19.0F, (var1x, var2x) -> {
            this.IllIIIl();
            return true;
         });
         this.lIIlIl.III(var9 + var2 * (double)0.5F + (double)10.0F, var13, (double)70.0F, (double)19.0F, (var1x, var2x) -> {
            this.lIllIl.I();
            this.IllIIIl();
            this.IlIll();
            return true;
         });
      }
   }

   private boolean IIIlIIl(class_11908 var1) {
      int var2 = var1.comp_4795();
      int var3 = var1.comp_4797();
      return var2 == llIIIll(-1645453268, 1328367547) && ((var3 & llIIIll(-1645453267, -1890597447)) != 0 || this.llIIIlI());
   }

   private void IIIlIlI(double var1, double var3, double var5, double var7) {
      <undefinedtype> var9 = this.lIIlll.lll;
      double var10 = this.lIlIIIl(var1 + (double)8.0F, var3 + (double)8.0F, Math.max((double)0.0F, var5 - (double)16.0F), var9);
      double var12 = var10 + (double)8.0F;
      this.lIIlIl.ll(var1, var12, var5, Math.max((double)0.0F, var7 - (var12 - var3)), null, (var1x, var3x, var5x, var7x) -> {
         this.lIIlll.IllI = Math.max((double)0.0F, this.lIIlll.IllI - var7x * (double)28.0F);
         this.IIllI();
         return true;
      });
      double var14 = Math.max((double)0.0F, var5 - (double)20.0F);
      double var16 = (double)8.0F;
      int var18 = Math.max(1, Math.min(4, (int)((var14 + var16) / ((double)74.0F + var16))));
      double var19 = Math.max((double)1.0F, (var14 - var16 * (double)(var18 - 1)) / (double)var18);
      double var21 = Math.max((double)32.0F, var19 * 0.48);
      double var23 = var21 + (double)24.0F;
      double var25 = var23 + var16;
      EnumSet var27 = EnumSet.noneOf(IIllIIlII.class);
      ArrayList var28 = new ArrayList();

      for(IIllIIlII var32 : IIllIIlII.values()) {
         if (var32 != IIllIIlII.lIl && var9.I(var32)) {
            var28.add(var32);
         }
      }

      boolean var63 = var9 == null.l || var9 == null.II;
      int var64 = (var28.size() + (var63 ? 1 : 0) + var18 - 1) / var18;
      double var65 = var9 == null.II ? (double)100.0F : (double)0.0F;
      double var33 = (double)var64 * var25 + (double)8.0F + var65;
      double var35 = Math.max((double)0.0F, var7 - (var12 - var3));
      double var37 = Math.max((double)0.0F, var33 - var35);
      this.lIIlll.IllI = Math.max((double)0.0F, Math.min(var37, this.lIIlll.IllI));
      double var39 = this.IIIIIIl(4L, this.lIIlll.IllI);
      double var41 = var1 + (double)10.0F + Math.max((double)0.0F, (var14 - ((double)var18 * var19 + (double)(var18 - 1) * var16)) * (double)0.5F);
      IIIIIIllI.IllIII(this.lIIIIl(), var1, var12, var1 + var5, var12 + var35);
      int var43 = 0;

      for(IIllIIlII var45 : var28) {
         int var46 = var43 % var18;
         int var47 = var43 / var18;
         double var48 = var41 + (double)var46 * (var19 + var16);
         double var50 = var12 + (double)8.0F + (double)var47 * var25 - var39;
         var27.add(var45);
         double var52 = this.IlIllIl((Double)this.IIIlII.getOrDefault(var45, (double)0.0F), (double)1.0F, (double)13.5F);
         this.IIIlII.put(var45, var52);
         double var54 = this.IlIllIl((Double)this.llllI.getOrDefault(var45, var50 + (double)18.0F), var50, (double)14.0F);
         this.llllI.put(var45, var54);
         double var56 = this.lIllIl(var52);
         double var58 = var54 + ((double)1.0F - var56) * (double)10.0F;
         boolean var60 = this.IIIIl.IIl().IIII().lIlII() == var45;
         this.IlIllI.llllI(var48, var58, var19, var23, var21, var45, var60, var56);
         int var61 = (int)Math.round(var56 * (var60 ? (double)255.0F : (double)220.0F));
         int var62 = var60 ? var61 << llIIIll(-1645453278, -1497527629) | this.IlIllI.lI() & llIIIll(-1645453277, 294788020) : var61 << llIIIll(-1645453280, 1561208560) | llIIIll(-1645453279, -1235596957);
         this.IIllll(var45.toString(), var48, var58, var19, var21, var62);
         this.lIIlIl.III(var48, var58, var19, var23, (var2, var3x) -> {
            this.IIIIl.IIl().IIII().lII(var45);
            this.lIIlll.Illl = var45;
            this.IIIIll = "";
            this.IlIll();
            return true;
         });
         ++var43;
      }

      if (var63) {
         int var66 = var43 % var18;
         int var68 = var43 / var18;
         double var69 = var41 + (double)var66 * (var19 + var16);
         double var71 = var12 + (double)8.0F + (double)var68 * var25 - var39;
         IIllIIlII var72 = IIllIIlII.lIl;
         var27.add(var72);
         double var51 = this.IlIllIl((Double)this.IIIlII.getOrDefault(var72, (double)0.0F), (double)1.0F, (double)13.5F);
         this.IIIlII.put(var72, var51);
         double var53 = this.IlIllIl((Double)this.llllI.getOrDefault(var72, var71 + (double)18.0F), var71, (double)14.0F);
         this.llllI.put(var72, var53);
         double var55 = this.lIllIl(var51);
         double var57 = var53 + ((double)1.0F - var55) * (double)10.0F;
         boolean var59 = this.IIIIl.IIl().IIII().lIlII() == IIllIIlII.lIl;
         this.IlIllI.llllI(var69, var57, var19, var23, var21, IIllIIlII.lIl, var59, var55);
         int var73 = (int)Math.round(var55 * (var59 ? (double)255.0F : (double)220.0F));
         int var74 = var59 ? var73 << llIIIll(-1645453274, 1249050072) | this.IlIllI.lI() & llIIIll(-1645453273, 1783775942) : var73 << llIIIll(-1645453276, -1264830875) | llIIIll(-1645453275, 257410632);
         this.IIllll(IIllIIlII.lIl.toString(), var69, var57, var19, var21, var74);
         this.lIIlIl.III(var69, var57, var19, var23, (var1x, var2) -> {
            this.IIIIl.IIl().IIII().lII(IIllIIlII.lIl);
            this.lIIlll.Illl = IIllIIlII.lIl;
            this.IIIIll = "";
            this.IlIll();
            return true;
         });
         ++var43;
      }

      if (var9 == null.II) {
         double var67 = var12 + (double)8.0F + (double)((var43 + var18 - 1) / var18) * var25 - var39 + (double)8.0F;
         lIIIllll var70 = this.IIIIl.IIl().IIII();
         this.IIllII(var70, var70.IIIll(), x.lIlIII.Il(llIIlII(481449090, 1370313263)), var1 + (double)10.0F, var67, var5 - (double)20.0F);
         this.IIllII(var70, var70.lllll(), x.lIlIII.Il(llIIlII(481449091, 489818272)), var1 + (double)10.0F, var67 + (double)48.0F, var5 - (double)20.0F);
      }

      IIIIIIllI.lIII(this.lIIIIl());
      this.IIIlII.keySet().removeIf((var1x) -> !var27.contains(var1x));
      this.llllI.keySet().removeIf((var1x) -> !var27.contains(var1x));
   }

   private double IIIllIl(IIIIIIIlI var1, boolean var2, boolean var3) {
      long var4 = var1.IIlIllI();
      double var6 = (Double)this.IlIlI.getOrDefault(var4, (double)0.0F);
      double var8 = var3 ? this.IlIllIl(var6, var2 ? (double)1.0F : (double)0.0F, (double)10.0F) : var6;
      if (!var2 && var8 < 0.01) {
         this.IlIlI.remove(var4);
         return (double)0.0F;
      } else {
         this.IlIlI.put(var4, var8);
         return var8;
      }
   }

   private double IIIlllI() {
      return Math.min((double)390.0F, Math.max((double)260.0F, (double)this.Il.I() - (double)30.0F));
   }

   private void IIlIIII(IIIIIIIlI var1) {
      if (var1 != null) {
         String var2 = var1.l();
         if (!var1.IIIIIlI() && var2 != null && !var2.isBlank()) {
            this.lIlIlI = var1.lllllI();
            this.IIlIII = var2;
            this.lIllIl = () -> var1.IIIllIl(true);
         } else {
            var1.IIIlllI();
         }
      }
   }

   private static long IIlIIlI(long var0, long var2, long var4) {
      long var6 = (var0 ^ var2) * 1099511628211L;
      return (var6 ^ var4) * 1099511628211L;
   }

   private double IIlIIll(int var1, double var2) {
      return Math.min((double)this.Il.lI() - (double)30.0F, Math.max((double)82.0F, (double)58.0F + (double)Math.max(1, var1) * var2));
   }

   private void IIlIlII(class_332 var1, List<llIlIIII> var2) {
      double var3 = (double)190.0F;
      double var5 = this.IlIIllI();
      double var7 = this.IlIII();
      double var9 = (double)var2.size() * var7;
      double var11 = this.IIIIlI(var2.size());
      double var13 = Math.max((double)8.0F, (double)this.Il.I() - var3 - (double)10.0F);
      double var15 = (double)12.0F;
      double var17 = this.lIIlll.ll;
      double var19 = this.lIIlll.lI;
      if (!Double.isFinite(var17) || var17 < (double)8.0F || var17 > (double)this.Il.I() - var3 - (double)8.0F) {
         var17 = var13;
      }

      if (!Double.isFinite(var19) || var19 < (double)8.0F || var19 > (double)this.Il.lI() - var11 - (double)8.0F) {
         var19 = var15;
      }

      this.lIIlll.ll = var17;
      this.lIIlll.lI = var19;
      double var21 = var19 + var5;
      double var23 = Math.max((double)0.0F, var11 - var5 - (double)7.0F);
      double var25 = Math.max((double)0.0F, var9 - var23);
      this.lIIlll.lII = Math.max((double)0.0F, Math.min(var25, this.lIIlll.lII));
      double var27 = this.IIIIIIl(5L, this.lIIlll.lII);
      this.IlIllI.IIlI(var17, var19, var3, var11, false);
      this.IlIllI.llII(x.lIlIII.Il(llIIlII(481449100, 894116613)), var17 + var3 * (double)0.5F, this.IIllllI(var19, var5), this.IlIllI.IllIl(), var3 - (double)18.0F);
      this.lIIlIl.III(var17, var19, var3, var5, (var1x, var2x) -> {
         this.IIlll = null.II;
         this.lIIlI = var1x.comp_4798() - this.lIIlll.ll;
         this.l = var1x.comp_4799() - this.lIIlll.lI;
         return true;
      });
      this.lIIlIl.ll(var17, var21, var3, var23, null, (var5x, var7x, var9x, var11x) -> {
         this.lIIlll.lII = Math.max((double)0.0F, Math.min(var25, this.lIIlll.lII - var11x * var7));
         this.IIllI();
         return true;
      });
      IIIIIIllI.IllIII(var1, var17 + (double)6.0F, var21, var17 + var3 - (double)6.0F, var21 + var23);
      double var29 = var21 + (double)3.0F - var27;

      for(llIlIIII var32 : var2) {
         if (var29 + var7 >= var21 && var29 <= var21 + var23) {
            IIIIIIIlI var33 = lllllI(var32);
            boolean var34 = llIlI(var32);
            long var35 = lIlll(var32);
            this.lIIlll.llI(var35);
            double var38 = var17 + (double)8.0F;
            double var40 = var3 - (double)16.0F;
            double var42 = IIIIIIllI.I();
            double var44 = IIIIIIllI.Il();
            double var46 = var38 + var40 - (double)10.0F - var42;
            double var48 = var29 + (var7 - (double)2.0F - var44) * (double)0.5F;
            this.IlIllI.lIll(var38, var29, var40, false, false);
            int var50 = var34 ? this.IlIllI.IllIl() : this.IlIllI.IIIlII();
            this.IlIllI.IlII(IIll(var32), var38 + (double)10.0F, this.IIllllI(var29, var7 - (double)2.0F), Math.max((double)0.0F, var46 - var38 - (double)10.0F - (double)8.0F), var50);
            this.IlIllI.IIIlI(var46, var48, var34);
            this.lIIlIl.III(var38, var29, var40, var7 - (double)2.0F, (var5x, var6) -> {
               if (var33 != null && var33.IIlIlIl()) {
                  var33.IIIlllI();
                  if (!var33.IIIIIlI()) {
                     if (this.lIIlll.llI(var35)) {
                        this.lIIlll.IIl();
                     }

                     if (this.lIIll == var32) {
                        this.lIIll = null;
                     }
                  } else {
                     this.lIIlll.IIlI(var35);
                  }

                  this.IlIll();
               }

               return true;
            });
         }

         var29 += var7;
      }

      IIIIIIllI.lIII(var1);
   }

   private double IIlIllI(List<IIIIIIIlI> var1) {
      if (var1 != null && !var1.isEmpty()) {
         double var2 = (double)0.0F;
         double var4 = (double)0.0F;
         double var6 = (double)6.0F;

         for(int var8 = 0; var8 < var1.size(); ++var8) {
            IIIIIIIlI var9 = (IIIIIIIlI)var1.get(var8);
            double var10 = this.IIIlIl(var9);
            if (var8 % 2 == 0) {
               if (var2 > (double)0.0F) {
                  var2 += var6;
               }

               var2 += var10;
            } else {
               if (var4 > (double)0.0F) {
                  var4 += var6;
               }

               var4 += var10;
            }
         }

         return Math.max(var2, var4);
      } else {
         return (double)0.0F;
      }
   }

   public boolean method_25401(double var1, double var3, double var5, double var7) {
      if (this.IIIIIl) {
         return true;
      } else {
         this.llIIIII();
         double var9 = this.IIIII(this.Il.Il(var1));
         double var11 = this.IIIIIll(this.Il.l(var3));
         return this.lIIlIl.II(var9, var11, var5, var7);
      }
   }

   private void IIlIlll(class_332 var1) {
      if (this.II != null) {
         double var2 = (double)224.0F;
         double var4 = (double)48.0F;
         double var6 = ((double)this.Il.I() - var2) * (double)0.5F;
         double var8 = ((double)this.Il.lI() - var4) * (double)0.5F;
         this.IlIllI.IIlI(var6, var8, var2, var4, true);
         this.IlIllI.llII(x.lIlIII.Il(llIIlII(481449103, 1083077129)), var6 + var2 * (double)0.5F, var8 + (double)11.0F, this.IlIllI.IllIl(), var2 - (double)18.0F);
         this.IlIllI.llII(x.lIlIII.Il(llIIlII(481449096, -845732534)), var6 + var2 * (double)0.5F, var8 + (double)28.0F, this.IlIllI.IIIlII(), var2 - (double)18.0F);
      }
   }

   private void IIllIII(class_332 var1, double var2, double var4, double var6, double var8) {
      this.IlIllI.lIl(x.lIlIII.l(llIIlII(481449097, 1305769518)), var2 + var6 * (double)0.5F, var4 + (double)4.0F, this.IlIllI.IllIl(), var6);
      this.IlIllI.lIl(x.lIlIII.l(llIIlII(481449098, -2083832395)), var2 + var6 * (double)0.5F, var4 + (double)18.0F, this.IlIllI.IIIlII(), var6);
      lIIIllI var10 = this.IIIIl.IIl().llll();
      IIIIllIl var11 = this.IIIIl.IIl().IllIll();
      IlllIllI var12 = this.IIIIl.IIl().IlIlIl();
      IIIIIIlII var13 = this.IIIIl.IIl().IllllI();
      lIIIllll var14 = this.IIIIl.IIl().IIII();
      IIIll var15 = this.IIIIl.IIl().IIIIII();
      double var16 = Math.min((double)520.0F, Math.max((double)0.0F, var6));
      double var18 = var2 + (var6 - var16) * (double)0.5F;
      boolean var20 = var16 >= (double)340.0F;
      double var21 = this.IllIIII(var10, var11, var12);
      double var23 = this.IllIIII(var13, var14, var15);
      double var25 = var20 ? Math.max(var21, var23) : var21 + (double)6.0F + var23;
      double var27 = var4 + (double)34.0F;
      double var29 = Math.max((double)0.0F, var8 - (double)34.0F);
      double var31 = Math.max((double)0.0F, var25 - var29);
      double var33 = Math.max((double)0.0F, Math.min(var31, this.lIIlll.lIlI));
      if (var33 != this.lIIlll.lIlI) {
         this.lIIlll.lIlI = var33;
         this.IIllI();
      }

      double var35 = var27 - var33;
      this.lIIlIl.ll(var18, var27, var16, var29, null, (var3, var5, var7, var9) -> {
         this.lIIlll.lIlI = Math.max((double)0.0F, Math.min(var31, this.lIIlll.lIlI - var9 * (double)28.0F));
         this.IIllI();
         return true;
      });
      IIIIIIllI.IllIII(var1, var18, var27, var18 + var16, var27 + var29);
      this.lIIlIl.l(var18, var27, var16, var29);

      try {
         if (var20) {
            double var37 = (var16 - (double)6.0F) * (double)0.5F;
            double var39 = var35 + this.lIIIlII(var1, var10, var18, var35, var37) + (double)6.0F;
            var39 += this.lIIIlII(var1, var11, var18, var39, var37) + (double)6.0F;
            this.lIIIlII(var1, var12, var18, var39, var37);
            double var41 = var35 + this.lIIIlII(var1, var13, var18 + var37 + (double)6.0F, var35, var37) + (double)6.0F;
            var41 += this.lIIIlII(var1, var14, var18 + var37 + (double)6.0F, var41, var37) + (double)6.0F;
            this.lIIIlII(var1, var15, var18 + var37 + (double)6.0F, var41, var37);
         } else {
            double var46 = var35 + this.lIIIlII(var1, var10, var18, var35, var16) + (double)6.0F;
            var46 += this.lIIIlII(var1, var11, var18, var46, var16) + (double)6.0F;
            var46 += this.lIIIlII(var1, var12, var18, var46, var16) + (double)6.0F;
            var46 += this.lIIIlII(var1, var13, var18, var46, var16) + (double)6.0F;
            var46 += this.lIIIlII(var1, var14, var18, var46, var16) + (double)6.0F;
            this.lIIIlII(var1, var15, var18, var46, var16);
         }
      } finally {
         this.lIIlIl.Il();
         IIIIIIllI.lIII(var1);
      }

   }

   private static byte[] IIllIIl(String var0) {
      if (var0 == null) {
         return null;
      } else {
         try {
            URI var1 = URI.create(var0.trim());
            if (IllIII.lIlI().equalsIgnoreCase(var1.getScheme())) {
               Path var2 = Path.of(var1);
               if (!Files.isRegularFile(var2, new LinkOption[0])) {
                  return null;
               }

               long var3 = Files.size(var2);
               return var3 > 0L && var3 <= 8388608L ? Files.readAllBytes(var2) : null;
            }
         } catch (Exception var5) {
            return null;
         }

         return IlIllll(var0);
      }
   }

   private double IIllIlI() {
      return Math.min((double)370.0F, Math.max((double)220.0F, (double)this.Il.I() - (double)30.0F));
   }

   private static boolean IIllIll(String var0) {
      if (var0 != null && !var0.isEmpty()) {
         for(int var1 = 0; var1 < var0.length(); ++var1) {
            char var2 = var0.charAt(var1);
            if (var2 != llIIIll(-1645453254, 2084267081) && !Character.isDigit(var2) && !Character.isUpperCase(var2)) {
               return false;
            }
         }

         return true;
      } else {
         return false;
      }
   }

   private double IIllllI(double var1, double var3) {
      return var1 + Math.max((double)0.0F, (var3 - IIIIIIllI.lllIII(this.field_22793)) * (double)0.5F);
   }

   private void IIlllll(class_332 var1, double var2, double var4, double var6, double var8) {
      boolean var10 = this.IIllIl != null && !this.IIllIl.isBlank();
      List var11 = !var10 ? this.IIIIl.IIl().II(this.lIIlll.II) : this.IIIIl.IIl().IIIIlII();
      List var12 = this.lllIlI(var11);
      var12 = this.lII(var12);
      double var13 = (double)22.0F;
      this.lIIIllI(var1, var2, var4, Math.max((double)0.0F, var6), var13);
      double var15 = var4 + var13 + (double)8.0F;
      double var17 = this.lIIllIl(var2, var15, var6);
      double var19 = var17 + (double)8.0F;
      double var21 = Math.max((double)0.0F, var4 + var8 - var19);
      this.lIIlIl.ll(var2, var19, var6, var21, null, (var1x, var3, var5, var7) -> {
         this.lIIlll.l(this.lIIlll.II, this.lIIlll.IIII(this.lIIlll.II) - var7 * (double)28.0F);
         this.IIllI();
         return true;
      });
      double var23 = (double)6.0F;
      double var25 = Math.max((double)0.0F, (var6 - var23) * (double)0.5F);
      double var27 = Math.max((double)0.0F, this.IIlIllI(var12) - var21);
      double var29 = Math.max((double)0.0F, Math.min(var27, this.lIIlll.IIII(this.lIIlll.II)));
      if (var29 != this.lIIlll.IIII(this.lIIlll.II)) {
         this.lIIlll.l(this.lIIlll.II, var29);
         this.IIllI();
      }

      double var31 = this.IIIIIIl(this.lIlIIlI(this.lIIlll.II), var29);
      double var33 = var19 - var31;
      double var35 = var19 - var31;
      IIIIIIllI.IllIII(var1, var2 - (double)10.0F, var19, var2 + var6 + (double)10.0F, var4 + var8);
      if (var12.isEmpty()) {
         String var60;
         if (this.IIllIl.isBlank()) {
            var60 = x.lIlIII.Il(llIIlII(481449099, 1469608821));
            String var53 = IIIIIII(this.lIIlll.II);
            String var52 = var60;
            var60 = var52 + var53;
         } else {
            var60 = x.lIlIII.Il(llIIlII(481449076, -2086766200));
            String var54 = this.IIllIl.trim();
            String var59 = var60;
            var60 = var59 + var54;
         }

         String var37 = var60;
         this.IlIllI.llII(var37, var2 + var6 * (double)0.5F, var19 + var21 * 0.45, this.IlIllI.IIIlII(), var6 - (double)20.0F);
      }

      double var58 = var19 + var21;
      this.lIIlIl.l(var2 - (double)10.0F, var19, var6 + (double)20.0F, var21);

      try {
         for(int var39 = 0; var39 < var12.size(); ++var39) {
            IIIIIIIlI var40 = (IIIIIIIlI)var12.get(var39);
            double var41 = this.IIIlIl(var40);
            double var43 = this.lIlI - (double)var39 * 0.03;
            double var45 = Math.max((double)0.0F, Math.min((double)1.0F, var43 / 0.22));
            double var47 = this.lIIIll(var45);
            double var49 = ((double)1.0F - var47) * (double)15.0F;
            if (var39 % 2 == 0) {
               if (var33 + var41 > var19 && var33 < var58) {
                  this.IIIllI(var1, var40, var2, var33 + var49, var25, var19, var58, var45);
               }

               var33 += var41 + var23;
            } else {
               if (var35 + var41 > var19 && var35 < var58) {
                  this.IIIllI(var1, var40, var2 + var25 + var23, var35 + var49, var25, var19, var58, var45);
               }

               var35 += var41 + var23;
            }
         }
      } finally {
         this.lIIlIl.Il();
      }

      IIIIIIllI.lIII(var1);
   }

   public void method_25419() {
      if (!this.IIIIIl) {
         this.IIIIIl = true;
         this.Illlll = System.nanoTime();
         this.IlIlII();
         this.IIlll = null.l;
         this.lIIll = null;
         this.lII = null;
         this.IlI = null;
         this.lIll = null;
         this.IIIIlII();
      }
   }

   private boolean IlIIIIl(long var1) {
      return this.IIIIIl && (this.lIllll <= 0.015 || this.Illlll > 0L && var1 - this.Illlll >= 750000000L);
   }

   private void IlIIIlI() {
      if (!this.llIllI) {
         this.llIllI = true;

         try {
            this.IIIIlII();
         } finally {
            this.lIlIII = "";
            this.IllIll = "";
            this.IlIII = "";
            this.IIIIll = "";
            this.IIllIl = "";
            this.IIlIII = null;
            this.lIlIll = null;
            this.lIIIll.clear();
            this.IIIlII.clear();
            this.llllI.clear();
            this.IIlIlI.clear();
            if (this.lIII != null && this.field_22787 != null) {
               this.field_22787.method_1507(this.lIII);
            } else {
               super.method_25419();
            }

         }

      }
   }

   private void IlIIIll(IIIllIIII var1, double var2) {
      double var4 = IlIIlIll.IlIlI((var2 - this.IIllll) / Math.max((double)1.0F, this.IIll), (double)0.0F, (double)1.0F);
      var1.III(var1.lIl() + (var1.ll() - var1.lIl()) * var4);
      this.IlIll();
   }

   IIIlIlIII IlIIlII() {
      return this.lIIlll.lIl;
   }

   private boolean IlIIlIl(class_11908 var1) {
      int var2 = var1.comp_4795();
      int var3 = var1.comp_4797();
      boolean var4 = var2 == llIIIll(-1645453253, -412802179) && ((var3 & llIIIll(-1645453256, -1588229201)) != 0 || this.llIIIlI());
      boolean var5 = var2 == llIIIll(-1645453255, 1104795738) && ((var3 & 1) != 0 || this.IIlll());
      return var4 || var5;
   }

   private double IlIIllI() {
      return (double)28.0F;
   }

   private void IlIIlll(class_332 var1, double var2, double var4, double var6, int var8) {
      double var9 = var6 * (double)0.5F;
      double var11 = 1.35;
      IIIIIIllI.IllIll(var1, var2 - var9, var4 - var11 * (double)0.5F, var6, var11, (double)0.0F, var8);
      IIIIIIllI.IllIll(var1, var2 - var11 * (double)0.5F, var4 - var9, var11, var6, (double)0.0F, var8);
   }

   private void IlIlIII(Object var1) {
      this.IllIlII();
      this.II = var1;
      this.IIllI = false;
      this.llIlI = null;
   }

   private void IlIlIIl(Object var1, String var2, double var3, double var5, double var7, Runnable var9) {
      double var10 = (double)23.0F;
      double var12 = (double)88.0F;
      double var14 = (double)19.0F;
      double var16 = var3 + var7 - var12 - (double)10.0F;
      double var18 = var5 + (var10 - var14) * (double)0.5F;
      this.IlIllI.lIll(var3, var5, var7, false, false);
      this.IlIllI.IlII(var1, var3 + (double)10.0F, this.IIllllI(var5, var10), Math.max((double)0.0F, var16 - var3 - (double)18.0F), this.IlIllI.IllIl());
      this.IlIllI.IllI(var16, var18, var12, var14, var2, false);
      this.lIIlIl.III(var3, var5, var7, var10, (var1x, var2x) -> {
         var9.run();
         return true;
      });
   }

   private double IlIllIl(double var1, double var3, double var5) {
      double var7 = Math.max((double)0.0F, Math.min((double)1.0F, this.IIlIIl * var5));
      return var1 + (var3 - var1) * var7;
   }

   private void IlIlllI(Object var1, String var2) {
      if (this.llIlI == null || !this.llIlI.IIl(var1)) {
         this.IllIlII();
         this.llIlI = var1;
         this.lIlIII = var2 == null ? "" : var2;
      }
   }

   private static byte[] IlIllll(String var0) {
      if (var0 == null) {
         return null;
      } else {
         String var1 = var0.trim();

         for(int var2 = 0; var2 < llIIIll(-1645453250, 918693797); ++var2) {
            Object var3 = null;

            try {
               URI var4 = URI.create(var1);
               URL var5 = var4.toURL();
               HttpURLConnection var29 = (HttpURLConnection)var5.openConnection();
               var29.setRequestMethod(x.lIlIII.Il(llIIlII(481449077, 784938145)));
               var29.setConnectTimeout(llIIIll(-1645453249, 25529821));
               var29.setReadTimeout(llIIIll(-1645453252, 299045736));
               var29.setInstanceFollowRedirects(true);
               var29.setRequestProperty(x.lIlIII.Il(llIIlII(481449078, -1303958590)), x.lIlIII.Il(llIIlII(481449079, 1142178060)));
               var29.setRequestProperty(x.lIlIII.Il(llIIlII(481449072, -1065933938)), x.lIlIII.Il(llIIlII(481449073, -596829365)));
               int var6 = var29.getResponseCode();
               if (var6 >= llIIIll(-1645453251, 1800938180) && var6 < llIIIll(-1645453262, -1139697941)) {
                  String var7 = var29.getHeaderField(x.lIlIII.Il(llIIlII(481449074, -1739948226)));
                  if (var7 != null && !var7.isBlank()) {
                     if (!var7.startsWith(x.lIlIII.Il(llIIlII(481449075, 1256995451))) && !var7.startsWith(x.lIlIII.Il(llIIlII(481449084, -1038725129)))) {
                        var1 = var4.resolve(var7).toString();
                     } else {
                        var1 = var7;
                     }

                     var29.disconnect();
                     continue;
                  }
               }

               if (var6 >= llIIIll(-1645453261, 871554228) && var6 < llIIIll(-1645453264, -414368322)) {
                  int var30 = var29.getContentLength();
                  if (var30 > llIIIll(-1645453263, 248647254)) {
                     var29.disconnect();
                     return null;
                  }

                  Object var13;
                  try {
                     InputStream var8;
                     label312: {
                        var8 = var29.getInputStream();

                        try {
                           label296: {
                              ByteArrayOutputStream var9 = new ByteArrayOutputStream();

                              label250: {
                                 try {
                                    byte[] var10 = new byte[llIIIll(-1645453258, 1623774168)];
                                    int var12 = 0;

                                    int var11;
                                    while((var11 = var8.read(var10)) != -1) {
                                       var12 += var11;
                                       if (var12 > llIIIll(-1645453257, -1598641366)) {
                                          var13 = null;
                                          break label250;
                                       }

                                       var9.write(var10, 0, var11);
                                    }

                                    var31 = var9.toByteArray();
                                 } catch (Throwable var25) {
                                    try {
                                       var9.close();
                                    } catch (Throwable var24) {
                                       var25.addSuppressed(var24);
                                    }

                                    throw var25;
                                 }

                                 var9.close();
                                 break label296;
                              }

                              var9.close();
                              break label312;
                           }
                        } catch (Throwable var26) {
                           if (var8 != null) {
                              try {
                                 var8.close();
                              } catch (Throwable var23) {
                                 var26.addSuppressed(var23);
                              }
                           }

                           throw var26;
                        }

                        if (var8 != null) {
                           var8.close();
                        }

                        return var31;
                     }

                     if (var8 != null) {
                        var8.close();
                     }
                  } finally {
                     var29.disconnect();
                  }

                  return (byte[])var13;
               }

               var29.disconnect();
               return null;
            } catch (Throwable var28) {
               if (var3 != null) {
                  try {
                     ((HttpURLConnection)var3).disconnect();
                  } catch (Throwable var22) {
                  }
               }

               return null;
            }
         }

         return null;
      }
   }

   private double IllIIII(IIIIIIIlI... var1) {
      double var2 = (double)0.0F;
      int var4 = 0;

      for(IIIIIIIlI var8 : var1) {
         if (var8 != null) {
            var2 += this.lIIlll(var8);
            ++var4;
         }
      }

      return var2 + (double)Math.max(0, var4 - 1) * (double)6.0F;
   }

   private void IllIIIl() {
      this.lIllIl = null;
      this.lIlIlI = null;
      this.IIlIII = null;
   }

   private boolean IllIlII() {
      if (this.llIlI == null) {
         return false;
      } else {
         if (this.llIlI.I) {
            this.IllIll = IlllIll(this.lIlIII);
         } else if (this.llIlI.II) {
            String var1 = this.lIlIII == null ? "" : this.lIlIII.trim();
            this.IlIII = var1.isBlank() ? x.lIlIII.Il(llIIlII(481449085, 1714172926)) : var1;
         } else {
            this.llIlI.Il(this.lIlIII);
         }

         this.llIlI = null;
         this.IlIll();
         return true;
      }
   }

   public boolean IllIlIl() {
      return !this.IIIIIl && !this.lll && this.llIlI == null;
   }

   private String IllIlll() {
      return this.field_22787 == null ? "" : this.field_22787.field_1774.method_1460();
   }

   private List<String> IlllIII(String var1, double var2) {
      ArrayList var4 = new ArrayList();
      if (var1 != null && !var1.isBlank()) {
         StringBuilder var5 = new StringBuilder();

         for(String var9 : var1.trim().split(x.lIlIII.Il(llIIlII(481449080, -1724889450)))) {
            if (!var9.isBlank()) {
               String var10000;
               if (var5.isEmpty()) {
                  var10000 = var9;
               } else {
                  var10000 = String.valueOf(var5);
                  String var12 = x.lIlIII.Il(llIIlII(481449081, 1770402471));
                  String var11 = var10000;
                  var10000 = var11 + var12 + var9;
               }

               String var10 = var10000;
               if (!((double)IIIIIIllI.IlIl(this.field_22793, var10) <= var2) && !var5.isEmpty()) {
                  var4.add(var5.toString());
                  var5.setLength(0);
                  var5.append(var9);
               } else {
                  var5.setLength(0);
                  var5.append(var10);
               }
            }
         }

         if (!var5.isEmpty()) {
            var4.add(var5.toString());
         }

         if (var4.isEmpty()) {
            var4.add(var1);
         }

         return var4;
      } else {
         return var4;
      }
   }

   private void IlllIIl(Object var1, String var2, Object var3) {
      this.lIlIlI = var1;
      this.IIlIII = var2;
      this.lIllIl = var3;
   }

   private static String IlllIll(String var0) {
      String var1 = var0 == null ? "" : var0.trim();
      String var2 = var1.replaceAll(x.lIlIII.Il(llIIlII(481449082, 781140136)), x.lIlIII.Il(llIIlII(481449083, -1710481748)));
      if (var2.length() > llIIIll(-1645453260, -144874837)) {
         var2 = var2.substring(0, llIIIll(-1645453259, 563406715));
      }

      return var2;
   }

   private boolean IllllII(String var1) {
      if (var1 == null) {
         return false;
      } else {
         String var2 = var1.trim();
         return var2.startsWith(x.lIlIII.Il(llIIlII(481449060, -1988165360))) || var2.startsWith(x.lIlIII.Il(llIIlII(481449061, -1741277442)));
      }
   }

   private void IllllIl(llllIlIl var1, double var2, boolean var4) {
      double var5 = IlIIlIll.IlIlI((var2 - this.IIllll) / Math.max((double)1.0F, this.IIll), (double)0.0F, (double)1.0F);
      double var7 = var1.ll() + (var1.lIl() - var1.ll()) * var5;
      if (var4) {
         var1.IIIl(new double[]{var7, var1.IlI()});
      } else {
         var1.IIIl(new double[]{var1.IlII(), var7});
      }

      this.IlIll();
   }

   private void Illllll(class_332 var1, int var2, int var3, float var4) {
      double var5 = (double)this.Il.I();
      double var7 = (double)this.Il.lI();
      double var9 = var5 * (double)0.5F;
      double var11 = var7 * (double)0.5F;
      IIIIIIllI.IlIlI(var1, var9, (double)0.0F, var9, var7, (double)1.0F, this.IlIllI.lllIl(llIIIll(-1645453110, -714457112)));
      IIIIIIllI.IlIlI(var1, (double)0.0F, var11, var5, var11, (double)1.0F, this.IlIllI.lllIl(llIIIll(-1645453109, -1723463372)));
      List var13 = this.IIIIl.IIl().llIlI();

      for(llIlIIII var15 : var13) {
         if (llIlI(var15)) {
            var15.III(var1, var2, var3, var4, false);
         }
      }

      for(llIlIIII var19 : var13) {
         if (llIlI(var19)) {
            long var16 = lIlll(var19);
            this.lIIlIl.III(var19.Il(), var19.Ill(), Math.max((double)4.0F, var19.llll()), Math.max((double)4.0F, var19.lIIl()), (var4x, var5x) -> {
               this.lIIlll.IIlI(var16);
               this.lIIll = var19;
               this.llIIII = var4x.comp_4798() - var19.Il();
               this.lIllII = var4x.comp_4799() - var19.Ill();
               this.lIIlIl(var4x.comp_4798(), var4x.comp_4799());
               return true;
            });
         }
      }

      this.IIlIlII(var1, var13);
   }

   private void lIIIIlI(class_332 var1) {
      if (this.lIlIll != null && !this.lIlIll.isBlank()) {
         double var2 = (double)220.0F;
         List var4 = this.IlllIII(this.lIlIll, var2 - (double)14.0F);
         double var5 = (double)0.0F;

         for(String var8 : var4) {
            var5 = Math.max(var5, (double)IIIIIIllI.IlIl(this.field_22793, var8));
         }

         double var23 = Math.max((double)72.0F, Math.min(var2, var5 + (double)14.0F));
         Objects.requireNonNull(this.field_22793);
         double var9 = (double)9.0F + (double)3.0F;
         int var10000 = var4.size();
         Objects.requireNonNull(this.field_22793);
         double var11 = (double)(var10000 * llIIIll(-1645453112, -809206675)) + (double)Math.max(0, var4.size() - 1) * (double)3.0F;
         double var13 = var11 + (double)12.0F;
         double var15 = Math.min(this.lIIlll.IIlI + this.lIIlll.IlIl - var23 - (double)8.0F, this.IllIlI + (double)12.0F);
         double var17 = this.IlII;
         IIIIIIllI.llI(var1, var15, var17, var23, var13, (double)5.5F, llIIIll(-1645453111, 873154785), (double)9.0F, 5, 0.35);
         IIIIIIllI.IllIll(var1, var15, var17, var23, var13, (double)5.5F, llIIIll(-1645453106, 40675530));
         double var19 = var17 + (var13 - var11) * (double)0.5F;

         for(String var22 : var4) {
            this.IlIllI.llIII(var22, var15 + (double)7.0F, var19, this.IlIllI.IllIl());
            var19 += var9;
         }

      }
   }

   private double lIIIlII(class_332 var1, IIIIIIIlI var2, double var3, double var5, double var7) {
      if (var2 == null) {
         return (double)0.0F;
      } else {
         double var9 = this.lIIlll(var2);
         IIIIIIllI.IllIll(var1, var3, var5, var7, var9, (double)5.0F, llIIIll(-1645453105, -1174226717));
         this.IlIllI.IlII(var2.lllllI(), var3 + (double)8.0F, var5 + (double)5.0F, var7 - (double)50.0F, this.IlIllI.IllIl());
         this.IlIllI.lIlIl(var2.llIllI(), var3 + (double)8.0F, var5 + (double)18.0F, var7 - (double)16.0F, this.IlIllI.IIIlII(), 0.58);
         if (var2.IIlIlIl()) {
            double var11 = var3 + var7 - (double)8.0F - IIIIIIllI.I();
            double var13 = var5 + (double)6.0F;
            this.IlIllI.IIIlI(var11, var13, var2.IIIIIlI());
            this.lIIlIl.III(var11 - (double)4.0F, var5 + (double)2.0F, IIIIIIllI.I() + (double)8.0F, (double)22.0F, (var2x, var3x) -> {
               this.IIlIIII(var2);
               this.IlIll();
               return true;
            });
         }

         double var15 = var5 + (double)31.0F;

         for(llllllI var14 : var2.IIIlll()) {
            var15 += this.llIlll(var1, var2, var14, var3 + (double)8.0F, var15, var7 - (double)16.0F);
         }

         if (var2 instanceof IIIll) {
            this.lIlI(var2, var3 + (double)8.0F, var15, var7 - (double)16.0F);
         }

         return var9;
      }
   }

   public void method_25420(class_332 var1, int var2, int var3, float var4) {
   }

   public boolean method_25404(class_11908 var1) {
      if (this.IIIIIl) {
         return true;
      } else {
         int var2 = var1.comp_4795();
         if (this.II != null) {
            if (var2 != llIIIll(-1645453108, 168135664) && var2 != llIIIll(-1645453107, 1151922565) && var2 != llIIIll(-1645453118, -1079841372)) {
               this.II.ll(IllllIlI.lllll(var2));
            } else {
               this.II.ll(class_3675.field_16237);
            }

            this.II = null;
            this.IlIll();
            return true;
         } else if (this.lIlIIll()) {
            if (var2 == llIIIll(-1645453117, 1045428930)) {
               this.lIIlII = true;
            }

            return true;
         } else if (this.lll) {
            if (var2 != llIIIll(-1645453120, -1428059436) && var2 != llIIIll(-1645453119, 60871958) && var2 != llIIIll(-1645453114, -1405744173)) {
               if (this.IIIIllI(var1)) {
                  this.llIlII = true;
                  return true;
               } else if (this.IIIIII(var1)) {
                  if (this.field_22787 != null && !this.IIllIl.isEmpty()) {
                     this.field_22787.field_1774.method_1455(this.IIllIl);
                  }

                  return true;
               } else if (this.IIIlIIl(var1)) {
                  if (this.field_22787 != null && !this.IIllIl.isEmpty()) {
                     this.field_22787.field_1774.method_1455(this.IIllIl);
                  }

                  this.IIllIl = "";
                  this.llIlII = false;
                  this.lIIlll.l(this.lIIlll.II, (double)0.0F);
                  return true;
               } else if (this.IlIIlIl(var1)) {
                  if (this.llIlII) {
                     this.IIllIl = this.IllIlll();
                     this.llIlII = false;
                  } else {
                     String var10001 = this.IIllIl;
                     String var9 = this.IllIlll();
                     String var5 = var10001;
                     this.IIllIl = var5 + var9;
                  }

                  this.lIIlll.l(this.lIIlll.II, (double)0.0F);
                  return true;
               } else if (var2 != llIIIll(-1645453113, -1569978231)) {
                  if (var2 == llIIIll(-1645453115, -1852508464)) {
                     this.IIllIl = "";
                     this.llIlII = false;
                     this.lIIlll.l(this.lIIlll.II, (double)0.0F);
                     return true;
                  } else if (var2 != llIIIll(-1645453094, -896537108) && var2 != llIIIll(-1645453093, 679614142) && var2 != llIIIll(-1645453096, -991457333) && var2 != llIIIll(-1645453095, -1217872227)) {
                     this.llIlII = false;
                     return true;
                  } else {
                     this.llIlII = false;
                     return true;
                  }
               } else {
                  if (this.llIlII) {
                     this.IIllIl = "";
                     this.llIlII = false;
                  } else if ((var1.comp_4797() & llIIIll(-1645453116, -1899412713)) == 0 && !this.llIIIlI()) {
                     if (!this.IIllIl.isEmpty()) {
                        this.IIllIl = this.IIllIl.substring(0, this.IIllIl.length() - 1);
                     }
                  } else {
                     this.IIllIl = lIIIlI(this.IIllIl);
                  }

                  this.lIIlll.l(this.lIIlll.II, (double)0.0F);
                  return true;
               }
            } else {
               this.lll = false;
               this.llIlII = false;
               return true;
            }
         } else if (this.llIlI != null) {
            if (var2 == llIIIll(-1645453090, 2093213414)) {
               this.llIlI = null;
               this.llIlII = false;
               return true;
            } else if (this.IIIIllI(var1)) {
               this.llIlII = true;
               return true;
            } else if (this.IIIIII(var1)) {
               if (this.field_22787 != null && !this.lIlIII.isEmpty()) {
                  this.field_22787.field_1774.method_1455(this.lIlIII);
               }

               return true;
            } else if (this.IIIlIIl(var1)) {
               if (this.field_22787 != null && !this.lIlIII.isEmpty()) {
                  this.field_22787.field_1774.method_1455(this.lIlIII);
               }

               this.lIlIII = "";
               this.llIlII = false;
               return true;
            } else if (this.IlIIlIl(var1)) {
               String var3 = this.IllIlll();
               if (this.llIlI.I) {
                  if (this.llIlII) {
                     this.lIlIII = var3.length() > llIIIll(-1645453089, -777049048) ? var3.substring(0, llIIIll(-1645453092, -894274122)) : var3;
                     this.llIlII = false;
                  } else {
                     String var6 = this.lIlIII;
                     String var4 = var6 + var3;
                     this.lIlIII = var4.length() > llIIIll(-1645453091, -1162546491) ? var4.substring(0, llIIIll(-1645453102, -1259821765)) : var4;
                  }
               } else if (this.llIlII) {
                  this.lIlIII = var3;
                  this.llIlII = false;
               } else {
                  String var7 = this.lIlIII;
                  this.lIlIII = var7 + var3;
               }

               return true;
            } else if (var2 != llIIIll(-1645453101, 884996380) && var2 != llIIIll(-1645453104, -1822699180)) {
               if (var2 != llIIIll(-1645453103, 827564130)) {
                  if (var2 == llIIIll(-1645453097, 244406314)) {
                     this.lIlIII = "";
                     this.llIlII = false;
                     return true;
                  } else if (var2 != llIIIll(-1645453100, 11200944) && var2 != llIIIll(-1645453099, -1303463823) && var2 != llIIIll(-1645453078, -2075617914) && var2 != llIIIll(-1645453077, 1038248315)) {
                     this.llIlII = false;
                     return true;
                  } else {
                     this.llIlII = false;
                     return true;
                  }
               } else {
                  if (this.llIlII) {
                     this.lIlIII = "";
                     this.llIlII = false;
                  } else if ((var1.comp_4797() & llIIIll(-1645453098, 1543053180)) == 0 && !this.llIIIlI()) {
                     if (!this.lIlIII.isEmpty()) {
                        this.lIlIII = this.lIlIII.substring(0, this.lIlIII.length() - 1);
                     }
                  } else {
                     this.lIlIII = lIIIlI(this.lIlIII);
                  }

                  return true;
               }
            } else {
               this.IllIlII();
               this.llIlII = false;
               return true;
            }
         } else if (this.lIllIl != null && var2 == llIIIll(-1645453080, 1267245956)) {
            this.IllIIIl();
            return true;
         } else if (var2 == llIIIll(-1645453079, -781010539)) {
            if (this.lIIlll.lIl != IIIlIlIII.IIl) {
               this.lIIlll.lIl = IIIlIlIII.IIl;
               this.lll = false;
               this.llIlI = null;
               this.llIlII = false;
               this.IIllI();
               return true;
            } else {
               this.method_25419();
               return true;
            }
         } else if (this.lIIlll.lIl == IIIlIlIII.l) {
            return true;
         } else if (var2 == llIIIll(-1645453074, 1230045293)) {
            this.lllIII((var1.comp_4797() & 1) != 0 ? -1 : 1);
            return true;
         } else if (var2 != llIIIll(-1645453073, 1490570513) && var2 != llIIIll(-1645453076, 1576970005)) {
            if (var2 != llIIIll(-1645453075, 1200243195) && var2 != llIIIll(-1645453086, -786545969)) {
               return super.method_25404(var1);
            } else {
               this.lllIII(1);
               return true;
            }
         } else {
            this.lllIII(-1);
            return true;
         }
      }
   }

   private void lIIIlIl(double var1, double var3, double var5) {
      double var7 = (double)24.0F;
      double var9 = (double)7.0F;
      double var11 = var3 + (double)52.0F - (double)6.0F + (double)(lllll.length + 1) * (double)28.0F + var7;
      double var13 = var11 + (double)20.0F;

      for(IIIlIlIII var18 : lIllI) {
         boolean var19 = this.lIIlll.lIl == var18;
         double var20 = (Double)this.IIlIlI.getOrDefault(var18, (double)0.0F);
         double var22 = var19 ? (double)2.0F : (double)0.0F;
         double var24 = this.IlIllIl(var20, var22, (double)18.0F);
         this.IIlIlI.put(var18, var24);
         double var26 = var1 + (double)18.0F + var24;
         double var28 = var13 - (double)6.0F;
         double var30 = (double)92.0F;
         double var32 = 0.85;
         double var34 = IIIIIIllI.lllIII(this.field_22793);
         double var36 = var28 + (var7 - var34 * var32) * (double)0.5F;
         <undefinedtype> var38 = var18 == IIIlIlIII.l ? x.lIlIII.l(llIIlII(481449062, -534771631)) : var18.I();
         double var39 = lIllIIl(var28, var7);
         double var41 = var26 + (double)20.0F;
         double var43 = var22 <= (double)0.0F ? (double)0.0F : var24 / var22;
         if (var43 > 0.01) {
            int var45 = this.lIlllIl(this.IlIllI.lI(), var1 + (double)10.0F, var28, 0);
            int var46 = (int)(var43 * (double)150.0F);
            int var47 = var45 & llIIIll(-1645453085, -124523328) | var46 << llIIIll(-1645453088, -2108733045);
            IIIIIIllI.IllIll(this.lIIIIl(), var1 + (double)10.0F, var28, var30, var7, (double)6.0F, var47);
         }

         byte var51 = -1;
         byte var52 = -1;
         IIIIIIllI.IIIllI(this.lIIIIl());

         try {
            IIIIIIllI.IlII(this.lIIIIl(), var41, var36);
            IIIIIIllI.lllI(this.lIIIIl(), var32, var32);
            this.IlIllI.IIIll(var38, (double)0.0F, (double)0.0F, var51);
         } finally {
            IIIIIIllI.lIIlIl(this.lIIIIl());
         }

         this.IlIllI.IlIIl(var18, var26, var39, var52);
         this.lIIlIl.III(var1 + (double)18.0F - (double)8.0F, var28, var30, var7, (var2, var3x) -> {
            this.IIIIIlI();
            this.lIIlll.lIl = var18;
            this.lll = false;
            this.llIlI = null;
            this.IIllI();
            return true;
         });
         var13 += var7 + var9;
      }

   }

   private void lIIIllI(class_332 var1, double var2, double var4, double var6, double var8) {
      this.IlIlII = var2;
      this.llIIll = var4;
      this.IlIIl = var6;
      this.lIIII = var8;
      boolean var10 = this.lll;
      IIIIIIllI.IllIll(this.lIIIIl(), var2, var4, var6, var8, (double)6.0F, llIIIll(-1645453087, -1765618121));
      double var11 = (double)14.0F;
      double var13 = var2 + (double)7.0F;
      double var15 = var2 + (double)25.0F;
      double var17 = Math.max((double)10.0F, var6 - (double)32.0F);
      int var19 = !this.IIllIl.isBlank() ? this.IlIllI.IllIl() : this.IlIllI.IIIlII();
      this.IlIllI.IIIIIl(var13, var4 + Math.max((double)0.0F, (var8 - var11) * (double)0.5F), var19);
      if (var10) {
         String var20 = this.IIllIl;
         double var21 = (double)this.IlIllI.IIl(var20);
         double var23 = Math.max((double)0.0F, var21 - var17);
         double var25 = var15 - var23;
         double var27 = this.IIllllI(var4, var8);
         IIIIIIllI.IllIII(this.lIIIIl(), var15, var4 + (double)1.0F, var2 + var6 - (double)4.0F, var4 + var8 - (double)1.0F);

         try {
            if (this.llIlII && !var20.isEmpty()) {
               int var29 = lllIIlI.III().getRGB();
               IIIIIIllI.IllIll(this.lIIIIl(), var25 - (double)1.0F, var27 - (double)1.0F, var21 + (double)2.0F, IIIIIIllI.lllIII(this.field_22793) + (double)2.0F, (double)2.0F, var29 & llIIIll(-1645453082, -638665723) | llIIIll(-1645453081, -2036716482));
            }

            this.IlIllI.llIII(var20, var25, var27, var19);
         } finally {
            IIIIIIllI.lIII(this.lIIIIl());
         }

         double var35 = Math.min(var2 + var6 - (double)6.0F, var25 + var21);
         this.lIlllI(var35, var4 + (var8 - (double)12.0F) * (double)0.5F, (double)12.0F);
         this.II(var1);
      } else {
         String var33 = this.IIllIl.isBlank() ? x.lIlIII.Il(llIIlII(481449063, -1220980751)) : this.IIllIl;
         String var34 = this.IlIllI.IIlll(var33, var17);
         this.IlIllI.llIII(var34, var15, this.IIllllI(var4, var8), var19);
      }

      this.lIIlIl.III(var2, var4, var6, var8, (var1x, var2x) -> {
         this.lll = true;
         this.llIlI = null;
         this.llIlII = false;
         return true;
      });
   }

   private double lIIIlll(IIIIIIIlI var1) {
      double var2 = (double)27.0F;

      for(llllllI var5 : var1.IIIlll()) {
         var2 += this.IllII(var1, var5);
      }

      if (var1 != null && var1.IIlIlIl()) {
         var2 += (double)27.0F;
      }

      if (var1 instanceof llIIIlII var6) {
         var2 += this.lIllII(var6);
      }

      return var2;
   }

   public void method_25394(class_332 var1, int var2, int var3, float var4) {
      boolean var5 = false;
      if (!var5 && this.lIII != null) {
         try {
            this.lIII.method_25394(var1, var2, var3, var4);
         } catch (Throwable var31) {
         }
      }

      this.lIIllI = false;
      lIIIllll var6 = this.IIIIl.IIl().IIII();
      this.llIIIII();
      int var7 = this.Il.I();
      int var8 = this.Il.lI();
      int var9 = (int)Math.round(this.Il.Il((double)var2));
      int var10 = (int)Math.round(this.Il.l((double)var3));
      this.lIIlllI();
      if (this.IlIIIIl(System.nanoTime())) {
         this.IlIIIlI();
      } else {
         this.lIIlll.Illl = var6.lIlII();
         this.lIIlll.lIlI(var7, var8);
         if (this.ll && this.lIIlll.lIl != IIIlIlIII.l) {
            this.lIIlll.IIIl(var7, var8);
            this.ll = false;
            this.IIllI();
         } else if (this.ll) {
            this.ll = false;
         }

         double var11 = this.IIIII((double)var9);
         double var13 = this.IIIIIll((double)var10);
         this.Illll = var11;
         this.lIIIl = var13;
         this.IllIIl = var1;
         this.lIIlIl.I();
         this.lIlIll = null;
         IIIIIIllI.IIIII(var1);
         this.IlIllI.lIIII(var1, this.field_22793, var6);
         Boolean var15 = IIIIIIllI.IIIll(false);
         IIIIIIllI.IIIllI(var1);

         try {
            IIIIIIllI.lllI(var1, this.Il.ll(), this.Il.II());
            if (!var5) {
               this.IlIllI.IIlIl(var7, var8);
               if (var6.lIllI()) {
                  this.lllIIl(var1, var6);
               }
            }

            if (this.lIIlll.lIl == IIIlIlIII.l) {
               this.Illllll(var1, var9, var10, var4);
            } else {
               double var16 = this.Illll();
               double var18 = this.lIIlll.IIlI + this.lIIlll.IlIl * (double)0.5F;
               double var20 = this.lIIlll.lIll + this.lIIlll.III * (double)0.5F;
               IIIIIIllI.IIIllI(var1);

               try {
                  IIIIIIllI.IlII(var1, var18, var20);
                  IIIIIIllI.lllI(var1, var16, var16);
                  IIIIIIllI.IlII(var1, -var18, -var20);
                  this.llIIl(var1, (int)Math.round(var11), (int)Math.round(var13), var4);
                  this.lIIIIlI(var1);
               } finally {
                  IIIIIIllI.lIIlIl(var1);
               }
            }

            IIIIIIllI.IIIII(var1);
            this.IIlIlll(var1);
            this.IIIIlll(var1);
            this.IlIIIl(var1);
            IIIIIIllI.IIIII(var1);
         } finally {
            IIIIIIllI.lIIlIl(var1);
            IIIIIIllI.IIl(var15);
         }

         IIIIIIllI.IIIII(var1);
      }
   }

   private boolean lIIlIlI(int var1) {
      return this.field_22787 != null && this.field_22787.method_22683() != null && GLFW.glfwGetKey(this.field_22787.method_22683().method_4490(), var1) == 1;
   }

   private List<String> lIIlIll(double var1) {
      String var3 = this.IIlIII == null ? x.lIlIII.Il(llIIlII(481449056, -1036686813)) : this.IIlIII;
      return this.IlllIII(var3, Math.max((double)80.0F, var1 - (double)22.0F));
   }

   private double lIIllIl(double var1, double var3, double var5) {
      double var7 = (double)6.0F;
      <undefinedtype>[] var9 = null.values();
      double var10 = Math.max((double)58.0F, (var5 - var7 * (double)(var9.length - 1)) / (double)var9.length);
      double var12 = var1;

      for(<undefinedtype> var17 : var9) {
         boolean var18 = this.IIIlI == var17;
         int var19 = var18 ? llIIIll(-1645453084, 1518855430) : llIIIll(-1645453083, -1977648673);
         IIIIIIllI.IllIll(this.lIIIIl(), var12, var3, var10, (double)22.0F, (double)6.0F, var19);
         <undefinedtype> var20 = this.IlIllI.lIIl(var17.l(), var10 - (double)8.0F);
         double var21 = var12 + (var10 - (double)this.IlIllI.lIII(var20)) * (double)0.5F;
         double var23 = this.IIllllI(var3, (double)22.0F);
         Runnable var25 = () -> this.IlIllI.IIIll(var20, var21, var23, var18 ? this.IlIllI.IllIl() : this.IlIllI.IIIlII());
         if (var18) {
            IIIIIIllI.IlIIll(true, var25);
         } else {
            var25.run();
         }

         this.lIIlIl.III(var12, var3, var10, (double)22.0F, (var2, var3x) -> {
            this.IIIlI = var17;
            this.lIlIll(this.lIIlll.II);
            this.IIllI();
            return true;
         });
         var12 += var10 + var7;
      }

      return var3 + (double)22.0F;
   }

   private void lIIlllI() {
      long var1 = System.nanoTime();
      if (this.IllI <= 0L) {
         this.IllI = var1;
         this.IIlIIl = 0.016666666666666666;
      } else {
         this.IIlIIl = Math.max(0.004166666666666667, Math.min(0.05, (double)(var1 - this.IllI) / (double)1.0E9F));
         this.IllI = var1;
      }

      this.lIllll = this.IlIllIl(this.lIllll, this.IIIIIl ? (double)0.0F : (double)1.0F, this.IIIIIl ? (double)60.0F : (double)9.0F);
      if (this.lIIlll.II != this.IIlIll || this.IIIlI != this.llIlIl) {
         this.IIlIll = this.lIIlll.II;
         this.llIlIl = this.IIIlI;
         this.lIlI = (double)0.0F;
      }

      this.lIlI += this.IIlIIl;
      if (this.lIIllI) {
         if (this.IlllII < (double)0.0F) {
            this.IlllII = this.llIIlI;
            this.IIlllI = this.IIIII;
            this.IllllI = this.IlIll;
         } else if (!(Math.abs(this.IlllII - this.llIIlI) > (double)40.0F) && !(Math.abs(this.IIlllI - this.IIIII) > (double)40.0F)) {
            this.IlllII = this.IlIllIl(this.IlllII, this.llIIlI, (double)22.0F);
            this.IIlllI = this.IlIllIl(this.IIlllI, this.IIIII, (double)22.0F);
            this.IllllI = this.IlIllIl(this.IllllI, this.IlIll, (double)22.0F);
         } else {
            this.IlllII = this.llIIlI;
            this.IIlllI = this.IIIII;
            this.IllllI = this.IlIll;
         }

         this.IIllII += this.IIlIIl;
      } else {
         this.IlllII = (double)-1.0F;
         this.IIlllI = (double)-1.0F;
         this.IllllI = (double)-1.0F;
         this.IIllII = (double)0.0F;
      }

   }

   public void method_25393() {
      super.method_25393();
      if (this.IlIIIIl(System.nanoTime())) {
         this.IlIIIlI();
      }

   }

   private double lIlIIIl(double var1, double var3, double var5, Object var7) {
      double var8 = (double)20.0F;
      double var10 = (double)6.0F;
      double var12 = (double)0.0F;

      for(<undefinedtype> var17 : null.values()) {
         if (var12 > (double)0.0F) {
            var12 += var10;
         }

         var12 += Math.max((double)42.0F, (double)this.IlIllI.lIII(var17.ll()) + (double)20.0F);
      }

      double var35 = var1 + Math.max((double)0.0F, (var5 - var12) * (double)0.5F);
      double var36 = var35;
      double var18 = var3;
      double var20 = var35;
      double var22 = var3;
      double var24 = (double)0.0F;

      for(<undefinedtype> var29 : null.values()) {
         double var30 = Math.max((double)42.0F, (double)this.IlIllI.lIII(var29.ll()) + (double)20.0F);
         if (var36 > var1 && var36 + var30 > var1 + var5) {
            var36 = var1;
            var18 += var8 + var10;
         }

         if (var29 == var7) {
            var20 = var36;
            var22 = var18;
            var24 = var30;
         }

         var36 += var30 + var10;
      }

      if (Double.isNaN(this.llII)) {
         this.llII = var20;
         this.Illl = var22;
         this.llIII = var24;
      } else {
         this.llII = this.IlIllIl(this.llII, var20, (double)18.0F);
         this.Illl = this.IlIllIl(this.Illl, var22, (double)18.0F);
         this.llIII = this.IlIllIl(this.llIII, var24, (double)18.0F);
      }

      IIIIIIllI.IllIll(this.lIIIIl(), this.llII, this.Illl, this.llIII, var8, (double)6.0F, this.IlIllI.lllIl(llIIIll(-1645453062, -46717265)));
      var36 = var35;
      var18 = var3;
      double var39 = var3 + var8;

      for(<undefinedtype> var31 : null.values()) {
         double var32 = Math.max((double)42.0F, (double)this.IlIllI.lIII(var31.ll()) + (double)20.0F);
         if (var36 > var1 && var36 + var32 > var1 + var5) {
            var36 = var1;
            var18 += var8 + var10;
         }

         boolean var34 = var31 == var7;
         IIIIIIllI.IllIll(this.lIIIIl(), var36, var18, var32, var8, (double)6.0F, var34 ? 0 : llIIIll(-1645453061, -616927140));
         this.IlIllI.lIl(var31.ll(), var36 + var32 * (double)0.5F, this.IIllllI(var18, var8), var34 ? this.IlIllI.IllIl() : this.IlIllI.IIIlII(), var32 - (double)10.0F);
         this.lIIlIl.III(var36, var18, var32, var8, (var2, var3x) -> {
            this.lIIlll.lll = var31;
            this.lIIlll.IllI = (double)0.0F;
            this.IIIlII.clear();
            this.llllI.clear();
            this.IIllI();
            return true;
         });
         var39 = Math.max(var39, var18 + var8);
         var36 += var32 + var10;
      }

      return var39;
   }

   private long lIlIIlI(lIllII var1) {
      return 256L + (var1 == null ? 0L : (long)var1.ordinal() + 1L);
   }

   private boolean lIlIIll() {
      if (!this.lIIlII && this.II == null && this.lIllIl == null) {
         <undefinedtype> var1 = this.IIIIl.II().ll();
         return var1 != null && var1.ll() && var1.III() != null && var1.lI() != null;
      } else {
         return false;
      }
   }

   private void lIlIlII() {
      Path var1 = this.IIIIl.lI().IIllI();
      if (var1 != null) {
         class_156.method_668().method_60932(var1);
         this.IIIIll = x.lIlIII.Il(llIIlII(481449057, -1007458893));
      }

   }

   private void lIlIlll(IIllIlIII var1, double var2, boolean var4) {
      double var5 = IlIIlIll.IlIlI((var2 - this.IIllll) / Math.max((double)1.0F, this.IIll), (double)0.0F, (double)1.0F);
      Color var7 = (Color)var1.III();
      if (var4) {
         var1.Il(new Color(var7.getRed(), var7.getGreen(), var7.getBlue(), (int)Math.round(var5 * (double)255.0F)));
      } else {
         int var8 = Color.HSBtoRGB((float)var5, 0.65F, 1.0F);
         var1.Il(new Color(var8 >> llIIIll(-1645453064, -131886452) & llIIIll(-1645453063, -565480295), var8 >> llIIIll(-1645453058, -651901667) & llIIIll(-1645453057, 722200158), var8 & llIIIll(-1645453060, -775518754), var7.getAlpha()));
      }

      this.IlIll();
   }

   private static double lIllIIl(double var0, double var2) {
      return var0 + Math.max((double)0.0F, (var2 - (double)14.0F) * (double)0.5F);
   }

   private int lIlllIl(int var1, double var2, double var4, int var6) {
      int var7 = var1 >>> llIIIll(-1645453059, -549626447) & llIIIll(-1645453070, -778706174);
      return var7 > 0 && (var1 & llIIIll(-1645453069, 841012736)) != 0 ? IIIIIIllI.lIIlI(var7, (int)Math.round(var2), (int)Math.round(var4), var6) : var1;
   }

   private void lIlllll(llllllI<?> var1, double var2, double var4, double var6, String var8) {
      String var9 = var8 == null ? "" : var8;
      <undefinedtype> var10 = (<undefinedtype>)this.IllIl.computeIfAbsent(var1, (var1x) -> (<undefinedtype>)(new Object(var9) {
            private String I;
            private String l;
            private double II = (double)1.0F;

            private {
               this.l = var1;
            }
         }));
      if (!var9.equals(var10.l)) {
         var10.I = var10.l;
         var10.l = var9;
         var10.II = (double)0.0F;
      } else if (var10.II < (double)1.0F) {
         var10.II = Math.min((double)1.0F, var10.II + this.IIlIIl * (double)8.5F);
      }

      this.IlIllI.IIIIlI(var2, var4, var6, (double)20.0F, var10.I, var10.l, var10.II, 0.82);
   }

   private void llIIIII() {
      if (this.field_22787 != null && this.field_22787.method_22683() != null) {
         this.Il = llllII(this.field_22789, this.field_22790, this.field_22787.method_22683().method_4489(), this.field_22787.method_22683().method_4506());
      } else {
         this.Il = llllII(this.field_22789, this.field_22790, this.field_22789, this.field_22790);
      }
   }

   private boolean llIIIlI() {
      return this.lIIlIlI(llIIIll(-1645453072, -1404841026)) || this.lIIlIlI(llIIIll(-1645453071, -851097080)) || this.lIIlIlI(llIIIll(-1645453066, 993188577)) || this.lIIlIlI(llIIIll(-1645453065, 625998352));
   }

   private static int llIIIll(int var0, int var1) {
      return llIlll[var0 ^ -1645453238] ^ var1 ^ var0;
   }

   private static String llIIlII(int var0, int var1) {
      int var3 = var0 ^ 481449204;
      char[] var4 = lllIII[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])lllIIl[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         lllIIl[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -902579851;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 145;
               break;
            case 1:
               var9 = 204;
               break;
            case 2:
               var9 = 186;
               break;
            case 3:
               var9 = 22;
               break;
            case 4:
               var9 = 45;
               break;
            case 5:
               var9 = 100;
               break;
            case 6:
               var9 = 245;
               break;
            case 7:
               var9 = 124;
               break;
            case 8:
               var9 = 219;
               break;
            case 9:
               var9 = 133;
               break;
            case 10:
               var9 = 225;
               break;
            case 11:
               var9 = 155;
               break;
            case 12:
               var9 = 161;
               break;
            case 13:
               var9 = 97;
               break;
            case 14:
               var9 = 40;
               break;
            case 15:
               var9 = 42;
               break;
            case 16:
               var9 = 229;
               break;
            case 17:
               var9 = 52;
               break;
            case 18:
               var9 = 24;
               break;
            case 19:
               var9 = 133;
               break;
            case 20:
               var9 = 0;
               break;
            case 21:
               var9 = 83;
               break;
            case 22:
               var9 = 170;
               break;
            case 23:
               var9 = 234;
               break;
            case 24:
               var9 = 129;
               break;
            case 25:
               var9 = 174;
               break;
            case 26:
               var9 = 141;
               break;
            case 27:
               var9 = 16;
               break;
            case 28:
               var9 = 78;
               break;
            case 29:
               var9 = 116;
               break;
            case 30:
               var9 = 114;
               break;
            case 31:
               var9 = 48;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
