package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import y.IIlIl;

@Environment(EnvType.CLIENT)
public final class IIllIllIl extends IIIIIIIlI {
   private static String[] I;
   private static final int[] l;
   private static final String[] II;
   private static final Object[] Il;

   private static void ll() {
      I[0] = IlI(llI((short)'뗐', -1536418624, 44592).toCharArray(), 40281L, lII(-795614737, 839775054));
      I[1] = IlI(llI((short)'遌', -694540108, 44593).toCharArray(), 92984L, lII(-795614738, 1641415504));
   }

   static {
      short var6 = 27328;
      String var7 = "두훳\ue370▙\uf2e2\ue90a즾ꓸ쐭㹴巬徱썓獳媈㶙咘䏷䦭䕺ﱨ䀰괉\ude76䓰欥췀⒓\udb28བྷđ虢⇍睮ଃ㝞麲\ue33a筒\uec83땋航샙縨\ud8cc퀐\udab3꣺\ue234娫扈\uf498頹ᄑ\ue9ce뺛礒褕쀊┅笾옎뵿Ⳟ";
      char[] var8 = "櫰櫐".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            II = var9;
            Il = new Object[var9.length];
            int var2 = 48125398;
            byte[] var0 = "\u008bwæ\u0096õ\nv¡ÞÙ]á#R1S".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            l = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               l[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            I = new String[2];
            ll();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 42;
                     break;
                  case 1:
                     var10000 = 2;
                     break;
                  case 2:
                     var10000 = 118;
                     break;
                  case 3:
                     var10000 = 40;
                     break;
                  case 4:
                     var10000 = 51;
                     break;
                  case 5:
                     var10000 = 74;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (var1 != null && var1.field_1724 != null) {
         ((IIlIl)var1.field_1724).ilovcats$setJumpingCooldown(0);
      }

   }

   public IIllIllIl() {
      super((Object)lIlIII.l(I[1]), lIllII.III, (Object)lIlIII.l(I[0]));
   }

   private static String IlI(char[] var0, long var1, int var3) {
      int var4 = lII(-795614739, 539894815) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & lII(-795614740, -249592426);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private static int lII(int var0, int var1) {
      return l[var0 ^ -795614737] ^ var1 ^ var0;
   }

   private static String llI(short var0, int var1, int var2) {
      int var3 = var2 ^ '기';
      char[] var4 = II[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])Il[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         Il[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 1088;
      int var9 = 0;

      do {
         int var10 = var4[var9] ^ '鋠';
         var10 -= 57582;
         var10 -= 38960;
         var10 += 20997;
         var10 += 48263;
         var10 += 53573;
         var10 ^= 43774;
         var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
