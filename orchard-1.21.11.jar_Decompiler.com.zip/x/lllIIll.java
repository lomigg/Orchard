package x;

public final class lllIIll {
   private static final int[] I;

   public static double I(double var0, double var2, double var4) {
      return Math.max(var2, Math.min(var4, var0));
   }

   public static int l(int var0, int var1) {
      return llI(var1, 0, IlIl(1747434546, 1796182962)) << IlIl(1747434547, 862821812) | var0 & IlIl(1747434544, 298129340);
   }

   public static double II(double var0, double var2, double var4, double var6) {
      double var8 = I(var6 * var4, (double)0.0F, (double)1.0F);
      return ((double)1.0F - var8) * var0 + var8 * var2;
   }

   public static <undefinedtype> Il(double var0, double var2, double var4, double var6, double var8, double var10) {
      double var12 = Double.isFinite(var0) ? var0 : (double)0.0F;
      double var14 = Double.isFinite(var2) ? var2 : (double)0.0F;
      double var16 = Double.isFinite(var4) ? Math.max((double)0.0F, var4) : (double)0.0F;
      double var18 = Double.isFinite(var6) ? Math.max((double)0.0F, var6) : (double)0.0F;
      double var20 = Double.isFinite(var8) ? Math.max((double)0.0F, var8) : (double)0.0F;
      double var22 = Double.isFinite(var10) ? Math.max((double)0.0F, var10) : (double)0.0F;
      double var24 = Math.max((double)0.0F, var20 - var16);
      double var26 = Math.max((double)0.0F, var22 - var18);
      return new Record(I(var12, (double)0.0F, var24), I(var14, (double)0.0F, var26), var16, var18) {
         private final double I;
         private final double l;
         private final double II;
         private final double Il;

         public double I() {
            return this.I;
         }

         public double l() {
            return this.II;
         }

         public double II() {
            return this.Il;
         }

         public {
            this.I = var1;
            this.l = var3;
            this.Il = var5;
            this.II = var7;
         }

         public double Il() {
            return this.l;
         }
      };
   }

   public static double lI(double var0, double var2, double var4) {
      return lIl(var0, var2, I(var4, (double)0.0F, (double)1.0F));
   }

   private static int ll(int var0, int var1, int var2, double var3) {
      int var5 = var0 >>> var2 & IlIl(1747434545, 1747784579);
      int var6 = var1 >>> var2 & IlIl(1747434550, -1165302859);
      return llI((int)lIl((double)var5, (double)var6, var3), 0, IlIl(1747434551, -821337591));
   }

   public static <undefinedtype> III(Object var0, Iterable<<undefinedtype>> var1, double var2, double var4) {
      if (var0 != null && var1 != null && !(var4 <= (double)0.0F)) {
         double var6 = var0.I();
         double var8 = var0.Il();
         boolean var10 = var6 + var0.II() * (double)0.5F >= var2 * (double)0.5F;

         for(<undefinedtype> var12 : var1) {
            if (var12 != null && !var12.equals(var0)) {
               if (var10) {
                  double var13 = var12.I() + var12.II();
                  double var15 = var6 + var0.II();
                  if (Math.abs(var13 - var15) < var4) {
                     var6 = var13 - var0.II();
                  }
               } else if (Math.abs(var12.I() - var6) < var4) {
                  var6 = var12.I();
               }

               if (Math.abs(var12.Il() - var8) < var4) {
                  var8 = var12.Il();
               }
            }
         }

         return new Record(var6, var8, var0.II(), var0.l()) {
            private final double I;
            private final double l;
            private final double II;
            private final double Il;

            public double I() {
               return this.I;
            }

            public double l() {
               return this.II;
            }

            public double II() {
               return this.Il;
            }

            public {
               this.I = var1;
               this.l = var3;
               this.Il = var5;
               this.II = var7;
            }

            public double Il() {
               return this.l;
            }
         };
      } else {
         return var0;
      }
   }

   public static double IIl(double var0, double var2, double var4, double var6) {
      double var8 = Ill(var0, (double)0.0F);
      double var10 = IlI(var4, (double)1.0F);
      double var12 = IlI(var6, (double)0.0F);
      double var14 = Math.max((double)0.0F, var10 - var12);
      double var16 = Ill(var2, var14);
      return var8 * Math.max(var16, var14);
   }

   private static double IlI(double var0, double var2) {
      return Double.isFinite(var0) ? var0 : var2;
   }

   private static double Ill(double var0, double var2) {
      return Double.isFinite(var0) && var0 > (double)0.0F ? var0 : var2;
   }

   public static float lII(float var0, float var1, float var2) {
      float var3 = (float)I((double)var2, (double)0.0F, (double)1.0F);
      float var4 = Math.max(var0, var1) - Math.min(var0, var1);
      float var5 = var4 * var3;
      return var1 + (var0 > var1 ? var5 : -var5);
   }

   public static double lIl(double var0, double var2, double var4) {
      return var0 + (var2 - var0) * var4;
   }

   public static int llI(int var0, int var1, int var2) {
      return Math.max(var1, Math.min(var2, var0));
   }

   private lllIIll() {
   }

   public static boolean lll(double var0, double var2, double var4, double var6, double var8, double var10) {
      double var12 = Math.min(var4, var4 + var8);
      double var14 = Math.max(var4, var4 + var8);
      double var16 = Math.min(var6, var6 + var10);
      double var18 = Math.max(var6, var6 + var10);
      return var0 > var12 && var0 < var14 && var2 > var16 && var2 < var18;
   }

   public static int IIII(int var0, int var1, double var2) {
      double var4 = I(var2, (double)0.0F, (double)1.0F);
      int var6 = ll(var0, var1, IlIl(1747434548, -838116650), var4);
      int var7 = ll(var0, var1, IlIl(1747434549, -2135236052), var4);
      int var8 = ll(var0, var1, IlIl(1747434554, 872343050), var4);
      int var9 = ll(var0, var1, 0, var4);
      return var6 << IlIl(1747434555, -721721608) | var7 << IlIl(1747434552, 1958640157) | var8 << IlIl(1747434553, -1515768811) | var9;
   }

   public static double IIIl(double var0, double var2, double var4, double var6) {
      double var8 = Ill(var0, (double)0.0F);
      double var10 = IlI(var4, (double)1.0F);
      double var12 = IlI(var6, (double)0.0F);
      double var14 = Math.max((double)0.0F, var10 - var12);
      double var16 = Math.max(Ill(var2, var14), var14);
      return var8 * (var10 + (var16 - var14) * (double)0.5F);
   }

   public static int IIlI(int var0, double var1) {
      int var3 = var0 >>> IlIl(1747434558, -1445840730) & IlIl(1747434559, 1587775708);
      return l(var0, (int)((double)var3 * I(var1, (double)0.0F, (double)1.0F)));
   }

   public static <undefinedtype> IIll(double var0, double var2, double var4, double var6, double var8, double var10) {
      if (Double.isFinite(var0) && Double.isFinite(var2) && Double.isFinite(var4) && Double.isFinite(var6) && Double.isFinite(var8) && Double.isFinite(var10)) {
         double var12 = var4 < (double)0.0F ? var0 + var4 : var0;
         double var14 = var6 < (double)0.0F ? var2 + var6 : var2;
         double var16 = Math.abs(var4);
         double var18 = Math.abs(var6);
         if (!(var16 <= (double)0.0F) && !(var18 <= (double)0.0F)) {
            double var20 = Math.min(var16, var18) * (double)0.5F;
            return new Record(var12, var14, var16, var18, I(var8, (double)0.0F, var20), I(var10, (double)0.0F, var20)) {
               private final double I;
               private final double l;
               private final double II;
               private final double Il;
               private static final <undefinedtype> lI = new <anonymous constructor>((double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F);
               private final double ll;
               private final double III;

               public double I() {
                  return this.II;
               }

               public boolean l() {
                  return this.II > (double)0.0F && this.l > (double)0.0F;
               }

               public double II() {
                  return this.l;
               }

               public double Il() {
                  return this.I;
               }

               public double lI() {
                  return this.III;
               }

               public double ll() {
                  return this.Il;
               }

               public {
                  this.Il = var1;
                  this.ll = var3;
                  this.II = var5;
                  this.l = var7;
                  this.III = var9;
                  this.I = var11;
               }

               public double III() {
                  return this.ll;
               }
            };
         } else {
            return null.lI;
         }
      } else {
         return null.lI;
      }
   }

   public static double IlII(double var0, double var2, double var4) {
      return var0 + (var2 - var0) * I(var4, (double)0.0F, (double)1.0F);
   }

   private static int IlIl(int var0, int var1) {
      return I[var0 ^ 1747434546] ^ var1 ^ var0;
   }

   static {
      int var2 = 914416780;
      byte[] var0 = "5¨ËómÊÅ\u0013O\u009d°ÿ6\u008aKÁä-»ð\u0091¬:M\u0090¬\u0002vÞ\u001dº\u0085mY¾´\u008a\\>W*\u0019\"¹û\u0000l¨÷u`\f\u0000\u0004Ð\u0090".getBytes("ISO-8859-1");
      int var1 = var0.length / 4;
      I = new int[var1];
      int var3 = 0;
      int var4 = 0;

      do {
         int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
         var5 ^= var2;
         I[var4] = var5;
         var3 += 4;
         ++var4;
      } while(var4 < var1);

   }
}
