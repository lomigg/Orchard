package x;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpClient.Redirect;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1060;
import net.minecraft.class_12079;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_5250;
import net.minecraft.class_640;
import net.minecraft.class_7417;
import net.minecraft.class_7920;
import net.minecraft.class_8685;
import net.minecraft.class_8828;

@Environment(EnvType.CLIENT)
public final class llIl extends IIIIIIIlI {
   private volatile Pattern I;
   private static final int l = 262144;
   private static final <undefinedtype> II;
   private String Il;
   private UUID lI;
   private final lIlIlllI ll;
   private static final <undefinedtype> III;
   private volatile Object IIl;
   private final lIIIIl IlI;
   private static final <undefinedtype> Ill;
   private final IlIIIlIlI<<undefinedtype>> lII;
   private static final int lIl = 512;
   private Pattern llI;
   private final lIlIlllI lll;
   private String IIII;
   private static volatile llIl IIIl;
   private final Map<UUID, Integer> IIlI;
   private final Map<String, CompletableFuture<Object>> IIll;
   private final IlIIIlIlI<<undefinedtype>> IlII;
   private volatile boolean IlIl;
   private final IlIIIlIlI<<undefinedtype>> IllI;
   private String Illl;
   private volatile Map<String, String> lIII;
   private final IlIIIlIlI<<undefinedtype>> lIIl;
   private final lIIIIl lIlI;
   private String lIll;
   private static final int llII = 64;
   private long llIl;
   private String lllI;
   private String llll;
   private final IlIIIlIlI<<undefinedtype>> IIIII;
   private final IlIIIlIlI<<undefinedtype>> IIIIl;
   private final Map<String, String> IIIlI;
   private String IIIll;
   private static final int IIlII = 512;
   private final IlIIIlIlI<<undefinedtype>> IIlIl;
   private static final <undefinedtype> IIllI;
   private static final HttpClient IIlll;
   private final IlIIIlIlI<<undefinedtype>> IlIII;
   private String IlIIl;
   private final AtomicInteger IlIlI;
   private static final int[] IlIll;
   private static final String[] IllII;
   private static final Object[] IllIl;

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (var1.field_1724 != null) {
         String var2 = this.IlII(var1);
         this.llll = var2;
         this.IIIIl(var1);
         String var3 = this.IlIIl();
         if ((Boolean)this.IlI.III() && !var3.isBlank() && !var2.isBlank() && !var3.equalsIgnoreCase(var2)) {
            if (!var3.equalsIgnoreCase(this.IIIll) || System.currentTimeMillis() - this.llIl >= 5000L) {
               if (!var3.equalsIgnoreCase(this.IIII) && !this.IlIl) {
                  this.IIII = var3;
                  this.IIl = null;
                  this.IlIl = true;
                  this.IlI(var1, var3).whenComplete((var3x, var4) -> var1.execute(() -> {
                        this.IlIl = false;
                        if (var3.equalsIgnoreCase(this.IIII) && (Boolean)this.IlI.III()) {
                           if (var4 == null && var3x != null) {
                              this.IIl = var3x;
                              this.IIIll = "";
                              this.llIl = 0L;
                           } else {
                              this.IIl = null;
                              this.IIIll = var3;
                              this.llIl = System.currentTimeMillis();
                              this.IIII = "";
                           }
                        }
                     }));
               }
            }
         } else {
            this.II();
         }
      }
   }

   private Pattern I(List<<undefinedtype>> var1) {
      if (var1.isEmpty()) {
         return null;
      } else {
         StringBuilder var2 = new StringBuilder();

         for(<undefinedtype> var4 : var1) {
            if (var2.length() > 0) {
               var2.append((char)IllIII(-718681405, 516103447));
            }

            var2.append(Pattern.quote(var4.l()));
         }

         String var10000 = lIlIII.Il(IllIIl(12526, 777071924, 'ᾓ'));
         String var10001 = lIlIII.Il(IllIIl(12527, 229845364, '嬻'));
         String var10002 = String.valueOf(var2);
         String var10003 = lIlIII.Il(IllIIl(12524, 201144062, '뀷'));
         String var9 = lIlIII.Il(IllIIl(12525, -1561299975, 'ᄎ'));
         String var8 = var10003;
         String var7 = var10002;
         String var6 = var10001;
         String var5 = var10000;
         return Pattern.compile(var5 + var6 + var7 + var8 + var9);
      }
   }

   private void II() {
      this.IIl = null;
      this.IlIl = false;
      this.IIII = "";
   }

   private <undefinedtype> ll(class_2561 var1, String var2, String var3) {
      Object var4 = var1.method_10851();
      boolean var5 = false;
      class_2583 var6 = var1.method_10866();
      if (var4 instanceof class_8828 var7) {
         if (!this.llII(var6)) {
            String var8 = var7.comp_737();
            if (var8 != null && var8.contains(var2)) {
               String var9 = var8.replace(var2, var3);
               if (!var8.equals(var9)) {
                  var4 = class_8828.method_54232(var9);
                  var5 = true;
               }
            }
         }
      }

      class_5250 var11 = class_5250.method_43477((class_7417)var4).method_10862(var6);

      for(class_2561 var13 : var1.method_10855()) {
         <undefinedtype> var10 = this.ll(var13, var2, var3);
         var11.method_10852(var10.l());
         var5 |= var10.I();
      }

      return new Record((class_2561)(var5 ? var11 : var1), var5) {
         private final boolean I;
         private final class_2561 l;

         public boolean I() {
            return this.I;
         }

         public class_2561 l() {
            return this.l;
         }

         private {
            this.l = var1;
            this.I = var2;
         }
      };
   }

   private CompletableFuture<Object> IlI(class_310 var1, String var2) {
      if (this.IIIIll(var2)) {
         return this.IlIll(var1, var2);
      } else {
         class_640 var3 = this.lllIl(var1, var2);
         if (var3 != null) {
            return CompletableFuture.completedFuture(var3.method_52810());
         } else {
            class_1657 var4 = this.IIlIII(var1, var2);
            return var4 != null ? var1.method_1582().method_52863(var4.method_7334()).thenApply((var1x) -> this.IIlIlI(var1x)) : this.IIIIlI(var2).thenCompose((var2x) -> var2x == null ? CompletableFuture.completedFuture((Object)null) : var1.method_1582().method_52863(var2x).thenApply(this::IIlIlI));
         }
      }
   }

   public class_2561 lII(GameProfile var1, class_2561 var2) {
      if (this.IIIIIlI() && var2 != null && var1 != null) {
         if (this.IIIIl.III() == null.l) {
            String var5 = IIIIlII.II(var1);
            if (var5 != null && !var5.isBlank()) {
               String var6 = this.IIlII(var1);
               if (this.ll.lII().lIIl()) {
                  var6 = var5;
               }

               return this.lIIl.III() != null.II ? lIIllllI.IlII(var6, (<undefinedtype>)this.lIIl.III(), (<undefinedtype>)this.IlII.III(), (<undefinedtype>)this.IllI.III(), (<undefinedtype>)this.lII.III(), (<undefinedtype>)this.IIIII.III(), (<undefinedtype>)this.IlIII.III(), (Boolean)this.lIlI.III()) : this.lll(var2, var5, var6);
            } else {
               return var2;
            }
         } else if (!this.IllI(var1)) {
            return var2;
         } else if (this.lIIl.III() != null.II) {
            String var3 = IIIIlII.II(var1);
            String var4 = this.ll.lII().lIIl() ? var3 : this.llIIl();
            return lIIllllI.IlII(var4, (<undefinedtype>)this.lIIl.III(), (<undefinedtype>)this.IlII.III(), (<undefinedtype>)this.IllI.III(), (<undefinedtype>)this.lII.III(), (<undefinedtype>)this.IIIII.III(), (<undefinedtype>)this.IlIII.III(), (Boolean)this.lIlI.III());
         } else {
            return this.lIIll(var2);
         }
      } else {
         return var2;
      }
   }

   private CompletableFuture<GameProfile> llI(String var1) {
      String var2 = URLEncoder.encode(var1, StandardCharsets.UTF_8);
      String var4 = III.lIlI();
      HttpRequest var3 = HttpRequest.newBuilder(URI.create(var4 + var2)).timeout(Duration.ofSeconds(5L)).header(IIllI.lIlI(), Ill.lIlI()).GET().build();
      return IIlll.sendAsync(var3, BodyHandlers.ofString()).thenApply((var1x) -> {
         if (var1x.statusCode() == IllIII(-718681399, -1582323206) && var1x.body() != null && !((String)var1x.body()).isBlank()) {
            JsonObject var2 = JsonParser.parseString((String)var1x.body()).getAsJsonObject();
            if (var2.has(lIlIII.Il(IllIIl(12529, -1339218770, '슿'))) && var2.has(lIlIII.Il(IllIIl(12494, -273538249, '咽')))) {
               UUID var3 = this.IIllll(var2.get(lIlIII.Il(IllIIl(12495, -2139740958, '鰗'))).getAsString());
               return var3 == null ? null : new GameProfile(var3, var2.get(lIlIII.Il(IllIIl(12492, -1390074111, '筭'))).getAsString());
            } else {
               return null;
            }
         } else {
            return null;
         }
      }).exceptionally((var0) -> null);
   }

   private class_2561 lll(class_2561 var1, String var2, String var3) {
      if (var1 != null && var2 != null && !var2.isBlank() && var3 != null) {
         <undefinedtype> var4 = this.ll(var1, var2, var3);
         return (class_2561)(var4.I() ? var4.l() : class_2561.method_43470(var3).method_10862(var1.method_10866()));
      } else {
         return var1;
      }
   }

   private String IIII() {
      return this.llll;
   }

   public llIl() {
      super((Object)lIlIII.l(IllIIl(12522, -1905912697, '貓')), lIllII.ll, (Object)lIlIII.l(IllIIl(12523, -1042542651, '\ue163')));
      this.IIIIl = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IllIIl(12520, 1221284412, '\ueeb7')), <undefinedtype>.class, null.Il));
      this.IIlIl = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IllIIl(12521, 1600475393, '鎥')), <undefinedtype>.class, null.Il));
      this.ll = (lIlIlllI)this.IIIlIll(new lIlIlllI(lIlIII.l(IllIIl(12518, 2077386401, '蠘')), lIlIII.l(IllIIl(12519, -1216993802, '䮸'))));
      this.IlI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IllIIl(12516, -1362210014, '굱')), false));
      this.lll = (lIlIlllI)this.IIIlIll(new lIlIlllI(lIlIII.l(IllIIl(12517, 1720851491, '쮱')), ""));
      this.lIIl = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IllIIl(12514, 2128379695, '\ua632')), <undefinedtype>.class, null.II));
      this.IlII = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IllIIl(12515, -1369685124, '慕')), <undefinedtype>.class, null.ll));
      this.lIlI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IllIIl(12512, 1272842124, '굇')), true));
      this.IllI = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IllIIl(12513, 198925351, '\uf21d')), <undefinedtype>.class, null.Il));
      this.lII = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IllIIl(12542, 1787583166, 'ʟ')), <undefinedtype>.class, null.lI));
      this.IIIII = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IllIIl(12543, 1135607904, '붸')), <undefinedtype>.class, null.II));
      this.IlIII = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IllIIl(12540, 1034752636, '履')), <undefinedtype>.class, null.II));
      this.IIll = new ConcurrentHashMap();
      this.IIlI = new ConcurrentHashMap();
      this.IlIlI = new AtomicInteger();
      this.IIIlI = new LinkedHashMap<String, String>(IllIII(-718681406, 1528184933), 0.75F, true) {
         private static final int[] l;

         protected boolean removeEldestEntry(Map.Entry<String, String> var1) {
            return this.size() > I(-915058812, -2008547846);
         }

         private static int I(int var0, int var1) {
            return l[var0 ^ -915058812] ^ var1 ^ var0;
         }

         static {
            int var2 = 2069959143;
            byte[] var0 = ":S¡\u0099".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            l = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               l[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

         }
      };
      this.IIII = "";
      this.IIIll = "";
      this.Il = "";
      this.Illl = "";
      this.llll = "";
      this.lIll = "";
      this.IlIIl = "";
      this.lIII = Map.of();
      this.lllI = "";
      this.IIlIl.lIII(() -> this.IIIIl.III() == null.I);
      this.IlI.lIII(() -> this.IIIIl.III() != null.l);
      this.lll.lIII(() -> this.IIIIl.III() != null.l && (Boolean)this.IlI.III());
      this.IlII.lIII(() -> this.lIIl.III() != null.II);
      this.lIlI.lIII(() -> this.lIIl.III() != null.II);
      this.IllI.lIII(() -> this.lIIl.III() != null.II);
      this.lII.lIII(() -> this.lIIl.III() != null.II && (Boolean)this.lIlI.III());
      this.IIIII.lIII(() -> this.lIIl.III() != null.II);
      this.IlIII.lIII(() -> this.lIIl.III() != null.II);
      IIIl = this;
   }

   private String IlII(class_310 var1) {
      if (var1.field_1724 == null) {
         return "";
      } else if (this.IIIIl.III() == null.I) {
         class_1657 var2 = this.llIlI(var1);
         if (var2 != null) {
            this.lllII(var2);
            return IIIIlII.II(var2.method_7334());
         } else {
            return this.lllI;
         }
      } else {
         return IIIIlII.II(var1.field_1724.method_7334());
      }
   }

   private boolean IllI(GameProfile var1) {
      class_310 var2 = class_310.method_1551();
      if (var2.field_1724 == null) {
         return false;
      } else if (this.IIIIl.III() == null.I) {
         class_1657 var5 = this.llIlI(var2);
         if (var5 != null) {
            String var4 = IIIIlII.II(var5.method_7334());
            return var5.method_5667().equals(IIIIlII.I(var1)) || !var4.isBlank() && var4.equalsIgnoreCase(IIIIlII.II(var1));
         } else {
            return this.lI != null && this.lI.equals(IIIIlII.I(var1)) || !this.lllI.isBlank() && this.lllI.equalsIgnoreCase(IIIIlII.II(var1));
         }
      } else {
         String var3 = IIIIlII.II(var2.field_1724.method_7334());
         return var2.field_1724.method_5667().equals(IIIIlII.I(var1)) || !var3.isBlank() && var3.equalsIgnoreCase(IIIIlII.II(var1));
      }
   }

   private Object Illl(String var1, byte[] var2) {
      class_310 var3 = class_310.method_1551();
      if (var3 != null && var3.method_1531() != null) {
         class_1011 var4;
         try {
            ByteArrayInputStream var5 = new ByteArrayInputStream(var2);

            try {
               var4 = class_1011.method_4309(var5);
            } catch (Throwable var15) {
               try {
                  var5.close();
               } catch (Throwable var14) {
                  var15.addSuppressed(var14);
               }

               throw var15;
            }

            var5.close();
         } catch (IOException var16) {
            return null;
         }

         if (!this.lIIl(var4)) {
            var4.close();
            return null;
         } else {
            String var10000 = lIlIII.Il(IllIIl(12541, -312065575, '콊'));
            String var10001 = lIlIII.Il(IllIIl(12538, 948009855, '㜎'));
            String var10002 = Integer.toUnsignedString(var1.hashCode());
            String var10003 = lIlIII.Il(IllIIl(12539, -110209523, '⚪'));
            int var10004 = var4.method_4307();
            String var10005 = lIlIII.Il(IllIIl(12536, 1738760966, '\udf1b'));
            int var13 = var4.method_4323();
            String var12 = var10005;
            int var11 = var10004;
            String var10 = var10003;
            String var9 = var10002;
            String var8 = var10001;
            class_2960 var17 = class_2960.method_60655(var10000, var8 + var9 + var10 + var11 + var12 + var13);
            class_1060 var18 = var3.method_1531();
            Objects.requireNonNull(var17);
            var18.method_4616(var17, new class_1043(var17::toString, var4));
            class_12079.class_10726 var6 = new class_12079.class_10726(var17, var17);
            return new class_8685(var6, (class_12079.class_12081)null, (class_12079.class_12081)null, class_7920.field_41123, false);
         }
      } else {
         return null;
      }
   }

   public void lI() {
      this.IIll.clear();
      this.II();
      this.llll = "";
      this.lI = null;
      this.lllI = "";
      this.IIIll = "";
      this.llIl = 0L;
      this.IIlI.clear();
      this.IlIlI.set(0);
      this.lIll = "";
      this.IlIIlI();
   }

   private <undefinedtype> lIII(class_2561 var1) {
      Object var2 = var1.method_10851();
      boolean var3 = false;
      class_2583 var4 = var1.method_10866();
      if (var2 instanceof class_8828 var5) {
         if (!this.llII(var4)) {
            String var6 = var5.comp_737();
            String var7 = this.llIII(var6);
            if (!var6.equals(var7)) {
               var2 = class_8828.method_54232(var7);
               var3 = true;
            }
         }
      }

      class_5250 var9 = class_5250.method_43477((class_7417)var2).method_10862(var4);

      for(class_2561 var11 : var1.method_10855()) {
         <undefinedtype> var8 = this.lIII(var11);
         var9.method_10852(var8.l());
         var3 |= var8.I();
      }

      return new Record((class_2561)(var3 ? var9 : var1), var3) {
         private final boolean I;
         private final class_2561 l;

         public boolean I() {
            return this.I;
         }

         public class_2561 l() {
            return this.l;
         }

         private {
            this.l = var1;
            this.I = var2;
         }
      };
   }

   private boolean lIIl(class_1011 var1) {
      if (var1 == null) {
         return false;
      } else {
         int var2 = var1.method_4307();
         int var3 = var1.method_4323();
         return var2 == IllIII(-718681407, 1359582465) && (var3 == IllIII(-718681408, 958574630) || var3 == IllIII(-718681401, 769873255));
      }
   }

   public void lIlI(class_1297 var1) {
      if (var1 instanceof class_1657 var2) {
         class_310 var3 = class_310.method_1551();
         if (var3.field_1724 != null && var2 != var3.field_1724) {
            this.lI = var2.method_5667();
            this.lllI = IIIIlII.II(var2.method_7334());
            if (this.IIIIl.III() == null.I && this.IIlIl.III() == null.I) {
               this.llll = this.lllI;
            }

         }
      }
   }

   private boolean llII(class_2583 var1) {
      return var1 != null && var1.method_27708() != null;
   }

   public boolean llll() {
      if (this.IIIIl.III() == null.l) {
         return true;
      } else {
         return !this.llll.isBlank();
      }
   }

   private void IIIII(Map<UUID, GameProfile> var1, GameProfile var2) {
      UUID var3 = this.IlIIIl(var2);
      String var4 = IIIIlII.II(var2);
      if (var3 != null && var4 != null && !var4.isBlank()) {
         var1.putIfAbsent(var3, var2);
      }
   }

   private void IIIIl(class_310 var1) {
      if (this.IIIIl.III() != null.l) {
         this.IlIIlI();
      } else {
         this.IIlIIl();
         int var2 = 0;

         for(Integer var4 : this.IIlI.values()) {
            if (var4 != null && var4 > var2) {
               var2 = var4;
            }
         }

         if (var1 != null && var1.field_1724 != null) {
            this.IIlI.putIfAbsent(var1.field_1724.method_5667(), 1);
            var2 = Math.max(var2, 1);
         }

         for(GameProfile var7 : this.IIlIll(var1)) {
            UUID var5 = this.IlIIIl(var7);
            if (var5 != null && (var1 == null || var1.field_1724 == null || !var1.field_1724.method_5667().equals(var5)) && !this.IIlI.containsKey(var5)) {
               ++var2;
               this.IIlI.putIfAbsent(var5, var2);
            }
         }

         this.IlIlI.updateAndGet((var1x) -> Math.max(var1x, var2));
         this.llIll(var1);
      }
   }

   private String IIlII(GameProfile var1) {
      this.IIlIIl();
      UUID var2 = this.IlIIIl(var1);
      if (var2 == null) {
         return this.IIlllI();
      } else {
         class_310 var3 = class_310.method_1551();
         if (var3 != null && var3.field_1724 != null && var3.field_1724.method_5667().equals(var2)) {
            this.IIlI.putIfAbsent(var2, 1);
            this.IlIlI.updateAndGet((var0) -> Math.max(var0, 1));
            String var6 = this.IIlllI();
            return var6 + "1";
         } else {
            this.IlIlI.updateAndGet((var0) -> Math.max(var0, 1));
            Integer var4 = (Integer)this.IIlI.get(var2);
            if (var4 == null) {
               var4 = this.IlIlI.incrementAndGet();
               Integer var5 = (Integer)this.IIlI.putIfAbsent(var2, var4);
               if (var5 != null) {
                  var4 = var5;
               }
            }

            String var7 = this.IIlllI();
            return var7 + var4;
         }
      }
   }

   private Iterable<class_1657> IIlll(class_310 var1) {
      ArrayList var2 = new ArrayList();

      for(class_1297 var4 : var1.field_1687.method_18112()) {
         if (var4 instanceof class_1657 var5) {
            var2.add(var5);
         }
      }

      return var2;
   }

   private String IlIIl() {
      String var1 = this.lll.IlI().trim();
      return var1.isEmpty() ? this.IIlllI() : var1;
   }

   private CompletableFuture<Object> IlIll(class_310 var1, String var2) {
      String var3 = var2.trim();
      this.lIIIl(var3);
      return (CompletableFuture)this.IIll.computeIfAbsent(var3, (var2x) -> {
         CompletableFuture var3 = this.IllIl(var1, var2x);
         var3.thenAccept((var3x) -> {
            if (var3x == null) {
               this.IIll.remove(var2x, var3);
            }

         });
         return var3;
      });
   }

   private CompletableFuture<Object> IllIl(class_310 var1, String var2) {
      HttpRequest var3;
      try {
         var3 = HttpRequest.newBuilder(URI.create(var2)).timeout(Duration.ofSeconds(8L)).header(IIllI.lIlI(), Ill.lIlI()).GET().build();
      } catch (IllegalArgumentException var5) {
         return CompletableFuture.completedFuture((Object)null);
      }

      return IIlll.sendAsync(var3, BodyHandlers.ofByteArray()).thenCompose((var3x) -> {
         if (var3x.statusCode() >= IllIII(-718681403, -1652940098) && var3x.statusCode() < IllIII(-718681404, 1816579100) && var3x.body() != null && ((byte[])var3x.body()).length != 0 && ((byte[])var3x.body()).length <= IllIII(-718681397, -1297871197)) {
            CompletableFuture var4 = new CompletableFuture();
            var1.execute(() -> var4.complete(this.Illl(var2, (byte[])var3x.body())));
            return var4;
         } else {
            return CompletableFuture.completedFuture((Object)null);
         }
      }).exceptionally((var0) -> null);
   }

   private class_1657 IlllI(class_310 var1) {
      if (this.lI == null) {
         return null;
      } else {
         for(class_1657 var3 : this.IIlll(var1)) {
            if (var3.method_5667().equals(this.lI)) {
               this.lllII(var3);
               return var3;
            }
         }

         return null;
      }
   }

   private void lIIIl(String var1) {
      if (this.IIll.size() >= IllIII(-718681398, -1258907420) && !this.IIll.containsKey(var1)) {
         Iterator var2 = this.IIll.keySet().iterator();
         if (var2.hasNext()) {
            this.IIll.remove(var2.next());
         }

      }
   }

   public class_2561 lIIll(class_2561 var1) {
      if (this.IIIIIlI() && var1 != null) {
         if (this.IIIIl.III() == null.l) {
            return this.lIllI(var1);
         } else {
            <undefinedtype> var2 = this.lIII(var1);
            return var2.I() ? var2.l() : var1;
         }
      } else {
         return var1;
      }
   }

   public static llIl lIlIl() {
      llIl var0 = IIIl;
      return var0 != null && var0.IIIIIlI() ? var0 : null;
   }

   private class_2561 lIllI(class_2561 var1) {
      if (this.I != null && !this.lIII.isEmpty()) {
         <undefinedtype> var2 = this.IIllII(var1);
         return var2.I() ? var2.l() : var1;
      } else {
         return var1;
      }
   }

   private class_1657 lIlll(class_310 var1) {
      class_1657 var2 = null;
      double var3 = Double.MAX_VALUE;

      for(class_1657 var6 : this.IIlll(var1)) {
         if (var6 != var1.field_1724 && var6.method_5805() && !var6.method_31481()) {
            double var7 = var1.field_1724.method_5858(var6);
            if (var7 < var3) {
               var3 = var7;
               var2 = var6;
            }
         }
      }

      return var2;
   }

   public void lIl() {
      this.IIll.clear();
      this.IIII = "";
      this.Il = "";
      this.Illl = "";
      this.llI = null;
      this.llll = "";
      this.IIIll = "";
      this.llIl = 0L;
      this.lI = null;
      this.lllI = "";
      this.IIlI.clear();
      this.IlIlI.set(0);
      this.lIll = "";
      this.IlIIlI();
   }

   public String llIII(String var1) {
      if (this.IIIIIlI() && var1 != null && !var1.isEmpty()) {
         if (this.IIIIl.III() == null.l) {
            return this.IlIllI(var1);
         } else {
            String var2 = this.llll;
            String var3 = this.llIIl();
            if (!var2.isBlank() && !var3.isBlank() && !var2.equalsIgnoreCase(var3)) {
               if (!var2.equals(this.Il) || !var3.equals(this.Illl) || this.llI == null) {
                  this.Il = var2;
                  this.Illl = var3;
                  String var10001 = lIlIII.Il(IllIIl(12493, 995239390, '댡'));
                  String var10002 = Pattern.quote(var2);
                  String var6 = lIlIII.Il(IllIIl(12490, 809182776, 'ᕬ'));
                  String var5 = var10002;
                  String var4 = var10001;
                  this.llI = Pattern.compile(var4 + var5 + var6);
               }

               return this.llI.matcher(var1).replaceAll(Matcher.quoteReplacement(var3));
            } else {
               return var1;
            }
         }
      } else {
         return var1;
      }
   }

   private String llIIl() {
      if (this.IIIIl.III() != null.l) {
         return this.IIlllI();
      } else {
         class_310 var1 = class_310.method_1551();
         if (var1 != null && var1.field_1724 != null) {
            return this.IIlII(var1.field_1724.method_7334());
         } else {
            String var2 = this.IIlllI();
            return var2 + "1";
         }
      }
   }

   private class_1657 llIlI(class_310 var1) {
      if (var1.field_1724 != null && var1.field_1687 != null) {
         return this.IIlIl.III() == null.Il ? this.lIlll(var1) : this.IlllI(var1);
      } else {
         return null;
      }
   }

   private void llIll(class_310 var1) {
      ArrayList var2 = new ArrayList();
      LinkedHashMap var3 = new LinkedHashMap();
      StringBuilder var4 = new StringBuilder();

      for(GameProfile var6 : this.IIlIll(var1)) {
         String var7 = IIIIlII.II(var6);
         if (var7 != null && !var7.isBlank()) {
            String var8 = this.IIlII(var6);
            if (var8 != null && !var8.isBlank() && !var7.equals(var8)) {
               var3.put(var7, var8);
               var2.add(new Record(var7, var8) {
                  private final String I;
                  private final String l;

                  public String I() {
                     return this.I;
                  }

                  public String l() {
                     return this.l;
                  }

                  private {
                     this.l = var1;
                     this.I = var2;
                  }
               });
            }
         }
      }

      var2.sort((var0, var1x) -> Integer.compare(var1x.l().length(), var0.l().length()));

      for(<undefinedtype> var13 : var2) {
         var4.append(var13.l()).append('\u0000').append(var13.I()).append('\u0001');
      }

      String var12 = var4.toString();
      if (!var12.equals(this.IlIIl)) {
         this.IlIIl = var12;
         this.lIII = Map.copyOf(var3);
         this.I = this.I(var2);
         synchronized(this.IIIlI) {
            this.IIIlI.clear();
         }
      }
   }

   private void lllII(class_1657 var1) {
      if (var1 != null) {
         this.lI = var1.method_5667();
         this.lllI = IIIIlII.II(var1.method_7334());
      }
   }

   private class_640 lllIl(class_310 var1, String var2) {
      return var1 != null && var1.method_1562() != null && var2 != null && !var2.isBlank() ? var1.method_1562().method_73471(var2) : null;
   }

   public static void llllI() {
      IIIl = null;
   }

   private CompletableFuture<GameProfile> IIIIlI(String var1) {
      return this.llI(var1).thenCompose((var1x) -> var1x == null ? CompletableFuture.completedFuture((Object)null) : this.IIIlIl(var1x));
   }

   private boolean IIIIll(String var1) {
      if (var1 != null && !var1.isBlank()) {
         try {
            URI var2 = URI.create(var1.trim());
            String var3 = var2.getScheme();
            return (lIlIII.Il(IllIIl(12491, 816269244, '됚')).equalsIgnoreCase(var3) || lIlIII.Il(IllIIl(12488, -1225378759, '紥')).equalsIgnoreCase(var3)) && var2.getHost() != null;
         } catch (IllegalArgumentException var4) {
            return false;
         }
      } else {
         return false;
      }
   }

   private CompletableFuture<GameProfile> IIIlIl(GameProfile var1) {
      String var3 = IIIIlII.I(var1).toString().replace(lIlIII.Il(IllIIl(12489, 1989354518, '\ue2e3')), "");
      String var5 = II.lIlI();
      HttpRequest var4 = HttpRequest.newBuilder(URI.create(var5 + var3)).timeout(Duration.ofSeconds(5L)).header(IIllI.lIlI(), Ill.lIlI()).GET().build();
      return IIlll.sendAsync(var4, BodyHandlers.ofString()).thenApply((var1x) -> {
         GameProfile var2 = var1;
         if (var1x.statusCode() == IllIII(-718681402, -1107703012) && var1x.body() != null && !((String)var1x.body()).isBlank()) {
            JsonObject var3 = JsonParser.parseString((String)var1x.body()).getAsJsonObject();
            if (!var3.has(lIlIII.Il(IllIIl(12537, -952870598, '垿')))) {
               return var1;
            } else {
               for(JsonElement var5 : var3.getAsJsonArray(lIlIII.Il(IllIIl(12534, 1700952187, '뵤')))) {
                  if (var5.isJsonObject()) {
                     JsonObject var6 = var5.getAsJsonObject();
                     if (var6.has(lIlIII.Il(IllIIl(12535, -1178178756, '浐'))) && var6.has(lIlIII.Il(IllIIl(12532, 1183912892, '\ued3b')))) {
                        String var7 = var6.get(lIlIII.Il(IllIIl(12533, -1744873087, '귋'))).getAsString();
                        String var8 = var6.get(lIlIII.Il(IllIIl(12530, -1705039650, '\uf7a2'))).getAsString();
                        if (!var8.isBlank()) {
                           if (var6.has(lIlIII.Il(IllIIl(12531, 959079608, '䜧')))) {
                              var2 = IIIIlII.IIl(var2, var7, new Property(var7, var8, var6.get(lIlIII.Il(IllIIl(12528, 517284241, '\uebba'))).getAsString()));
                           } else {
                              var2 = IIIIlII.IIl(var2, var7, new Property(var7, var8));
                           }
                        }
                     }
                  }
               }

               return var2;
            }
         } else {
            return var1;
         }
      }).exceptionally((var1x) -> var1);
   }

   static {
      short var6 = 6377;
      String var7 = "紆綹綴綋索綱綻綥緄緩紡緜綽緀緂綍綟緟紉綡網綛绋継緗紒緆緶\u1cccᷣᰱᶤᰰᰍ᷸᷾ᱬ᱿᷽ᷚᷨ᷼ᱺ᱾᷐᷹᷸ᰪᱧᲕ᷀᳐\uef4e\ue0f5\uef75\uef5a\ue8e2\uf7dd\uf7df\uf78d\uf787\uf7a1\ue8ed\uf7c9\uf7ad\uf7fb\ue8c4\uf7ca\uf70f\uf7bb\ue884\uf78e\uf7f9\uf7a6\uf7b8\uf7b2\ue89d\uf7ec\ue8d2\ue8eeГе\u0590іמ\u05f7\u05fb\u05eeгֶѵКМӈ֭֝вїҪҰ\ue2a4\ue2bf\ue2a5\ue289\ue29b\ue2ce\ue2bd\ue2d2\ue2b5\ue295\ue3c7\ue214\ue2d9\ue215\ue271\ue292\ue2f2\ue3f5\ue2b7\ue2ba\ue398\ue2f3\ue2ff\ue2ae\ue2c4\ue2d6\ue396\ue25e\ue2e1\ue2d2\ue2be\ue2df\ue2dd\ue2eb\ue281\ue2d0\ue20d\ue2c2\ue39c\ue2e8\ue3c3\ue3f1\ue2c2\ue2a3\ue39a\ue28a\ue28d\ue2db\ue2ca\ue2d2\ue396\ue2ea\ue2f3\ue2d5\ue2cb\ue2c6\ue2c2\ue3b4\ue283\ue2db\ue3e5\ue2d9\ue2b4\ue2e6\ue286\ue2da\ue2c7\ue2ad\ue2c1\ue285\ue284\ue2d5\ue20d\ue2a7\ue2fe\ue25e\ue2f8\ue2da\ue2bd\ue2c4\ue2b7\ue27c\ue228\ue214\ue2bf\ue215\ue2a4\ue29b\ue2ef\ue2c6\ue2a1\ue215\ue2b4\ue29a\ue2fd\ue2de\ue2be\ue2a4\ue2c2\ue2e9\ue2ee\ue2b3\ue2a8\ue2d3\ue398\ue25e\ue3db\ue2d3\ue3e4\ue2c1\ue2c6\ue298\ue2f3\ue2d1\ue3e9\ue2de\ue2a3\ue25e\ue29b\ue2c4\ue2bc\ue3fe\ue2a6\ue28f\ue28f\ue216\ue3eb\ue2d8\ue2df\ue28e\ue2ee\ue2da\ue280\ue2de\ue2d8\ue295\ue2e1\ue3fd\ue2ac\ue2c2\ue2aa\ue3b9\ue22a\ue214\ue2c4\ue2de\ue24e\ue261慤憆懶懈慆憷憮憀䘞䛄䞾䙾䘬䘃䙎䟻䞄䘜䘭䟣䟦䘘䞆䞭䘈䛂䙐䟽匕哸匮单卫哠协叇嘳埤噦垷ΨӲϗΉΘϒΡΤδҼϯ̖洀晦昆昼洏洼津洰洧浯洁暖晲晦浘春ﯶ穀頋漢廓ﯲ瑱請\uf757䜻\uf729䝫\ue8ab䜣\ue89e\ue884\u20ca“\u218d₈⃧–⃟⇺⃘↢ₙ\u20c8儞勼劜劑儬儍儔儈兯兾凢儩儑勬劔儞ꭲꨱꨣꨒꩿꩌ꩕ꩀꨭ꩑ꭋ\uaa5a\uaa3d꭪\uabfaꯕ硘祪秥硩禵禗禎禀硜砓砌砺砥硌秽砊砀禛硘砣秱砄禺禆\ud914\ud92a\ud9a5\udab8\ud96b\udae1\ud9db\udae3\uda85\ud91f\ud926\ud928\ud912\ud909\udabe\udaa5\udacc\ud91c\ud9df\ud9c5榗榕椒椲榽槔桇桝ꓵꌋ\ua48eꍘꓐꌷꌑꓺꌰꌁꓝꌕꓠꌁꍯꍄꍵꌍꌝꍕꒋꏽꓥꌀꌞꌴꏚꏵ铫鏑鍑鍾\uee31\uee35\ueea5\uee8a寨娒婥婂寎娪对婕婽婢娻娛婎寤嫊嫥鎭鏗鏠錷鎋鎟鍼鎐鏨鏗鎾鎎鎋鍡鉟鉰韀韾陴队韄阜雑雋䌊䓺䒀䒨䌬䓻䌟䏏疂疜甖甽疦畾畳畩וԕ֯\u05f7׳۴ԐԐ녦뀸끀뇒녁녾녧놩뇣뇏뀄놅㵄㙺㛢㵰㵣㵜㵅㵋㵁㵭㚦㴧먁먪뮅멞\uf28b\uf285\uf21f\uf224\uf2af\uf267\ue95a\ue940큒큙퀶턭附阺陀陫陠阸鞕鞏▛╴\u2429␖▿\u242c␦⑈\u2459⑴▼⑁╰\u245d\u242f┠␂⑂▔\u243c\u243f␆␆╴⑊▏\u245b⑫桷桨읊眈윒윤율으의栾桑윿睊윮栁看睼윣윽桷栈읩桇桻ꮂꭚꬅꬩꮦꭡꩌ꩖弴\uef4c\uef23\uef0f弐\uef47弸\ue070\uda0c\udab6\uda76\uda59鏟鎧鏈鏤鏻鎬鏃鎸鏂鍔鎆鎲鎻鎤钓鏽鎐鏑錎鎳鎼鍘鏰鎱鎻鏞鍲鏺鎎鏅錌鎤鎢鏤錣鎻鎧鏅鏆鏩錫鎧鎻鏃鎼鏻鏸铷鎷鏆鎢鎉鎟铷鏟鎸鎼鏨鏢鎺錅鏍鎸鏷燿瀇灨灄燛瀌燣瀘灢烴瀦瀀瀘灗熒灎瀳燱瀮瀟熀瀟炃瀂瀅燾熁熱瀾瀓炤瀒熜灔燄瀟瀌燥灢灔炁灗瀄瀖熂烴瀾瀝瀗燚烗熫瀼燱燻瀀熾熑燒瀆炤瀛灓熫燇燺瀕燬熀灄燍灔瀊燦灵熧瀽燡瀕烋舙菤艶莭舔菬艐菲峺嬜嬳孓峑嬄嬝嬨孌嬟峓峻嬝寈孼嬁嬸峥嬃字岊孏宏害楺榝槯槎⧺⣀⦀⦯ᒍᒷጷጘऺኀी९ွᆇ၇ၨ\ude50\ude00\udea5\udfb4\ude6a\udfe1\udff4\udecd\udf8b\udfa9\udfd4\ude10\ude30\ude00\udea9\udfa6\udfcc\ude1c\udedf\udec5";
      char[] var8 = "\u001c\u0018\u0004\u0018\u0014\u0094\b\u0014\b\u0004\f\u0010\b\b\f\u0010\u0010\u0018\u0014\b\u001c\u0004\u0004\u0010\u0010\b\b\b\b\f\f\u0004\b\u0004\b\u001c\u0018\b\b\u0004@P\b\u0018\u0004\u0004\u0004\u0004\u0004\u0014".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            IllII = var9;
            IllIl = new Object[var9.length];
            int var2 = -756801338;
            byte[] var0 = "\u0019\u000e÷n\\ÛªáVÄ\u007fF>ïZ\u0000*.¿&º4!Ô\u009a·Èuk\u008b'2µmä®³;r¨¦bC=}q}\u008e\u009e\u009c´\u0003öcVü(\u001a;\u0013\u000bÎP\u001br\u001b\u0087ËA6|\u0091Ú\u0011) %ÄyÂ\f\tònè\u0099\u0019Ä".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IlIll = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IlIll[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            III = lIlIII.l(IllIIl(12486, -242713883, 'ꉞ'));
            II = lIlIII.l(IllIIl(12487, 167059198, '뽃'));
            IIllI = lIlIII.l(IllIIl(12484, 15339414, '恬'));
            Ill = lIlIII.l(IllIIl(12485, -984983994, '\udef7'));
            IIlll = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5L)).followRedirects(Redirect.NORMAL).build();
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 9;
                     break;
                  case 1:
                     var10000 = 19;
                     break;
                  case 2:
                     var10000 = 119;
                     break;
                  case 3:
                     var10000 = 88;
                     break;
                  case 4:
                     var10000 = 44;
                     break;
                  case 5:
                     var10000 = 16;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private class_1657 IIlIII(class_310 var1, String var2) {
      if (var1 != null && var1.field_1687 != null && var2 != null && !var2.isBlank()) {
         for(class_1657 var4 : var1.field_1687.method_18456()) {
            if (var4 != null && var4.method_7334() != null) {
               String var5 = IIIIlII.II(var4.method_7334());
               if (!var5.isBlank() && var5.equalsIgnoreCase(var2)) {
                  return var4;
               }
            }
         }

         return null;
      } else {
         return null;
      }
   }

   private void IIlIIl() {
      String var1 = this.IIlllI();
      if (!var1.equals(this.lIll)) {
         this.IIlI.clear();
         this.IlIlI.set(0);
         this.lIll = var1;
         this.IlIIlI();
      }

   }

   private Object IIlIlI(Object var1) {
      if (var1 instanceof Optional var3) {
         return var3.orElse((Object)null);
      } else {
         return var1;
      }
   }

   private List<GameProfile> IIlIll(class_310 var1) {
      if (var1 == null) {
         return List.of();
      } else {
         LinkedHashMap var2 = new LinkedHashMap();
         if (var1.field_1724 != null) {
            this.IIIII(var2, var1.field_1724.method_7334());
         }

         if (var1.field_1687 != null) {
            for(class_1657 var4 : var1.field_1687.method_18456()) {
               if (var4 != null) {
                  this.IIIII(var2, var4.method_7334());
               }
            }
         }

         if (var1.method_1562() != null) {
            for(class_640 var7 : var1.method_1562().method_2880()) {
               if (var7 != null) {
                  this.IIIII(var2, var7.method_2966());
               }
            }
         }

         ArrayList var6 = new ArrayList(var2.values());
         UUID var8 = var1.field_1724 == null ? null : var1.field_1724.method_5667();
         var6.sort((var2x, var3) -> {
            UUID var4 = this.IlIIIl(var2x);
            UUID var5 = this.IlIIIl(var3);
            boolean var6 = var8 != null && var8.equals(var4);
            boolean var7 = var8 != null && var8.equals(var5);
            if (var6 != var7) {
               return var6 ? -1 : 1;
            } else {
               return IIIIlII.II(var2x).compareToIgnoreCase(IIIIlII.II(var3));
            }
         });
         return var6;
      }
   }

   private <undefinedtype> IIllII(class_2561 var1) {
      Object var2 = var1.method_10851();
      boolean var3 = false;
      class_2583 var4 = var1.method_10866();
      if (var2 instanceof class_8828 var5) {
         if (!this.llII(var4)) {
            String var6 = var5.comp_737();
            String var7 = this.IlIllI(var6);
            if (var6 != null && var7 != null && !var6.equals(var7)) {
               var2 = class_8828.method_54232(var7);
               var3 = true;
            }
         }
      }

      class_5250 var9 = class_5250.method_43477((class_7417)var2).method_10862(var4);

      for(class_2561 var11 : var1.method_10855()) {
         <undefinedtype> var8 = this.IIllII(var11);
         var9.method_10852(var8.l());
         var3 |= var8.I();
      }

      return new Record((class_2561)(var3 ? var9 : var1), var3) {
         private final boolean I;
         private final class_2561 l;

         public boolean I() {
            return this.I;
         }

         public class_2561 l() {
            return this.l;
         }

         private {
            this.l = var1;
            this.I = var2;
         }
      };
   }

   public String IIlllI() {
      String var1 = this.ll.IlI().trim();
      return var1.isEmpty() ? lIlIII.Il(IllIIl(12482, 1948916264, '훊')) : var1;
   }

   private UUID IIllll(String var1) {
      if (var1 != null && var1.length() == IllIII(-718681400, 2059179936)) {
         String var10000 = var1.substring(0, IllIII(-718681393, -1722720766));
         String var10001 = lIlIII.Il(IllIIl(12483, 2045454081, 'ᯕ'));
         String var10002 = var1.substring(IllIII(-718681394, -240206596), IllIII(-718681395, 802672916));
         String var10003 = lIlIII.Il(IllIIl(12480, 917792764, '\ue975'));
         String var10004 = var1.substring(IllIII(-718681396, 201570845), IllIII(-718681389, 1976987086));
         String var10005 = lIlIII.Il(IllIIl(12481, -1813941105, '丟'));
         String var10006 = var1.substring(IllIII(-718681390, 1190893205), IllIII(-718681391, -572734557));
         String var10007 = lIlIII.Il(IllIIl(12510, -197906928, '⻅'));
         String var12 = var1.substring(IllIII(-718681392, 571052992));
         String var11 = var10007;
         String var10 = var10006;
         String var9 = var10005;
         String var8 = var10004;
         String var7 = var10003;
         String var6 = var10002;
         String var5 = var10001;
         String var4 = var10000;
         String var2 = var4 + var5 + var6 + var7 + var8 + var9 + var10 + var11 + var12;

         try {
            return UUID.fromString(var2);
         } catch (IllegalArgumentException var13) {
            return null;
         }
      } else {
         return null;
      }
   }

   public Object IlIIII(GameProfile var1) {
      if (this.IIIIIlI() && (Boolean)this.IlI.III() && var1 != null) {
         return this.IllI(var1) ? this.IIl : null;
      } else {
         return null;
      }
   }

   private UUID IlIIIl(GameProfile var1) {
      if (var1 == null) {
         return null;
      } else {
         UUID var2 = IIIIlII.I(var1);
         if (var2 != null) {
            return var2;
         } else {
            String var3 = IIIIlII.II(var1);
            return var3 != null && !var3.isBlank() ? UUID.nameUUIDFromBytes(var3.toLowerCase(Locale.ROOT).getBytes(StandardCharsets.UTF_8)) : null;
         }
      }
   }

   private void IlIIlI() {
      this.IlIIl = "";
      this.I = null;
      this.lIII = Map.of();
      synchronized(this.IIIlI) {
         this.IIIlI.clear();
      }
   }

   public JsonObject IlIlII() {
      JsonObject var1 = super.IlIlII();
      return var1;
   }

   private String IlIlIl(String var1, Pattern var2, Map<String, String> var3) {
      Matcher var4 = var2.matcher(var1);
      StringBuffer var5 = null;

      while(var4.find()) {
         String var6 = (String)var3.get(var4.group(lIlIII.Il(IllIIl(12511, -1112862282, '\uf79b'))));
         if (var6 != null) {
            if (var5 == null) {
               var5 = new StringBuffer(var1.length());
            }

            var4.appendReplacement(var5, Matcher.quoteReplacement(var6));
         }
      }

      if (var5 == null) {
         return var1;
      } else {
         var4.appendTail(var5);
         return var5.toString();
      }
   }

   private String IlIllI(String var1) {
      Pattern var2 = this.I;
      Map var3 = this.lIII;
      if (var2 != null && !var3.isEmpty() && var1 != null && !var1.isEmpty()) {
         if (var1.length() <= IllIII(-718681385, 197401215)) {
            synchronized(this.IIIlI) {
               String var5 = (String)this.IIIlI.get(var1);
               if (var5 != null) {
                  return var5;
               }
            }
         }

         String var4 = this.IlIlIl(var1, var2, var3);
         if (var1.length() <= IllIII(-718681386, -279645740)) {
            synchronized(this.IIIlI) {
               this.IIIlI.put(var1, var4);
            }
         }

         return var4;
      } else {
         return var1;
      }
   }

   private static int IllIII(int var0, int var1) {
      return IlIll[var0 ^ -718681405] ^ var1 ^ var0;
   }

   private static String IllIIl(int var0, int var1, char var2) {
      int var3 = var0 ^ 12526;
      char[] var4 = IllII[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])IllIl[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         IllIl[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 32674;
      int var9 = 0;

      do {
         int var10 = var4[var9] - 25121;
         var10 ^= 42094;
         var10 += 47489;
         var10 -= 38977;
         var10 += 15580;
         var10 ^= 38881;
         var10 -= 10535;
         var10 += 6798;
         var10 ^= 63866;
         var10 ^= 64295;
         var4[var9] = (char)(var10 ^ var8 ^ var2 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
