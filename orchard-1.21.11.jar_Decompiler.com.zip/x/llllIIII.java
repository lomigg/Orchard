package x;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class llllIIII {
   private long I = Long.MIN_VALUE;
   private static final double l = 0.05;
   private <undefinedtype> II = null.I();
   private static final double Il = (double)28.0F;
   private static final double lI = 0.96;
   private static final double ll = (double)210.0F;
   private static final double III = (double)240.0F;
   private static final double IIl = (double)26.0F;
   private static final double IlI = 0.008333333333333333;
   private final Map<String, <undefinedtype>> Ill = new LinkedHashMap();
   private static final double lII = 5.0E-4;

   public <undefinedtype> I(List<<undefinedtype>> var1, double var2, double var4, double var6, long var8) {
      double var10 = IlI(var2);
      double var12 = IlI(var4);
      double var14 = II(var6, (double)0.0F, (double)1.0F);
      double var16 = this.Ill(var8);

      for(<undefinedtype> var19 : this.Ill.values()) {
         var19.I = false;
      }

      LinkedHashMap var38 = new LinkedHashMap();
      if (var1 != null) {
         for(<undefinedtype> var20 : var1) {
            if (var20 != null && var20.l() != null && !var20.l().isBlank()) {
               var38.putIfAbsent(var20.l(), var20);
            }
         }
      }

      HashSet var40 = new HashSet();
      ArrayList var41 = new ArrayList(var38.size());
      int var21 = 0;

      for(<undefinedtype> var23 : var38.values()) {
         double var24 = IlI(var23.I());
         Object var26 = (<undefinedtype>)this.Ill.get(var23.l());
         if (var26 == null) {
            var26 = new Object(var23.l(), var24, var21) {
               private boolean I;
               private double l;
               private double II;
               private boolean Il;
               private double lI;
               private double ll;
               private final String III;
               private int IIl;
               private double IlI;
               private double Ill;

               private {
                  this.III = var1;
                  this.II = var2;
                  this.IlI = var2 * 0.96;
                  this.IIl = var4;
               }
            };
            this.Ill.put(var23.l(), var26);
            var40.add(var23.l());
         }

         ((<undefinedtype>)var26).I = true;
         ((<undefinedtype>)var26).II = var24;
         var41.add(var23.l());
         ++var21;
      }

      for(<undefinedtype> var44 : this.Ill.values()) {
         if (!var40.contains(var44.III)) {
            var44.Ill = III(var44.Ill, var44.I ? (double)1.0F : (double)0.0F, var14, var16);
            <undefinedtype> var46 = IIl(var44.IlI, var44.ll, var44.II, var16, (double)240.0F, (double)28.0F);
            var44.IlI = var46.l();
            var44.ll = var46.I();
         }
      }

      this.Ill.values().removeIf((var0) -> !var0.I && var0.Ill <= 5.0E-4);
      List var43 = this.Ill.values().stream().filter((var0) -> !var0.I).sorted(Comparator.comparingInt((var0) -> var0.IIl)).toList();
      ArrayList var45 = new ArrayList(var41);

      for(<undefinedtype> var25 : var43) {
         int var50 = Math.max(0, Math.min(var25.IIl, var45.size()));
         var45.add(var50, var25.III);
      }

      ArrayList var48 = new ArrayList(var45.size());
      double var49 = (double)0.0F;
      double var27 = (double)0.0F;
      double var29 = (double)0.0F;

      for(int var31 = 0; var31 < var45.size(); ++var31) {
         <undefinedtype> var32 = (<undefinedtype>)this.Ill.get(var45.get(var31));
         if (var32 != null) {
            var32.IIl = var31;
            double var33 = lII(var32.Ill);
            if (!var32.Il) {
               var32.lI = var49;
               var32.Il = true;
            } else {
               <undefinedtype> var37 = IIl(var32.lI, var32.l, var49, var16, (double)210.0F, (double)26.0F);
               var32.lI = var37.l();
               var32.l = var37.I();
            }

            var48.add(new Record(var32.III, var32.I, var32.Ill, var33, var32.lI, var32.IlI, var32.II, var32.IIl) {
               private final double I;
               private final String l;
               private final double II;
               private final boolean Il;
               private final double lI;
               private final int ll;
               private final double III;
               private final double IIl;

               public double I() {
                  return this.II;
               }

               public double l(double var1, double var3) {
                  return (llllIIII.IlI(var1) + llllIIII.IlI(var3)) * this.lI;
               }

               public boolean II() {
                  return this.Il;
               }

               public double Il() {
                  return this.lI;
               }

               public {
                  this.l = var1;
                  this.Il = var2;
                  this.II = var3;
                  this.lI = var5;
                  this.I = var7;
                  this.IIl = var9;
                  this.III = var11;
                  this.ll = var13;
               }

               public double lI() {
                  return this.IIl;
               }

               public int ll() {
                  return this.ll;
               }

               public double III() {
                  return this.III;
               }

               public double IIl() {
                  return this.I;
               }

               public String IlI() {
                  return this.l;
               }
            });
            var27 = Math.max(var27, var32.II);
            var49 += (var10 + var12) * var33;
            var29 = var12 * var33;
         }
      }

      double var51 = Math.max((double)0.0F, var49 - var29);
      this.II = new Record(List.copyOf(var48), var27, var51) {
         private final List<<undefinedtype>> I;
         private final double l;
         private final double II;

         private static <undefinedtype> I() {
            return new <anonymous constructor>(List.of(), (double)0.0F, (double)0.0F);
         }

         public double l() {
            return this.l;
         }

         public {
            this.I = var1;
            this.II = var2;
            this.l = var4;
         }

         public List<<undefinedtype>> II() {
            return this.I;
         }

         public double Il() {
            return this.II;
         }
      };
      return this.II;
   }

   private static double II(double var0, double var2, double var4) {
      return Math.max(var2, Math.min(var4, var0));
   }

   public void lI() {
      this.Ill.clear();
      this.II = null.I();
      this.I = Long.MIN_VALUE;
   }

   private static double III(double var0, double var2, double var4, double var6) {
      if (!(var6 <= (double)0.0F) && var0 != var2) {
         double var8 = var6 * (double)60.0F;
         double var10 = (double)1.0F - Math.pow((double)1.0F - II(var4, (double)0.0F, (double)1.0F), var8);
         return var0 + (var2 - var0) * var10;
      } else {
         return var0;
      }
   }

   private static <undefinedtype> IIl(double var0, double var2, double var4, double var6, double var8, double var10) {
      if (var6 <= (double)0.0F) {
         return new Record(var0, var2) {
            private final double I;
            private final double l;

            public double I() {
               return this.l;
            }

            public double l() {
               return this.I;
            }

            private {
               this.I = var1;
               this.l = var3;
            }
         };
      } else {
         int var12 = Math.max(1, (int)Math.ceil(var6 / 0.008333333333333333));
         double var13 = var6 / (double)var12;
         double var15 = var0;
         double var17 = var2;

         for(int var19 = 0; var19 < var12; ++var19) {
            double var20 = (var4 - var15) * var8 - var17 * var10;
            var17 += var20 * var13;
            var15 += var17 * var13;
         }

         return Math.abs(var4 - var15) < 5.0E-4 && Math.abs(var17) < 0.005 ? new Record(var4, (double)0.0F) {
            private final double I;
            private final double l;

            public double I() {
               return this.l;
            }

            public double l() {
               return this.I;
            }

            private {
               this.I = var1;
               this.l = var3;
            }
         } : new Record(var15, var17) {
            private final double I;
            private final double l;

            public double I() {
               return this.l;
            }

            public double l() {
               return this.I;
            }

            private {
               this.I = var1;
               this.l = var3;
            }
         };
      }
   }

   private static double IlI(double var0) {
      return Double.isFinite(var0) ? Math.max((double)0.0F, var0) : (double)0.0F;
   }

   private double Ill(long var1) {
      if (this.I == Long.MIN_VALUE) {
         this.I = var1;
         return (double)0.0F;
      } else if (var1 <= this.I) {
         return (double)0.0F;
      } else {
         double var3 = (double)(var1 - this.I) / (double)1.0E9F;
         this.I = var1;
         return Math.min(0.05, Math.max((double)0.0F, var3));
      }
   }

   private static double lII(double var0) {
      double var2 = (double)1.0F - II(var0, (double)0.0F, (double)1.0F);
      return (double)1.0F - var2 * var2 * var2;
   }

   public <undefinedtype> lIl() {
      return this.II;
   }
}
