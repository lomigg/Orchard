package x;

import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_4969;
import net.minecraft.class_638;
import net.minecraft.class_239.class_240;

@Environment(EnvType.CLIENT)
public final class llIIlIII extends IIIIIIIlI {
   private int I = IIIll(-1230808059, -1580123184);
   private class_2338 l;
   private class_3965 II;
   private static final int Il = 4;
   private boolean lI;
   private final IIIllIIII ll = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IIlII(1752221227, 1540842769)), (double)100.0F, (double)0.0F, (double)100.0F, (double)1.0F)).IIIl(lIlIII.l(IIlII(1752221226, -186239726))));
   private class_2338 III;
   private int IIl = IIIll(-1230808058, -642152770);
   private static final int[] IlI;
   private static final String[] Ill;
   private static final Object[] lII;

   private boolean ll(class_310 var1, class_2338 var2, class_3965 var3) {
      if (this.IlI(var1) && var2 != null) {
         int var4 = var1.field_1724.method_6047().method_31574(class_1802.field_23141) ? IllllIlI.lIIlI(var1.field_1724.method_31548()) : this.IIIIl(var1.field_1724, class_1802.field_23141);
         if (var4 >= 0 && var4 < IIIll(-1230808060, 1189237236)) {
            class_3965 var5 = this.IlII(var1, var2, var3);
            if (var5 == null) {
               return false;
            } else {
               return var4 == IllllIlI.lIIlI(var1.field_1724.method_31548()) ? this.IIII(var1, var5) : IllllIlI.llIll(var1, this, var4, () -> this.IIII(var1, var5));
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public String Il() {
      return String.valueOf(Math.round((Double)this.ll.III()));
   }

   private boolean IlI(class_310 var1) {
      return var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var1.method_1562() != null && var1.field_1755 == null && var1.field_1724.method_5805() && !lIlIllll.lIIl(var1);
   }

   public void lII(class_310 var1, class_1268 var2, class_3965 var3) {
   }

   private boolean llI() {
      lIllIIl var1 = lIllIIl.Il();
      IIIlIlI var2 = var1 != null && var1.IIl() != null ? var1.IIl().IIlll() : null;
      return var2 != null && var2.lIIII();
   }

   public void lll(class_310 var1, class_3965 var2) {
      this.llII(var1, class_1268.field_5808, var2);
   }

   private boolean IIII(class_310 var1, class_3965 var2) {
      int var3 = IllllIlI.lIllI(var1);
      this.lI = true;
      boolean var4 = false;

      boolean var5;
      try {
         var4 = IllllIlI.IIlIIII(var1, var2);
         if (var4) {
            var1.field_1724.method_6104(class_1268.field_5808);
         }

         var5 = var4;
      } finally {
         IIlllllI.IlIl(var1, var4 ? Math.max(var3, 4) : var3);
         this.lI = false;
      }

      return var5;
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (this.IIIIIlI() && this.IlI(var1)) {
         if (this.II != null) {
            if (var1.field_1724.field_6012 > this.IIl) {
               this.IIll();
               return;
            }

            if (var1.field_1724.field_6012 >= this.I) {
               class_2338 var2 = this.III;
               class_3965 var3 = this.II;
               if (this.ll(var1, var2, var3)) {
                  this.IIll();
               } else {
                  this.I = var1.field_1724.field_6012 + 1;
               }
            }
         }

      } else {
         this.IIll();
      }
   }

   public llIIlIII() {
      super((Object)lIlIII.l(IIlII(1752221225, -1036353746)), lIllII.I, (Object)lIlIII.l(IIlII(1752221224, -1503233576)));
   }

   private void IIll() {
      this.III = null;
      this.II = null;
      this.I = IIIll(-1230808057, -312200763);
      this.IIl = IIIll(-1230808064, -1276861998);
   }

   private class_3965 IlII(class_310 var1, class_2338 var2, class_3965 var3) {
      if (var1 != null && var1.field_1687 != null && var2 != null) {
         class_638 var4 = var1.field_1687;
         class_2338 var5 = var2.method_10074();
         class_2680 var6 = ((class_1937)var4).method_8320(var5);
         if (this.lIIl(var1, var5, var6)) {
            class_243 var16 = new class_243((double)var2.method_10263() + (double)0.5F, (double)var2.method_10264(), (double)var2.method_10260() + (double)0.5F);
            return new class_3965(var16, class_2350.field_11036, var5, false);
         } else {
            class_2350[] var7 = new class_2350[]{class_2350.field_11043, class_2350.field_11035, class_2350.field_11039, class_2350.field_11034, class_2350.field_11036};

            for(class_2350 var11 : var7) {
               class_2338 var12 = var2.method_10093(var11);
               class_2680 var13 = ((class_1937)var4).method_8320(var12);
               class_2350 var14 = var11.method_10153();
               if (this.lIIl(var1, var12, var13)) {
                  class_243 var15 = new class_243((double)var2.method_10263() + (double)0.5F + (double)var11.method_10148() * (double)0.5F, (double)var2.method_10264() + (double)0.5F + (double)var11.method_10164() * (double)0.5F, (double)var2.method_10260() + (double)0.5F + (double)var11.method_10165() * (double)0.5F);
                  return new class_3965(var15, var14, var12, false);
               }
            }

            return null;
         }
      } else {
         return null;
      }
   }

   public void IlIl(class_310 var1, class_1268 var2, class_3965 var3, class_1269 var4) {
      class_2338 var5 = this.l;
      this.l = null;
      if (var5 != null && var3 != null && var5.equals(var3.method_17777()) && var4 != null && (var4.method_23665() || var4 == class_1269.field_5812)) {
         this.llII(var1, var2, var3);
      }

   }

   public void Illl(class_310 var1, class_1268 var2, class_3965 var3) {
      this.l = null;
      if (!this.lI && this.IIIIIlI() && this.IlI(var1) && var2 != null && var3 != null && var3.method_17783() == class_240.field_1332 && !var1.field_1687.method_27983().equals(class_1937.field_25180) && !this.llI()) {
         class_2338 var4 = var3.method_17777();
         class_2680 var5 = var1.field_1687.method_8320(var4);
         if (var5.method_27852(class_2246.field_23152) && (Integer)var5.method_11654(class_4969.field_23153) > 0 && !var1.field_1724.method_5998(var2).method_31574(class_1802.field_8801)) {
            this.l = var4.method_10062();
         }
      }
   }

   private boolean lIII() {
      double var1 = Math.max((double)0.0F, Math.min((double)100.0F, (Double)this.ll.III()));
      return var1 >= (double)100.0F || var1 > (double)0.0F && ThreadLocalRandom.current().nextDouble((double)100.0F) < var1;
   }

   public void lI() {
      this.l = null;
      this.IIll();
      this.lI = false;
   }

   private boolean lIIl(class_310 var1, class_2338 var2, class_2680 var3) {
      if (var2 != null && var3 != null && !var3.method_26215()) {
         return var3.method_26212(var1.field_1687, var2) && var3.method_26227().method_15769() && !var3.method_26220(var1.field_1687, var2).method_1110();
      } else {
         return false;
      }
   }

   private void llII(class_310 var1, class_1268 var2, class_3965 var3) {
      if (!this.lI && this.IIIIIlI() && this.IlI(var1) && var3 != null && var3.method_17783() == class_240.field_1332 && !var1.field_1687.method_27983().equals(class_1937.field_25180)) {
         int var4 = var1.field_1724.method_6047().method_31574(class_1802.field_23141) ? IllllIlI.lIIlI(var1.field_1724.method_31548()) : this.IIIIl(var1.field_1724, class_1802.field_23141);
         if (var4 >= 0 && var4 < IIIll(-1230808063, 497466092)) {
            class_2338 var5 = var3.method_17777();
            class_2680 var6 = var1.field_1687.method_8320(var5);
            if (!var6.method_27852(class_2246.field_23152) || (Integer)var6.method_11654(class_4969.field_23153) > 0) {
               if (this.lIII()) {
                  this.III = var5;
                  this.II = var3;
                  this.I = var1.field_1724.field_6012 + 1;
                  this.IIl = var1.field_1724.field_6012 + IIIll(-1230808062, -252855442);
               }
            }
         }
      }
   }

   public boolean IIIII() {
      return this.lI;
   }

   private int IIIIl(class_1657 var1, class_1792 var2) {
      if (var1 != null && var1.method_31548() != null) {
         for(int var3 = 0; var3 < IIIll(-1230808061, -67892116); ++var3) {
            if (var1.method_31548().method_5438(var3).method_31574(var2)) {
               return var3;
            }
         }

         return -1;
      } else {
         return -1;
      }
   }

   private static int IIIll(int var0, int var1) {
      return IlI[var0 ^ -1230808060] ^ var1 ^ var0;
   }

   static {
      short var6 = 16826;
      String var7 = "ꦁꤡꦥꤺ꧍ꦆꥶ\ua9ddꦿ꧁꧳ꤧ췝쵾춊쵠춊췚촜출췦춞췏쵥최췖촦촳춉쵃춮쵧출췯쵱쵙쵤췣춊춑촦촉쵹촍췀쵲춡쵯춿췊촴춐춇췫춍쵪촥췚촰촺춆촖춸쵧춶췁촡쵎쵙췫춨춤쵅촁쵨촲췆쵾춰쵤춌췊촔춀췢춍춊쵥쵗췆촡초춃쵃췻쵌췁췚촫쵮쵠춌춖춈촯쵔촦촄춚쵶췵촜ぬィ、テ〽けわ〶鼛鿶齵龜";
      char[] var8 = "䆶䇞䆲䆾".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            Ill = var9;
            lII = new Object[var9.length];
            int var2 = 1032884348;
            byte[] var0 = "ÍÑ\u009d\u0085ªâ÷©Ò\u008aJÄæWý¾¸×m®\u0096\u0095v\u0098{Þw\u0016pÇÀ\u001a".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IlI = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IlI[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static String IIlII(int var0, int var1) {
      int var3 = var0 ^ 1752221225;
      char[] var4 = Ill[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])lII[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         lII[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -1174221755;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 116;
               break;
            case 1:
               var9 = 251;
               break;
            case 2:
               var9 = 20;
               break;
            case 3:
               var9 = 253;
               break;
            case 4:
               var9 = 59;
               break;
            case 5:
               var9 = 84;
               break;
            case 6:
               var9 = 146;
               break;
            case 7:
               var9 = 8;
               break;
            case 8:
               var9 = 104;
               break;
            case 9:
               var9 = 3;
               break;
            case 10:
               var9 = 60;
               break;
            case 11:
               var9 = 225;
               break;
            case 12:
               var9 = 200;
               break;
            case 13:
               var9 = 64;
               break;
            case 14:
               var9 = 187;
               break;
            case 15:
               var9 = 181;
               break;
            case 16:
               var9 = 29;
               break;
            case 17:
               var9 = 166;
               break;
            case 18:
               var9 = 93;
               break;
            case 19:
               var9 = 221;
               break;
            case 20:
               var9 = 46;
               break;
            case 21:
               var9 = 105;
               break;
            case 22:
               var9 = 158;
               break;
            case 23:
               var9 = 208;
               break;
            case 24:
               var9 = 238;
               break;
            case 25:
               var9 = 101;
               break;
            case 26:
               var9 = 31;
               break;
            case 27:
               var9 = 26;
               break;
            case 28:
               var9 = 171;
               break;
            case 29:
               var9 = 228;
               break;
            case 30:
               var9 = 194;
               break;
            case 31:
               var9 = 139;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
