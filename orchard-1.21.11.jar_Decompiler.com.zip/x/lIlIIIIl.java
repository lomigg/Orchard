package x;

import java.util.Locale;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
final class lIlIIIIl {
   private static String[] I;
   private static final int[] l;
   private static final String[] II;
   private static final Object[] Il;

   public static double I(double var0, double var2, double var4, double var6) {
      return lllIIll.II(var0, var2, var4, var6);
   }

   public static int l(int var0, int var1, double var2) {
      double var4 = lIl(var2, (double)0.0F, (double)1.0F);
      int var6 = var0 >>> Illl(-1998408408, -1070732724) & Illl(-1998408407, -638208964);
      int var7 = var0 >>> Illl(-1998408406, -1348829434) & Illl(-1998408405, -1170255552);
      int var8 = var0 >>> Illl(-1998408404, -1640999707) & Illl(-1998408403, 1569160659);
      int var9 = var0 & Illl(-1998408402, 385708789);
      int var10 = var1 >>> Illl(-1998408401, -941807865) & Illl(-1998408416, 1886707867);
      int var11 = var1 >>> Illl(-1998408415, -612837785) & Illl(-1998408414, 1600380135);
      int var12 = var1 >>> Illl(-1998408413, -1449563876) & Illl(-1998408412, -2078618361);
      int var13 = var1 & Illl(-1998408411, 1252783251);
      int var14 = ll((int)Math.round(lI((double)var6, (double)var10, var4)), 0, Illl(-1998408410, -637604826));
      int var15 = ll((int)Math.round(lI((double)var7, (double)var11, var4)), 0, Illl(-1998408409, -1856271623));
      int var16 = ll((int)Math.round(lI((double)var8, (double)var12, var4)), 0, Illl(-1998408392, 1840387785));
      int var17 = ll((int)Math.round(lI((double)var9, (double)var13, var4)), 0, Illl(-1998408391, -1524037473));
      return var14 << Illl(-1998408390, 30620106) | var15 << Illl(-1998408389, -704979191) | var16 << Illl(-1998408388, 1634608501) | var17;
   }

   public static float II(float var0, float var1, float var2) {
      return lllIIll.lII(var0, var1, var2);
   }

   public static <undefinedtype> Il(double var0, double var2, double var4, double var6, double var8, double var10) {
      return lllIIll.Il(var0, var2, var4, var6, var8, var10);
   }

   public static double lI(double var0, double var2, double var4) {
      return lllIIll.lI(var0, var2, var4);
   }

   public static int ll(int var0, int var1, int var2) {
      return lllIIll.llI(var0, var1, var2);
   }

   public static double III(double var0) {
      double var2 = lIl(var0, (double)0.0F, (double)1.0F);
      return (double)1.0F - ((double)1.0F - var2) * ((double)1.0F - var2);
   }

   public static String IIl(double var0, double var2, String var4) {
      int var5 = IllI(var2);
      String var10000;
      if (var5 <= 0) {
         var10000 = Long.toString(Math.round(var0));
      } else {
         Locale var10 = Locale.US;
         String var10001 = lIlIII.Il(I[1]);
         String var9 = lIlIII.Il(I[0]);
         String var7 = var10001;
         var10000 = String.format(var10, var7 + var5 + var9, var0);
      }

      String var6 = var10000;
      if (var5 > 0 && var6.indexOf(Illl(-1998408387, -745114926)) >= 0) {
         while(var6.endsWith(lIlIII.Il(I[3]))) {
            var6 = var6.substring(0, var6.length() - 1);
         }

         if (var6.endsWith(lIlIII.Il(I[2]))) {
            var6 = var6.substring(0, var6.length() - 1);
         }
      }

      return var4 != null && !var4.isBlank() ? var6 + var4 : var6;
   }

   private static void IlI() {
      I[0] = llI(lIII(-486004341, -459130236).toCharArray(), 67756L, Illl(-1998408386, 519537652));
      I[1] = llI(lIII(-486004342, 685338548).toCharArray(), 22178L, Illl(-1998408385, -602824342));
      I[2] = llI(lIII(-486004343, 1108687962).toCharArray(), 64655L, Illl(-1998408400, 1542760226));
      I[3] = llI(lIII(-486004344, -1981211789).toCharArray(), 33260L, Illl(-1998408399, 2089256610));
   }

   public static boolean Ill(llIlIIII var0, double var1, double var3) {
      if (var0 == null) {
         return false;
      } else {
         double var5 = var0.Il();
         double var7 = var0.Ill();
         <undefinedtype> var9 = Il(var5, var7, var0.llll(), var0.lIIl(), var1, var3);
         if (Double.compare(var5, var9.I()) == 0 && Double.compare(var7, var9.Il()) == 0) {
            return false;
         } else {
            var0.lIlI(var9.I(), var9.Il());
            return true;
         }
      }
   }

   public static double lII(double var0, double var2, double var4) {
      return lllIIll.IlII(var0, var2, var4);
   }

   public static double lIl(double var0, double var2, double var4) {
      return lllIIll.I(var0, var2, var4);
   }

   private static String llI(char[] var0, long var1, int var3) {
      int var4 = Illl(-1998408398, -1065668042) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & Illl(-1998408397, -355245850);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   public static boolean lll(double var0, double var2, double var4, double var6, double var8, double var10) {
      return lllIIll.lll(var0, var2, var4, var6, var8, var10);
   }

   public static double IIII(double var0, double var2, double var4) {
      return var4 <= var2 ? (double)0.0F : lIl((var0 - var2) / (var4 - var2), (double)0.0F, (double)1.0F);
   }

   public static <undefinedtype> IIIl(Object var0, Iterable<<undefinedtype>> var1, double var2, double var4) {
      return lllIIll.III(var0, var1, var2, var4);
   }

   public static int IIlI(int var0, double var1) {
      return lllIIll.IIlI(var0, var1);
   }

   private lIlIIIIl() {
   }

   public static int IIll(int var0, int var1, double var2) {
      return lllIIll.IIII(var0, var1, var2);
   }

   static {
      short var6 = 30938;
      String var7 = "鎪㪩ꉻ뷱⾈땭ꏪ饎蓈뱨喐쭎ﶬ뱲鹀\uead2";
      char[] var8 = "磞磞磞磞".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            II = var9;
            Il = new Object[var9.length];
            int var2 = -615267396;
            byte[] var0 = "\u0093\u009c\u009cÀ\u008aDÂVü+\t\u0080é\u008e'(Í\u0081\"}\u000e6\u000b½EL\u0004\u0098\u0094lQ\u008c#Å\u0096ø\u0088É ê\fÒª\u0086ú(\u001f\u008b×«»`\u0019\u001a\u0082õ\u008aO\u009aCÂêü\u009d>\u0003`²ö\u0098~åRbOT\u0086K©\u009e2ßSý\u0080'\u0004}RÉT|ÛÎ\u0087«7r\u0015t(%~z\"l\u0094I¹b\u0016\u0096u-\"þ".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            l = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               l[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            I = new String[4];
            IlI();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 37;
                     break;
                  case 1:
                     var10000 = 54;
                     break;
                  case 2:
                     var10000 = 31;
                     break;
                  case 3:
                     var10000 = 78;
                     break;
                  case 4:
                     var10000 = 82;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public static double IlII(double var0) {
      double var2 = lIl(var0, (double)0.0F, (double)1.0F);
      double var4 = (double)1.0F - var2;
      return (double)1.0F - var4 * var4 * var4;
   }

   public static int IlIl(int var0, int var1) {
      return lllIIll.l(var0, var1);
   }

   private static int IllI(double var0) {
      double var2 = Math.abs(var0);
      if (var2 <= (double)0.0F) {
         return 0;
      } else {
         int var4;
         for(var4 = 0; var4 < Illl(-1998408396, 647779440) && Math.abs(var2 - Math.rint(var2)) > 1.0E-6; ++var4) {
            var2 *= (double)10.0F;
         }

         return var4;
      }
   }

   private static int Illl(int var0, int var1) {
      return l[var0 ^ -1998408408] ^ var1 ^ var0;
   }

   private static String lIII(int var0, int var1) {
      int var3 = var0 ^ -486004341;
      char[] var4 = II[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])Il[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         Il[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 224144868;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 219;
               break;
            case 1:
               var9 = 63;
               break;
            case 2:
               var9 = 49;
               break;
            case 3:
               var9 = 39;
               break;
            case 4:
               var9 = 176;
               break;
            case 5:
               var9 = 57;
               break;
            case 6:
               var9 = 175;
               break;
            case 7:
               var9 = 231;
               break;
            case 8:
               var9 = 74;
               break;
            case 9:
               var9 = 197;
               break;
            case 10:
               var9 = 227;
               break;
            case 11:
               var9 = 138;
               break;
            case 12:
               var9 = 187;
               break;
            case 13:
               var9 = 242;
               break;
            case 14:
               var9 = 164;
               break;
            case 15:
               var9 = 43;
               break;
            case 16:
               var9 = 219;
               break;
            case 17:
               var9 = 110;
               break;
            case 18:
               var9 = 233;
               break;
            case 19:
               var9 = 190;
               break;
            case 20:
               var9 = 245;
               break;
            case 21:
               var9 = 146;
               break;
            case 22:
               var9 = 194;
               break;
            case 23:
               var9 = 227;
               break;
            case 24:
               var9 = 155;
               break;
            case 25:
               var9 = 213;
               break;
            case 26:
               var9 = 202;
               break;
            case 27:
               var9 = 130;
               break;
            case 28:
               var9 = 171;
               break;
            case 29:
               var9 = 12;
               break;
            case 30:
               var9 = 162;
               break;
            case 31:
               var9 = 216;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
