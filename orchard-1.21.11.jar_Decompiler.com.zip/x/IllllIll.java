package x;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class IllllIll {
   private static final Map<UUID, Integer> I;
   private static final Map<UUID, Integer> l;
   private static volatile int II;
   private static final Map<UUID, Integer> Il;
   private static final int[] lI;

   public static void I() {
      l.clear();
   }

   public static boolean l(UUID var0) {
      return var0 != null && (l.containsKey(var0) || Il.containsKey(var0) || I.containsKey(var0));
   }

   public static void II(UUID var0, int var1) {
      if (var0 != null) {
         I.put(var0, var1);
      }

   }

   public static void Il(UUID var0, int var1) {
      if (var0 != null) {
         Il.put(var0, var1);
      }

   }

   public static int lI(UUID var0) {
      if (var0 == null) {
         return II;
      } else {
         Integer var1 = (Integer)Il.get(var0);
         if (var1 != null) {
            return var1;
         } else {
            Integer var2 = (Integer)I.get(var0);
            if (var2 != null) {
               return var2;
            } else {
               Integer var3 = (Integer)l.get(var0);
               return var3 != null ? var3 : II;
            }
         }
      }
   }

   public static int ll() {
      return II;
   }

   public static void III(UUID var0) {
      if (var0 != null) {
         l.put(var0, II);
      }

   }

   public static void IIl(int var0) {
      II = var0;
   }

   public static void IlI() {
      Il.clear();
   }

   static {
      int var2 = 775177996;
      byte[] var0 = "ºÊ&\f".getBytes("ISO-8859-1");
      int var1 = var0.length / 4;
      lI = new int[var1];
      int var3 = 0;
      int var4 = 0;

      do {
         int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
         var5 ^= var2;
         lI[var4] = var5;
         var3 += 4;
         ++var4;
      } while(var4 < var1);

      l = new ConcurrentHashMap();
      Il = new ConcurrentHashMap();
      I = new ConcurrentHashMap();
      II = lII(1596606863, 875240125);
   }

   public static void Ill() {
      I.clear();
   }

   private IllllIll() {
   }

   private static int lII(int var0, int var1) {
      return lI[var0 ^ 1596606863] ^ var1 ^ var0;
   }
}
