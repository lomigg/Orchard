package x;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4604;
import net.minecraft.class_757;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;

@Environment(EnvType.CLIENT)
public final class IIIIIIIII {
   public static final <undefinedtype> I = (<undefinedtype>)(new Object() {
      private static final String I;
      private static volatile boolean l;
      private static final String II;
      private static final String Il;
      private static String[] lI;
      private static final int[] ll;
      private static final String[] III;
      private static final Object[] IIl;

      static {
         short var9 = 12002;
         String var10 = "ཝ믛㞅㸔醁쩚风섐陔忱\ufafcꗩ룭髲퇏汐⩙\uddc8茟\ue62e䳍㙶欉퇞ኀ\udc76돿\u181a벤䓑Ֆ阇㮾\uea39죎䦁퉤瞤\uaacc翤銘겨\uf748맥C쁝ಳצ蘡ꦯ鰥⍑˙ꑊ겉㕈ꬓ볝먒㭐榳탰ᧅ哫믙݊\udad5\ufd91䞿(˽塀矑纸竧谸\uf45c\ue671ℯ⓸\ue871⡲堰蛔墍\udc54鯍瓙蘳⩖शꯗዓ텡㊊㺫椔\ud96a봷嗱\uda0aДᡑ효⽃芯ᔒꢏ材ςﲤ岑䕬燌쳽蠝䯑આળ\ue355梳캤\uee04\ud96f䑃舿靃ᚥ웄諁\ufddb㵕尿岒鰹뻆\uf3a9ᒍ㷜Ꮀ䘅륹\ue6ccḝ욅뙅틩ⵣ饢㲙樊弃\uea5a\udc9d擅㜴⛩\uf39b\ue37c㛐\udda7ꩶӲ變潈べ\ue3bcᶑ\ud949殥䛒䂑⮸蒪\u0eee䪙緥ඉ\u0dfc\udc03\ua63d豈붕㾆\u0a04뒯礁鄚ؔ㛳䈳\uefafᐅ㮄\uf291\ue913Ħ\uec94ႏ⌕㦦\udbe1ᚌ皕\uf401됣桸뉹㷔筓矰Ⱄ⎩ഷퟎ鑥\ue233\ue241騉勿샱ꗘ츂﵎늯惺\uabef䆂㠢\udaea긗熰쯕姏ސꤔ쁅\u1aef㓑覹직鼨\uee85镏ᭌ鲰헱ⵚᢵꗽ粚⡚敖콚ႍ㳻ߔ\ue0e4\ue1c5‡";
         char[] var11 = "\u2ef6⺮\u2ef6⺾\u2ef6⻮\u2ef6".toCharArray();
         String[] var12 = new String[var11.length];
         byte var16 = -1;

         while(true) {
            int var13 = 0;
            int var14 = 0;
            int var15 = 0;
            if (var16 == 0) {
               III = var12;
               IIl = new Object[var12.length];
               int var2 = -2088239940;
               byte[] var0 = "6\u0096õDMr\u000b\u0096±Y\u000f\bg8\u0084îT¥FÆá?mo×¥\u007f\u001clá\u0085\u0097;\u007füûVdaÕò?gYòFç\u0083".getBytes("ISO-8859-1");
               int var1 = var0.length / 4;
               ll = new int[var1];
               int var3 = 0;
               int var4 = 0;

               do {
                  int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
                  var5 ^= var2;
                  ll[var4] = var5;
                  var3 += 4;
                  ++var4;
               } while(var4 < var1);

               lI = new String[ll(-1282528953, 111091896)];
               II();
               Il = lIlIII.Il(lI[3]);
               String var10000 = Il;
               String var7 = lIlIII.Il(lI[4]);
               String var6 = var10000;
               I = var6 + var7;
               var10000 = Il;
               String var8 = lIlIII.Il(lI[2]);
               var7 = var10000;
               II = var7 + var8;
               return;
            }

            do {
               var15 = var11[var13] ^ var9;
               var12[var13] = var10.substring(var14, var14 + var15);
               var14 += var15;
               ++var13;
            } while(var13 < var11.length);

            var16 = 0;
         }
      }

      private static synchronized void I() throws ReflectiveOperationException {
         if (!l) {
            Class var0 = Class.forName(Il);
            Object var1 = var0.getField(lIlIII.Il(lI[ll(-1282528954, 2105269866)])).get((Object)null);
            Class var2 = Class.forName(II);
            Method var3 = l(var1.getClass());
            Object var4 = Proxy.newProxyInstance(var2.getClassLoader(), new Class[]{var2}, new InvocationHandler() {
               private static String[] I;
               private static final int[] l;
               private static final String[] II;
               private static final Object[] Il;

               private static void I() {
                  I[0] = l(Il((short)'舘', 23740449, '큨').toCharArray(), 95375L, II(1316689719, 1211140956));
                  I[1] = l(Il((short)10922, 1428713969, '큩').toCharArray(), 73642L, II(1316689718, 701565397));
                  I[2] = l(Il((short)4559, 347092165, '큪').toCharArray(), 909L, II(1316689717, -1534242643));
                  I[3] = l(Il((short)22914, 649879685, '큫').toCharArray(), 87598L, II(1316689716, 751369207));
               }

               private static String l(char[] var0, long var1, int var3) {
                  int var4 = II(1316689715, -1449786409) ^ var3;

                  for(int var5 = 0; var5 < var0.length; ++var5) {
                     int var7 = var4 ^ (int)var1 ^ ~var5;
                     int var8 = var7 ^ var3 - var5 * var0.length;
                     var4 = -var8 * var3 | var5;
                     var0[var5] = (char)(var0[var5] ^ var4);
                     int var6 = var5 & II(1316689714, -1470472700);
                     var3 = var3 << var6 | var3 >>> -var6;
                     var1 ^= (long)var6;
                  }

                  return new String(var0);
               }

               static {
                  short var6 = 29947;
                  String var7 = "봏꣕霂駒\uf53f聓薘䯸홋ꓖ훠ⵊ쑯韂\uedd9殬袜⯈\u20f7痖䶴\udee2䊥锢\ud7fc떑恌葠㠑ꇴ\ue726熼֜\ue694鬰㹩楷䫈咒檂酂嶰䘠厛뵁徍놀梥ᶑᲖ᱔\ud99cᎶ쳾ר뭜늂뙅圊䬨６蟵";
                  char[] var8 = "瓳瓽瓓瓳".toCharArray();
                  String[] var9 = new String[var8.length];
                  byte var13 = -1;

                  while(true) {
                     int var10 = 0;
                     int var11 = 0;
                     int var12 = 0;
                     if (var13 == 0) {
                        II = var9;
                        Il = new Object[var9.length];
                        int var2 = 977069161;
                        byte[] var0 = "¥\u001c\u001fFm\u0088oÝÁXùp\u001e\u0091 ^Å8Æ\u0080Ü\u001d\u00ad ".getBytes("ISO-8859-1");
                        int var1 = var0.length / 4;
                        l = new int[var1];
                        int var3 = 0;
                        int var4 = 0;

                        do {
                           int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
                           var5 ^= var2;
                           l[var4] = var5;
                           var3 += 4;
                           ++var4;
                        } while(var4 < var1);

                        I = new String[4];
                        I();
                        return;
                     }

                     do {
                        var12 = var8[var10] ^ var6;
                        char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
                        int var15 = 0;

                        do {
                           byte var10000;
                           switch (var15 % 5) {
                              case 0:
                              default:
                                 var10000 = 34;
                                 break;
                              case 1:
                                 var10000 = 80;
                                 break;
                              case 2:
                                 var10000 = 19;
                                 break;
                              case 3:
                                 var10000 = 38;
                                 break;
                              case 4:
                                 var10000 = 109;
                           }

                           byte var16 = var10000;
                           var14[var15] = (char)(var14[var15] ^ var16);
                           ++var15;
                        } while(var15 < var14.length);

                        var9[var10] = (new String(var14)).intern();
                        var11 += var12;
                        ++var10;
                     } while(var10 < var8.length);

                     var13 = 0;
                  }
               }

               public Object invoke(Object var1, Method var2, Object[] var3) {
                  if (var2.getDeclaringClass() == Object.class) {
                     String var6 = var2.getName();
                     byte var5 = -1;
                     switch (var6.hashCode()) {
                        case -1776922004:
                           if (var6.equals(I[3])) {
                              var5 = 0;
                           }
                           break;
                        case -1295482945:
                           if (var6.equals(I[1])) {
                              var5 = 2;
                           }
                           break;
                        case 147696667:
                           if (var6.equals(I[0])) {
                              var5 = 1;
                           }
                     }

                     Object var10000;
                     switch (var5) {
                        case 0 -> var10000 = lIlIII.Il(I[2]);
                        case 1 -> var10000 = System.identityHashCode(var1);
                        case 2 -> var10000 = var1 == (var3 != null && var3.length != 0 ? var3[0] : null);
                        default -> var10000 = null;
                     }

                     return var10000;
                  } else {
                     Object var4 = var3 != null && var3.length > 0 ? var3[0] : null;
                     IIIIIIIII.l = null.III(var4);
                     return null;
                  }
               }

               private static int II(int var0, int var1) {
                  return l[var0 ^ 1316689719] ^ var1 ^ var0;
               }

               private static String Il(short var0, int var1, char var2) {
                  int var3 = var2 ^ '큨';
                  char[] var4 = II[var3].toCharArray();
                  StackTraceElement[] var5 = (StackTraceElement[])Il[var3];
                  StackTraceElement[] var6;
                  if (var5 != null) {
                     var6 = var5;
                  } else {
                     var6 = (new Throwable()).getStackTrace();
                     Il[var3] = var6;
                  }

                  StackTraceElement var7 = var6[1];
                  int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 30058;
                  int var9 = 0;

                  do {
                     int var10 = var4[var9] ^ 27922;
                     var10 -= 25076;
                     var10 += 56187;
                     var10 += 54988;
                     var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var1 >> 16);
                     ++var9;
                  } while(var9 < var4.length);

                  return (new String(var4)).intern();
               }
            });
            var3.invoke(var1, var4);
            l = true;
         }
      }

      private static Method l(Class<?> var0) throws NoSuchMethodException {
         for(Method var4 : var0.getMethods()) {
            if (var4.getName().equals(lIlIII.Il(lI[5])) && var4.getParameterCount() == 1) {
               var4.setAccessible(true);
               return var4;
            }
         }

         throw new NoSuchMethodException(lIlIII.Il(lI[5]));
      }

      private static void II() {
         lI[0] = Il(III((short)'蝄', '\uf829', 1003510870).toCharArray(), 47451L, ll(-1282528955, 1584936141));
         lI[1] = Il(III((short)22356, '\uf828', 1044730403).toCharArray(), 77829L, ll(-1282528956, 742411217));
         lI[2] = Il(III((short)26466, '\uf82b', 176245149).toCharArray(), 59369L, ll(-1282528957, 822114565));
         lI[3] = Il(III((short)12190, '\uf82a', -881232871).toCharArray(), 88222L, ll(-1282528958, 1766421763));
         lI[4] = Il(III((short)25465, '\uf82d', 1559828419).toCharArray(), 16016L, ll(-1282528959, -556474154));
         lI[5] = Il(III((short)'잱', '\uf82c', 2125613676).toCharArray(), 29695L, ll(-1282528960, 384526891));
         lI[ll(-1282528945, 192293134)] = Il(III((short)'떋', '\uf82f', 1235241443).toCharArray(), 98543L, ll(-1282528946, 1749303843));
      }

      private static String Il(char[] var0, long var1, int var3) {
         int var4 = ll(-1282528947, -811671052) ^ var3;

         for(int var5 = 0; var5 < var0.length; ++var5) {
            int var7 = var4 ^ (int)var1 ^ ~var5;
            int var8 = var7 ^ var3 - var5 * var0.length;
            var4 = -var8 * var3 | var5;
            var0[var5] = (char)(var0[var5] ^ var4);
            int var6 = var5 & ll(-1282528948, -1034997108);
            var3 = var3 << var6 | var3 >>> -var6;
            var1 ^= (long)var6;
         }

         return new String(var0);
      }

      public void lI(Object var1) {
         if (var1 != null) {
            try {
               I();
               Class var2 = Class.forName(Il);
               Object var3 = var2.getField(lIlIII.Il(lI[0])).get((Object)null);
               Class var4 = Class.forName(I);
               Method var5 = l(var3.getClass());
               Object var6 = Proxy.newProxyInstance(var4.getClassLoader(), new Class[]{var4}, new InvocationHandler(var1) {
                  private final <undefinedtype> I;
                  private static String[] l;
                  private static final int[] II;
                  private static final String[] Il;
                  private static final Object[] lI;

                  private {
                     this.I = var1;
                  }

                  private static void I() {
                     l[0] = l(Il('仅', 44361, 1793482560).toCharArray(), 39206L, II(382899982, 617496808));
                     l[1] = l(Il('\uf163', 44360, -866498239).toCharArray(), 22836L, II(382899983, -2045171942));
                     l[2] = l(Il('펚', 44363, 1779061526).toCharArray(), 34965L, II(382899980, 480209231));
                     l[3] = l(Il('痜', 44362, -1980624521).toCharArray(), 77288L, II(382899981, -262463092));
                  }

                  public Object invoke(Object var1, Method var2, Object[] var3) {
                     if (var2.getDeclaringClass() == Object.class) {
                        String var6 = var2.getName();
                        byte var5 = -1;
                        switch (var6.hashCode()) {
                           case -1776922004:
                              if (var6.equals(l[1])) {
                                 var5 = 0;
                              }
                              break;
                           case -1295482945:
                              if (var6.equals(l[3])) {
                                 var5 = 2;
                              }
                              break;
                           case 147696667:
                              if (var6.equals(l[2])) {
                                 var5 = 1;
                              }
                        }

                        Object var10000;
                        switch (var5) {
                           case 0 -> var10000 = lIlIII.Il(l[0]);
                           case 1 -> var10000 = System.identityHashCode(var1);
                           case 2 -> var10000 = var1 == (var3 != null && var3.length != 0 ? var3[0] : null);
                           default -> var10000 = null;
                        }

                        return var10000;
                     } else {
                        Object var4 = var3 != null && var3.length > 0 ? var3[0] : null;
                        this.I.afterEntities(new llIIllI(var4) {
                           private final class_4587 I;
                           private final class_4597 l;
                           private final Matrix4f II;
                           private final class_4604 Il;
                           private final class_4184 lI;
                           private final Matrix4f ll;
                           private static String[] III;
                           private final class_757 IIl;
                           private static final int[] IlI;
                           private static final String[] Ill;
                           private static final Object[] lII;

                           private {
                              <undefinedtype> var2 = IIIIIIIII.II;
                              this.I = (class_4587)lIl(var1, class_4587.class, lIlIII.Il(III[1]), lIlIII.Il(III[3]));
                              this.l = (class_4597)lIl(var1, class_4597.class, lIlIII.Il(III[llI(-130092721, -46603189)]));
                              class_4604 var3 = (class_4604)lIl(var1, class_4604.class, lIlIII.Il(III[4]));
                              this.Il = var3 != null ? var3 : IIIIIIIII.l.l();
                              class_4184 var4 = (class_4184)lIl(var1, class_4184.class, lIlIII.Il(III[5]));
                              this.lI = var4 != null ? var4 : (class_4184)IIIIIIIII.I(var2.l(), IIIIIIIII.l.lI());
                              class_757 var5 = (class_757)lIl(var1, class_757.class, lIlIII.Il(III[llI(-130092722, -1082571948)]));
                              this.IIl = var5 != null ? var5 : (class_757)IIIIIIIII.I(var2.II(), IIIIIIIII.l.ll());
                              Matrix4f var6 = Il(var1, lIlIII.Il(III[llI(-130092723, -1251175724)]));
                              this.II = var6 != null ? var6 : (Matrix4f)IIIIIIIII.I(var2.I(), IIIIIIIII.l.Il());
                              Matrix4f var7 = Il(var1, lIlIII.Il(III[0]), lIlIII.Il(III[2]));
                              this.ll = var7 != null ? var7 : (Matrix4f)IIIIIIIII.I(var2.Il(), IIIIIIIII.l.IIl());
                           }

                           static {
                              short var6 = 11402;
                              String var7 = "렐訷ꋧ\udd40떮\ude2c\uf531㔅䀉슆翈畝⠉踺\uddb3䴱დంᏙ\ueba2⎳荕柦ﱅ\ude18㙟\uf4e6䝼Ӵﮓ橂蔘淤嬲ڸ뇸揮ʞ\ue48a\udc67옘핟혬馺䵩眬ⶏ㺁䰮ᆄ촣醟䍪ꈂꛚ\udb2e퀉饲灏졉镙⍕₰\u1af7윰ᔫ㨖\uda84ℤ餡묲\uf733♐ᣚ\ue85f渊㱻볶㚋든曛\udf15ఏ㟄\udef6ꛁ竞\u19af\u0a63偋\udd52繱锴钏┼뼸墦⫋㽍鬗駮㝅縷蝡谇䮇䉮\ud8f2⣎좾伡\ue844䄑\uf2d0繋쓬⩿⎈̬罿\udf4f橲嵮㤬珥춻\u0df9혴仐傑▂韅䗼\ue5b9堊愱뀭䤻⁽\ud895奭䂃妐ᱽ";
                              char[] var8 = "ⲒⲆⲖⲚⲆⲂⲚⲚⲆ".toCharArray();
                              String[] var9 = new String[var8.length];
                              byte var13 = -1;

                              while(true) {
                                 int var10 = 0;
                                 int var11 = 0;
                                 int var12 = 0;
                                 if (var13 == 0) {
                                    Ill = var9;
                                    lII = new Object[var9.length];
                                    int var2 = 1555675570;
                                    byte[] var0 = "Y¿¬¾\u001bþ\u000b¯\u0011ëÚ-â¨{ðZ.ãDOP±#|[\u0018\u0089\u008a¶÷\u001d´\u0090\u0005{ßÏß\u0002ÙÇ=AV!ø¤\u001dÇzem²¾_\u008b&þ÷¸9ÄF«§Aîá\u008d\u0000>".getBytes("ISO-8859-1");
                                    int var1 = var0.length / 4;
                                    IlI = new int[var1];
                                    int var3 = 0;
                                    int var4 = 0;

                                    do {
                                       int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
                                       var5 ^= var2;
                                       IlI[var4] = var5;
                                       var3 += 4;
                                       ++var4;
                                    } while(var4 < var1);

                                    III = new String[llI(-130092724, 1177498375)];
                                    IIl();
                                    return;
                                 }

                                 do {
                                    var12 = var8[var10] ^ var6;
                                    var9[var10] = var7.substring(var11, var11 + var12);
                                    var11 += var12;
                                    ++var10;
                                 } while(var10 < var8.length);

                                 var13 = 0;
                              }
                           }

                           public Matrix4f I() {
                              return this.ll;
                           }

                           public class_4604 l() {
                              return this.Il;
                           }

                           private static Object II(Object var0, String var1) {
                              if (var0 == null) {
                                 return null;
                              } else {
                                 try {
                                    Method var2 = var0.getClass().getMethod(var1);
                                    var2.setAccessible(true);
                                    return var2.invoke(var0);
                                 } catch (ReflectiveOperationException var3) {
                                    return null;
                                 }
                              }
                           }

                           private static Matrix4f Il(Object var0, String... var1) {
                              for(String var5 : var1) {
                                 Object var6 = II(var0, var5);
                                 if (var6 instanceof Matrix4fc var7) {
                                    return new Matrix4f(var7);
                                 }
                              }

                              return null;
                           }

                           public class_4587 lI() {
                              return this.I;
                           }

                           public class_4597 ll() {
                              return this.l;
                           }

                           public class_4184 III() {
                              return this.lI;
                           }

                           private static void IIl() {
                              III[0] = lII(lll(-1365426890, 47215, '䙔').toCharArray(), 32604L, llI(-130092725, -107352491));
                              III[1] = lII(lll(484195497, 15621, '䙕').toCharArray(), 3386L, llI(-130092726, 1220238837));
                              III[2] = lII(lll(-1293191851, 27303, '䙖').toCharArray(), 42325L, llI(-130092727, 1242976378));
                              III[3] = lII(lll(-1726213708, 44413, '䙗').toCharArray(), 53388L, llI(-130092728, 346675637));
                              III[4] = lII(lll(1147340984, 34757, '䙐').toCharArray(), 36082L, llI(-130092729, 474261416));
                              III[5] = lII(lll(-942442800, 64977, '䙑').toCharArray(), 34175L, llI(-130092730, -543668534));
                              III[llI(-130092731, 2101376432)] = lII(lll(2091281974, 22507, '䙒').toCharArray(), 43547L, llI(-130092732, 948950213));
                              III[llI(-130092733, -1186975085)] = lII(lll(534585673, 24406, '䙓').toCharArray(), 25780L, llI(-130092734, -1681962434));
                              III[llI(-130092735, 799127052)] = lII(lll(1031545986, 60882, '䙜').toCharArray(), 25705L, llI(-130092736, -1360893007));
                           }

                           public class_757 IlI() {
                              return this.IIl;
                           }

                           public Matrix4f Ill() {
                              return this.II;
                           }

                           private static String lII(char[] var0, long var1, int var3) {
                              int var4 = llI(-130092705, -35580495) ^ var3;

                              for(int var5 = 0; var5 < var0.length; ++var5) {
                                 int var7 = var4 ^ (int)var1 ^ ~var5;
                                 int var8 = var7 ^ var3 - var5 * var0.length;
                                 var4 = -var8 * var3 | var5;
                                 var0[var5] = (char)(var0[var5] ^ var4);
                                 int var6 = var5 & llI(-130092706, 1158301741);
                                 var3 = var3 << var6 | var3 >>> -var6;
                                 var1 ^= (long)var6;
                              }

                              return new String(var0);
                           }

                           private static <T> T lIl(Object var0, Class<T> var1, String... var2) {
                              if (var0 == null) {
                                 return null;
                              } else {
                                 for(String var6 : var2) {
                                    Object var7 = II(var0, var6);
                                    if (var1.isInstance(var7)) {
                                       return (T)var1.cast(var7);
                                    }
                                 }

                                 return null;
                              }
                           }

                           private static int llI(int var0, int var1) {
                              return IlI[var0 ^ -130092721] ^ var1 ^ var0;
                           }

                           private static String lll(int var0, int var1, char var2) {
                              int var3 = var2 ^ 18004;
                              char[] var4 = Ill[var3].toCharArray();
                              StackTraceElement[] var5 = (StackTraceElement[])lII[var3];
                              StackTraceElement[] var6;
                              if (var5 != null) {
                                 var6 = var5;
                              } else {
                                 var6 = (new Throwable()).getStackTrace();
                                 lII[var3] = var6;
                              }

                              StackTraceElement var7 = var6[1];
                              int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 6950;
                              int var9 = 0;

                              do {
                                 int var10 = var4[var9] - 11561;
                                 var10 += 18533;
                                 var10 -= 15169;
                                 var10 ^= 64249;
                                 var10 ^= 38348;
                                 var10 -= 36824;
                                 var10 ^= 32381;
                                 var10 ^= 32528;
                                 var10 ^= 34607;
                                 var10 ^= 5889;
                                 var4[var9] = (char)(var10 ^ var8 ^ var1 ^ var0 >> 16);
                                 ++var9;
                              } while(var9 < var4.length);

                              return (new String(var4)).intern();
                           }
                        });
                        return null;
                     }
                  }

                  static {
                     short var6 = 22945;
                     String var7 = "蘠嶨\ue381쎨쇂谤\udc59눿Ꮍ홄铲鰗捚俾趫몮䷾\ue1b9鯩됱묤⧺\uecc2⧬퓧\udd6a耩謀⬓፸済띟쪵✳镛삌\uf687ᾔ\ue93f馈ꬸ肐諷餫빒鿶ꂦ촥\ue600梢椰邩䯋ݣᥚ里º䨇줍勽؆ꜰ挺⥫ހ壞쌠ꉘ✑\u0a84弭䱺Ṩ軆";
                     char[] var8 = "妕妩妩妧".toCharArray();
                     String[] var9 = new String[var8.length];
                     byte var13 = -1;

                     while(true) {
                        int var10 = 0;
                        int var11 = 0;
                        int var12 = 0;
                        if (var13 == 0) {
                           Il = var9;
                           lI = new Object[var9.length];
                           int var2 = 1166579227;
                           byte[] var0 = "©+_>\u008c¢Ê\u0010\u0097ñ\u0000\n\u001eiÛ^îOúõ£\u009a2F".getBytes("ISO-8859-1");
                           int var1 = var0.length / 4;
                           II = new int[var1];
                           int var3 = 0;
                           int var4 = 0;

                           do {
                              int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
                              var5 ^= var2;
                              II[var4] = var5;
                              var3 += 4;
                              ++var4;
                           } while(var4 < var1);

                           l = new String[4];
                           I();
                           return;
                        }

                        do {
                           var12 = var8[var10] ^ var6;
                           char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
                           int var15 = 0;

                           do {
                              byte var10000;
                              switch (var15 % 5) {
                                 case 0:
                                 default:
                                    var10000 = 91;
                                    break;
                                 case 1:
                                    var10000 = 5;
                                    break;
                                 case 2:
                                    var10000 = 101;
                                    break;
                                 case 3:
                                    var10000 = 29;
                                    break;
                                 case 4:
                                    var10000 = 116;
                              }

                              byte var16 = var10000;
                              var14[var15] = (char)(var14[var15] ^ var16);
                              ++var15;
                           } while(var15 < var14.length);

                           var9[var10] = (new String(var14)).intern();
                           var11 += var12;
                           ++var10;
                        } while(var10 < var8.length);

                        var13 = 0;
                     }
                  }

                  private static String l(char[] var0, long var1, int var3) {
                     int var4 = II(382899978, -140505507) ^ var3;

                     for(int var5 = 0; var5 < var0.length; ++var5) {
                        int var7 = var4 ^ (int)var1 ^ ~var5;
                        int var8 = var7 ^ var3 - var5 * var0.length;
                        var4 = -var8 * var3 | var5;
                        var0[var5] = (char)(var0[var5] ^ var4);
                        int var6 = var5 & II(382899979, -255839319);
                        var3 = var3 << var6 | var3 >>> -var6;
                        var1 ^= (long)var6;
                     }

                     return new String(var0);
                  }

                  private static int II(int var0, int var1) {
                     return II[var0 ^ 382899982] ^ var1 ^ var0;
                  }

                  private static String Il(char var0, int var1, int var2) {
                     int var3 = var1 ^ '굉';
                     char[] var4 = Il[var3].toCharArray();
                     StackTraceElement[] var5 = (StackTraceElement[])lI[var3];
                     StackTraceElement[] var6;
                     if (var5 != null) {
                        var6 = var5;
                     } else {
                        var6 = (new Throwable()).getStackTrace();
                        lI[var3] = var6;
                     }

                     StackTraceElement var7 = var6[1];
                     int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 21892;
                     int var9 = 0;

                     do {
                        int var10 = var4[var9] ^ '\uf7cf';
                        var10 ^= 9598;
                        var10 += 15035;
                        var10 -= 34048;
                        var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var2 >> 16);
                        ++var9;
                     } while(var9 < var4.length);

                     return (new String(var4)).intern();
                  }
               });
               var5.invoke(var3, var6);
            } catch (ReflectiveOperationException var7) {
               throw new RuntimeException(lIlIII.Il(lI[1]), var7);
            }
         }
      }

      private static int ll(int var0, int var1) {
         return ll[var0 ^ -1282528953] ^ var1 ^ var0;
      }

      private static String III(short var0, char var1, int var2) {
         int var3 = var1 ^ '\uf829';
         char[] var4 = III[var3].toCharArray();
         StackTraceElement[] var5 = (StackTraceElement[])IIl[var3];
         StackTraceElement[] var6;
         if (var5 != null) {
            var6 = var5;
         } else {
            var6 = (new Throwable()).getStackTrace();
            IIl[var3] = var6;
         }

         StackTraceElement var7 = var6[1];
         int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 14100;
         int var9 = 0;

         do {
            int var10 = var4[var9] ^ '툰';
            var10 -= 3024;
            var10 -= 20422;
            var10 -= 9080;
            var10 += 28625;
            var10 -= 4234;
            var10 += 23603;
            var10 += 48404;
            var10 -= 44550;
            var10 ^= 51837;
            var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var2 >> 16);
            ++var9;
         } while(var9 < var4.length);

         return (new String(var4)).intern();
      }
   });
   private static volatile <undefinedtype> l = new Record((class_4184)null, (class_4604)null, (class_757)null, (Matrix4f)null, (Matrix4f)null) {
      private final class_4184 I;
      private final Matrix4f l;
      private final class_757 II;
      private final Matrix4f Il;
      private final class_4604 lI;
      private static String[] ll;
      private static final int[] III;
      private static final String[] IIl;
      private static final Object[] IlI;

      private static void I() {
         ll[0] = II(lIl((short)31044, 13630, 56063545).toCharArray(), 38311L, lII(-1685235517, 127535912));
         ll[1] = II(lIl((short)15235, 13631, -2116613411).toCharArray(), 99168L, lII(-1685235518, 984838823));
         ll[2] = II(lIl((short)'횀', 13628, -1876939051).toCharArray(), 41076L, lII(-1685235519, 787514172));
         ll[3] = II(lIl((short)'쀏', 13629, 1975083411).toCharArray(), 18390L, lII(-1685235520, 241332357));
         ll[4] = II(lIl((short)'툶', 13626, 769064990).toCharArray(), 45518L, lII(-1685235513, 1479451116));
         ll[5] = II(lIl((short)12714, 13627, 736429283).toCharArray(), 14368L, lII(-1685235514, -693913105));
      }

      public class_4604 l() {
         return this.lI;
      }

      private static String II(char[] var0, long var1, int var3) {
         int var4 = lII(-1685235515, -1634045308) ^ var3;

         for(int var5 = 0; var5 < var0.length; ++var5) {
            int var7 = var4 ^ (int)var1 ^ ~var5;
            int var8 = var7 ^ var3 - var5 * var0.length;
            var4 = -var8 * var3 | var5;
            var0[var5] = (char)(var0[var5] ^ var4);
            int var6 = var5 & lII(-1685235516, -420066106);
            var3 = var3 << var6 | var3 >>> -var6;
            var1 ^= (long)var6;
         }

         return new String(var0);
      }

      static {
         short var6 = 11701;
         String var7 = "\ue76a뺄\ue472㨭㺡皌Ⰻ礲퇔檡蠣Ͷ险֍㕌쵃灡\uee71༓Ո⒠\uf0dd⫶鰫恾ᜯ훞影碌稇鴯鴌捸뮟⒉דּ嬓⒌\udc28ꉪ僑㻸ྡᙕ徏\uaa39\ue929鋯ⅽ菋ࣔୗ\ud867눾↘枟꽈⣭葊\udca6崖⚙꘏湂憺쫏\ue674쇲㎪\ue0c3飪ꚽ퍌屮砙뱞\udd03ꀗꎖᓬ裃䚐\uf5d4⮍り\uee0d㐳쓂랳컅샤䒰娱䪳ડ뫙ὴ\ue0fd왃즲햺嗶㩇⩼";
         char[] var8 = "ⶥⶹⶽⶥⶭⶩ".toCharArray();
         String[] var9 = new String[var8.length];
         byte var13 = -1;

         while(true) {
            int var10 = 0;
            int var11 = 0;
            int var12 = 0;
            if (var13 == 0) {
               IIl = var9;
               IlI = new Object[var9.length];
               int var2 = -704779829;
               byte[] var0 = ";ø:ö ©\u0015úÂÉ2\u001e¥ZR\t\u009f*%©\u0098\u000bBéð\u0094¢¯¨\u0086ý6(W<Ò".getBytes("ISO-8859-1");
               int var1 = var0.length / 4;
               III = new int[var1];
               int var3 = 0;
               int var4 = 0;

               do {
                  int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
                  var5 ^= var2;
                  III[var4] = var5;
                  var3 += 4;
                  ++var4;
               } while(var4 < var1);

               ll = new String[lII(-1685235509, 1713868244)];
               I();
               return;
            }

            do {
               var12 = var8[var10] ^ var6;
               var9[var10] = var7.substring(var11, var11 + var12);
               var11 += var12;
               ++var10;
            } while(var10 < var8.length);

            var13 = 0;
         }
      }

      public Matrix4f Il() {
         return this.l;
      }

      public class_4184 lI() {
         return this.I;
      }

      public class_757 ll() {
         return this.II;
      }

      private static <undefinedtype> III(Object var0) {
         if (var0 == null) {
            return new <anonymous constructor>((class_4184)null, (class_4604)null, (class_757)null, (Matrix4f)null, (Matrix4f)null);
         } else {
            class_4184 var1 = (class_4184)Ill(var0, class_4184.class, lIlIII.Il(ll[2]));
            class_4604 var2 = (class_4604)Ill(var0, class_4604.class, lIlIII.Il(ll[1]));
            class_757 var3 = (class_757)Ill(var0, class_757.class, lIlIII.Il(ll[0]));
            Matrix4f var4 = IlI(var0, lIlIII.Il(ll[3]));
            Matrix4f var5 = IlI(var0, lIlIII.Il(ll[5]), lIlIII.Il(ll[4]));
            return new <anonymous constructor>(var1, var2, var3, var4, var5);
         }
      }

      public Matrix4f IIl() {
         return this.Il;
      }

      private {
         this.I = var1;
         this.lI = var2;
         this.II = var3;
         this.l = var4;
         this.Il = var5;
      }

      private static Matrix4f IlI(Object var0, String... var1) {
         for(String var5 : var1) {
            try {
               Method var6 = var0.getClass().getMethod(var5);
               var6.setAccessible(true);
               Object var7 = var6.invoke(var0);
               if (var7 instanceof Matrix4fc var8) {
                  return new Matrix4f(var8);
               }
            } catch (ReflectiveOperationException var9) {
            }
         }

         return null;
      }

      private static <T> T Ill(Object var0, Class<T> var1, String... var2) {
         for(String var6 : var2) {
            try {
               Method var7 = var0.getClass().getMethod(var6);
               var7.setAccessible(true);
               Object var8 = var7.invoke(var0);
               if (var1.isInstance(var8)) {
                  return (T)var1.cast(var8);
               }
            } catch (ReflectiveOperationException var9) {
            }
         }

         return null;
      }

      private static int lII(int var0, int var1) {
         return III[var0 ^ -1685235517] ^ var1 ^ var0;
      }

      private static String lIl(short var0, int var1, int var2) {
         int var3 = var1 ^ 13630;
         char[] var4 = IIl[var3].toCharArray();
         StackTraceElement[] var5 = (StackTraceElement[])IlI[var3];
         StackTraceElement[] var6;
         if (var5 != null) {
            var6 = var5;
         } else {
            var6 = (new Throwable()).getStackTrace();
            IlI[var3] = var6;
         }

         StackTraceElement var7 = var6[1];
         int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 13995;
         int var9 = 0;

         do {
            int var10 = var4[var9] ^ '쟾';
            var10 += 13317;
            var10 += 31354;
            var10 ^= 47255;
            var10 += 21407;
            var10 -= 29064;
            var10 -= 38830;
            var10 -= 31706;
            var10 += 33289;
            var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var2 >> 16);
            ++var9;
         } while(var9 < var4.length);

         return (new String(var4)).intern();
      }
   };
   private static volatile <undefinedtype> II = new Record((class_4184)null, (class_757)null, (Matrix4f)null, (Matrix4f)null) {
      private final class_4184 I;
      private final class_757 l;
      private final Matrix4f II;
      private final Matrix4f Il;

      public Matrix4f I() {
         return this.II;
      }

      private {
         this.I = var1;
         this.l = var2;
         this.II = var3;
         this.Il = var4;
      }

      public class_4184 l() {
         return this.I;
      }

      public class_757 II() {
         return this.l;
      }

      public Matrix4f Il() {
         return this.Il;
      }
   };

   private static <T> T I(T var0, T var1) {
      return var0 != null ? var0 : var1;
   }

   public static void l(class_4184 var0, class_757 var1, Matrix4f var2, Matrix4f var3) {
      II = new Record(var0, var1, II(var2), II(var3)) {
         private final class_4184 I;
         private final class_757 l;
         private final Matrix4f II;
         private final Matrix4f Il;

         public Matrix4f I() {
            return this.II;
         }

         private {
            this.I = var1;
            this.l = var2;
            this.II = var3;
            this.Il = var4;
         }

         public class_4184 l() {
            return this.I;
         }

         public class_757 II() {
            return this.l;
         }

         public Matrix4f Il() {
            return this.Il;
         }
      };
   }

   private static Matrix4f II(Matrix4f var0) {
      return var0 == null ? null : new Matrix4f(var0);
   }

   private IIIIIIIII() {
   }
}
