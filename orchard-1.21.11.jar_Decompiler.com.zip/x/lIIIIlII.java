package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_238;
import net.minecraft.class_243;

@Environment(EnvType.CLIENT)
public record lIIIIlII(double x, double y, double z, long timestampMs, double width, double height) {
   private final double I;
   private final double l;
   private final double II;
   private final double Il;
   private final double lI;
   private final long ll;
   private static final double III = 0.1;

   public class_243 I() {
      return new class_243(this.lI, this.Il, this.I);
   }

   public lIIIIlII(double var1, double var3, double var5, long var7, double var9, double var11) {
      var9 = Math.max(0.1, var9);
      var11 = Math.max(0.1, var11);
      this.lI = var1;
      this.Il = var3;
      this.I = var5;
      this.ll = var7;
      this.II = var9;
      this.l = var11;
   }

   public double l() {
      return this.I;
   }

   private static double II(double var0, double var2, double var4) {
      return var0 + (var2 - var0) * var4;
   }

   public class_238 Il() {
      double var1 = this.II * (double)0.5F;
      return new class_238(this.lI - var1, this.Il, this.I - var1, this.lI + var1, this.Il + this.l, this.I + var1);
   }

   public double lI() {
      return this.l;
   }

   public double ll() {
      return this.II;
   }

   public lIIIIlII III(lIIIIlII var1, long var2) {
      if (var1 != null && var1.ll != this.ll) {
         double var4 = (double)(var1.ll - this.ll);
         double var6 = Math.max((double)0.0F, Math.min((double)1.0F, (double)(var2 - this.ll) / var4));
         return new lIIIIlII(II(this.lI, var1.lI, var6), II(this.Il, var1.Il, var6), II(this.I, var1.I, var6), var2, II(this.II, var1.II, var6), II(this.l, var1.l, var6));
      } else {
         return this;
      }
   }

   public long IIl() {
      return this.ll;
   }

   public double IlI() {
      return this.Il;
   }

   public double Ill() {
      return this.lI;
   }
}
