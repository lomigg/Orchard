package x;

import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_490;
import net.minecraft.class_638;
import net.minecraft.class_746;

@Environment(EnvType.CLIENT)
public final class IllIllII extends IIIIIIIlI {
   private final lIIIIl I = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lllI(58439, '䂷', 1273133204)), false));
   private int l = llII(-1887239986, 1484165444);
   private Object II;
   private Object Il;
   private static final int lI = 35;
   private final llllIlIl ll = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(lllI(58432, '琙', -1944976619)), (double)0.0F, (double)0.0F, (double)0.0F, (double)1000.0F, (double)5.0F)).Ill(lIlIII.l(lllI(58433, '꾤', -409658514))));
   private final lIIIIl III = (lIIIIl)this.IIIlIll((lIIIIl)(new lIIIIl(lIlIII.l(lllI(58438, '㼝', 1416983437)), true)).lIII(() -> false));
   private class_490 IIl;
   private int IlI = llII(-1887239985, -156948685);
   private static final int Ill = 44;
   private long lII;
   private final IIIllIIII lIl = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(lllI(58436, '씅', -738845599)), (double)1.0F, (double)1.0F, (double)9.0F, (double)1.0F));
   private class_490 llI;
   private static final int lll = 9;
   private static final int IIII = 40;
   private static final int IIIl = 36;
   private static final int[] IIlI;
   private static final String[] IIll;
   private static final Object[] IlII;

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      this.IlII(var1);
      if (!this.IlIl(var1)) {
         this.llI(var1, false);
      } else {
         class_746 var2 = var1.field_1724;
         boolean var3 = !this.lIIl(var2.method_6079());
         boolean var4 = this.IIII(var2);
         class_437 var6 = var1.field_1755;
         if (var6 instanceof class_490) {
            class_490 var5 = (class_490)var6;
            if (var5 != this.llI) {
               this.llI = var5;
               this.l = var5 == this.IIl ? this.l : var2.field_6012 - 1;
               this.IlI = llII(-1887239988, 1914236965);
               this.lII = System.currentTimeMillis() + this.lII();
            }

            if (!var3 && !var4) {
               if (this.IIl == var5 && var2.field_6012 > this.l) {
                  var1.method_1507((class_437)null);
                  this.IIll();
               }

            } else if (var2.field_6012 > this.l && var2.field_6012 > this.IlI && System.currentTimeMillis() >= this.lII && var2.field_7498.method_34255().method_7960()) {
               if (var1.field_1761 != null) {
                  if (var3) {
                     int var10 = var4 ? this.lIII() : -1;
                     int var11 = this.lll(var2, var10);
                     if (var11 >= 0) {
                        var1.field_1761.method_2906(var2.field_7498.field_7763, var11, llII(-1887239987, 2082969806), class_1713.field_7791, var2);
                        this.Illl(var2);
                     }
                  } else {
                     if (var4) {
                        int var9 = this.lIII();
                        int var7 = this.lll(var2, var9);
                        if (var7 < 0) {
                           return;
                        }

                        var1.field_1761.method_2906(var2.field_7498.field_7763, var7, this.ll(), class_1713.field_7791, var2);
                        this.Illl(var2);
                     }

                  }
               }
            }
         } else {
            this.IIll();
            if (var1.field_1755 == null) {
               if (!(Boolean)this.III.III()) {
               }

               if ((var3 || var4) && this.lll(var2, -1) >= 0) {
                  class_490 var8 = new class_490(var2);
                  this.IIl = var8;
                  this.llI = var8;
                  this.l = var2.field_6012;
                  this.lII = System.currentTimeMillis() + this.lII();
                  var1.method_1507(var8);
               }
            }

         }
      }
   }

   private void II(boolean var1) {
      class_310 var2 = class_310.method_1551();
      this.llI(var2, var1);
      this.II = null;
      this.Il = null;
   }

   public void lI() {
      this.II(true);
   }

   public void lIl() {
      this.II(false);
   }

   private int ll() {
      return (int)Math.round((Double)this.lIl.III()) - 1;
   }

   private long lII() {
      long var1 = Math.max(0L, Math.round(Math.min(this.ll.IlII(), this.ll.IlI())));
      long var3 = Math.max(var1, Math.round(Math.max(this.ll.IlII(), this.ll.IlI())));
      return var1 == var3 ? var1 : ThreadLocalRandom.current().nextLong(var1, var3 + 1L);
   }

   public IllIllII() {
      super((Object)lIlIII.l(lllI(58434, '䧁', 981737085)), lIllII.I, (Object)lIlIII.l(lllI(58435, '\u2029', 1660574358)));
   }

   private void llI(class_310 var1, boolean var2) {
      if (var2 && var1 != null && var1.field_1755 == this.IIl) {
         var1.method_1507((class_437)null);
      }

      this.IIll();
   }

   private int lll(class_746 var1, int var2) {
      int var3 = Math.min(llII(-1887239992, 124347730), Math.min(llII(-1887239991, 771069254), var1.field_7498.field_7761.size() - 1));

      for(int var4 = llII(-1887239990, -582862100); var4 <= var3; ++var4) {
         if (var4 != var2 && this.lIIl(((class_1735)var1.field_7498.field_7761.get(var4)).method_7677())) {
            return var4;
         }
      }

      return -1;
   }

   private boolean IIII(class_746 var1) {
      return (Boolean)this.I.III() && !this.lIIl(var1.method_31548().method_5438(this.ll()));
   }

   private void IIll() {
      this.IIl = null;
      this.llI = null;
      this.l = llII(-1887239989, 1730699910);
      this.IlI = llII(-1887239996, 1308073796);
      this.lII = 0L;
   }

   private void IlII(class_310 var1) {
      class_746 var2 = var1 == null ? null : var1.field_1724;
      class_638 var3 = var1 == null ? null : var1.field_1687;
      if (var2 != this.II || var3 != this.Il) {
         this.II(false);
         this.II = var2;
         this.Il = var3;
      }
   }

   private boolean IlIl(class_310 var1) {
      return var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var1.field_1724.method_5805();
   }

   private void Illl(class_746 var1) {
      this.IlI = var1.field_6012;
      this.lII = System.currentTimeMillis() + this.lII();
   }

   private int lIII() {
      return llII(-1887239995, 1947067820) + this.ll();
   }

   private boolean lIIl(class_1799 var1) {
      return var1 != null && !var1.method_7960() && var1.method_31574(class_1802.field_8288);
   }

   private static int llII(int var0, int var1) {
      return IIlI[var0 ^ -1887239988] ^ var1 ^ var0;
   }

   static {
      short var6 = 29706;
      String var7 = "㣌㢎㢫㢿㢠㠈㢛㣆㢆㢬㣈㢄㢯㢑㣟㢮㢿㢎㣯㢮㣈㣧㢈㢿㢾㢣㢲㠰븺빮븡빬빐븝빘빹븻븋븶븸븜븂븭븗븉븑븸븅비븈빍븺븊빀빦븬븺븈빃빢빷빯빜빍븆븪븄빞븶븋븎븄빬븩븹빸브븋빇븄븜븲븭븦빭빷빫빟빼븋빍븀빑빻븇븜빛븿븕븳븭빠븎븘븃븋븛빠缁翳翥翉翫翦翸翾쿡쿚쿚쾷ァャゆをろュザピモイ゙ム邺邍邉邏郕郁郯邛邋邸郀邾邕還邫邜騜驫騯驩騳騧騉驽驭驞驤騃驹驼騎驒";
      char[] var8 = "琖瑚琂琎理琚琚".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IIll = var9;
            IlII = new Object[var9.length];
            int var2 = -810388564;
            byte[] var0 = "²)\u0083E<\u0016ë\u0087\u0098Gâ&6\u0094TPGX\u0016\u001amÄæ\u000f\u009dsI\u0083§\u0019\u0011á\u008dÆì,4<\u0096á".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IIlI = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IIlI[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 114;
                     break;
                  case 1:
                     var10000 = 92;
                     break;
                  case 2:
                     var10000 = 70;
                     break;
                  case 3:
                     var10000 = 85;
                     break;
                  case 4:
                     var10000 = 96;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static String lllI(int var0, char var1, int var2) {
      int var3 = var0 ^ '\ue442';
      char[] var4 = IIll[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])IlII[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         IlII[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 17061;
      int var9 = 0;

      do {
         int var10 = var4[var9] + 'ꆦ';
         var10 -= 3278;
         var10 -= 22191;
         var10 += 20033;
         var10 += 63590;
         var10 ^= 28928;
         var10 ^= 43799;
         var10 -= 10668;
         var10 += 20588;
         var4[var9] = (char)(var10 ^ var8 ^ var1 ^ var2 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
