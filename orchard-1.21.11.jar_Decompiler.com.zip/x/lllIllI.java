package x;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2480;
import net.minecraft.class_2588;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_5134;
import net.minecraft.class_5537;
import net.minecraft.class_6880;
import net.minecraft.class_7417;
import net.minecraft.class_746;
import net.minecraft.class_7923;
import net.minecraft.class_9285;
import net.minecraft.class_9304;
import net.minecraft.class_9334;
import net.minecraft.class_239.class_240;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;

@Environment(EnvType.CLIENT)
public final class lllIllI extends IIIIIIIlI {
   private int I;
   private static final int l = 2;
   private int II;
   private boolean Il;
   private boolean lI;
   private static final int ll = 27;
   private <undefinedtype> III;
   private final llllIlIl IIl;
   private int IlI;
   private final llllIlIl Ill;
   private static final int lII = 8;
   private int lIl;
   private final lIIIIl llI;
   private static final int lll = 2;
   private final lIIIIl IIII;
   private boolean IIIl;
   private final lIIIIl IIlI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IlIIlI(55878, 162217697, 58559)), false));
   private final lIIIIl IIll;
   private static final int IlII = 8;
   private final IlIIIlIlI<<undefinedtype>> IlIl;
   private boolean IllI;
   private <undefinedtype> Illl;
   private static final double lIII = (double)0.0625F;
   private static final int lIIl = 36;
   private int lIlI;
   private long lIll;
   private final llllIlIl llII;
   private long llIl;
   private class_2338 lllI;
   private boolean llll;
   private final lIIIIl IIIII;
   private long IIIIl;
   private final lIIIIl IIIlI;
   private final lIIIIl IIIll;
   private final IlIlIll IIlII;
   private int IIlIl;
   private static final int IIllI = 4;
   private final Map<Integer, <undefinedtype>> IIlll;
   private static final double IlIII = (double)20.25F;
   private class_2338 IlIIl;
   private final IIIllIIII IlIlI;
   private final lIIIIl IlIll;
   private class_2338 IllII;
   private static final int[] IllIl;
   private static final String[] IlllI;
   private static final Object[] Illll;

   private boolean II(class_310 var1, class_2338 var2) {
      return var2 != null && IlIlIl.lIll(var1, new class_3965(class_243.method_24953(var2), class_2350.field_11036, var2, false), false);
   }

   private boolean ll(class_310 var1) {
      class_437 var4 = var1.field_1755;
      if (var4 instanceof class_465 var2) {
         class_1703 var6 = var2.method_17577();
         if (var6 instanceof class_1707 var3) {
            if (var3.method_17388() == 3) {
               class_7417 var5 = var2.method_25440().method_10851();
               boolean var10000;
               if (var5 instanceof class_2588) {
                  class_2588 var7 = (class_2588)var5;
                  if (lIlIII.Il(IlIIlI(20808, 2103200248, 58537)).equals(var7.method_11022())) {
                     var10000 = true;
                     return var10000;
                  }
               }

               var10000 = false;
               return var10000;
            }
         }
      }

      return false;
   }

   private int IlI(llllIlIl var1) {
      return Math.max(0, (int)Math.ceil((double)this.llIlI(var1) / (double)50.0F));
   }

   private int lII(class_1703 var1, List<<undefinedtype>> var2) {
      int var3 = 0;
      int var4 = 0;

      for(int var5 = IlIIIl(-1653510949, -846479710); var5 < var1.field_7761.size(); ++var5) {
         class_1735 var6 = (class_1735)var1.field_7761.get(var5);
         if (var6 != null && var6.field_7874 >= 0 && var6.method_7681()) {
            class_1799 var7 = var6.method_7677();
            <undefinedtype> var8 = this.lIIII(var7);
            if (var8 != null) {
               ++var3;
               if (!this.IIlll.containsKey(var6.field_7874)) {
                  var2.add(new Record(var6.field_7874, var8, this.IIllII(var7, var8), var4) {
                     private final double I;
                     private final int l;
                     private final <undefinedtype> II;
                     private final int Il;

                     public int I() {
                        return this.l;
                     }

                     public int l() {
                        return this.Il;
                     }

                     public double II() {
                        return this.I;
                     }

                     private {
                        this.Il = var1;
                        this.II = var2;
                        this.I = var3;
                        this.l = var5;
                     }

                     public <undefinedtype> Il() {
                        return this.II;
                     }
                  });
               }

               ++var4;
            }
         }
      }

      return var3;
   }

   private boolean llI(class_1799 var1) {
      class_1792 var3 = var1.method_7909();
      boolean var10000;
      if (var3 instanceof class_1747 var2) {
         if (var2.method_7711() instanceof class_2480) {
            var10000 = true;
            return var10000;
         }
      }

      var10000 = false;
      return var10000;
   }

   private int lll(class_746 var1) {
      for(int var2 = 0; var2 < IlIIIl(-1653510950, -2141924081); ++var2) {
         if (var1.method_31548().method_5438(var2).method_31574(class_1802.field_8466)) {
            return var2;
         }
      }

      return -1;
   }

   public boolean IIII(class_310 var1) {
      return this.IIIIIlI() && this.ll(var1);
   }

   private void IIlI() {
      class_310 var1 = class_310.method_1551();
      if (var1 != null && var1.field_1724 != null) {
         IllllIlI.IlII(var1, this, null.II);
      }

      this.llIII();
      this.lllI = null;
      this.IlIIl = null;
      this.lIll = 0L;
      this.IIlIl = IlIIIl(-1653510951, 786423213);
      this.lI = false;
      this.lIl = IlIIIl(-1653510952, -1537979226);
      this.llll = false;
      this.IlI = IlIIIl(-1653510945, -806442681);
      this.IllI = false;
      this.IIIl = false;
      this.Illl = null;
   }

   private <undefinedtype> IIll(class_310 var1) {
      class_2338 var2 = var1.field_1724.method_24515();
      ArrayList var3 = new ArrayList();

      for(int var4 = -1; var4 <= 1; ++var4) {
         for(int var5 = IlIIIl(-1653510946, -81005569); var5 <= 2; ++var5) {
            for(int var6 = IlIIIl(-1653510947, 1826531426); var6 <= 2; ++var6) {
               if (var5 != 0 || var6 != 0) {
                  var3.add(var2.method_10069(var5, var4, var6));
               }
            }
         }
      }

      var3.sort(Comparator.comparingDouble((var1x) -> var1.field_1724.method_33571().method_1025(class_243.method_24953(var1x))));

      for(class_2338 var9 : var3) {
         if (this.lllI(var1, var9)) {
            class_2338 var10 = var9.method_10074();
            class_243 var7 = class_243.method_24953(var10).method_1031((double)0.0F, (double)0.4375F, (double)0.0F);
            if (this.lIll(var1.field_1724, var7) && this.IIllI(var1, var7, var10)) {
               return new Record(var9.method_10062(), var10.method_10062(), var7) {
                  private final class_243 I;
                  private final class_2338 l;
                  private final class_2338 II;

                  public class_2338 I() {
                     return this.l;
                  }

                  public class_2338 l() {
                     return this.II;
                  }

                  public class_243 II() {
                     return this.I;
                  }

                  private {
                     this.II = var1;
                     this.l = var2;
                     this.I = var3;
                  }
               };
            }
         }
      }

      return null;
   }

   private void IlII(class_310 var1, class_465<?> var2) {
      class_1703 var3 = var2.method_17577();
      if (var3 instanceof class_1707 var4) {
         if (var4.method_17388() == 3 && var3.method_34255() != null && var3.method_34255().method_7960()) {
            if (var3.field_7763 != this.lIlI) {
               this.lIlI = var3.field_7763;
               this.I = IlIIIl(-1653510948, -2034728224);
               this.IIlll.clear();
            }

            this.lIIl(var1, var3);
            ArrayList var5 = new ArrayList();
            int var6 = this.lII(var3, var5);
            if (var6 == 0) {
               this.IIIlll(var1);
               return;
            }

            this.I = IlIIIl(-1653510957, 1830405565);
            long var7 = System.currentTimeMillis();
            if (var7 - this.llIl < this.llIlI(this.IIl)) {
               return;
            }

            if (!var5.isEmpty() && lIlIllll.IIll(var1)) {
               this.llIl = var7;
               var5.sort(this.IllIl());
               int var9 = Math.min(IlIIIl(-1653510958, -1326741489), var5.size());

               for(int var10 = 0; var10 < var9; ++var10) {
                  int var11 = ((<undefinedtype>)var5.get(var10)).l();
                  this.IIllIl(var3, var11, var1.field_1724.field_6012);
                  var1.field_1761.method_2906(var3.field_7763, var11, 0, class_1713.field_7794, var1.field_1724);
               }

               lIlIllll.IllI(var1);
               return;
            }

            return;
         }
      }

   }

   private boolean Illl(class_1799 var1) {
      String var2 = class_7923.field_41178.method_10221(var1.method_7909()).method_12832();
      return var2.endsWith(lIlIII.Il(IlIIlI(46754, 942420822, 58536))) || var2.endsWith(lIlIII.Il(IlIIlI(58692, -106734024, 58539))) || var2.endsWith(lIlIII.Il(IlIIlI(45320, 1104487396, 58538))) || var2.endsWith(lIlIII.Il(IlIIlI(57391, 1143423358, 58541))) || var2.equals(lIlIII.Il(IlIIlI(41476, 1577846152, 58540)));
   }

   private boolean lIII(class_310 var1) {
      return this.IIlll(var1) && var1.field_1724.method_5805();
   }

   private void lIIl(class_310 var1, class_1703 var2) {
      int var3 = var1.field_1724.field_6012;
      this.IIlll.entrySet().removeIf((var3x) -> {
         if (var3 - ((<undefinedtype>)var3x.getValue()).l() >= IlIIIl(-1653510966, -1018130200)) {
            return true;
         } else {
            class_1735 var4 = this.IIlIlI(var2, (Integer)var3x.getKey());
            if (var4 != null && var4.method_7681()) {
               class_1799 var5 = var4.method_7677();
               return var5 == null || var5.method_7960() || !((<undefinedtype>)var3x.getValue()).Il(var5);
            } else {
               return true;
            }
         }
      });
   }

   private boolean lIll(class_746 var1, class_243 var2) {
      return var1 != null && var2 != null && var1.method_33571().method_1025(var2) <= (double)20.25F;
   }

   private void llII(class_310 var1, int var2) {
      if (this.IIlll(var1) && var2 >= 0 && var2 < IlIIIl(-1653510959, 1739997897)) {
         IllllIlI.llIIlI(var1, this, var2);
      }

      this.Illl = null;
   }

   private boolean lllI(class_310 var1, class_2338 var2) {
      if (this.IIlll(var1) && var2 != null) {
         class_2680 var3 = var1.field_1687.method_8320(var2);
         class_2338 var4 = var2.method_10074();
         class_2680 var5 = var1.field_1687.method_8320(var4);
         return (var3.method_26215() || var3.method_45474()) && !this.lllll(var1.field_1724, var2) && var5 != null && !var5.method_26215() && var5.method_26227().method_15769() && !var5.method_26220(var1.field_1687, var4).method_1110();
      } else {
         return false;
      }
   }

   private boolean IIIII(class_746 var1) {
      int var2 = Math.min(IlIIIl(-1653510960, -768163896), var1.method_31548().method_5439());

      for(int var3 = 0; var3 < var2; ++var3) {
         if (this.IIIIll(var1.method_31548().method_5438(var3))) {
            return true;
         }
      }

      return false;
   }

   private boolean IIIIl(class_1799 var1) {
      String var2 = class_7923.field_41178.method_10221(var1.method_7909()).method_12832();
      return var2.endsWith(lIlIII.Il(IlIIlI(22341, 1484089051, 58543))) || var2.endsWith(lIlIII.Il(IlIIlI(43834, -920646337, 58542))) || var2.endsWith(lIlIII.Il(IlIIlI(58286, -40948911, 58529))) || var2.endsWith(lIlIII.Il(IlIIlI(52449, 817785484, 58528))) || var2.endsWith(lIlIII.Il(IlIIlI(31657, -1852620530, 58531))) || var2.endsWith(lIlIII.Il(IlIIlI(49790, 1482703416, 58530))) || var2.equals(lIlIII.Il(IlIIlI(42558, -890869041, 58533))) || var2.equals(lIlIII.Il(IlIIlI(14790, 1896156583, 58532))) || var2.equals(lIlIII.Il(IlIIlI(41790, -258391030, 58535))) || var2.equals(lIlIII.Il(IlIIlI(17143, 2005807414, 58534))) || var2.equals(lIlIII.Il(IlIIlI(23519, 1467237612, 58553))) || var2.equals(lIlIII.Il(IlIIlI(31809, 268655481, 58552))) || var2.equals(lIlIII.Il(IlIIlI(60398, -2087365274, 58555))) || var2.equals(lIlIII.Il(IlIIlI(52737, -647757100, 58554)));
   }

   private void IIlII() {
      this.IlIIl = null;
      this.lIll = 0L;
      this.Illl = null;
   }

   public lllIllI() {
      super((Object)lIlIII.l(IlIIlI(41705, 735459197, 58557)), lIllII.l, (Object)lIlIII.l(IlIIlI(22523, 1685916949, 58556)));
      this.IlIl = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IlIIlI(33687, 70388845, 58558)), <undefinedtype>.class, null.II));
      this.IlIlI = (IIIllIIII)this.IIIlIll((IIIllIIII)(new IIIllIIII(lIlIII.l(IlIIlI(7347, 1573061379, 58545)), (double)50.0F, (double)1.0F, (double)100.0F, (double)1.0F)).lIII(() -> this.IlIl.III() == null.I));
      this.IIlII = new IlIlIll();
      this.II = -1;
      this.IIIlI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IlIIlI(58144, -152237812, 58544)), true));
      this.IIl = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(IlIIlI(60924, 554311028, 58547)), (double)25.0F, (double)50.0F, (double)0.0F, (double)300.0F, (double)5.0F)).Ill(lIlIII.l(IlIIlI(43123, 712801436, 58546))));
      this.Ill = (llllIlIl)this.IIIlIll((llllIlIl)(new llllIlIl(lIlIII.l(IlIIlI(63935, -1733591232, 58549)), (double)55.0F, (double)60.0F, (double)0.0F, (double)300.0F, (double)5.0F)).Ill(lIlIII.l(IlIIlI(12631, -768444278, 58548))).lIII(() -> false));
      this.llII = (llllIlIl)this.IIIlIll((llllIlIl)(new llllIlIl(lIlIII.l(IlIIlI(43790, -1897117398, 58551)), (double)10.0F, (double)25.0F, (double)0.0F, (double)300.0F, (double)5.0F)).Ill(lIlIII.l(IlIIlI(51719, -2050992035, 58550))).lIII(() -> false));
      this.IIll = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IlIIlI(11089, -349431979, 58505)), false));
      this.IIII = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IlIIlI(57024, 45304357, 58504)), true));
      this.IlIll = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IlIIlI(48935, -1802929696, 58507)), true));
      this.IIIII = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IlIIlI(10863, -525650827, 58506)), true));
      this.IIIll = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IlIIlI(39692, 1229086245, 58509)), true));
      this.llI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IlIIlI(26058, 1478043663, 58508)), true));
      this.IIlll = new HashMap();
      this.lIlI = IlIIIl(-1653510953, -302197949);
      this.I = IlIIIl(-1653510954, -161137793);
      this.IIlIl = IlIIIl(-1653510955, -2079136455);
      this.lIl = IlIIIl(-1653510956, -294912612);
      this.IlI = IlIIIl(-1653510965, 1515405294);
      IlIIIlIlI var10000 = this.IlIl;
      lIIIIl var10001 = this.IIlI;
      Objects.requireNonNull(var10001);
      var10000.lIII(var10001::III);
      lIIIIl var1 = this.IIIlI;
      var10001 = this.IIlI;
      Objects.requireNonNull(var10001);
      var1.lIII(var10001::III);
   }

   private boolean IIllI(class_310 var1, class_243 var2, class_2338 var3) {
      class_3965 var4 = var1.field_1687.method_17742(new class_3959(var1.field_1724.method_33571(), var2, class_3960.field_17559, class_242.field_1348, var1.field_1724));
      return var4 != null && var4.method_17783() != class_240.field_1333 && var4.method_17777().equals(var3);
   }

   private boolean IIlll(class_310 var1) {
      return var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null;
   }

   private void IlIIl(class_310 var1, class_2338 var2) {
      if (!this.IIlllI(var1, var2)) {
         this.lllI = null;
      } else {
         class_243 var3 = class_243.method_24953(var2);
         float[] var4 = IlIlIl.llIlI(var1, var3);
         if (var4 != null) {
            boolean var5;
            if (this.IlIl.III() == null.II) {
               this.llll = true;
               this.IlI = var1.field_1724.field_6012 + 2;
               var5 = IlIlIl.IIIIlI(var1, IlIIIl(-1653510967, -1207151745), var4[0], var4[1], () -> this.lIlll(var1, var2, var3));
            } else if (this.IlIl.III() == null.I) {
               this.IllII = var2;
               this.Il = true;
               this.IIIl = true;
               this.IIIIl = System.currentTimeMillis();
               var5 = true;
            } else {
               this.llll = true;
               this.IlI = var1.field_1724.field_6012 + 2;
               var5 = IlIlIl.IIIIlI(var1, IlIIIl(-1653510968, -621772086), var4[0], var4[1], () -> this.lIlll(var1, var2, var3));
            }

            if (!var5) {
               this.llll = false;
               this.IlI = IlIIIl(-1653510961, -581657609);
            }

         }
      }
   }

   private boolean IlIll(class_1799 var1) {
      return var1.method_57380().method_57845(class_9334.field_49637) != null || var1.method_57380().method_57845(class_9334.field_54199) != null;
   }

   private Comparator<<undefinedtype>> IllIl() {
      return Comparator.comparingInt((var0) -> var0.Il().IIl).thenComparing((var0, var1) -> var0.Il().l ? Double.compare(var1.II(), var0.II()) : 0).thenComparingInt(<undefinedtype>::I);
   }

   private double IlllI(String var1) {
      if (var1.equals(lIlIII.Il(IlIIlI(13746, -1903811747, 58511)))) {
         return (double)36.0F;
      } else if (var1.equals(lIlIII.Il(IlIIlI(34697, 164303424, 58510)))) {
         return (double)22.0F;
      } else if (var1.equals(lIlIII.Il(IlIIlI(24863, -761102605, 58497)))) {
         return (double)26.0F;
      } else if (!var1.equals(lIlIII.Il(IlIIlI(55240, -1773441745, 58496))) && !var1.equals(lIlIII.Il(IlIIlI(41490, -510954996, 58499))) && !var1.equals(lIlIII.Il(IlIIlI(39917, 1825798739, 58498)))) {
         if (!var1.equals(lIlIII.Il(IlIIlI(10929, 709306311, 58501))) && !var1.equals(lIlIII.Il(IlIIlI(20848, 105800327, 58500))) && !var1.equals(lIlIII.Il(IlIIlI(49561, 1587749951, 58503))) && !var1.equals(lIlIII.Il(IlIIlI(47277, 991843324, 58502)))) {
            return !var1.equals(lIlIII.Il(IlIIlI(61559, -399101318, 58521))) && !var1.equals(lIlIII.Il(IlIIlI(29923, 897717576, 58520))) && !var1.equals(lIlIII.Il(IlIIlI(19835, -1109906297, 58523))) && !var1.equals(lIlIII.Il(IlIIlI(46339, -688121026, 58522))) && !var1.equals(lIlIII.Il(IlIIlI(24533, -1410959234, 58525))) && !var1.equals(lIlIII.Il(IlIIlI(52536, -1035925209, 58524))) && !var1.equals(lIlIII.Il(IlIIlI(56224, 124128401, 58527))) && !var1.equals(lIlIII.Il(IlIIlI(46301, 2020941830, 58526))) ? (double)8.0F : (double)14.0F;
         } else {
            return (double)20.0F;
         }
      } else {
         return (double)24.0F;
      }
   }

   private <undefinedtype> lIIII(class_1799 var1) {
      if (var1 != null && !var1.method_7960()) {
         if (this.llI(var1)) {
            return (Boolean)this.IIIll.III() || (Boolean)this.IlIll.III() && this.IlIll(var1) ? null.ll : null;
         } else if (this.IIlIIl(var1)) {
            return (Boolean)this.llI.III() || (Boolean)this.IlIll.III() && this.IlIll(var1) ? null.lI : null;
         } else if (((Boolean)this.IIIII.III() || (Boolean)this.IIll.III()) && this.Illl(var1)) {
            return null.II;
         } else if ((Boolean)this.IIII.III() && this.IIIIl(var1)) {
            return null.III;
         } else {
            return (Boolean)this.IlIll.III() && this.IlIll(var1) ? null.I : null;
         }
      } else {
         return null;
      }
   }

   private void lIIlI(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         int var2 = var1.field_1724.field_6012;
         if (this.lI && this.lIl != IlIIIl(-1653510962, -1079406783) && var2 >= this.lIl) {
            this.lI = false;
            this.lIl = IlIIIl(-1653510963, 922051731);
         }

         if (this.llll && this.IlI != IlIIIl(-1653510964, 631796265) && var2 >= this.IlI) {
            this.llll = false;
            this.IlI = IlIIIl(-1653510973, -155756704);
         }

      }
   }

   private boolean lIlII(class_746 var1) {
      if (var1 != null && var1.field_7498 != null) {
         for(int var2 = 5; var2 <= IlIIIl(-1653510974, -1474015918); ++var2) {
            class_1735 var3 = (class_1735)var1.field_7498.field_7761.get(var2);
            if (var3 != null && var3.method_7681()) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public void lI() {
      this.IIlI();
      this.IIlII.IIIlIll();
   }

   private class_3965 lIllI(Object var1) {
      return var1 == null ? null : new class_3965(var1.II(), class_2350.field_11036, var1.I(), false);
   }

   private boolean lIlll(class_310 var1, class_2338 var2, class_243 var3) {
      boolean var10 = false;

      boolean var12;
      label66: {
         boolean var7;
         try {
            var10 = true;
            if (!this.IIlllI(var1, var2)) {
               this.lllI = null;
               var12 = false;
               var10 = false;
               break label66;
            }

            IllllIlI.lIllll(var1);
            class_3965 var4 = new class_3965(var3, class_2350.field_11036, var2, false);
            class_1269 var5 = IllllIlI.lIlII(var1, class_1268.field_5808, var4);
            boolean var6 = var5 != null && var5.method_23665();
            if (var6) {
               this.IIlIl = var1.field_1724.field_6012 + 4;
               this.IllI = false;
            }

            var7 = var6;
            var10 = false;
         } finally {
            if (var10) {
               this.llll = false;
               this.IlI = IlIIIl(-1653510969, 916088730);
               this.IIlII();
            }
         }

         this.llll = false;
         this.IlI = IlIIIl(-1653510976, 1858743384);
         this.IIlII();
         return var7;
      }

      this.llll = false;
      this.IlI = IlIIIl(-1653510975, -368563409);
      this.IIlII();
      return var12;
   }

   private void llIII() {
      this.lIlI = IlIIIl(-1653510970, 648171944);
      this.I = IlIIIl(-1653510971, 763671731);
      this.IIlll.clear();
   }

   private void llIIl(class_310 var1) {
      this.lIIlI(var1);
      if (!this.IIIl) {
         if (!this.lI && !this.llll) {
            if (this.lllI != null) {
               if (var1.field_1687.method_8320(this.lllI).method_27852(class_2246.field_10443)) {
                  if (!this.llllI(this.lllI)) {
                     return;
                  }

                  this.IlIIl(var1, this.lllI);
                  return;
               }

               this.lllI = null;
               this.IlIIl = null;
               this.lIll = 0L;
            }

            class_2338 var9 = this.IIIllI(var1);
            if (var9 != null) {
               this.lllI = var9;
               if (this.llllI(var9)) {
                  this.IlIIl(var1, var9);
               }
            } else if ((Boolean)this.IIIlI.III()) {
               int var11 = this.lll(var1.field_1724);
               <undefinedtype> var13 = this.IIll(var1);
               if (var11 >= 0 && var13 != null) {
                  int var15 = this.Illl != null ? this.Illl.I() : IllllIlI.lIIlI(var1.field_1724.method_31548());
                  if (this.IIIIIl(var1, var11)) {
                     if (this.llllI(var13.l())) {
                        float[] var6 = IlIlIl.llIlI(var1, var13.II());
                        if (var6 == null) {
                           this.llII(var1, var15);
                        } else {
                           boolean var7;
                           if (this.IlIl.III() == null.II) {
                              this.lI = true;
                              this.lIl = var1.field_1724.field_6012 + 2;
                              var7 = IlIlIl.IIIIlI(var1, IlIIIl(-1653510920, -1474633162), var6[0], var6[1], () -> this.llIll(var1, var13, var15));
                           } else if (this.IlIl.III() == null.I) {
                              this.III = var13;
                              this.II = var15;
                              this.Il = false;
                              this.IIIl = true;
                              this.IIIIl = System.currentTimeMillis();
                              var7 = true;
                           } else {
                              this.lI = true;
                              this.lIl = var1.field_1724.field_6012 + 2;
                              var7 = IlIlIl.IIIIlI(var1, IlIIIl(-1653510913, 475045981), var6[0], var6[1], () -> this.llIll(var1, var13, var15));
                           }

                           if (!var7) {
                              this.lI = false;
                              this.lIl = IlIIIl(-1653510914, -415051108);
                           }

                        }
                     }
                  }
               }
            }
         }
      } else {
         if (this.Il) {
            if (this.IllII == null) {
               this.IIIl = false;
               return;
            }

            boolean var2 = this.II(var1, this.IllII);
            float var3 = var2 ? 0.0F : this.IIlII.IlIl(var1, class_243.method_24953(this.IllII), ((Double)this.IlIlI.III()).floatValue());
            if (var2 || var3 <= 0.5F || System.currentTimeMillis() - this.IIIIl >= 1500L) {
               this.IIIl = false;
               float[] var4 = var2 ? new float[]{var1.field_1724.method_36454(), var1.field_1724.method_36455()} : IlIlIl.llIlI(var1, class_243.method_24953(this.IllII));
               boolean var5 = false;
               if (var4 != null) {
                  this.llll = true;
                  this.IlI = var1.field_1724.field_6012 + 2;
                  var5 = IlIlIl.IIIIlI(var1, IlIIIl(-1653510972, 1903671235), var4[0], var4[1], () -> this.lIlll(var1, this.IllII, class_243.method_24953(this.IllII)));
               }

               if (!var5) {
                  this.llll = false;
                  this.IlI = IlIIIl(-1653510917, 2080934212);
               }
            }
         } else {
            if (this.III == null) {
               this.IIIl = false;
               return;
            }

            boolean var8 = this.IIIlII(var1, this.III);
            float var10 = var8 ? 0.0F : this.IIlII.IlIl(var1, this.III.II(), ((Double)this.IlIlI.III()).floatValue());
            if (var8 || var10 <= 0.5F || System.currentTimeMillis() - this.IIIIl >= 1500L) {
               this.IIIl = false;
               float[] var12 = var8 ? new float[]{var1.field_1724.method_36454(), var1.field_1724.method_36455()} : IlIlIl.llIlI(var1, this.III.II());
               boolean var14 = false;
               if (var12 != null) {
                  this.lI = true;
                  this.lIl = var1.field_1724.field_6012 + 2;
                  var14 = IlIlIl.IIIIlI(var1, IlIIIl(-1653510918, 2082589486), var12[0], var12[1], () -> this.llIll(var1, this.III, this.II));
               }

               if (!var14) {
                  this.lI = false;
                  this.lIl = IlIIIl(-1653510919, -1725601618);
               }
            }
         }

      }
   }

   private long llIlI(llllIlIl var1) {
      double var2 = var1.IlII();
      double var4 = var1.IlI();
      return var2 == var4 ? Math.max(0L, Math.round(var2)) : Math.max(0L, Math.round(ThreadLocalRandom.current().nextDouble(var2, var4)));
   }

   private boolean llIll(class_310 var1, Object var2, int var3) {
      boolean var4 = false;
      boolean var9 = false;

      boolean var12;
      label85: {
         boolean var13;
         label84: {
            try {
               var9 = true;
               if (!this.IIlll(var1) || !this.lllI(var1, var2.l())) {
                  var12 = false;
                  var9 = false;
                  break label85;
               }

               IllllIlI.lIllll(var1);
               class_1269 var5 = IllllIlI.lIlII(var1, class_1268.field_5808, this.lIllI(var2));
               var4 = var5 != null && var5.method_23665();
               if (var4) {
                  this.lllI = var2.l();
                  this.IIlIl = var1.field_1724.field_6012 + 2;
                  var13 = true;
                  var9 = false;
                  break label84;
               }

               var13 = false;
               var9 = false;
            } finally {
               if (var9) {
                  this.lI = false;
                  this.lIl = IlIIIl(-1653510926, 1783893703);
                  this.IIlII();
                  this.llII(var1, var3);
               }
            }

            this.lI = false;
            this.lIl = IlIIIl(-1653510925, -886720104);
            this.IIlII();
            this.llII(var1, var3);
            return var13;
         }

         this.lI = false;
         this.lIl = IlIIIl(-1653510916, -1342241083);
         this.IIlII();
         this.llII(var1, var3);
         return var13;
      }

      this.lI = false;
      this.lIl = IlIIIl(-1653510915, -282760818);
      this.IIlII();
      this.llII(var1, var3);
      return var12;
   }

   private double lllII(class_1799 var1) {
      String var2 = class_7923.field_41178.method_10221(var1.method_7909()).method_12832();
      if (var2.startsWith(lIlIII.Il(IlIIlI(11528, -179485254, 58513)))) {
         return (double)700.0F;
      } else if (var2.startsWith(lIlIII.Il(IlIIlI(36293, 2106399148, 58512)))) {
         return (double)600.0F;
      } else if (var2.startsWith(lIlIII.Il(IlIIlI(12508, -631166422, 58515)))) {
         return (double)500.0F;
      } else if (var2.startsWith(lIlIII.Il(IlIIlI(6930, -1880211263, 58514)))) {
         return (double)440.0F;
      } else if (var2.startsWith(lIlIII.Il(IlIIlI(25818, -1509149381, 58517)))) {
         return (double)420.0F;
      } else if (var2.startsWith(lIlIII.Il(IlIIlI(15225, 673664062, 58516)))) {
         return (double)350.0F;
      } else if (var2.startsWith(lIlIII.Il(IlIIlI(740, 1027371225, 58519)))) {
         return (double)310.0F;
      } else if (var2.startsWith(lIlIII.Il(IlIIlI(21672, 1779448194, 58518)))) {
         return (double)220.0F;
      } else {
         return var2.startsWith(lIlIII.Il(IlIIlI(7173, -1999430333, 58601))) ? (double)180.0F : (double)300.0F;
      }
   }

   private boolean llllI(class_2338 var1) {
      long var2 = System.currentTimeMillis();
      if (var1 == null) {
         this.IlIIl = null;
         this.lIll = 0L;
         return true;
      } else if (this.IlIIl != null && this.IlIIl.equals(var1)) {
         return var2 >= this.lIll;
      } else {
         this.IlIIl = var1.method_10062();
         this.lIll = var2 + this.llIlI(this.IIl);
         return var2 >= this.lIll;
      }
   }

   private boolean lllll(class_746 var1, class_2338 var2) {
      return var1 != null && var1.method_5829().method_994(class_238.method_29968(class_243.method_24954(var2)).method_989((double)0.5F, (double)0.5F, (double)0.5F).method_1014(0.49));
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (!this.lIII(var1)) {
         this.IIlI();
      } else if (this.ll(var1)) {
         this.lI = false;
         this.lIl = IlIIIl(-1653510927, -1822123031);
         this.llll = false;
         this.IlI = IlIIIl(-1653510928, -1154910301);
         if ((Boolean)this.IIll.III() && this.lIlII(var1.field_1724)) {
            class_2338 var2 = this.IIIllI(var1);
            if (var2 != null && this.IIIIII(var1.field_1724)) {
               this.lllI = var2;
               this.IllI = true;
               var1.field_1724.method_7346();
               var1.method_1507((class_437)null);
               this.llIII();
               return;
            }
         }

         this.IllI = false;
         this.IlII(var1, (class_465)var1.field_1755);
      } else {
         this.llIII();
         if (var1.field_1755 == null && !lIlIllll.lIIl(var1) && var1.field_1724.field_6012 >= this.IIlIl) {
            if (!(Boolean)this.IIlI.III() && !this.IllI || !(Boolean)this.IIll.III() || !this.lIlII(var1.field_1724) || !this.IIIIII(var1.field_1724) || !this.IIIIlI(var1)) {
               if (this.IIIII(var1.field_1724)) {
                  if ((Boolean)this.IIlI.III() || this.IllI) {
                     this.llIIl(var1);
                  }
               }
            }
         }
      }
   }

   private boolean IIIIII(class_746 var1) {
      if (var1 == null) {
         return false;
      } else {
         for(int var2 = 0; var2 < IlIIIl(-1653510921, 1899477255); ++var2) {
            if (var1.method_31548().method_5438(var2).method_7960()) {
               return true;
            }
         }

         return false;
      }
   }

   private boolean IIIIIl(class_310 var1, int var2) {
      if (var1 != null && var1.field_1724 != null && var2 >= 0 && var2 < IlIIIl(-1653510922, -770886176)) {
         if (this.Illl == null || this.Illl.ll() != var2) {
            boolean var3 = IllllIlI.IIlIl(var1) != var2;
            int var4 = var3 ? this.IlI(this.IIl) : 0;
            this.Illl = IllllIlI.lIll(var1, this, var2, var4, true);
         }

         return IllllIlI.IlIllII(var1, this.Illl);
      } else {
         return false;
      }
   }

   private boolean IIIIlI(class_310 var1) {
      if (this.IIIIII(var1.field_1724) && lIlIllll.IIll(var1)) {
         for(int var2 = 5; var2 <= IlIIIl(-1653510923, 591205922); ++var2) {
            class_1735 var3 = (class_1735)var1.field_1724.field_7498.field_7761.get(var2);
            if (var3 != null && var3.method_7681() && var3.method_7674(var1.field_1724)) {
               var1.field_1761.method_2906(var1.field_1724.field_7498.field_7763, var2, 0, class_1713.field_7794, var1.field_1724);
               lIlIllll.IllI(var1);
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   private boolean IIIIll(class_1799 var1) {
      return this.lIIII(var1) != null;
   }

   private boolean IIIlII(class_310 var1, Object var2) {
      return IlIlIl.III(var1, this.lIllI(var2));
   }

   private class_2338 IIIllI(class_310 var1) {
      class_2338 var2 = var1.field_1724.method_24515();
      class_2338 var3 = null;
      double var4 = Double.MAX_VALUE;

      for(int var6 = IlIIIl(-1653510924, 1701091911); var6 <= 2; ++var6) {
         for(int var7 = IlIIIl(-1653510933, 1143642438); var7 <= 4; ++var7) {
            for(int var8 = IlIIIl(-1653510934, 1548488756); var8 <= 4; ++var8) {
               class_2338 var9 = var2.method_10069(var7, var6, var8);
               if (this.IIlllI(var1, var9)) {
                  double var10 = var1.field_1724.method_33571().method_1025(class_243.method_24953(var9));
                  if (var10 < var4) {
                     var4 = var10;
                     var3 = var9.method_10062();
                  }
               }
            }
         }
      }

      return var3;
   }

   private void IIIlll(class_310 var1) {
      if (!this.IIlll.isEmpty()) {
         this.I = IlIIIl(-1653510935, -1977439471);
      } else if (this.I == IlIIIl(-1653510936, 1749132601)) {
         this.I = var1.field_1724.field_6012;
      } else {
         if (var1.field_1724.field_6012 - this.I >= 2) {
            var1.field_1724.method_7346();
            var1.method_1507((class_437)null);
            this.llIII();
         }

      }
   }

   private double IIlIII(class_1799 var1) {
      return var1.method_7963() && var1.method_7936() > 0 ? (double)100.0F * (double)(var1.method_7936() - var1.method_7919()) / (double)var1.method_7936() : (double)100.0F;
   }

   private boolean IIlIIl(class_1799 var1) {
      return var1 != null && var1.method_7909() instanceof class_5537;
   }

   private class_1735 IIlIlI(class_1703 var1, int var2) {
      for(class_1735 var4 : var1.field_7761) {
         if (var4 != null && var4.field_7874 == var2) {
            return var4;
         }
      }

      return null;
   }

   private double IIlIll(class_1799 var1) {
      class_9304 var2 = (class_9304)var1.method_58695(class_9334.field_49633, class_9304.field_49385);
      double var3 = (double)0.0F;

      for(class_6880 var6 : var2.method_57534()) {
         String var7 = (String)var6.method_40230().map((var0) -> var0.method_29177().method_12832()).orElse("");
         int var8 = var2.method_57536(var6);
         var3 += (double)var8 * this.IlllI(var7);
      }

      return var3;
   }

   private double IIllII(class_1799 var1, Object var2) {
      if (!var2.l) {
         return (double)0.0F;
      } else {
         double var3 = this.lllII(var1) + this.IlIIII(var1) + this.IIlIll(var1) + this.IIlIII(var1);
         if (var2 == null.I) {
            if (var1.method_57380().method_57845(class_9334.field_49637) != null) {
               var3 += (double)180.0F;
            }

            if (var1.method_57380().method_57845(class_9334.field_54199) != null) {
               var3 += (double)140.0F;
            }

            var3 += (double)Math.min(IlIIIl(-1653510929, 1701543612), var1.method_7947());
         }

         return var3;
      }
   }

   private void IIllIl(class_1703 var1, int var2, int var3) {
      class_1735 var4 = this.IIlIlI(var1, var2);
      if (var4 != null && var4.method_7681()) {
         class_1799 var5 = var4.method_7677();
         if (var5 != null && !var5.method_7960()) {
            this.IIlll.put(var2, new Record(var5.method_7909().toString(), var5.method_7947(), var3) {
               private final int I;
               private final int l;
               private final String II;

               public String I() {
                  return this.II;
               }

               private {
                  this.II = var1;
                  this.l = var2;
                  this.I = var3;
               }

               public int l() {
                  return this.I;
               }

               public int II() {
                  return this.l;
               }

               boolean Il(class_1799 var1) {
                  return this.l == var1.method_7947() && this.II.equals(var1.method_7909().toString());
               }
            });
         }

      }
   }

   private boolean IIlllI(class_310 var1, class_2338 var2) {
      if (this.IIlll(var1) && var2 != null && var1.field_1687.method_8320(var2).method_27852(class_2246.field_10443)) {
         class_243 var3 = class_243.method_24953(var2);
         return this.lIll(var1.field_1724, var3) && this.IIllI(var1, var3, var2);
      } else {
         return false;
      }
   }

   public void lIl() {
      this.IIlI();
      this.IIlII.IIlIIII();
   }

   private double IlIIII(class_1799 var1) {
      double var2 = (double)0.0F;
      class_9285 var4 = (class_9285)var1.method_58695(class_9334.field_49636, class_9285.field_49326);

      for(class_9285.class_9287 var6 : var4.comp_2393()) {
         if (var6.comp_2395().equals(class_5134.field_23724)) {
            var2 += var6.comp_2396().comp_2449() * (double)80.0F;
         } else if (var6.comp_2395().equals(class_5134.field_23725)) {
            var2 += var6.comp_2396().comp_2449() * (double)45.0F;
         } else if (var6.comp_2395().equals(class_5134.field_23721)) {
            var2 += var6.comp_2396().comp_2449() * (double)65.0F;
         } else if (var6.comp_2395().equals(class_5134.field_23723)) {
            var2 += var6.comp_2396().comp_2449() * (double)10.0F;
         }
      }

      return var2;
   }

   private static int IlIIIl(int var0, int var1) {
      return IllIl[var0 ^ -1653510949] ^ var1 ^ var0;
   }

   static {
      short var6 = 29508;
      String var7 = "ං\u0d53ධඩ\u0dd7ණඈඟඖැං\u0dbeථ\u0dbe\u0dc8නඡൃඬෳඏයලග෪\u0d65ඝേꬡꫫꬼꬤꭩꬓꬊꬕꬤꭇꫪꫣﳎﴜﳏﳼﲌﳩﳇﳯﳎﲩﳻﳾﳣﳗﲎﴍ飰餶飽飱颦飸餶飺飿颹飿飆疯畩疀疚痫疦略疅鶹鶜鶒鶾鸕鶜鶪鶓ẛẮẂẐỗẚỮẒ뎱덴뎆뎊돦뎹뎂뎉뎷돒뎨덳\uef88\uef5e\uefbf\uef98\uefce\uefab\uef46\uef5a酲醿酳酈鄦酳鉌酊酽鄜醹醰䮑䭛䮌䮤䯛䮶䭓䭏箽筸箴管篿箟箼箖샨섵샮샶삤샐샶샙\uecfc\uece7\ued3c\uecf1\ueca3\uecd8\uecd1\uecd5\uecf3\uecb0\uecdf\ueced\ueccd\ued12\uecba\ued2d\ue210\ue203\ue207\ue239\ue24e\ue21b맜\ue206\ue20e\ue265\ue23f\ue227\ue225맩\ue253\ue230\ue20e\ue21b\ue203\ue266塗塜填塁堟塘塦売ℚ℡ℹ℉ⅴ℡⃜⃀셳셟셖섢섣셛셨셖셬섏솢솫쵕쵟쵇쵅\uf653\uf681\uf677\uf67d\uf603\uf649\uf65d\uf67b\uf64b\uf618\uf655\uf68a㑩㑄㑍㑂㐮㑬㒼㑂㑲㐵㑓㑐㑰㑪㐦㒡뇖뇳뇶뇅놅뇥뇶뇥뇘놾뇰뇿뇹뇠놺뇳뇪뇈뇚놓뇎먘뇟뇨놮먖뇿뇾뇘놾뇢뇴뇁뇧놭뇂뇹뇀뇴놡먟뇘먆뇘놟뇔뇽뇒뇄멌뇫뇊뇴뇯멇뇪뇀뇁먺놥먜뇕먉뇡놅뇇뇔뇷뇳멃뇉뇹놐뇮놋뇼뇦뇈뇶놝뇵뇎뇨뇦놘뇝먖뇠뇕놺뇪먗\uda3b\uda16\uda1b\uda30\uda7c퇇\uda29\uda2a\uda3b\uda7d\uda2f\uda2c\uda1c\udae3\uda6d\uda1a\uda1c\udad0\uda2f\uda5c䗰䗓䗥䗸䖺䗟㸲㸮ಠ౦಄ವകಁಶಕದೀಀ౽ရံျတၜဧဉဓရၻ࿚ဲွဠྂ࿓褣襮褆褭襪褂褛裻䭆䭴䭂䮶ⱌⲊⱬⱴⰵⱽⱆⱄⱗⰢⱤⱫⱨⰢⳑⱼꪨꫮꪸ꩜\ue032\ue012\ue038\ue021\ue064\ue013\ue012\ue00e\ue025\ue05c\ue02e\ue019\ue016\ue02c\udfa3\ue006؎یؚ\u0dfe趪趛趛趙跢趎趹趚趩跭趪超趰趨账趋跮趆趼贲\ud9a0\ud991\ud9b7\ud997\ud9ea\ud991\ud98e\ud960\ue9fe툰\ue9de\ue9ea\ue9b3\ue9d7\ue9d6\ue9ff\ue9e9\ue998\ue9d8\ue9c0\ue9dc\ue9f8\ue99e\ue9cc猐珍珐珢獛猖猛狍\udb9a\udb57\udb88\udb90\udbdd\udbb7\udba6\udc51\udb9d\udbd9\udb5d\udb5f렍롮렩렶롴렰력렶렆롞럕럜\uda90\udaab\udaab\udac0\udac2\udaba\udab3\udab7\uda89\udad8\uda43\uda4a齠齙齫龀鼱齦齿龲龀鼧龧齙齟齠鿬龽舤苍舠舺艵舽舞舵舊艬舦舽舨舱\ud999\ud9c8퐦폳퐤푀푲퐴퐤퐆푀푏폠퐃틅툀툌툡퉖툁툪툩툪퉐툞툅툉툧\ue9a5\ue9f4隥靍隓隑雈隭隆陜ᓐᓃᓛᓜᒌᒅᓋᓹᓏᒤᔁᔈ뚞띍뚓뚻뛴뚼뚵뚡뚇뛒뙉뙀溙湄湔溎滋溉溡溧溉滞溥溤溤準渄湕鈐鈪鈜鈏鉌鈫鈬鈏鈌鉯鈪꧋ﵭﵲﶭﵭﴽﵞﵘ﵏ﵿﴫﵰﵗﵛﶠﴯﶼ푍푒푖퐢퐗푹푓풉䔆䔯䔢䔩䕞䔑䔣䓇짤눏짘째즊징짎짶직즾눤징首饜馪馌駃馮馔馏馆駀馊馕驐馄駄馚馱馱饥餓ṥṰṨṷḈṋṸṪṁḱẔẝメリドッケヤンヽ愎惖惆愤慆愡愷愧愑慢惒愦愽愄慶愧㭶㭣㭍㭂㬧㭤㭫㭍㭬㬄㭽㭞㭅㭌㯰㮡䍇䍒䎳䍨䌩䍃䍂䍞䍨䌁䍚䎣䴗䷌䷑䴫䵆䴕䷌䳌盎真盰盔皘盿盈盗监皮盰盆盾盷睏眞哠唱哮哯咼哕哶哜哒咯唰唹⑴Ⓔ\u2458⑊\u243b⑷\u244e⑻俷倻俨俹侻促俰俎俄侭债倳儋僛儈儤兛儣儐儮儤免僚僓監盄盜盾皽盕盀盏盃皽盀眹";
      char[] var8 = "獘獈獔獈獌獌獌獈獌獈獌獌獌獔獐獌獌獈獀獈獔猘獐獌獈獔獌獀獔獀獔獀獐獌獔獌獈獈獈獔獔獈獔獌獈獈獔獈獔獌獌獈獐獈獌獔獔獈獌獔獈獌獈獈獈".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IlllI = var9;
            Illll = new Object[var9.length];
            int var2 = 947529102;
            byte[] var0 = "h\u0080÷ì%_\u009cR\u000bÔ\u0094ú\u0081_\u0005ðêåà\u0016¡ßEQ6*\u001eÏ£³Ë²H\u0012\u008cà\u0015àÁ[Â½\u000b\u009fw=ö²È÷\u009a\u001aÓnr'¡\u0019¬bË`´Æ\u007fXv«f[Ù¤\u001d\u0007\u001a\u0097\u007fûË#ø_Ò¶\u009a¢Æ\u0001\u0013þ-Ð\u0000£;kÓ¼\u001e-\r/\u0004\u0016Ï\u0003b`KÁe\u0016\u0013\u0091.Ó\u0003©\u0018à\b\u008fýøÔ|þ&Y\u0003À1Ù*\u0082õ¼.!Ù\r\u0011«ï¹[é\u0083ÂI\u009bìÊ. ý\u008aôO·î.ðåO_G»¶oÒ\u0096\u009e\">ÝÔ<ðZw\u0006|\u0091\u00866_Q?\u0090,Ã\u001eÞ/ß\u0006¸¦¬¯)âvMJì_À`7\u009d".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IllIl = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IllIl[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 69;
                     break;
                  case 1:
                     var10000 = 76;
                     break;
                  case 2:
                     var10000 = 80;
                     break;
                  case 3:
                     var10000 = 98;
                     break;
                  case 4:
                     var10000 = 20;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static String IlIIlI(int var0, int var1, int var2) {
      int var3 = var2 ^ '\ue4a9';
      char[] var4 = IlllI[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])Illll[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         Illll[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 406;
      int var9 = 0;

      do {
         int var10 = var4[var9] + 27024;
         var10 += 49572;
         var10 -= 39222;
         var10 ^= 21600;
         var10 += 40394;
         var10 -= 20875;
         var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
