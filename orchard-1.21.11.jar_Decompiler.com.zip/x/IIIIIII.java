package x;

import java.util.Locale;

public final class IIIIIII {
   private static String[] I;
   private static final <undefinedtype> l;
   private static final int[] II;
   private static final String[] Il;
   private static final Object[] lI;

   static {
      short var6 = 19000;
      String var7 = "\ue32c\ue059ﻸ쇊钥ůቮҦᔬオ읲왦ᦠ擮豦흯ㅏ크셜荞\udfff箰㣏ꗠ㋌包\uefdb\udbd2횏\ue345⩟㭇\u1941㨚蠴\uf17dઞ딬䚌鏬";
      char[] var8 = "䨴䨼䨼䨼䨰䨼䨼".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            Il = var9;
            lI = new Object[var9.length];
            int var2 = -2061280342;
            byte[] var0 = "ïû\u0019]´\u009e¢©\u009do#vú°Ñ\u0018&H6\u0088\u000b7÷åËÆ,g*{Æñ\u0095P\u008fSÌj÷¯ÌzÜ+*F\u0018L«\f^ü¥åß\u001a\t\u001asø".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            II = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               II[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            I = new String[IIl(-2054419354, -279687527)];
            Il();
            l = lI(System.getProperty(lIlIII.Il(I[0]), I[1]));
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public static boolean I() {
      return l == null.II;
   }

   private static String l(char[] var0, long var1, int var3) {
      int var4 = IIl(-2054419353, 1496767928) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IIl(-2054419356, -1648331705);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   public static boolean II() {
      return l == null.Il;
   }

   private static void Il() {
      I[0] = l(IlI((short)'먴', 'Ὡ', -1763824365).toCharArray(), 65711L, IIl(-2054419355, 529931059));
      I[1] = l("".toCharArray(), 92566L, IIl(-2054419358, -730240573));
      I[2] = l(IlI((short)29227, 'Ὠ', 1767658651).toCharArray(), 52851L, IIl(-2054419357, 612423829));
      I[3] = l(IlI((short)'频', 'Ὣ', 1424690806).toCharArray(), 68278L, IIl(-2054419360, 220008004));
      I[4] = l(IlI((short)'룗', 'Ὢ', -970579946).toCharArray(), 76852L, IIl(-2054419359, 975712226));
      I[5] = l(IlI((short)9073, 'Ὥ', 1615423941).toCharArray(), 35907L, IIl(-2054419346, 1762180630));
      I[IIl(-2054419345, -859463572)] = l(IlI((short)17863, 'Ὤ', -1826730730).toCharArray(), 74818L, IIl(-2054419348, -982801873));
      I[IIl(-2054419347, 719933324)] = l(IlI((short)'\uf1d4', 'Ὧ', -494121182).toCharArray(), 28829L, IIl(-2054419350, 1269929367));
   }

   private IIIIIII() {
   }

   private static <undefinedtype> lI(String var0) {
      String var1 = var0 == null ? I[1] : var0.toLowerCase(Locale.ROOT);
      if (var1.contains(lIlIII.Il(I[IIl(-2054419349, -1521841956)]))) {
         return null.II;
      } else if (!var1.contains(lIlIII.Il(I[4])) && !var1.contains(lIlIII.Il(I[5]))) {
         return !var1.contains(lIlIII.Il(I[3])) && !var1.contains(lIlIII.Il(I[IIl(-2054419352, 162866236)])) && !var1.contains(lIlIII.Il(I[2])) ? null.ll : null.Il;
      } else {
         return null.lI;
      }
   }

   public static boolean ll() {
      return l == null.lI;
   }

   public static <undefinedtype> III() {
      return l;
   }

   private static int IIl(int var0, int var1) {
      return II[var0 ^ -2054419354] ^ var1 ^ var0;
   }

   private static String IlI(short var0, char var1, int var2) {
      int var3 = var1 ^ 8041;
      char[] var4 = Il[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])lI[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         lI[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 4474;
      int var9 = 0;

      do {
         int var10 = var4[var9] + 16983;
         var10 += 23936;
         var10 ^= 36336;
         var10 -= 24667;
         var10 ^= 33329;
         var10 -= 26943;
         var10 += 4827;
         var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var2 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
