package x;

public final class IIIlllllI {
   private int I = -1;
   private long l = Long.MIN_VALUE;

   public static int I(long var0) {
      return Math.max(0, (int)Math.ceil((double)Math.max(0L, var0) / (double)50.0F));
   }

   public boolean l(int var1) {
      return this.I == var1;
   }

   public void II() {
      this.I = -1;
      this.l = Long.MIN_VALUE;
   }

   public boolean Il(int var1, long var2) {
      return this.I == var1 && var2 >= this.l;
   }

   public void lI(int var1, long var2, long var4) {
      this.I = var1;
      this.l = var2 + Math.max(0L, var4);
   }
}
