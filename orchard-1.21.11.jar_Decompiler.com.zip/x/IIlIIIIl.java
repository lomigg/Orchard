package x;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import java.awt.Color;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Objects;
import java.util.function.Function;
import java.util.function.IntPredicate;
import java.util.function.ToDoubleFunction;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_10799;
import net.minecraft.class_12245;
import net.minecraft.class_12246;
import net.minecraft.class_12247;
import net.minecraft.class_12249;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_7833;
import net.minecraft.class_327.class_6415;
import org.joml.Matrix4f;
import org.joml.Vector4f;

@Environment(EnvType.CLIENT)
public final class IIlIIIIl {
   private static final Method I;
   private static final int l = 15728880;
   private static final Vector4f II;
   private static final Method Il;
   private static final Matrix4f lI;
   private static final Method ll;
   private static final class_1921 III;
   private static final Method IIl;
   private static String[] IlI;
   private static final Method Ill;
   private static final Object lII;
   private static final class_1921 lIl;
   private static final Method llI;
   private static final class_1921 lll;
   private static final Method IIII;
   private static final Method IIIl;
   private static final Method IIlI;
   private static final Object IIll;
   private static final Method IlII;
   private static float IlIl;
   private static final Method IllI;
   private static final Method Illl;
   private static final Method lIII;
   private static final Object lIIl;
   private static final Object lIlI;
   private static final Method lIll;
   private static final class_1921 llII;
   private static final int[] llIl;
   private static final String[] lllI;
   private static final Object[] llll;

   public static void I(Object var0, class_238 var1, Color var2, double var3, float var5) {
      if (var1 != null && var2 != null && IIIl(var0, var1)) {
         if (var0 instanceof llIIllI) {
            llIIllI var6 = (llIIllI)var0;
            if (var6.lI() != null) {
               lIlI(var6.lI(), IIIlI(var6), var1, var2, var3, var5, llII);
               return;
            }
         }

         if (var0 instanceof WorldRenderContext) {
            WorldRenderContext var7 = (WorldRenderContext)var0;
            if (var7.matrices() != null) {
               lIlI(var7.matrices(), IIIlI(var7), var1, var2, var3, var5, llII);
            }
         }

      }
   }

   private static float l(float var0, float var1, float var2) {
      if (var2 <= 0.0F) {
         return 0.0F;
      } else {
         if (var0 < var2) {
            float var3 = var2 - var0;
            if (var3 > 0.0F && var3 < var2) {
               return (float)((double)var2 - Math.sqrt((double)(var2 * var2 - var3 * var3)));
            }
         } else if (var0 > var1 - var2) {
            float var4 = var0 - (var1 - var2);
            if (var4 > 0.0F && var4 < var2) {
               return (float)((double)var2 - Math.sqrt((double)(var2 * var2 - var4 * var4)));
            }
         }

         return 0.0F;
      }
   }

   public static void II(llIIllI var0, class_243 var1, class_243 var2, Color var3, double var4, float var6) {
      lIIlI(var6, () -> llIll(var0, var1, var2, var3, var4));
   }

   private IIlIIIIl() {
   }

   public static class_243 Il(Object var0) {
      if (var0 instanceof llIIllI var1) {
         return var1.III() != null ? var1.III().method_71156() : class_310.method_1551().field_1773.method_19418().method_71156();
      } else {
         return class_310.method_1551().field_1773.method_19418().method_71156();
      }
   }

   private static Object ll() {
      Object var0 = IIlIl(lIlIII.Il(IlI[1]), lIlIII.Il(IlI[2]));
      if (var0 == null) {
         var0 = IIlIl(lIlIII.Il(IlI[0]), lIlIII.Il(IlI[2]));
      }

      return var0;
   }

   private static float III(float var0) {
      return !Float.isFinite(var0) ? 1.0F : Math.max(0.5F, var0);
   }

   private static float IIl(float var0, float var1, float var2) {
      return Math.min(Math.min(var0, var1) / 2.0F, Math.max(0.0F, var2));
   }

   private static void IlI(float var0) {
      IlIl = III(var0);
      if (Il != null) {
         try {
            Il.invoke((Object)null, IlIl);
         } catch (ReflectiveOperationException var2) {
         }

      }
   }

   public static void Ill(Object var0, class_243 var1, float var2, float var3, float var4, Color var5, double var6) {
      if (var0 instanceof llIIllI var8) {
         IIIIl(var8, var1, var2, var3, var4, var5, var6);
      } else if (var0 instanceof WorldRenderContext var9) {
         IIIll(var9.matrices(), IIIlI(var9), var1, var2, var3, var4, var5, var6);
      }

   }

   private static void lII(class_4588 var0, Matrix4f var1, float var2, float var3, float var4, float var5, float var6, Color var7, double var8) {
      float var10 = (float)var7.getRed() / 255.0F;
      float var11 = (float)var7.getGreen() / 255.0F;
      float var12 = (float)var7.getBlue() / 255.0F;
      float var13 = (float)lllI(var8) / 255.0F;
      var0.method_22918(var1, var2, var3, var4).method_22915(var10, var11, var12, var13);
      var0.method_22918(var1, var2, var3, var6).method_22915(var10, var11, var12, var13);
      var0.method_22918(var1, var5, var3, var6).method_22915(var10, var11, var12, var13);
      var0.method_22918(var1, var5, var3, var4).method_22915(var10, var11, var12, var13);
   }

   private static void lIl(Method var0, Object... var1) {
      if (var0 != null) {
         try {
            var0.invoke((Object)null, var1);
         } catch (ReflectiveOperationException var3) {
         }

      }
   }

   public static void llI(llIIllI var0, class_238 var1, Color var2, double var3, float var5) {
      if (IlIII(var0) && var1 != null && var2 != null && IIIl(var0, var1)) {
         IIIlII(var0.lI(), var0.ll(), var1, var2, var3, var5);
      }
   }

   private static float lll(float var0, float var1, float var2, float var3) {
      if (var3 <= 0.0F) {
         return var2;
      } else {
         if (var0 < var3) {
            float var4 = var3 - var0;
            if (var4 > 0.0F && var4 < var3) {
               return (float)((double)(var2 - var3) + Math.sqrt((double)(var3 * var3 - var4 * var4)));
            }
         } else if (var0 > var1 - var3) {
            float var5 = var0 - (var1 - var3);
            if (var5 > 0.0F && var5 < var3) {
               return (float)((double)(var2 - var3) + Math.sqrt((double)(var3 * var3 - var5 * var5)));
            }
         }

         return var2;
      }
   }

   static {
      byte var6 = 88;
      String var7 = "㕭繙ꮫ導샛㸮舸셙퐩㎏鰂볢䠑┡留挔䍋궉\uf301\uec39\uf3ce\uf7fd垪ᛁ\ue7a5檉勪\uf8f4\uefe7嵷\udcba\uda38폍뛠㥆勀ֺ喆籔Ë눓䠶\ue81c휧ꂆ㏹張ꏯ㼛洝袭\uf7f0᭣ǉ緯\uf2e0͌犙鼗븒\u0ee8굒ᴤ頱♙䄧㽧颮ᷕ吢\ue150\uea19ፃ⹈싻ʛ\uec62\ue486쭒蘲\ud821说犥▆㿊搊ᒈ\ue7eb\ua95a\ue626麑酇腊涕კ曔먑龴\uef86옜缛ᕱ蚶\uf81c।紐阙დ䩻ᦾ萌낆䈄쬫\ue61f麘灒쾩豂밗ꑰ㙩묄ꋱ腬짝\ue8fe\ue5fe槄㾼坄塁⯝\udc2f絈ﭲ礶ᅶͧ㠯橝ꋭ쓰枬㊯帆\udedbꄣ複⑲⠙們나륖籅ڄ軫\udd28쀧⃜箔㓘껚兹중ﺔ\uf387\uef45‷﹙畿챝ᔟ\ue4e3\uefc5澇ᓘ뎝毡〒\ueceb\ue375ꘝ㇑ᚦ\u2d7b곒튨㏳籨嫄釀े\ue47b\ue941ᖁꌟ謢䒲ｇᩯ剢됫睠댹\uea39\uedd0谤倧丧먁釬\udde6绊䚔\ue8ecݶ\ue50dㇳ\ue771佨Ȁ掿࠹뾵휔靽\uf433귙瀨\ua7dbボ⩫ዳ냗痼﹂僶쇃聙ퟄ稐响㜈쬦\uf236\ue201九텷䵡ᬑ탡ꐐﵪ傈쫞Ѯ쉱煉콰\ud86e㝆嫚ᇬএ䙬鐖渾ᦃᔑ瀠迧ኈ䙺Ꮫ\uf302壚С귔꿰먙㻫ȥꨃၸㅤ鉾퓶䡑矍㍧曀厚ᚫｄ棾\udafe\u09a9띗뵴厳㱇掀띎֝뽙ꪖ᧵簆\u2b74諏\uf491븎\uec85屛फ़ᬕ８譨弡ꩯ큍蒒\udad2\uf527□契త兌\ue821ﵵﲵ囮캽棢ᄩᳩ䛯\ue29eꔨ衒鄉葚㇘\ud83c暒汢댴㥉뭶ܘꐒ辘㎮䒼搗觫馾粍Μ뾜\uef4e톃⨝ൃ\uea02ច닗᧵ꇙ⍔ẍꘌ綮褚\uf632ﭲ䲻\uf0eb臷₻桿詻\uec6cŀ뀈崕\ue793奻쯃㝣ⷧ䱩桜졊왢쿈ᛧ瓻\udf1c터㫸壇韯\ue612䘦ᵄ쇘\uf849ߺ닶床ᰪ쯿ᯬꆈ糑⍩孋軷λ\ue25d䩗䠌簋谬ႏ끢冁‽싶죕\ue649㽖\uecdc崎ꕔၚ鰌誨⽶ㄭ妋㩢༎ﮡ븝䥥殿䖧ઘ紶ཛ熖뮙䤏騑싱鑕\uee84଼\ue928眂东\uf409代Ḟ鸂皖狸\uf37dฑ遢报解礪䒊\ue5ef\uf7c1ㅜ褕筛妤ｉꭰ궫믧㺱、槝至\uec7c꺊㙏禲ꩰ\ud9d6槠ｂ므阤䒐玕確䠣獘짏癯\udf89瘌㊆완ഴ⭡㺿⠴쵣팱쟀ᩇꂎӄ\u0bbb谢冷旿͓슜ᶮ鏖㖍\uebac鬒癕弼셇ࠜ㠾\udae0柒럣\uf584瞏吩셎ԏ毖⽞邙ྌ羯䲩a䎞䒸\u2066Ꭲ軻츅⨨뮉愅ቆፆ쏃\ud8fc뽔틚\uf827엛\uec59뺞鞥ᾯ糂⏿⦢吏\udce9砓\u20f6ꋩ牯鬓客벾鬚쟥鄁⺷\uf748ν蔭ꂙ穂巤\ude2a쀳亄ꈀ쨬⁈ｼ\u177c盧魆㙌멓丁齽㖼풅㪷\ueba4辅㫴ㅀ傱嗡ᛴᆒ鵢ﵫ嵚䭌຺疍ഫ氖ဩ梯䢵屒땽뇲櫷瘑꿛녿覄槟ꕪෙ鎘糝⛃쩲\udfca傆\u12bf\ueb15ⶏ䭐㉌贱\ue7e9闔ऱ\ud852썀漼쇊緑ㅱ阥๚ᰠ咷\uf843䫑\uaa4eﭝ褗蛆蠤트橼놙糣\uea93㚱ﯹ忔稄ꉧ뾸菼雼哕幧㵊䏖\uec3b쨈\udc88梛䩊Ꮾ㫅\ue2ad㭥亴⤺愆ᥜ폴宙\uea61\ud921꠆קï\udfb9\ue3c3\udc5f뾍\udfd0\u0a00炪랯\ud834搧ແ\ue840。젔穷辫凎ꇾ茘䙵ᶖ₺翨꽀㑼\uf75c\ufddb엠ㅌ\uddea뛏\ueaf5침힖뺋喉ꮞ쀯\udedb䛁풳귪썰ῳ츮Ꜧ䰁\uf22aኇ砣\uf0daኧ譛簲傂ꀇ\u12b6䵝\ue4d8־︦玠آꝾᵙ뿁\uf429❈랤ṋ䉳嚏푪\ueadf戉媝罟䖡\udee6൬꒐⭌᰷茶뢆च阺唍\ue76cയต줉\ue907ၚ漿ꄋꈸ誺\uf751\u0a78‚棤뜷샖琬\u0004祍\ue99b㥮㏟\ue4d0㸸國㶝\uf87a턚\ue4fa꒒ぴ䟦텋릷섐\uf1d6\uf8c3흂\ufff8䩕\uef54沫㮵\uf53e\ue602ꅃ鄦⃭앃\ud82a䖞ఓ絴꧶\ud948\u09b5牂逕ꑲ丽⭧\ue4c6㥟\uea92髶Ꮔ審\uf187뼗\ueadd樗\ude00规缊䧲ꂃ\ue601츯혱\udcd0㦿趼ᗢ︃꒥門⪵哭圲䜼圤埬ʟ\ue30c歆蜐黒ㅢ喺ꋭ凛嗾쏦죑밁蠷숋㏽\uee3d낲ຨ뉻櫦\u173c觽窲툟\uece8ᓒ䯯按\uaad3䖥諈\uebe8㶰㣤鵂ᦧᣔힴ욯ᢙ\ufaffࢍ쌣챔쓍㼻꽞飉\uea2b䧑툒Ě鼜많為膷虁볆쯹턈볈័ןţ⢼ꇏ짱\uf0dbథ붯䛹㖞蟏⎜杴奎嬁땱ق엊ᢽꃛ훐";
      char[] var8 = "d`L\u001clTHHT`PHHDDl@pLLTHH\\HP@`Dxp`DL".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            lllI = var9;
            llll = new Object[var9.length];
            int var2 = -1637293362;
            byte[] var0 = "v\u000bz\rÌ¨\u000e|ò\u0084\u0086I®T,b:\u000eHðu@\u009fNÕyÂC/CæÅ\u0011E0\u008fuz(\u009d\u0017j\u009c3\u001a\b\u0017\bo#á\u0085tÅ\u009f\u0011\u000b\u0081h¹\u0003L<\t\u0000\u008d7\u000f#\ràìfQ\u0095NOÜ²\u001b)\u001cµù\u0085\u009aßAGy\u0082ýôJa\u000eq\u0001süO\u0003>£}\u001aÃ½ºyq\u0085¼\u0098Wuôz\u007f\u008c^í\u0005\u0088gk)\u0095\fòX>7:ÃéÊ\u0001u\u0084¶J7>Lf\u0080\u0096\u000eq=³»Éw\u0007'éø0\u0081v¿áyìËc\f\u001b»Ì\u0093\u008bè\u0000}E\u0085\u009côj`/Uv\u0092ñãÙ~*\u0092\u008f=jé\u001aR¦åòLå\u0016Ý\u0013P\u0080kºmX\u00ad^Þb\u0086½\u0002\u0098è?üÀLÂ\u0004\u0087\u009eç-\u0081>Bd\u0004\u008b\u0006\u008c\u0013µ§\u0006Bñþ+|ÌÙ@êÓ\u0004©ÒPY½þúõü\u0098\u0012Á¿W\u0010\u0098\rÓðm\u0081{§\u0010ïEü9AQ\u001d\n2\u000eå(Øæ,Û3v¶2,\u008e\u007fs\u009b\u009f£¨kÈ\n\u0084t\u001b@ämí²¼\u0098.,µ\u008aó8«\u0098\u0007Tr\u0003Ï\u0010\u008eF¶Jì Uï·½7d¼VW³»Q\r\u0087`5·9Â\u008c\u0019º§@§\u0080ïÿ;ÿÐÚÄ\u0094\u0099Ö2\nQstmë \"ÒiÈöãr¯\n±D\u0019ÄÆÐ¹\u008c×Z\"_\u0007\u0019[¿Ð\u0006tÿ!\u0004¾@À\u009a&\u0018\u009e÷äÅÉ¿¿\u0099X\u0095\u0099\u000f²Ò\u000bÄ·\u008cZ\u0003,q\n8Dz\u0012Ý\u0096\u0096Òh\u0080\"atÂ#\u0090a\u001eZ¸ÂAí\u008b§\u008f\u001eqC\u0080)^k*\u0015\\ÛÝ\u0015¦o6iw/Ñ>Ht¦)^ð\u00992P\u00127í\u0000\u0007\u009böñ_^\u0011©\u009dBèr¬\u0080\u0080n¡\u000e\u0017\u001fÓ¤:\u0096Af¨\tµó\u0007^\u0093\u007fuPtÛ\u008e[wÇGÀ\u0018¯hÂç×t\u0084oRy\"7´\u0083\\Iò\u0014\u0006î\bB\u000e\u0088\u0018ý0\u0010zq\u0080bËP\u001fvÓSõ\u008aÉ¼¢\fûzèÖ}\u0014¿\u0006^\u000f\u0083\u000eÎ`F\u0004ýT*ËN*wëb>öPå9xIòÂ_Ã\u0006ÖfH\u009aã|~y\u0003\u000f\u009ap\u0011oîôÕA÷\u001fÃÜ\u009c\u008b \u00ad\u0003ÚP¸A\u009b^} °\u0094xöfÊcÐ_\u0001ònJ¦ikSS,ä\"æZld7¤".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            llIl = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               llIl[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            IlI = new String[IlIIlI(344617448, -51779319)];
            IlIIIl();
            lI = new Matrix4f();
            II = new Vector4f();
            Il = lIllI(lIlIII.Il(IlI[4]), lIlIII.Il(IlI[IlIIlI(344617449, 1179295059)]), 1);
            I = lIllI(lIlIII.Il(IlI[4]), lIlIII.Il(IlI[IlIIlI(344617450, 2019956093)]), 0);
            lIII = lIllI(lIlIII.Il(IlI[4]), lIlIII.Il(IlI[IlIIlI(344617451, 615956309)]), 0);
            IIII = lIllI(lIlIII.Il(IlI[4]), lIlIII.Il(IlI[IlIIlI(344617452, -1326654498)]), 0);
            ll = lIllI(lIlIII.Il(IlI[4]), lIlIII.Il(IlI[IlIIlI(344617453, -6157195)]), 0);
            Ill = lIllI(lIlIII.Il(IlI[4]), lIlIII.Il(IlI[IlIIlI(344617454, 1604014457)]), 0);
            lIll = lIllI(lIlIII.Il(IlI[4]), lIlIII.Il(IlI[IlIIlI(344617455, -1516145181)]), 0);
            IIl = lIllI(lIlIII.Il(IlI[4]), lIlIII.Il(IlI[IlIIlI(344617440, -1683512409)]), 0);
            IIlI = lIllI(lIlIII.Il(IlI[4]), lIlIII.Il(IlI[5]), 1);
            IlII = lIllI(lIlIII.Il(IlI[4]), lIlIII.Il(IlI[IlIIlI(344617441, -6767706)]), 1);
            IllI = lIllI(lIlIII.Il(IlI[IlIIlI(344617442, -1652027632)]), lIlIII.Il(IlI[IlIIlI(344617443, -1863678928)]), 0);
            Illl = IIlIll(lIlIII.Il(IlI[IlIIlI(344617444, -440307040)]), lIlIII.Il(IlI[IlIIlI(344617445, -30995421)]), 2);
            llI = IIlIll(lIlIII.Il(IlI[IlIIlI(344617446, -2124153974)]), lIlIII.Il(IlI[IlIIlI(344617447, -1985040585)]), 0);
            IIIl = lIIll();
            lIIl = IIlIl(lIlIII.Il(IlI[3]), lIlIII.Il(IlI[IlIIlI(344617464, -1972394961)]));
            IIll = IIlIl(lIlIII.Il(IlI[3]), lIlIII.Il(IlI[IlIIlI(344617465, -1443925039)]));
            lII = IIlIl(lIlIII.Il(IlI[IlIIlI(344617466, -323811725)]), lIlIII.Il(IlI[2]));
            lIlI = ll();
            llII = class_1921.method_75940(lIlIII.Il(IlI[IlIIlI(344617467, -985784032)]), class_12247.method_75927(RenderPipeline.builder(new RenderPipeline.Snippet[]{class_10799.field_56859}).withLocation(lIlIII.Il(IlI[IlIIlI(344617468, -1543625003)])).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).build()).method_75930(class_12245.field_63976).method_75931(class_12246.field_63983).method_75938());
            lIl = class_1921.method_75940(lIlIII.Il(IlI[IlIIlI(344617469, 259542126)]), class_12247.method_75927(RenderPipeline.builder(new RenderPipeline.Snippet[]{class_10799.field_56859}).withLocation(lIlIII.Il(IlI[IlIIlI(344617470, -845475386)])).withDepthWrite(false).build()).method_75930(class_12245.field_63976).method_75938());
            lll = class_1921.method_75940(lIlIII.Il(IlI[IlIIlI(344617471, 2125001250)]), class_12247.method_75927(RenderPipeline.builder(new RenderPipeline.Snippet[]{class_10799.field_56859}).withLocation(lIlIII.Il(IlI[IlIIlI(344617456, -68951855)])).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).build()).method_75930(class_12245.field_63976).method_75938());
            III = class_1921.method_75940(lIlIII.Il(IlI[IlIIlI(344617457, -975065711)]), class_12247.method_75927(RenderPipeline.builder(new RenderPipeline.Snippet[]{class_10799.field_56860}).withLocation(lIlIII.Il(IlI[IlIIlI(344617458, -134721392)])).withCull(false).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withDepthWrite(false).build()).method_75937().method_75930(class_12245.field_63976).method_75938());
            IlIl = 1.0F;
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 125;
                     break;
                  case 1:
                     var10000 = 24;
                     break;
                  case 2:
                     var10000 = 75;
                     break;
                  case 3:
                     var10000 = 44;
                     break;
                  case 4:
                     var10000 = 14;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static void IIII(class_4588 var0, Matrix4f var1, class_243 var2, class_243 var3, class_243 var4, class_243 var5, class_243 var6, Color var7, double var8) {
      float var10 = (float)var7.getRed() / 255.0F;
      float var11 = (float)var7.getGreen() / 255.0F;
      float var12 = (float)var7.getBlue() / 255.0F;
      float var13 = (float)lllI(var8) / 255.0F;
      var0.method_22918(var1, (float)(var3.field_1352 - var2.field_1352), (float)(var3.field_1351 - var2.field_1351), (float)(var3.field_1350 - var2.field_1350)).method_22915(var10, var11, var12, var13);
      var0.method_22918(var1, (float)(var4.field_1352 - var2.field_1352), (float)(var4.field_1351 - var2.field_1351), (float)(var4.field_1350 - var2.field_1350)).method_22915(var10, var11, var12, var13);
      var0.method_22918(var1, (float)(var5.field_1352 - var2.field_1352), (float)(var5.field_1351 - var2.field_1351), (float)(var5.field_1350 - var2.field_1350)).method_22915(var10, var11, var12, var13);
      var0.method_22918(var1, (float)(var6.field_1352 - var2.field_1352), (float)(var6.field_1351 - var2.field_1351), (float)(var6.field_1350 - var2.field_1350)).method_22915(var10, var11, var12, var13);
   }

   public static boolean IIIl(Object var0, class_238 var1) {
      if (var1 == null) {
         return false;
      } else if (!(var0 instanceof llIIllI)) {
         return true;
      } else {
         llIIllI var2 = (llIIllI)var0;
         return var2.l() == null || var2.l().method_23093(var1);
      }
   }

   private static void IIlI(class_4587 var0, class_4597 var1, class_238 var2, Color var3, double var4, class_1921 var6) {
      if (var0 != null && var1 != null && var2 != null && var3 != null && var6 != null) {
         class_4184 var7 = class_310.method_1551().field_1773.method_19418();
         class_243 var8 = var7.method_71156();
         float var9 = (float)(var2.field_1323 - var8.field_1352);
         float var10 = (float)(var2.field_1322 - var8.field_1351);
         float var11 = (float)(var2.field_1321 - var8.field_1350);
         float var12 = (float)(var2.field_1320 - var8.field_1352);
         float var13 = (float)(var2.field_1325 - var8.field_1351);
         float var14 = (float)(var2.field_1324 - var8.field_1350);
         float var15 = (float)var3.getRed() / 255.0F;
         float var16 = (float)var3.getGreen() / 255.0F;
         float var17 = (float)var3.getBlue() / 255.0F;
         float var18 = (float)lllI(var4) / 255.0F;
         Matrix4f var19 = var0.method_23760().method_23761();
         class_4588 var20 = var1.method_73477(var6);
         var20.method_22918(var19, var9, var10, var11).method_22915(var15, var16, var17, var18);
         var20.method_22918(var19, var12, var10, var11).method_22915(var15, var16, var17, var18);
         var20.method_22918(var19, var12, var13, var11).method_22915(var15, var16, var17, var18);
         var20.method_22918(var19, var9, var13, var11).method_22915(var15, var16, var17, var18);
         var20.method_22918(var19, var9, var10, var14).method_22915(var15, var16, var17, var18);
         var20.method_22918(var19, var9, var13, var14).method_22915(var15, var16, var17, var18);
         var20.method_22918(var19, var12, var13, var14).method_22915(var15, var16, var17, var18);
         var20.method_22918(var19, var12, var10, var14).method_22915(var15, var16, var17, var18);
         var20.method_22918(var19, var9, var10, var11).method_22915(var15, var16, var17, var18);
         var20.method_22918(var19, var9, var10, var14).method_22915(var15, var16, var17, var18);
         var20.method_22918(var19, var12, var10, var14).method_22915(var15, var16, var17, var18);
         var20.method_22918(var19, var12, var10, var11).method_22915(var15, var16, var17, var18);
         var20.method_22918(var19, var9, var13, var11).method_22915(var15, var16, var17, var18);
         var20.method_22918(var19, var12, var13, var11).method_22915(var15, var16, var17, var18);
         var20.method_22918(var19, var12, var13, var14).method_22915(var15, var16, var17, var18);
         var20.method_22918(var19, var9, var13, var14).method_22915(var15, var16, var17, var18);
         var20.method_22918(var19, var9, var10, var11).method_22915(var15, var16, var17, var18);
         var20.method_22918(var19, var9, var13, var11).method_22915(var15, var16, var17, var18);
         var20.method_22918(var19, var9, var13, var14).method_22915(var15, var16, var17, var18);
         var20.method_22918(var19, var9, var10, var14).method_22915(var15, var16, var17, var18);
         var20.method_22918(var19, var12, var10, var11).method_22915(var15, var16, var17, var18);
         var20.method_22918(var19, var12, var10, var14).method_22915(var15, var16, var17, var18);
         var20.method_22918(var19, var12, var13, var14).method_22915(var15, var16, var17, var18);
         var20.method_22918(var19, var12, var13, var11).method_22915(var15, var16, var17, var18);
      }
   }

   public static void IIll(Object var0, class_238 var1, Color var2, double var3) {
      if (var1 != null && var2 != null && IIIl(var0, var1)) {
         if (var0 instanceof llIIllI) {
            llIIllI var5 = (llIIllI)var0;
            if (var5.lI() != null) {
               IIlI(var5.lI(), IIIlI(var5), var1, var2, var3, III);
               return;
            }
         }

         if (var0 instanceof WorldRenderContext) {
            WorldRenderContext var6 = (WorldRenderContext)var0;
            if (var6.matrices() != null) {
               IIlI(var6.matrices(), IIIlI(var6), var1, var2, var3, III);
            }
         }

      }
   }

   public static void IlII(llIIllI var0, class_243 var1, double var2, int var4, Color var5, double var6, float var8, boolean var9, IntPredicate var10) {
      if (IlIII(var0) && var1 != null && !(var2 <= (double)0.0F) && var4 >= 3 && var5 != null) {
         class_243 var11 = Il(var0);
         Matrix4f var12 = var0.lI().method_23760().method_23761();
         class_4588 var13 = IIIlI(var0).method_73477(var9 ? lIl : lll);
         float var14 = (float)var5.getRed() / 255.0F;
         float var15 = (float)var5.getGreen() / 255.0F;
         float var16 = (float)var5.getBlue() / 255.0F;
         float var17 = (float)lllI(var6) / 255.0F;
         float var18 = III(var8);

         for(int var19 = 0; var19 < var4; ++var19) {
            if (var10 == null || var10.test(var19)) {
               double var20 = (Math.PI * 2D) * (double)var19 / (double)var4;
               double var22 = (Math.PI * 2D) * (double)(var19 + 1) / (double)var4;
               float var24 = (float)(var1.field_1352 + Math.cos(var20) * var2 - var11.field_1352);
               float var25 = (float)(var1.field_1351 - var11.field_1351);
               float var26 = (float)(var1.field_1350 + Math.sin(var20) * var2 - var11.field_1350);
               float var27 = (float)(var1.field_1352 + Math.cos(var22) * var2 - var11.field_1352);
               float var29 = (float)(var1.field_1350 + Math.sin(var22) * var2 - var11.field_1350);
               float var30 = var27 - var24;
               float var31 = var29 - var26;
               float var32 = Math.max(1.0E-4F, class_3532.method_15355(var30 * var30 + var31 * var31));
               var30 /= var32;
               var31 /= var32;
               var13.method_22918(var12, var24, var25, var26).method_22915(var14, var15, var16, var17).method_60831(var0.lI().method_23760(), var30, 0.0F, var31).method_75298(var18);
               var13.method_22918(var12, var27, var25, var29).method_22915(var14, var15, var16, var17).method_60831(var0.lI().method_23760(), var30, 0.0F, var31).method_75298(var18);
            }
         }

      }
   }

   public static <T> void IlIl(Object var0, Iterable<? extends Iterable<T>> var1, Function<T, class_2338> var2, Function<T, Color> var3, ToDoubleFunction<T> var4) {
      if (var0 instanceof llIIllI var5) {
         if (IlIII(var5)) {
            for(Iterable var7 : var1) {
               for(Object var9 : var7) {
                  class_2338 var10 = (class_2338)var2.apply(var9);
                  if (var10 != null) {
                     IIlIII(var5, new class_238((double)var10.method_10263(), (double)var10.method_10264(), (double)var10.method_10260(), (double)var10.method_10263() + (double)1.0F, (double)var10.method_10264() + (double)1.0F, (double)var10.method_10260() + (double)1.0F), (Color)var3.apply(var9), var4.applyAsDouble(var9));
                  }
               }
            }

            return;
         }
      }

   }

   private static void Illl(llIIllI var0) {
      if (var0 != null && var0.ll() == null) {
         class_4597 var1 = IIIlI(var0);
         if (var1 instanceof class_4597.class_4598) {
            class_4597.class_4598 var2 = (class_4597.class_4598)var1;
            var2.method_22993();
         }

      }
   }

   private static void lIlI(class_4587 var0, class_4597 var1, class_238 var2, Color var3, double var4, float var6, class_1921 var7) {
      if (var0 != null && var1 != null && var2 != null && var3 != null && var7 != null) {
         class_4184 var8 = class_310.method_1551().field_1773.method_19418();
         class_243 var9 = var8.method_71156();
         float var10 = (float)(var2.field_1323 - var9.field_1352);
         float var11 = (float)(var2.field_1322 - var9.field_1351);
         float var12 = (float)(var2.field_1321 - var9.field_1350);
         float var13 = (float)(var2.field_1320 - var9.field_1352);
         float var14 = (float)(var2.field_1325 - var9.field_1351);
         float var15 = (float)(var2.field_1324 - var9.field_1350);
         float var16 = (float)var3.getRed() / 255.0F;
         float var17 = (float)var3.getGreen() / 255.0F;
         float var18 = (float)var3.getBlue() / 255.0F;
         float var19 = (float)lllI(var4) / 255.0F;
         Matrix4f var20 = var0.method_23760().method_23761();
         class_4588 var21 = var1.method_73477(var7);
         var21.method_22918(var20, var10, var11, var12).method_22915(var16, var17, var18, var19).method_60831(var0.method_23760(), 1.0F, 0.0F, 0.0F).method_75298(III(var6));
         var21.method_22918(var20, var13, var11, var12).method_22915(var16, var17, var18, var19).method_60831(var0.method_23760(), 1.0F, 0.0F, 0.0F).method_75298(III(var6));
         var21.method_22918(var20, var13, var11, var12).method_22915(var16, var17, var18, var19).method_60831(var0.method_23760(), 0.0F, 1.0F, 0.0F).method_75298(III(var6));
         var21.method_22918(var20, var13, var14, var12).method_22915(var16, var17, var18, var19).method_60831(var0.method_23760(), 0.0F, 1.0F, 0.0F).method_75298(III(var6));
         var21.method_22918(var20, var13, var14, var12).method_22915(var16, var17, var18, var19).method_60831(var0.method_23760(), -1.0F, 0.0F, 0.0F).method_75298(III(var6));
         var21.method_22918(var20, var10, var14, var12).method_22915(var16, var17, var18, var19).method_60831(var0.method_23760(), -1.0F, 0.0F, 0.0F).method_75298(III(var6));
         var21.method_22918(var20, var10, var14, var12).method_22915(var16, var17, var18, var19).method_60831(var0.method_23760(), 0.0F, -1.0F, 0.0F).method_75298(III(var6));
         var21.method_22918(var20, var10, var11, var12).method_22915(var16, var17, var18, var19).method_60831(var0.method_23760(), 0.0F, -1.0F, 0.0F).method_75298(III(var6));
         var21.method_22918(var20, var10, var11, var15).method_22915(var16, var17, var18, var19).method_60831(var0.method_23760(), 1.0F, 0.0F, 0.0F).method_75298(III(var6));
         var21.method_22918(var20, var13, var11, var15).method_22915(var16, var17, var18, var19).method_60831(var0.method_23760(), 1.0F, 0.0F, 0.0F).method_75298(III(var6));
         var21.method_22918(var20, var13, var11, var15).method_22915(var16, var17, var18, var19).method_60831(var0.method_23760(), 0.0F, 1.0F, 0.0F).method_75298(III(var6));
         var21.method_22918(var20, var13, var14, var15).method_22915(var16, var17, var18, var19).method_60831(var0.method_23760(), 0.0F, 1.0F, 0.0F).method_75298(III(var6));
         var21.method_22918(var20, var13, var14, var15).method_22915(var16, var17, var18, var19).method_60831(var0.method_23760(), -1.0F, 0.0F, 0.0F).method_75298(III(var6));
         var21.method_22918(var20, var10, var14, var15).method_22915(var16, var17, var18, var19).method_60831(var0.method_23760(), -1.0F, 0.0F, 0.0F).method_75298(III(var6));
         var21.method_22918(var20, var10, var14, var15).method_22915(var16, var17, var18, var19).method_60831(var0.method_23760(), 0.0F, -1.0F, 0.0F).method_75298(III(var6));
         var21.method_22918(var20, var10, var11, var15).method_22915(var16, var17, var18, var19).method_60831(var0.method_23760(), 0.0F, -1.0F, 0.0F).method_75298(III(var6));
         var21.method_22918(var20, var10, var11, var12).method_22915(var16, var17, var18, var19).method_60831(var0.method_23760(), 0.0F, 0.0F, 1.0F).method_75298(III(var6));
         var21.method_22918(var20, var10, var11, var15).method_22915(var16, var17, var18, var19).method_60831(var0.method_23760(), 0.0F, 0.0F, 1.0F).method_75298(III(var6));
         var21.method_22918(var20, var13, var11, var12).method_22915(var16, var17, var18, var19).method_60831(var0.method_23760(), 0.0F, 0.0F, 1.0F).method_75298(III(var6));
         var21.method_22918(var20, var13, var11, var15).method_22915(var16, var17, var18, var19).method_60831(var0.method_23760(), 0.0F, 0.0F, 1.0F).method_75298(III(var6));
         var21.method_22918(var20, var13, var14, var12).method_22915(var16, var17, var18, var19).method_60831(var0.method_23760(), 0.0F, 0.0F, 1.0F).method_75298(III(var6));
         var21.method_22918(var20, var13, var14, var15).method_22915(var16, var17, var18, var19).method_60831(var0.method_23760(), 0.0F, 0.0F, 1.0F).method_75298(III(var6));
         var21.method_22918(var20, var10, var14, var12).method_22915(var16, var17, var18, var19).method_60831(var0.method_23760(), 0.0F, 0.0F, 1.0F).method_75298(III(var6));
         var21.method_22918(var20, var10, var14, var15).method_22915(var16, var17, var18, var19).method_60831(var0.method_23760(), 0.0F, 0.0F, 1.0F).method_75298(III(var6));
      }
   }

   private static class_243[] lIll(class_243 var0, float var1, float var2, float var3) {
      double var4 = Math.toRadians((double)var3);
      double var6 = Math.cos(var4);
      double var8 = Math.sin(var4);
      double var10 = var0.field_1351 - (double)var2 / (double)2.0F;
      double var12 = var0.field_1351 + (double)var2 / (double)2.0F;
      double[][] var14 = new double[][]{{(double)(-var1), (double)(-var1)}, {(double)var1, (double)(-var1)}, {(double)var1, (double)var1}, {(double)(-var1), (double)var1}};
      class_243[] var15 = new class_243[IlIIlI(344617459, 815522480)];

      for(int var16 = 0; var16 < var14.length; ++var16) {
         double var17 = var14[var16][0];
         double var19 = var14[var16][1];
         double var21 = var17 * var6 - var19 * var8;
         double var23 = var17 * var8 + var19 * var6;
         var15[var16] = new class_243(var0.field_1352 + var21, var10, var0.field_1350 + var23);
         var15[var16 + 4] = new class_243(var0.field_1352 + var21, var12, var0.field_1350 + var23);
      }

      return var15;
   }

   public static <undefinedtype> llII(llIIllI var0, class_243 var1) {
      if (IlIII(var0) && var1 != null) {
         class_310 var2 = class_310.method_1551();
         if (var2.method_22683() == null) {
            return null;
         } else {
            int var3 = var2.method_22683().method_4486();
            int var4 = var2.method_22683().method_4502();
            if (var3 > 0 && var4 > 0) {
               Matrix4f var5 = var0.I();
               Matrix4f var6 = var0.Ill();
               class_243 var7 = Il(var0);
               lI.set(var5).mul(var6);
               Vector4f var8 = II.set((float)(var1.field_1352 - var7.field_1352), (float)(var1.field_1351 - var7.field_1351), (float)(var1.field_1350 - var7.field_1350), 1.0F);
               lI.transform(var8);
               if (Float.isFinite(var8.x) && Float.isFinite(var8.y) && Float.isFinite(var8.z) && Float.isFinite(var8.w) && !(var8.w < 0.05F)) {
                  float var9 = var8.x / var8.w;
                  float var10 = var8.y / var8.w;
                  float var11 = var8.z / var8.w;
                  if (Float.isFinite(var9) && Float.isFinite(var10) && Float.isFinite(var11) && !(var11 < -1.0F) && !(var11 > 1.0F)) {
                     double var12 = (double)((var9 * 0.5F + 0.5F) * (float)var3);
                     double var14 = (double)((-var10 * 0.5F + 0.5F) * (float)var4);
                     return Double.isFinite(var12) && Double.isFinite(var14) ? new Record(var12, var14, var11) {
                        private final float I;
                        private final double l;
                        private final double II;

                        public float I() {
                           return this.I;
                        }

                        public {
                           this.l = var1;
                           this.II = var3;
                           this.I = var5;
                        }

                        public double l() {
                           return this.II;
                        }

                        public double II() {
                           return this.l;
                        }
                     } : null;
                  } else {
                     return null;
                  }
               } else {
                  return null;
               }
            } else {
               return null;
            }
         }
      } else {
         return null;
      }
   }

   public static void llIl(llIIllI var0, class_2338 var1, Color var2, double var3) {
      if (IlIII(var0)) {
         class_243 var5 = Il(var0);
         float var6 = 0.06F;
         float var7 = (float)((double)var1.method_10263() - var5.field_1352) + var6;
         float var8 = (float)((double)var1.method_10264() - var5.field_1351) + 0.02F;
         float var9 = (float)((double)var1.method_10260() - var5.field_1350) + var6;
         float var10 = (float)((double)var1.method_10263() - var5.field_1352 + (double)1.0F) - var6;
         float var11 = (float)((double)var1.method_10260() - var5.field_1350 + (double)1.0F) - var6;
         Matrix4f var12 = var0.lI().method_23760().method_23761();
         class_4588 var13 = IIIlI(var0).method_73477(class_12249.method_76023());
         lII(var13, var12, var7, var8, var9, var10, var11, var2, var3);
      }
   }

   private static int lllI(double var0) {
      return Math.max(0, Math.min(IlIIlI(344617460, 914015408), (int)Math.round(var0)));
   }

   public static void llll(llIIllI var0, class_243 var1, double var2, int var4, Color var5, double var6, float var8) {
      IlII(var0, var1, var2, var4, var5, var6, var8, true, (var0x) -> true);
   }

   public static class_243 IIIII(class_1297 var0, float var1) {
      return var0.method_30950(var1);
   }

   public static void IIIIl(llIIllI var0, class_243 var1, float var2, float var3, float var4, Color var5, double var6) {
      if (IlIII(var0) && var1 != null && !(var2 <= 0.0F) && !(var3 <= 0.0F)) {
         IIIll(var0.lI(), IIIlI(var0), var1, var2, var3, var4, var5, var6);
      }
   }

   public static class_4597 IIIlI(Object var0) {
      if (var0 instanceof llIIllI var2) {
         return (class_4597)(var2.ll() != null ? var2.ll() : class_310.method_1551().method_22940().method_23000());
      } else if (var0 instanceof WorldRenderContext var1) {
         return (class_4597)(var1.consumers() != null ? var1.consumers() : class_310.method_1551().method_22940().method_23000());
      } else {
         return class_310.method_1551().method_22940().method_23000();
      }
   }

   private static void IIIll(class_4587 var0, class_4597 var1, class_243 var2, float var3, float var4, float var5, Color var6, double var7) {
      if (var0 != null && var1 != null && var2 != null) {
         class_243[] var9 = lIll(var2, var3, var4, var5);
         Matrix4f var10 = var0.method_23760().method_23761();
         class_4588 var11 = var1.method_73477(class_12249.method_76023());
         class_243 var12 = class_310.method_1551().field_1773.method_19418().method_71156();
         IIII(var11, var10, var12, var9[0], var9[1], var9[2], var9[3], var6, var7);
         IIII(var11, var10, var12, var9[4], var9[5], var9[IlIIlI(344617461, 2123951281)], var9[IlIIlI(344617462, -737175881)], var6, var7);
         IIII(var11, var10, var12, var9[0], var9[1], var9[5], var9[4], var6, var7);
         IIII(var11, var10, var12, var9[1], var9[2], var9[IlIIlI(344617463, -309740886)], var9[5], var6, var7);
         IIII(var11, var10, var12, var9[2], var9[3], var9[IlIIlI(344617416, -2045719745)], var9[IlIIlI(344617417, -1109896984)], var6, var7);
         IIII(var11, var10, var12, var9[3], var9[0], var9[4], var9[IlIIlI(344617418, 1088677511)], var6, var7);
         if (var1 instanceof class_4597.class_4598) {
            class_4597.class_4598 var13 = (class_4597.class_4598)var1;
            var13.method_22993();
         }

      }
   }

   public static void IIlII(llIIllI var0, Matrix4f var1, float var2, float var3, float var4, float var5, int var6, int var7) {
      int var8 = var6 >>> IlIIlI(344617419, 1017685027) & IlIIlI(344617420, -964422805);
      int var9 = var7 >>> IlIIlI(344617421, -2070696280) & IlIIlI(344617422, 824960248);
      if (IlIII(var0) && var1 != null && (var8 > 0 || var9 > 0) && !(var4 <= var2) && !(var5 <= var3)) {
         float var10 = (float)(var6 >> IlIIlI(344617423, -1391760607) & IlIIlI(344617408, 194259984)) / 255.0F;
         float var11 = (float)(var6 >> IlIIlI(344617409, -217163676) & IlIIlI(344617410, -2030491585)) / 255.0F;
         float var12 = (float)(var6 & IlIIlI(344617411, 426343410)) / 255.0F;
         float var13 = (float)var8 / 255.0F;
         float var14 = (float)(var7 >> IlIIlI(344617412, -140044666) & IlIIlI(344617413, 2122904539)) / 255.0F;
         float var15 = (float)(var7 >> IlIIlI(344617414, -543948303) & IlIIlI(344617415, 1765535196)) / 255.0F;
         float var16 = (float)(var7 & IlIIlI(344617432, 409841283)) / 255.0F;
         float var17 = (float)var9 / 255.0F;
         class_4588 var18 = IIIlI(var0).method_73477(class_12249.method_76023());
         var18.method_22918(var1, var2, var3, 0.0F).method_22915(var10, var11, var12, var13);
         var18.method_22918(var1, var2, var5, 0.0F).method_22915(var14, var15, var16, var17);
         var18.method_22918(var1, var4, var5, 0.0F).method_22915(var14, var15, var16, var17);
         var18.method_22918(var1, var4, var3, 0.0F).method_22915(var10, var11, var12, var13);
      }
   }

   private static Object IIlIl(String var0, String var1) {
      try {
         Class var2 = Class.forName(var0);
         Field var3 = var2.getDeclaredField(var1);
         var3.setAccessible(true);
         return var3.get((Object)null);
      } catch (ReflectiveOperationException var4) {
         return null;
      }
   }

   public static boolean IIllI(class_310 var0, class_1297 var1) {
      if (var0 != null && var0.field_1724 != null && var0.field_1687 != null && var1 != null && var1 != var0.field_1724) {
         if (var1 instanceof class_1657) {
            class_1657 var2 = (class_1657)var1;
            return llIIl(var0, var2);
         } else {
            return var1.method_5805() && !var1.method_7325();
         }
      } else {
         return false;
      }
   }

   private static void IIlll(class_4588 var0, Matrix4f var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8, float var9, float var10, float var11, float var12, float var13, float var14) {
      int var15 = Math.max(1, class_3532.method_15386(var4));

      for(int var16 = 0; var16 < var15; ++var16) {
         float var17 = Math.min(var4, (float)var16);
         float var18 = Math.min(var4, (float)var16 + 1.0F);
         if (!(var18 <= var17)) {
            float var19 = (var17 + var18) * 0.5F;
            float var20 = l(var19, var4, var6);
            float var21 = lll(var19, var4, var5, var6);
            if (!(var21 <= var20)) {
               var0.method_22918(var1, var2 + var17, var3 + var20, 0.0F).method_22915(var7, var8, var9, var10);
               var0.method_22918(var1, var2 + var17, var3 + var21, 0.0F).method_22915(var11, var12, var13, var14);
               var0.method_22918(var1, var2 + var18, var3 + var21, 0.0F).method_22915(var11, var12, var13, var14);
               var0.method_22918(var1, var2 + var18, var3 + var20, 0.0F).method_22915(var7, var8, var9, var10);
            }
         }
      }

   }

   public static boolean IlIII(Object var0) {
      if (var0 instanceof llIIllI var2) {
         return var2 != null && var2.lI() != null;
      } else if (!(var0 instanceof WorldRenderContext var1)) {
         return false;
      } else {
         return var1 != null && var1.matrices() != null;
      }
   }

   private static void IlIIl(class_4587 var0, class_4597 var1, class_238 var2, Color var3, double var4) {
      if (var0 != null && var2 != null && var3 != null) {
         class_4184 var6 = class_310.method_1551().field_1773.method_19418();
         class_243 var7 = var6.method_71156();
         float var8 = (float)(var2.field_1323 - var7.field_1352);
         float var9 = (float)(var2.field_1322 - var7.field_1351);
         float var10 = (float)(var2.field_1321 - var7.field_1350);
         float var11 = (float)(var2.field_1320 - var7.field_1352);
         float var12 = (float)(var2.field_1325 - var7.field_1351);
         float var13 = (float)(var2.field_1324 - var7.field_1350);
         float var14 = (float)var3.getRed() / 255.0F;
         float var15 = (float)var3.getGreen() / 255.0F;
         float var16 = (float)var3.getBlue() / 255.0F;
         float var17 = (float)lllI(var4) / 255.0F;
         Matrix4f var18 = var0.method_23760().method_23761();
         if (var1 != null) {
            class_4588 var25 = var1.method_73477(class_12249.method_76023());
            var25.method_22918(var18, var8, var9, var10).method_22915(var14, var15, var16, var17);
            var25.method_22918(var18, var11, var9, var10).method_22915(var14, var15, var16, var17);
            var25.method_22918(var18, var11, var12, var10).method_22915(var14, var15, var16, var17);
            var25.method_22918(var18, var8, var12, var10).method_22915(var14, var15, var16, var17);
            var25.method_22918(var18, var8, var9, var13).method_22915(var14, var15, var16, var17);
            var25.method_22918(var18, var8, var12, var13).method_22915(var14, var15, var16, var17);
            var25.method_22918(var18, var11, var12, var13).method_22915(var14, var15, var16, var17);
            var25.method_22918(var18, var11, var9, var13).method_22915(var14, var15, var16, var17);
            var25.method_22918(var18, var8, var9, var10).method_22915(var14, var15, var16, var17);
            var25.method_22918(var18, var8, var9, var13).method_22915(var14, var15, var16, var17);
            var25.method_22918(var18, var11, var9, var13).method_22915(var14, var15, var16, var17);
            var25.method_22918(var18, var11, var9, var10).method_22915(var14, var15, var16, var17);
            var25.method_22918(var18, var8, var12, var10).method_22915(var14, var15, var16, var17);
            var25.method_22918(var18, var11, var12, var10).method_22915(var14, var15, var16, var17);
            var25.method_22918(var18, var11, var12, var13).method_22915(var14, var15, var16, var17);
            var25.method_22918(var18, var8, var12, var13).method_22915(var14, var15, var16, var17);
            var25.method_22918(var18, var8, var9, var10).method_22915(var14, var15, var16, var17);
            var25.method_22918(var18, var8, var12, var10).method_22915(var14, var15, var16, var17);
            var25.method_22918(var18, var8, var12, var13).method_22915(var14, var15, var16, var17);
            var25.method_22918(var18, var8, var9, var13).method_22915(var14, var15, var16, var17);
            var25.method_22918(var18, var11, var9, var10).method_22915(var14, var15, var16, var17);
            var25.method_22918(var18, var11, var9, var13).method_22915(var14, var15, var16, var17);
            var25.method_22918(var18, var11, var12, var13).method_22915(var14, var15, var16, var17);
            var25.method_22918(var18, var11, var12, var10).method_22915(var14, var15, var16, var17);
         } else {
            IlIll(IIII);
            IlIll(Ill);
            IlIll(IIl);
            lllII();
            lIl(IlII, lIlI);

            try {
               Object var19 = lIlII(IllI);
               class_4588 var20 = (class_4588)IllII(var19, Illl, IIll, lII);
               if (var20 != null) {
                  var20.method_22918(var18, var8, var9, var10).method_22915(var14, var15, var16, var17);
                  var20.method_22918(var18, var11, var9, var10).method_22915(var14, var15, var16, var17);
                  var20.method_22918(var18, var11, var12, var10).method_22915(var14, var15, var16, var17);
                  var20.method_22918(var18, var8, var12, var10).method_22915(var14, var15, var16, var17);
                  var20.method_22918(var18, var8, var9, var13).method_22915(var14, var15, var16, var17);
                  var20.method_22918(var18, var8, var12, var13).method_22915(var14, var15, var16, var17);
                  var20.method_22918(var18, var11, var12, var13).method_22915(var14, var15, var16, var17);
                  var20.method_22918(var18, var11, var9, var13).method_22915(var14, var15, var16, var17);
                  var20.method_22918(var18, var8, var9, var10).method_22915(var14, var15, var16, var17);
                  var20.method_22918(var18, var8, var9, var13).method_22915(var14, var15, var16, var17);
                  var20.method_22918(var18, var11, var9, var13).method_22915(var14, var15, var16, var17);
                  var20.method_22918(var18, var11, var9, var10).method_22915(var14, var15, var16, var17);
                  var20.method_22918(var18, var8, var12, var10).method_22915(var14, var15, var16, var17);
                  var20.method_22918(var18, var11, var12, var10).method_22915(var14, var15, var16, var17);
                  var20.method_22918(var18, var11, var12, var13).method_22915(var14, var15, var16, var17);
                  var20.method_22918(var18, var8, var12, var13).method_22915(var14, var15, var16, var17);
                  var20.method_22918(var18, var8, var9, var10).method_22915(var14, var15, var16, var17);
                  var20.method_22918(var18, var8, var12, var10).method_22915(var14, var15, var16, var17);
                  var20.method_22918(var18, var8, var12, var13).method_22915(var14, var15, var16, var17);
                  var20.method_22918(var18, var8, var9, var13).method_22915(var14, var15, var16, var17);
                  var20.method_22918(var18, var11, var9, var10).method_22915(var14, var15, var16, var17);
                  var20.method_22918(var18, var11, var9, var13).method_22915(var14, var15, var16, var17);
                  var20.method_22918(var18, var11, var12, var13).method_22915(var14, var15, var16, var17);
                  var20.method_22918(var18, var11, var12, var10).method_22915(var14, var15, var16, var17);
                  Object var21 = IllII(var20, llI);
                  if (var21 != null) {
                     lIl(IIIl, var21);
                  }

                  return;
               }
            } finally {
               IlllI();
               IlIll(lIll);
               IlIll(ll);
            }

         }
      }
   }

   private static void IlIlI(class_4587 var0, class_238 var1, Color var2, double var3, float var5) {
      if (var0 != null && var1 != null && var2 != null) {
         class_4184 var6 = class_310.method_1551().field_1773.method_19418();
         class_243 var7 = var6.method_71156();
         float var8 = (float)(var1.field_1323 - var7.field_1352);
         float var9 = (float)(var1.field_1322 - var7.field_1351);
         float var10 = (float)(var1.field_1321 - var7.field_1350);
         float var11 = (float)(var1.field_1320 - var7.field_1352);
         float var12 = (float)(var1.field_1325 - var7.field_1351);
         float var13 = (float)(var1.field_1324 - var7.field_1350);
         float var14 = (float)var2.getRed() / 255.0F;
         float var15 = (float)var2.getGreen() / 255.0F;
         float var16 = (float)var2.getBlue() / 255.0F;
         float var17 = (float)lllI(var3) / 255.0F;
         Matrix4f var18 = var0.method_23760().method_23761();
         IlIll(IIII);
         IlIll(Ill);
         IlIll(IIl);
         lllII();
         lIl(IlII, lIlI);
         lIl(Il, III(var5));

         try {
            Object var19 = lIlII(IllI);
            class_4588 var20 = (class_4588)IllII(var19, Illl, lIIl, lII);
            if (var20 != null) {
               var20.method_22918(var18, var8, var9, var10).method_22915(var14, var15, var16, var17);
               var20.method_22918(var18, var11, var9, var10).method_22915(var14, var15, var16, var17);
               var20.method_22918(var18, var11, var9, var10).method_22915(var14, var15, var16, var17);
               var20.method_22918(var18, var11, var12, var10).method_22915(var14, var15, var16, var17);
               var20.method_22918(var18, var11, var12, var10).method_22915(var14, var15, var16, var17);
               var20.method_22918(var18, var8, var12, var10).method_22915(var14, var15, var16, var17);
               var20.method_22918(var18, var8, var12, var10).method_22915(var14, var15, var16, var17);
               var20.method_22918(var18, var8, var9, var10).method_22915(var14, var15, var16, var17);
               var20.method_22918(var18, var8, var9, var13).method_22915(var14, var15, var16, var17);
               var20.method_22918(var18, var11, var9, var13).method_22915(var14, var15, var16, var17);
               var20.method_22918(var18, var11, var9, var13).method_22915(var14, var15, var16, var17);
               var20.method_22918(var18, var11, var12, var13).method_22915(var14, var15, var16, var17);
               var20.method_22918(var18, var11, var12, var13).method_22915(var14, var15, var16, var17);
               var20.method_22918(var18, var8, var12, var13).method_22915(var14, var15, var16, var17);
               var20.method_22918(var18, var8, var12, var13).method_22915(var14, var15, var16, var17);
               var20.method_22918(var18, var8, var9, var13).method_22915(var14, var15, var16, var17);
               var20.method_22918(var18, var8, var9, var10).method_22915(var14, var15, var16, var17);
               var20.method_22918(var18, var8, var9, var13).method_22915(var14, var15, var16, var17);
               var20.method_22918(var18, var11, var9, var10).method_22915(var14, var15, var16, var17);
               var20.method_22918(var18, var11, var9, var13).method_22915(var14, var15, var16, var17);
               var20.method_22918(var18, var11, var12, var10).method_22915(var14, var15, var16, var17);
               var20.method_22918(var18, var11, var12, var13).method_22915(var14, var15, var16, var17);
               var20.method_22918(var18, var8, var12, var10).method_22915(var14, var15, var16, var17);
               var20.method_22918(var18, var8, var12, var13).method_22915(var14, var15, var16, var17);
               Object var21 = IllII(var20, llI);
               if (var21 != null) {
                  lIl(IIIl, var21);
               }

               return;
            }
         } finally {
            lIl(Il, 1.0F);
            IlllI();
            IlIll(lIll);
            IlIll(ll);
         }

      }
   }

   private static void IlIll(Method var0) {
      if (var0 != null) {
         try {
            var0.invoke((Object)null);
         } catch (ReflectiveOperationException var2) {
         }

      }
   }

   private static Object IllII(Object var0, Method var1, Object... var2) {
      if (var0 != null && var1 != null) {
         try {
            return var1.invoke(var0, var2);
         } catch (ReflectiveOperationException var4) {
            return null;
         }
      } else {
         return null;
      }
   }

   public static void IllIl(llIIllI var0, class_2960 var1, class_243 var2, double var3, double var5) {
      IIlIIl(var0, var1, var2, var3, var5, Color.WHITE);
   }

   private static void IlllI() {
      lIl(IIlI, true);
      IlIll(lIII);
   }

   public static void Illll(Object var0, class_238 var1, Color var2, double var3) {
      if (var0 instanceof llIIllI var5) {
         lIIII(var5, var1, var2, var3);
      }

   }

   public static void lIIII(llIIllI var0, class_238 var1, Color var2, double var3) {
      llI(var0, var1, var2, var3, 1.0F);
   }

   public static void lIIIl(llIIllI var0, class_243 var1, class_243 var2, class_243 var3, Color var4, double var5) {
      if (IlIII(var0) && var1 != null && var2 != null && var3 != null && var4 != null) {
         class_243 var7 = Il(var0);
         Matrix4f var8 = var0.lI().method_23760().method_23761();
         class_4588 var9 = IIIlI(var0).method_73477(class_12249.method_76023());
         float var10 = (float)var4.getRed() / 255.0F;
         float var11 = (float)var4.getGreen() / 255.0F;
         float var12 = (float)var4.getBlue() / 255.0F;
         float var13 = (float)lllI(var5) / 255.0F;
         var9.method_22918(var8, (float)(var1.field_1352 - var7.field_1352), (float)(var1.field_1351 - var7.field_1351), (float)(var1.field_1350 - var7.field_1350)).method_22915(var10, var11, var12, var13);
         var9.method_22918(var8, (float)(var2.field_1352 - var7.field_1352), (float)(var2.field_1351 - var7.field_1351), (float)(var2.field_1350 - var7.field_1350)).method_22915(var10, var11, var12, var13);
         var9.method_22918(var8, (float)(var3.field_1352 - var7.field_1352), (float)(var3.field_1351 - var7.field_1351), (float)(var3.field_1350 - var7.field_1350)).method_22915(var10, var11, var12, var13);
         var9.method_22918(var8, (float)(var1.field_1352 - var7.field_1352), (float)(var1.field_1351 - var7.field_1351), (float)(var1.field_1350 - var7.field_1350)).method_22915(var10, var11, var12, var13);
      }
   }

   private static void lIIlI(float var0, Runnable var1) {
      float var2 = IlIl;
      IlI(var0);

      try {
         var1.run();
      } finally {
         IlIl = var2;
      }

   }

   private static Method lIIll() {
      Method var0 = lIllI(lIlIII.Il(IlI[IlIIlI(344617433, 1677246894)]), lIlIII.Il(IlI[IlIIlI(344617434, 1863376849)]), 1);
      if (var0 == null) {
         var0 = lIllI(lIlIII.Il(IlI[IlIIlI(344617435, -1673559974)]), lIlIII.Il(IlI[IlIIlI(344617436, 176761182)]), 1);
      }

      return var0;
   }

   private static Object lIlII(Method var0, Object... var1) {
      if (var0 == null) {
         return null;
      } else {
         try {
            return var0.invoke((Object)null, var1);
         } catch (ReflectiveOperationException var3) {
            return null;
         }
      }
   }

   public static void lIlIl(llIIllI var0, String var1, class_243 var2, Color var3, double var4, boolean var6) {
      if (IlIII(var0)) {
         class_310 var7 = class_310.method_1551();
         class_327 var8 = var7.field_1772;
         class_4597 var9 = IIIlI(var0);
         if (var8 != null && var9 != null) {
            class_243 var10 = Il(var0);
            class_4184 var11 = var7.field_1773.method_19418();
            var0.lI().method_22903();
            var0.lI().method_22904(var2.field_1352 - var10.field_1352, var2.field_1351 - var10.field_1351, var2.field_1350 - var10.field_1350);
            var0.lI().method_22907(class_7833.field_40716.rotationDegrees(-var11.method_19330()));
            var0.lI().method_22907(class_7833.field_40714.rotationDegrees(var11.method_19329()));
            float var12 = (float)(0.025 * var4);
            var0.lI().method_22905(-var12, -var12, var12);
            Matrix4f var13 = var0.lI().method_23760().method_23761();
            float var14 = (float)(-var8.method_1727(var1)) / 2.0F;
            Objects.requireNonNull(var8);
            float var15 = (float)(-IlIIlI(344617437, -766521916)) / 2.0F;
            int var16 = llIlI(var3, (double)var3.getAlpha());
            if (lIIIllll.IllIl() && (var16 & IlIIlI(344617438, -392441363)) != 0) {
               float var17 = var14;
               int var18 = 0;

               for(int var19 = 0; var19 < var1.length(); ++var18) {
                  int var20 = var1.codePointAt(var19);
                  String var21 = new String(Character.toChars(var20));
                  if (!Character.isWhitespace(var20)) {
                     int var22 = IIIIIIllI.lIIlI(var3.getAlpha(), Math.round(var14), Math.round(var15), var18);
                     var8.method_27521(var21, var17, var15, var22, var6, var13, var9, class_6415.field_33993, 0, IlIIlI(344617439, 318417949));
                  }

                  var17 += (float)var8.method_1727(var21);
                  var19 += Character.charCount(var20);
               }
            } else {
               var8.method_27521(var1, var14, var15, var16, var6, var13, var9, class_6415.field_33993, 0, IlIIlI(344617424, 1247695338));
            }

            var0.lI().method_22909();
         }
      }
   }

   private static Method lIllI(String var0, String var1, int var2) {
      try {
         Class var3 = Class.forName(var0);

         for(Method var7 : var3.getMethods()) {
            if (var7.getName().equals(var1) && var7.getParameterCount() == var2) {
               var7.setAccessible(true);
               return var7;
            }
         }
      } catch (ReflectiveOperationException var8) {
      }

      return null;
   }

   public static <T> void lIlll(Object var0, Iterable<? extends Iterable<T>> var1, Function<T, class_2338> var2, Function<T, Color> var3, ToDoubleFunction<T> var4) {
      if (var0 instanceof llIIllI var5) {
         lllIl(var5, var1, var2, var3, var4);
      }

   }

   private static void llIII(class_4587 var0, class_238 var1, Color var2, double var3) {
      if (var0 != null && var1 != null && var2 != null) {
         class_4184 var5 = class_310.method_1551().field_1773.method_19418();
         class_243 var6 = var5.method_71156();
         float var7 = (float)(var1.field_1323 - var6.field_1352);
         float var8 = (float)(var1.field_1322 - var6.field_1351);
         float var9 = (float)(var1.field_1321 - var6.field_1350);
         float var10 = (float)(var1.field_1320 - var6.field_1352);
         float var11 = (float)(var1.field_1325 - var6.field_1351);
         float var12 = (float)(var1.field_1324 - var6.field_1350);
         float var13 = (float)var2.getRed() / 255.0F;
         float var14 = (float)var2.getGreen() / 255.0F;
         float var15 = (float)var2.getBlue() / 255.0F;
         float var16 = (float)lllI(var3) / 255.0F;
         Matrix4f var17 = var0.method_23760().method_23761();
         IlIll(IIII);
         IlIll(Ill);
         IlIll(IIl);
         lllII();
         lIl(IlII, lIlI);

         try {
            Object var18 = lIlII(IllI);
            class_4588 var19 = (class_4588)IllII(var18, Illl, IIll, lII);
            if (var19 != null) {
               var19.method_22918(var17, var7, var8, var9).method_22915(var13, var14, var15, var16);
               var19.method_22918(var17, var10, var8, var9).method_22915(var13, var14, var15, var16);
               var19.method_22918(var17, var10, var11, var9).method_22915(var13, var14, var15, var16);
               var19.method_22918(var17, var7, var11, var9).method_22915(var13, var14, var15, var16);
               var19.method_22918(var17, var7, var8, var12).method_22915(var13, var14, var15, var16);
               var19.method_22918(var17, var7, var11, var12).method_22915(var13, var14, var15, var16);
               var19.method_22918(var17, var10, var11, var12).method_22915(var13, var14, var15, var16);
               var19.method_22918(var17, var10, var8, var12).method_22915(var13, var14, var15, var16);
               var19.method_22918(var17, var7, var8, var9).method_22915(var13, var14, var15, var16);
               var19.method_22918(var17, var7, var8, var12).method_22915(var13, var14, var15, var16);
               var19.method_22918(var17, var10, var8, var12).method_22915(var13, var14, var15, var16);
               var19.method_22918(var17, var10, var8, var9).method_22915(var13, var14, var15, var16);
               var19.method_22918(var17, var7, var11, var9).method_22915(var13, var14, var15, var16);
               var19.method_22918(var17, var10, var11, var9).method_22915(var13, var14, var15, var16);
               var19.method_22918(var17, var10, var11, var12).method_22915(var13, var14, var15, var16);
               var19.method_22918(var17, var7, var11, var12).method_22915(var13, var14, var15, var16);
               var19.method_22918(var17, var7, var8, var9).method_22915(var13, var14, var15, var16);
               var19.method_22918(var17, var7, var11, var9).method_22915(var13, var14, var15, var16);
               var19.method_22918(var17, var7, var11, var12).method_22915(var13, var14, var15, var16);
               var19.method_22918(var17, var7, var8, var12).method_22915(var13, var14, var15, var16);
               var19.method_22918(var17, var10, var8, var9).method_22915(var13, var14, var15, var16);
               var19.method_22918(var17, var10, var8, var12).method_22915(var13, var14, var15, var16);
               var19.method_22918(var17, var10, var11, var12).method_22915(var13, var14, var15, var16);
               var19.method_22918(var17, var10, var11, var9).method_22915(var13, var14, var15, var16);
               Object var20 = IllII(var19, llI);
               if (var20 != null) {
                  lIl(IIIl, var20);
               }

               return;
            }
         } finally {
            IlllI();
            IlIll(lIll);
            IlIll(ll);
         }

      }
   }

   public static boolean llIIl(class_310 var0, class_1657 var1) {
      if (var0 != null && var0.field_1724 != null && var0.field_1687 != null && var1 != null && var1 != var0.field_1724) {
         if (var1.method_5805() && !var1.method_7325()) {
            if (IlIII.I(var1)) {
               return false;
            } else {
               return !IlIIlIlII.IlI(var1);
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private static int llIlI(Color var0, double var1) {
      int var3 = lllI(var1);
      return (var3 & IlIIlI(344617425, 226260173)) << IlIIlI(344617426, 199020896) | (var0.getRed() & IlIIlI(344617427, -1905683090)) << IlIIlI(344617428, -1722338292) | (var0.getGreen() & IlIIlI(344617429, -938250801)) << IlIIlI(344617430, -164738480) | var0.getBlue() & IlIIlI(344617431, 1613862735);
   }

   public static void llIll(llIIllI var0, class_243 var1, class_243 var2, Color var3, double var4) {
      if (IlIII(var0) && var1 != null && var2 != null && var3 != null) {
         class_243 var6 = Il(var0);
         float var7 = (float)(var1.field_1352 - var6.field_1352);
         float var8 = (float)(var1.field_1351 - var6.field_1351);
         float var9 = (float)(var1.field_1350 - var6.field_1350);
         float var10 = (float)(var2.field_1352 - var6.field_1352);
         float var11 = (float)(var2.field_1351 - var6.field_1351);
         float var12 = (float)(var2.field_1350 - var6.field_1350);
         float var13 = (float)var3.getRed() / 255.0F;
         float var14 = (float)var3.getGreen() / 255.0F;
         float var15 = (float)var3.getBlue() / 255.0F;
         float var16 = (float)lllI(var4) / 255.0F;
         Matrix4f var17 = var0.lI().method_23760().method_23761();
         IlIll(IIII);
         IlIll(Ill);
         IlIll(IIl);
         lllII();
         lIl(IlII, lIlI);
         lIl(Il, III(IIIlll()));

         try {
            Object var18 = lIlII(IllI);
            class_4588 var19 = (class_4588)IllII(var18, Illl, lIIl, lII);
            if (var19 != null) {
               var19.method_22918(var17, var7, var8, var9).method_22915(var13, var14, var15, var16);
               var19.method_22918(var17, var10, var11, var12).method_22915(var13, var14, var15, var16);
               Object var20 = IllII(var19, llI);
               if (var20 != null) {
                  lIl(IIIl, var20);
               }

               return;
            }
         } finally {
            lIl(Il, 1.0F);
            IlllI();
            IlIll(lIll);
            IlIll(ll);
         }

      }
   }

   private static void lllII() {
      lIl(IIlI, false);
      IlIll(I);
   }

   public static <T> void lllIl(llIIllI var0, Iterable<? extends Iterable<T>> var1, Function<T, class_2338> var2, Function<T, Color> var3, ToDoubleFunction<T> var4) {
      if (IlIII(var0)) {
         class_243 var5 = Il(var0);
         Matrix4f var6 = var0.lI().method_23760().method_23761();
         class_4588 var7 = IIIlI(var0).method_73477(class_12249.method_76023());

         for(Iterable var9 : var1) {
            for(Object var11 : var9) {
               class_2338 var12 = (class_2338)var2.apply(var11);
               Color var13 = (Color)var3.apply(var11);
               float var14 = 0.06F;
               float var15 = (float)((double)var12.method_10263() - var5.field_1352) + var14;
               float var16 = (float)((double)var12.method_10264() - var5.field_1351) + 0.02F;
               float var17 = (float)((double)var12.method_10260() - var5.field_1350) + var14;
               float var18 = (float)((double)var12.method_10263() - var5.field_1352 + (double)1.0F) - var14;
               float var19 = (float)((double)var12.method_10260() - var5.field_1350 + (double)1.0F) - var14;
               lII(var7, var6, var15, var16, var17, var18, var19, var13, var4.applyAsDouble(var11));
            }
         }

      }
   }

   public static void llllI(llIIllI var0, class_243 var1, float var2, float var3, float var4, Color var5, double var6, float var8) {
      if (IlIII(var0) && var1 != null && !(var2 <= 0.0F) && !(var3 <= 0.0F)) {
         class_243[] var9 = lIll(var1, var2, var3, var4);
         lIIlI(var8, () -> IIIlIl(var0, var9, var5, var6));
      }
   }

   private static void lllll(class_4588 var0, Matrix4f var1, float var2, float var3, float var4, float var5, float var6, float var7, Color var8, double var9) {
      float var11 = (float)var8.getRed() / 255.0F;
      float var12 = (float)var8.getGreen() / 255.0F;
      float var13 = (float)var8.getBlue() / 255.0F;
      float var14 = (float)lllI(var9) / 255.0F;
      var0.method_22918(var1, var2, var3, var4).method_22915(var11, var12, var13, var14);
      var0.method_22918(var1, var5, var3, var4).method_22915(var11, var12, var13, var14);
      var0.method_22918(var1, var5, var6, var4).method_22915(var11, var12, var13, var14);
      var0.method_22918(var1, var2, var6, var4).method_22915(var11, var12, var13, var14);
      var0.method_22918(var1, var2, var3, var7).method_22915(var11, var12, var13, var14);
      var0.method_22918(var1, var5, var3, var7).method_22915(var11, var12, var13, var14);
      var0.method_22918(var1, var5, var6, var7).method_22915(var11, var12, var13, var14);
      var0.method_22918(var1, var2, var6, var7).method_22915(var11, var12, var13, var14);
      var0.method_22918(var1, var2, var3, var4).method_22915(var11, var12, var13, var14);
      var0.method_22918(var1, var5, var3, var4).method_22915(var11, var12, var13, var14);
      var0.method_22918(var1, var5, var3, var7).method_22915(var11, var12, var13, var14);
      var0.method_22918(var1, var2, var3, var7).method_22915(var11, var12, var13, var14);
      var0.method_22918(var1, var2, var6, var4).method_22915(var11, var12, var13, var14);
      var0.method_22918(var1, var5, var6, var4).method_22915(var11, var12, var13, var14);
      var0.method_22918(var1, var5, var6, var7).method_22915(var11, var12, var13, var14);
      var0.method_22918(var1, var2, var6, var7).method_22915(var11, var12, var13, var14);
      var0.method_22918(var1, var2, var3, var4).method_22915(var11, var12, var13, var14);
      var0.method_22918(var1, var2, var6, var4).method_22915(var11, var12, var13, var14);
      var0.method_22918(var1, var2, var6, var7).method_22915(var11, var12, var13, var14);
      var0.method_22918(var1, var2, var3, var7).method_22915(var11, var12, var13, var14);
      var0.method_22918(var1, var5, var3, var4).method_22915(var11, var12, var13, var14);
      var0.method_22918(var1, var5, var6, var4).method_22915(var11, var12, var13, var14);
      var0.method_22918(var1, var5, var6, var7).method_22915(var11, var12, var13, var14);
      var0.method_22918(var1, var5, var3, var7).method_22915(var11, var12, var13, var14);
   }

   public static <undefinedtype> IIIIII(llIIllI var0, Iterable<class_243> var1) {
      if (IlIII(var0) && var1 != null) {
         double var2 = Double.POSITIVE_INFINITY;
         double var4 = Double.POSITIVE_INFINITY;
         double var6 = Double.NEGATIVE_INFINITY;
         double var8 = Double.NEGATIVE_INFINITY;
         int var10 = 0;

         for(class_243 var12 : var1) {
            <undefinedtype> var13 = llII(var0, var12);
            if (var13 != null) {
               ++var10;
               var2 = Math.min(var2, var13.II());
               var4 = Math.min(var4, var13.l());
               var6 = Math.max(var6, var13.II());
               var8 = Math.max(var8, var13.l());
            }
         }

         return var10 < 2 ? null : new Record(var2, var4, var6, var8) {
            private final double I;
            private final double l;
            private final double II;
            private final double Il;

            public double I() {
               return this.I;
            }

            public double l() {
               return this.II;
            }

            public double II() {
               return this.Il;
            }

            public double Il() {
               return this.I - this.l;
            }

            public double lI() {
               return (this.l + this.I) * (double)0.5F;
            }

            public double ll() {
               return this.l;
            }

            public double III() {
               return this.Il - this.II;
            }

            public double IIl() {
               return (this.II + this.Il) * (double)0.5F;
            }

            public {
               this.II = var1;
               this.l = var3;
               this.Il = var5;
               this.I = var7;
            }
         };
      } else {
         return null;
      }
   }

   private static String IIIIIl(char[] var0, long var1, int var3) {
      int var4 = IlIIlI(344617384, -1281602087) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IlIIlI(344617385, 1947756132);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   public static void IIIIlI(Object var0, class_243 var1, float var2, float var3, float var4, Color var5, double var6, float var8) {
      if (var0 instanceof llIIllI var9) {
         llllI(var9, var1, var2, var3, var4, var5, var6, var8);
      }

   }

   public static void IIIIll(Object var0, class_238 var1, Color var2, double var3, float var5) {
      if (IIIl(var0, var1)) {
         if (var0 instanceof llIIllI) {
            llIIllI var6 = (llIIllI)var0;
            IIIlII(var6.lI(), var6.ll(), var1, var2, var3, var5);
         } else if (var0 instanceof WorldRenderContext) {
            WorldRenderContext var7 = (WorldRenderContext)var0;
            IIIlII(var7.matrices(), var7.consumers(), var1, var2, var3, var5);
         }

      }
   }

   private static void IIIlII(class_4587 var0, class_4597 var1, class_238 var2, Color var3, double var4, float var6) {
      if (var0 != null && var2 != null && var3 != null) {
         class_4184 var7 = class_310.method_1551().field_1773.method_19418();
         class_243 var8 = var7.method_71156();
         float var9 = (float)(var2.field_1323 - var8.field_1352);
         float var10 = (float)(var2.field_1322 - var8.field_1351);
         float var11 = (float)(var2.field_1321 - var8.field_1350);
         float var12 = (float)(var2.field_1320 - var8.field_1352);
         float var13 = (float)(var2.field_1325 - var8.field_1351);
         float var14 = (float)(var2.field_1324 - var8.field_1350);
         float var15 = (float)var3.getRed() / 255.0F;
         float var16 = (float)var3.getGreen() / 255.0F;
         float var17 = (float)var3.getBlue() / 255.0F;
         float var18 = (float)lllI(var4) / 255.0F;
         Matrix4f var19 = var0.method_23760().method_23761();
         if (var1 != null) {
            class_4588 var26 = var1.method_73477(class_12249.method_76015());
            var26.method_22918(var19, var9, var10, var11).method_22915(var15, var16, var17, var18).method_60831(var0.method_23760(), 1.0F, 0.0F, 0.0F).method_75298(III(var6));
            var26.method_22918(var19, var12, var10, var11).method_22915(var15, var16, var17, var18).method_60831(var0.method_23760(), 1.0F, 0.0F, 0.0F).method_75298(III(var6));
            var26.method_22918(var19, var12, var10, var11).method_22915(var15, var16, var17, var18).method_60831(var0.method_23760(), 0.0F, 1.0F, 0.0F).method_75298(III(var6));
            var26.method_22918(var19, var12, var13, var11).method_22915(var15, var16, var17, var18).method_60831(var0.method_23760(), 0.0F, 1.0F, 0.0F).method_75298(III(var6));
            var26.method_22918(var19, var12, var13, var11).method_22915(var15, var16, var17, var18).method_60831(var0.method_23760(), -1.0F, 0.0F, 0.0F).method_75298(III(var6));
            var26.method_22918(var19, var9, var13, var11).method_22915(var15, var16, var17, var18).method_60831(var0.method_23760(), -1.0F, 0.0F, 0.0F).method_75298(III(var6));
            var26.method_22918(var19, var9, var13, var11).method_22915(var15, var16, var17, var18).method_60831(var0.method_23760(), 0.0F, -1.0F, 0.0F).method_75298(III(var6));
            var26.method_22918(var19, var9, var10, var11).method_22915(var15, var16, var17, var18).method_60831(var0.method_23760(), 0.0F, -1.0F, 0.0F).method_75298(III(var6));
            var26.method_22918(var19, var9, var10, var14).method_22915(var15, var16, var17, var18).method_60831(var0.method_23760(), 1.0F, 0.0F, 0.0F).method_75298(III(var6));
            var26.method_22918(var19, var12, var10, var14).method_22915(var15, var16, var17, var18).method_60831(var0.method_23760(), 1.0F, 0.0F, 0.0F).method_75298(III(var6));
            var26.method_22918(var19, var12, var10, var14).method_22915(var15, var16, var17, var18).method_60831(var0.method_23760(), 0.0F, 1.0F, 0.0F).method_75298(III(var6));
            var26.method_22918(var19, var12, var13, var14).method_22915(var15, var16, var17, var18).method_60831(var0.method_23760(), 0.0F, 1.0F, 0.0F).method_75298(III(var6));
            var26.method_22918(var19, var12, var13, var14).method_22915(var15, var16, var17, var18).method_60831(var0.method_23760(), -1.0F, 0.0F, 0.0F).method_75298(III(var6));
            var26.method_22918(var19, var9, var13, var14).method_22915(var15, var16, var17, var18).method_60831(var0.method_23760(), -1.0F, 0.0F, 0.0F).method_75298(III(var6));
            var26.method_22918(var19, var9, var13, var14).method_22915(var15, var16, var17, var18).method_60831(var0.method_23760(), 0.0F, -1.0F, 0.0F).method_75298(III(var6));
            var26.method_22918(var19, var9, var10, var14).method_22915(var15, var16, var17, var18).method_60831(var0.method_23760(), 0.0F, -1.0F, 0.0F).method_75298(III(var6));
            var26.method_22918(var19, var9, var10, var11).method_22915(var15, var16, var17, var18).method_60831(var0.method_23760(), 0.0F, 0.0F, 1.0F).method_75298(III(var6));
            var26.method_22918(var19, var9, var10, var14).method_22915(var15, var16, var17, var18).method_60831(var0.method_23760(), 0.0F, 0.0F, 1.0F).method_75298(III(var6));
            var26.method_22918(var19, var12, var10, var11).method_22915(var15, var16, var17, var18).method_60831(var0.method_23760(), 0.0F, 0.0F, 1.0F).method_75298(III(var6));
            var26.method_22918(var19, var12, var10, var14).method_22915(var15, var16, var17, var18).method_60831(var0.method_23760(), 0.0F, 0.0F, 1.0F).method_75298(III(var6));
            var26.method_22918(var19, var12, var13, var11).method_22915(var15, var16, var17, var18).method_60831(var0.method_23760(), 0.0F, 0.0F, 1.0F).method_75298(III(var6));
            var26.method_22918(var19, var12, var13, var14).method_22915(var15, var16, var17, var18).method_60831(var0.method_23760(), 0.0F, 0.0F, 1.0F).method_75298(III(var6));
            var26.method_22918(var19, var9, var13, var11).method_22915(var15, var16, var17, var18).method_60831(var0.method_23760(), 0.0F, 0.0F, 1.0F).method_75298(III(var6));
            var26.method_22918(var19, var9, var13, var14).method_22915(var15, var16, var17, var18).method_60831(var0.method_23760(), 0.0F, 0.0F, 1.0F).method_75298(III(var6));
         } else {
            IlIll(IIII);
            IlIll(Ill);
            IlIll(IIl);
            lllII();
            lIl(IlII, lIlI);
            lIl(Il, III(var6));

            try {
               Object var20 = lIlII(IllI);
               class_4588 var21 = (class_4588)IllII(var20, Illl, lIIl, lII);
               if (var21 != null) {
                  var21.method_22918(var19, var9, var10, var11).method_22915(var15, var16, var17, var18);
                  var21.method_22918(var19, var12, var10, var11).method_22915(var15, var16, var17, var18);
                  var21.method_22918(var19, var12, var10, var11).method_22915(var15, var16, var17, var18);
                  var21.method_22918(var19, var12, var13, var11).method_22915(var15, var16, var17, var18);
                  var21.method_22918(var19, var12, var13, var11).method_22915(var15, var16, var17, var18);
                  var21.method_22918(var19, var9, var13, var11).method_22915(var15, var16, var17, var18);
                  var21.method_22918(var19, var9, var13, var11).method_22915(var15, var16, var17, var18);
                  var21.method_22918(var19, var9, var10, var11).method_22915(var15, var16, var17, var18);
                  var21.method_22918(var19, var9, var10, var14).method_22915(var15, var16, var17, var18);
                  var21.method_22918(var19, var12, var10, var14).method_22915(var15, var16, var17, var18);
                  var21.method_22918(var19, var12, var10, var14).method_22915(var15, var16, var17, var18);
                  var21.method_22918(var19, var12, var13, var14).method_22915(var15, var16, var17, var18);
                  var21.method_22918(var19, var12, var13, var14).method_22915(var15, var16, var17, var18);
                  var21.method_22918(var19, var9, var13, var14).method_22915(var15, var16, var17, var18);
                  var21.method_22918(var19, var9, var13, var14).method_22915(var15, var16, var17, var18);
                  var21.method_22918(var19, var9, var10, var14).method_22915(var15, var16, var17, var18);
                  var21.method_22918(var19, var9, var10, var11).method_22915(var15, var16, var17, var18);
                  var21.method_22918(var19, var9, var10, var14).method_22915(var15, var16, var17, var18);
                  var21.method_22918(var19, var12, var10, var11).method_22915(var15, var16, var17, var18);
                  var21.method_22918(var19, var12, var10, var14).method_22915(var15, var16, var17, var18);
                  var21.method_22918(var19, var12, var13, var11).method_22915(var15, var16, var17, var18);
                  var21.method_22918(var19, var12, var13, var14).method_22915(var15, var16, var17, var18);
                  var21.method_22918(var19, var9, var13, var11).method_22915(var15, var16, var17, var18);
                  var21.method_22918(var19, var9, var13, var14).method_22915(var15, var16, var17, var18);
                  Object var22 = IllII(var21, llI);
                  if (var22 != null) {
                     lIl(IIIl, var22);
                  }

                  return;
               }
            } finally {
               lIl(Il, 1.0F);
               IlllI();
               IlIll(lIll);
               IlIll(ll);
            }

         }
      }
   }

   private static void IIIlIl(llIIllI var0, class_243[] var1, Color var2, double var3) {
      int[][] var10000 = new int[IlIIlI(344617386, 317739735)][];
      var10000[0] = new int[]{0, 1};
      var10000[1] = new int[]{1, 2};
      var10000[2] = new int[]{2, 3};
      var10000[3] = new int[]{3, 0};
      var10000[4] = new int[]{4, 5};
      var10000[5] = new int[]{5, IlIIlI(344617387, -571339922)};
      var10000[IlIIlI(344617388, 1494417125)] = new int[]{IlIIlI(344617389, -247102582), IlIIlI(344617390, -820073946)};
      var10000[IlIIlI(344617391, -604006060)] = new int[]{IlIIlI(344617376, -2079867983), 4};
      var10000[IlIIlI(344617377, 1825458260)] = new int[]{0, 4};
      var10000[IlIIlI(344617378, -61562551)] = new int[]{1, 5};
      var10000[IlIIlI(344617379, 77455612)] = new int[]{2, IlIIlI(344617380, 356596487)};
      var10000[IlIIlI(344617381, 1122506516)] = new int[]{3, IlIIlI(344617382, -1851623678)};
      int[][] var5 = var10000;

      for(int[] var9 : var5) {
         llIll(var0, var1[var9[0]], var1[var9[1]], var2, var3);
      }

   }

   private static void IIIllI(llIIllI var0, class_238 var1, Color var2, double var3, float var5) {
      lIIlI(var5, () -> {
         class_243 var5 = new class_243(var1.field_1323, var1.field_1322, var1.field_1321);
         class_243 var6 = new class_243(var1.field_1320, var1.field_1322, var1.field_1321);
         class_243 var7 = new class_243(var1.field_1320, var1.field_1325, var1.field_1321);
         class_243 var8 = new class_243(var1.field_1323, var1.field_1325, var1.field_1321);
         class_243 var9 = new class_243(var1.field_1323, var1.field_1322, var1.field_1324);
         class_243 var10 = new class_243(var1.field_1320, var1.field_1322, var1.field_1324);
         class_243 var11 = new class_243(var1.field_1320, var1.field_1325, var1.field_1324);
         class_243 var12 = new class_243(var1.field_1323, var1.field_1325, var1.field_1324);
         llIll(var0, var5, var6, var2, var3);
         llIll(var0, var6, var7, var2, var3);
         llIll(var0, var7, var8, var2, var3);
         llIll(var0, var8, var5, var2, var3);
         llIll(var0, var9, var10, var2, var3);
         llIll(var0, var10, var11, var2, var3);
         llIll(var0, var11, var12, var2, var3);
         llIll(var0, var12, var9, var2, var3);
         llIll(var0, var5, var9, var2, var3);
         llIll(var0, var6, var10, var2, var3);
         llIll(var0, var7, var11, var2, var3);
         llIll(var0, var8, var12, var2, var3);
      });
      Illl(var0);
   }

   private static float IIIlll() {
      return III(IlIl);
   }

   public static void IIlIII(Object var0, class_238 var1, Color var2, double var3) {
      if (IIIl(var0, var1)) {
         if (var0 instanceof llIIllI) {
            llIIllI var5 = (llIIllI)var0;
            IlIIl(var5.lI(), var5.ll(), var1, var2, var3);
         } else if (var0 instanceof WorldRenderContext) {
            WorldRenderContext var6 = (WorldRenderContext)var0;
            IlIIl(var6.matrices(), var6.consumers(), var1, var2, var3);
         }

      }
   }

   public static void IIlIIl(llIIllI var0, class_2960 var1, class_243 var2, double var3, double var5, Color var7) {
      if (IlIII(var0) && var1 != null && !(var3 <= (double)0.0F) && !(var5 <= (double)0.0F)) {
         class_310 var8 = class_310.method_1551();
         class_4597 var9 = IIIlI(var0);
         if (var9 != null) {
            class_243 var10 = Il(var0);
            class_4184 var11 = var8.field_1773.method_19418();
            class_4588 var12 = var9.method_73477(class_12249.method_75990(var1));
            float var13 = (float)(var3 / (double)2.0F);
            float var14 = (float)(var5 / (double)2.0F);
            Color var15 = var7 == null ? Color.WHITE : var7;
            int var16 = var15.getAlpha();
            var0.lI().method_22903();
            var0.lI().method_22904(var2.field_1352 - var10.field_1352, var2.field_1351 - var10.field_1351, var2.field_1350 - var10.field_1350);
            var0.lI().method_22907(class_7833.field_40716.rotationDegrees(-var11.method_19330()));
            var0.lI().method_22907(class_7833.field_40714.rotationDegrees(var11.method_19329()));
            Matrix4f var17 = var0.lI().method_23760().method_23761();
            var12.method_22918(var17, -var13, -var14, 0.0F).method_1336(var15.getRed(), var15.getGreen(), var15.getBlue(), var16).method_22913(0.0F, 1.0F).method_22922(class_4608.field_21444).method_60803(IlIIlI(344617383, 1738551041)).method_22914(0.0F, 0.0F, 1.0F);
            var12.method_22918(var17, var13, -var14, 0.0F).method_1336(var15.getRed(), var15.getGreen(), var15.getBlue(), var16).method_22913(1.0F, 1.0F).method_22922(class_4608.field_21444).method_60803(IlIIlI(344617400, -1539430900)).method_22914(0.0F, 0.0F, 1.0F);
            var12.method_22918(var17, var13, var14, 0.0F).method_1336(var15.getRed(), var15.getGreen(), var15.getBlue(), var16).method_22913(1.0F, 0.0F).method_22922(class_4608.field_21444).method_60803(IlIIlI(344617401, 2032810015)).method_22914(0.0F, 0.0F, 1.0F);
            var12.method_22918(var17, -var13, var14, 0.0F).method_1336(var15.getRed(), var15.getGreen(), var15.getBlue(), var16).method_22913(0.0F, 0.0F).method_22922(class_4608.field_21444).method_60803(IlIIlI(344617402, -1924734585)).method_22914(0.0F, 0.0F, 1.0F);
            var0.lI().method_22909();
         }
      }
   }

   public static boolean IIlIlI(class_310 var0, llIIllI var1, class_1297 var2, class_243 var3) {
      if (var0 != null && var2 != null && var3 != null) {
         class_243 var4 = Il(var1);
         if (var1 != null && var1.l() != null) {
            return var0.method_1561().method_3950(var2, var1.l(), var3.field_1352 - var4.field_1352, var3.field_1351 - var4.field_1351, var3.field_1350 - var4.field_1350);
         } else {
            return var3.method_1022(var4) <= (double)16384.0F;
         }
      } else {
         return false;
      }
   }

   private static Method IIlIll(String var0, String var1, int var2) {
      try {
         Class var3 = Class.forName(var0);

         for(Method var7 : var3.getMethods()) {
            if (var7.getName().equals(var1) && var7.getParameterCount() == var2 && !Modifier.isStatic(var7.getModifiers())) {
               return var7;
            }
         }
      } catch (ReflectiveOperationException var8) {
      }

      return null;
   }

   public static void IIllII(llIIllI var0, Matrix4f var1, float var2, float var3, float var4, float var5, int var6) {
      int var7 = var6 >>> IlIIlI(344617403, 1173495083) & IlIIlI(344617404, 1017675693);
      if (IlIII(var0) && var1 != null && var7 > 0 && !(var4 <= var2) && !(var5 <= var3)) {
         float var8 = (float)(var6 >> IlIIlI(344617405, -552786722) & IlIIlI(344617406, -1115279399)) / 255.0F;
         float var9 = (float)(var6 >> IlIIlI(344617407, -581883864) & IlIIlI(344617392, -2023361612)) / 255.0F;
         float var10 = (float)(var6 & IlIIlI(344617393, 1037783308)) / 255.0F;
         float var11 = (float)var7 / 255.0F;
         class_4588 var12 = IIIlI(var0).method_73477(class_12249.method_76023());
         var12.method_22918(var1, var2, var3, 0.0F).method_22915(var8, var9, var10, var11);
         var12.method_22918(var1, var2, var5, 0.0F).method_22915(var8, var9, var10, var11);
         var12.method_22918(var1, var4, var5, 0.0F).method_22915(var8, var9, var10, var11);
         var12.method_22918(var1, var4, var3, 0.0F).method_22915(var8, var9, var10, var11);
      }
   }

   public static void IIllIl(llIIllI var0, Matrix4f var1, float var2, float var3, float var4, float var5, float var6, int var7, int var8) {
      int var9 = var7 >>> IlIIlI(344617394, -1822936028) & IlIIlI(344617395, 761429117);
      int var10 = var8 >>> IlIIlI(344617396, -1323482184) & IlIIlI(344617397, 1316358738);
      if (IlIII(var0) && var1 != null && (var9 > 0 || var10 > 0) && !(var4 <= 0.0F) && !(var5 <= 0.0F)) {
         float var11 = IIl(var4, var5, var6);
         if (var11 <= 0.01F) {
            IIlII(var0, var1, var2, var3, var2 + var4, var3 + var5, var7, var8);
         } else {
            float var12 = (float)(var7 >> IlIIlI(344617398, -1192705509) & IlIIlI(344617399, -24152026)) / 255.0F;
            float var13 = (float)(var7 >> IlIIlI(344617352, -1473185146) & IlIIlI(344617353, 2080497943)) / 255.0F;
            float var14 = (float)(var7 & IlIIlI(344617354, -2141988958)) / 255.0F;
            float var15 = (float)var9 / 255.0F;
            float var16 = (float)(var8 >> IlIIlI(344617355, 1310999532) & IlIIlI(344617356, 104188319)) / 255.0F;
            float var17 = (float)(var8 >> IlIIlI(344617357, -706377200) & IlIIlI(344617358, 892507595)) / 255.0F;
            float var18 = (float)(var8 & IlIIlI(344617359, 1975752448)) / 255.0F;
            float var19 = (float)var10 / 255.0F;
            class_4588 var20 = IIIlI(var0).method_73477(class_12249.method_76023());
            IIlll(var20, var1, var2, var3, var4, var5, var11, var12, var13, var14, var15, var16, var17, var18, var19);
         }
      }
   }

   public static void IIlllI(llIIllI var0) {
      Illl(var0);
   }

   public static class_243 IIllll() {
      class_4184 var0 = class_310.method_1551().field_1773.method_19418();
      float var1 = (float)Math.PI;
      float var2 = (float)Math.toRadians((double)(-var0.method_19330()));
      float var3 = (float)Math.toRadians((double)(-var0.method_19329()));
      float var4 = class_3532.method_15374((double)(var2 - var1));
      float var5 = class_3532.method_15362((double)(var2 - var1));
      float var6 = -class_3532.method_15374((double)var3);
      float var7 = class_3532.method_15362((double)var3);
      return (new class_243((double)(var5 * var6), (double)var7, (double)(var4 * var6))).method_1019(var0.method_71156());
   }

   public static void IlIIII(llIIllI var0, Matrix4f var1, float var2, float var3, float var4, float var5, float var6, int var7) {
      int var8 = var7 >>> IlIIlI(344617344, -903739024) & IlIIlI(344617345, -1837341612);
      if (IlIII(var0) && var1 != null && var8 > 0 && !(var4 <= 0.0F) && !(var5 <= 0.0F)) {
         float var9 = IIl(var4, var5, var6);
         if (var9 <= 0.01F) {
            IIllII(var0, var1, var2, var3, var2 + var4, var3 + var5, var7);
         } else {
            float var10 = (float)(var7 >> IlIIlI(344617346, 1328229603) & IlIIlI(344617347, 330958379)) / 255.0F;
            float var11 = (float)(var7 >> IlIIlI(344617348, -2058337975) & IlIIlI(344617349, 1314201582)) / 255.0F;
            float var12 = (float)(var7 & IlIIlI(344617350, -1982930243)) / 255.0F;
            float var13 = (float)var8 / 255.0F;
            class_4588 var14 = IIIlI(var0).method_73477(class_12249.method_76023());
            IIlll(var14, var1, var2, var3, var4, var5, var9, var10, var11, var12, var13, var10, var11, var12, var13);
         }
      }
   }

   private static void IlIIIl() {
      IlI[0] = IIIIIl(IlIIll('壠', (short)'賎', 917991495).toCharArray(), 29858L, IlIIlI(344617351, 1865794315));
      IlI[1] = IIIIIl(IlIIll('壡', (short)'輙', -686850063).toCharArray(), 33803L, IlIIlI(344617368, 1247654827));
      IlI[2] = IIIIIl(IlIIll('壢', (short)'葖', 1297689762).toCharArray(), 91313L, IlIIlI(344617369, 54809319));
      IlI[3] = IIIIIl(IlIIll('壣', (short)10677, 1526555614).toCharArray(), 72211L, IlIIlI(344617370, 1174863205));
      IlI[4] = IIIIIl(IlIIll('壤', (short)'즇', -755273967).toCharArray(), 33798L, IlIIlI(344617371, 1117256549));
      IlI[5] = IIIIIl(IlIIll('壥', (short)25712, -396155886).toCharArray(), 92728L, IlIIlI(344617372, -955945968));
      IlI[IlIIlI(344617373, 762154276)] = IIIIIl(IlIIll('壦', (short)'퇾', -808770221).toCharArray(), 70923L, IlIIlI(344617374, -445521088));
      IlI[IlIIlI(344617375, -506952182)] = IIIIIl(IlIIll('壧', (short)1386, -1841797770).toCharArray(), 20925L, IlIIlI(344617360, 212213443));
      IlI[IlIIlI(344617361, -439027168)] = IIIIIl(IlIIll('壨', (short)28861, 792752017).toCharArray(), 26643L, IlIIlI(344617362, -845324249));
      IlI[IlIIlI(344617363, -29050358)] = IIIIIl(IlIIll('壩', (short)'龉', -183497906).toCharArray(), 26608L, IlIIlI(344617364, -1792029549));
      IlI[IlIIlI(344617365, -1730838959)] = IIIIIl(IlIIll('壪', (short)25249, -1212979595).toCharArray(), 97487L, IlIIlI(344617366, -1028093400));
      IlI[IlIIlI(344617367, -709065989)] = IIIIIl(IlIIll('士', (short)31151, -789508846).toCharArray(), 86690L, IlIIlI(344617320, -2027287635));
      IlI[IlIIlI(344617321, 643961797)] = IIIIIl(IlIIll('壬', (short)7155, -134403408).toCharArray(), 5316L, IlIIlI(344617322, 215930580));
      IlI[IlIIlI(344617323, 1497803070)] = IIIIIl(IlIIll('壭', (short)11013, -1583676113).toCharArray(), 94107L, IlIIlI(344617324, -1935431011));
      IlI[IlIIlI(344617325, 1058116851)] = IIIIIl(IlIIll('壮', (short)'\uf0f4', 1064590708).toCharArray(), 50774L, IlIIlI(344617326, 960019023));
      IlI[IlIIlI(344617327, -29811211)] = IIIIIl(IlIIll('壯', (short)17757, 1618756609).toCharArray(), 22215L, IlIIlI(344617312, 1646239160));
      IlI[IlIIlI(344617313, -1840383107)] = IIIIIl(IlIIll('声', (short)'鋆', -921492996).toCharArray(), 12603L, IlIIlI(344617314, 952020246));
      IlI[IlIIlI(344617315, -441390434)] = IIIIIl(IlIIll('壱', (short)16566, -259504742).toCharArray(), 55709L, IlIIlI(344617316, -487773559));
      IlI[IlIIlI(344617317, -1022326849)] = IIIIIl(IlIIll('売', (short)'靧', 2048665725).toCharArray(), 7292L, IlIIlI(344617318, -446228869));
      IlI[IlIIlI(344617319, 49966730)] = IIIIIl(IlIIll('壳', (short)28856, -1267641907).toCharArray(), 11544L, IlIIlI(344617336, -1504699870));
      IlI[IlIIlI(344617337, -399916100)] = IIIIIl(IlIIll('壴', (short)'\ueb6a', -1476962130).toCharArray(), 42791L, IlIIlI(344617338, -1110742844));
      IlI[IlIIlI(344617339, 2830082)] = IIIIIl(IlIIll('壵', (short)'笠', 1038641474).toCharArray(), 94233L, IlIIlI(344617340, -311411071));
      IlI[IlIIlI(344617341, 1553958682)] = IIIIIl(IlIIll('壶', (short)'뗡', 1811033666).toCharArray(), 4206L, IlIIlI(344617342, 1630483452));
      IlI[IlIIlI(344617343, -2077428768)] = IIIIIl(IlIIll('壷', (short)11223, 1998527860).toCharArray(), 16158L, IlIIlI(344617328, 32758563));
      IlI[IlIIlI(344617329, 1101838800)] = IIIIIl(IlIIll('壸', (short)14576, 1988836992).toCharArray(), 5150L, IlIIlI(344617330, 1181754272));
      IlI[IlIIlI(344617331, -637031716)] = IIIIIl(IlIIll('壹', (short)'變', 398352955).toCharArray(), 54565L, IlIIlI(344617332, -2092681445));
      IlI[IlIIlI(344617333, 1239696839)] = IIIIIl(IlIIll('壺', (short)'\uf8ee', 1520707465).toCharArray(), 81574L, IlIIlI(344617334, 1716585963));
      IlI[IlIIlI(344617335, -191131475)] = IIIIIl(IlIIll('壻', (short)3839, 793472115).toCharArray(), 50188L, IlIIlI(344617288, 2103412893));
      IlI[IlIIlI(344617289, 1679181530)] = IIIIIl(IlIIll('壼', (short)'\uf458', 1910395460).toCharArray(), 31222L, IlIIlI(344617290, -2106965849));
      IlI[IlIIlI(344617291, 376025909)] = IIIIIl(IlIIll('壽', (short)27763, -922326514).toCharArray(), 29307L, IlIIlI(344617292, -106525931));
      IlI[IlIIlI(344617293, -881209888)] = IIIIIl(IlIIll('壾', (short)'魟', -725466604).toCharArray(), 69384L, IlIIlI(344617294, 718128441));
      IlI[IlIIlI(344617295, 2089048573)] = IIIIIl(IlIIll('壿', (short)'鸈', 1474588513).toCharArray(), 44973L, IlIIlI(344617280, 875674205));
      IlI[IlIIlI(344617281, -458738234)] = IIIIIl(IlIIll('壀', (short)'ꮒ', -1535815912).toCharArray(), 79675L, IlIIlI(344617282, 1104750617));
      IlI[IlIIlI(344617283, 1858106870)] = IIIIIl(IlIIll('壁', (short)'ꯗ', -1247405730).toCharArray(), 98134L, IlIIlI(344617284, -7719642));
   }

   private static int IlIIlI(int var0, int var1) {
      return llIl[var0 ^ 344617448] ^ var1 ^ var0;
   }

   private static String IlIIll(char var0, short var1, int var2) {
      int var3 = var0 ^ 22752;
      char[] var4 = lllI[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])llll[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         llll[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 3765;
      int var9 = 0;

      do {
         int var10 = var4[var9] - 'ﾖ';
         var10 ^= 34869;
         var10 -= 18491;
         var10 += 17486;
         var10 ^= 33430;
         var10 -= 47050;
         var10 -= 55101;
         var10 += 17204;
         var10 -= 52676;
         var4[var9] = (char)(var10 ^ var8 ^ var1 ^ var2 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
