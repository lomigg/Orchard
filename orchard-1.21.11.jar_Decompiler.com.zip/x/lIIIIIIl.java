package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

@Environment(EnvType.CLIENT)
public final class lIIIIIIl extends IIIIIIIlI implements llIlIIII {
   private final IIIllIIII I;
   private static final double l = (double)18.0F;
   private final IIIllIIII II;
   private static final int Il = 9;
   private static final double lI = (double)5.0F;
   private static final int ll = 3;
   private final lIIIIl III;
   private static final double IIl = (double)0.0F;
   private static final <undefinedtype> IlI;
   private static final double Ill = (double)64.0F;
   private final IIIllIIII lII;
   private static final double lIl = (double)172.0F;
   private static String[] llI;
   private static final int[] lll;
   private static final String[] IIII;
   private static final Object[] IIIl;

   public void IIIlI(class_332 var1, int var2, int var3, float var4) {
      this.lII(var1, false);
   }

   private void ll(class_332 var1, class_310 var2, class_1661 var3) {
      class_327 var4 = var2.field_1772;
      double var5 = (double)5.0F;
      double var7 = (double)5.0F;

      for(int var9 = 0; var9 < 3; ++var9) {
         for(int var10 = 0; var10 < IlII(10576929, 1109761685); ++var10) {
            int var11 = this.IlI(var9, var10);
            double var12 = var5 + (double)var10 * (double)18.0F + (double)1.0F;
            double var14 = var7 + (double)var9 * (double)18.0F + (double)1.0F;
            lllIIlI.lIl(var1, var12, var14, (double)16.0F, (double)16.0F, (double)3.5F);
            class_1799 var16 = var3.method_5438(var11);
            if (!var16.method_7960()) {
               IIIIIIllI.IllIIl(var1, var4, var16, (int)Math.round(var12 + (double)0.0F), (int)Math.round(var14 + (double)0.0F));
            }
         }
      }

   }

   public double llll() {
      return (double)172.0F * this.IIII();
   }

   public boolean IIlI(double var1, double var3) {
      return var1 >= this.Il() && var1 <= this.Il() + this.llll() && var3 >= this.Ill() && var3 <= this.Ill() + this.lIIl();
   }

   private int IlI(int var1, int var2) {
      return IlII(10576928, -2109334579) + var1 * IlII(10576931, 2143506335) + var2;
   }

   private void lII(class_332 var1, boolean var2) {
      class_310 var3 = class_310.method_1551();
      if (var1 != null && var3 != null && var3.field_1724 != null && var3.field_1772 != null) {
         double var4 = this.IIII();
         IIIIIIllI.IIIllI(var1);
         IIIIIIllI.IlII(var1, this.Il(), this.Ill());
         IIIIIIllI.lllI(var1, var4, var4);

         try {
            this.llI(var1, var2);
            this.ll(var1, var3, var3.field_1724.method_31548());
         } finally {
            IIIIIIllI.lIIlIl(var1);
         }

      }
   }

   private void llI(class_332 var1, boolean var2) {
      if ((Boolean)this.III.III() || var2) {
         lllIIlI.lI(var1, IlI, (double)0.0F, (double)0.0F, (double)172.0F, (double)64.0F, var2);
      }

   }

   public void III(class_332 var1, int var2, int var3, float var4, boolean var5) {
      this.lII(var1, var5);
   }

   public double Ill() {
      return (Double)this.II.III();
   }

   private static String lll(char[] var0, long var1, int var3) {
      int var4 = IlII(10576930, 116680557) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IlII(10576933, 191345313);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   public double Il() {
      return (Double)this.I.III();
   }

   private double IIII() {
      return (Double)this.lII.III() / (double)100.0F;
   }

   public void lIlI(double var1, double var3) {
      class_310 var5 = class_310.method_1551();
      double var6 = Double.MAX_VALUE;
      double var8 = Double.MAX_VALUE;
      if (var5 != null && var5.method_22683() != null) {
         var6 = Math.max((double)0.0F, (double)var5.method_22683().method_4486() - this.llll());
         var8 = Math.max((double)0.0F, (double)var5.method_22683().method_4502() - this.lIIl());
      }

      this.I.III(Math.max((double)0.0F, Math.min(var1, var6)));
      this.II.III(Math.max((double)0.0F, Math.min(var3, var8)));
   }

   private static void IIll() {
      llI[0] = lll(IlIl(-866628651, -1046080615).toCharArray(), 52930L, IlII(10576932, 796671776));
      llI[1] = lll(IlIl(-866628652, -1955964285).toCharArray(), 59911L, IlII(10576935, 1293756370));
      llI[2] = lll(IlIl(-866628649, -1379134745).toCharArray(), 40403L, IlII(10576934, -1128457643));
      llI[3] = lll(IlIl(-866628650, -288807307).toCharArray(), 70482L, IlII(10576937, 982500166));
      llI[4] = lll(IlIl(-866628655, 1379211833).toCharArray(), 48555L, IlII(10576936, -495818117));
      llI[5] = lll(IlIl(-866628656, 200813621).toCharArray(), 26102L, IlII(10576939, -414468999));
      llI[IlII(10576938, 417594765)] = lll(IlIl(-866628653, 703728331).toCharArray(), 39139L, IlII(10576941, 330062823));
      llI[IlII(10576940, 2128718875)] = lll(IlIl(-866628654, -1113192427).toCharArray(), 39658L, IlII(10576943, -2088666960));
   }

   public double lIIl() {
      return (double)64.0F * this.IIII();
   }

   public void IIl(class_332 var1, int var2, int var3, float var4) {
      this.lII(var1, false);
   }

   static {
      short var6 = 27127;
      String var7 = "\ud8e9眄걨\uedef콰⌲굣ᣥዽ巆䆧\udb60\udae5朗茏쁉ﴰ郇㢀Ꝋ\uf06cﰫ\ue482\ude0f勍쥛\u05cd\udf70婳\uf49fഝ쮜腧覒埧㩃\ue27d髡\ue0ff֡낎\u0cb4襲歹㆔咬係㡷\uebc1\udcb9\uf00d\uaaca䏶斉闬滅\uf14c㸻疖廃ㆰ諶䓓⼕ꄙ톽鎯퀫ꚅ罝俭뼐\ue8ed곷⊫떿㣯쯭孀梓\u0ff9뺦꽿⛀\ueba0\ueeaa⇧냠츯泙\udf8e䊣搑뮤竘\uf5c8芏ꀲ퇹Ⴐ";
      char[] var8 = "\b\u00040\f\u0004\u0010\u0004\u0004".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            IIII = var9;
            IIIl = new Object[var9.length];
            int var2 = 201516845;
            byte[] var0 = "N\u0086\u001d\u0090\u008eå\u0098És`Ì\u0098&ðI+\u0007Ä1V\b·\u0014t\u0005{züN0\u0088\u0090öØFôPú<\u0019B \u0002e\u0014@~\u008cØBV\u00adrB/\u001dc®Ìüp31\u008e'7<[óh\u008d0".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lll = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lll[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            llI = new String[IlII(10576942, 2089857669)];
            IIll();
            IlI = null.III;
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 24;
                     break;
                  case 1:
                     var10000 = 107;
                     break;
                  case 2:
                     var10000 = 34;
                     break;
                  case 3:
                     var10000 = 43;
                     break;
                  case 4:
                     var10000 = 79;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public lIIIIIIl() {
      super((Object)lIlIII.l(llI[3]), lIllII.IIl, (Object)lIlIII.l(llI[2]));
      this.I = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(llI[4]), (double)18.0F, (double)0.0F, (double)4000.0F, (double)1.0F)).IIl(lIlIII.Il(llI[1])));
      this.II = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(llI[IlII(10576945, 731168577)]), (double)240.0F, (double)0.0F, (double)4000.0F, (double)1.0F)).IIl(lIlIII.Il(llI[1])));
      this.lII = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(llI[0]), (double)100.0F, (double)60.0F, (double)200.0F, (double)5.0F)).IIl(lIlIII.Il(llI[IlII(10576944, -3469782)])));
      this.III = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(llI[5]), true));
   }

   private static int IlII(int var0, int var1) {
      return lll[var0 ^ 10576929] ^ var1 ^ var0;
   }

   private static String IlIl(int var0, int var1) {
      int var3 = var0 ^ -866628651;
      char[] var4 = IIII[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IIIl[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IIIl[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -1573525211;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 29;
               break;
            case 1:
               var9 = 36;
               break;
            case 2:
               var9 = 173;
               break;
            case 3:
               var9 = 240;
               break;
            case 4:
               var9 = 49;
               break;
            case 5:
               var9 = 206;
               break;
            case 6:
               var9 = 80;
               break;
            case 7:
               var9 = 228;
               break;
            case 8:
               var9 = 5;
               break;
            case 9:
               var9 = 22;
               break;
            case 10:
               var9 = 247;
               break;
            case 11:
               var9 = 177;
               break;
            case 12:
               var9 = 186;
               break;
            case 13:
               var9 = 241;
               break;
            case 14:
               var9 = 109;
               break;
            case 15:
               var9 = 54;
               break;
            case 16:
               var9 = 169;
               break;
            case 17:
               var9 = 153;
               break;
            case 18:
               var9 = 194;
               break;
            case 19:
               var9 = 40;
               break;
            case 20:
               var9 = 179;
               break;
            case 21:
               var9 = 127;
               break;
            case 22:
               var9 = 150;
               break;
            case 23:
               var9 = 117;
               break;
            case 24:
               var9 = 118;
               break;
            case 25:
               var9 = 125;
               break;
            case 26:
               var9 = 43;
               break;
            case 27:
               var9 = 143;
               break;
            case 28:
               var9 = 195;
               break;
            case 29:
               var9 = 28;
               break;
            case 30:
               var9 = 135;
               break;
            case 31:
               var9 = 73;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
