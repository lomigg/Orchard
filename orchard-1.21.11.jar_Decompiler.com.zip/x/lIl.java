package x;

import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_7923;
import net.minecraft.class_9362;
import net.minecraft.class_239.class_240;

@Environment(EnvType.CLIENT)
public final class lIl extends IIIIIIIlI {
   private final lIIIIl I;
   private long l;
   private int II;
   private static String[] Il;
   private long lI;
   private final lIIIIl ll;
   private final llllIlIl III;
   private int IIl;
   private long IlI;
   private long Ill;
   private <undefinedtype> lII;
   private final lIIIIl lIl;
   private final lIIIIl llI;
   private static final int[] lll;
   private static final String[] IIII;
   private static final Object[] IIIl;

   public static float ll(class_310 var0, class_2680 var1, int var2) {
      if (var0.field_1724 == null) {
         return 0.0F;
      } else {
         class_1799 var3 = var0.field_1724.method_31548().method_5438(var2);
         return var3.method_7924(var1);
      }
   }

   public void III(class_1297 var1) {
      class_310 var2 = class_310.method_1551();
      if (!IllllIlI.II() && (Boolean)this.ll.III() && var2.field_1724 != null && var1 instanceof class_1657) {
         int var3 = this.lIIl(var2.field_1724);
         if (var3 >= 0) {
            if (this.IIl == -1) {
               this.IIl = IIlllllI.IIIl(var2.field_1724.method_31548());
            }

            this.II = var3;
            this.l = System.currentTimeMillis();
            this.lI = this.IIIll();
         }
      }
   }

   private void IlI(class_310 var1) {
      if (this.II >= 0) {
         this.IIII(var1, this.II);
      }

   }

   private void lII(class_310 var1) {
      IllllIlI.IlII(var1, this, null.II);
      this.lII = null;
      this.II = -1;
   }

   private boolean llI(class_310 var1) {
      return (Boolean)this.I.III() && var1.field_1761 != null && !IIIIl(var1) && (IIlllllI.IIlII(var1.field_1761) || this.IlII(var1));
   }

   private float lll(class_1799 var1) {
      if (var1.method_7960()) {
         return 0.0F;
      } else if (var1.method_7909() instanceof class_9362) {
         return 7.0F;
      } else if (var1.method_7909() instanceof class_1743) {
         return (Boolean)this.llI.III() ? 6.0F : 0.0F;
      } else {
         String var2 = class_7923.field_41178.method_10221(var1.method_7909()).method_12832();
         if (!var2.endsWith(lIlIII.Il(Il[2]))) {
            return 0.0F;
         } else if (var2.contains(lIlIII.Il(Il[3]))) {
            return 8.0F;
         } else if (var2.contains(lIlIII.Il(Il[4]))) {
            return 7.0F;
         } else if (var2.contains(lIlIII.Il(Il[1]))) {
            return 6.0F;
         } else if (var2.contains(lIlIII.Il(Il[5]))) {
            return 5.0F;
         } else {
            return var2.contains(lIlIII.Il(Il[0])) ? 4.0F : 3.0F;
         }
      }
   }

   private boolean IIII(class_310 var1, int var2) {
      if (var1 != null && var1.field_1724 != null && var2 >= 0 && var2 < IIlII(1788680098, -2014296822)) {
         if (this.lII != null && this.lII.ll() != var2) {
            this.lII(var1);
         }

         if (this.lII == null) {
            if (IIlllllI.IIIl(var1.field_1724.method_31548()) == var2) {
               return true;
            }

            this.II = var2;
            this.lII = IllllIlI.lIll(var1, this, var2, 0, true);
         }

         if (this.lII != null && this.lII.III()) {
            if (!IllllIlI.IIII(var1, this.lII)) {
               this.lII(var1);
               return false;
            } else if (IllllIlI.IlIllII(var1, this.lII) && IllllIlI.IIlIIlI(var1, var2)) {
               this.lII = null;
               this.II = -1;
               IllllIlI.IlII(var1, this, null.Il);
               return IIlllllI.IIIl(var1.field_1724.method_31548()) == var2;
            } else {
               return false;
            }
         } else {
            this.lII(var1);
            return false;
         }
      } else {
         return false;
      }
   }

   public void IIll(class_310 var1, class_2338 var2, class_2350 var3) {
      if (this.IIIIIlI() && (Boolean)this.I.III()) {
         if (var1.field_1724 != null && var1.field_1687 != null) {
            class_2680 var4 = var1.field_1687.method_8320(var2);
            int var5 = Illl(var1, var4);
            int var6 = IIlllllI.IIIl(var1.field_1724.method_31548());
            if (var5 >= 0 && var5 != var6) {
               if (this.IIl == -1) {
                  this.IIl = var6;
               }

               this.IIII(var1, var5);
               long var7 = System.currentTimeMillis();
               this.IlI = var7;
               this.Ill = this.IIIll();
               this.l = var7;
               this.lI = this.IIIll();
            }

         }
      }
   }

   private boolean IlII(class_310 var1) {
      boolean var10000;
      if (var1.field_1690 != null && var1.field_1690.field_1886 != null && (var1.field_1690.field_1886.method_1434() || IllllIlI.IllIlI(var1.field_1690.field_1886) > 0)) {
         class_239 var3 = var1.field_1765;
         if (var3 instanceof class_3965) {
            class_3965 var2 = (class_3965)var3;
            if (var2.method_17783() == class_240.field_1332) {
               var10000 = true;
               return var10000;
            }
         }
      }

      var10000 = false;
      return var10000;
   }

   private static void IlIl() {
      Il[0] = llII(IIlIl(1691545860, -52475621).toCharArray(), 94456L, IIlII(1788680099, 1709695491));
      Il[1] = llII(IIlIl(1691545861, 1930982491).toCharArray(), 5817L, IIlII(1788680096, -120697701));
      Il[2] = llII(IIlIl(1691545862, -1730913858).toCharArray(), 83959L, IIlII(1788680097, 1989157411));
      Il[3] = llII(IIlIl(1691545863, 1194074980).toCharArray(), 19070L, IIlII(1788680102, 93146706));
      Il[4] = llII(IIlIl(1691545856, -1072035890).toCharArray(), 22232L, IIlII(1788680103, 1494784530));
      Il[5] = llII(IIlIl(1691545857, -1372708487).toCharArray(), 8563L, IIlII(1788680100, -152690055));
      Il[IIlII(1788680101, 603609405)] = llII(IIlIl(1691545858, 577898824).toCharArray(), 89270L, IIlII(1788680106, -833186361));
      Il[IIlII(1788680107, 1711352110)] = llII(IIlIl(1691545859, -2132264594).toCharArray(), 89220L, IIlII(1788680104, 1419347794));
      Il[IIlII(1788680105, -1169591605)] = llII(IIlIl(1691545868, -343657705).toCharArray(), 81843L, IIlII(1788680110, 1977089323));
      Il[IIlII(1788680111, 1447134818)] = llII(IIlIl(1691545869, -1198119067).toCharArray(), 32506L, IIlII(1788680108, -545352507));
      Il[IIlII(1788680109, 1593867815)] = llII(IIlIl(1691545870, -927462504).toCharArray(), 16290L, IIlII(1788680114, -1822713074));
      Il[IIlII(1788680115, -752892921)] = llII(IIlIl(1691545871, 1710101988).toCharArray(), 45193L, IIlII(1788680112, 882858911));
      Il[IIlII(1788680113, -1036578109)] = llII(IIlIl(1691545864, -1814670231).toCharArray(), 99833L, IIlII(1788680118, -1579245426));
      Il[IIlII(1788680119, -425060590)] = llII(IIlIl(1691545865, 538643699).toCharArray(), 10960L, IIlII(1788680116, -1944567201));
   }

   public static int Illl(class_310 var0, class_2680 var1) {
      if (var0.field_1724 == null) {
         return -1;
      } else {
         int var2 = IIlllllI.IIIl(var0.field_1724.method_31548());
         float var3 = ll(var0, var1, var2);

         for(int var4 = 0; var4 < IIlII(1788680117, -1721516252); ++var4) {
            float var5 = ll(var0, var1, var4);
            if (var5 > var3) {
               var3 = var5;
               var2 = var4;
            }
         }

         return var2;
      }
   }

   private void lIII(class_310 var1, boolean var2) {
      this.lII(var1);
      if (var2 && (Boolean)this.lIl.III() && this.IIl >= 0 && this.IIl < IIlII(1788680122, -1878914539) && var1 != null && var1.field_1724 != null && IIlllllI.IIIl(var1.field_1724.method_31548()) != this.IIl) {
         IllllIlI.IIIIlI(var1, this.IIl);
      }

      this.lllI();
   }

   private int lIIl(class_1657 var1) {
      float var2 = 0.0F;
      int var3 = -1;

      for(int var4 = 0; var4 < IIlII(1788680123, 1081488007); ++var4) {
         class_1799 var5 = var1.method_31548().method_5438(var4);
         float var6 = this.lll(var5);
         if (var6 > var2) {
            var2 = var6;
            var3 = var4;
         }
      }

      return var3;
   }

   static {
      short var6 = 23309;
      String var7 = "岿냘\u1976ᛏ䀎뛼\ua8df፼↥馻罿䥛ꝕ꜎\uda04ܴ銀㈐篅籹ꦱన͐\uef29畄ﴪⲟ琈㜌銗⒴\ueed3쪽\uda63ߛ매巶ꈒ꼮嶩樵贉欈\udb59难䵇䃹\uf11c㳫靸巍秭뼙붯꾉㒢ᱩ\ud9b3\ued28ዞ枢䑥拳➬넿묐\uf011艀껕솾꿓얮鿹釺㖋㨹뭱쀕댤僣ョচ孬ꎌ擯ꞔ嵽䑉讱뜴戅됯鿃㭥봎ฑꂐꊊ疡Ṛ녯⏫⨫逇該㲍\ua4cd㡛˗ꋠ댄藋智棞ꦘㅋ꽒\uebb8ﴀ姡⢏騅驔슉갠헋蜳빑\ue903욌ﳀ\ud8a7△攍桇둁\ued19֑\ue161譒犕횠⌟姹\ue335\ue9cd\udc99苳\uf1cb퐬온\uf62f\ue009\ue7e5撦ꛁ鸁⇉튱।韌蓔\ufae0댭삉엲빰챇砟\uef3a\ufdd1\ue92d\ue388㿁郖\uf331\ueee1ꁴ蒽퀭鄏᷋撝㋹鉠ꇣ맂\u31eeέ\uf344\ud85f濋ʝ㥆\ud982沤읊돊숩\uf28dퟯ\ue3aeྥᰄ\ue9e4݊ࢵᶑꉪ醦짺ﶾ龶䁐ꄺཇ带\ue56e歒뙣줳鞪윙Ċĉ㱾㾊ꛁꧩ乚㬤죡\ueffd\uf8baᣚ陓慒刻荄缹슴\uf859꒡\uf18b組ᦲ㲺굼畼聣땪蹉迶강\ud969ₔ趒蔆⌄㩓";
      char[] var8 = "\b\b\b\f\f\b\u0004\f\u0010\u0010\u0018\u0014\u0010`".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            IIII = var9;
            IIIl = new Object[var9.length];
            int var2 = -1228582029;
            byte[] var0 = "[¨\u0001Òâ®ðQ:\u0081ai\u009epæn!à\u0002ïî\u001a·(%\u008f\u008dÂÿ¢\u001dí+îíãºYmñ#ð;þf\u00116\u0019Å\u001a\u009cò\u008a\u0019Â·H³J\u0084\u0083X:óótJ~\u000fG\u0080Ìh%·\u001c\u001eoV\rô·«\u0093:òSÛ\u008f\tvÃE;ûëLZNÕ\u009c.vFè\u001c²\u0099Uç\u001cëuò\t¨vÁ&Ï³É°GðÎéüêôÁ\rÈÙé\u0098Wx\u0099ïà<\u0013À\u0083\u0089z\f".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lll = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lll[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            Il = new String[IIlII(1788680120, 876934748)];
            IlIl();
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 49;
                     break;
                  case 1:
                     var10000 = 68;
                     break;
                  case 2:
                     var10000 = 110;
                     break;
                  case 3:
                     var10000 = 110;
                     break;
                  case 4:
                     var10000 = 100;
                     break;
                  case 5:
                     var10000 = 41;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public lIl() {
      super((Object)lIlIII.l(Il[IIlII(1788680121, -1983948762)]), lIllII.l, (Object)lIlIII.l(Il[IIlII(1788680126, -1448456856)]));
      this.I = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(Il[IIlII(1788680127, -1432788465)]), true));
      this.lIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(Il[IIlII(1788680124, 1871836288)]), true));
      this.III = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(Il[IIlII(1788680125, 748072251)]), (double)45.0F, (double)55.0F, (double)0.0F, (double)250.0F, (double)5.0F)).IIII(lIlIII.Il(Il[IIlII(1788680066, 917276154)])));
      this.ll = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(Il[IIlII(1788680067, 344042851)]), false));
      this.llI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(Il[IIlII(1788680064, -1960780522)]), false));
      this.IIl = -1;
      this.II = -1;
   }

   private static String llII(char[] var0, long var1, int var3) {
      int var4 = IIlII(1788680065, -632843262) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IIlII(1788680070, 1607548422);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private void lllI() {
      this.IIl = -1;
      this.IlI = 0L;
      this.Ill = 0L;
      this.l = 0L;
      this.lI = 0L;
      this.II = -1;
      this.lII = null;
   }

   public void lIl() {
      this.lllI();
   }

   public void lI() {
      this.lIII(class_310.method_1551(), true);
   }

   private void IIIII(class_310 var1) {
      if (this.IIl >= 0 && var1.field_1724 != null) {
         if (!(Boolean)this.lIl.III()) {
            this.lII(var1);
            this.lllI();
         } else {
            long var2 = System.currentTimeMillis();
            if (this.l == 0L || var2 - this.l >= this.lI) {
               if (this.IIII(var1, this.IIl)) {
                  this.lllI();
               }
            }
         }
      }
   }

   private static boolean IIIIl(class_310 var0) {
      if (var0 != null && var0.field_1724 != null && var0.field_1687 != null) {
         class_1799 var1 = var0.field_1724.method_6047();
         if (!var1.method_7960() && var1.method_31574(class_1802.field_8301)) {
            class_239 var3 = var0.field_1765;
            if (var3 instanceof class_3965) {
               class_3965 var2 = (class_3965)var3;
               if (var2.method_17783() == class_240.field_1332) {
                  class_2680 var4 = var0.field_1687.method_8320(var2.method_17777());
                  if (!var4.method_27852(class_2246.field_10540) && !var4.method_27852(class_2246.field_9987)) {
                     return false;
                  }

                  return true;
               }
            }

            return false;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private long IIIll() {
      double var1 = this.III.IlII();
      double var3 = this.III.IlI();
      return var1 == var3 ? Math.max(0L, Math.round(var1)) : Math.max(0L, Math.round(ThreadLocalRandom.current().nextDouble(var1, var3)));
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null) {
         this.IlI(var1);
         if (!this.llI(var1)) {
            this.IIIII(var1);
         } else {
            long var2 = System.currentTimeMillis();
            if (this.IlI == 0L || var2 - this.IlI >= this.Ill) {
               class_239 var5 = var1.field_1765;
               if (var5 instanceof class_3965) {
                  class_3965 var4 = (class_3965)var5;
                  if (var4.method_17783() == class_240.field_1332) {
                     class_2680 var8 = var1.field_1687.method_8320(var4.method_17777());
                     int var6 = Illl(var1, var8);
                     int var7 = IIlllllI.IIIl(var1.field_1724.method_31548());
                     if (var6 >= 0 && var6 != var7) {
                        if (this.IIl == -1) {
                           this.IIl = var7;
                        }

                        this.IIII(var1, var6);
                        this.IlI = var2;
                        this.Ill = this.IIIll();
                        this.l = var2;
                        this.lI = this.IIIll();
                     }

                     return;
                  }
               }

            }
         }
      } else {
         this.lIII(var1, false);
      }
   }

   private static int IIlII(int var0, int var1) {
      return lll[var0 ^ 1788680098] ^ var1 ^ var0;
   }

   private static String IIlIl(int var0, int var1) {
      int var3 = var0 ^ 1691545860;
      char[] var4 = IIII[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IIIl[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IIIl[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 82390875;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 232;
               break;
            case 1:
               var9 = 150;
               break;
            case 2:
               var9 = 216;
               break;
            case 3:
               var9 = 201;
               break;
            case 4:
               var9 = 241;
               break;
            case 5:
               var9 = 16;
               break;
            case 6:
               var9 = 210;
               break;
            case 7:
               var9 = 143;
               break;
            case 8:
               var9 = 21;
               break;
            case 9:
               var9 = 30;
               break;
            case 10:
               var9 = 209;
               break;
            case 11:
               var9 = 184;
               break;
            case 12:
               var9 = 146;
               break;
            case 13:
               var9 = 59;
               break;
            case 14:
               var9 = 237;
               break;
            case 15:
               var9 = 52;
               break;
            case 16:
               var9 = 227;
               break;
            case 17:
               var9 = 61;
               break;
            case 18:
               var9 = 144;
               break;
            case 19:
               var9 = 150;
               break;
            case 20:
               var9 = 165;
               break;
            case 21:
               var9 = 212;
               break;
            case 22:
               var9 = 193;
               break;
            case 23:
               var9 = 79;
               break;
            case 24:
               var9 = 213;
               break;
            case 25:
               var9 = 86;
               break;
            case 26:
               var9 = 68;
               break;
            case 27:
               var9 = 3;
               break;
            case 28:
               var9 = 170;
               break;
            case 29:
               var9 = 174;
               break;
            case 30:
               var9 = 50;
               break;
            case 31:
               var9 = 168;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
