package x;

import java.lang.reflect.Method;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_639;
import net.minecraft.class_642;

@Environment(EnvType.CLIENT)
public final class lllIlIl {
   private static String[] I;
   private static final int[] l;
   private static final String[] II;
   private static final Object[] Il;

   private static String I(Object var0, String var1) {
      if (var0 == null) {
         return I[0];
      } else {
         try {
            Method var2 = var0.getClass().getMethod(var1);
            Object var3 = var2.invoke(var0);
            String var10000;
            if (var3 instanceof String) {
               String var4 = (String)var3;
               var10000 = var4;
            } else {
               var10000 = I[0];
            }

            return var10000;
         } catch (ReflectiveOperationException var5) {
            return I[0];
         }
      }
   }

   static {
      short var6 = 21161;
      String var7 = "믙ꁶ\ue61eﳹ웊펼珅讥递懁ⴎ\ue29a⧁\u187fଧ같詔\uec21襈\ue5b1猯ୢꞬ\u20f4Ų㽳艙槶ᔘˍ瓅鱽쌸\uf891틟䤑\uf646升␚끞爰䔱곙㥛雴\uf8ecਾ\ue4a1㋗ᡴ㕺ᅦꀇ栮ര社哭삨뾑\uecc9㋋泾ୡ噜㫸䍢ቒ祌譌儉\uf139ꩥÀ鵻乹㾠綦癶숽췼";
      char[] var8 = "効劭劽劽劭効".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            II = var9;
            Il = new Object[var9.length];
            int var2 = 265499315;
            byte[] var0 = "Ýc¾BU\u0083Äé\r\u000eµ\u0019g\u000fs\u0096ÑcqGá¶\n~Ý`Û\u000b¶?þK#Nf\u008b;\u008aAEá d¡\u008byà'".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            l = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               l[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            I = new String[III(1455885837, -2072542469)];
            lI();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public static String l(class_639 var0, class_642 var1) {
      if (var1 != null && var1.field_3761 != null && !var1.field_3761.isBlank()) {
         return var1.field_3761;
      } else {
         String var2 = I(var0, lIlIII.Il(I[III(1455885836, 211286096)]));
         if (!var2.isBlank()) {
            return var2;
         } else {
            String var3 = var0 == null ? I[0] : String.valueOf(var0);
            return var3.contains(lIlIII.Il(I[5])) ? I[0] : var3;
         }
      }
   }

   public static boolean II(String var0) {
      if (var0 == null) {
         return false;
      } else {
         String var1 = var0.trim().toLowerCase();
         if (var1.contains(lIlIII.Il(I[2]))) {
            var1 = var1.split(lIlIII.Il(I[2]))[0].trim();
         }

         return var1.equals(lIlIII.Il(I[3])) || var1.equals(lIlIII.Il(I[1])) || var1.equals(lIlIII.Il(I[4]));
      }
   }

   public static boolean Il(class_437 var0, class_310 var1, class_639 var2, class_642 var3) {
      String var4 = l(var2, var3);
      return II(var4);
   }

   private lllIlIl() {
   }

   private static void lI() {
      I[0] = ll("".toCharArray(), 70471L, III(1455885839, -855663195));
      I[1] = ll(IIl('坽', 1324953093, '쏰').toCharArray(), 67695L, III(1455885838, -1844963041));
      I[2] = ll(IIl('坼', -1304730999, '얚').toCharArray(), 14254L, III(1455885833, -870311305));
      I[3] = ll(IIl('坿', 1243446476, '\uf8c9').toCharArray(), 95270L, III(1455885832, 823759817));
      I[4] = ll(IIl('坾', -707782245, 'ᐻ').toCharArray(), 83866L, III(1455885835, 404158623));
      I[5] = ll(IIl('坹', -1807403988, '镩').toCharArray(), 15444L, III(1455885834, 1726085314));
      I[III(1455885829, 2052741691)] = ll(IIl('坸', -2031871652, 'Ꮸ').toCharArray(), 56256L, III(1455885828, 574736326));
   }

   private static String ll(char[] var0, long var1, int var3) {
      int var4 = III(1455885831, -133968396) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & III(1455885830, -764552083);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private static int III(int var0, int var1) {
      return l[var0 ^ 1455885837] ^ var1 ^ var0;
   }

   private static String IIl(char var0, int var1, char var2) {
      int var3 = var0 ^ 22397;
      char[] var4 = II[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])Il[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         Il[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 21777;
      int var9 = 0;

      do {
         int var10 = var4[var9] + 3306;
         var10 += 28377;
         var10 += 8130;
         var10 += 58347;
         var10 -= 20952;
         var4[var9] = (char)(var10 ^ var8 ^ var2 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
