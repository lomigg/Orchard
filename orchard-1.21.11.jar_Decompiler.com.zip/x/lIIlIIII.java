package x;

import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1812;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_490;
import net.minecraft.class_746;

@Environment(EnvType.CLIENT)
abstract class lIIlIIII extends IIIIIIIlI {
   private final int[] l = new int[llIII(51990043, -391194037)];
   private final lIIIIl II;
   private final IlIIIlIlI<IIlllIllI> Il;
   private final IIIllIIII lI;
   private int ll = -1;
   private final llllIlIl III;
   private boolean IIl;
   private int IlI = llIII(51990037, 943717871);
   private final class_1799[] Ill = new class_1799[llIII(51990042, -54458122)];
   private static final int lII = 36;
   private long lIl;
   private final lIIIIl llI;
   private long lll;
   private boolean IIII;
   private final IIIllIIII IIIl;
   private static final int IIlI = 9;
   private static String[] IIll;
   private int IlII = -1;
   private boolean IlIl;
   private int IllI;
   private final lIIIIl Illl;
   private final <undefinedtype> lIII;
   private static final int[] lIlI;
   private static final String[] llIl;
   private static final Object[] lllI;

   private boolean ll(class_310 var1) {
      boolean var2 = var1 != null && var1.field_1755 instanceof class_490;
      if (this.IlIl()) {
         if (this.Il.III() == IIlllIllI.Il) {
            if (!lIlIllll.llII(var1)) {
               return false;
            } else {
               lIlIllll.IllI(var1);
               return true;
            }
         } else if (this.IIIll(var1) && this.IlIII(var1)) {
            lIlIllll.IllI(var1);
            return true;
         } else {
            return false;
         }
      } else if (!lIlIllll.I(var1)) {
         return false;
      } else if (!var2 && !lIlIllll.IIIl(var1)) {
         return false;
      } else if (!lIlIllll.III(var1)) {
         return false;
      } else {
         lIlIllll.IllI(var1);
         return true;
      }
   }

   public String Il() {
      return this.IIIl == null ? IIll[0] : String.valueOf(Math.round((Double)this.IIIl.III()));
   }

   private void IlI(class_310 var1, class_746 var2) {
      this.IIII(var2);
      if (var2.field_7498.method_34255().method_7960()) {
         this.IlIl = false;
         this.IllI = 0;
         if (System.currentTimeMillis() - this.lll >= this.lIl) {
            if (this.IIlIl(var1, var2)) {
               if (lIlIllll.IIIII(var1)) {
                  int var3 = 0;

                  for(int var4 = 0; var4 < llIII(51990018, 434116813) && var2.field_7498.method_34255().method_7960(); ++var4) {
                     class_1799 var5 = var2.method_31548().method_5438(var4);
                     if (!this.lll(var1, var5, var4)) {
                        class_1799 var6 = this.IlIIl(var4, var5);
                        if (!var6.method_7960() && this.lIIl(var5, var6) && this.IIllI(var6)) {
                           int var7 = this.IllII(var2, var6);
                           if (var7 >= 0) {
                              if (!this.IIll(var1, var2, var7, llIII(51990019, 306471743) + var4)) {
                                 break;
                              }

                              ++var3;
                           }
                        }
                     }
                  }

                  if (var3 > 0) {
                     this.lll = System.currentTimeMillis();
                     this.lIl = this.IIIIl();
                     lIlIllll.IllI(var1);
                  }

                  lIlIllll.llIl(var1);
               }
            }
         }
      }
   }

   private boolean lII(class_1799 var1) {
      return System.currentTimeMillis() - this.lll >= this.lIl;
   }

   private boolean llI(class_1799 var1) {
      return !(var1.method_7909() instanceof class_1812) && !this.IlII(var1) && !var1.method_31574(class_1802.field_8069);
   }

   private boolean lll(class_310 var1, class_1799 var2, int var3) {
      return var2.method_7960() && var1 != null && var1.field_1724 != null && var1.field_1755 instanceof class_490 && !this.IIII && var3 >= 0 && var3 < llIII(51990016, -1325576938) && this.l[var3] >= var1.field_1724.field_6012;
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (var1.field_1724 != null && var1.field_1761 != null && var1.field_1687 != null) {
         lIllIIl var2 = lIllIIl.Il();
         if (var2 != null) {
            IIIIIlIlI var3 = var2.IIl().IIllI();
            if (var3 != null && var3.llI()) {
               return;
            }
         }

         if ((Boolean)this.llI.III() && !(var1.field_1755 instanceof class_490)) {
            this.Illll();
         } else if (this.IlIl()) {
            this.IIlII(var1, var1.field_1724);
         } else {
            boolean var12 = this.IIII && var1.field_1755 instanceof class_490;
            if ((Boolean)this.llI.III() || !(Boolean)this.II.III() || var1.field_1755 == null || var12) {
               if (var1.field_1755 == null || var1.field_1755 instanceof class_490 || var12) {
                  class_746 var4 = var1.field_1724;
                  this.IIII(var4);
                  if (this.IIIII()) {
                     if (this.IIl) {
                        if (var4.field_6012 < this.IlI) {
                           return;
                        }

                        if (!this.ll(var1)) {
                           return;
                        }
                     } else if (!(var1.field_1755 instanceof class_490)) {
                        this.Illll();
                        return;
                     }

                     if (this.IIl || this.ll(var1)) {
                        boolean var13 = this.IIll(var1, var4, this.ll, this.IlII);
                        this.lll = System.currentTimeMillis();
                        this.lIl = this.IIIIl();
                        if (this.IIII && var13) {
                           this.lIIll(var1);
                        }

                        this.Illll();
                     }
                  } else if (var1.field_1724.field_7498.method_34255().method_7960()) {
                     if (System.currentTimeMillis() - this.lll >= this.lIl) {
                        boolean var5 = var1.field_1755 instanceof class_490;
                        if (!var5) {
                           for(int var14 = 0; var14 < llIII(51990023, -50508430); ++var14) {
                              class_1799 var15 = var4.method_31548().method_5438(var14);
                              class_1799 var16 = this.IlIIl(var14, var15);
                              if (!var16.method_7960() && this.lIIl(var15, var16) && this.IIllI(var16) && this.lII(var16)) {
                                 int var17 = this.IllII(var4, var16);
                                 if (var17 >= 0) {
                                    int var18 = llIII(51990020, -606574283) + var14;
                                    if (!(Boolean)this.llI.III()) {
                                       if (!this.ll(var1)) {
                                          return;
                                       }

                                       this.lIIIl(var17, var18, var4, var1);
                                       return;
                                    }
                                 }
                              }
                           }

                        } else {
                           int var6 = 0;

                           for(int var7 = 0; var7 < llIII(51990017, 986943248) && var1.field_1724.field_7498.method_34255().method_7960(); ++var7) {
                              class_1799 var8 = var4.method_31548().method_5438(var7);
                              if (!this.lll(var1, var8, var7)) {
                                 class_1799 var9 = this.IlIIl(var7, var8);
                                 if (!var9.method_7960() && this.lIIl(var8, var9) && this.IIllI(var9)) {
                                    int var10 = this.IllII(var4, var9);
                                    if (var10 >= 0) {
                                       int var11 = llIII(51990022, 168469357) + var7;
                                       if (!this.ll(var1)) {
                                          return;
                                       }

                                       if (var6 == 0) {
                                          this.lIIIl(var10, var11, var4, var1);
                                          return;
                                       }

                                       if (!this.IIll(var1, var4, var10, var11)) {
                                          return;
                                       }

                                       ++var6;
                                    }
                                 }
                              }
                           }

                           if (var6 > 0) {
                              this.lll = System.currentTimeMillis();
                              this.lIl = this.IIIIl();
                           }

                        }
                     }
                  }
               }
            }
         }
      } else {
         this.Illll();
         this.IlIl = false;
         this.IllI = 0;
      }
   }

   private void IIII(class_746 var1) {
      for(int var2 = 0; var2 < llIII(51990021, 1771396302); ++var2) {
         class_1799 var3 = var1.method_31548().method_5438(var2);
         if (!var3.method_7960()) {
            this.Ill[var2] = var3.method_7972();
            this.l[var2] = llIII(51990026, 1718538624);
         } else if (!this.Ill[var2].method_7960() && this.l[var2] == llIII(51990027, -480913694)) {
            this.l[var2] = var1.field_6012;
         }
      }

   }

   private boolean IIll(class_310 var1, class_746 var2, int var3, int var4) {
      if (var3 >= 0 && var4 >= 0 && var3 != var4 && var2.field_7498.method_34255().method_7960()) {
         int var5 = var2.field_7498.field_7763;
         var1.field_1761.method_2906(var5, var3, 0, class_1713.field_7790, var2);
         var1.field_1761.method_2906(var5, var4, 0, class_1713.field_7790, var2);
         if (!var2.field_7498.method_34255().method_7960()) {
            var1.field_1761.method_2906(var5, var3, 0, class_1713.field_7790, var2);
         }

         return var2.field_7498.method_34255().method_7960();
      } else {
         return false;
      }
   }

   private boolean IlII(class_1799 var1) {
      return !var1.method_7960() && var1.method_7909() == class_1802.field_8288;
   }

   private boolean IlIl() {
      return !(Boolean)this.llI.III();
   }

   public void lIl() {
      this.lll = 0L;
      this.lIl = this.IIIIl();
      this.Illll();
      this.IlIl = false;
      this.IllI = 0;
      this.Illl();
   }

   private void Illl() {
      for(int var1 = 0; var1 < this.Ill.length; ++var1) {
         this.Ill[var1] = class_1799.field_8037;
         this.l[var1] = llIII(51990024, 430398002);
      }

   }

   private void lIII(class_310 var1, class_746 var2) {
      if (var1.field_1755 instanceof class_490) {
         this.IIII = false;
      } else {
         var1.method_1507(new class_490(var2));
         this.IIII = true;
      }
   }

   private boolean lIIl(class_1799 var1, class_1799 var2) {
      if (!var2.method_7960() && this.IIllI(var2)) {
         if (this.lIII != null.II) {
            return var1.method_7960();
         } else if (var1.method_7960()) {
            return var2.method_7914() > 0;
         } else if (var1.method_7946() && var1.method_7914() > 1) {
            if (var1.method_7947() >= var1.method_7914()) {
               return false;
            } else {
               int var3 = Math.min((int)Math.round((Double)this.IIIl.III()), var1.method_7914() - 1);
               return var1.method_7947() <= var3;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private int lIll() {
      return Math.max(1, Math.min(llIII(51990025, -266591878), (int)Math.round((Double)this.lI.III())));
   }

   public void lI() {
      this.lIIll(class_310.method_1551());
      this.Illll();
      this.IlIl = false;
      this.IllI = 0;
      this.lIl = 0L;
      this.Illl();
   }

   static {
      short var6 = 10937;
      String var7 = "\uf013쒦⍹矉팲㞂ᓇ䥻뭛⏹῍ᤨި䆥聖௨餍ꚃꏭ⧋歇ᙖ\udcee푯᎐\uf40fꥊ贉妯\uf59f矱澿숯택✐힟㹱\uf7d7ഛ\ue10dᨂ떁讅⌐솪\ue864绘\udd49\ue7ca醏ፌ햇ᬚ\ud99c畼❁黎烴珖脐ੇꕠꙷӫ賎╽尾澲킷ⷍㅠ\udbda㽺魬ၧ\uf7c7寯멻쓥ޛ໔賯殾ন逊\u1aafۻ䙷ꭚ䁰\uf39f嫄㶞㕢롵\ue232릍歬붕剓\ue5f5퇭概ꭥ쿌ཌ譣埝ؤ옸\ud969Ꮮ誹蠰쯾\ued96ᡓᦘ\u17fc뫐";
      char[] var8 = "⪥⪱⪵⪩⪭⪭⪽⪵".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            llIl = var9;
            lllI = new Object[var9.length];
            int var2 = 173036771;
            byte[] var0 = "\u0010©\u0002%\u001b\ryû¹´Wü3\u009a\u0095û\u0003C¹¬õ´W\u009fÒ\u0091sö`ÜF!ï'Ëij\u001cÌ\n\u0090î@ÙùU;\u0099r5Ëâ+æ\u001fÊ\u0083Á×ö¢NëGÛ\u0093j\u0007\u0006ã/Êb\u000fÔ¬H5\u00114y~ÛP\u00ad¯.ö\u0005\u0080ò'±vç\u0019õ\u0088\u0012\u0006áçÀºgþ\u0011F\u008c3¿\u000f?4gÞÿqÚ\u00ad³È0½\u0012\u009eÒ3l5LÙÍ¬A\u0097d\u0094F\u0088/¶3\u000e·F´ñiñXÉ9\t^Z[Ð5ì¸å\u0088îZ_/!".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lIlI = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lIlI[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            IIll = new String[llIII(51990030, 2071777542)];
            lIIlI();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private boolean lllI(class_310 var1, class_746 var2) {
      for(int var3 = 0; var3 < llIII(51990031, 581895471); ++var3) {
         class_1799 var4 = var2.method_31548().method_5438(var3);
         if (!this.lll(var1, var4, var3)) {
            class_1799 var5 = this.IlIIl(var3, var4);
            if (!var5.method_7960() && this.lIIl(var4, var5) && this.IIllI(var5)) {
               int var6 = this.IllII(var2, var5);
               if (var6 >= 0) {
                  this.lIIIl(var6, llIII(51990028, -1970746051) + var3, var2, var1);
                  return true;
               }
            }
         }
      }

      return false;
   }

   private boolean IIIII() {
      return this.ll >= 0 && this.IlII >= 0;
   }

   private long IIIIl() {
      double var1 = this.III.IlII();
      double var3 = this.III.IlI();
      return var1 == var3 ? Math.round(var1) : Math.round(ThreadLocalRandom.current().nextDouble(var1, var3));
   }

   private boolean IIIll(class_310 var1) {
      boolean var10000;
      switch ((IIlllIllI)this.Il.III()) {
         case I -> var10000 = lIlIllll.IlIl(var1);
         case ll -> var10000 = lIlIllll.lIl(var1);
         case Il -> var10000 = true;
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   private void IIlII(class_310 var1, class_746 var2) {
      if (this.Il.III() == IIlllIllI.Il) {
         this.IlI(var1, var2);
      } else {
         this.IIII(var2);
         boolean var3 = var1.field_1755 instanceof class_490;
         if ((Boolean)this.llI.III() && !var3) {
            this.Illll();
            this.IlIl = false;
            this.IllI = 0;
         } else if (!(Boolean)this.llI.III() && (Boolean)this.II.III() && var1.field_1755 != null && !var3) {
            this.IlIl = false;
            this.IllI = 0;
         } else if (var1.field_1755 != null && !var3) {
            this.IlIl = false;
            this.IllI = 0;
         } else if (var2.field_7498.method_34255().method_7960()) {
            if (this.Il.III() != IIlllIllI.I) {
               this.IlIl = false;
               this.IllI = 0;
               this.Illll();
            }

            if (this.Il.III() == IIlllIllI.I && this.IIIII()) {
               if (var2.field_6012 >= this.IlI) {
                  if (this.ll(var1)) {
                     boolean var11 = this.IIll(var1, var2, this.ll, this.IlII);
                     this.Illll();
                     if (var11) {
                        this.lll = System.currentTimeMillis();
                        this.lIl = this.IIIIl();
                        this.IllI = Math.max(0, this.IllI - 1);
                        if (this.IllI == 0) {
                           this.IlIl = false;
                        }
                     } else {
                        this.IlIl = false;
                        this.IllI = 0;
                        this.lIl = 0L;
                     }

                  }
               }
            } else if (this.Il.III() != IIlllIllI.I || this.IlIl || System.currentTimeMillis() - this.lll >= this.lIl) {
               int var4 = this.IIlll(var1, var2);
               if (var4 <= 0) {
                  this.IlIl = false;
                  this.IllI = 0;
               } else if (this.Il.III() == IIlllIllI.I) {
                  if (System.currentTimeMillis() - this.lll >= this.lIl || this.IlIl) {
                     if (!this.IlIl) {
                        this.IlIl = true;
                        this.IllI = Math.min(var4, this.lIll());
                     }

                     if (!this.lllI(var1, var2)) {
                        this.IlIl = false;
                        this.IllI = 0;
                     }

                  }
               } else if (System.currentTimeMillis() - this.lll >= this.lIl) {
                  if (this.IIIll(var1) && this.IlIII(var1)) {
                     int var5 = 0;

                     for(int var6 = 0; var6 < llIII(51990029, -1425542752) && var2.field_7498.method_34255().method_7960(); ++var6) {
                        class_1799 var7 = var2.method_31548().method_5438(var6);
                        if (!this.lll(var1, var7, var6)) {
                           class_1799 var8 = this.IlIIl(var6, var7);
                           if (!var8.method_7960() && this.lIIl(var7, var8) && this.IIllI(var8)) {
                              int var9 = this.IllII(var2, var8);
                              if (var9 >= 0) {
                                 int var10 = llIII(51990034, -757436206) + var6;
                                 if (!this.IIll(var1, var2, var9, var10)) {
                                    break;
                                 }

                                 ++var5;
                              }
                           }
                        }
                     }

                     if (var5 > 0) {
                        this.lll = System.currentTimeMillis();
                        this.lIl = this.IIIIl();
                        lIlIllll.IllI(var1);
                     }

                  }
               }
            }
         }
      }
   }

   private boolean IIlIl(class_310 var1, class_746 var2) {
      for(int var3 = 0; var3 < llIII(51990035, 262812979); ++var3) {
         class_1799 var4 = var2.method_31548().method_5438(var3);
         if (!this.lll(var1, var4, var3)) {
            class_1799 var5 = this.IlIIl(var3, var4);
            if (!var5.method_7960() && this.lIIl(var4, var5) && this.IIllI(var5) && this.IllII(var2, var5) >= 0) {
               return true;
            }
         }
      }

      return false;
   }

   private boolean IIllI(class_1799 var1) {
      if (var1.method_7960()) {
         return false;
      } else {
         boolean var10000;
         switch (this.lIII.ordinal()) {
            case 0 -> var10000 = var1.method_7909() instanceof class_1812;
            case 1 -> var10000 = this.llI(var1);
            case 2 -> var10000 = var1.method_31574(class_1802.field_8069);
            default -> throw new MatchException((String)null, (Throwable)null);
         }

         return var10000;
      }
   }

   private int IIlll(class_310 var1, class_746 var2) {
      int var3 = 0;

      for(int var4 = 0; var4 < llIII(51990032, 1799802454); ++var4) {
         class_1799 var5 = var2.method_31548().method_5438(var4);
         if (!this.lll(var1, var5, var4)) {
            class_1799 var6 = this.IlIIl(var4, var5);
            if (!var6.method_7960() && this.lIIl(var5, var6) && this.IIllI(var6) && this.IllII(var2, var6) >= 0) {
               ++var3;
            }
         }
      }

      return var3;
   }

   private boolean IlIII(class_310 var1) {
      boolean var10000;
      switch ((IIlllIllI)this.Il.III()) {
         case I -> var10000 = lIlIllll.IIll(var1);
         case ll -> var10000 = lIlIllll.IIl(var1);
         case Il -> var10000 = lIlIllll.llII(var1);
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   private class_1799 IlIIl(int var1, class_1799 var2) {
      if (!var2.method_7960()) {
         return var2;
      } else {
         class_1799 var3 = this.Ill[var1];
         return var3 == null ? class_1799.field_8037 : var3;
      }
   }

   private boolean IlIll(class_1799 var1, class_1799 var2) {
      return class_1799.method_31577(var1, var2) && var1.method_7947() > 0;
   }

   private int IllII(class_746 var1, class_1799 var2) {
      int var3 = -1;
      int var4 = 0;

      for(int var5 = llIII(51990033, 1098648527); var5 < llIII(51990038, 1882702209); ++var5) {
         class_1799 var6 = ((class_1735)var1.field_7498.field_7761.get(var5)).method_7677();
         if (!var6.method_7960() && this.IlIll(var6, var2) && var6.method_7947() > var4) {
            var3 = var5;
            var4 = var6.method_7947();
         }
      }

      lIllIIl var9 = lIllIIl.Il();
      if ((Boolean)this.Illl.III() && var9 != null) {
         lIIlIl var10 = var9.IIl().IIIlII();
         if (var10 != null && var10.lll()) {
            for(int var7 = 1; var7 <= 4; ++var7) {
               class_1799 var8 = ((class_1735)var1.field_7498.field_7761.get(var7)).method_7677();
               if (!var8.method_7960() && this.IlIll(var8, var2) && var8.method_7947() > var4) {
                  var3 = var7;
                  var4 = var8.method_7947();
               }
            }
         }
      }

      return var3;
   }

   private static String IlllI(char[] var0, long var1, int var3) {
      int var4 = llIII(51990039, -1591669215) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & llIII(51990036, 214558767);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   protected lIIlIIII(Object var1, Object var2, Object var3, boolean var4) {
      super(var1, lIllII.l, var2);
      this.lIII = var3;
      this.IIIl = var4 ? (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(IIll[3]), (double)10.0F, (double)1.0F, (double)63.0F, (double)1.0F)) : null;
      this.III = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(IIll[2]), (double)75.0F, (double)75.0F, (double)0.0F, (double)500.0F, (double)5.0F)).IIII(lIlIII.Il(IIll[llIII(51990040, 1857489850)])));
      this.Il = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IIll[llIII(51990041, -2055559683)]), IIlllIllI.class, IIlllIllI.I));
      this.lI = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(IIll[llIII(51990046, 914193701)]), (double)1.0F, (double)1.0F, (double)9.0F, (double)1.0F));
      this.Illl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIll[4]), true));
      this.llI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIll[1]), var3 != null.I));
      this.II = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIll[5]), true));
      this.II.lIII(() -> !(Boolean)this.llI.III());
      this.lI.lIII(() -> !(Boolean)this.llI.III() && this.Il.III() == IIlllIllI.I);
      this.Il.lIII(() -> !(Boolean)this.llI.III());
      this.Illl.lIII(() -> !(Boolean)this.llI.III());
   }

   private void Illll() {
      this.ll = -1;
      this.IlII = -1;
      this.IlI = llIII(51990047, 1983430737);
      this.IIl = false;
      this.IIII = false;
   }

   private void lIIIl(int var1, int var2, class_746 var3, class_310 var4) {
      this.ll = var1;
      this.IlII = var2;
      this.IlI = var3.field_6012 + 1;
      this.IIl = true;
      if (this.Il.III() == IIlllIllI.Il) {
         lIlIllll.IlI(var4);
      } else if (this.Il.III() == IIlllIllI.I) {
         lIlIllll.lll(var4);
      }

   }

   private static void lIIlI() {
      IIll[0] = IlllI("".toCharArray(), 9455L, llIII(51990044, 1884278017));
      IIll[1] = IlllI(llIlI(-592233568, 1339259783).toCharArray(), 95179L, llIII(51990045, 480952429));
      IIll[2] = IlllI(llIlI(-592233567, 995185751).toCharArray(), 11184L, llIII(51990050, -2112498045));
      IIll[3] = IlllI(llIlI(-592233566, -879418545).toCharArray(), 75910L, llIII(51990051, 1389785420));
      IIll[4] = IlllI(llIlI(-592233565, 566908364).toCharArray(), 40842L, llIII(51990048, 929916588));
      IIll[5] = IlllI(llIlI(-592233564, 524570943).toCharArray(), 21170L, llIII(51990049, -862273407));
      IIll[llIII(51990054, -1106268622)] = IlllI(llIlI(-592233563, -758311796).toCharArray(), 14346L, llIII(51990055, -1275380278));
      IIll[llIII(51990052, 809518234)] = IlllI(llIlI(-592233562, -955840636).toCharArray(), 30085L, llIII(51990053, -870947521));
      IIll[llIII(51990058, -1314090449)] = IlllI(llIlI(-592233561, 1342927904).toCharArray(), 93211L, llIII(51990059, 1880389491));
   }

   private void lIIll(class_310 var1) {
      if (this.IIII) {
         if (var1 != null && var1.field_1755 instanceof class_490) {
            var1.method_1507((class_437)null);
         }

         this.IIII = false;
      }
   }

   private static int llIII(int var0, int var1) {
      return lIlI[var0 ^ 51990018] ^ var1 ^ var0;
   }

   private static String llIlI(int var0, int var1) {
      int var3 = var0 ^ -592233568;
      char[] var4 = llIl[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])lllI[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         lllI[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -1617014266;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 2;
               break;
            case 1:
               var9 = 55;
               break;
            case 2:
               var9 = 78;
               break;
            case 3:
               var9 = 86;
               break;
            case 4:
               var9 = 193;
               break;
            case 5:
               var9 = 190;
               break;
            case 6:
               var9 = 248;
               break;
            case 7:
               var9 = 178;
               break;
            case 8:
               var9 = 88;
               break;
            case 9:
               var9 = 82;
               break;
            case 10:
               var9 = 130;
               break;
            case 11:
               var9 = 177;
               break;
            case 12:
               var9 = 163;
               break;
            case 13:
               var9 = 0;
               break;
            case 14:
               var9 = 248;
               break;
            case 15:
               var9 = 5;
               break;
            case 16:
               var9 = 248;
               break;
            case 17:
               var9 = 18;
               break;
            case 18:
               var9 = 46;
               break;
            case 19:
               var9 = 156;
               break;
            case 20:
               var9 = 77;
               break;
            case 21:
               var9 = 87;
               break;
            case 22:
               var9 = 213;
               break;
            case 23:
               var9 = 239;
               break;
            case 24:
               var9 = 26;
               break;
            case 25:
               var9 = 242;
               break;
            case 26:
               var9 = 168;
               break;
            case 27:
               var9 = 138;
               break;
            case 28:
               var9 = 232;
               break;
            case 29:
               var9 = 28;
               break;
            case 30:
               var9 = 19;
               break;
            case 31:
               var9 = 111;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
