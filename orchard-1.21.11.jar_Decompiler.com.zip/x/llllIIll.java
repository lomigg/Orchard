package x;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.net.http.HttpClient;
import java.net.http.HttpResponse;
import java.net.http.HttpClient.Redirect;
import java.time.Duration;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.fabricmc.loader.api.metadata.CustomValue;
import net.fabricmc.loader.api.metadata.ModMetadata;

@Environment(EnvType.CLIENT)
public final class llllIIll {
   private final <undefinedtype> I = III();
   private volatile <undefinedtype> l;
   private static final long II = 1800000L;
   static final <undefinedtype> Il;
   private volatile long lI;
   static final boolean ll = false;
   private static final <undefinedtype> III;
   private static final int IIl = 16384;
   private volatile CompletableFuture<Void> IlI;
   private static final <undefinedtype> Ill;
   static final <undefinedtype> lII;
   static final <undefinedtype> lIl;
   private static final HttpClient llI;
   private static final Duration lll;
   static final <undefinedtype> IIII;
   private static final int[] IIIl;
   private static final String[] IIlI;
   private static final Object[] IIll;

   void I() {
      this.IlI = null;
      this.l = null.I(this.I);
   }

   String l() {
      String var10000 = lIlIII.l(lll('ｄ', -1351414926, (short)9952)).lIlI();
      String var2 = lIl.lIlI();
      String var1 = var10000;
      return var1 + var2;
   }

   private static String II(JsonObject var0, String var1) {
      JsonElement var2 = var0 == null ? null : var0.get(var1);
      return var2 != null && !var2.isJsonNull() ? var2.getAsString().trim() : "";
   }

   private static int Il(ModMetadata var0, String var1) {
      if (var0 != null && var1 != null && var0.containsCustomValue(var1)) {
         CustomValue var2 = var0.getCustomValue(var1);
         if (var2 == null) {
            return 0;
         } else {
            try {
               Number var3 = var2.getAsNumber();
               return var3 == null ? 0 : var3.intValue();
            } catch (RuntimeException var6) {
               try {
                  return Integer.parseInt(var2.getAsString());
               } catch (RuntimeException var5) {
                  return 0;
               }
            }
         }
      } else {
         return 0;
      }
   }

   static String lI(String var0, int var1) {
      String var2 = var0 != null && !var0.isBlank() ? var0.trim() : lIlIII.Il(lll('ｅ', 827919462, (short)32212));
      String var10000;
      if (var1 > 0) {
         String var4 = lIlIII.Il(lll('ｆ', -244841353, (short)'蔎'));
         var10000 = var2 + var4 + var1;
      } else {
         var10000 = var2;
      }

      return var10000;
   }

   <undefinedtype> ll() {
      return this.l;
   }

   static {
      short var6 = 11631;
      String var7 = "劬劳刟剸ඪඐ\u0dccඅ\u0df8ඨඐ\u0dfdඃ\u0dcc൵ൿ☚◎♲☕杌权朾杲柆枾枓柬ṬṥḿṩḠṑṧḛṺḂṢẲ龎\ufae2益頋愈\ufada靖瑱\ufafb猪\ufb0a\ufb0d䲭䲢䳟䲐䳽䲚䲭䳷䲞䳆䱱䱻ꡤꡟꠛꡆ꠵ꡧꡥ꠬ꡖ꣭ꢤꡢꣀꡳ\ua83cꡎꢴ\ua8caꡇ꣩⻌⻗⺳⻎⺝⻏⻍⺔\u2efe⺥⼌⻚⺄⼐⺔⻕⻲⺧⻎⺡⻍⻗⺄⻎⺻⻘⼈⽾폞폄펈폱펌폜폄펹폗편찱찻\ue168\ue178\ue1c0\ue1a6\ue13b\ue17a\ue14a\ue127\ue141\ue10e\ue1b7\ue1bd㈯㈧㉨㈭㉢㈘㇠ㆣ轓辌輈轾輀轒轈輈轰輑轥轩輄轎辬迿蟣蟇螗蟮融蟅蟕螵蟂螼蟢蟁聛聽耽聪者聕聩耘聻而联聐耉聿肯聣\ue8ca\ue8c4\ue8ae\ue8c4\ue898\ue8ef\ue8c4\ue8b5\ue8f7\ue8bc\ue910\ue936쌏쌕썹쌀썝쌍쌕썈쌆썉싀싊";
      char[] var8 = "\u2d6bⵣ\u2d6bⵧⵣⵣⵣ\u2d7b\u2d73ⵣⵣⵧ⵿ⵣ⵿ⵣⵣ".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IIlI = var9;
            IIll = new Object[var9.length];
            int var2 = 1898034143;
            byte[] var0 = "ó\u0001\u0019\u0096\u00adå¢0öóÂx³Âdµ".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IIIl = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IIIl[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            lIl = lIlIII.l(lll('ｇ', -1320942417, (short)'螲'));
            Il = lIlIII.l(lll('｀', 195909524, (short)'멳'));
            lII = lIlIII.l(lll('ａ', -1555945318, (short)3627));
            IIII = lIlIII.l(lll('ｂ', -289967139, (short)'\ued20'));
            III = lIlIII.l(lll('ｃ', -298619562, (short)'釯'));
            Ill = lIlIII.l(lll('ｌ', 121121960, (short)'\ue65c'));
            lll = Duration.ofSeconds(2L);
            llI = HttpClient.newBuilder().connectTimeout(lll).followRedirects(Redirect.NORMAL).build();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 119;
                     break;
                  case 1:
                     var10000 = 125;
                     break;
                  case 2:
                     var10000 = 11;
                     break;
                  case 3:
                     var10000 = 108;
                     break;
                  case 4:
                     var10000 = 36;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static <undefinedtype> III() {
      try {
         Optional var0 = FabricLoader.getInstance().getModContainer(lII.lIlI());
         if (var0.isPresent()) {
            ModMetadata var1 = ((ModContainer)var0.get()).getMetadata();
            return new Record(lIl(var1.getVersion().getFriendlyString()), Il(var1, III.lIlI()), Il(var1, Ill.lIlI())) {
               private final int I;
               private final int l;
               private final String II;

               {
                  this.II = var1;
                  this.I = var2;
                  this.l = var3;
               }

               public String I() {
                  return this.II;
               }

               public int l() {
                  return this.l;
               }

               public int II() {
                  return this.I;
               }
            };
         }
      } catch (RuntimeException var2) {
      }

      return new Record(lIlIII.Il(lll('ｍ', -1434642353, (short)'ꐽ')), 0, 0) {
         private final int I;
         private final int l;
         private final String II;

         {
            this.II = var1;
            this.I = var2;
            this.l = var3;
         }

         public String I() {
            return this.II;
         }

         public int l() {
            return this.l;
         }

         public int II() {
            return this.I;
         }
      };
   }

   // $FF: synthetic method
   private Void IIl(HttpResponse var1, Throwable var2) {
      if (var2 == null && var1 != null && var1.statusCode() >= llI(1153578682, -958227397) && var1.statusCode() < llI(1153578683, -1744427400)) {
         String var3 = (String)var1.body();
         if (var3 != null && !var3.isBlank() && var3.length() <= llI(1153578680, -1022359777)) {
            try {
               <undefinedtype> var4 = lII(var3);
               this.l = null.II(this.I, var4, IlI(this.I, var4));
            } catch (RuntimeException var5) {
               this.l = null.l(this.I);
            }

            return null;
         } else {
            this.l = null.l(this.I);
            return null;
         }
      } else {
         this.l = null.l(this.I);
         return null;
      }
   }

   public llllIIll() {
      this.l = null.I(this.I);
   }

   static boolean IlI(Object var0, Object var1) {
      if (var0 != null && var1 != null) {
         String var2 = var1.II();
         if (var2 != null && !var2.isBlank() && !IIII.IlII(var2.trim())) {
            return false;
         } else if (var1.l() > var0.II()) {
            return true;
         } else {
            return var1.l() == var0.II() && var1.lI() > var0.l();
         }
      } else {
         return false;
      }
   }

   private static int Ill(JsonObject var0, String var1, int var2) {
      JsonElement var3 = var0 == null ? null : var0.get(var1);
      if (var3 != null && !var3.isJsonNull()) {
         try {
            return var3.getAsInt();
         } catch (RuntimeException var7) {
            try {
               return Integer.parseInt(var3.getAsString().trim());
            } catch (RuntimeException var6) {
               return var2;
            }
         }
      } else {
         return var2;
      }
   }

   static <undefinedtype> lII(String var0) {
      JsonObject var1 = JsonParser.parseString(var0).getAsJsonObject();
      return new Record(II(var1, lIlIII.Il(lll('ｎ', 181164273, (short)12802))), Ill(var1, lIlIII.Il(lll('ｏ', -949125164, (short)'꽻')), -1), Ill(var1, lIlIII.Il(lll('ｈ', 1318873808, (short)'鱪')), 0), II(var1, lIlIII.Il(lll('ｉ', 1592527391, (short)'蒯'))), II(var1, lIlIII.Il(lll('ｊ', -350737104, (short)12513))), II(var1, lIlIII.Il(lll('ｋ', -471182645, (short)'킀')))) {
         private final int I;
         private final String l;
         private final String II;
         private final int Il;
         private final String lI;
         private final String ll;

         {
            this.lI = var1;
            this.I = var2;
            this.Il = var3;
            this.ll = var4;
            this.II = var5;
            this.l = var6;
         }

         public String I() {
            return this.II;
         }

         public int l() {
            return this.I;
         }

         public String II() {
            return this.ll;
         }

         public String Il() {
            return this.l;
         }

         public int lI() {
            return this.Il;
         }

         public String ll() {
            return this.lI;
         }
      };
   }

   private static String lIl(String var0) {
      if (var0 != null && !var0.isBlank()) {
         int var1 = var0.indexOf(llI(1153578681, -2044599816));
         return var1 >= 0 ? var0.substring(0, var1) : var0;
      } else {
         return lIlIII.Il(lll('ｔ', 186661245, (short)4625));
      }
   }

   private static int llI(int var0, int var1) {
      return IIIl[var0 ^ 1153578682] ^ var1 ^ var0;
   }

   private static String lll(char var0, int var1, short var2) {
      int var3 = var0 ^ 'ｄ';
      char[] var4 = IIlI[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])IIll[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         IIll[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 20703;
      int var9 = 0;

      do {
         int var10 = var4[var9] ^ '\ue881';
         var10 ^= 53796;
         var10 ^= 42734;
         var10 += 48316;
         var10 ^= 23378;
         var4[var9] = (char)(var10 ^ var8 ^ var2 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
