package x;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_239.class_240;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;

@Environment(EnvType.CLIENT)
public final class IlIlIll {
   private float I = 1.0F;
   private static final float l = 0.08F;
   private static final float II = 1.55F;
   private static final float Il = 0.5F;
   private static final float lI = 0.86F;
   private final <undefinedtype> ll = (<undefinedtype>)(new Object() {
      private float I = 1.0F;
      private float l = 1.0F;
      private float II;
      private float Il = 1.0F;
      private int lI = -1;
      private int ll;
      private float III;

      private void I() {
         this.Il = 1.0F;
         this.l = 1.0F;
         this.I = 1.0F;
         this.III = 0.0F;
         this.II = 0.0F;
         this.lI = -1;
         this.ll = 0;
      }
   });
   private float III;
   private float IIl;
   private static final float IlI = 2.85F;
   private float Ill = 1.0F;
   private float lII;
   private static final float lIl = 0.4F;
   private static final float llI = 0.012F;
   private final <undefinedtype> lll = (<undefinedtype>)(new Object() {
      private static final float I = ((float)Math.PI * 2F);
      private long l;
      private float II = 4.5F;
      private float Il;
      private float lI = 2.7F;
      private float ll;
      private float III;
      private float IIl;
      private float IlI;
      private float Ill;

      void I() {
         this.II(System.nanoTime());
      }

      float[] l(float var1, float var2, float var3, float var4) {
         float var5 = Math.max(0.0F, Math.min(var1, 0.1F));

         for(this.IlI += var5 * this.lI; this.IlI >= 1.0F; this.Ill = ThreadLocalRandom.current().nextFloat() * 2.0F - 1.0F) {
            --this.IlI;
            this.IIl = this.Ill;
         }

         for(this.ll += var5 * this.II; this.ll >= 1.0F; this.III = ThreadLocalRandom.current().nextFloat() * 2.0F - 1.0F) {
            --this.ll;
            this.Il = this.III;
         }

         float var6 = this.IlI;
         float var7 = var6 * var6 * (3.0F - 2.0F * var6);
         float var8 = class_3532.method_16439(var7, this.IIl, this.Ill);
         float var9 = this.ll;
         float var10 = var9 * var9 * (3.0F - 2.0F * var9);
         float var11 = class_3532.method_16439(var10, this.Il, this.III);
         float var12 = class_3532.method_15363(var2 / 120.0F, 0.0F, 1.0F);
         float var13 = 0.06F + 0.94F * var12 * var12;
         float var14 = var3 * var13;
         float var15 = var3 * class_3532.method_15363(var4, 0.0F, 1.0F) * var13;
         return new float[]{var8 * var14, var11 * var15};
      }

      {
         this.II(System.nanoTime());
      }

      void II(long var1) {
         this.l = var1;
         ThreadLocalRandom var3 = ThreadLocalRandom.current();
         this.IlI = var3.nextFloat();
         this.IIl = var3.nextFloat() * 2.0F - 1.0F;
         this.Ill = var3.nextFloat() * 2.0F - 1.0F;
         this.ll = var3.nextFloat();
         this.Il = var3.nextFloat() * 2.0F - 1.0F;
         this.III = var3.nextFloat() * 2.0F - 1.0F;
         this.lI = 2.2F + var3.nextFloat() * 1.6F;
         this.II = 3.5F + var3.nextFloat() * 2.5F;
      }

      float[] Il(float var1, float var2, float var3) {
         return this.l(var1, var2, var3, 0.65F);
      }
   });
   private static final float IIII = 0.88F;
   private static final long IIIl = 100000000L;
   private static final float IIlI = 0.55F;
   private long IIll;
   private static final float IlII = 0.7F;
   private static final float IlIl = 0.3F;
   private static final float IllI = 0.075F;
   private static final float Illl = 36.0F;
   private static final double lIII = 1.0E-6;
   private static final float lIIl = 0.11F;
   private static final float lIlI = 144.0F;
   private float lIll;
   private static final float llII = 1.5F;
   private static final float llIl = 1.35F;
   private float lllI;
   private static final float llll = 0.42F;
   private float IIIII;
   private static final float IIIIl = 3.0F;
   private static final float IIIlI = 1.35F;
   private float IIIll = 1.0F;
   private static final float IIlII = 0.42F;
   private float IIlIl;
   private static final float IIllI = 0.25F;
   private float IIlll;
   private static final float IlIII = 0.46F;
   private float IlIIl;
   private double IlIlI = Double.MAX_VALUE;
   private int IlIll;
   private static final float IllII = 0.18F;
   private static final float IllIl = 0.35F;
   private float IlllI;
   private static final float Illll = 0.06666667F;
   private int lIIII;
   private static final float lIIIl = 3.0F;
   private float lIIlI;
   private static final float lIIll = 0.22F;
   private static final float lIlII = 0.12F;
   private static final float lIlIl = 0.78F;
   private float lIllI;
   private int lIlll = -1;
   private float llIII = 1.0F;
   private static final int llIIl = 6;
   private static final float llIlI = 0.6F;
   private static final float llIll = 1.3F;
   private static final float lllII = 1.4F;
   private static final float lllIl = 2.05F;
   private static final float llllI = 0.12F;
   private static final float lllll = 0.55F;
   private float IIIIII;
   private float IIIIIl;
   private static final float IIIIlI = 0.42F;
   private static final float IIIIll = 0.12F;
   private static final float IIIlII = 0.22F;
   private float IIIlIl;
   private static final float IIIllI = 4.9F;
   private static final float IIIlll = 0.005F;
   private static final float IIlIII = 0.35F;
   private static final float IIlIIl = 0.08F;
   private static final int IIlIlI = 4;
   private static final float IIlIll = 1.15F;
   private int IIllII = -1;
   private static final float IIllIl = 1.08F;
   private float IIlllI;
   private static final float IIllll = 0.78F;
   private static final float IlIIII = 0.18F;
   private float IlIIIl = (float)(Math.random() * 6.2831853);
   private static final float IlIIlI = 0.9F;
   private float IlIIll = Float.NaN;
   private static final float IlIlII = 0.016F;
   private static final float IlIlIl = 6.5F;
   private static final float IlIllI = 1.7F;
   private static final double IlIlll = (double)2.0F;
   private static final float IllIII = 0.55F;
   private float IllIIl;
   private static final float IllIlI = 0.018F;
   private float IllIll;
   private float IlllII;
   private static final float IlllIl = 0.0015F;
   private float IllllI = 1.0F;
   private static final float Illlll = 0.28F;
   private float lIIIII;
   private long lIIIIl;
   private static final float lIIIlI = 0.0125F;
   private float lIIIll;
   private static final float lIIlII = 0.01F;
   private static final float lIIlIl = 4.2F;
   private float lIIllI;
   private float lIIlll;
   private static final float lIlIII = 0.035F;
   private static final float lIlIIl = 0.7F;
   private static final float lIlIlI = 4.5F;
   private float lIlIll;
   private static final float lIllII = 0.55F;
   private static final float lIllIl = 680.0F;
   private static final float lIlllI = 0.14F;
   private static final float lIllll = 0.35F;
   private float llIIII = (float)(Math.random() * 6.2831853);
   private float llIIIl;
   private float llIIlI;
   private float llIIll;
   private float llIlII;
   private static final float llIlIl = 0.18F;
   private static final float llIllI = 1.35F;
   private static final float llIlll = 0.004F;
   private boolean lllIII;
   private static final float lllIIl = 0.0F;
   private float lllIlI;
   private static final float lllIll = 10.5F;
   private float llllII;
   private float llllIl;
   private static final float lllllI = 16.0F;
   private float llllll = 1.0F;
   private static final float IIIIIII = 0.35F;
   private static final float IIIIIIl = 0.0014F;
   private static final float IIIIIlI = 1.4F;
   private static final double IIIIIll = 0.2;
   private static final float IIIIlII = 8.0F;
   private static final float IIIIlIl = 1.2F;
   private static final float IIIIllI = 0.1F;
   private float IIIIlll = 1.0F;
   private float IIIlIII = 1.0F;
   private static final float IIIlIIl = 0.1F;
   private float IIIlIlI = 0.45F;
   private float IIIlIll;
   private static final float IIIllII = 0.22F;
   private static final float IIIllIl = 0.55F;
   private static IlIlIll IIIlllI;
   private static final float IIIllll = 1.35F;
   private static final float IIlIIII = 90.0F;
   private float IIlIIIl;
   private static final float IIlIIlI = 1.02F;
   private boolean IIlIIll;
   private static final float IIlIlII = 1.12F;
   private final <undefinedtype> IIlIlIl = (<undefinedtype>)(new Object() {
      private float I = 1.0F;
      private float l = 1.0F;
      private float II;
      private float Il = 1.0F;
      private int lI = -1;
      private int ll;
      private float III;

      private void I() {
         this.Il = 1.0F;
         this.l = 1.0F;
         this.I = 1.0F;
         this.III = 0.0F;
         this.II = 0.0F;
         this.lI = -1;
         this.ll = 0;
      }
   });
   private static final float IIlIllI = 1.45F;
   private static final float IIlIlll = 0.7F;
   private boolean IIllIII;
   private float IIllIIl;
   private static final float IIllIlI = 1.35F;
   private static final float IIllIll = 0.14F;
   private <undefinedtype> IIlllII;
   private boolean IIlllIl;
   private float IIllllI;
   private float IIlllll = (float)(Math.random() * 6.2831853);
   private <undefinedtype> IlIIIII;
   private static final float IlIIIIl = 0.52F;
   private static final float IlIIIlI = 0.4F;
   private static final float IlIIIll = 0.4F;
   private float IlIIlII = 0.35F;
   private static final float IlIIlIl = 0.26F;
   private float IlIIllI;
   private boolean IlIIlll;
   private boolean IlIlIII;
   private static final float IlIlIIl = 1.3F;
   private static final float IlIlIlI = 0.34F;
   private static final float IlIlIll = 0.14F;
   private float IlIllII;
   private float IlIllIl;
   private static final float IlIlllI = 1.45F;
   private static final float IlIllll = 0.3F;
   private static final float IllIIII = 1.14F;
   private static final float IllIIIl = 0.86F;
   private static final float IllIIlI = 0.01F;
   private static final float IllIIll = 3.25F;
   private static final int IllIlII = 4;
   private float IllIlIl;
   private float IllIllI = (float)(Math.random() * 6.2831853);
   private static final float IllIlll = 0.05F;
   private float IlllIII;
   private static final float IlllIIl = 0.6F;
   private static final float IlllIlI = 0.8F;
   private static final float IlllIll = 14.0F;
   private static final float IllllII = 0.22F;
   private float IllllIl = 1.0F;
   private static final float IlllllI = 0.68F;
   private static final float Illllll = 0.12F;
   private float lIIIIII;
   private int lIIIIIl = -1;
   private static final float lIIIIlI = 0.18F;
   private static final float lIIIIll = 0.6F;
   private static final float lIIIlII = 4.0F;
   private static final float lIIIlIl = 0.016666668F;
   private float lIIIllI;
   private static final float lIIIlll = 60.0F;
   private static final float lIIlIII = 0.08F;
   private float lIIlIIl;
   private static final float lIIlIlI = 1.45F;
   private static final float lIIlIll = 0.012F;
   private static final float lIIllII = 0.18F;
   private static final float lIIllIl = 0.07F;
   private float lIIlllI;
   private static final float lIIllll = 0.32F;
   private static final float lIlIIII = 0.45F;
   private static final float lIlIIIl = 1.1F;
   private static final float lIlIIlI = -90.0F;
   private float lIlIIll;
   private static final float lIlIlII = 0.58F;
   private static final float lIlIlIl = 0.19F;
   private static final float lIlIllI = 1.8F;
   private int lIlIlll = -1;
   private long lIllIII;
   private static final float lIllIIl = 0.02F;
   private static final float lIllIlI = 0.028F;
   private static final float lIllIll = 0.04F;
   private static final float lIlllII = 0.12F;
   private static final float lIlllIl = 0.82F;
   private static final float lIllllI = 0.42F;
   private static final float lIlllll = 0.82F;
   private static final float llIIIII = 0.92F;
   private static final float llIIIIl = 0.4F;
   private float llIIIlI;
   private static final float llIIIll = 0.82F;
   private static final float llIIlII = 500.0F;
   private final <undefinedtype> llIIlIl = (<undefinedtype>)(new Object() {
      private float I = 1.0F;
      private float l = 1.0F;
      private float II;
      private float Il = 1.0F;
      private int lI = -1;
      private int ll;
      private float III;

      private void I() {
         this.Il = 1.0F;
         this.l = 1.0F;
         this.I = 1.0F;
         this.III = 0.0F;
         this.II = 0.0F;
         this.lI = -1;
         this.ll = 0;
      }
   });
   private float llIIllI;
   private float llIIlll;
   private static final float llIlIII = 3.0F;
   private class_243 llIlIIl;
   private static final float llIlIlI = 120.0F;
   private static final float llIlIll = 0.18F;
   private static final float llIllII = 180.0F;
   private float llIllIl;
   private int llIlllI = -1;
   private static final float llIllll = 0.1F;
   private static final float lllIIII = 0.16F;
   private int lllIIIl;
   private static final float lllIIlI = 0.25F;
   private static final float lllIIll = 0.075F;
   private float lllIlII;
   private static final float lllIlIl = 0.36F;
   private static final float lllIllI = 0.06F;
   private float lllIlll;
   private float llllIII;
   private static final float llllIIl = 0.024F;
   private float llllIlI;
   private static final float llllIll = 2.3F;
   private static final float lllllII = 0.55F;
   private static final int lllllIl = 2;
   private int llllllI = -1;
   private static final float lllllll = 0.9F;
   private static final float IIIIIIII = 0.3F;
   private static final float IIIIIIIl = 0.18F;
   private static final float IIIIIIlI = 420.0F;
   private static final float IIIIIIll = 0.24F;
   private static final float IIIIIlII = 2.5F;
   private float IIIIIlIl;
   private static final long IIIIIllI = 150000000L;
   private static final float IIIIIlll = 2.15F;
   private static final float IIIIlIII = 24.0F;
   private float IIIIlIIl;
   private float IIIIlIlI = (float)(Math.random() * 6.2831853);
   private float IIIIlIll;
   private float IIIIllII;
   private float IIIIllIl;
   private float IIIIlllI;
   private float IIIIllll = 1.0F;
   private static final float IIIlIIII = 0.72F;
   private static final float IIIlIIIl = 0.82F;
   private static final float IIIlIIlI = 20.0F;
   private static final float IIIlIIll = 0.46F;
   private float IIIlIlII = (float)(Math.random() * 6.2831853);
   private static final float IIIlIlIl = 3.8F;
   private static final float IIIlIllI = 1.7F;
   private long IIIlIlll;
   private static final float IIIllIII = 0.04F;
   private static final float IIIllIIl = 0.28F;
   private static final float IIIllIlI = 0.0015F;
   private static final int[] IIIllIll;

   void I(float var1, float var2) {
      this.IlIIlll = true;
      this.IIIIllIl = var1;
      this.IIIIIl = 0.0F;
      this.llIllIl = this.IlIIll(var1, var2);
      this.lIlIIll = 0.0F;
      ThreadLocalRandom var3 = ThreadLocalRandom.current();
      this.llllII = 0.18F + var3.nextFloat() * 0.099999994F;
      this.llllIlI = 0.55F + var3.nextFloat() * 0.14999998F;
      this.lllI = 0.01F + var3.nextFloat() * 0.24F;
   }

   private int l(float var1, float var2, float var3, int var4, boolean var5) {
      if (Math.abs(var3) <= 0.01F) {
         return 0;
      } else {
         float var6 = var5 ? class_3532.method_15393(var1 - var2) : var1 - var2;
         return Math.abs(var6) >= 0.8F && Math.signum(var6) != Math.signum(var3) ? 4 : Math.max(0, var4 - 1);
      }
   }

   private <undefinedtype> II(Object var1, float var2, float var3, float var4, float var5, boolean var6, float var7, float var8, float var9, boolean var10, float var11, boolean var12) {
      float var13 = this.Il(var1, var8, var9, !var10);
      float var14 = this.llIlll(var1, var5, var8, var9);
      if (var12) {
         float var15 = (float)lIlllllI.lI((double)var11);
         float var16 = var1.Ill().I();
         var13 *= 0.9F + var16 * 0.35F + (1.0F - var15) * 0.15F;
         var14 *= 0.85F - var16 * 0.15F + var15 * 0.3F;
         if (this.IIlII(var1)) {
            var13 *= 0.3F;
            var14 *= 4.2F;
         }
      } else {
         float var19 = var1.Ill().I();
         var13 *= 0.85F + var19 * 0.3F;
         var14 *= 0.9F - var19 * 0.1F;
      }

      if (var1.ll() > 1.0F && var11 < 3.0F) {
         float var20 = class_3532.method_15363(var11 / 3.0F, 0.35F, 1.0F);
         var14 *= var20;
      }

      float var21 = class_3532.method_15363(var7, 0.0033333334F, 0.055555556F);
      if (var6) {
         return new Record(var2, this.lIlIII(var4, 0.0F, var14 * var21 * 1.25F)) {
            private final float I;
            private final float l;

            private {
               this.I = var1;
               this.l = var2;
            }

            public float I() {
               return this.l;
            }

            public float l() {
               return this.I;
            }
         };
      } else {
         return var10 ? this.llll(var2, var3, var4, var13, var14, var21) : this.llIl(var2, this.IIlllI(var3), var4, var13, var14, var21);
      }
   }

   private float Il(Object var1, float var2, float var3, boolean var4) {
      float var5 = var1.Ill().I();
      float var6 = 0.035F + var5 * 0.145F - var2 * 0.02F;
      float var7 = class_3532.method_15363(var6 * class_3532.method_15363(2.0F - var3, 0.9F, 1.1F), 0.03F, 0.22F);
      float var8 = var4 ? Math.abs(this.lIIIII) : Math.abs(this.IIlll);
      float var9 = var4 ? 0.35F : 0.12F;
      if (this.ll(var1)) {
         var9 *= 0.78F;
      }

      float var10 = class_3532.method_15363(var8 / 60.0F, 0.0F, 1.0F);
      var7 *= 1.0F + var9 * var10 * 0.3F;
      if (var1.l() == null.I) {
         float var11 = class_3532.method_15363(var1.lI() / 100.0F, 0.0F, 1.0F);
         float var12 = 1.0F + (1.0F - var11) * 2.5F;
         var7 *= var12;
      }

      float var15 = Math.max(1.0F, var1.ll());
      float var16 = class_3532.method_15363(0.015F / var15, 0.003F, 0.025F);
      if (this.ll(var1)) {
         var7 *= var1.IlI().IlII();
         return class_3532.method_15363(var7 / var15, var16, 0.25F);
      } else {
         return class_3532.method_15363(var7 / var15, var16, 0.28F);
      }
   }

   public <undefinedtype> lI(class_310 var1, class_1309 var2, Object var3, boolean var4, class_243 var5) {
      if (var1 != null && var1.field_1724 != null && var2 != null && var3 != null && lIlIll(var5)) {
         if (var2 != var1.field_1724 && var2.method_5805() && !var2.method_31481() && !var2.method_5767() && !x.IlIII.l(var2)) {
            class_243 var6 = var1.field_1724.method_33571();
            class_243 var7 = this.IIlIlII(var1);
            return lIlIll(var6) && lIlIll(var7) ? this.IIIIlll(var1, var2, var3, var4, var6, var7, var5) : null;
         } else {
            return null;
         }
      } else {
         return null;
      }
   }

   private boolean ll(Object var1) {
      return var1.III() == null.I;
   }

   private float III(class_243 var1) {
      return var1 != null && var1.field_1351 > (double)0.0F ? -90.0F : 90.0F;
   }

   static float IIl(float var0, float var1, float var2, float var3) {
      if (!Float.isFinite(var0) || !Float.isFinite(var1) || Math.abs(var0) <= 0.0015F || var1 != 0.0F && Math.signum(var1) != Math.signum(var0)) {
         return 0.0F;
      } else {
         float var4 = class_3532.method_15363(var2, 0.0033333334F, 0.055555556F);
         float var5 = Math.max(Math.max(var3, 0.0F), 180.0F * var4);
         return class_3532.method_15363(var1, -var5, var5);
      }
   }

   private float IlI(long var1) {
      if (this.lIllIII == 0L) {
         return 0.05F;
      } else {
         float var3 = (float)(var1 - this.lIllIII) / 1.0E9F;
         return class_3532.method_15363(var3, 0.0033333334F, 0.055555556F);
      }
   }

   private void Ill(class_310 var1, Object var2, Object var3, float var4) {
      <undefinedtype> var5 = var2.Ill();
      float[] var6 = var2.lII() ? x.IlIlIl.lllII(var1) : null;
      float var7 = var6 == null ? var1.field_1724.method_36454() : var6[0];
      float var8 = this.IIlllI(var6 == null ? var1.field_1724.method_36455() : var6[1]);
      <undefinedtype> var9 = this.IlIIlI(var1, var2, var3, var7, var8, var4);
      float var10 = var9.I();
      float var11 = this.IIIIIll(var5, var8, var9.l());
      float var12 = class_3532.method_15393(var10 - var7);
      float var13 = var11 - var8;
      float var14 = (float)Math.hypot((double)var12, (double)var13);
      <undefinedtype> var15 = this.IIIIll(var5.II(), var14, var4);
      if (var15.l()) {
         var10 += var15.I();
         var11 = this.IIlllI(var11 + var15.II());
      }

      var11 = this.IIIIIll(var5, var8, var11);
      var12 = class_3532.method_15393(var10 - var7);
      var13 = var11 - var8;
      var14 = (float)Math.hypot((double)var12, (double)var13);
      this.lIlI();
      this.lIII(var4);
      if (var5.IIl() > 0.0F && this.llIIIl()) {
         this.llIIl();
         this.IIIIIl();
         this.llllII(var7, var8);
      } else if (var14 <= 0.01F) {
         this.llIIl();
         this.IIIIIl();
         this.llllII(var7, var8);
      } else {
         this.IIIIlIl(var2, var7, var8, var12, var13);
         boolean var16 = this.IlIll > 0;
         boolean var17 = this.lIIII > 0;
         if (var16 && var17) {
            this.llIIl();
            this.IIIIIl();
            this.llllII(var7, var8);
         } else {
            float var18 = (float)lIlllllI.lI((double)var14);
            boolean var19 = var2.ll() > 1.0F;
            float var20 = var19 ? 0.0F : (this.ll(var2) ? var2.IlI().Ill() * 0.25F : var5.lI());
            float var21 = var10;
            float var22 = var11;
            if (var20 > 0.0F && var14 > 0.15F) {
               float var23 = (float)Math.hypot((double)this.lIIIII, (double)this.IIlll);
               float var24 = class_3532.method_15363(var23 / 10.0F, 0.35F, 1.6F);
               float var25 = class_3532.method_15363(var14 / 4.0F, 0.25F, 1.25F);
               float var26 = var12 * (0.2F + 0.8F * var20) * var24 * var25;
               float var27 = var13 * (0.15F + 0.6F * var20) * var24 * var25;
               var21 = class_3532.method_15393(var10 + var26);
               var22 = this.IIlllI(var11 + var27);
            }

            <undefinedtype> var44 = this.II(var2, var7, var21, this.lIIIII, this.IIIII(var2), var16, var4, var18, 1.0F, true, var14, true);
            Object var45 = !(var5.IlI() <= 0.0F) && var13 != 0.0F ? this.II(var2, var8, var22, this.IIlll, this.IllIl(var2) * var5.IlI(), var17, var4, var18, 1.0F, false, var14, true) : new Record(var8, 0.0F) {
               private final float I;
               private final float l;

               private {
                  this.I = var1;
                  this.l = var2;
               }

               public float I() {
                  return this.l;
               }

               public float l() {
                  return this.I;
               }
            };
            float var46 = class_3532.method_15393(var44.l() - var7);
            float var50 = ((<undefinedtype>)var45).l() - var8;
            this.lIIIII = var44.I();
            this.IIlll = ((<undefinedtype>)var45).I();
            float var54 = (float)Math.hypot((double)var46, (double)var50);
            <undefinedtype> var28 = this.lIIIlI(var2, var46, var50, var12, var13, var14, var54, var18, true);
            var46 = var28.I();
            var50 = var28.l();
            if (var20 > 0.0F && var14 > 0.15F) {
               float var29 = var20 * class_3532.method_15363(var14 / 4.0F, 0.15F, 1.0F);
               float var30 = Math.signum(var12) * Math.min(Math.abs(var12) * 0.3F, 3.0F) * var29;
               float var31 = Math.signum(var13) * Math.min(Math.abs(var13) * 0.2F, 1.8F) * var29;
               var46 += var30 * class_3532.method_15363(var4 * 30.0F, 0.3F, 1.5F);
               var50 += var31 * class_3532.method_15363(var4 * 30.0F, 0.3F, 1.5F);
            }

            if (var5.III() > 0.0F) {
               float var55 = (float)Math.hypot((double)this.lIIIII, (double)this.IIlll) * 20.0F;
               float[] var57 = this.lll.l(var4, var55, 0.045F * var5.III(), 1.0F);
               var46 += var57[0];
               var50 += var57[1];
            }

            float var56 = this.IIlIlll(var1);
            float var58 = class_3532.method_15363(var4 * 60.0F, 0.25F, 3.0F);
            float var59 = Math.max(var56, (0.35F + (1.0F - var5.I()) * 0.45F + var20 * 0.4F) * var58);
            if (var14 < 3.0F) {
               float var32 = class_3532.method_15363(var14 / 3.0F, 0.0F, 1.0F);
               this.lllIlII *= var32;
               this.IIIIlIIl *= var32;
               this.lIIIII *= var32;
               this.IIlll *= var32;
            }

            if (this.IIlII(var2)) {
               var59 *= 3.8F;
            }

            float var60 = var46 - this.lllIlII;
            float var33 = Math.abs(var60) <= 1.0E-5F ? var60 : (float)((double)var59 * Math.tanh((double)(var60 / var59)));
            var46 = this.lllIlII + var33;
            if (var5.IlI() <= 0.0F) {
               this.IIIIlIIl = 0.0F;
            }

            float var34 = var59 * Math.max(0.2F, var5.IlI());
            float var35 = var50 - this.IIIIlIIl;
            float var36 = Math.abs(var35) <= 1.0E-5F ? var35 : (float)((double)var34 * Math.tanh((double)(var35 / var34)));
            var50 = this.IIIIlIIl + var36;
            if (Math.abs(var12) < 3.0F && Math.signum(var46) == Math.signum(var12) && Math.abs(var46) > Math.abs(var12)) {
               var46 = var12;
            }

            if (Math.abs(var13) < 3.0F && Math.signum(var50) == Math.signum(var13) && Math.abs(var50) > Math.abs(var13)) {
               var50 = var13;
            }

            if (var2.Il()) {
               var50 = this.lllIlI(var13, var50, var4, var56);
            }

            var46 = this.lIIIIl(var46, var56, true);
            var50 = this.lIIIIl(var50, var56, false);
            if (var2.Il()) {
               var50 = this.lllIlI(var13, var50, var4, var56);
            }

            this.lllIlII = var46;
            this.IIIIlIIl = var50;
            if (Math.abs(var46) <= 0.01F && Math.abs(var50) <= 0.01F) {
               this.llllII(var7, var8);
            } else {
               float var37 = var7 + var46;
               float var38 = this.IIlllI(var8 + var50);
               boolean var39 = !var2.lII() || this.lIIIll(var1, var3, var37, var38);
               if (!var2.lII()) {
                  IllllIlI.IIIlIII(var1, var37, var38);
               }

               if (!var39) {
                  this.llIIl();
                  this.IIIIIl();
                  this.llllII(var7, var8);
               } else {
                  this.llllII(var37, var38);
               }
            }
         }
      }
   }

   private class_243 lII(class_310 var1, class_243 var2, class_243 var3, class_1309 var4, class_238 var5, double var6, float var8) {
      if (var1 != null && var1.field_1687 != null && var2 != null && var3 != null && var4 != null && var5 != null) {
         double var9 = var6 * var6;
         class_243 var11 = null;
         class_243 var12 = null;
         double var13 = Double.POSITIVE_INFINITY;
         double var15 = Double.NEGATIVE_INFINITY;

         for(class_243 var18 : this.lIllll(var2, var5)) {
            if (this.lIlIlI(var1, var2, var3, var18, var9, var8)) {
               double var19 = var2.method_1025(var18);
               if (var19 < var13) {
                  var13 = var19;
                  var11 = var18;
               }

               if (var19 > var15) {
                  var15 = var19;
                  var12 = var18;
               }
            }
         }

         if (!lIlIll(var11)) {
            return null;
         } else if (!lIlIll(var12)) {
            return var11;
         } else {
            class_243 var21 = var11.method_35590(var12, (double)0.5F);
            class_243 var22 = this.IIIll(var11.method_35590(var21, (double)0.5F), var5);
            if (this.lIlIlI(var1, var2, var3, var22, var9, var8)) {
               return var22;
            } else if (this.lIlIlI(var1, var2, var3, var21, var9, var8)) {
               return this.IIIll(var21, var5);
            } else {
               return var11;
            }
         }
      } else {
         return null;
      }
   }

   private float lIl(float var1) {
      float var2 = class_3532.method_15363(var1, 1.0F, 300.0F);
      return class_3532.method_15363((var2 - 1.0F) / 299.0F, 0.0F, 1.0F);
   }

   private void llI(class_310 var1, Object var2, boolean var3, Object var4, long var5, boolean var7) {
      if (this.IIll == 0L) {
         this.IIll = var5;
         this.IIllIIl = 0.0F;
         this.IIIlIIl(var1, var2, var3, var4, 0.016666668F, var5, var7);
      } else {
         float var8 = class_3532.method_15363((float)(var5 - this.IIll) / 1.0E9F, 0.0F, 0.2F);
         this.IIll = var5;
         this.IIllIIl = Math.min(this.IIllIIl + var8, 0.06666667F);

         int var9;
         for(var9 = 0; this.IIllIIl >= 0.016666668F && var9 < 4; ++var9) {
            this.IIIlIIl(var1, var2, var3, var4, 0.016666668F, var5, var7);
            this.IIllIIl -= 0.016666668F;
         }

         if (var9 == 0 && this.IIllIIl > 0.0F) {
            float var10 = class_3532.method_15363(this.IIllIIl, 0.0033333334F, 0.016666668F);
            this.IIllIIl = 0.0F;
            this.IIIlIIl(var1, var2, var3, var4, var10, var5, var7);
         }

      }
   }

   private float lll(Object var1, Object var2, ThreadLocalRandom var3) {
      if (!this.ll(var1)) {
         return 0.06F + var3.nextFloat() * 0.105F;
      } else {
         return var2.lI() ? 0.01F + var3.nextFloat() * 0.026F : 0.014F + var3.nextFloat() * 0.038F;
      }
   }

   private static float IIII(float var0, float var1, float var2) {
      float var3 = class_3532.method_15363((var2 - var0) / (var1 - var0), 0.0F, 1.0F);
      return var3 * var3 * (3.0F - 2.0F * var3);
   }

   private static int IIIl(class_243 var0) {
      int var1 = (int)Math.round(var0.field_1352);
      int var2 = (int)Math.round(var0.field_1351);
      int var3 = (int)Math.round(var0.field_1350);
      return var1 * IIllIII(-1986517615, 649109560) ^ var2 * IIllIII(-1986517616, 1055647339) ^ var3 * IIllIII(-1986517613, 386165881);
   }

   private float IIlI(Object var1, float var2, boolean var3) {
      float var4 = Math.abs(var2);
      if (var4 <= 1.0E-4F) {
         return 0.0F;
      } else {
         ThreadLocalRandom var5 = ThreadLocalRandom.current();
         float var6 = (var5.nextFloat() - 0.5F) * 2.0F;
         float var7 = Math.min(var4 * 0.018F, 0.035F);
         if (var3) {
            var7 *= 0.35F;
         } else {
            var7 *= var1.IlI().IlI();
         }

         return var6 * var7;
      }
   }

   <undefinedtype> IIll(class_310 var1, class_1309 var2, Object var3, boolean var4, boolean var5) {
      return var1 != null && var1.field_1724 != null ? this.lIIII(var1, var2, var3, var4, var5, var1.field_1724.method_33571(), this.IIlIlII(var1)) : null;
   }

   private void IlII() {
      this.lllIIIl = 0;
      this.IIIII = 0.0F;
      this.IlIllIl = 0.0F;
      this.IIIIllII = 0.0F;
   }

   public float IlIl(class_310 var1, class_243 var2, float var3) {
      return this.IIIllII(var1, var2, null.IIl(var3));
   }

   private void IllI(class_310 var1, Object var2, Object var3, float var4, boolean var5) {
      <undefinedtype> var6 = var2.Ill();
      if (var3.IIl()) {
         this.Ill(var1, var2, var3, var4);
      } else {
         float[] var7 = var2.lII() ? x.IlIlIl.lllII(var1) : null;
         float var8 = var7 == null ? var1.field_1724.method_36454() : var7[0];
         float var9 = this.IIlllI(var7 == null ? var1.field_1724.method_36455() : var7[1]);
         <undefinedtype> var10 = this.IlIIlI(var1, var2, var3, var8, var9, var4);
         float var11 = var10.I();
         float var12 = this.IIIIIll(var6, var9, var10.l());
         float var13 = class_3532.method_15393(var11 - var8);
         float var14 = var12 - var9;
         float var15 = (float)Math.hypot((double)var13, (double)var14);
         if (var15 <= 0.01F) {
            this.llIIl();
            this.lIlI();
            this.lll.I();
            this.llllII(var8, var9);
         } else if (this.IlIIII(var3, var15)) {
            this.llIIl();
            this.lIlI();
            this.lll.I();
            this.llllII(var8, var9);
         } else {
            <undefinedtype> var16 = var2.IlI();
            <undefinedtype> var17 = this.IllllI(var2, var3, var15, var4, var5);
            if (var17.l()) {
               var11 += var17.I();
               var12 = this.IIlllI(var12 + var17.II());
            }

            float var18 = class_3532.method_15393(var11 - var8);
            float var19 = var12 - var9;
            float var20 = (float)Math.hypot((double)var18, (double)var19);
            <undefinedtype> var21 = this.IIIIIII(var2, var3, var20, var4, var5);
            if (var21.l()) {
               var11 += var21.I();
               var12 = this.IIlllI(var12 + var21.II());
               var18 = class_3532.method_15393(var11 - var8);
               var19 = var12 - var9;
               var20 = (float)Math.hypot((double)var18, (double)var19);
            }

            <undefinedtype> var22 = this.IlIlI(var2, var3, var20, var4, var5);
            if (var22.l()) {
               var11 += var22.I();
               var12 = this.IIlllI(var12 + var22.II());
               var18 = class_3532.method_15393(var11 - var8);
               var19 = var12 - var9;
               var20 = (float)Math.hypot((double)var18, (double)var19);
            }

            this.lllIII(var2, var3, var20);
            <undefinedtype> var23 = this.IIIllIl(var2, var3, var20);
            if (var23.l()) {
               var11 = var8 + var18 + var23.I();
               var12 = this.IIlllI(var9 + var19 + var23.II());
            }

            var12 = this.IIIIIll(var6, var9, var12);
            var18 = class_3532.method_15393(var11 - var8);
            var19 = var12 - var9;
            var20 = (float)Math.hypot((double)var18, (double)var19);
            this.IIIIlIl(var2, var8, var9, var18, var19);
            float var24 = this.IIIlIlI(this.llIIlIl, var3.l(), IIllIII(-1986517614, -1810055556), var4, var16.lII(), var16.llIl(), var16.II(), var16.IIl());
            float var25 = this.IIIlIlI(this.ll, var3.l(), IIllIII(-1986517611, 1938973509), var4, var16.III(), var16.IIll(), var16.II(), var16.IIl());
            float var26 = this.llllI(var3, var18, var19);
            var26 = class_3532.method_15363(var26 * this.Ill, 0.0F, 1.0F);
            float var27 = this.lIlII(var2, var26, var24);
            float var28 = this.lIlII(var2, var26, var25) * 0.78F;
            if (Math.abs(var18) <= var27 && Math.abs(var19) <= var28 && Math.abs(this.lIIIII) <= 0.011F && Math.abs(this.IIlll) <= 0.011F) {
               this.llIIl();
               this.lIlI();
               this.lll.I();
               this.llllII(var8, var9);
               float var68 = this.Illl(var2) * Math.max(var4, 0.0F) * 0.35F;
               if (!var3.IIl() && !this.IIlllIl && var2.ll() <= 1.0F && ThreadLocalRandom.current().nextFloat() < var68) {
                  ThreadLocalRandom var69 = ThreadLocalRandom.current();
                  this.IIlllIl = true;
                  this.lllIlI = 0.3F + var69.nextFloat() * 0.59999996F;
               }

            } else {
               boolean var29 = this.IlIll > 0;
               boolean var30 = this.lIIII > 0;
               if (var29 && var30) {
                  this.llIIl();
                  this.llllII(var8, var9);
               } else {
                  float var31 = this.IIIII(var2);
                  float var32 = this.IllIl(var2);
                  <undefinedtype> var33 = this.II(var2, var8, var11, this.lIIIII, var31, var29, var4, var26, var24, true, var20, var3.IIl());
                  Object var34 = var19 == 0.0F ? new Record(var9, 0.0F) {
                     private final float I;
                     private final float l;

                     private {
                        this.I = var1;
                        this.l = var2;
                     }

                     public float I() {
                        return this.l;
                     }

                     public float l() {
                        return this.I;
                     }
                  } : this.II(var2, var9, var12, this.IIlll, var32, var30, var4, var26, var25, false, var20, var3.IIl());
                  float var35 = class_3532.method_15393(var33.l() - var8);
                  float var36 = ((<undefinedtype>)var34).l() - var9;
                  this.lIIIII = var33.I();
                  this.IIlll = ((<undefinedtype>)var34).I();
                  float var37 = (float)Math.hypot((double)var35, (double)var36);
                  if (!this.IIlII(var2) && var20 > 1.0E-4F && var37 > 1.0E-4F) {
                     float var38 = class_3532.method_15363(var37 / var20, 0.0F, 1.0F);
                     float var39 = var38 * var38 * (3.0F - 2.0F * var38);
                     float var40 = var39 / Math.max(var38, 1.0E-4F);
                     float var41 = class_3532.method_15363(1.0F + (var40 - 1.0F) * 0.42F, 0.55F, 1.45F);
                     float var42 = 0.22F;
                     if (this.ll(var2)) {
                        var42 *= 0.78F;
                     }

                     float var43 = (float)Math.sin((double)var38 * Math.PI);
                     float var44 = this.IllIIl * var42 * var43;
                     float var45 = var41 * (1.0F - var44 * 0.5F);
                     float var46 = var41 * (1.0F + var44);
                     var35 *= var45;
                     var36 *= var46;
                  }

                  <undefinedtype> var87 = this.lllIll(var2, var35, var36, var20, var4, Math.max(var31, var32));
                  var35 = var87.I();
                  var36 = var87.l();
                  var37 = (float)Math.hypot((double)var35, (double)var36);
                  <undefinedtype> var88 = this.lIIIlI(var2, var35, var36, var18, var19, var20, var37, var26, var3.IIl());
                  var35 = var88.I();
                  var36 = var88.l();
                  boolean var89 = var2.ll() > 1.0F;
                  boolean var90 = var2.l() == null.l;
                  float var91 = var2.Ill().III();
                  float var92 = !var3.IIl() && !var90 ? (var89 ? 0.05F : 0.2F * var91 * class_3532.method_15363(var20 / 6.0F, 0.0F, 1.0F)) : 0.0F;
                  float var93 = this.ll(var2) ? var16.Ill() : var2.Ill().lI();
                  float var94 = !var89 && !var90 ? var93 : 0.0F;
                  if (var94 > 0.0F && var20 > 0.15F) {
                     float var95 = (float)Math.hypot((double)this.lIIIII, (double)this.IIlll);
                     float var47 = class_3532.method_15363(var95 / 10.0F, 0.35F, 1.6F);
                     float var48 = class_3532.method_15363(var20 / 4.0F, 0.25F, 1.25F);
                     float var49 = var94 * var47 * var48;
                     float var50 = Math.signum(var18) * Math.min(Math.abs(var18) * 0.3F, 3.0F) * var49;
                     float var51 = Math.signum(var19) * Math.min(Math.abs(var19) * 0.2F, 1.8F) * var49;
                     var35 += var50 * class_3532.method_15363(var4 * 30.0F, 0.3F, 1.5F);
                     var36 += var51 * class_3532.method_15363(var4 * 30.0F, 0.3F, 1.5F);
                  }

                  ThreadLocalRandom var96 = ThreadLocalRandom.current();
                  float var97 = Math.abs(this.lIIIII);
                  float var98 = Math.abs(this.IIlll);
                  float var99 = var90 ? 0.0F : var16.llI() * var92;
                  float var100 = class_3532.method_15363(var20 / 2.0F, 0.0F, 1.0F);
                  var100 *= var100;
                  float var102 = (0.028F + Math.min(var97 * 0.0014F, 0.06F)) * var99 * var100;
                  float var52 = (0.028F + Math.min(var98 * 0.0014F, 0.06F)) * var99 * var100;
                  float var53 = 0.18F * var99;
                  if (var53 <= 1.0E-6F) {
                     this.IlIllII = 0.0F;
                     this.lII = 0.0F;
                  } else {
                     this.IlIllII = class_3532.method_15363(this.IlIllII * 0.86F + (var96.nextFloat() - 0.5F) * var102, -var53, var53);
                     this.lII = class_3532.method_15363(this.lII * 0.86F + (var96.nextFloat() - 0.5F) * var52, -var53, var53);
                  }

                  if (var96.nextFloat() < 0.55F * var16.IlIl() * var92 * Math.max(var4, 0.0F)) {
                     float var54 = (0.07F + var96.nextFloat() * 0.15F) * var16.llII();
                     float var55 = 0.28800002F * Math.max(var99, var16.llII());
                     if (var96.nextBoolean()) {
                        float var56 = var35 == 0.0F ? (var96.nextBoolean() ? 1.0F : -1.0F) : -Math.signum(var35);
                        this.IlIllII = class_3532.method_15363(this.IlIllII + var56 * var54, -var55, var55);
                     } else {
                        float var105 = var36 == 0.0F ? (var96.nextBoolean() ? 1.0F : -1.0F) : -Math.signum(var36);
                        this.lII = class_3532.method_15363(this.lII + var105 * var54, -var55, var55);
                     }
                  }

                  var35 += this.IlIllII;
                  var36 += this.lII;
                  float var103 = (float)Math.hypot((double)this.lIIIII, (double)this.IIlll) * 20.0F;
                  float var104 = 0.07F * var16.llI() * var100;
                  float[] var106 = this.lll.Il(var4, var103, var104);
                  var35 += var106[0];
                  var36 += var106[1];
                  var35 *= var6.l();
                  var36 *= var6.ll();
                  if (Math.abs(var12 - var9) <= 0.0015F && Math.abs(var36) <= 0.0015F) {
                     var36 = 0.0F;
                     this.IIlll = 0.0F;
                  }

                  if (Math.abs(var35) <= 0.01F && Math.abs(var36) <= 0.01F) {
                     this.llllII(var8, var9);
                  } else {
                     float var57 = this.Illll(var2, var4, var5);
                     var35 *= var57;
                     var36 *= var57;
                     if (this.IIllllI < 0.25F) {
                        this.IIllllI += Math.max(0.0F, Math.min(var4, 0.1F));
                        float var58 = class_3532.method_15363(this.IIllllI / 0.25F, 0.0F, 1.0F);
                        var58 = var58 * var58 * (3.0F - 2.0F * var58);
                        var35 *= var58;
                        var36 *= var58;
                     }

                     if (!var89) {
                        this.lIII(var4);
                        if (this.llIIIl()) {
                           float var108 = class_3532.method_15363(1.0F - this.IlllI / Math.max(0.001F, this.IlllI + var4), 0.05F, 0.25F);
                           var35 *= var108;
                           var36 *= var108;
                        }

                        if (this.lIIIIII > 0.0F && this.lIlIll > 1.0E-4F) {
                           float var109 = class_3532.method_15363(this.lIIIIII / this.lIlIll, 0.0F, 1.0F);
                           float var59 = class_3532.method_15363(1.0F - 0.85F * var109, 0.15F, 1.0F);
                           var35 *= var59;
                           var36 *= var59;
                           this.lIIIIII = Math.max(0.0F, this.lIIIIII - Math.max(0.0F, var4));
                        }
                     }

                     var35 += this.IIlI(var2, var35, var5) * var92;
                     var36 += this.IIlI(var2, var36, var5) * var92;
                     float var110 = this.IIlIlll(var1);
                     var35 = this.lIIIIl(var35, var110, true);
                     var36 = this.lIIIIl(var36, var110, false);
                     float var111 = var8 + var35;
                     float var60 = this.IIlllI(var9 + var36);
                     boolean var61 = !var2.lII() || this.lIIIll(var1, var3, var111, var60);
                     if (!var2.lII()) {
                        IllllIlI.IIIlIII(var1, var111, var60);
                     }

                     if (!var61) {
                        this.llIIl();
                        this.llllII(var8, var9);
                     } else {
                        this.llllII(var111, var60);
                        if (Math.abs(this.IllIIl) > 1.0E-4F) {
                           float var62 = Math.max(0.05F, 0.55F);
                           this.IllIIl *= (float)Math.exp((double)(-Math.max(var4, 0.0F) / var62));
                        }

                     }
                  }
               }
            }
         }
      }
   }

   private float Illl(Object var1) {
      return var1.IlI().lIIl();
   }

   void lIII(float var1) {
      if (this.IIlIIll) {
         this.IlllI -= var1;
         if (this.IlllI <= 0.0F) {
            this.IIlIIll = false;
            this.IlllI = 0.0F;
         }
      }

   }

   private float lIIl(ThreadLocalRandom var1, float var2, float var3) {
      float var4 = var2 + var1.nextFloat() * (var3 - var2);
      return var4 * (var1.nextBoolean() ? 1.0F : -1.0F);
   }

   private void lIlI() {
      this.IlIllII = 0.0F;
      this.lII = 0.0F;
      this.llIIlI = 0.0F;
      this.llllIl = 0.0F;
   }

   private float lIll(Object var1) {
      return this.lIIlll(1.45F, 2.15F, this.lIl(var1.lI()));
   }

   private static float llII(float var0) {
      float var1 = class_3532.method_15363(var0, 1.0F, 300.0F);
      return class_3532.method_15363((var1 - 1.0F) / 299.0F, 0.0F, 1.0F);
   }

   private <undefinedtype> llIl(float var1, float var2, float var3, float var4, float var5, float var6) {
      float var7 = Math.max(0.003F, var4);
      float var8 = 2.0F / var7;
      float var9 = var8 * var6;
      float var10 = 1.0F / (1.0F + var9 + 0.48F * var9 * var9 + 0.235F * var9 * var9 * var9);
      float var11 = var1 - var2;
      float var12 = var2;
      float var13 = var5 * var7;
      var11 = class_3532.method_15363(var11, -var13, var13);
      var2 = var1 - var11;
      float var14 = (var3 + var8 * var11) * var6;
      float var15 = (var3 - var8 * var14) * var10;
      float var16 = var2 + (var11 + var14) * var10;
      boolean var17 = var12 - var1 > 0.0F == var16 > var12;
      if (var17) {
         var16 = var12;
         var15 *= 0.25F;
      }

      return new Record(var16, var15) {
         private final float I;
         private final float l;

         private {
            this.I = var1;
            this.l = var2;
         }

         public float I() {
            return this.l;
         }

         public float l() {
            return this.I;
         }
      };
   }

   private void lllI(class_310 var1, long var2) {
      if (this.IlIIIII != null && this.IIlllII != null && var2 <= this.IIIlIlll) {
         this.llIIlI(var1, this.IlIIIII, true, this.IIlllII, false);
      } else {
         this.lIllI();
      }
   }

   private <undefinedtype> llll(float var1, float var2, float var3, float var4, float var5, float var6) {
      float var7 = class_3532.method_15393(var2 - var1);
      float var8 = var1 + var7;
      return this.llIl(var1, var8, var3, var4, var5, var6);
   }

   private float IIIII(Object var1) {
      float var2 = this.IIlll(var1);
      float var3 = (1.0F + (1.0F - var2) * 1.55F) * 1.45F * this.IIIIIIl(var1) * var1.ll();
      if (this.ll(var1)) {
         var3 *= var1.IlI().lIll();
      }

      return var3;
   }

   private void IIIIl() {
      this.llIIl();
      this.IlIll = 0;
      this.lIIII = 0;
      this.llIlIIl = null;
      this.lIlIlll = -1;
      this.lIllIII = 0L;
      this.lIIIIl = 0L;
      this.IIll = 0L;
      this.IIllIIl = 0.0F;
      this.llIIlIl.I();
      this.ll.I();
      this.IIlIlIl.I();
      this.IIIIIlIl = 0.0F;
      this.IllllI = 1.0F;
      this.IIlllIl = false;
      this.lllIlI = 0.0F;
      this.IIllllI = 0.25F;
      this.lIlI();
      this.IllIIl = 0.0F;
      this.lIIIIII = 0.0F;
      this.lIlIll = 0.0F;
      this.Ill = 1.0F;
      this.IIIIlllI = 0.0F;
      this.IllIlIl = 0.0F;
      this.llllll = 1.0F;
      this.IIIIllll = 1.0F;
      this.IIIIIl();
      this.lIIllI = 0.0F;
      this.lIIlllI = 0.0F;
      this.IIllII = -1;
      this.lIIlIIl = 0.0F;
      this.lIll = 0.0F;
      this.IlllII = 0.0F;
      this.lIIlI = 0.0F;
      this.IIIIlIll = 0.0F;
      this.llIIIl = 0.0F;
      this.lllll();
      this.lIIll();
      this.IIIIlI();
      this.IlII();
      this.lIlll = -1;
      this.IlIlI = Double.MAX_VALUE;
      this.IlllI = 0.0F;
      this.IIlIIll = false;
      this.lll.I();
   }

   private float IIIlI(class_310 var1, class_243 var2, class_243 var3) {
      class_243 var4 = var3.method_1020(var2);
      double var5 = Math.sqrt(var4.field_1352 * var4.field_1352 + var4.field_1350 * var4.field_1350);
      if (var5 <= 1.0E-4) {
         return 0.016F;
      } else {
         float var7 = (float)(Math.toDegrees(Math.atan2(var4.field_1350, var4.field_1352)) - (double)90.0F);
         float var8 = (float)(-Math.toDegrees(Math.atan2(var4.field_1351, var5)));
         float var9 = class_3532.method_15393(var7 - var1.field_1724.method_36454());
         float var10 = var8 - this.IIlllI(var1.field_1724.method_36455());
         float var11 = (float)Math.sqrt((double)(var9 * var9 + var10 * var10));
         float var12 = class_3532.method_15363((var11 - 2.5F) / 11.5F, 0.0F, 1.0F);
         return 0.016F + var12 * 0.084F;
      }
   }

   private class_243 IIIll(class_243 var1, class_238 var2) {
      return var1 != null && var2 != null ? new class_243(class_3532.method_15350(var1.field_1352, var2.field_1323, var2.field_1320), class_3532.method_15350(var1.field_1351, var2.field_1322, var2.field_1325), class_3532.method_15350(var1.field_1350, var2.field_1321, var2.field_1324)) : var1;
   }

   private boolean IIlII(Object var1) {
      return var1 != null && var1.l() == null.l && var1.III() == null.I && var1.Ill().I() <= 1.0E-4F && !var1.lII();
   }

   private class_243 IIlIl(class_243 var1, class_243 var2, class_1309 var3) {
      class_238 var4 = var3.method_5829();
      class_243 var5 = var4.method_1005();
      double var6 = var4.field_1325 - var4.field_1322;
      class_243 var8 = new class_243(var5.field_1352, var4.field_1322, var5.field_1350);
      class_243 var9 = new class_243(var5.field_1352, var4.field_1322 + var6, var5.field_1350);
      return this.IIlIIIl(var1, var8, var9);
   }

   public float IIllI(class_310 var1, class_243 var2, float var3, int var4) {
      return this.lIllIl(var1, var2, null.II(var3), var4);
   }

   private float IIlll(Object var1) {
      if (var1.l() != null.Il && var1.l() != null.l) {
         float var2 = class_3532.method_15363(var1.lI(), 0.0F, 200.0F);
         float var3 = var2 / 100.0F;
         return class_3532.method_15363(1.01F - var3, 0.01F, 1.0F);
      } else {
         return class_3532.method_15363(this.lIIlll(0.14F, 0.01F, this.IIIlII(var1)), 0.01F, 0.14F);
      }
   }

   private static float IlIII(ThreadLocalRandom var0) {
      return (var0.nextFloat() + var0.nextFloat() + var0.nextFloat()) / 1.5F - 1.0F;
   }

   float IlIIl(float var1, float var2) {
      float var3 = IIII(0.0F, 1.0F, var1 / 0.35F);
      float var4 = (float)Math.pow((double)var3, 0.7);
      float var5 = IIII(0.5F, 1.0F, var1);
      float var6 = (float)Math.pow((double)var5, 1.4);
      return var2 * var4 * (1.0F - var6);
   }

   private <undefinedtype> IlIlI(Object var1, Object var2, float var3, float var4, boolean var5) {
      if (this.ll(var1) && var1.l() != null.l && var2 != null && !var2.IIl() && this.lIIIIIl == var2.l() && !(this.IlIIllI <= 1.0E-4F) && !(var3 <= 3.25F)) {
         float var6 = Math.max(0.0F, Math.min(var4, 0.1F));
         this.IllIll = Math.min(this.IlIIllI, this.IllIll + var6);
         float var7 = class_3532.method_15363(this.IllIll / this.IlIIllI, 0.0F, 1.0F);
         if (var7 >= 1.0F) {
            if (!(var3 > 4.15F)) {
               return null.l;
            }

            this.IIIlIl(var2.l(), ThreadLocalRandom.current());
            var7 = 0.0F;
         }

         float var8 = (float)Math.sin((double)var7 * Math.PI);
         float var9 = IIII(3.25F, 24.0F, var3);
         float var10 = var8 * var9;
         if (var5) {
            var10 *= 0.55F;
         }

         return (<undefinedtype>)(var10 <= 1.0E-4F ? null.l : new Record(this.IIlIl * var10, this.IIIlIll * var10) {
            private final float I;
            private static final <undefinedtype> l = new <anonymous constructor>(0.0F, 0.0F);
            private final float II;

            public float I() {
               return this.I;
            }

            private boolean l() {
               return Math.abs(this.I) > 1.0E-4F || Math.abs(this.II) > 1.0E-4F;
            }

            private {
               this.I = var1;
               this.II = var2;
            }

            public float II() {
               return this.II;
            }
         });
      } else {
         return null.l;
      }
   }

   private void IlIll(class_310 var1, Object var2, Object var3, float var4, float var5, float var6) {
      float var7 = var3.I();
      float var8 = this.IIlllI(var3.l());
      float var9 = class_3532.method_15393(var7 - var4);
      float var10 = var8 - var5;
      float var11 = (float)Math.hypot((double)var9, (double)var10);
      float var12 = 0.35F;
      if (var11 <= var12 && Math.abs(this.lIIIII) <= 0.5F && Math.abs(this.IIlll) <= 0.5F) {
         this.llIIl();
         this.llllII(var4, var5);
      } else {
         float var13 = this.IIIII(var2);
         float var14 = 0.06F + 0.04F * class_3532.method_15363(var11 / 15.0F, 0.0F, 1.0F);
         float var15 = var13 * 22.0F;
         float var16 = class_3532.method_15363(var6, 0.0033333334F, 0.055555556F);
         <undefinedtype> var17 = this.llll(var4, var7, this.lIIIII, var14, var15, var16);
         <undefinedtype> var18 = this.IllIII(var5, var8, this.IIlll, var15, var13, var16);
         float var19 = class_3532.method_15393(var17.l() - var4);
         float var20 = var18.l() - var5;
         this.lIIIII = var17.I();
         this.IIlll = var18.I();
         float var21 = this.IIlIlll(var1);
         var19 = this.lIIIIl(var19, var21, true);
         var20 = this.lIIIIl(var20, var21, false);
         if (Math.abs(var19) <= 0.01F && Math.abs(var20) <= 0.01F) {
            this.llllII(var4, var5);
         } else {
            float var22 = var4 + var19;
            float var23 = this.IIlllI(var5 + var20);
            IllllIlI.IIIlIII(var1, var22, var23);
            this.llllII(var22, var23);
         }
      }
   }

   private class_243 IllII(class_243 var1, class_243 var2, float var3, Object var4) {
      <undefinedtype> var5 = var4.IlI();
      float var6 = var5.Illl();
      if (var6 <= 1.0E-6F) {
         return var2;
      } else {
         if (!this.IIllIII) {
            ThreadLocalRandom var7 = ThreadLocalRandom.current();
            this.llIII = var7.nextFloat() * 1.35F + 0.35F;
            this.IIIlIII = var7.nextFloat() * 1.35F + 0.35F;
            this.IIIIlll = var7.nextFloat() * 1.35F + 0.35F;
            this.IIlllI = var7.nextFloat() * ((float)Math.PI * 2F);
            this.llIIllI = var7.nextFloat() * ((float)Math.PI * 2F);
            this.lIIlll = var7.nextFloat() * ((float)Math.PI * 2F);
            this.IIllIII = true;
         }

         float var28 = Math.max(0.0F, Math.min(var3, 0.1F));
         ThreadLocalRandom var8 = ThreadLocalRandom.current();
         float var9 = 1.0F + (var8.nextFloat() - 0.5F) * 0.018F;
         float var10 = 1.0F + (var8.nextFloat() - 0.5F) * 0.018F;
         float var11 = 1.0F + (var8.nextFloat() - 0.5F) * 0.014F;
         float var12 = var5.lIlI();
         this.IllIllI += var28 * this.llIII * var9 * var12 * ((float)Math.PI * 2F);
         this.llIIII += var28 * this.IIIlIII * var10 * var12 * ((float)Math.PI * 2F);
         this.IIIlIlII += var28 * this.IIIIlll * var11 * var12 * ((float)Math.PI * 2F);
         float var13 = (float)(Math.sin((double)(this.IllIllI + this.IIlllI)) * (double)0.5F + Math.sin((double)this.IllIllI * 1.7 + (double)this.llIIllI) * 0.3 + Math.sin((double)this.IIIlIlII * 2.3 + (double)this.lIIlll) * 0.2);
         float var14 = (float)(Math.sin((double)(this.llIIII + this.llIIllI)) * 0.45 + Math.sin((double)this.llIIII * 1.3 + (double)this.IIlllI) * 0.3 + Math.sin((double)this.IIIlIlII * 1.9 + (double)this.lIIlll) * (double)0.25F);
         class_243 var15 = var2.method_1020(var1);
         double var16 = Math.sqrt(var15.field_1352 * var15.field_1352 + var15.field_1350 * var15.field_1350);
         if (var16 <= 1.0E-4) {
            return var2;
         } else {
            double var18 = -var15.field_1350 / var16;
            double var20 = var15.field_1352 / var16;
            double var22 = var18 * (double)var13 * (double)var6;
            double var24 = var20 * (double)var13 * (double)var6;
            double var26 = (double)(var14 * var6);
            return var2.method_1031(var22, var26, var24);
         }
      }
   }

   private float IllIl(Object var1) {
      float var2 = this.IIlll(var1);
      float var3 = (0.74F + (1.0F - var2) * 1.15F) * 1.45F * this.IIIIIIl(var1) * var1.ll();
      if (this.ll(var1)) {
         var3 *= var1.IlI().lIll();
      }

      return var3;
   }

   private double IlllI(class_243 var1, class_243 var2, class_243 var3) {
      class_243 var4 = var3.method_1020(var1);
      double var5 = Math.max((double)0.0F, var4.method_1026(var2));
      class_243 var7 = var1.method_1019(var2.method_1021(var5));
      return var3.method_1025(var7);
   }

   private float Illll(Object var1, float var2, boolean var3) {
      if (!var3 && !(var1.ll() > 1.0F)) {
         float var4 = Math.max(0.0F, Math.min(var2, 0.1F));
         if (this.IIIIIlIl > 0.0F) {
            this.IIIIIlIl -= var4;
            if (this.IIIIIlIl > 0.0F) {
               return this.IllllI;
            }

            this.IIIIIlIl = 0.0F;
            this.IllllI = 1.0F;
         }

         <undefinedtype> var5 = var1.IlI();
         float var6 = 0.82F * var5.IIII() * var4;
         float var7 = var5.I();
         float var8 = var5.ll();
         float var9 = 0.04F * var5.IIIl();
         float var10 = 0.18F * var5.IIIl();
         ThreadLocalRandom var11 = ThreadLocalRandom.current();
         if (var11.nextFloat() < var6) {
            this.IIIIIlIl = var9 + var11.nextFloat() * (var10 - var9);
            this.IllllI = var7 + var11.nextFloat() * (var8 - var7);
            return this.IllllI;
         } else {
            return 1.0F;
         }
      } else {
         this.IIIIIlIl = 0.0F;
         this.IllllI = 1.0F;
         return 1.0F;
      }
   }

   <undefinedtype> lIIII(class_310 var1, class_1309 var2, Object var3, boolean var4, boolean var5, class_243 var6, class_243 var7) {
      if (var1 != null && var1.field_1724 != null && var2 != null && var3 != null && var6 != null && var7 != null) {
         if (var2 != var1.field_1724 && var2.method_5805() && !var2.method_31481() && (var5 || !var2.method_5767())) {
            if (x.IlIII.l(var2)) {
               return null;
            } else {
               double var8 = var7.method_1027();
               if (var8 <= 1.0E-6) {
                  return null;
               } else {
                  var7 = var7.method_1021((double)1.0F / Math.sqrt(var8));
                  if (lIlIll(var6) && lIlIll(var7)) {
                     class_243 var10 = this.lIlllI(var1, var6, var7, var2, var3);
                     return !lIlIll(var10) ? null : this.IIIIlll(var1, var2, var3, var4, var6, var7, var10);
                  } else {
                     return null;
                  }
               }
            }
         } else {
            return null;
         }
      } else {
         return null;
      }
   }

   private boolean lIIIl(class_310 var1, class_1309 var2) {
      if (var1 != null && var1.field_1724 != null && var2 != null) {
         double var3 = var1.field_1724.method_18798().method_37267();
         double var5 = var2.method_18798().method_37267();
         if (Double.isFinite(var3) && Double.isFinite(var5)) {
            return var3 <= (double)0.012F && var5 <= (double)0.012F;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private float lIIlI(float var1, float var2) {
      return (float)Math.hypot((double)var1, (double)var2);
   }

   private void lIIll() {
      this.llIlllI = -1;
      this.llIlII = 0.0F;
      this.llIIIlI = 0.0F;
      this.IIIlIl = 0.0F;
      this.lIIIllI = 0.0F;
      this.IIlIIIl = 0.0F;
      this.III = 0.0F;
      this.llllIII = 0.0F;
      this.lIIIll = 0.0F;
      this.IIl = 0.0F;
      this.llIIll = 0.0F;
      this.lllIlll = 0.0F;
      this.IlIIl = 0.0F;
      this.IlIIll = Float.NaN;
   }

   private float lIlII(Object var1, float var2, float var3) {
      float var4 = this.IIlll(var1);
      return class_3532.method_15363(0.024F + var4 * 0.038F + (1.0F - var3) * 0.09F - var2 * 0.018F, 0.024F, 0.14F);
   }

   private <undefinedtype> lIlIl(float var1, float var2, float var3, float var4, float var5, boolean var6) {
      if (!var6 && !(var4 <= 1.0E-4F) && !(var3 <= 0.01F)) {
         if (this.llIIlI == 0.0F && this.llllIl == 0.0F) {
            float var7 = (float)Math.hypot((double)var1, (double)var2);
            if (var7 <= 0.005F) {
               return new Record(var1, var2) {
                  private final float I;
                  private final float l;

                  private {
                     this.l = var1;
                     this.I = var2;
                  }

                  public float I() {
                     return this.l;
                  }

                  public float l() {
                     return this.I;
                  }
               };
            } else {
               float var8 = IIII(0.9F, 2.3F, var3) * (1.0F - IIII(6.2F, 10.4F, var3));
               float var9 = 1.15F * Math.max(var5, 0.0F) * class_3532.method_15363(var4 * 2.4F, 0.0F, 0.85F) * class_3532.method_15363(0.35F + var8 * 0.4F, 0.35F, 0.75F);
               ThreadLocalRandom var10 = ThreadLocalRandom.current();
               if (var10.nextFloat() >= var9) {
                  return new Record(var1, var2) {
                     private final float I;
                     private final float l;

                     private {
                        this.l = var1;
                        this.I = var2;
                     }

                     public float I() {
                        return this.l;
                     }

                     public float l() {
                        return this.I;
                     }
                  };
               } else {
                  boolean var11 = var8 > 0.55F && var4 > 0.12F && var10.nextFloat() < 0.144F;
                  float var12 = var11 ? 0.52F + var10.nextFloat() * 1.78F : 0.11F + var10.nextFloat() * 0.49F;
                  var12 *= class_3532.method_15363(0.75F + var4 * 2.6F, 0.75F, var11 ? 1.75F : 1.45F);
                  float var13 = var1 * var12;
                  float var14 = var11 ? 0.38F + var10.nextFloat() * 0.24F : 0.78F + var10.nextFloat() * 0.26F;
                  float var15 = var2 * var12 * var14;
                  float var16 = var11 ? 1.06F : 0.82F;
                  this.llIIlI = -var13 * var16;
                  this.llllIl = -var15 * var16;
                  return new Record(var1 + var13, var2 + var15) {
                     private final float I;
                     private final float l;

                     private {
                        this.l = var1;
                        this.I = var2;
                     }

                     public float I() {
                        return this.l;
                     }

                     public float l() {
                        return this.I;
                     }
                  };
               }
            }
         } else {
            var1 += this.llIIlI;
            var2 += this.llllIl;
            this.llIIlI = 0.0F;
            this.llllIl = 0.0F;
            return new Record(var1, var2) {
               private final float I;
               private final float l;

               private {
                  this.l = var1;
                  this.I = var2;
               }

               public float I() {
                  return this.l;
               }

               public float l() {
                  return this.I;
               }
            };
         }
      } else {
         this.llIIlI = 0.0F;
         this.llllIl = 0.0F;
         return new Record(var1, var2) {
            private final float I;
            private final float l;

            private {
               this.l = var1;
               this.I = var2;
            }

            public float I() {
               return this.l;
            }

            public float l() {
               return this.I;
            }
         };
      }
   }

   private void lIllI() {
      this.IlIIIII = null;
      this.IIlllII = null;
      this.IIIlIlll = 0L;
      this.llIIl();
      this.IIIIIl();
      synchronized(IlIlIll.class) {
         if (IIIlllI == this) {
            IIIlllI = null;
         }

      }
   }

   private static float lIlll(float var0, float var1, float var2) {
      return class_3532.method_16439(class_3532.method_15363(var2, 0.0F, 1.0F), var0, var1);
   }

   private void llIII(float var1) {
      float var2 = class_3532.method_15363(Math.max(var1, 0.0F) * 6.5F, 0.0F, 1.0F);
      this.IIIlIl += (0.0F - this.IIIlIl) * var2;
      this.lIIIllI += (0.0F - this.lIIIllI) * var2;
   }

   private void llIIl() {
      this.lIIIII = 0.0F;
      this.IIlll = 0.0F;
   }

   private void llIlI(Object var1, Object var2, long var3) {
      this.IlIIIII = var1;
      this.IIlllII = var2;
      this.IIIlIlll = var3 + 150000000L;
      synchronized(IlIlIll.class) {
         IlIlIll var6 = IIIlllI;
         if (var6 != null && var6 != this) {
            var6.lIllI();
         }

         IIIlllI = this;
      }
   }

   private boolean llIll(class_310 var1, class_243 var2, class_243 var3) {
      class_3965 var4 = var1.field_1687.method_17742(new class_3959(var2, var3, class_3960.field_17558, class_242.field_1348, var1.field_1724));
      return var4 == null || var4.method_17783() != class_240.field_1332;
   }

   class_243 lllII(class_243 var1, class_1309 var2, class_238 var3) {
      if (var2 != null && var1 != null) {
         --this.lllIIIl;
         if (this.lllIIIl <= 0) {
            ThreadLocalRandom var4 = ThreadLocalRandom.current();
            class_238 var5 = var2.method_5829();
            float var6 = (float)((var5.field_1320 - var5.field_1323) * (double)0.5F);
            float var7 = (float)(var5.field_1325 - var5.field_1322);
            this.IIIII = IlIII(var4) * var6 * 0.22F;
            this.IlIllIl = IlIII(var4) * var7 * 0.18F + 0.1F;
            this.IIIIllII = IlIII(var4) * var6 * 0.22F;
            this.lllIIIl = 2 + var4.nextInt(5);
         }

         class_238 var11 = var3 == null ? var2.method_5829() : var3;
         double var12 = class_3532.method_15350(var1.field_1352 + (double)this.IIIII, var11.field_1323, var11.field_1320);
         double var13 = class_3532.method_15350(var1.field_1351 + (double)this.IlIllIl, var11.field_1322, var11.field_1325);
         double var9 = class_3532.method_15350(var1.field_1350 + (double)this.IIIIllII, var11.field_1321, var11.field_1324);
         return new class_243(var12, var13, var9);
      } else {
         return var1;
      }
   }

   public static void lllIl() {
   }

   private float llllI(Object var1, float var2, float var3) {
      float var4 = Math.max(var1.Il(), 1.0F);
      float var5 = class_3532.method_15363(this.lIIlI(var2, var3) / var4, 0.0F, 1.0F);
      return Math.max(var1.IlI(), var5);
   }

   private void lllll() {
      this.lIIIIIl = -1;
      this.IllIll = 0.0F;
      this.IlIIllI = 0.0F;
      this.IIlIl = 0.0F;
      this.IIIlIll = 0.0F;
   }

   private float IIIIII(int var1) {
      return (float)(var1 & IIllIII(-1986517612, 644242900)) / (float)Integer.MAX_VALUE;
   }

   private void IIIIIl() {
      this.lllIlII = 0.0F;
      this.IIIIlIIl = 0.0F;
   }

   void IIIIlI() {
      this.IlIIlll = false;
      this.IIIIIl = 0.0F;
      this.llIllIl = 0.0F;
      this.lIlIIll = 0.0F;
      this.llllllI = -1;
   }

   private <undefinedtype> IIIIll(float var1, float var2, float var3) {
      if (!(var1 <= 0.0F) && !(var2 <= 0.2F)) {
         float var4 = class_3532.method_15363(var3, 0.0F, 0.1F);
         this.llIIlll = this.IIIIllI(this.llIIlll + var4 * this.IIIlIlI * ((float)Math.PI * 2F));
         this.IlllIII = this.IIIIllI(this.IlllIII + var4 * this.IlIIlII * ((float)Math.PI * 2F));
         float var5 = IIII(0.2F, 4.0F, var2);
         float var6 = 0.22F * var1 * var5;
         float var7 = (float)(Math.sin((double)this.llIIlll) + Math.sin((double)(this.llIIlll * 0.47F + 1.3F)) * (double)0.35F);
         float var8 = (float)(Math.sin((double)this.IlllIII) + Math.sin((double)(this.IlllIII * 0.61F + 0.7F)) * (double)0.28F);
         return new Record(var7 * var6, var8 * var6 * 0.72F) {
            private final float I;
            private static final <undefinedtype> l = new <anonymous constructor>(0.0F, 0.0F);
            private final float II;

            public float I() {
               return this.I;
            }

            private boolean l() {
               return Math.abs(this.I) > 1.0E-4F || Math.abs(this.II) > 1.0E-4F;
            }

            private {
               this.I = var1;
               this.II = var2;
            }

            public float II() {
               return this.II;
            }
         };
      } else {
         return null.l;
      }
   }

   private float IIIlII(Object var1) {
      return var1.l() == null.l ? llIlIl(var1.lI()) : this.lIl(var1.lI());
   }

   private void IIIlIl(int var1, ThreadLocalRandom var2) {
      this.lIIIIIl = var1;
      this.IllIll = 0.0F;
      this.IlIIllI = 0.18F + var2.nextFloat() * 0.22F;
      float var3 = 0.18F + var2.nextFloat() * 0.64F;
      float var4 = 0.12F + var2.nextFloat() * 0.22F;
      this.IIlIl = var3 * (var2.nextBoolean() ? 1.0F : -1.0F);
      this.IIIlIll = var3 * var4 * (var2.nextBoolean() ? 1.0F : -1.0F);
   }

   void IIIllI(float var1) {
      if (!(var1 <= 0.0F) && Float.isFinite(var1)) {
         this.IIlIIll = true;
         this.IlllI = var1;
      } else {
         this.IIlIIll = false;
         this.IlllI = 0.0F;
      }
   }

   private void IIIlll() {
      this.IIll = 0L;
      this.IIllIIl = 0.0F;
   }

   private float IIlIII(class_243 var1, class_243 var2) {
      double var3 = var1.method_1033();
      double var5 = var2.method_1033();
      if (!(var3 <= 1.0E-6) && !(var5 <= 1.0E-6)) {
         double var7 = var1.method_1026(var2) / (var3 * var5);
         var7 = class_3532.method_15350(var7, (double)-1.0F, (double)1.0F);
         return (float)Math.toDegrees(Math.acos(var7));
      } else {
         return Float.POSITIVE_INFINITY;
      }
   }

   private float IIlIIl(int var1, int var2, int var3, float var4, float var5) {
      int var6 = this.IIlIIlI(var1 * IIllIII(-1986517609, 1678937016) + var3 * IIllIII(-1986517610, -1572928178) + var2);
      int var7 = Math.floorMod(var6, 3);
      float var8 = this.IIIIII(this.IIlIIlI(var1 * IIllIII(-1986517607, 1902886863) + var3 * IIllIII(-1986517608, 1802193696) + var2 * 3));
      float var9 = this.lIIlll(var4, 0.992F, 0.72F);
      float var10 = this.lIIlll(1.008F, var5, 0.28F);
      float var10000;
      switch (var7) {
         case 0 -> var10000 = this.lIIlll(var4, var9, var8);
         case 1 -> var10000 = this.lIIlll(var10, var5, var8);
         default -> var10000 = this.lIIlll(var9, var10, var8);
      }

      return var10000;
   }

   <undefinedtype> IIlIlI(class_310 var1, class_1309 var2, Object var3, boolean var4) {
      return this.IIll(var1, var2, var3, var4, false);
   }

   boolean IIlIll() {
      return this.IlIIlll && !this.llIIII();
   }

   public void IIllII() {
      this.lIllI();
   }

   public void IIllIl(class_310 var1, Object var2, boolean var3, Object var4, boolean var5) {
      long var6 = System.nanoTime();
      if (var5) {
         if (var6 - this.lIIIIl > 100000000L) {
            this.llI(var1, var2, var3, var4, var6, true);
         }

      } else {
         this.IIIlll();
         if (var6 - this.lIIIIl > 100000000L) {
            this.IIIlIIl(var1, var2, var3, var4, 0.05F, var6, false);
         }
      }
   }

   private float IIlllI(float var1) {
      return class_3532.method_15363(var1, -90.0F, 90.0F);
   }

   private class_243 IIllll(class_243 var1, class_1309 var2) {
      class_238 var3 = var2.method_5829();
      return new class_243(class_3532.method_15350(var1.field_1352, var3.field_1323, var3.field_1320), class_3532.method_15350(var1.field_1351, var3.field_1322, var3.field_1325), class_3532.method_15350(var1.field_1350, var3.field_1321, var3.field_1324));
   }

   private boolean IlIIII(Object var1, float var2) {
      if (var1 != null && !var1.IIl() && !(var2 > 0.42F)) {
         if (!(var1.I() > 0.012F) && !(var1.II() > 0.012F)) {
            return Math.abs(this.lIIIII) <= 0.011F && Math.abs(this.IIlll) <= 0.011F;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   static void IlIIIl(class_310 var0) {
      if (var0 != null && var0.field_1724 != null && var0.field_1687 != null) {
         long var1 = System.nanoTime();
         IlIlIll var3;
         synchronized(IlIlIll.class) {
            var3 = IIIlllI;
         }

         if (var3 != null) {
            var3.lllI(var0, var1);
         }

      }
   }

   private <undefinedtype> IlIIlI(class_310 var1, Object var2, Object var3, float var4, float var5, float var6) {
      class_243 var7 = var1.field_1724.method_33571();
      class_243 var8 = var3.ll();
      if (!lIlIll(var8)) {
         return new Record(var4, this.IIlllI(var5)) {
            private final float I;
            private final float l;

            public float I() {
               return this.l;
            }

            private {
               this.l = var1;
               this.I = var2;
            }

            public float l() {
               return this.I;
            }
         };
      } else {
         if (this.lIlIlll == var3.l() && lIlIll(this.llIlIIl)) {
            if (var2.Il()) {
               float var15 = class_3532.method_15363(var6, 0.0F, 0.1F);
               float var10 = 1.0F - (float)Math.exp((double)(-20.0F * var15));
               this.llIlIIl = this.llIlIIl.method_35590(var8, (double)var10);
            } else {
               this.llIlIIl = var8;
            }

            this.llllIl(var3.l(), var3.Ill());
         } else {
            this.lIlIlll = var3.l();
            this.llIlIIl = var8;
            this.lllIIIl = 0;
            this.IllIIl = 0.0F;
            this.lIlIll = 0.0F;
            this.lIIIIII = 0.0F;
            this.IIIllI(var2.Ill().IIl());
            this.Ill = 1.0F;
            this.IIIIlllI = 0.0F;
            this.IllIlIl = 0.0F;
            ThreadLocalRandom var9 = ThreadLocalRandom.current();
            this.llllll = var9.nextBoolean() ? 1.0F : -1.0F;
            this.IIIIllll = 0.28F + var9.nextFloat() * 0.24F;
            this.llIIlll = var9.nextFloat() * ((float)Math.PI * 2F);
            this.IlllIII = var9.nextFloat() * ((float)Math.PI * 2F);
            this.IIIlIlI = 0.32F + var9.nextFloat() * 0.26F;
            this.IlIIlII = 0.24F + var9.nextFloat() * 0.22F;
            this.lll.I();
            this.lllll();
            this.llllIl(var3.l(), var3.Ill());
         }

         class_243 var16 = var3.IIl() ? this.llIlIIl : this.IllII(var7, this.llIlIIl, var6, var2);
         class_243 var17 = var16.method_1020(var7);
         double var11 = Math.sqrt(var17.field_1352 * var17.field_1352 + var17.field_1350 * var17.field_1350);
         if (var2.Il() && var11 < 0.2) {
            this.llIIl();
            this.IIIIIl();
            return new Record(var4, this.IIlllI(var5)) {
               private final float I;
               private final float l;

               public float I() {
                  return this.l;
               }

               private {
                  this.l = var1;
                  this.I = var2;
               }

               public float l() {
                  return this.I;
               }
            };
         } else if (var11 <= 1.0E-4) {
            return var17.method_1027() <= 1.0E-8 ? new Record(var4, this.IIlllI(var5)) {
               private final float I;
               private final float l;

               public float I() {
                  return this.l;
               }

               private {
                  this.l = var1;
                  this.I = var2;
               }

               public float l() {
                  return this.I;
               }
            } : new Record(var4, this.III(var17)) {
               private final float I;
               private final float l;

               public float I() {
                  return this.l;
               }

               private {
                  this.l = var1;
                  this.I = var2;
               }

               public float l() {
                  return this.I;
               }
            };
         } else {
            float var13 = (float)(Math.toDegrees(Math.atan2(var17.field_1350, var17.field_1352)) - (double)90.0F);
            float var14 = this.IIlllI((float)(-Math.toDegrees(Math.atan2(var17.field_1351, var11))));
            return new Record(var13, var14) {
               private final float I;
               private final float l;

               public float I() {
                  return this.l;
               }

               private {
                  this.l = var1;
                  this.I = var2;
               }

               public float l() {
                  return this.I;
               }
            };
         }
      }
   }

   float IlIIll(float var1, float var2) {
      if (!(var1 <= 0.0F) && !(var2 <= 0.0F)) {
         float var3 = (float)(Math.log((double)2.0F * (double)var1 / (double)var2 + (double)1.0F) / Math.log((double)2.0F));
         return 0.14F * var3 + 0.08F;
      } else {
         return 0.1F;
      }
   }

   float IlIlII(float var1, float var2, float var3) {
      if (!this.IlIIlll) {
         return 0.0F;
      } else {
         this.IIIIIl += var2;
         float var4 = this.llIllIl > 0.0F ? class_3532.method_15363(this.IIIIIl / this.llIllIl, 0.0F, 1.0F) : 1.0F;
         float var5 = Math.abs(var1);
         float var6 = this.IlIIl(var4, var3);
         ThreadLocalRandom var7 = ThreadLocalRandom.current();
         var6 += var6 * (var7.nextFloat() - 0.5F) * 2.0F * 0.08F;
         float var8 = Math.signum(var1) * Math.min(var6, var5);
         float var9 = this.IlIlll(var1, this.lIlIIll);
         var9 = class_3532.method_15363(var9, -var3 * 0.6F, var3 * 0.6F);
         float var10 = 8.0F;
         float var11 = 4.0F;
         float var12;
         if (var5 >= var10) {
            var12 = 1.0F;
         } else if (var5 <= var11) {
            var12 = 0.0F;
         } else {
            float var13 = (var5 - var11) / (var10 - var11);
            var12 = var13 * var13 * (3.0F - 2.0F * var13);
         }

         float var16 = class_3532.method_16439(var12, var9, var8);
         this.lIlIIll = var16;
         return var16;
      }
   }

   private float IlIlIl(Object var1, float var2, float var3, boolean var4) {
      float var5 = this.IIlll(var1);
      float var6 = class_3532.method_15363((0.05F + (1.0F - var5) * 0.11F + var2 * 0.08F) * var3, 0.035F, 0.26F);
      if (this.ll(var1)) {
         var6 *= var1.IlI().IllI();
         var6 = class_3532.method_15363(var6, 0.06F, 0.54F);
      }

      return var4 ? class_3532.method_15363(var6 * 0.48F, 0.018F, 0.12F) : var6;
   }

   private void IlIllI(boolean var1, float var2) {
      if (var1) {
         this.lIIllI = var2;
      } else {
         this.lIIlllI = var2;
      }

   }

   float IlIlll(float var1, float var2) {
      float var3 = var1 * this.llllII + var2 * this.llllIlI;
      return Math.abs(var1) < this.lllI ? 0.0F : var3;
   }

   private <undefinedtype> IllIII(float var1, float var2, float var3, float var4, float var5, float var6) {
      float var7 = 12.88053F;
      float var8 = 1.0F;
      float var9 = var1 - var2;
      float var10 = -2.0F * var8 * var7 * var3 - var7 * var7 * var9;
      float var11 = var3 + var10 * var6;
      if (var4 > 0.0F) {
         var11 = class_3532.method_15363(var11, -var4, var4);
      }

      float var12 = var11 * var6;
      if (var5 > 0.0F) {
         var12 = class_3532.method_15363(var12, -var5, var5);
      }

      float var13 = var1 + var12;
      boolean var14 = var2 - var1 > 0.0F == var13 > var2;
      if (var14 && Math.abs(var9) <= var5) {
         var13 = var2;
         var11 *= 0.25F;
      }

      return new Record(var13, var11) {
         private final float I;
         private final float l;

         private {
            this.I = var1;
            this.l = var2;
         }

         public float I() {
            return this.l;
         }

         public float l() {
            return this.I;
         }
      };
   }

   private class_243 IllIIl(class_243 var1, class_238 var2) {
      double var3 = class_3532.method_15350(var1.field_1352, var2.field_1323, var2.field_1320);
      double var5 = class_3532.method_15350(var1.field_1351, var2.field_1322, var2.field_1325);
      double var7 = class_3532.method_15350(var1.field_1350, var2.field_1321, var2.field_1324);
      boolean var9 = var1.field_1352 >= var2.field_1323 && var1.field_1352 <= var2.field_1320 && var1.field_1351 >= var2.field_1322 && var1.field_1351 <= var2.field_1325 && var1.field_1350 >= var2.field_1321 && var1.field_1350 <= var2.field_1324;
      if (!var9) {
         return new class_243(var3, var5, var7);
      } else {
         double var10 = Math.abs(var1.field_1352 - var2.field_1323);
         double var12 = Math.abs(var2.field_1320 - var1.field_1352);
         double var14 = Math.abs(var1.field_1351 - var2.field_1322);
         double var16 = Math.abs(var2.field_1325 - var1.field_1351);
         double var18 = Math.abs(var1.field_1350 - var2.field_1321);
         double var20 = Math.abs(var2.field_1324 - var1.field_1350);
         double var22 = Math.min(Math.min(Math.min(var10, var12), Math.min(var14, var16)), Math.min(var18, var20));
         if (var22 == var10) {
            return new class_243(var2.field_1323, var5, var7);
         } else if (var22 == var12) {
            return new class_243(var2.field_1320, var5, var7);
         } else if (var22 == var14) {
            return new class_243(var3, var2.field_1322, var7);
         } else if (var22 == var16) {
            return new class_243(var3, var2.field_1325, var7);
         } else {
            return var22 == var18 ? new class_243(var3, var5, var2.field_1321) : new class_243(var3, var5, var2.field_1324);
         }
      }
   }

   private class_243 IllIlI(class_310 var1, class_243 var2) {
      if (var1 != null && var1.field_1724 != null && var2 != null) {
         class_243 var3 = var1.field_1724.method_33571();
         class_243 var4 = this.IIlIlII(var1);
         if (!lIlIll(var4)) {
            return var2;
         } else {
            double var5 = Math.max((double)0.75F, Math.min(var3.method_1022(var2), (double)8.0F));
            return var3.method_1019(var4.method_1021(var5));
         }
      } else {
         return var2;
      }
   }

   class_243 IllIll(class_243 var1, class_1309 var2) {
      return this.lllII(var1, var2, (class_238)null);
   }

   private void IlllII(int var1, ThreadLocalRandom var2) {
      this.IIllII = var1;
      this.lIIlIIl = var2.nextFloat() * ((float)Math.PI * 2F);
      this.lIll = var2.nextFloat() * ((float)Math.PI * 2F);
      this.IlllII = 1.35F + var2.nextFloat() * 3.5500002F;
      this.lIIlI = 0.97200006F + var2.nextFloat() * 3.5500002F * 0.58F;
      this.IIIIlIll = 0.075F + var2.nextFloat() * 0.145F;
      this.llIIIl = this.IIIIlIll * 0.4F;
   }

   private float IlllIl(Object var1) {
      return this.lIIlll(0.46F, 0.24F, this.lIl(var1.lI()));
   }

   private <undefinedtype> IllllI(Object var1, Object var2, float var3, float var4, boolean var5) {
      if (this.ll(var1) && var1.l() != null.l && var2 != null && !var2.IIl() && !(var3 <= 0.45F)) {
         if (this.IIllII != var2.l()) {
            this.IlllII(var2.l(), ThreadLocalRandom.current());
         }

         float var6 = Math.max(0.0F, Math.min(var4, 0.1F));
         this.lIIlIIl = this.IIIIllI(this.lIIlIIl + var6 * this.IlllII * ((float)Math.PI * 2F));
         this.lIll = this.IIIIllI(this.lIll + var6 * this.lIIlI * ((float)Math.PI * 2F));
         <undefinedtype> var7 = var1.IlI();
         float var8 = IIII(0.45F, 10.5F, var3);
         float var9 = (float)Math.hypot((double)this.lIIIII, (double)this.IIlll);
         float var10 = class_3532.method_15363(0.32F + var9 / 36.0F, 0.32F, 1.0F);
         float var11 = class_3532.method_15363(0.72F + var7.IlI() * 0.18F + var7.llI() * 0.22F, 0.7F, 1.35F);
         if (var5) {
            var11 *= 0.55F;
         }

         float var12 = var8 * var10 * var11;
         if (var12 <= 1.0E-4F) {
            return null.l;
         } else {
            float var13 = (float)(Math.sin((double)this.lIIlIIl) * 0.72 + Math.sin((double)(this.lIIlIIl * 2.17F + this.lIll)) * 0.28);
            float var14 = (float)(Math.sin((double)this.lIll) * 0.68 + Math.sin((double)(this.lIll * 1.63F + this.lIIlIIl)) * 0.32);
            return new Record(var14 * this.llIIIl * var12, var13 * this.IIIIlIll * var12) {
               private final float I;
               private static final <undefinedtype> l = new <anonymous constructor>(0.0F, 0.0F);
               private final float II;

               public float I() {
                  return this.I;
               }

               private boolean l() {
                  return Math.abs(this.I) > 1.0E-4F || Math.abs(this.II) > 1.0E-4F;
               }

               private {
                  this.I = var1;
                  this.II = var2;
               }

               public float II() {
                  return this.II;
               }
            };
         }
      } else {
         return null.l;
      }
   }

   private boolean Illlll(Object var1) {
      return var1 != null && var1.l() == null.I && var1.lI() <= 0.001F;
   }

   void lIIIII() {
      this.lIlll = -1;
      this.IlIlI = Double.MAX_VALUE;
   }

   private float lIIIIl(float var1, float var2, boolean var3) {
      if (!(var2 <= 1.0E-6F) && Float.isFinite(var2) && Float.isFinite(var1)) {
         float var4 = var3 ? this.lIIllI : this.lIIlllI;
         var1 += var4;
         float var5 = Math.abs(var1);
         if (var5 < var2 * 0.06F) {
            this.IlIllI(var3, var1);
            return 0.0F;
         } else {
            float var6 = (float)Math.round(var1 / var2) * var2;
            this.IlIllI(var3, class_3532.method_15363(var1 - var6, -var2 * 0.5F, var2 * 0.5F));
            return var6;
         }
      } else {
         return var1;
      }
   }

   private <undefinedtype> lIIIlI(Object var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8, boolean var9) {
      if (!this.IIlII(var1) && !(var6 <= 1.35F) && !(var7 <= 1.0E-4F)) {
         float var10 = class_3532.method_15363((var6 - 1.35F) / 1.65F, 0.0F, 1.0F);
         float var11 = this.ll(var1) ? 1.08F : 1.0F;
         float var12 = var9 ? 0.34F : 0.19F;
         float var13 = var9 ? 0.24F : 0.14F;
         if (this.IIlII(var1)) {
            var12 *= 0.4F;
            var13 *= 0.4F;
         }

         float var14 = Math.min(var12, var7 * var13) * var10 * var11 * this.IIIIllll * class_3532.method_15363(0.55F + var8 * 0.45F, 0.55F, 1.0F);
         if (var14 <= 1.0E-4F) {
            return new Record(var2, var3) {
               private final float I;
               private final float l;

               private {
                  this.l = var1;
                  this.I = var2;
               }

               public float I() {
                  return this.l;
               }

               public float l() {
                  return this.I;
               }
            };
         } else {
            float var15 = -var5 / var6;
            float var16 = var4 / var6;
            var2 += var15 * var14 * this.llllll;
            var3 += var16 * var14 * this.llllll * 0.58F;
            return new Record(var2, var3) {
               private final float I;
               private final float l;

               private {
                  this.l = var1;
                  this.I = var2;
               }

               public float I() {
                  return this.l;
               }

               public float l() {
                  return this.I;
               }
            };
         }
      } else {
         return new Record(var2, var3) {
            private final float I;
            private final float l;

            private {
               this.l = var1;
               this.I = var2;
            }

            public float I() {
               return this.l;
            }

            public float l() {
               return this.I;
            }
         };
      }
   }

   private boolean lIIIll(class_310 var1, Object var2, float var3, float var4) {
      if (var1 != null && var1.field_1687 != null && var2 != null) {
         class_1297 var5 = var1.field_1687.method_8469(var2.l());
         return var5 != null && x.IlIlIl.lIIll(var1, IIllIII(-1986517605, -1198044611), var3, var4);
      } else {
         return false;
      }
   }

   static class_238 lIIlII(class_238 var0, double var1) {
      if (var0 == null) {
         return null;
      } else {
         double var3 = Math.min(var0.method_17939(), Math.min(var0.method_17940(), var0.method_17941()));
         double var5 = Math.max((double)0.0F, var3 * 0.49);
         double var7 = Double.isFinite(var1) ? class_3532.method_15350(var1, (double)0.0F, var5) : (double)0.0F;
         return new class_238(var0.field_1323 + var7, var0.field_1322 + var7, var0.field_1321 + var7, var0.field_1320 - var7, var0.field_1325 - var7, var0.field_1324 - var7);
      }
   }

   private static boolean lIIlIl(double var0, double var2) {
      return Math.abs(var0 - var2) <= 1.0E-7;
   }

   boolean lIIllI(int var1, double var2) {
      if (this.lIlll != -1 && var1 != this.lIlll) {
         return var2 * (double)1.4F < this.IlIlI;
      } else {
         return true;
      }
   }

   private float lIIlll(float var1, float var2, float var3) {
      return class_3532.method_16439(class_3532.method_15363(var3, 0.0F, 1.0F), var1, var2);
   }

   private float lIlIII(float var1, float var2, float var3) {
      return var1 < var2 ? Math.min(var1 + var3, var2) : Math.max(var1 - var3, var2);
   }

   private boolean lIlIIl(Object var1, Object var2, float var3, boolean var4) {
      return false;
   }

   private boolean lIlIlI(class_310 var1, class_243 var2, class_243 var3, class_243 var4, double var5, float var7) {
      if (lIlIll(var4) && !(var2.method_1025(var4) > var5)) {
         class_243 var8 = var4.method_1020(var2);
         return this.IIlIII(var3, var8) <= var7 && this.llIll(var1, var2, var4);
      } else {
         return false;
      }
   }

   private static boolean lIlIll(class_243 var0) {
      return var0 != null && Double.isFinite(var0.field_1352) && Double.isFinite(var0.field_1351) && Double.isFinite(var0.field_1350);
   }

   private class_243 lIllII(class_243 var1, class_238 var2, float var3, float var4) {
      if (!this.lllIII) {
         ThreadLocalRandom var5 = ThreadLocalRandom.current();
         this.IIIll = var5.nextFloat() * 1.0999999F + 0.3F;
         this.I = var5.nextFloat() * 1.0999999F + 0.3F;
         this.IllllIl = var5.nextFloat() * 1.0999999F + 0.3F;
         this.lllIII = true;
      }

      float var15 = Math.max(0.0F, Math.min(var3, 0.1F));
      this.IIIIlIlI += var15 * this.IIIll * ((float)Math.PI * 2F);
      this.IIlllll += var15 * this.I * ((float)Math.PI * 2F);
      this.IlIIIl += var15 * this.IllllIl * ((float)Math.PI * 2F);
      float var6 = (float)(Math.sin((double)this.IIIIlIlI) * 0.6 + Math.sin((double)this.IIIIlIlI * 1.9) * 0.4);
      float var7 = (float)(Math.sin((double)this.IIlllll) * 0.55 + Math.sin((double)this.IIlllll * (double)1.5F) * 0.45);
      float var8 = (float)(Math.sin((double)this.IlIIIl) * 0.65 + Math.sin((double)this.IlIIIl * 1.7) * 0.35);
      double var9 = var1.field_1352 + (double)(var6 * var4);
      double var11 = var1.field_1351 + (double)(var7 * var4);
      double var13 = var1.field_1350 + (double)(var8 * var4);
      return new class_243(class_3532.method_15350(var9, var2.field_1323, var2.field_1320), class_3532.method_15350(var11, var2.field_1322, var2.field_1325), class_3532.method_15350(var13, var2.field_1321, var2.field_1324));
   }

   private float lIllIl(class_310 var1, class_243 var2, Object var3, int var4) {
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null && var2 != null && lIlIll(var2) && var3 != null) {
         class_239 var6 = var1.field_1765;
         if (var6 instanceof class_3965) {
            class_3965 var5 = (class_3965)var6;
            if (var5.method_17783() == class_240.field_1332 && var5.method_17784().method_1025(var2) <= 0.04000000000000001) {
               return 0.0F;
            }
         }

         long var19 = System.nanoTime();
         <undefinedtype> var7 = null.III(var4, var2);
         if (var7 == null) {
            return Float.MAX_VALUE;
         } else {
            this.llIlI(var3, var7, var19);
            this.IIllIl(var1, var3, true, var7, false);
            float var8 = var1.field_1724.method_36454();
            float var9 = this.IIlllI(var1.field_1724.method_36455());
            class_243 var10 = var1.field_1724.method_33571();
            class_243 var11 = var2.method_1020(var10);
            double var12 = Math.sqrt(var11.field_1352 * var11.field_1352 + var11.field_1350 * var11.field_1350);
            float var14;
            if (var12 <= 1.0E-4) {
               var14 = Math.abs(this.III(var11) - var9);
            } else {
               float var15 = (float)(Math.toDegrees(Math.atan2(var11.field_1350, var11.field_1352)) - (double)90.0F);
               float var16 = this.IIlllI((float)(-Math.toDegrees(Math.atan2(var11.field_1351, var12))));
               float var17 = class_3532.method_15393(var15 - var8);
               float var18 = var16 - var9;
               var14 = (float)Math.hypot((double)var17, (double)var18);
            }

            return var14;
         }
      } else {
         return Float.MAX_VALUE;
      }
   }

   private class_243 lIlllI(class_310 var1, class_243 var2, class_243 var3, class_1309 var4, Object var5) {
      double var6 = var5.II();
      float var8 = Math.max(var5.l(), 0.5F);
      if (this.IIIIlII(var2, var4.method_5829()) > var6 * var6) {
         return null;
      } else if (var5.Ill()) {
         return this.IIlIllI(var1, var2, var3, var4, var5, var6, var8);
      } else {
         boolean var9 = var5.lII() && var5.IIl() && var5.III();
         class_243 var10 = null;
         class_238 var11 = null;
         double var12 = Double.POSITIVE_INFINITY;

         for(<undefinedtype> var15 : IlllIlII.IlIIlll(var5.lII(), var5.IIl(), var5.III())) {
            class_238 var16 = IlllIlII.IlIIIlI(var4, var15);
            class_243 var17 = this.lII(var1, var2, var3, var4, var16, var6, var8);
            if (var5.lI() && !lIlIll(var17)) {
               var17 = this.IIIlIII(var1, var2, var3, var4, var4.method_5829(), var6, var8);
            }

            if (lIlIll(var17)) {
               class_243 var18 = var17.method_1020(var2);
               float var19 = this.IIlIII(var3, var18);
               if (!(var19 > var8)) {
                  double var20 = var2.method_1025(var17);
                  double var22;
                  if (var9) {
                     var22 = var20;
                  } else {
                     double var24 = Math.sqrt(this.IlllI(var2, var3, var17));
                     var22 = (double)var19 + var24 * 1.8 + Math.sqrt(var20) * 1.1;
                  }

                  if (var22 < var12) {
                     var12 = var22;
                     var10 = var17;
                     var11 = var16;
                  }
               }
            }
         }

         if (!lIlIll(var10)) {
            return null;
         } else if (this.lIIIl(var1, var4)) {
            this.IlII();
            return var10;
         } else {
            class_243 var26 = this.lllII(var10, var4, var11);
            if (!lIlIll(var26)) {
               return var10;
            } else if (var2.method_1025(var26) > var6 * var6) {
               return var10;
            } else {
               class_243 var27 = var26.method_1020(var2);
               if (this.IIlIII(var3, var27) > var8) {
                  return var10;
               } else if (var5.lI() && !this.llIll(var1, var2, var26)) {
                  return var10;
               } else {
                  return var26;
               }
            }
         }
      }
   }

   private List<class_243> lIllll(class_243 var1, class_238 var2) {
      ArrayList var3 = new ArrayList(IIllIII(-1986517606, 1061706105));
      var3.add(this.IllIIl(var1, var2));
      double var4 = (var2.field_1323 + var2.field_1320) * (double)0.5F;
      double var6 = (var2.field_1322 + var2.field_1325) * (double)0.5F;
      double var8 = (var2.field_1321 + var2.field_1324) * (double)0.5F;
      double var10 = class_3532.method_15350(var1.field_1352, var2.field_1323, var2.field_1320);
      double var12 = class_3532.method_15350(var1.field_1351, var2.field_1322, var2.field_1325);
      double var14 = class_3532.method_15350(var1.field_1350, var2.field_1321, var2.field_1324);
      double[] var16 = new double[]{var2.field_1323, var4, var2.field_1320, var10};
      double[] var17 = new double[]{var2.field_1322, var6, var2.field_1325, var12};
      double[] var18 = new double[]{var2.field_1321, var8, var2.field_1324, var14};

      for(double var22 : var16) {
         for(double var27 : var17) {
            for(double var32 : var18) {
               boolean var34 = lIIlIl(var22, var2.field_1323) || lIIlIl(var22, var2.field_1320) || lIIlIl(var27, var2.field_1322) || lIIlIl(var27, var2.field_1325) || lIIlIl(var32, var2.field_1321) || lIIlIl(var32, var2.field_1324);
               if (var34) {
                  var3.add(new class_243(var22, var27, var32));
               }
            }
         }
      }

      return var3;
   }

   boolean llIIII() {
      return this.IlIIlll && this.IIIIIl < this.llIllIl * 0.65F;
   }

   boolean llIIIl() {
      return this.IIlIIll && this.IlllI > 0.0F;
   }

   public void llIIlI(class_310 var1, Object var2, boolean var3, Object var4, boolean var5) {
      long var6 = System.nanoTime();
      if (var5) {
         this.lIIIIl = var6;
         this.llI(var1, var2, var3, var4, var6, true);
      } else {
         this.IIIlll();
         float var8 = this.IlI(var6);
         this.lIIIIl = var6;
         this.IIIlIIl(var1, var2, var3, var4, var8, var6, false);
      }
   }

   public float llIIll(class_310 var1, class_243 var2, float var3) {
      return this.IIIllII(var1, var2, null.II(var3));
   }

   private float llIlII(Object var1) {
      return this.lIIlll(1.35F, 2.85F, this.lIl(var1.lI()));
   }

   private static float llIlIl(float var0) {
      float var1 = class_3532.method_15363(var0, 1.0F, 500.0F);
      return class_3532.method_15363((var1 - 1.0F) / 499.0F, 0.0F, 1.0F);
   }

   private class_243 llIllI(class_310 var1, class_243 var2, class_243 var3, class_1309 var4, class_238 var5, double var6, float var8) {
      if (var1 != null && var1.field_1687 != null && var2 != null && var3 != null && var4 != null && var5 != null) {
         double var9 = var6 * var6;
         class_243 var11 = this.IllIIl(var2, var5);
         if (this.lIlIlI(var1, var2, var3, var11, var9, var8)) {
            return var11;
         } else {
            class_243 var12 = null;
            double var13 = Double.POSITIVE_INFINITY;

            for(class_243 var16 : this.lIllll(var2, var5)) {
               if (this.lIlIlI(var1, var2, var3, var16, var9, var8)) {
                  double var17 = var2.method_1025(var16);
                  if (var17 < var13) {
                     var13 = var17;
                     var12 = var16;
                  }
               }
            }

            return var12;
         }
      } else {
         return null;
      }
   }

   private float llIlll(Object var1, float var2, float var3, float var4) {
      float var5 = Math.max(var2, 0.005F);
      float var6 = this.IIlll(var1);
      float var7 = var5 * 20.0F * (0.95F + (1.0F - var6) * 0.55F + var3 * 0.95F) * var4 * 1.45F * this.IIIIIIl(var1) * var1.ll();
      if (this.ll(var1)) {
         var7 *= var1.IlI().lIll();
      }

      return var7;
   }

   private void lllIII(Object var1, Object var2, float var3) {
      if (this.ll(var1) && var2 != null) {
         if (var3 <= 3.36F) {
            this.IIIIlI();
         } else {
            boolean var4 = this.llllllI != var2.l();
            boolean var5 = this.IlIIlll && var3 > this.IIIIllIl + 6.0F;
            if (!this.IlIIlll || var4 || var5) {
               float var6 = class_3532.method_15363(1.4F + (1.0F - var2.IlI()) * 2.4F, 1.2F, 4.0F);
               this.I(var3, var6);
               this.llllllI = var2.l();
            }

         }
      } else {
         this.IIIIlI();
      }
   }

   float lllIIl() {
      return (float)Math.hypot((double)this.lIIIII, (double)this.IIlll);
   }

   private float lllIlI(float var1, float var2, float var3, float var4) {
      float var5 = IIl(var1, var2, var3, var4);
      if (var5 == 0.0F && var2 != 0.0F) {
         this.IIlll = 0.0F;
         this.IIIIlIIl = 0.0F;
      }

      return var5;
   }

   private <undefinedtype> lllIll(Object var1, float var2, float var3, float var4, float var5, float var6) {
      if (this.ll(var1) && this.IlIIlll && !(var4 <= 1.0E-4F)) {
         float var7 = (float)Math.hypot((double)var2, (double)var3);
         if (var7 <= 1.0E-4F) {
            return new Record(var2, var3) {
               private final float I;
               private final float l;

               private {
                  this.l = var1;
                  this.I = var2;
               }

               public float I() {
                  return this.l;
               }

               public float l() {
                  return this.I;
               }
            };
         } else {
            float var8 = Math.abs(this.IlIlII(var4, var5, Math.max(var6, 0.005F)));
            if (var8 <= 1.0E-4F) {
               return new Record(var2, var3) {
                  private final float I;
                  private final float l;

                  private {
                     this.l = var1;
                     this.I = var2;
                  }

                  public float I() {
                     return this.l;
                  }

                  public float l() {
                     return this.I;
                  }
               };
            } else {
               float var9 = class_3532.method_15363(var8 / var7, 0.42F, 1.34F);
               return new Record(var2 * var9, var3 * var9) {
                  private final float I;
                  private final float l;

                  private {
                     this.l = var1;
                     this.I = var2;
                  }

                  public float I() {
                     return this.l;
                  }

                  public float l() {
                     return this.I;
                  }
               };
            }
         }
      } else {
         return new Record(var2, var3) {
            private final float I;
            private final float l;

            private {
               this.l = var1;
               this.I = var2;
            }

            public float I() {
               return this.l;
            }

            public float l() {
               return this.I;
            }
         };
      }
   }

   private void llllII(float var1, float var2) {
      this.IlIlIII = true;
      this.lIllI = var1;
      this.IIIIII = this.IIlllI(var2);
   }

   void llllIl(int var1, double var2) {
      this.lIlll = var1;
      this.IlIlI = var2;
   }

   private float lllllI(int var1, int var2, int var3, float var4, float var5) {
      float var6 = this.IIIIII(this.IIlIIlI(var1 * IIllIII(-1986517603, 1865490040) + var3 * IIllIII(-1986517604, 1739886766) + var2 * 5));
      return this.lIIlll(var4, var5, var6);
   }

   private void llllll(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         this.IIIIl();
         this.llllII(var1.field_1724.method_36454(), this.IIlllI(var1.field_1724.method_36455()));
      } else {
         this.IIlIIll();
      }
   }

   private <undefinedtype> IIIIIII(Object var1, Object var2, float var3, float var4, boolean var5) {
      if (!this.lIlIIl(var1, var2, var3, var5)) {
         this.llIII(var4);
         this.IlIIll = Float.NaN;
         return null.l;
      } else {
         boolean var6 = this.llIlllI == var2.l();
         float var7 = var6 ? this.IlIIll : Float.NaN;
         boolean var8 = Float.isFinite(var7);
         float var9 = var8 ? var7 - var3 : 0.0F;
         boolean var10 = !var8 || var9 >= -0.04F;
         if (!var6 || this.llIIIlI <= 1.0E-4F) {
            this.IIIlllI(var2.l(), ThreadLocalRandom.current(), true);
         }

         this.IlIIll = var3;
         if (!var10) {
            this.llIII(var4);
            return null.l;
         } else {
            float var11 = 1.0F - IIII(3.0F, 16.0F, var3);
            if (var11 <= 1.0E-4F) {
               this.llIII(var4);
               return null.l;
            } else {
               float var12 = class_3532.method_15363(var4, 0.0F, 0.1F);
               this.llIlII += var12;
               if (this.llIlII >= this.llIIIlI) {
                  this.IIIlllI(var2.l(), ThreadLocalRandom.current(), false);
               }

               float var13 = class_3532.method_15363(var12 * 6.5F, 0.0F, 1.0F);
               ThreadLocalRandom var14 = ThreadLocalRandom.current();
               float var15 = 0.05F * var12;
               this.IIl += (var14.nextFloat() - 0.5F) * var15;
               this.IIl = class_3532.method_15363(this.IIl, 1.0F, 5.0F);
               this.llIIll += (var14.nextFloat() - 0.5F) * var15;
               this.llIIll = class_3532.method_15363(this.llIIll, 1.0F, 5.0F);
               float var16 = 0.02F * var12;
               this.IIlIIIl += (var14.nextFloat() - 0.5F) * var16;
               this.IIlIIIl = class_3532.method_15363(this.IIlIIIl, -0.92F, 0.92F);
               this.III += (var14.nextFloat() - 0.5F) * var16;
               this.III = class_3532.method_15363(this.III, -0.42F, 0.42F);
               this.IIIlIl += (this.IIlIIIl - this.IIIlIl) * var13;
               this.lIIIllI += (this.III - this.lIIIllI) * var13;
               this.llllIII = this.IIIIllI(this.llllIII + var12 * this.IIl * ((float)Math.PI * 2F));
               this.lIIIll = this.IIIIllI(this.lIIIll + var12 * this.llIIll * ((float)Math.PI * 2F));
               float var17 = var8 ? class_3532.method_15363((var9 + 0.04F) / 0.89000005F, 0.35F, 1.0F) : 0.72F;
               float var18 = class_3532.method_15363(0.78F + (var2.I() + var2.II()) * 8.5F, 0.78F, 1.35F);
               float var19 = class_3532.method_15363(var11 * var17 * var18, 0.0F, 0.78F);
               float var20 = (float)Math.sin((double)this.llllIII);
               float var21 = (float)Math.sin((double)(this.llllIII * 0.58F + this.IlIIl));
               float var22 = var20 * 0.56F + (float)Math.sin((double)(this.lIIIll * 1.37F + this.llllIII * 0.41F)) * 0.27F + var21 * 0.17F;
               float var23 = (float)Math.sin((double)(this.llllIII + this.IlIIl)) * 0.46F + (float)Math.sin((double)this.lIIIll) * 0.34F + var20 * this.lllIlll * 0.2F;
               float var24 = this.IIIlIl + var22 * 0.26F;
               float var25 = this.lIIIllI + var23 * 0.16F + var24 * this.lllIlll * 0.26F;
               return new Record(var24 * var19, var25 * var19) {
                  private final float I;
                  private static final <undefinedtype> l = new <anonymous constructor>(0.0F, 0.0F);
                  private final float II;

                  public float I() {
                     return this.I;
                  }

                  private boolean l() {
                     return Math.abs(this.I) > 1.0E-4F || Math.abs(this.II) > 1.0E-4F;
                  }

                  private {
                     this.I = var1;
                     this.II = var2;
                  }

                  public float II() {
                     return this.II;
                  }
               };
            }
         }
      }
   }

   private float IIIIIIl(Object var1) {
      return var1 != null && var1.l() == null.I ? class_3532.method_15363(var1.lI() / 100.0F, 0.0F, 2.0F) : 1.0F;
   }

   float IIIIIlI(class_310 var1, class_243 var2) {
      if (var1 != null && var1.field_1724 != null && var2 != null) {
         class_243 var3 = var1.field_1724.method_33571();
         class_243 var4 = var2.method_1020(var3);
         double var5 = Math.sqrt(var4.field_1352 * var4.field_1352 + var4.field_1350 * var4.field_1350);
         if (var5 <= 1.0E-4) {
            return 0.0F;
         } else {
            float var7 = (float)(Math.toDegrees(Math.atan2(var4.field_1350, var4.field_1352)) - (double)90.0F);
            float var8 = this.IIlllI((float)(-Math.toDegrees(Math.atan2(var4.field_1351, var5))));
            float var9 = class_3532.method_15393(var7 - var1.field_1724.method_36454());
            float var10 = var8 - this.IIlllI(var1.field_1724.method_36455());
            return (float)Math.hypot((double)var9, (double)var10);
         }
      } else {
         return Float.MAX_VALUE;
      }
   }

   private float IIIIIll(Object var1, float var2, float var3) {
      if (var1.IlI() <= 0.0F) {
         return var2;
      } else {
         float var4 = this.IIlllI(var3);
         return Math.abs(var4 - var2) <= 0.0125F ? var2 : var4;
      }
   }

   private double IIIIlII(class_243 var1, class_238 var2) {
      if (var1 != null && var2 != null) {
         double var3 = class_3532.method_15350(var1.field_1352, var2.field_1323, var2.field_1320);
         double var5 = class_3532.method_15350(var1.field_1351, var2.field_1322, var2.field_1325);
         double var7 = class_3532.method_15350(var1.field_1350, var2.field_1321, var2.field_1324);
         double var9 = var1.field_1352 - var3;
         double var11 = var1.field_1351 - var5;
         double var13 = var1.field_1350 - var7;
         return var9 * var9 + var11 * var11 + var13 * var13;
      } else {
         return Double.POSITIVE_INFINITY;
      }
   }

   private void IIIIlIl(Object var1, float var2, float var3, float var4, float var5) {
      if (var1.I() && this.IlIlIII) {
         this.IlIll = this.l(var2, this.lIllI, var4, this.IlIll, true);
         this.lIIII = this.l(var3, this.IIIIII, var5, this.lIIII, false);
      } else {
         this.IlIll = 0;
         this.lIIII = 0;
      }
   }

   private float IIIIllI(float var1) {
      float var2 = ((float)Math.PI * 2F);
      float var3 = var1 % var2;
      return var3 < 0.0F ? var3 + var2 : var3;
   }

   private <undefinedtype> IIIIlll(class_310 var1, class_1309 var2, Object var3, boolean var4, class_243 var5, class_243 var6, class_243 var7) {
      if (var1 != null && var1.field_1724 != null && var2 != null && var3 != null && lIlIll(var5) && lIlIll(var6) && lIlIll(var7)) {
         double var8 = var3.II();
         double var10 = this.IIIIlII(var5, var2.method_5829());
         if (var10 > var8 * var8) {
            return null;
         } else {
            class_243 var12 = var7.method_1020(var5);
            double var13 = Math.sqrt(var12.field_1352 * var12.field_1352 + var12.field_1350 * var12.field_1350);
            if (var13 <= 1.0E-4) {
               return null;
            } else {
               float var15 = Math.max(var3.l(), 0.5F);
               float var16 = this.IIlIII(var6, var12);
               if (var16 > var15) {
                  return null;
               } else {
                  double var17 = Math.sqrt(this.IlllI(var5, var6, var7));
                  double var19 = (double)var16 + var17 * 1.8 + Math.sqrt(var10) * 1.1;
                  if (var4) {
                     var19 -= (double)2.0F;
                  }

                  float var21 = class_3532.method_15363(var16 / Math.max(var15, 1.0F), 0.0F, 1.0F);
                  float var22 = (float)var1.field_1724.method_18798().method_37267();
                  if (!Float.isFinite(var22) || var22 < 0.0F) {
                     var22 = 0.0F;
                  }

                  float var23 = (float)var2.method_18798().method_37267();
                  if (!Float.isFinite(var23) || var23 < 0.0F) {
                     var23 = 0.0F;
                  }

                  return new Record(var2.method_5628(), var7, var21, var19, var15, var4, var22, var23, var3.Ill()) {
                     private final boolean I;
                     private final float l;
                     private final double II;
                     private final class_243 Il;
                     private final int lI;
                     private final boolean ll;
                     private final float III;
                     private final float IIl;
                     private final float IlI;

                     public float I() {
                        return this.l;
                     }

                     public int l() {
                        return this.lI;
                     }

                     public float II() {
                        return this.III;
                     }

                     public float Il() {
                        return this.IIl;
                     }

                     public boolean lI() {
                        return this.I;
                     }

                     public class_243 ll() {
                        return this.Il;
                     }

                     static <undefinedtype> III(int var0, class_243 var1) {
                        return var1 == null ? null : new <anonymous constructor>(var0, var1, 0.0F, (double)0.0F, 360.0F, false, 0.0F, 0.0F, true);
                     }

                     public boolean IIl() {
                        return this.ll;
                     }

                     public {
                        this.lI = var1;
                        this.Il = var2;
                        this.IlI = var3;
                        this.II = var4;
                        this.IIl = var6;
                        this.I = var7;
                        this.l = var8;
                        this.III = var9;
                        this.ll = var10;
                     }

                     public float IlI() {
                        return this.IlI;
                     }

                     public double Ill() {
                        return this.II;
                     }
                  };
               }
            }
         }
      } else {
         return null;
      }
   }

   private class_243 IIIlIII(class_310 var1, class_243 var2, class_243 var3, class_1309 var4, class_238 var5, double var6, float var8) {
      if (var1 != null && var1.field_1687 != null && var2 != null && var3 != null && var4 != null) {
         class_238 var9 = var5 == null ? var4.method_5829() : var5;
         double var10 = var6 * var6;
         class_243 var12 = null;
         double var13 = Double.POSITIVE_INFINITY;

         for(class_243 var16 : this.lIllll(var2, var9)) {
            if (lIlIll(var16) && !(var2.method_1025(var16) > var10)) {
               class_243 var17 = var16.method_1020(var2);
               float var18 = this.IIlIII(var3, var17);
               if (!(var18 > var8) && this.llIll(var1, var2, var16)) {
                  double var19 = var2.method_1025(var16);
                  double var21 = this.IlllI(var2, var3, var16);
                  double var23 = var19 + var21 * 0.35 + (double)var18 * 0.02;
                  if (var23 < var13) {
                     var13 = var23;
                     var12 = var16;
                  }
               }
            }
         }

         return var12;
      } else {
         return null;
      }
   }

   private void IIIlIIl(class_310 var1, Object var2, boolean var3, Object var4, float var5, long var6, boolean var8) {
      if (var1 != null && var1.field_1724 != null) {
         if (var3 && !this.Illlll(var2)) {
            if (this.IIlllIl) {
               float var9 = Math.max(0.0F, Math.min(var5, 0.1F));
               this.lllIlI -= var9;
               if (!(this.lllIlI <= 0.0F)) {
                  this.llllll(var1);
                  this.lIllIII = var6;
                  return;
               }

               this.IIlllIl = false;
               this.lllIlI = 0.0F;
               this.IIllllI = 0.0F;
            }

            if (var4 == null) {
               this.llllll(var1);
               this.lIlIlll = -1;
               this.lllll();
               this.lIllIII = var6;
            } else {
               this.IllI(var1, var2, var4, var5, var8);
               this.lIllIII = var6;
            }
         } else {
            this.llllll(var1);
            this.IIlllIl = false;
            this.lllIlI = 0.0F;
            this.lIllIII = var6;
         }
      } else {
         this.IIlIIll();
      }
   }

   private float IIIlIlI(Object var1, int var2, int var3, float var4, float var5, float var6, float var7, float var8) {
      if (var1.lI != var2) {
         var1.lI = var2;
         var1.ll = 0;
         var1.Il = 1.0F;
         var1.l = 1.0F;
         var1.I = this.IIlIIl(var2, var3, 0, var5, var6);
         var1.II = this.lllllI(var2, var3, 0, var7, var8);
         var1.III = 0.0F;
      }

      for(var1.III += Math.max(var4, 0.0F); var1.III >= var1.II; var1.II = this.lllllI(var2, var3, var1.ll, var7, var8)) {
         var1.III -= var1.II;
         var1.Il = var1.I;
         var1.l = var1.Il;
         ++var1.ll;
         var1.I = this.IIlIIl(var2, var3, var1.ll, var5, var6);
      }

      float var9 = var1.II <= 1.0E-4F ? 1.0F : class_3532.method_15363(var1.III / var1.II, 0.0F, 1.0F);
      float var10 = var9 * var9 * (3.0F - 2.0F * var9);
      var1.Il = class_3532.method_16439(var10, var1.l, var1.I);
      return var1.Il;
   }

   public void IIIlIll() {
      this.IIlIIll();
      this.lIllI();
   }

   private float IIIllII(class_310 var1, class_243 var2, Object var3) {
      return this.lIllIl(var1, var2, var3, IIIl(var2));
   }

   private <undefinedtype> IIIllIl(Object var1, Object var2, float var3) {
      if (var2 != null && !var2.lI() && !(var3 <= 1.35F)) {
         float var4 = class_3532.method_15363((var2.IlI() - 0.18F) / 0.82F, 0.0F, 1.0F);
         if (var4 <= 1.0E-4F) {
            return null.l;
         } else {
            float var5 = class_3532.method_15363((var3 - 1.35F) / 1.65F, 0.0F, 1.0F);
            if (var5 <= 1.0E-4F) {
               return null.l;
            } else {
               float var6 = this.ll(var1) ? 0.6F : 1.0F;
               float var7 = Math.min(0.02F, var3 * 0.004F) * var5 * var6 * var4;
               return new Record(this.IIIIlllI * var7, this.IllIlIl * var7 * 0.72F) {
                  private final float I;
                  private static final <undefinedtype> l = new <anonymous constructor>(0.0F, 0.0F);
                  private final float II;

                  public float I() {
                     return this.I;
                  }

                  private boolean l() {
                     return Math.abs(this.I) > 1.0E-4F || Math.abs(this.II) > 1.0E-4F;
                  }

                  private {
                     this.I = var1;
                     this.II = var2;
                  }

                  public float II() {
                     return this.II;
                  }
               };
            }
         }
      } else {
         return null.l;
      }
   }

   private void IIIlllI(int var1, ThreadLocalRandom var2, boolean var3) {
      this.llIlllI = var1;
      this.llIlII = 0.0F;
      this.llIIIlI = 0.18F + var2.nextFloat() * 0.23999998F;
      this.IIlIIIl = this.lIIl(var2, 0.28F, 0.92F);
      float var4 = 0.12F + var2.nextFloat() * 0.29999998F;
      float var5 = var2.nextFloat() < 0.68F ? -Math.signum(this.IIlIIIl) : Math.signum(this.IIlIIIl);
      this.III = var4 * var5;
      this.IIl = 1.35F + var2.nextFloat() * 3.15F;
      this.llIIll = this.IIl * (0.78F + var2.nextFloat() * 0.54F);
      this.lllIlll = this.lIIl(var2, 0.1F, 0.28F);
      this.IlIIl = this.lIIl(var2, 0.62F, 1.75F);
      if (var3) {
         this.IIIlIl = this.IIlIIIl * (0.1F + var2.nextFloat() * 0.2F);
         this.lIIIllI = this.III * (0.1F + var2.nextFloat() * 0.2F);
         this.llllIII = var2.nextFloat() * ((float)Math.PI * 2F);
         this.lIIIll = var2.nextFloat() * ((float)Math.PI * 2F);
      }

   }

   private float IIIllll(float var1, float var2, float var3) {
      if (!(var3 <= 1.0E-6F) && !(Math.abs(var1) <= 0.01F)) {
         float var4 = Math.min(var2, Math.abs(var1) * 0.42F);
         return Math.signum(var1) * var4 * var3;
      } else {
         return 0.0F;
      }
   }

   public void IIlIIII() {
      this.IIlIIll();
   }

   private class_243 IIlIIIl(class_243 var1, class_243 var2, class_243 var3) {
      class_243 var4 = var3.method_1020(var2);
      double var5 = var4.method_1027();
      if (var5 <= 1.0E-6) {
         return var3;
      } else {
         double var7 = var4.method_1026(var1.method_1020(var2)) / var5;
         var7 = class_3532.method_15350(var7, (double)0.0F, (double)1.0F);
         return var2.method_1019(var4.method_1021(var7));
      }
   }

   private int IIlIIlI(int var1) {
      int var2 = var1 ^ var1 << IIllIII(-1986517601, -1716826897);
      var2 ^= var2 >>> IIllIII(-1986517602, -1288252049);
      var2 ^= var2 << 5;
      return var2;
   }

   private void IIlIIll() {
      this.IlIlIII = false;
      this.lIllI = 0.0F;
      this.IIIIII = 0.0F;
      this.IIIIl();
   }

   private class_243 IIlIlII(class_310 var1) {
      class_243 var2 = var1.field_1724.method_5828(1.0F);
      double var3 = var2.method_1027();
      return var3 <= 1.0E-6 ? null : var2.method_1021((double)1.0F / Math.sqrt(var3));
   }

   private static float IIlIlIl(float var0, float var1, float var2) {
      return !Float.isFinite(var0) ? var1 : class_3532.method_15363(var0, var1, var2);
   }

   private class_243 IIlIllI(class_310 var1, class_243 var2, class_243 var3, class_1309 var4, Object var5, double var6, float var8) {
      <undefinedtype> var9 = var5.IlI() == null ? null.I : var5.IlI();
      if (!var5.lI()) {
         class_243 var11 = IlllIlII.IlIIllI(var4, var9);
         return this.lIlIlI(var1, var2, var3, var11, var6 * var6, var8) ? var11 : null;
      } else {
         class_238 var10 = IlllIlII.IlIIIlI(var4, var9);
         return this.llIllI(var1, var2, var3, var4, var10, var6, var8);
      }
   }

   private float IIlIlll(class_310 var1) {
      if (var1 != null && var1.field_1690 != null) {
         double var2;
         try {
            var2 = (Double)var1.field_1690.method_42495().method_41753();
         } catch (Exception var8) {
            var2 = (double)0.5F;
         }

         double var4 = var2 * 0.6 + 0.2;
         double var6 = var4 * var4 * var4;
         return (float)(var6 * (double)8.0F * 0.15);
      } else {
         return 0.0F;
      }
   }

   private static int IIllIII(int var0, int var1) {
      return IIIllIll[var0 ^ -1986517615] ^ var1 ^ var0;
   }

   static {
      int var2 = 798056917;
      byte[] var0 = "\u0084ß\u0010!\u0099Åâ±µô×\u00882\u0015ú\u0016Õ\u009b'Rÿ\u0090æjÂ\u001bÏå\u00046A\u001c×bûâÍb\u000fH\u001e\u009e\u000eå\u0099A\u001d*É8Z\u0005Á½Ôú?¢\b¨\u0015?\u00915".getBytes("ISO-8859-1");
      int var1 = var0.length / 4;
      IIIllIll = new int[var1];
      int var3 = 0;
      int var4 = 0;

      do {
         int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
         var5 ^= var2;
         IIIllIll[var4] = var5;
         var3 += 4;
         ++var4;
      } while(var4 < var1);

   }
}
