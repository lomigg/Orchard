package x;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Environment(EnvType.CLIENT)
public final class IlIIIlIll {
   private static final String I;
   private static final String l;
   private static final String II;
   private static final Logger Il;
   private static String[] lI;
   private static volatile boolean ll;
   private static final String III;
   private static final String IIl;
   private static final int[] IlI;
   private static final String[] Ill;
   private static final Object[] lII;

   private static Path I() {
      return Paths.get(System.getProperty(lIlIII.Il(lI[Ill(475787130, -996358355)])), lIlIII.Il(lI[4]), lIlIII.Il(lI[Ill(475787131, 13136155)]));
   }

   private static InputStream l(String var0) {
      return IlIIIlIll.class.getClassLoader().getResourceAsStream(var0);
   }

   public static void II() {
      if (!ll) {
         synchronized(IlIIIlIll.class) {
            if (!ll) {
               try {
                  InputStream var1;
                  label265: {
                     var1 = l(I);

                     try {
                        if (var1 == null) {
                           ll = true;
                           break label265;
                        }

                        Path var2 = III();
                        Files.createDirectories(var2);
                        BufferedReader var4 = new BufferedReader(new InputStreamReader(var1));

                        List var3;
                        try {
                           var3 = (List)var4.lines().map(String::trim).filter((var0) -> !var0.isEmpty()).collect(Collectors.toList());
                        } catch (Throwable var26) {
                           try {
                              var4.close();
                           } catch (Throwable var25) {
                              var26.addSuppressed(var25);
                           }

                           throw var26;
                        }

                        var4.close();

                        for(String var5 : var3) {
                           Path var6 = var2.resolve(var5.replace((char)Ill(475787128, -214173322), var2.getFileSystem().getSeparator().charAt(0)));
                           if (!Files.exists(var6, new LinkOption[0])) {
                              Files.createDirectories(var6.getParent());
                              String var12 = IIl;
                              InputStream var7 = l(var12 + var5);

                              label217: {
                                 try {
                                    if (var7 != null) {
                                       Files.copy(var7, var6, new CopyOption[0]);
                                       break label217;
                                    }
                                 } catch (Throwable var27) {
                                    if (var7 != null) {
                                       try {
                                          var7.close();
                                       } catch (Throwable var24) {
                                          var27.addSuppressed(var24);
                                       }
                                    }

                                    throw var27;
                                 }

                                 if (var7 != null) {
                                    var7.close();
                                 }
                                 continue;
                              }

                              if (var7 != null) {
                                 var7.close();
                              }
                           }
                        }
                     } catch (Throwable var28) {
                        if (var1 != null) {
                           try {
                              var1.close();
                           } catch (Throwable var23) {
                              var28.addSuppressed(var23);
                           }
                        }

                        throw var28;
                     }

                     if (var1 != null) {
                        var1.close();
                     }

                     return;
                  }

                  if (var1 != null) {
                     var1.close();
                  }
               } catch (Exception var29) {
                  Il.warn(lIlIII.Il(lI[Ill(475787129, -1357326822)]), var29);
                  return;
               } finally {
                  ll = true;
               }

            }
         }
      }
   }

   private IlIIIlIll() {
   }

   private static void Il() {
      lI[0] = lI(lII(-942391194, 886457485).toCharArray(), 86766L, Ill(475787134, 781087129));
      lI[1] = lI(lII(-942391193, 796284797).toCharArray(), 15968L, Ill(475787135, 286361323));
      lI[2] = lI(lII(-942391196, -807462822).toCharArray(), 37098L, Ill(475787132, 1504448916));
      lI[3] = lI(lII(-942391195, 97411851).toCharArray(), 90835L, Ill(475787133, -1127891121));
      lI[4] = lI(lII(-942391198, 2137216104).toCharArray(), 41792L, Ill(475787122, 1011657463));
      lI[5] = lI(lII(-942391197, 374015552).toCharArray(), 73339L, Ill(475787123, 978031541));
      lI[Ill(475787120, 512820851)] = lI(lII(-942391200, 1103763850).toCharArray(), 69793L, Ill(475787121, 2105245845));
      lI[Ill(475787126, -101669059)] = lI(lII(-942391199, -1012586727).toCharArray(), 10342L, Ill(475787127, 1507977352));
      lI[Ill(475787124, -1208476156)] = lI(lII(-942391186, -1874382049).toCharArray(), 98074L, Ill(475787125, -1112701856));
      lI[Ill(475787114, -513231912)] = lI(lII(-942391185, -836827604).toCharArray(), 21714L, Ill(475787115, 1366266271));
      lI[Ill(475787112, 1627984957)] = lI(lII(-942391188, -1162904012).toCharArray(), 41772L, Ill(475787113, -852317861));
      lI[Ill(475787118, -531313385)] = lI(lII(-942391187, 180095813).toCharArray(), 79634L, Ill(475787119, 7438385));
      lI[Ill(475787116, -30644146)] = lI(lII(-942391190, -1673443558).toCharArray(), 7830L, Ill(475787117, 1031244620));
   }

   private static String lI(char[] var0, long var1, int var3) {
      int var4 = Ill(475787106, 1637506563) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & Ill(475787107, -638560723);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   static {
      short var11 = 7033;
      String var12 = "쾋믕㲸\uef15⼚☒訞脳弧䰭豋᩸อ沣륳鈉᰾\udd31臤푿\uec20㋘赽申䖠\uee7d諿䀶କꌉ麱\uabff㣻ل\ue7c9\ue2ffꓣ鈎됒ᘬ履ᥰ玕眮杛❃钳\ue69cꮬ嘲鴋姁ᕊ羣筿眬\ue961ᾄ乔뫓Ϊ\uf55dљ搂㘑櫢鸄鍸\uf303༒㒘玞Ტ磑坰標堶\ue5ee㞸ˁ氼蝦띔ꘊ돊ⅰ搽»袥ﻫꟽ３ᆞ娃؆⑿莴䀹㴇࡞\uefa4ᨾ锞貊씑瘮\ue4ce䑽塦䦯켭疲♃쵶떖녷瀗樫ו\uf856杳鐹踠\ud84c峒\u17fb苯䒵跂╒빦旰༌還臂\ue719葉ⷣꕽ勴淽\uefc7㟖Έ蘫ꔬⱲ\ufe6e䬗蝇ᢧ훷\u137f줳仭ꀾ揍띈護⬰扜⺌缱ᆹ鐊㱩꾉ⅅꅹ쫫糥ﻧｙⶍ퀳勖片鉣괮\ueede뤂ﴏ鉳䎐偸蜮識福㵿㓛⫍ӟ轙锳ﴄ\ue678\udff8显诇悕㵍趵㲟﹩鲋鐽軚單ኇ\uebbe啣\ue036豂ጁᙏ\uddbe셓⁻偷ꁵ鳒鿬理Θ苝\uef20㻳谑\u321fḖ묅﮹碑\uf4cdꕙ㮂\ue6dd俱횖꿰◮څ訢汕ピ\uf4b8駊ﳖ銿ﬦ竮ꇌ쪄頹\ue866쁏";
      char[] var13 = "᭵᭡᭵᭱᭩᭱᭵᭭᭭\u1b4d᭡᭝᭵".toCharArray();
      String[] var14 = new String[var13.length];
      byte var18 = -1;

      while(true) {
         int var15 = 0;
         int var16 = 0;
         int var17 = 0;
         if (var18 == 0) {
            Ill = var14;
            lII = new Object[var14.length];
            int var2 = -215507730;
            byte[] var0 = "+à´¿ï´\u0002\u0086\u001cG\u008aÏ@d¥\u0084\fC\u0003c\u0083]\u008e\u00adòë\u009dô~tÏY\u008aB}&î§éÀñíuë%!T\u0098\u0016\u008cÔ¢o\u009f\u0003\u000bX\u0084m\u00965\f¨'\u000e\u0014ÀUµ\u009f\u007f»\u008eug±uýt\u008c\u000f(¾\u009c8\u00913\u0092\u0011P\u001bÀ\u0094Y\u009c\rÁI\"\u008d6\u008c%_IÊ\u0014Sz\u0019V\u0001u\u0093ÿÛ\u001eÀ\u0080v°Ü\u0019\u0084¥\u0081ÖäÈÖÛ=".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IlI = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IlI[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            lI = new String[Ill(475787104, -1497995312)];
            Il();
            Il = LoggerFactory.getLogger(lIlIII.Il(lI[Ill(475787105, -1788533372)]));
            IIl = lIlIII.Il(lI[Ill(475787110, -1695577000)]);
            String var27 = IIl;
            String var7 = lIlIII.Il(lI[Ill(475787111, -239275021)]);
            String var6 = var27;
            I = var6 + var7;
            var27 = IIl;
            String var8 = lIlIII.Il(lI[Ill(475787108, 1604348425)]);
            var7 = var27;
            II = var7 + var8;
            var27 = IIl;
            String var9 = lIlIII.Il(lI[0]);
            var8 = var27;
            l = var8 + var9;
            var27 = IIl;
            String var10 = lIlIII.Il(lI[1]);
            var9 = var27;
            III = var9 + var10;
            return;
         }

         do {
            var17 = var13[var15] ^ var11;
            char[] var19 = var12.substring(var16, var16 + var17).toCharArray();
            int var20 = 0;

            do {
               byte var10000;
               switch (var20 % 5) {
                  case 0:
                  default:
                     var10000 = 22;
                     break;
                  case 1:
                     var10000 = 62;
                     break;
                  case 2:
                     var10000 = 68;
                     break;
                  case 3:
                     var10000 = 100;
                     break;
                  case 4:
                     var10000 = 55;
               }

               byte var21 = var10000;
               var19[var20] = (char)(var19[var20] ^ var21);
               ++var20;
            } while(var20 < var19.length);

            var14[var15] = (new String(var19)).intern();
            var16 += var17;
            ++var15;
         } while(var15 < var13.length);

         var18 = 0;
      }
   }

   public static BufferedReader ll() throws IOException {
      Path var0 = III().resolve(lIlIII.Il(lI[0]));
      if (Files.exists(var0, new LinkOption[0])) {
         return Files.newBufferedReader(var0);
      } else {
         Path var1 = I().resolve(lIlIII.Il(lI[1]));
         if (Files.exists(var1, new LinkOption[0])) {
            return Files.newBufferedReader(var1);
         } else {
            InputStream var2 = l(l);
            if (var2 != null) {
               return new BufferedReader(new InputStreamReader(var2));
            } else {
               InputStream var3 = l(III);
               return var3 == null ? null : new BufferedReader(new InputStreamReader(var3));
            }
         }
      }
   }

   private static Path III() {
      return Paths.get(System.getProperty(lIlIII.Il(lI[Ill(475787109, 1258136937)])), lIlIII.Il(lI[4]), lIlIII.Il(lI[2]), lIlIII.Il(lI[5]), lIlIII.Il(lI[3]));
   }

   public static BufferedReader IIl() throws IOException {
      Path var0 = III().resolve(lIlIII.Il(lI[Ill(475787098, 665495694)]));
      if (Files.exists(var0, new LinkOption[0])) {
         return Files.newBufferedReader(var0);
      } else {
         InputStream var1 = l(II);
         return var1 == null ? null : new BufferedReader(new InputStreamReader(var1));
      }
   }

   private static int Ill(int var0, int var1) {
      return IlI[var0 ^ 475787130] ^ var1 ^ var0;
   }

   private static String lII(int var0, int var1) {
      int var3 = var0 ^ -942391194;
      char[] var4 = Ill[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])lII[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         lII[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -2073343187;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 119;
               break;
            case 1:
               var9 = 113;
               break;
            case 2:
               var9 = 204;
               break;
            case 3:
               var9 = 56;
               break;
            case 4:
               var9 = 188;
               break;
            case 5:
               var9 = 184;
               break;
            case 6:
               var9 = 239;
               break;
            case 7:
               var9 = 41;
               break;
            case 8:
               var9 = 238;
               break;
            case 9:
               var9 = 82;
               break;
            case 10:
               var9 = 89;
               break;
            case 11:
               var9 = 62;
               break;
            case 12:
               var9 = 154;
               break;
            case 13:
               var9 = 39;
               break;
            case 14:
               var9 = 177;
               break;
            case 15:
               var9 = 95;
               break;
            case 16:
               var9 = 249;
               break;
            case 17:
               var9 = 174;
               break;
            case 18:
               var9 = 251;
               break;
            case 19:
               var9 = 243;
               break;
            case 20:
               var9 = 185;
               break;
            case 21:
               var9 = 139;
               break;
            case 22:
               var9 = 207;
               break;
            case 23:
               var9 = 210;
               break;
            case 24:
               var9 = 56;
               break;
            case 25:
               var9 = 151;
               break;
            case 26:
               var9 = 92;
               break;
            case 27:
               var9 = 231;
               break;
            case 28:
               var9 = 59;
               break;
            case 29:
               var9 = 226;
               break;
            case 30:
               var9 = 2;
               break;
            case 31:
               var9 = 139;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
