package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class IIIIllIl extends IIIIIIIlI {
   private static String[] I;
   private static final int[] l;
   private static final String[] II;
   private static final Object[] Il;

   static {
      short var6 = 15166;
      String var7 = "蓘\u128f欰ʤ\uf402ꕴꨡ뼚癯̴斃痡㓁枤佤嗯\ueb2f炚ᇟₗ넎⌾䤓¾螡ᱶ是쁒졳⽥\u1259ᜅ梫ℕ\ue826ᆿ\uebe4谷⓹漯茘ﰣ㙐镾礗絕먅弈蚢비㜇˧\udb8a\udf27⍷ሯ忎솴㩪툸獍䥅꺵羦誤ৼꑒ\u17ec딽ﵐ溓디ꠝ帛褹붂福㻉\ue8ec篻틎翿㏈ꗉㅚ鸄⾃즅뵡倦∙쭊礶Ⳍ㳠ᵚ";
      char[] var8 = "㬲㭪".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            II = var9;
            Il = new Object[var9.length];
            int var2 = -272334542;
            byte[] var0 = "\u008d\u007fF\u0084\u0002O\u0019¢?\u0083Ï¸*\u0018¢\u0085".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            l = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               l[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            I = new String[2];
            ll();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static void ll() {
      I[0] = IlI(llI(187202255, 740974242).toCharArray(), 45634L, lII(504005686, -365268608));
      I[1] = IlI(llI(187202254, -880649493).toCharArray(), 55896L, lII(504005687, 1697538086));
   }

   public IIIIllIl() {
      super((Object)lIlIII.l(I[0]), lIllII.ll, (Object)lIlIII.l(I[1]));
   }

   private static String IlI(char[] var0, long var1, int var3) {
      int var4 = lII(504005684, 151506390) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & lII(504005685, -606689411);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private static int lII(int var0, int var1) {
      return l[var0 ^ 504005686] ^ var1 ^ var0;
   }

   private static String llI(int var0, int var1) {
      int var3 = var0 ^ 187202255;
      char[] var4 = II[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])Il[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         Il[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 1754436224;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 93;
               break;
            case 1:
               var9 = 10;
               break;
            case 2:
               var9 = 26;
               break;
            case 3:
               var9 = 54;
               break;
            case 4:
               var9 = 21;
               break;
            case 5:
               var9 = 174;
               break;
            case 6:
               var9 = 10;
               break;
            case 7:
               var9 = 148;
               break;
            case 8:
               var9 = 11;
               break;
            case 9:
               var9 = 119;
               break;
            case 10:
               var9 = 214;
               break;
            case 11:
               var9 = 223;
               break;
            case 12:
               var9 = 5;
               break;
            case 13:
               var9 = 253;
               break;
            case 14:
               var9 = 75;
               break;
            case 15:
               var9 = 15;
               break;
            case 16:
               var9 = 107;
               break;
            case 17:
               var9 = 152;
               break;
            case 18:
               var9 = 247;
               break;
            case 19:
               var9 = 64;
               break;
            case 20:
               var9 = 137;
               break;
            case 21:
               var9 = 21;
               break;
            case 22:
               var9 = 114;
               break;
            case 23:
               var9 = 6;
               break;
            case 24:
               var9 = 245;
               break;
            case 25:
               var9 = 196;
               break;
            case 26:
               var9 = 44;
               break;
            case 27:
               var9 = 250;
               break;
            case 28:
               var9 = 205;
               break;
            case 29:
               var9 = 78;
               break;
            case 30:
               var9 = 23;
               break;
            case 31:
               var9 = 4;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
