package x;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class IIIIlIIII extends llllllI<String> {
   private static String[] I;
   private final List<String> l;
   private int II;
   private static final int[] Il;
   private static final String[] lII;
   private static final Object[] lIl;

   private static String I(char[] var0, long var1, int var3) {
      int var4 = IIII(1008623597, -909754448) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IIII(1008623596, 1770285926);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   public List<String> ll() {
      return this.l;
   }

   private static void IlI() {
      I[0] = I("".toCharArray(), 5833L, IIII(1008623599, -1829446202));
      I[1] = I(IIIl('⤡', (short)'죰', 1322601753).toCharArray(), 34906L, IIII(1008623598, -1694533224));
   }

   public void II(JsonElement var1) {
      if (var1 != null && var1.isJsonPrimitive()) {
         this.llI(var1.getAsString());
      }

   }

   public void Ill() {
      this.II = (this.II - 1 + this.l.size()) % this.l.size();
      super.Il((String)this.l.get(this.II));
   }

   static {
      short var6 = 16999;
      String var7 = "댐霏䏡涶䳣藤す䗍";
      char[] var8 = "䉯".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            lII = var9;
            lIl = new Object[var9.length];
            int var2 = -1840154723;
            byte[] var0 = "d»¥\u000bÇËCèË\u0007Å\tpF÷D".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            Il = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               Il[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            I = new String[2];
            IlI();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 112;
                     break;
                  case 1:
                     var10000 = 60;
                     break;
                  case 2:
                     var10000 = 125;
                     break;
                  case 3:
                     var10000 = 26;
                     break;
                  case 4:
                     var10000 = 97;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public void lII() {
      this.II = (this.II + 1) % this.l.size();
      super.Il((String)this.l.get(this.II));
   }

   public JsonElement lI() {
      return new JsonPrimitive((String)this.III());
   }

   public int lIl() {
      return this.II;
   }

   public void llI(String var1) {
      int var2 = this.l.indexOf(var1);
      if (var2 >= 0) {
         this.II = var2;
         super.Il(var1);
      } else {
         this.II = 0;
         super.Il((String)this.l.get(0));
      }

   }

   public IIIIlIIII(Object var1, List<String> var2) {
      super((Object)var1, I[0]);
      this.l = var2;
      this.II = 0;
   }

   public String lll() {
      String var1 = (String)this.III();
      return var1.isEmpty() ? lIlIII.Il(I[1]) : var1;
   }

   private static int IIII(int var0, int var1) {
      return Il[var0 ^ 1008623597] ^ var1 ^ var0;
   }

   private static String IIIl(char var0, short var1, int var2) {
      int var3 = var0 ^ 10529;
      char[] var4 = lII[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])lIl[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         lIl[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 15516;
      int var9 = 0;

      do {
         int var10 = var4[var9] ^ 28867;
         var10 -= 36229;
         var10 ^= 52777;
         var10 += 52842;
         var10 -= 42547;
         var4[var9] = (char)(var10 ^ var8 ^ var1 ^ var2 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
