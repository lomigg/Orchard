package x;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11909;

@Environment(EnvType.CLIENT)
final class IIIlIIIll {
   private final List<<undefinedtype>> I = new ArrayList();
   private final List<<undefinedtype>> l = new ArrayList();

   void I() {
      this.I.clear();
   }

   void l(double var1, double var3, double var5, double var7) {
      if (!(var5 <= (double)0.0F) && !(var7 <= (double)0.0F)) {
         this.l.add(new Record(var1, var3, var5, var7) {
            private final double I;
            private final double l;
            private final double II;
            private final double Il;

            public double I() {
               return this.II;
            }

            public double l() {
               return this.Il;
            }

            private {
               this.l = var1;
               this.I = var3;
               this.II = var5;
               this.Il = var7;
            }

            public double II() {
               return this.I;
            }

            public double Il() {
               return this.l;
            }
         });
      } else {
         this.l.add(new Record((double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F) {
            private final double I;
            private final double l;
            private final double II;
            private final double Il;

            public double I() {
               return this.II;
            }

            public double l() {
               return this.Il;
            }

            private {
               this.l = var1;
               this.I = var3;
               this.II = var5;
               this.Il = var7;
            }

            public double II() {
               return this.I;
            }

            public double Il() {
               return this.l;
            }
         });
      }
   }

   boolean II(double var1, double var3, double var5, double var7) {
      for(int var9 = this.I.size() - 1; var9 >= 0; --var9) {
         <undefinedtype> var10 = (<undefinedtype>)this.I.get(var9);
         if (var10.Il != null && var10.I(var1, var3) && var10.Il.I(var1, var3, var5, var7)) {
            return true;
         }
      }

      return false;
   }

   void Il() {
      if (!this.l.isEmpty()) {
         this.l.remove(this.l.size() - 1);
      }

   }

   boolean lI(class_11909 var1, boolean var2) {
      for(int var3 = this.I.size() - 1; var3 >= 0; --var3) {
         <undefinedtype> var4 = (<undefinedtype>)this.I.get(var3);
         if (var4.I != null && var4.I(var1.comp_4798(), var1.comp_4799()) && var4.I.I(var1, var2)) {
            return true;
         }
      }

      return false;
   }

   void ll(double var1, double var3, double var5, double var7, Object var9, Object var10) {
      if (!(var5 <= (double)0.0F) && !(var7 <= (double)0.0F)) {
         double var11 = var1;
         double var13 = var3;
         double var15 = var5;
         double var17 = var7;

         for(<undefinedtype> var20 : this.l) {
            double var21 = Math.max(var11, var20.l);
            double var23 = Math.max(var13, var20.I);
            double var25 = Math.min(var11 + var15, var20.l + var20.II);
            double var27 = Math.min(var13 + var17, var20.I + var20.Il);
            var11 = var21;
            var13 = var23;
            var15 = var25 - var21;
            var17 = var27 - var23;
            if (var15 <= (double)0.0F || var17 <= (double)0.0F) {
               return;
            }
         }

         this.I.add(new Record(var11, var13, var15, var17, var9, var10) {
            private final <undefinedtype> I;
            private final double l;
            private final double II;
            private final <undefinedtype> Il;
            private final double lI;
            private final double ll;

            boolean I(double var1, double var3) {
               return var1 >= this.II && var1 <= this.II + this.l && var3 >= this.lI && var3 <= this.lI + this.ll;
            }

            public double l() {
               return this.lI;
            }

            private {
               this.II = var1;
               this.lI = var3;
               this.l = var5;
               this.ll = var7;
               this.I = var9;
               this.Il = var10;
            }

            public double II() {
               return this.II;
            }

            public <undefinedtype> Il() {
               return this.Il;
            }

            public double lI() {
               return this.l;
            }

            public double ll() {
               return this.ll;
            }

            public <undefinedtype> III() {
               return this.I;
            }
         });
      }
   }

   void III(double var1, double var3, double var5, double var7, Object var9) {
      this.ll(var1, var3, var5, var7, var9, null);
   }
}
