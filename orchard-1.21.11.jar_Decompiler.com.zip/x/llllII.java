package x;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Locale;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_364;
import net.minecraft.class_412;
import net.minecraft.class_4185;
import net.minecraft.class_419;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_500;
import net.minecraft.class_639;
import net.minecraft.class_642;

@Environment(EnvType.CLIENT)
public final class llllII extends IIIIIIIlI {
   private class_642 I;
   private long l;
   private Object II;
   private static String[] Il;
   private final IIIllIIII lI;
   private static final int[] ll;
   private static final String[] III;
   private static final Object[] IIl;

   private static String ll(char[] var0, long var1, int var3) {
      int var4 = lllI(-1048717523, -839599511) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & lllI(-1048717524, -1538279050);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private void IlI(class_310 var1) {
      if (!var1.method_1542()) {
         class_642 var2 = var1.method_1558();
         if (var2 != null && var2.field_3761 != null && !var2.field_3761.isBlank()) {
            this.I = this.IlII(var2);
         }
      }
   }

   private void lII() {
      this.II = null;
      this.l = 0L;
   }

   public void lI() {
      this.lII();
   }

   private boolean llI(class_4185 var1) {
      if (var1 == null) {
         return false;
      } else {
         try {
            Method var11 = var1.getClass().getMethod(lIlIII.Il(Il[5]));
            var11.invoke(var1);
            return true;
         } catch (ReflectiveOperationException var10) {
            for(Method var5 : var1.getClass().getMethods()) {
               if (var5.getName().equals(lIlIII.Il(Il[5])) && var5.getParameterCount() == 1) {
                  Class var6 = var5.getParameterTypes()[0];
                  Object var7 = var6.isInterface() ? Proxy.newProxyInstance(var6.getClassLoader(), new Class[]{var6}, (var0, var1x, var2) -> {
                     String var3 = var1x.getName();
                     byte var4 = -1;
                     switch (var3.hashCode()) {
                        case -1901045636:
                           if (var3.equals(Il[4])) {
                              var4 = 1;
                           }
                           break;
                        case -1776922004:
                           if (var3.equals(Il[1])) {
                              var4 = 3;
                           }
                           break;
                        case -1417910757:
                           if (var3.equals(Il[3])) {
                              var4 = 2;
                           }
                           break;
                        case 221855894:
                           if (var3.equals(Il[0])) {
                              var4 = 0;
                           }
                     }

                     Object var10000;
                     switch (var4) {
                        case 0:
                        case 1:
                        case 2:
                           var10000 = 0;
                           break;
                        case 3:
                           var10000 = lIlIII.Il(Il[2]);
                           break;
                        default:
                           var10000 = var1x.getReturnType() == Boolean.TYPE ? Boolean.FALSE : 0;
                     }

                     return var10000;
                  }) : null;

                  try {
                     var5.invoke(var1, var7);
                     return true;
                  } catch (ReflectiveOperationException var9) {
                  }
               }
            }

            return false;
         }
      }
   }

   private boolean IIII(class_419 var1) {
      if (var1 == null) {
         return false;
      } else {
         for(class_364 var3 : var1.method_25396()) {
            if (var3 instanceof class_4185) {
               class_4185 var4 = (class_4185)var3;
               if (this.llII(var4) && this.llI(var4)) {
                  return true;
               }
            }
         }

         return false;
      }
   }

   private class_437 IIll(class_419 var1) {
      class_437 var2 = this.IlIl(var1);
      return var2 != null ? var2 : this.lIII();
   }

   private class_642 IlII(class_642 var1) {
      if (var1 == null) {
         return null;
      } else {
         class_642 var2 = new class_642(var1.field_3752, var1.field_3761, var1.method_55616());
         var2.method_44292(var1);
         return var2;
      }
   }

   private class_437 IlIl(class_419 var1) {
      if (var1 == null) {
         return null;
      } else {
         try {
            Field var2 = class_419.class.getDeclaredField(lIlIII.Il(Il[lllI(-1048717521, -512639673)]));
            var2.setAccessible(true);
            Object var3 = var2.get(var1);
            if (var3 instanceof class_437) {
               class_437 var4 = (class_437)var3;
               return var4;
            } else {
               return null;
            }
         } catch (ReflectiveOperationException var5) {
            return null;
         }
      }
   }

   private static void Illl() {
      Il[0] = ll(IIIII(-1325461772, -1368519940).toCharArray(), 63833L, lllI(-1048717522, -1117876684));
      Il[1] = ll(IIIII(-1325461771, -479572816).toCharArray(), 89216L, lllI(-1048717527, -337070384));
      Il[2] = ll(IIIII(-1325461770, -874436946).toCharArray(), 68605L, lllI(-1048717528, 1348869700));
      Il[3] = ll(IIIII(-1325461769, -740009241).toCharArray(), 13601L, lllI(-1048717525, 1062612296));
      Il[4] = ll(IIIII(-1325461776, -1456522681).toCharArray(), 83902L, lllI(-1048717526, 1763624415));
      Il[5] = ll(IIIII(-1325461775, 1059342466).toCharArray(), 7702L, lllI(-1048717531, -946364888));
      Il[lllI(-1048717532, 1698616966)] = ll(IIIII(-1325461774, 1904150912).toCharArray(), 80986L, lllI(-1048717529, 970827334));
      Il[lllI(-1048717530, -2992634)] = ll(IIIII(-1325461773, -941421025).toCharArray(), 20369L, lllI(-1048717535, -1460513803));
      Il[lllI(-1048717536, 224120485)] = ll("".toCharArray(), 69992L, lllI(-1048717533, -1119709971));
      Il[lllI(-1048717534, -360634752)] = ll(IIIII(-1325461764, -1924581373).toCharArray(), 52207L, lllI(-1048717507, -995811788));
      Il[lllI(-1048717508, 1700697288)] = ll(IIIII(-1325461763, -1180995939).toCharArray(), 26624L, lllI(-1048717505, 1221415568));
      Il[lllI(-1048717506, 1222299009)] = ll(IIIII(-1325461762, -343572514).toCharArray(), 19595L, lllI(-1048717511, -2099078161));
      Il[lllI(-1048717512, 560784750)] = ll(IIIII(-1325461761, 806442782).toCharArray(), 69958L, lllI(-1048717509, -1831030022));
      Il[lllI(-1048717510, -1155688683)] = ll(IIIII(-1325461768, 900167135).toCharArray(), 70635L, lllI(-1048717515, 1915773816));
   }

   public String Il() {
      double var1 = (Double)this.lI.III();
      if (Math.abs(var1 - Math.rint(var1)) < 0.001) {
         int var10000 = (int)Math.rint(var1);
         String var4 = lIlIII.Il(Il[lllI(-1048717516, 1021477576)]);
         int var3 = var10000;
         return var3 + var4;
      } else {
         return String.format(Locale.ROOT, lIlIII.Il(Il[lllI(-1048717513, 2065780397)]), var1);
      }
   }

   private class_437 lIII() {
      return new class_500(new class_442());
   }

   private boolean lIIl(class_310 var1) {
      if (!var1.method_1542() && this.I != null) {
         String var2 = this.I.field_3761;
         return var2 != null && !var2.isBlank() && class_639.method_36224(var2) && !lllIlIl.II(var2);
      } else {
         return false;
      }
   }

   private boolean llII(class_4185 var1) {
      if (var1 != null && var1.field_22763 && var1.field_22764) {
         String var2 = var1.method_25369() == null ? Il[lllI(-1048717514, 1643986675)] : var1.method_25369().getString();
         return var2 != null && var2.toLowerCase(Locale.ROOT).contains(lIlIII.Il(Il[lllI(-1048717519, 932637031)]));
      } else {
         return false;
      }
   }

   static {
      short var6 = 21941;
      String var7 = "璁놁\uf813㭽뙽⍻᠄敀\uea9b\uf716\uf1e1饯\ue0c9\uf886꜏⩇佔䊔괈璌僚雄 완⥔医\u1311☴䍵\udd1e횘虋ᖩ拑퍁쥸럚銡刽텹\uf79cᅅ\ue22b졭楇鎹し䗈\ueff1ׯ\udc63\u1f7e뿿㩊탴着띪젼㼸豛虷\udc60齗ᑒ\uf52a窤젨껐⟞㶒銨稷‒䨒\uebbe蘎귽異植部ዸ▜᰿\ud886酉࡞\ueb6d챜\uf6adဴ掊퍌\uee56㻹\u197c\u0015༳ꋑᜌ㇢\uda97෧浖㚘搣灢캙㿒裁ᛨ昖ղ뻨䅵\uee04햻⭶㍄Ⱊ섥︗\u0efc䠛ᠵ餠０䵕⅗麟즯筬哙㕌뚆띲ᰞⱒ윜\uf6f7닉駻\udb66詆绉Ắб㖒쥓휃뉅롲掿캾몃馫뻶쥟\uf2e2\u0feb\ue2fd☏短岗䴤ɇ\ue649똑䵘⸧⟓䱭㒘ᠷ嬗\ueefc댦ᾼ㺁㜵\ue5c4彝ⵝ豢竏漒䆲땗㨡≴・ჯ\ud8e9됮ޜ\uf22b튦㫹闷\uaac8♲蜌鎀颅菕䭬⌤殮屪橀ꟓ\uf3fa땆❊烇䇫ꤞᯟ騘വ礨Ḕ竉Ꭿ";
      char[] var8 = "\n\b\u0018\b\t\f\u0004\b\f\b\\\b\u0014".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            III = var9;
            IIl = new Object[var9.length];
            int var2 = -1574013351;
            byte[] var0 = "¢ÑÁ¾Ç\u001c\u0018ü\u0082\"\u001c;a\u0087Æ\u009aN[ø¥ßö\"¼·I`M_\u009et×7Þ¿\u0090\u0006mwýåEû¡\u009c\u0081÷~ô|\u0004\u009an\boÔ\u0002 #µ\u0089Ò\u0087ò\u007fUpq\u0006\r5§ê\u0017s\u0005+\u0089lí?\u0007@@B?D\u0003|`®\u007fØN6{\u0098\u0097Uø_±#£\u0018rïÄ\u0002®\u009f\u0094TÅH\u0006ÑW@Eb\u00024 ÂÊ\u0099å\u0098\u0016xuÕÚ\u0080H".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            ll = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               ll[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            Il = new String[lllI(-1048717520, -1308303070)];
            Illl();
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 82;
                     break;
                  case 1:
                     var10000 = 15;
                     break;
                  case 2:
                     var10000 = 7;
                     break;
                  case 3:
                     var10000 = 91;
                     break;
                  case 4:
                     var10000 = 109;
                     break;
                  case 5:
                     var10000 = 45;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public llllII() {
      super((Object)lIlIII.l(Il[lllI(-1048717517, 22123975)]), lIllII.l, (Object)lIlIII.l(Il[lllI(-1048717518, -1583794043)]));
      this.lI = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(Il[lllI(-1048717555, -79308499)]), (double)3.0F, (double)0.5F, (double)30.0F, (double)0.5F)).IIl(lIlIII.Il(Il[lllI(-1048717556, -1232527077)])));
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (var1 == null) {
         this.lII();
      } else {
         this.IlI(var1);
         class_437 var3 = var1.field_1755;
         if (var3 instanceof class_419) {
            class_419 var2 = (class_419)var3;
            if (!this.lIIl(var1)) {
               this.lII();
            } else {
               long var6 = System.nanoTime() / 1000000L;
               if (this.II != var2) {
                  this.II = var2;
                  this.l = var6 + Math.max(0L, Math.round((Double)this.lI.III() * (double)1000.0F));
               } else if (var6 >= this.l) {
                  if (this.IIII(var2)) {
                     this.lII();
                  } else {
                     class_642 var5 = this.IlII(this.I);
                     if (var5 == null) {
                        this.lII();
                     } else {
                        this.lII();
                        class_412.method_36877(this.IIll(var2), var1, class_639.method_2950(var5.field_3761), var5, false, IlIIllIl.I());
                     }
                  }
               }
            }
         } else {
            this.lII();
         }
      }
   }

   private static int lllI(int var0, int var1) {
      return ll[var0 ^ -1048717523] ^ var1 ^ var0;
   }

   private static String IIIII(int var0, int var1) {
      int var3 = var0 ^ -1325461772;
      char[] var4 = III[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IIl[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IIl[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -1878750042;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 115;
               break;
            case 1:
               var9 = 226;
               break;
            case 2:
               var9 = 239;
               break;
            case 3:
               var9 = 142;
               break;
            case 4:
               var9 = 87;
               break;
            case 5:
               var9 = 180;
               break;
            case 6:
               var9 = 30;
               break;
            case 7:
               var9 = 187;
               break;
            case 8:
               var9 = 0;
               break;
            case 9:
               var9 = 103;
               break;
            case 10:
               var9 = 70;
               break;
            case 11:
               var9 = 189;
               break;
            case 12:
               var9 = 237;
               break;
            case 13:
               var9 = 162;
               break;
            case 14:
               var9 = 171;
               break;
            case 15:
               var9 = 31;
               break;
            case 16:
               var9 = 176;
               break;
            case 17:
               var9 = 108;
               break;
            case 18:
               var9 = 2;
               break;
            case 19:
               var9 = 163;
               break;
            case 20:
               var9 = 133;
               break;
            case 21:
               var9 = 49;
               break;
            case 22:
               var9 = 118;
               break;
            case 23:
               var9 = 125;
               break;
            case 24:
               var9 = 65;
               break;
            case 25:
               var9 = 106;
               break;
            case 26:
               var9 = 168;
               break;
            case 27:
               var9 = 200;
               break;
            case 28:
               var9 = 22;
               break;
            case 29:
               var9 = 41;
               break;
            case 30:
               var9 = 229;
               break;
            case 31:
               var9 = 255;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
