package x;

import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1294;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_746;

@Environment(EnvType.CLIENT)
public final class IlIIIlIII extends IIIIIIIlI {
   private static final float I = 0.5F;
   private static final long l = 1000L;
   private <undefinedtype> II;
   private static final long Il = 2000L;
   private int lI;
   private float ll;
   private static final int III = 2;
   private static final int IIl = 40;
   private static final long IlI = 50L;
   private long Ill;
   private <undefinedtype> lII;
   private long lIl;
   private <undefinedtype> llI;
   private static final int lll = 9;
   private long IIII;
   private float IIIl;
   private final IlIIIlIlI<<undefinedtype>> IIlI;
   private long IIll;
   private boolean IlII;
   private <undefinedtype> IlIl;
   private int IllI;
   private class_243 Illl;
   private long lIII;
   private static final int lIIl = 1;
   private final lIIIIl lIlI;
   private static String[] lIll;
   private final IIIllIIII llII;
   private final llllIlIl llIl;
   private final IlIlIll lllI;
   private static final int llll = 2;
   private int IIIII;
   private static final int[] IIIIl;
   private static final String[] IIIlI;
   private static final Object[] IIIll;

   public void lI() {
      class_310 var1 = class_310.method_1551();
      if (this.IlII && var1 != null && var1.field_1724 != null) {
         IlIlIl.IllI(var1, this.ll, this.IIIl);
      }

      this.IllIl(var1);
      this.lllI.IIIlIll();
      this.IIII();
      this.IIII = 0L;
   }

   private void ll(class_310 var1) {
      if (this.IlII && var1 != null && var1.field_1724 != null && this.IIlI.III() == null.II) {
         IlIlIl.IllI(var1, this.ll, this.IIIl);
      }

      this.IllIl(var1);
      this.IIII();
      this.IIII = 0L;
   }

   private void IlI(class_310 var1, long var2) {
      if (this.IIlIl(var1, null.I) && IllllIlI.lIllI(var1) <= 0) {
         Record var4 = new Record(null.I, 0) {
            private final int I;
            private final <undefinedtype> l;

            public <undefinedtype> I() {
               return this.l;
            }

            private {
               this.l = var1;
               this.I = var2;
            }

            private <undefinedtype> l(int var1) {
               return new <anonymous constructor>(this.l, var1);
            }

            public int II() {
               return this.I;
            }
         };
         if (!this.IIll(var1, var4)) {
            this.lII = var4;
         }

      } else {
         this.ll(var1);
      }
   }

   private void lII(class_310 var1, long var2) {
      this.IIII();
      this.IIII = 0L;
   }

   private void llI(class_310 var1, long var2) {
      if (!this.IIIll(var1)) {
         this.ll(var1);
      } else if (!this.IIlIl(var1, null.I)) {
         this.ll(var1);
      } else {
         class_746 var4 = var1.field_1724;
         if (this.IIlI.III() == null.II) {
            this.IlII = true;
            this.Illl = var4.method_33571().method_1031((double)0.0F, (double)-2.0F, (double)0.0F);
            this.IIll = var2;
            this.lI = 0;
            this.IlIl = null.Il;
            this.Ill = var2;
         } else {
            Record var5 = new Record(null.I, 0) {
               private final int I;
               private final <undefinedtype> l;

               public <undefinedtype> I() {
                  return this.l;
               }

               private {
                  this.l = var1;
                  this.I = var2;
               }

               private <undefinedtype> l(int var1) {
                  return new <anonymous constructor>(this.l, var1);
               }

               public int II() {
                  return this.I;
               }
            };
            if (!this.IIll(var1, var5)) {
               this.lII = var5;
            }

         }
      }
   }

   private void IIII() {
      ++this.lIII;
      this.II = null;
      this.lII = null;
      this.IlIl = null.lI;
      this.Ill = 0L;
      this.lIl = 0L;
      this.IllI = -1;
      this.IIIII = -1;
      this.IlII = false;
      this.llI = null;
      this.Illl = null;
      this.IIll = 0L;
      this.lI = 0;
   }

   private boolean IIll(class_310 var1, Object var2) {
      if (var2 != null && this.IIlIl(var1, var2.I()) && IllllIlI.lIllI(var1) <= 0) {
         if (this.IIlI.III() == null.I) {
            return this.IIlII(var1, var2);
         } else {
            float var3 = var1.field_1724.method_36454();
            long var4 = ++this.lIII;
            boolean var6 = var2.I() == null.I ? IlIlIl.IIlIII(var1, lIIIl(2131181295, -1342254973), this.lIll(var1.field_1724), () -> this.lllI(var1, var4, var2)) : IlIlIl.IIIlIl(var1, lIIIl(2131181294, 1113893492), var3, 90.0F, () -> this.lllI(var1, var4, var2));
            if (!var6) {
               ++this.lIII;
               return false;
            } else {
               int var7 = var2.I() == null.I ? 2 : 1;
               this.II = new Record(var4, var2, var1.field_1724.field_6012 + var7) {
                  private final long I;
                  private final int l;
                  private final <undefinedtype> II;

                  public long I() {
                     return this.I;
                  }

                  public <undefinedtype> l() {
                     return this.II;
                  }

                  private {
                     this.I = var1;
                     this.II = var3;
                     this.l = var4;
                  }

                  public int II() {
                     return this.l;
                  }
               };
               return true;
            }
         }
      } else {
         return false;
      }
   }

   private boolean IlII(class_310 var1) {
      class_746 var2 = var1.field_1724;
      return var2 != null && var2.method_6059(class_1294.field_5918);
   }

   private void IlIl(class_310 var1, long var2) {
      class_746 var4 = var1.field_1724;
      if (this.IlII && this.IIlI.III() == null.II) {
         IlIlIl.IllI(var1, this.ll, this.IIIl);
      }

      this.IlII = false;
      this.llI = null;
      if (!(Boolean)this.lIlI.III()) {
         IllllIlI.IlII(var1, this, null.Il);
      } else if (this.IIIII >= 0 && this.IIIII < lIIIl(2131181293, -1382484391)) {
         IllllIlI.llIIlI(var1, this, this.IIIII);
      } else {
         IllllIlI.IlII(var1, this, null.II);
      }

      this.lII(var1, var2);
   }

   private static void Illl() {
      lIll[0] = IIIIl(lIIlI(52845, 381186763, 23280).toCharArray(), 60631L, lIIIl(2131181292, -305701343));
      lIll[1] = IIIIl(lIIlI(44067, -724942007, 23281).toCharArray(), 74815L, lIIIl(2131181291, -819457968));
      lIll[2] = IIIIl(lIIlI(62117, -618247659, 23282).toCharArray(), 80905L, lIIIl(2131181290, -1632281667));
      lIll[3] = IIIIl(lIIlI(33261, -38466081, 23283).toCharArray(), 93583L, lIIIl(2131181289, -1514630074));
      lIll[4] = IIIIl(lIIlI(50971, -2106322162, 23284).toCharArray(), 85178L, lIIIl(2131181288, -115734069));
      lIll[5] = IIIIl(lIIlI(31489, -106802854, 23285).toCharArray(), 17428L, lIIIl(2131181287, -1637146965));
      lIll[lIIIl(2131181286, 1613251413)] = IIIIl(lIIlI(35635, 1138560872, 23286).toCharArray(), 95804L, lIIIl(2131181285, 2062830966));
   }

   private int lIII(llllIlIl var1) {
      return Math.max(0, (int)Math.ceil((double)this.lIIII(var1) / (double)50.0F));
   }

   private void lIIl(class_310 var1, long var2) {
      if (!this.IIIII(var1, var2)) {
         if (this.lII != null) {
            this.IlIll(var1, var2);
         } else {
            switch (this.IlIl.ordinal()) {
               case 1:
                  if (var2 > this.lIl) {
                     this.ll(var1);
                     return;
                  }

                  if (!IllllIlI.IIII(var1, this.llI)) {
                     this.llI = IllllIlI.lIll(var1, this, this.IllI, 0, true);
                     this.IIII = Long.MAX_VALUE;
                  }

                  if (!IllllIlI.IlIllII(var1, this.llI)) {
                     return;
                  }

                  if (this.IIII == Long.MAX_VALUE) {
                     this.IIII = var2 + 0L;
                  }

                  if (var2 < this.IIII) {
                     return;
                  }

                  this.llI(var1, var2);
                  break;
               case 2:
                  if (var2 - this.IIll >= 2000L) {
                     this.IlI(var1, var2);
                     return;
                  }

                  if (this.Illl == null) {
                     this.IlI(var1, var2);
                     return;
                  }

                  float var4 = this.lllI.IlIl(var1, this.Illl, ((Double)this.llII.III()).floatValue());
                  ++this.lI;
                  if (var4 <= 0.5F || this.lI >= lIIIl(2131181284, -2026222265)) {
                     this.IlI(var1, var2);
                  }
                  break;
               case 3:
                  if (var2 >= this.IIII) {
                     this.Illll(var1, var2);
                  }
                  break;
               case 4:
                  if (var2 >= this.IIII) {
                     this.IlIl(var1, var2);
                  }
            }

         }
      }
   }

   private class_243 lIll(class_746 var1) {
      return new class_243(var1.method_23317(), var1.method_23318() - (double)0.125F, var1.method_23321());
   }

   static {
      short var6 = 7683;
      String var7 = "楡론鄞緺团ꚿ\uf045\uf8b8ꔜ䢓\uf0e8\udf72둩\ue81c榀零➹㼱நﳔ뻈쫶桤ªⲃ羍礦◓\uea74䒜\udff1칿ᄹꌿ⁊ꀰ癹\uf3a5হ녞ຘ퓻샆舢寴刃웽煳烙Ȇᕷ彋畩㰎糚烯襧\ue4e2츊쁞赾ﻧ斩弾昡❩℘亹칩藴鈶暑\uf229ᠻ鰮⋩\ue143娏綂⏣쒖ﾒ㸧啊ॳ\ueb5e堅䩴\uda07؉驋\u2d6d\u0efb䀠ᇼ䛬\ue91c䋔磌醍撝똳横䄨웑댙᳸將\uee74〇壳沘熹ᛙ巭㲽糌೨쾴\ue9c5蘡㨬㖠鄓쟴퉟鮡驥\udd01讀\uea78領뤫땶\u0001婆궹슄运㒧ꐲ烈퀖妹ჱ\ue437䢁ꎚ\uedbd圹䆩\ue609䋚⫭突ꟲ";
      char[] var8 = "L\u0010\u0004\f\u0010\u0010\u0010".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            IIIlI = var9;
            IIIll = new Object[var9.length];
            int var2 = -116362707;
            byte[] var0 = ")é\u009c»ÄsæM+\u008fº\u0090æóg£ÞTï3YèÁü¿tÛÝu©b\u0086Ô\u0010¹Ìæ?\u000f\u0098\u009a©\u001e\u0093\u0001-\u0001¦zÔ\u0088Ýw\u008d\u0099ññ,YIC&¹îÝ\u0015IIU\u009eð3".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IIIIl = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IIIIl[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            lIll = new String[lIIIl(2131181283, -54279148)];
            Illl();
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 76;
                     break;
                  case 1:
                     var10000 = 79;
                     break;
                  case 2:
                     var10000 = 80;
                     break;
                  case 3:
                     var10000 = 103;
                     break;
                  case 4:
                     var10000 = 46;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private int llII(class_746 var1) {
      for(int var2 = 0; var2 < lIIIl(2131181282, -241511113); ++var2) {
         class_1799 var3 = var1.method_31548().method_5438(var2);
         if (var3 != null && var3.method_31574(class_1802.field_8705)) {
            return var2;
         }
      }

      return -1;
   }

   private boolean lllI(class_310 var1, long var2, Object var4) {
      <undefinedtype> var5 = this.II;
      if (var5 != null && var5.I() == var2) {
         this.II = null;
         this.lII = null;
         boolean var6 = this.IlIIl(var1, var4.I());
         long var7 = System.currentTimeMillis();
         if (!var6) {
            if (var4.I() == null.I) {
               this.ll(var1);
            } else if (var7 - this.Ill >= 1000L) {
               this.IlIl(var1, var7);
            } else {
               this.IIII = var7 + 50L;
            }

            return false;
         } else {
            if (var4.I() == null.I) {
               if (this.IIlI.III() == null.II) {
                  var1.field_1724.method_36457(90.0F);
               }

               this.IlIl = null.III;
               this.Ill = var7;
               this.IIII = var7 + 0L;
            } else {
               this.IlIl = null.l;
               this.Ill = var7;
               this.IIII = var7;
            }

            return true;
         }
      } else {
         return false;
      }
   }

   public void lIl() {
      this.IIII();
      this.IIII = 0L;
      this.lllI.IIlIIII();
   }

   private boolean IIIII(class_310 var1, long var2) {
      <undefinedtype> var4 = this.II;
      if (var4 == null) {
         return false;
      } else if (var1.field_1724.field_6012 <= var4.II()) {
         return true;
      } else {
         this.II = null;
         ++this.lIII;
         <undefinedtype> var5 = var4.l();
         if (var5.II() >= 2) {
            if (var5.I() == null.I) {
               this.ll(var1);
            } else if (var2 - this.Ill >= 1000L) {
               this.IlIl(var1, var2);
            } else {
               this.IIII = var2 + 50L;
            }

            return true;
         } else {
            this.lII = var5.l(var5.II() + 1);
            return false;
         }
      }
   }

   private static String IIIIl(char[] var0, long var1, int var3) {
      int var4 = lIIIl(2131181281, 616314234) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & lIIIl(2131181280, -986581540);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private boolean IIIll(class_310 var1) {
      class_746 var2 = var1.field_1724;
      return var2 != null && var2.method_24828();
   }

   public IlIIIlIII() {
      super((Object)lIlIII.l(lIll[lIIIl(2131181311, 1526859165)]), lIllII.l, (Object)lIlIII.l(lIll[0]));
      this.IIlI = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(lIll[4]), <undefinedtype>.class, null.I));
      this.llIl = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(lIll[1]), (double)0.0F, (double)0.0F, (double)0.0F, (double)300.0F, (double)5.0F)).IIII(lIlIII.Il(lIll[2])));
      this.lIlI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lIll[5]), true));
      this.llII = (IIIllIIII)this.IIIlIll((IIIllIIII)(new IIIllIIII(lIlIII.l(lIll[3]), (double)50.0F, (double)1.0F, (double)100.0F, (double)1.0F)).lIII(() -> this.IIlI.III() == null.II));
      this.lllI = new IlIlIll();
      this.IlIl = null.lI;
      this.IllI = -1;
      this.IIIII = -1;
      this.llI = null;
   }

   private boolean IIlII(class_310 var1, Object var2) {
      if (var2 != null && this.IIlIl(var1, var2.I()) && IllllIlI.lIllI(var1) <= 0) {
         class_746 var3 = var1.field_1724;
         float var4 = var3.method_36454();
         float var5 = var3.method_36455();
         float var6 = var3.field_3932;
         float var7 = var3.field_3931;
         float var8 = var3.field_3916;
         float var9 = var3.field_3914;

         try {
            var3.method_36457(90.0F);
            class_1269 var10 = var1.field_1761.method_2919(var1.field_1724, class_1268.field_5808);
            if (var10 == null || !var10.method_23665()) {
               boolean var11 = false;
               return var11;
            }
         } finally {
            var3.method_36456(var4);
            var3.method_36457(var5);
            var3.field_3932 = var6;
            var3.field_3931 = var7;
            var3.field_3916 = var8;
            var3.field_3914 = var9;
         }

         long var15 = System.currentTimeMillis();
         this.II = null;
         this.lII = null;
         if (var2.I() == null.I) {
            this.IlIl = null.III;
            this.Ill = var15;
            this.IIII = var15 + 0L;
         } else {
            this.IlIl = null.l;
            this.Ill = var15;
            this.IIII = var15;
         }

         return true;
      } else {
         return false;
      }
   }

   private boolean IIlIl(class_310 var1, Object var2) {
      if (var1 != null && var1.field_1724 != null && this.IllI >= 0 && this.IllI < lIIIl(2131181310, -745947927)) {
         if (IllllIlI.IIlIl(var1) == this.IllI && IllllIlI.IIlIIlI(var1, this.IllI)) {
            boolean var10000;
            label49: {
               class_1799 var3 = var1.field_1724.method_31548().method_5438(this.IllI);
               if (var3 != null) {
                  if (var2 == null.I) {
                     if (var3.method_31574(class_1802.field_8705)) {
                        break label49;
                     }
                  } else if (var3.method_31574(class_1802.field_8550)) {
                     break label49;
                  }
               }

               var10000 = false;
               return var10000;
            }

            var10000 = true;
            return var10000;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private boolean IIlll(class_310 var1) {
      return var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var1.field_1690 != null && var1.field_1755 == null && var1.field_1724.method_5805();
   }

   private boolean IlIIl(class_310 var1, Object var2) {
      if (this.IIlIl(var1, var2) && IllllIlI.lIllI(var1) <= 0) {
         class_1269 var3 = var1.field_1761.method_2919(var1.field_1724, class_1268.field_5808);
         return var3 != null && var3.method_23665();
      } else {
         return false;
      }
   }

   private void IlIll(class_310 var1, long var2) {
      <undefinedtype> var4 = this.lII;
      if (var4 != null) {
         if (var4.I() == null.I && !this.IIIll(var1)) {
            this.ll(var1);
         } else if (!this.IIlIl(var1, var4.I())) {
            this.lII = null;
            if (var4.I() == null.I) {
               this.ll(var1);
            } else if (var2 - this.Ill >= 1000L) {
               this.IlIl(var1, var2);
            } else {
               this.IIII = var2 + 50L;
            }

         } else if (IllllIlI.lIllI(var1) <= 0) {
            if (this.IIll(var1, var4)) {
               this.lII = null;
            }

         }
      }
   }

   private boolean IllII(class_310 var1) {
      class_746 var2 = var1.field_1724;
      return x.IlIllIl.IIl(var2.method_5809(), var2.method_20802(), var2.method_5771());
   }

   private void IllIl(class_310 var1) {
      <undefinedtype> var2 = (Boolean)this.lIlI.III() ? null.II : null.Il;
      IllllIlI.IlII(var1, this, var2);
   }

   private void IlllI(class_310 var1, int var2, long var3) {
      class_746 var5 = var1.field_1724;
      this.IIIII = IllllIlI.lIIlI(var5.method_31548());
      this.IllI = var2;
      this.IIIl = var5.method_36455();
      this.ll = var5.method_36454();
      boolean var6 = IllllIlI.IIlIl(var1) != this.IllI;
      int var7 = var6 ? this.lIII(this.llIl) : 0;
      this.llI = IllllIlI.lIll(var1, this, this.IllI, var7, true);
      if (this.llI != null && this.llI.III()) {
         long var8 = (long)var7 * 50L + 0L;
         this.IIII = Long.MAX_VALUE;
         this.lIl = var3 + var8 + 1000L;
         this.IlIl = null.ll;
         this.Ill = var3;
      } else {
         this.IIII();
      }
   }

   private void Illll(class_310 var1, long var2) {
      if (!this.IIlIl(var1, null.l)) {
         if (var2 - this.Ill >= 1000L) {
            this.IlIl(var1, var2);
         } else {
            this.IIII = var2 + 50L;
         }
      } else {
         Record var4 = new Record(null.l, 0) {
            private final int I;
            private final <undefinedtype> l;

            public <undefinedtype> I() {
               return this.l;
            }

            private {
               this.l = var1;
               this.I = var2;
            }

            private <undefinedtype> l(int var1) {
               return new <anonymous constructor>(this.l, var1);
            }

            public int II() {
               return this.I;
            }
         };
         if (!this.IIll(var1, var4)) {
            this.lII = var4;
         }

      }
   }

   private long lIIII(llllIlIl var1) {
      double var2 = var1.IlII();
      double var4 = var1.IlI();
      return var2 == var4 ? Math.max(0L, Math.round(var2)) : Math.max(0L, Math.round(ThreadLocalRandom.current().nextDouble(var2, var4)));
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (!this.IIlll(var1)) {
         this.ll(var1);
      } else if (lIlIllll.lIIl(var1)) {
         this.ll(var1);
      } else {
         long var2 = System.currentTimeMillis();
         if (this.IlII(var1)) {
            if (this.IlIl != null.lI) {
               this.ll(var1);
            }

            this.IIII = 0L;
         } else if (this.IlIl != null.lI) {
            this.lIIl(var1, var2);
         } else {
            boolean var4 = this.IllII(var1);
            if (!var4) {
               this.IIII = 0L;
            } else if (var2 >= this.IIII) {
               if (this.IIIll(var1)) {
                  int var5 = this.llII(var1.field_1724);
                  if (var5 >= 0) {
                     this.IlllI(var1, var5, var2);
                  }
               }
            }
         }
      }
   }

   private static int lIIIl(int var0, int var1) {
      return IIIIl[var0 ^ 2131181295] ^ var1 ^ var0;
   }

   private static String lIIlI(int var0, int var1, int var2) {
      int var3 = var2 ^ 23280;
      char[] var4 = IIIlI[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])IIIll[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         IIIll[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 32714;
      int var9 = 0;

      do {
         int var10 = var4[var9] ^ '\uf03f';
         var10 += 12091;
         var10 -= 50092;
         var10 -= 24637;
         var10 ^= 32712;
         var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
