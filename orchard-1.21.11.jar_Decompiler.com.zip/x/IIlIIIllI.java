package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2596;

@Environment(EnvType.CLIENT)
public final class IIlIIIllI {
   private volatile long I;
   private volatile long l;
   private volatile long II;
   private static String[] Il;
   private static final IIlIIIllI lI;
   private static final int[] ll;
   private static final String[] III;
   private static final Object[] IIl;

   static {
      short var6 = 30848;
      String var7 = "ꗴ羜遢鞚≱罴춱\uf1db讫彵ⷁ⅙釖靡黚䚛츩岑\ue1df犵㊐품懹\u0a0b菤\uf5d4썈㓼ᄨ窼猵踼权빚\u2d71콵鼀ಇ\uefd2켫┏உⰂ垭燡⮵鏄ꀉ\uf19a\uf454ꑜ썮氐h\uf58b뮃㔚浬큻솸핕쾷\ue9d4迉\ud872擁ꐧ튳ﰺ᱀佌ꮸꈮ╯쾕ꔠ";
      char[] var8 = "\u0018\u0018\u001c".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            III = var9;
            IIl = new Object[var9.length];
            int var2 = -514869991;
            byte[] var0 = "â_\u008b«\u0092M=\u0004H]7ýt ÍÓ9Ó)\t".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            ll = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               ll[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            Il = new String[3];
            lI();
            lI = new IIlIIIllI();
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 48;
                     break;
                  case 1:
                     var10000 = 25;
                     break;
                  case 2:
                     var10000 = 29;
                     break;
                  case 3:
                     var10000 = 97;
                     break;
                  case 4:
                     var10000 = 83;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public long I() {
      return this.II;
   }

   public void l() {
      long var1 = System.currentTimeMillis();
      this.I = var1;
      this.II = var1;
      this.l = var1;
   }

   public void II(class_2596<?> var1) {
      long var2 = System.currentTimeMillis();
      this.II = var2;
      if (this.I == 0L) {
         this.I = var2;
      }

      if (this.ll(var1)) {
         this.l = var2;
      }

   }

   public static IIlIIIllI Il() {
      return lI;
   }

   private static void lI() {
      Il[0] = Ill(lIl(-950768809, -1960170761).toCharArray(), 98688L, lII(-280795808, -611650512));
      Il[1] = Ill(lIl(-950768810, -1049337382).toCharArray(), 92728L, lII(-280795807, 874305067));
      Il[2] = Ill(lIl(-950768811, -1266539249).toCharArray(), 30372L, lII(-280795806, 2018309951));
   }

   private boolean ll(class_2596<?> var1) {
      String var2 = var1.getClass().getName();
      if (!var2.contains(lIlIII.Il(Il[1]))) {
         return false;
      } else {
         return !var2.endsWith(lIlIII.Il(Il[0])) && !var2.endsWith(lIlIII.Il(Il[2]));
      }
   }

   public long III() {
      return this.I;
   }

   public long IIl() {
      return this.l;
   }

   public void IlI() {
      this.I = 0L;
      this.II = 0L;
      this.l = 0L;
   }

   private static String Ill(char[] var0, long var1, int var3) {
      int var4 = lII(-280795805, -407448630) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & lII(-280795804, 937425291);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private static int lII(int var0, int var1) {
      return ll[var0 ^ -280795808] ^ var1 ^ var0;
   }

   private static String lIl(int var0, int var1) {
      int var3 = var0 ^ -950768809;
      char[] var4 = III[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IIl[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IIl[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -769368800;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 140;
               break;
            case 1:
               var9 = 74;
               break;
            case 2:
               var9 = 244;
               break;
            case 3:
               var9 = 161;
               break;
            case 4:
               var9 = 12;
               break;
            case 5:
               var9 = 156;
               break;
            case 6:
               var9 = 109;
               break;
            case 7:
               var9 = 48;
               break;
            case 8:
               var9 = 178;
               break;
            case 9:
               var9 = 169;
               break;
            case 10:
               var9 = 233;
               break;
            case 11:
               var9 = 91;
               break;
            case 12:
               var9 = 251;
               break;
            case 13:
               var9 = 182;
               break;
            case 14:
               var9 = 101;
               break;
            case 15:
               var9 = 209;
               break;
            case 16:
               var9 = 44;
               break;
            case 17:
               var9 = 153;
               break;
            case 18:
               var9 = 159;
               break;
            case 19:
               var9 = 14;
               break;
            case 20:
               var9 = 203;
               break;
            case 21:
               var9 = 133;
               break;
            case 22:
               var9 = 179;
               break;
            case 23:
               var9 = 175;
               break;
            case 24:
               var9 = 12;
               break;
            case 25:
               var9 = 56;
               break;
            case 26:
               var9 = 80;
               break;
            case 27:
               var9 = 4;
               break;
            case 28:
               var9 = 65;
               break;
            case 29:
               var9 = 163;
               break;
            case 30:
               var9 = 151;
               break;
            case 31:
               var9 = 223;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
