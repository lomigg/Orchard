package x;

import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;

@Environment(EnvType.CLIENT)
public final class lIllIll extends IIIIIIIlI {
   private final IIIllIIII I;
   private final IIIllIIII l;
   private final IIIllIIII II;
   private final IIllIlIII Il;
   private final IIllIlIII lI;
   private final lIIIIl ll;
   private final lIIIIl III;
   private final lIIIIl IIl;
   private final IIIllIIII IlI;
   private final IIIllIIII Ill;
   private final IIIllIIII lII;
   private static String[] lIl;
   private static final int[] llI;
   private static final String[] lll;
   private static final Object[] IIII;

   static {
      short var6 = 5035;
      String var7 = "䫵钭坠鳞뱴\uda8e\ud7aeЪ釞ᛉ\uee8a\ue932䷧匟욷曘䚝翗爃빋ᚋ\ue2ac翞ノ㫸捏䊙䃦눫粣햴}៘\u2d29ᾂ渻䁜\udac6滑蝸鋎曬坾䓾緛臣緬⣉⛫\uffe7\ue555娉忍師浪諫䲎有ɣ\u000e䀄ꌘ\uf591\ued5a멢谒鄨翶螤䕖䭴꿊ᯫ鋰ზ莳룳쑾䛿廅ⴞ蟿ｉઔ烥犐莮簢쵪鰞撪☻촺䮁놵ᱛ낥㉡蠿愷ੀ\uee22欱\u05cf簔\ue0bf炪鷯챷д：\ue002꣕\u0bac䉣穂≚㳟黊ꉰꈮ쬱᷎슷\uda83ﻥ쮽辏宐땶⮩\uf09f傲潘ṩ鳈鞴ู쀱\udc58靓ҏⅈ㟽᳀ද\ud8b6樂洇慶\udcf0叀ｽ쓘㢼\uf8e8䪝\ua878刃힕υ\u171c럷긏沽▸p린ퟦ쌁砇뺊뗢ꞗ䯖\uec95柠渺ꈳ諉⻛躬िԾ緣앲\u2428凳㤻꿺⠀㨩ᗏ鮯蹟ꭾᆡ㹈\ud9dfꂨ騔\uf08f鈝\u1cfc㾼즪圵媾ퟑ䴃諲榽䳎\uedef팉㭞솉\uf1c1ꢥ恿켂㶠걎뛞";
      char[] var8 = "ᎣᎻᎿᎯᎻᎣᎇᎿᎻᎻᎻᎻᎧᎧ".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            lll = var9;
            IIII = new Object[var9.length];
            int var2 = 470967104;
            byte[] var0 = "\u0099_`[hÿ²\u0010\u0099ß\u0093tüc\u0087KíééQ\u0086ÿgØWx\u0012iWë¨\u0090\u0085f½¹\u0005Íö§Rè\u001fÿ6Â¢ßHg\bNzÛßâ\u0087¡Z\u0013O\u0086\u009fh\u0083|4Ï\u0092±¦\u0091h\u0097BÃ6*\u0014\u0007Y¿r2\u0018^¦¶MÆ2¨É4÷\u0004oq\u0006\u008c¯\u0005ê¼8É\u000e\fëE\u009c\u0006K\u0096\u0090Ìß9ÅsCñ`6R\u009dç£O\u0002Ñ\u0084oóâå+¬ù4ì\u001a$$7¶\u009d<püÌþe4HÖS\f+ÞO>^\u008fêýuò®ù\b|\u009aDi\u001c\fqPY".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            llI = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               llI[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            lIl = new String[IIII(-879287781, 1322918158)];
            lll();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public void llIl(llIIllI var1) {
      if (this.IIIIIlI() && IIlIIIIl.IlIII(var1)) {
         class_310 var2 = class_310.method_1551();
         if (var2 != null && var2.field_1687 != null && var2.field_1724 != null) {
            float var3 = IllllIlI.IlIIIlI(var2);
            if ((Boolean)this.ll.III() && !var2.field_1690.method_31044().method_31034()) {
               this.l(var1, var2.field_1724, var3, (double)0.0F);
            }

            if ((Boolean)this.IIl.III()) {
               for(class_1657 var5 : var2.field_1687.method_18456()) {
                  if (var5 != var2.field_1724 && IIlIIIIl.llIIl(var2, var5)) {
                     this.l(var1, var5, var3, (double)var5.method_5628() * 0.113);
                  }
               }
            }

         }
      }
   }

   public lIllIll() {
      super((Object)lIlIII.l(lIl[IIII(-879287782, -1082461370)]), lIllII.ll, (Object)lIlIII.l(lIl[IIII(-879287783, 1314574891)]));
      this.IlI = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(lIl[0]), 0.55, (double)0.25F, 1.2, 0.01)).IIl(lIlIII.Il(lIl[3])));
      this.Ill = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(lIl[5]), 0.31, 0.05, 0.8, 0.01)).IIl(lIlIII.Il(lIl[3])));
      this.II = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(lIl[4]), 0.24, -0.3, (double)0.5F, 0.01)).IIl(lIlIII.Il(lIl[3])));
      this.III = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lIl[IIII(-879287784, 736544282)]), true));
      this.lI = (IIllIlIII)this.IIIlIll(new IIllIlIII(lIlIII.l(lIl[IIII(-879287777, 980199430)]), new Color(IIII(-879287778, 1366959834), IIII(-879287779, -2130881576), IIII(-879287780, -2140214989), IIII(-879287789, 1390673019))));
      this.Il = (IIllIlIII)this.IIIlIll(new IIllIlIII(lIlIII.l(lIl[2]), new Color(IIII(-879287790, -766986486), IIII(-879287791, -2056429999), IIII(-879287792, -515382416), IIII(-879287785, -1612559886))));
      this.lII = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(lIl[IIII(-879287786, -1386307906)]), (double)145.0F, (double)0.0F, (double)255.0F, (double)1.0F));
      this.I = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(lIl[IIII(-879287787, 1344543553)]), (double)235.0F, (double)0.0F, (double)255.0F, (double)1.0F));
      this.l = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(lIl[1]), 1.2, (double)0.5F, (double)4.0F, 0.1));
      this.ll = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lIl[IIII(-879287788, -1744576975)]), true));
      this.IIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lIl[IIII(-879287797, 1425634703)]), false));
      this.lI.lIII(() -> !(Boolean)this.III.III());
      this.Il.lIII(() -> !(Boolean)this.III.III());
   }

   private void l(llIIllI var1, class_1657 var2, float var3, double var4) {
      if (var2 != null && var2.method_5805() && !var2.method_7325()) {
         class_243 var6 = IIlIIIIl.IIIII(var2, var3).method_1031((double)0.0F, (double)var2.method_5751() + (Double)this.II.III() - (var2.method_5715() ? 0.08 : (double)0.0F), (double)0.0F);
         double var7 = (Double)this.IlI.III();
         double var9 = (Double)this.Ill.III();
         class_243 var11 = var6.method_1031((double)0.0F, var9, (double)0.0F);
         int var12 = IIII(-879287798, 1161095099);
         Color var13 = this.III(var4);
         Color var14 = this.llI(var4 + 0.17);
         class_243 var15 = this.ll(var6, var7, 0, var12);

         for(int var16 = 1; var16 <= var12; ++var16) {
            class_243 var17 = this.ll(var6, var7, var16, var12);
            if ((Double)this.lII.III() > (double)0.0F) {
               IIlIIIIl.lIIIl(var1, var11, var15, var17, var13, (double)var13.getAlpha());
            }

            if ((Double)this.I.III() > (double)0.0F) {
               IIlIIIIl.II(var1, var15, var17, var14, (double)var14.getAlpha(), ((Double)this.l.III()).floatValue());
               if (var16 % IIII(-879287799, -1089338494) == 0) {
                  IIlIIIIl.II(var1, var11, var17, var14, (double)var14.getAlpha() * 0.62, ((Double)this.l.III()).floatValue());
               }
            }

            var15 = var17;
         }

      }
   }

   private class_243 ll(class_243 var1, double var2, int var4, int var5) {
      double var6 = (Math.PI * 2D) * (double)var4 / (double)var5;
      return var1.method_1031(Math.cos(var6) * var2, (double)0.0F, Math.sin(var6) * var2);
   }

   private Color III(double var1) {
      boolean var3 = (Boolean)this.III.III() || lIllIIl.Il().IIl().llI().lIlII() != IIllIIlII.lIl;
      Color var4 = var3 ? lIllIIl.Il().IIl().llI().IIllII() : (Color)this.lI.III();
      int var5 = class_3532.method_15340((int)Math.round((Double)this.lII.III()), 0, IIII(-879287800, -508602960));
      return var3 ? IIlIIllIl.I(var4, var5) : IIlIIllIl.I(IIlIIllIl.Ill(var4, null.ll, var1), var5);
   }

   private static String IlI(char[] var0, long var1, int var3) {
      int var4 = IIII(-879287793, -63837783) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IIII(-879287794, -807672057);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private Color llI(double var1) {
      boolean var3 = (Boolean)this.III.III() || lIllIIl.Il().IIl().llI().lIlII() != IIllIIlII.lIl;
      Color var4 = var3 ? lIllIIl.Il().IIl().llI().llIII() : (Color)this.Il.III();
      int var5 = class_3532.method_15340((int)Math.round((Double)this.I.III()), 0, IIII(-879287795, -1706855654));
      return var3 ? IIlIIllIl.I(var4, var5) : IIlIIllIl.I(IIlIIllIl.Ill(var4, null.l, var1), var5);
   }

   private static void lll() {
      lIl[0] = IlI(IIll(42540, -983426732, '蟆').toCharArray(), 2253L, IIII(-879287796, 956914624));
      lIl[1] = IlI(IIll(42541, 1135679554, '毑').toCharArray(), 79933L, IIII(-879287805, 551738424));
      lIl[2] = IlI(IIll(42542, -94819119, '砉').toCharArray(), 91937L, IIII(-879287806, -867366628));
      lIl[3] = IlI(IIll(42543, -498643623, '䌰').toCharArray(), 4422L, IIII(-879287807, 1180847345));
      lIl[4] = IlI(IIll(42536, -1069531354, '여').toCharArray(), 65939L, IIII(-879287808, -208318910));
      lIl[5] = IlI(IIll(42537, -986050613, 'ཿ').toCharArray(), 66819L, IIII(-879287801, 2094083507));
      lIl[IIII(-879287802, 146572339)] = IlI(IIll(42538, -393190645, 'ᾪ').toCharArray(), 87066L, IIII(-879287803, -190209618));
      lIl[IIII(-879287804, -2061981984)] = IlI(IIll(42539, -829011607, '뛨').toCharArray(), 80920L, IIII(-879287749, 248928779));
      lIl[IIII(-879287750, -1200184425)] = IlI(IIll(42532, 1702498702, '̨').toCharArray(), 78843L, IIII(-879287751, -2035281497));
      lIl[IIII(-879287752, 1000301909)] = IlI(IIll(42533, -163233886, '\ue7c7').toCharArray(), 10041L, IIII(-879287745, -471624536));
      lIl[IIII(-879287746, -1485206134)] = IlI(IIll(42534, 527195904, '뜬').toCharArray(), 14430L, IIII(-879287747, -2016198321));
      lIl[IIII(-879287748, -2071369047)] = IlI(IIll(42535, 366491274, 'ႂ').toCharArray(), 7204L, IIII(-879287757, 600874336));
      lIl[IIII(-879287758, 1031287948)] = IlI(IIll(42528, 313416237, '闵').toCharArray(), 40648L, IIII(-879287759, 1651669279));
      lIl[IIII(-879287760, 1304504417)] = IlI(IIll(42529, -774384, '珫').toCharArray(), 99568L, IIII(-879287753, 521933586));
   }

   private static int IIII(int var0, int var1) {
      return llI[var0 ^ -879287781] ^ var1 ^ var0;
   }

   private static String IIll(int var0, int var1, char var2) {
      int var3 = var0 ^ '\ua62c';
      char[] var4 = lll[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])IIII[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         IIII[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 14227;
      int var9 = 0;

      do {
         int var10 = var4[var9] ^ 3184;
         var10 += 40299;
         var10 -= 37377;
         var10 += 772;
         var10 += 53252;
         var4[var9] = (char)(var10 ^ var8 ^ var2 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
