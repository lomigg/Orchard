package x;

import java.io.PrintStream;
import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_6880;
import net.minecraft.class_746;
import net.minecraft.class_7923;
import net.minecraft.class_9304;
import net.minecraft.class_9334;
import net.minecraft.class_9362;
import net.minecraft.class_239.class_240;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;

@Environment(EnvType.CLIENT)
public final class IIIIIIIl extends IIIIIIIlI {
   private static final int I = 4;
   private boolean l;
   private final IlIIIlIlI<<undefinedtype>> II;
   private static final <undefinedtype> Il;
   private boolean lI;
   private final llllIlIl ll;
   private static final double III = 1.0E-4;
   private static final long IIl = 1500L;
   private final lIIIIl IlI;
   private final lIIIIl Ill;
   private static final double lII = (double)3.0F;
   private static final long lIl = 500L;
   private boolean llI;
   private long lll;
   private final IIIllIIII IIII;
   private boolean IIIl;
   private double IIlI;
   private static final long IIll = 1000L;
   private final IlIIIlIlI<<undefinedtype>> IlII;
   private final llllIlIl IlIl;
   private int IllI;
   private <undefinedtype> Illl;
   private long lIII;
   private boolean lIIl;
   private final lIIIIl lIlI;
   private final IlIIIlIlI<<undefinedtype>> lIll;
   private float llII;
   private float llIl;
   private double lllI;
   private class_3966 llll;
   private static final int IIIII = 1;
   private long IIIIl;
   private long IIIlI;
   private float IIIll;
   private int IIlII;
   private <undefinedtype> IIlIl;
   private int IIllI;
   private int IIlll;
   private static final int IlIII = 9;
   private long IlIIl;
   private boolean IlIlI;
   private final IIIllIIII IlIll;
   private float IllII;
   private int IllIl;
   private long IlllI;
   private final IlIlIll Illll;
   private float lIIII;
   private int lIIIl;
   private long lIIlI;
   private boolean lIIll;
   private int lIlII;
   private long lIlIl;
   private class_1657 lIllI;
   private float lIlll;
   private final IIIllIIII llIII;
   private final IIIllIIII llIIl;
   private class_1657 llIlI;
   private static final long llIll = 2500L;
   private static final double lllII = (double)3.0F;
   private final lIIIIl lllIl;
   private <undefinedtype> llllI;
   private static final int[] lllll;
   private static final String[] IIIIII;
   private static final Object[] IIIIIl;

   private static class_243 l(class_243 var0, class_238 var1) {
      class_243 var2 = IlI(var0, var1);
      if (!var1.method_1006(var0)) {
         return var2;
      } else {
         double var3 = var0.field_1352 - var1.field_1323;
         double var5 = var1.field_1320 - var0.field_1352;
         double var7 = var0.field_1351 - var1.field_1322;
         double var9 = var1.field_1325 - var0.field_1351;
         double var11 = var0.field_1350 - var1.field_1321;
         double var13 = var1.field_1324 - var0.field_1350;
         double var15 = Math.min(Math.min(Math.min(var3, var5), Math.min(var7, var9)), Math.min(var11, var13));
         if (var15 == var3) {
            return new class_243(var1.field_1323, var0.field_1351, var0.field_1350);
         } else if (var15 == var5) {
            return new class_243(var1.field_1320, var0.field_1351, var0.field_1350);
         } else if (var15 == var7) {
            return new class_243(var0.field_1352, var1.field_1322, var0.field_1350);
         } else if (var15 == var9) {
            return new class_243(var0.field_1352, var1.field_1325, var0.field_1350);
         } else {
            return var15 == var11 ? new class_243(var0.field_1352, var0.field_1351, var1.field_1321) : new class_243(var0.field_1352, var0.field_1351, var1.field_1324);
         }
      }
   }

   private void II(class_310 var1) {
      if (var1 != null && var1.field_1690 != null && var1.field_1690.field_1886 != null) {
         var1.field_1690.field_1886.method_23481(false);
      }
   }

   private void ll(class_310 var1) {
      long var2 = System.currentTimeMillis();
      if (var2 >= this.IIIIl && this.IlII(var1.field_1724) && !lIlIllll.lIIl(var1) && !this.llIlI(var1.field_1724)) {
         if (!(Boolean)this.Ill.III() || this.IIlIIl(var1.field_1724.method_6047())) {
            class_1657 var4 = this.IlIlIl(var1, this.lIllI);
            if (var4 != null && this.IIIIlI(var1, var4)) {
               class_243 var5 = this.IIIlII(var1, var4, this.IIllI());
               if (var5 != null) {
                  this.llIlI = var4;
                  this.lIllI = var4;
                  this.lIlII = this.IIIIIl(var1);
                  if (this.lIlII < 0) {
                     this.llIlI = null;
                  } else {
                     boolean var6 = IllllIlI.l(var4, var1.field_1724);
                     this.IIllI = var6 && (Boolean)this.IlI.III() ? this.lIIll(var1) : -1;
                     this.lI = this.IIllI >= 0;
                     this.IllI = IllllIlI.lIIlI(var1.field_1724.method_31548());
                     this.IIIl = false;
                     this.lIlIl = var2 + (this.lI ? 1500L : 2500L) + (this.IlIllI() + this.lIlll()) * 2L;
                     this.Illll(this.lI ? null.l : null.I, var2);
                     this.lIllI(var1);
                  }
               }
            }
         }
      }
   }

   private boolean III(class_310 var1) {
      return this.IIIIIlI() && var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1724.method_5805() && var1.field_1755 == null && !var1.field_1724.method_7325();
   }

   private static class_243 IlI(class_243 var0, class_238 var1) {
      return new class_243(class_3532.method_15350(var0.field_1352, var1.field_1323, var1.field_1320), class_3532.method_15350(var0.field_1351, var1.field_1322, var1.field_1325), class_3532.method_15350(var0.field_1350, var1.field_1321, var1.field_1324));
   }

   private long lII(long var1, boolean var3) {
      return var1 + (var3 ? this.IlIllI() : 0L) + this.lIlll();
   }

   public void llI(float var1, float var2, float var3, float var4) {
      float var5 = class_3532.method_15393(var3 - var1);
      float var6 = var4 - var2;
      this.lIIII = class_3532.method_15393(this.lIIII + var5);
      this.lIlll = class_3532.method_15363(this.lIlll + var6, -90.0F, 90.0F);
   }

   private <undefinedtype> lll(class_310 var1, class_1657 var2) {
      class_243 var3 = var1.field_1724.method_33571();
      class_243 var4 = this.IIIlII(var1, var2, (Double)this.llIIl.III());
      class_243 var5 = var4 != null ? var4 : IlI(var3, var2.method_5829());
      double var6 = var3.method_1022(var5);
      float[] var8 = IlIlIl.llIlI(var1, var5);
      double var9 = var8 == null ? (double)180.0F : Math.hypot((double)class_3532.method_15393(var8[0] - var1.field_1724.method_36454()), (double)(var8[1] - var1.field_1724.method_36455()));
      return new Record(var2, var6, var9, var2.method_6032()) {
         private final float I;
         private final class_1657 l;
         private final double II;
         private final double Il;

         public class_1657 I() {
            return this.l;
         }

         public double l() {
            return this.II;
         }

         public double II() {
            return this.Il;
         }

         public float Il() {
            return this.I;
         }

         private {
            this.l = var1;
            this.Il = var2;
            this.II = var4;
            this.I = var6;
         }
      };
   }

   private boolean IIII(class_310 var1, int var2) {
      this.lIIll = false;
      if (var1 != null && var1.field_1724 != null && var2 >= 0 && var2 < IlIlll(-162776105, 438788426)) {
         int var3 = IllllIlI.IIlIl(var1);
         if (var3 != var2 && IllllIlI.lIIlI(var1.field_1724.method_31548()) != var2) {
            if (this.IIlIl == null || this.IIlIl.ll() != var2) {
               this.IIlIl = IllllIlI.lIll(var1, this, var2, 0, true);
            }

            if (this.IIlIl != null && this.IIlIl.III()) {
               if (!IllllIlI.IlIllII(var1, this.IIlIl)) {
                  return false;
               } else {
                  this.lIIll = this.IIlIl.lI();
                  this.IIlIl = null;
                  return true;
               }
            } else {
               this.IIlIl = null;
               return false;
            }
         } else {
            return true;
         }
      } else {
         return false;
      }
   }

   private void IIIl(class_310 var1, boolean var2) {
      ++this.IIIlI;
      this.IlIlI = false;
      boolean var3 = var2 && (Boolean)this.lllIl.III() && var1 != null && var1.field_1724 != null && this.IllI >= 0 && this.IllI < IlIlll(-162776106, -842616953) && IllllIlI.lIIlI(var1.field_1724.method_31548()) != this.IllI;
      if (var3) {
         IllllIlI.llIIlI(var1, this, this.IllI);
      } else {
         IllllIlI.IlII(var1, this, var2 && (Boolean)this.lllIl.III() ? null.II : null.Il);
      }

      this.lllI();
   }

   public boolean IIlI(class_310 var1) {
      return this.llI;
   }

   private void IIll(class_310 var1, class_1657 var2) {
      if (this.IlIIlI(var1, var2, (Double)this.llIIl.III())) {
         class_243 var3 = this.IIIlII(var1, var2, (Double)this.llIIl.III());
         if (var3 == null && var2 != null) {
            var3 = var2.method_5829().method_1005();
         }

         float[] var4 = IlIlIl.llIlI(var1, var3);
         if (var4 != null) {
            this.Illll.IIllI(var1, var3, ((Double)this.llIII.III()).floatValue(), var2.method_5628());
         }
      }
   }

   private boolean IlII(class_746 var1) {
      if (var1 == null) {
         return false;
      } else if ((Double)this.IlIll.III() <= (double)0.0F) {
         return true;
      } else {
         return this.llII(var1) && Math.max(var1.field_6017, this.lllI) >= (Double)this.IlIll.III();
      }
   }

   public boolean IlIl(class_1297 var1) {
      class_310 var2 = class_310.method_1551();
      return var2 != null && var2.field_1724 != null && var1 == var2.field_1724 && this.IIlIl();
   }

   private void Illl() {
      if (this.IlII.III() == null.I) {
         this.IlII.I(null.l);
         IIlllIlI var1 = IIlllIlI.II();
         if (var1 != null) {
            var1.III(null.l, lIlIII.Il(IllIII(-283695386, '䌚', 42035)), lIlIII.Il(IllIII(-464184104, 'ឌ', 42034)), 4000L);
         }
      }

   }

   private void lIII(class_310 var1, long var2, Object var4) {
      if (var2 == this.IIIlI && this.IIIll(var1)) {
         this.Illl = null;
         this.llll = null;
         long var5 = System.currentTimeMillis();
         this.Illll(var4 == null.l ? null.lI : null.II, var5);
         this.IlIIl = var5 + 50L;
      } else {
         this.IIIIll(var1, var2, var4, false);
      }
   }

   private int lIIl(class_1799 var1, Object var2) {
      if (var1 != null && var2 != null) {
         class_9304 var3 = (class_9304)var1.method_58695(class_9334.field_49633, class_9304.field_49385);

         for(class_6880 var5 : var3.method_57534()) {
            String var6 = (String)var5.method_40230().map((var0) -> var0.method_29177().method_12832()).orElse("");
            if (var2.lIlI().equalsIgnoreCase(var6)) {
               return var3.method_57536(var5);
            }
         }

         return 0;
      } else {
         return 0;
      }
   }

   private void lIll(class_310 var1, long var2) {
      if (this.lI && this.IIllI >= 0) {
         if (var2 >= this.IlIIl) {
            if (!this.IIII(var1, this.IIllI)) {
               if (var2 - this.lll > 500L) {
                  this.Illll(null.I, var2);
               }

            } else {
               this.Illll(null.lI, var2);
               this.IlIIl = this.lII(var2, this.lIIll);
            }
         }
      } else {
         this.Illll(null.I, var2);
         this.IIllIl(var1, var2);
      }
   }

   private boolean llII(class_746 var1) {
      return var1 != null && !var1.method_24828() && !var1.method_6101() && !var1.method_5799() && var1.method_18798().field_1351 < -0.08 && (var1.field_6017 > (double)0.0F || this.lllI > (double)0.0F || this.IlllI >= 2L);
   }

   private void lllI() {
      this.llllI = null.Il;
      this.Illl = null;
      this.llll = null;
      this.lll = 0L;
      this.IlIIl = 0L;
      this.lIlIl = 0L;
      this.llIlI = null;
      this.IllI = -1;
      this.IIllI = -1;
      this.lIlII = -1;
      this.lI = false;
      this.IIIl = false;
      this.IIlIl = null;
      this.lIIll = false;
   }

   private boolean IIIII(class_310 var1, class_1297 var2) {
      lIllIIl var3 = lIllIIl.Il();
      if (var3 != null && var3.IIl() != null) {
         llIlIllI var4 = var3.IIl().IIIlIII();
         return var4 != null && var4.lllll(var1, var2);
      } else {
         return false;
      }
   }

   private void IIIIl() {
      this.Illll.IIllII();
      this.lIllI = null;
   }

   private boolean IIIll(class_310 var1) {
      if (this.III(var1) && this.llIlI != null && this.llIlI.method_5805() && !this.llIlI.method_31481()) {
         return this.lI ? this.IlIIlI(var1, this.llIlI, (Double)this.llIIl.III()) : this.IIIIlI(var1, this.llIlI);
      } else {
         return false;
      }
   }

   private boolean IIlII(class_310 var1, class_243 var2, class_243 var3) {
      if (var1 != null && var1.field_1687 != null && var2 != null && var3 != null) {
         class_3965 var4 = var1.field_1687.method_17742(new class_3959(var2, var3, class_3960.field_17558, class_242.field_1348, var1.field_1724));
         return var4 == null || var4.method_17783() == class_240.field_1333 || var2.method_1025(var4.method_17784()) + 1.0E-4 >= var2.method_1025(var3);
      } else {
         return false;
      }
   }

   public boolean IIlIl() {
      class_310 var1 = class_310.method_1551();
      return this.l && var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1755 == null ? this.llIll(var1) : false;
   }

   private double IIllI() {
      return class_3532.method_15350((Double)this.IIII.III(), (double)1.0F, (double)3.0F);
   }

   public boolean IIlll() {
      return this.llllI != null.Il;
   }

   private void IlIII(long var1) {
      this.IIIIl = 0L;
   }

   private boolean IlIIl(class_310 var1, Object var2, class_3966 var3, long var4) {
      if (this.IIIll(var1) && this.IIlIll(var1, var2) && var3 != null && !this.IIIII(var1, this.llIlI)) {
         boolean var10000;
         label59: {
            label58: {
               class_239 var8 = var1.field_1765;
               if (var8 instanceof class_3966) {
                  class_3966 var7 = (class_3966)var8;
                  if (var7.method_17782() == this.llIlI) {
                     break label58;
                  }
               }

               if (!this.llIIl(var1, this.llIlI, this.IIllI())) {
                  var10000 = false;
                  break label59;
               }
            }

            var10000 = true;
         }

         boolean var6 = var10000;
         if (!var6) {
            return false;
         } else {
            boolean var9 = IllllIlI.lllII(var1, var3);
            this.IllII(var1, var9 ? IlIlll(-162776107, -646145968) : IlIlll(-162776108, 275211069));
            if (!var9) {
               return false;
            } else if (var2 == null.l) {
               this.Illll(null.I, var4);
               this.IIllIl(var1, var4);
               return true;
            } else {
               this.IlIII(var4);
               this.IIIl = true;
               this.lIIl = true;
               this.IIIl(var1, true);
               return true;
            }
         }
      } else {
         return false;
      }
   }

   public void IIIlI(class_332 var1, int var2, int var3, float var4) {
      class_310 var5 = class_310.method_1551();
      if (this.III(var5) && this.llII(var5.field_1724) && !this.lIIl) {
         class_1657 var6 = this.llllI == null.Il ? this.lIllI : this.llIlI;
         if (var6 != null && this.IlIIlI(var5, var6, (Double)this.llIIl.III())) {
         }

      }
   }

   private void IllII(class_310 var1, int var2) {
      if ((Boolean)this.lIlI.III() && var1 != null && var1.field_1724 != null) {
         int var3 = var1.field_1724.field_6012;
         if (this.IllIl != var2 || this.lIIIl == IlIlll(-162776109, -1705715891) || var3 - this.lIIIl >= IlIlll(-162776110, -990623685)) {
            this.IllIl = var2;
            this.lIIIl = var3;
            PrintStream var10000 = System.out;
            String var4 = Il.lIlI();
            var10000.println(var4 + var2);
         }
      }
   }

   private void IllIl(class_310 var1, long var2) {
      if (var2 >= this.IlIIl) {
         if (!this.lI && !this.IlII(var1.field_1724)) {
            this.IIIl(var1, true);
         } else {
            int var4 = this.IIIIIl(var1);
            if (var4 < 0) {
               this.IIIl(var1, true);
            } else if (var4 != this.lIlII) {
               this.lIlII = var4;
               this.Illll(null.I, var2);
               this.IIllIl(var1, var2);
            } else if (!this.IIlIll(var1, null.I)) {
               if (this.lI && IllllIlI.l(this.llIlI, var1.field_1724) && this.IIllI >= 0) {
                  this.Illll(null.l, var2);
                  this.lIll(var1, var2);
               } else {
                  this.Illll(null.I, var2);
                  this.IIllIl(var1, var2);
               }
            } else {
               class_3966 var5 = this.lIIlI(var1, this.llIlI);
               if (var5 != null) {
                  this.II(var1);
                  if (this.IlII.III() != null.l || !this.IlIIl(var1, null.I, var5, var2)) {
                     if (!this.IIIlIl(var1, null.I, var5)) {
                        this.IIIl(var1, true);
                     }
                  }
               }
            }
         }
      }
   }

   private void IlllI(class_310 var1) {
      if (this.llI) {
         if (var1 != null && var1.field_1724 != null && var1.field_1687 != null) {
            long var2 = var1.field_1687.method_75260();
            if (var2 != this.lIII) {
               this.lIII = var2;
               float var4 = this.IllII;
               float var5 = class_3532.method_15363(this.llII, -90.0F, 90.0F);
               if (IlIlIl.llI(var1, IlIlll(-162776111, -121640648), var4, var5)) {
                  --this.IIlII;
                  if (this.IIlII <= 0) {
                     this.llI = false;
                  }

               }
            }
         } else {
            this.llI = false;
         }
      }
   }

   public void IllI(class_310 var1) {
      this.IIlllI(var1 == null ? null : var1.field_1724);
      if (!this.III(var1)) {
         if (this.llllI != null.Il) {
            this.IIIl(var1, true);
         }

      } else {
         if (this.llllI == null.Il) {
            this.ll(var1);
         }

         if (this.llllI != null.Il) {
            this.II(var1);
            this.lIllI(var1);
         }

      }
   }

   private void Illll(Object var1, long var2) {
      this.llllI = var1;
      this.lll = var2;
      this.IlIIl = var2;
   }

   private boolean lIIII(class_310 var1, class_1657 var2) {
      return var2 != null && this.IlIIlI(var1, var2, (Double)this.llIIl.III());
   }

   private long lIIIl(llllIlIl var1) {
      double var2 = var1.IlII();
      double var4 = var1.IlI();
      return var2 == var4 ? Math.max(0L, Math.round(var2)) : Math.max(0L, Math.round(ThreadLocalRandom.current().nextDouble(var2, var4)));
   }

   private class_3966 lIIlI(class_310 var1, class_1657 var2) {
      if (!this.IIIIlI(var1, var2)) {
         return null;
      } else {
         class_3966 var3 = IllllIlI.IlIIllI(var1, this.IIllI());
         if (this.IlIIII(var1, var2, var3)) {
            return var3;
         } else {
            class_243 var4 = this.IIIlII(var1, var2, this.IIllI());
            return var4 == null ? null : new class_3966(var2, var4);
         }
      }
   }

   private int lIIll(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         for(int var2 = 0; var2 < IlIlll(-162776112, -274724293); ++var2) {
            class_1799 var3 = var1.field_1724.method_31548().method_5438(var2);
            if (var3 != null && var3.method_7909() instanceof class_1743) {
               return var2;
            }
         }

         return -1;
      } else {
         return -1;
      }
   }

   private boolean lIlII(class_310 var1, int var2, Class<?> var3) {
      if (var1 != null && var1.field_1724 != null && var2 >= 0 && var2 < IlIlll(-162776097, 112143692)) {
         class_1799 var4 = var1.field_1724.method_31548().method_5438(var2);
         if (var4 != null && var3.isInstance(var4.method_7909())) {
            int var5 = IllllIlI.IIlIl(var1);
            return var5 == var2 || IllllIlI.lIIlI(var1.field_1724.method_31548()) == var2;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private boolean lIlIl(class_310 var1, long var2, Object var4) {
      if (var2 == this.IIIlI && this.llllI == null.ll && this.Illl == var4 && this.IIIll(var1) && this.IIlIll(var1, var4)) {
         if (this.IIIII(var1, this.llIlI)) {
            this.IllII(var1, IlIlll(-162776099, 1739830122));
            this.IIIIll(var1, var2, var4, false);
            return false;
         } else if (!this.llIIl(var1, this.llIlI, this.IIllI())) {
            this.IllII(var1, IlIlll(-162776100, -1217205692));
            this.lIII(var1, var2, var4);
            return false;
         } else {
            class_3966 var10000;
            label115: {
               if (this.IlII.III() == null.I) {
                  class_239 var7 = var1.field_1765;
                  if (var7 instanceof class_3966) {
                     class_3966 var6 = (class_3966)var7;
                     if (var6.method_17782() == this.llIlI) {
                        var10000 = var6;
                        break label115;
                     }
                  }
               }

               var10000 = null;
            }

            class_3966 var5 = var10000;
            if (this.IlII.III() != null.I) {
               var5 = IllllIlI.IlIIll(var1, this.llIlI, this.IIllI(), true);
            }

            if (var5 == null && this.llll != null && this.llll.method_17782() == this.llIlI && this.IIIIlI(var1, this.llIlI)) {
               var5 = this.llll;
            }

            if (var5 == null && this.IlII.III() != null.I) {
               var5 = this.lIIlI(var1, this.llIlI);
            }

            if (var5 == null && this.IlII.III() != null.I) {
               class_243 var8 = this.IIIlII(var1, this.llIlI, this.IIllI());
               if (var8 != null) {
                  var5 = new class_3966(this.llIlI, var8);
               }
            }

            if (var5 == null && this.IlII.III() == null.I) {
               class_243 var9 = this.IIIlII(var1, this.llIlI, this.IIllI());
               if (var9 != null) {
                  var5 = new class_3966(this.llIlI, var9);
               }
            }

            if (var5 == null) {
               this.IllII(var1, IlIlll(-162776101, 1351642240));
               this.lIII(var1, var2, var4);
               return false;
            } else {
               boolean var10 = IllllIlI.lllII(var1, var5);
               this.IllII(var1, var10 ? IlIlll(-162776102, 1132899703) : IlIlll(-162776103, -1049042867));
               this.IIIIll(var1, var2, var4, var10);
               return var10;
            }
         }
      } else {
         this.IllII(var1, IlIlll(-162776098, -689036916));
         this.IIIIll(var1, var2, var4, false);
         return false;
      }
   }

   private void lIllI(class_310 var1) {
      long var2 = System.currentTimeMillis();
      if (this.llllI != null.Il) {
         if (this.IIIll(var1) && var2 <= this.lIlIl) {
            if (this.llllI == null.ll) {
               if (var2 - this.lll > 1000L) {
                  ++this.IIIlI;
                  this.IIIl(var1, true);
               }

            } else {
               this.IIll(var1, this.llIlI);
               switch (this.llllI.ordinal()) {
                  case 1 -> this.lIll(var1, var2);
                  case 2 -> this.lllII(var1, var2);
                  case 3 -> this.IIllIl(var1, var2);
                  case 4 -> this.IllIl(var1, var2);
               }

            }
         } else {
            this.IIIl(var1, true);
         }
      }
   }

   public void lIl() {
      this.Illl();
      class_310 var1 = class_310.method_1551();
      this.Illll.IIlIIII();
      IllllIlI.IlII(var1, this, null.II);
      this.llllI(var1, true);
      this.lllll();
      this.IIIIl();
      this.lllI();
   }

   private long lIlll() {
      return this.lIIIl(this.ll);
   }

   public boolean llIII(class_310 var1) {
      return this.III(var1) && this.IlII(var1.field_1724) && (!(Boolean)this.Ill.III() || this.IIlIIl(var1.field_1724.method_6047())) && this.IIIIIl(var1) >= 0;
   }

   private boolean llIIl(class_310 var1, class_1297 var2, double var3) {
      return IlIlIl.IIIlI(var1, var2, var3);
   }

   private boolean llIlI(class_746 var1) {
      return var1 == null || var1.method_6115() || var1.method_6128() || var1.method_3144() || var1.method_5799();
   }

   private boolean llIll(class_310 var1) {
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null) {
         if (this.III(var1) && this.IlII(var1.field_1724)) {
            class_1657 var2 = this.llllI == null.Il ? this.lIllI : this.llIlI;
            if (var2 != null && var2.method_5805() && !var2.method_31481() && this.llIII(var1)) {
               this.IIlll = var1.field_1724.field_6012;
               return true;
            } else {
               return this.l && this.IIlll != IlIlll(-162776104, -1797171431) && var1.field_1724.field_6012 - this.IIlll <= 4;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private void lllII(class_310 var1, long var2) {
      if (var2 >= this.IlIIl) {
         if (!this.IIlIll(var1, null.l)) {
            this.Illll(null.l, var2);
         } else {
            class_3966 var4 = this.lIIlI(var1, this.llIlI);
            if (var4 == null) {
               this.IllII(var1, IlIlll(-162776121, 1392744014));
            } else {
               this.II(var1);
               if (this.IlII.III() != null.l || !this.IlIIl(var1, null.l, var4, var2)) {
                  if (!this.IIIlIl(var1, null.l, var4)) {
                     this.Illll(null.I, var2);
                     this.IIllIl(var1, var2);
                  }
               }
            }
         }
      }
   }

   public void Ill() {
      this.Illl();
      class_310 var1 = class_310.method_1551();
      this.llllI(var1, false);
      this.IIlllI(var1 == null ? null : var1.field_1724);
      if (!this.III(var1)) {
         if (this.llllI != null.Il) {
            this.IIIl(var1, true);
         }

         this.lIllI = null;
      } else if (this.IlIlI && !IllllIlI.llIIII(this)) {
         this.IIIl(var1, false);
      } else if (this.llllI != null.Il) {
         if (!this.IIIll(var1)) {
            this.IIIl(var1, true);
         } else {
            this.lIllI(var1);
         }
      } else if (!this.llIII(var1)) {
         this.lIllI = null;
         this.IIIIl();
      } else {
         this.lIllI = this.IlIlIl(var1, this.lIllI);
         if (this.lIllI == null) {
            this.IIIIl();
         } else {
            this.IIll(var1, this.lIllI);
         }
      }
   }

   private void llllI(class_310 var1, boolean var2) {
      boolean var3 = this.IIIIIlI() && this.IlII.III() == null.I && var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1755 == null && this.llIll(var1);
      if (var3 == this.l) {
         if (var3) {
            this.llI = false;
            this.IIIll = this.lIIII;
            this.llIl = this.lIlll;
         } else {
            this.IlllI(var1);
         }

      } else {
         boolean var4 = this.l;
         this.l = var3;
         if (var3) {
            this.llI = false;
            this.lIIII = var1.field_1724.method_36454();
            this.lIlll = var1.field_1724.method_36455();
            this.IIIll = this.lIIII;
            this.llIl = this.lIlll;
         } else {
            if (!var2 && var4 && var1 != null && var1.field_1724 != null) {
               this.llI = true;
               this.IllII = this.lIIII;
               this.llII = this.lIlll;
               this.lIII = Long.MIN_VALUE;
               this.IIlII = 1;
               this.IlllI(var1);
            }

         }
      }
   }

   private void lllll() {
      this.lIIlI = Long.MIN_VALUE;
      this.IlllI = 0L;
      this.IIlI = Double.NaN;
      this.lllI = (double)0.0F;
      this.lIIl = false;
      this.IIIIl = 0L;
   }

   public boolean IIIIII(class_1309 var1) {
      return var1 != null && var1 == this.llIlI && this.llllI != null.Il;
   }

   private int IIIIIl(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         <undefinedtype> var2 = this.IIlIII(var1.field_1724);
         int var3 = IllllIlI.lIIlI(var1.field_1724.method_31548());
         int var4 = -1;
         int var5 = IlIlll(-162776122, -113030946);

         for(int var6 = 0; var6 < IlIlll(-162776123, 928804428); ++var6) {
            class_1799 var7 = var1.field_1724.method_31548().method_5438(var6);
            if (var7 != null && var7.method_7909() instanceof class_9362) {
               int var8 = this.lIIl(var7, var2.II);
               int var9 = this.lIIl(var7, var2.I);
               int var10 = var8 * IlIlll(-162776124, 277453811) + var9 * IlIlll(-162776125, 1312909297) + (var6 == var3 ? 1 : 0);
               if (var10 > var5) {
                  var5 = var10;
                  var4 = var6;
               }
            }
         }

         return var4;
      } else {
         return -1;
      }
   }

   private boolean IIIIlI(class_310 var1, class_1657 var2) {
      if (var1 != null && var1.field_1724 != null && var2 != null) {
         class_243 var3 = var1.field_1724.method_33571();
         double var4 = this.IIllI() + 1.0E-4;
         return var3.method_1025(IlI(var3, var2.method_5829())) <= var4 * var4;
      } else {
         return false;
      }
   }

   public IIIIIIIl() {
      super((Object)lIlIII.l(IllIII(1953589332, '\uf15f', 42033)), lIllII.I, (Object)lIlIII.l(IllIII(247473965, '輩', 42032)));
      this.lIll = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IllIII(395078689, '悔', 42039)), <undefinedtype>.class, null.l));
      this.llIII = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IllIII(267520388, '㍔', 42038)), (double)92.0F, (double)1.0F, (double)100.0F, (double)1.0F)).IIIl(lIlIII.l(IllIII(1952730687, 'Ҽ', 42037))));
      this.llIIl = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IllIII(751327062, '큼', 42036)), (double)5.0F, (double)1.0F, (double)8.0F, 0.1)).IIIl(lIlIII.l(IllIII(1242184970, '탺', 42043))));
      this.IIII = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IllIII(133639221, '眉', 42042)), 2.95, (double)1.0F, (double)3.0F, 0.05)).IIIl(lIlIII.l(IllIII(429091083, '䮥', 42041))));
      this.IlII = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IllIII(720375480, '呣', 42040)), <undefinedtype>.class, null.l));
      this.IlIll = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IllIII(421593719, '笐', 42047)), (double)1.0F, (double)0.0F, (double)12.0F, (double)0.25F)).IIIl(lIlIII.l(IllIII(1606685001, '懘', 42046))));
      this.II = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IllIII(-1578010949, 'Լ', 42045)), <undefinedtype>.class, null.I));
      this.IlI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IllIII(1646663932, '俩', 42044)), true));
      this.lllIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IllIII(1408842612, 'ⶮ', 42019)), true));
      this.Ill = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IllIII(-1845231126, '㚗', 42018)), false));
      this.IlIl = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(IllIII(241980892, '쑜', 42017)), (double)0.0F, (double)0.0F, (double)0.0F, (double)300.0F, (double)5.0F)).Ill(lIlIII.l(IllIII(121257908, '\u0ff4', 42016))));
      this.ll = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(IllIII(999377316, 'Ł', 42023)), (double)0.0F, (double)0.0F, (double)0.0F, (double)300.0F, (double)5.0F)).Ill(lIlIII.l(IllIII(-1799066219, '\ue800', 42022))));
      this.lIlI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IllIII(1283260884, '븕', 42021)), false));
      this.Illll = new IlIlIll();
      this.llllI = null.Il;
      this.IllI = -1;
      this.IIllI = -1;
      this.lIlII = -1;
      this.lIIlI = Long.MIN_VALUE;
      this.IIlI = Double.NaN;
      this.IllIl = IlIlll(-162776126, 1324745041);
      this.lIIIl = IlIlll(-162776127, -403087362);
      this.IIlll = IlIlll(-162776128, -964295077);
      this.lIII = Long.MIN_VALUE;
   }

   private void IIIIll(class_310 var1, long var2, Object var4, boolean var5) {
      if (var2 == this.IIIlI) {
         long var6 = System.currentTimeMillis();
         this.llll = null;
         if (!var5) {
            this.IIIl(var1, true);
         } else if (var4 == null.l) {
            this.Illll(null.I, var6);
            this.IIllIl(var1, var6);
         } else {
            this.IlIII(var6);
            this.IIIl = true;
            this.lIIl = true;
            this.IIIl(var1, true);
         }
      }
   }

   static {
      short var6 = 31598;
      String var7 = "픞홆홊협홒혺혵홋혟픁홎혿혐홉혧황홛핸홏혴홇헔퍝헼\uee8a\uef52\ueede\uee85\uef46\ueeae\ueea1\ueedf\uee83\uee9d\uef5a\ueea3\uef06\uee8d\uef6b\uef5c\uee8e\uef08\ueebb\ueebd\uef56\uef57\uef2f\uee84\ueebd\ueea7\uf1c3\ueedf\uee81\ueebf\uef71\ueead\uef25\uf19b\uef42\ueea6\ueea1\uef20\uf1e5\ueeb9\uf1b0\uef7d\uef19\ueebb\uf1da\uef7a\uee9a\uef0d\uef53\ueebb\uef5c\uef73\uef02\uee8d\uef40\uef7b\uee9e\uf1b7\uef7e\uef68\uef5d\uf1cc\uef2f\uee83\uef54\uef76\uef71\ueed7\ueebe\uef6a\uef70\ueeac\ueed0\ueea3\uef61\ueea6ࠂਥࢋࣝࣕࠏਬੜਉࣀࣀु࿇\u0fe1ᓻ࿁ᒏᒃᒋྕ࿇ᒉᒚ\u0fe7࿊ྑᒒ\u0fecྲᓴྒᒂᒞᒀᓣ࿁\u0ff3\u0feaᒇᓡྜྷᒑ྿\u0fe9ᓸᒷ࿒\u0fecྶྛྒྷᒍᒞ࿏࿁ᒳᒕ\u0fe7ᒘᓯ\u0f98ྦྷᒘᒝ࿀ྐᒌྼᒊྞ\u0fe6ྦྷ࿌ᒇᓱᒼᒏᒇ࿇ᓠᒪྦྷ\u0fcd\u0fe7ྞᒷᒗᒒྐྵ࿂࿁\u0ff9ྐྵྱᓼᒤ慚悩愆慞悒慔慟惨悮慯悩慰愙悃悷悅悚惫慘悂醊醬邶醌邥鉠鉞鈅醀醺鉒醚\ue672\ue59f\ue618\ue64b퉜퉶퇸퉖톋톮퉐툂퉜톒퉜퉵\udac7\udab7\udc20\udc73\ue592\ue4b5\ue49f\ue4cd\ue4de\ue4b7\ue596\ue4b0\ue4c9\ue4fd\ue653\ue4bf\ue49f\ue5b6\ue580\ue4c8䌉䏵䍪䌹偾偟倆偪侸偁亶仅\uf3c0\uf3f9\uf363\uf320\uf314\ue910\uf318\uf37d\uf3df\ue93f\ue910\uf3ff\ue950\ue909\uf3e7\ue929\uf3fe\uf36b\ue903\uf3ee\uf306\uf3f9\uf364\uf33c锫迓遄逗꣤ꣅꢺꢛꢮꣂꢷ\ua9daꢛꣅꢿ\ua8c6䯭₩⃠₳䮪䯅䯭䯀䯢䯝ₙₚ偅俱值偁偸倰倵倔倚偟俼伐倷俊唰俹ꩼ꣎ꨈꩫꦱꦌ꩟ꨬꩾꦛꦇ꩟꧴ꦢꩌꢽ\uebdc\ueb14셕\ueb24\ueb11섑\uebd0\uebad섻섺\ueb04\uebf1셩섂\ueb15섬겡곅곀궁窺竂簄竧籯竏籷篢箸窤籡竍傳僃僆冏摍搪捼摆挕摋挜搔摏摓挜挓摊挬摓揰\ue5bf\ue2ac\ue59e\ue2bc\ue5b5\ue5ea\ue293\ue5bf\ue5e2\ue5af\ue5bc\ue5ba\ue2e3\ue59a\ue5f7\ue280\ue292\ue5ba\ue28c\ue5ad\ue5a0\ue5c7\ue2dc\ue5c9\ue28d\ue29c\ue2a1\ue5bf\ue5e6\ue2bc\ue5c8\ue29f꿒꼝꽾딍꼞꿗꿝꾎";
      char[] var8 = "筶笢筢笺筺筢筪筢筪签筪筦筶筪筢筢签签签筪筢筪签筎筦".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IIIIII = var9;
            IIIIIl = new Object[var9.length];
            int var2 = 1651674175;
            byte[] var0 = "\u008e\u0019Ö«Yø\u0018gMB.\n\u0084YÕg\u008ej`¡PÊÿÂl\u0081_ú{\u009e½Ý\u0092\u0091\u009a¥BÐ\u0097Éó\u008d\u0005-#L\\\u0000Ä®ÚÂ×¸\u001b<UFV\u0004\u0080ßàþÇ= &í}ÿ'£bÙ¿\u0084·/àÚ\u007fÐiZÈ¶¬óÇè\u0000Ò¸±¤¾K\u0096>`\u007f\u00991g\u0083è\u0017".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lllll = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lllll[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            Il = lIlIII.l(IllIII(1098481315, '틺', 42020));
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 113;
                     break;
                  case 1:
                     var10000 = 122;
                     break;
                  case 2:
                     var10000 = 9;
                     break;
                  case 3:
                     var10000 = 90;
                     break;
                  case 4:
                     var10000 = 100;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private class_243 IIIlII(class_310 var1, class_1657 var2, double var3) {
      if (var1 != null && var1.field_1724 != null && var2 != null) {
         class_243 var5 = var1.field_1724.method_33571();
         class_238 var6 = var2.method_5829();
         double var7 = var3 + 1.0E-4;
         double var9 = var7 * var7;
         class_243 var11 = l(var5, var6);
         if (var5.method_1025(var11) <= var9 && this.IIlII(var1, var5, var11)) {
            return var11;
         } else {
            class_243 var12 = var6.method_1005();
            if (var5.method_1025(var12) <= var9 && this.IIlII(var1, var5, var12)) {
               return var12;
            } else {
               class_243 var13 = var2.method_33571();
               if (var5.method_1025(var13) <= var9 && this.IIlII(var1, var5, var13)) {
                  return var13;
               } else {
                  class_243 var14 = new class_243(var12.field_1352, var13.field_1351 - 0.35, var12.field_1350);
                  return var5.method_1025(var14) <= var9 && this.IIlII(var1, var5, var14) ? var14 : null;
               }
            }
         }
      } else {
         return null;
      }
   }

   private boolean IIIlIl(class_310 var1, Object var2, class_3966 var3) {
      if (this.IIIll(var1) && var1 != null && var1.field_1724 != null) {
         long var4 = ++this.IIIlI;
         long var6 = System.currentTimeMillis();
         int var8 = var2 == null.l ? this.IIllI : this.lIlII;
         if (var8 >= 0 && var8 < IlIlll(-162776113, 712319431)) {
            if (!this.IIlIll(var1, var2)) {
               return false;
            } else {
               this.IlIlI = IllllIlI.llIIII(this);
               this.Illl = var2;
               this.llll = var3;
               this.Illll(null.ll, var6);
               float[] var9 = IlIlIl.llIlI(var1, var3.method_17784());
               if (var9 == null) {
                  this.IIIIll(var1, var4, var2, false);
                  return false;
               } else {
                  boolean var10 = IlIlIl.IIIlll(var1, IlIlll(-162776114, -197054484), var9[0], var9[1], () -> this.lIlIl(var1, var4, var2));
                  if (!var10) {
                     this.IllII(var1, IlIlll(-162776115, -205693314));
                     this.Illl = null;
                     this.llll = null;
                     this.Illll(var2 == null.l ? null.lI : null.II, var6);
                     this.IlIIl = var6 + 50L;
                  }

                  return true;
               }
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public String Il() {
      return ((<undefinedtype>)this.II.III()).toString();
   }

   private static boolean IIIllI(double var0, double var2, double var4, double var6, double var8, double var10) {
      if (Math.abs(var0 - var6) > 1.0E-4) {
         return var0 < var6;
      } else if (Math.abs(var2 - var8) > 1.0E-4) {
         return var2 < var8;
      } else {
         return var4 < var10;
      }
   }

   private <undefinedtype> IIlIII(class_746 var1) {
      <undefinedtype> var10000;
      switch (((<undefinedtype>)this.II.III()).ordinal()) {
         case 0 -> var10000 = this.IIlIlI(var1) > (double)3.0F ? null.Il : null.lI;
         case 1 -> var10000 = null.Il;
         case 2 -> var10000 = null.lI;
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   private boolean IIlIIl(class_1799 var1) {
      if (var1 != null && !var1.method_7960()) {
         if (!(var1.method_7909() instanceof class_1743) && !(var1.method_7909() instanceof class_9362)) {
            String var2 = class_7923.field_41178.method_10221(var1.method_7909()).method_12832();
            return var2.endsWith(lIlIII.Il(IllIII(17459803, '㎧', 42027)));
         } else {
            return true;
         }
      } else {
         return false;
      }
   }

   private double IIlIlI(class_746 var1) {
      return var1 == null ? (double)0.0F : Math.max(var1.field_6017, this.lllI);
   }

   private boolean IIlIll(class_310 var1, Object var2) {
      return var2 == null.l ? this.lIlII(var1, this.IIllI, class_1743.class) : this.lIlII(var1, this.lIlII, class_9362.class);
   }

   public void lllIl(class_310 var1) {
      if (this.llllI != null.Il) {
         this.II(var1);
      }

   }

   public void lI() {
      class_310 var1 = class_310.method_1551();
      this.Illll.IIIlIll();
      ++this.IIIlI;
      IllllIlI.IlII(var1, this, null.Il);
      this.llllI(var1, false);
      this.lllll();
      this.IIIIl();
      this.lllI();
   }

   private void IIllIl(class_310 var1, long var2) {
      if (var2 >= this.IlIIl) {
         int var4 = this.IIIIIl(var1);
         if (var4 >= 0) {
            this.lIlII = var4;
         }

         if (this.lIlII < 0 || !this.lIlII(var1, this.lIlII, class_9362.class)) {
            this.lIlII = this.IIIIIl(var1);
            if (this.lIlII < 0) {
               if (this.lI && this.IIllI >= 0) {
                  this.Illll(null.l, var2);
                  this.lIll(var1, var2);
                  return;
               }

               this.IIIl(var1, true);
               return;
            }
         }

         if (!this.IIII(var1, this.lIlII)) {
            if (var2 - this.lll > 500L) {
               this.IIIl(var1, true);
            }

         } else {
            this.Illll(null.II, var2);
            this.IlIIl = this.lII(var2, this.lIIll);
         }
      }
   }

   private void IIlllI(class_746 var1) {
      if (var1 == null) {
         this.lllll();
      } else {
         long var2 = (long)var1.field_6012;
         if (var2 != this.lIIlI) {
            this.lIIlI = var2;
            if (!var1.method_24828() && !var1.method_6101() && !var1.method_5799() && !var1.method_6128() && !var1.method_3144()) {
               double var4 = var1.method_23318();
               if (var1.method_18798().field_1351 < (double)0.0F) {
                  ++this.IlllI;
                  if (Double.isNaN(this.IIlI) || var4 > this.IIlI) {
                     this.IIlI = var4;
                  }

                  this.lllI = Math.max(this.lllI, this.IIlI - var4);
               } else {
                  this.IIlI = var4;
                  this.lllI = (double)0.0F;
                  this.IlllI = 0L;
                  this.lIIl = false;
               }

            } else {
               this.lllll();
            }
         }
      }
   }

   private boolean IIllll(Object var1, Object var2) {
      if (var2 == null) {
         return true;
      } else {
         boolean var10000;
         switch (((<undefinedtype>)this.lIll.III()).ordinal()) {
            case 0 -> var10000 = IIIllI(var1.l(), var1.II(), (double)var1.Il(), var2.l(), var2.II(), (double)var2.Il());
            case 1 -> var10000 = IIIllI((double)var1.Il(), var1.II(), var1.l(), (double)var2.Il(), var2.II(), var2.l());
            case 2 -> var10000 = IIIllI(var1.II(), var1.l(), (double)var1.Il(), var2.II(), var2.l(), (double)var2.Il());
            default -> throw new MatchException((String)null, (Throwable)null);
         }

         return var10000;
      }
   }

   private boolean IlIIII(class_310 var1, class_1657 var2, class_3966 var3) {
      if (var1 != null && var1.field_1724 != null && var2 != null && var3 != null && var3.method_17782() == var2 && var3.method_17784() != null) {
         double var4 = this.IIllI() + 1.0E-4;
         class_243 var6 = var1.field_1724.method_33571();
         return var6.method_1025(var3.method_17784()) <= var4 * var4 && this.IIlII(var1, var6, var3.method_17784());
      } else {
         return false;
      }
   }

   public float IlIIIl(float var1) {
      return class_3532.method_17821(var1, this.IIIll, this.lIIII);
   }

   private boolean IlIIlI(class_310 var1, class_1657 var2, double var3) {
      if (var1 != null && var1.field_1724 != null && var2 != null && var2 != var1.field_1724 && var2.method_5805() && !var2.method_7325() && !var2.method_68878()) {
         lIllIIl var5 = lIllIIl.Il();
         if (var5 != null && var5.IIl() != null && var5.IIl().IlllI() != null && var5.IIl().IlllI().ll(var2)) {
            return false;
         } else {
            return this.IIIlII(var1, var2, var3) != null;
         }
      } else {
         return false;
      }
   }

   public float IlIIll(float var1) {
      return class_3532.method_16439(var1, this.llIl, this.lIlll);
   }

   private class_1657 IlIlIl(class_310 var1, class_1657 var2) {
      if (this.lIIII(var1, var2)) {
         return var2;
      } else if (var1 != null && var1.field_1687 != null && var1.field_1724 != null) {
         class_1657 var3 = null;
         <undefinedtype> var4 = null;

         for(class_1657 var6 : var1.field_1687.method_18456()) {
            if (this.IlIIlI(var1, var6, (Double)this.llIIl.III())) {
               <undefinedtype> var7 = this.lll(var1, var6);
               if (this.IIllll(var7, var4)) {
                  var4 = var7;
                  var3 = var6;
               }
            }
         }

         return var3;
      } else {
         return null;
      }
   }

   private long IlIllI() {
      return this.lIIIl(this.IlIl);
   }

   private static int IlIlll(int var0, int var1) {
      return lllll[var0 ^ -162776105] ^ var1 ^ var0;
   }

   private static String IllIII(int var0, char var1, int var2) {
      int var3 = var2 ^ 'ꐳ';
      char[] var4 = IIIIII[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])IIIIIl[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         IIIIIl[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 11862;
      int var9 = 0;

      do {
         int var10 = var4[var9] - '홢';
         var10 ^= 5388;
         var10 -= 44237;
         var10 -= 22179;
         var10 ^= 10382;
         var10 ^= 63727;
         var10 -= 55395;
         var10 -= 9804;
         var10 -= 23040;
         var4[var9] = (char)(var10 ^ var8 ^ var1 ^ var0 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
