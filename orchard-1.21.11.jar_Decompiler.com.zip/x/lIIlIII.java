package x;

import java.awt.image.BufferedImage;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_437;

@Environment(EnvType.CLIENT)
public final class lIIlIII {
   private static BufferedImage I;
   private static int l = -1;
   private static int II = -1;
   private static class_437 Il;
   private static final long lI = 50L;
   private static long ll;

   private lIIlIII() {
   }

   public static void I() {
      I = null;
      Il = null;
      II = -1;
      l = -1;
      ll = 0L;
   }

   public static void l(class_310 var0, long var1) {
      if (var0 != null && var0.method_22683() != null && var0.field_1687 != null) {
         class_437 var3 = var0.field_1755;
         int var4 = var0.method_22683().method_4486();
         int var5 = var0.method_22683().method_4502();
         long var6 = Math.max(0L, var1);
         long var8 = System.currentTimeMillis();
         if (var8 - ll >= var6 || var3 != Il || var4 != II || var5 != l) {
            BufferedImage var10 = IllllIlI.IIIIII(var0);
            if (var10 != null) {
               I = var10;
               Il = var3;
               II = var4;
               l = var5;
               ll = var8;
            }
         }
      }
   }

   public static void II(class_310 var0) {
      l(var0, 50L);
   }

   public static <undefinedtype> Il() {
      return I == null ? null : new Record(I, II, l, ll) {
         private final int I;
         private final BufferedImage l;
         private final long II;
         private final int Il;

         public {
            this.l = var1;
            this.I = var2;
            this.Il = var3;
            this.II = var4;
         }

         public int I() {
            return this.Il;
         }

         public long l() {
            return this.II;
         }

         public BufferedImage II() {
            return this.l;
         }

         public int Il() {
            return this.I;
         }
      };
   }
}
