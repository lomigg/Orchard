package x;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_304;
import net.minecraft.class_310;

@Environment(EnvType.CLIENT)
public final class lIlIIIlI extends IIIIIIIlI {
   private static String[] I;
   private final llllIlIl l;
   private final lIIIIl II;
   private final IlIIIlIlI<<undefinedtype>> Il;
   private final IlIIIlII lI;
   private static final int[] ll;
   private static final String[] III;
   private static final Object[] IIl;

   public void lIl() {
      this.II();
   }

   public void lllIl(class_310 var1) {
      this.lII(var1);
   }

   private boolean l(class_310 var1) {
      if (this.Il.III() == null.II) {
         IllllIlI.lIllll(var1);
         IllllIlI.llIllI(var1);
         return true;
      } else if (IllllIlI.IlIllIl(var1, IllllIlI.llIII(var1))) {
         return false;
      } else {
         IllllIlI.IIlII(var1);
         IllllIlI.IIlIlII(var1);
         return true;
      }
   }

   static {
      short var6 = 11458;
      String var7 = "좃屚儝\u1cc9菤\ue07fⶹв\udfe1頢\uea4e鴚\uf140蜜䷰厛\uee80\uee72긗侑韥鲥爂䣵Ŷ廼⊡沖릑룿⭜皣犴乷냊籚얺櫖纘⥇≽켥\udedd\ue4c0᚛̅랗樶ἡƜ\u0ee0길蚤⎵勘롳셨绫㪿풼捄콤셳這\u007fẵ\uec70휕ᵺ樂䔷ᴩ珠㿋륄\ua83c䍯ᒰ霴ႌꖪ츐⭞䥴ꓹ\ue4aa㼅琻긿ᲴỔ赥蔼ﭦ䍆㳓沆ᴄ萑츤ᇅ∢䋵⫻枥\uf8d4劧璥Ｚ덗낛鳇ળ뢖㽦\ue3f7涙࿌ꬼ⌊\ue4fa裴뤊\u209e\uda0f⸸쏼쇐";
      char[] var8 = "ⳆⳎⳒⳚⳆⳊ⳾".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            III = var9;
            IIl = new Object[var9.length];
            int var2 = -415980223;
            byte[] var0 = "´\u0013#6Q/1º\u000e fAþ½\u0087Àá\u0085d)^\u008c\u0016á\u0016\u0090\u0011<Ìo?\u0091\u0080\u008a1ðâÔç¶\u009eõÀ\u0084Àr\u0091©".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            ll = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               ll[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            I = new String[lll(935644655, 1692617631)];
            ll();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public String Il() {
      return ((<undefinedtype>)this.Il.III()).toString();
   }

   public lIlIIIlI() {
      super((Object)lIlIII.l(I[2]), lIllII.I, (Object)lIlIII.l(I[lll(935644654, -2116069101)]));
      this.l = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(I[0]), (double)10.0F, (double)14.0F, (double)1.0F, (double)20.0F, (double)0.5F)).IIII(lIlIII.Il(I[4])));
      this.Il = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(I[5]), <undefinedtype>.class, null.I));
      this.II = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(I[3]), true));
      this.lI = new IlIIIlII();
   }

   private void II() {
      this.lI.I();
   }

   private static void ll() {
      I[0] = llI(IIII(-287762200, -1017099713).toCharArray(), 79285L, lll(935644653, 1181133793));
      I[1] = llI(IIII(-287762199, -1250142676).toCharArray(), 65825L, lll(935644652, -254555162));
      I[2] = llI(IIII(-287762198, -1109689796).toCharArray(), 66556L, lll(935644651, 1023685709));
      I[3] = llI(IIII(-287762197, 834944502).toCharArray(), 12839L, lll(935644650, -287091064));
      I[4] = llI(IIII(-287762196, 516119229).toCharArray(), 29963L, lll(935644649, -1542491632));
      I[5] = llI(IIII(-287762195, -1097659247).toCharArray(), 78472L, lll(935644648, 1095475820));
      I[lll(935644647, 1350195536)] = llI(IIII(-287762194, 137844505).toCharArray(), 76433L, lll(935644646, 248075139));
   }

   public void lI() {
      this.II();
   }

   private class_304 III(class_310 var1) {
      if (var1 != null && var1.field_1690 != null) {
         return this.Il.III() == null.II ? var1.field_1690.field_1904 : var1.field_1690.field_1886;
      } else {
         return null;
      }
   }

   private boolean IlI(class_310 var1) {
      if (this.IIIIIlI() && var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var1.field_1755 == null && var1.field_1690 != null) {
         if (var1.field_1724.method_6115()) {
            return false;
         } else if (!(Boolean)this.II.III()) {
            return true;
         } else {
            class_304 var2 = this.III(var1);
            return var2 != null && (IllllIlI.IIIll(var1, var2) || var2.method_1434());
         }
      } else {
         return false;
      }
   }

   private void lII(class_310 var1) {
      if (var1 != null && this.IlI(var1)) {
         if (this.lI.Il()) {
            if (this.l(var1)) {
               this.lI.l(this.l.IlII(), this.l.IlI());
            }

         }
      } else {
         this.II();
      }
   }

   public void IIl(JsonObject var1) {
      super.IIl(var1);
      if (var1 != null && var1.has(lIlIII.Il(I[1]))) {
         JsonObject var2 = var1.getAsJsonObject(lIlIII.Il(I[1]));
         if (var2 != null) {
            JsonElement var3 = var2.get(lIlIII.Il(I[0]));
            if (var3 != null && var3.isJsonPrimitive() && var3.getAsJsonPrimitive().isNumber()) {
               double var4 = var3.getAsDouble();
               this.l.IIIl(new double[]{var4, var4});
            }

         }
      }
   }

   private static String llI(char[] var0, long var1, int var3) {
      int var4 = lll(935644645, 2057490417) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & lll(935644644, 277019123);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private static int lll(int var0, int var1) {
      return ll[var0 ^ 935644655] ^ var1 ^ var0;
   }

   private static String IIII(int var0, int var1) {
      int var3 = var0 ^ -287762200;
      char[] var4 = III[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IIl[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IIl[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -943114900;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 151;
               break;
            case 1:
               var9 = 188;
               break;
            case 2:
               var9 = 33;
               break;
            case 3:
               var9 = 101;
               break;
            case 4:
               var9 = 87;
               break;
            case 5:
               var9 = 222;
               break;
            case 6:
               var9 = 154;
               break;
            case 7:
               var9 = 222;
               break;
            case 8:
               var9 = 111;
               break;
            case 9:
               var9 = 129;
               break;
            case 10:
               var9 = 2;
               break;
            case 11:
               var9 = 252;
               break;
            case 12:
               var9 = 127;
               break;
            case 13:
               var9 = 13;
               break;
            case 14:
               var9 = 212;
               break;
            case 15:
               var9 = 247;
               break;
            case 16:
               var9 = 161;
               break;
            case 17:
               var9 = 109;
               break;
            case 18:
               var9 = 72;
               break;
            case 19:
               var9 = 174;
               break;
            case 20:
               var9 = 66;
               break;
            case 21:
               var9 = 179;
               break;
            case 22:
               var9 = 175;
               break;
            case 23:
               var9 = 0;
               break;
            case 24:
               var9 = 146;
               break;
            case 25:
               var9 = 35;
               break;
            case 26:
               var9 = 174;
               break;
            case 27:
               var9 = 88;
               break;
            case 28:
               var9 = 196;
               break;
            case 29:
               var9 = 218;
               break;
            case 30:
               var9 = 23;
               break;
            case 31:
               var9 = 114;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
