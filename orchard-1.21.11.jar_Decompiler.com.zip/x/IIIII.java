package x;

import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_239.class_240;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;

@Environment(EnvType.CLIENT)
public final class IIIII extends IIIIIIIlI {
   private final IIIllIIII I;
   private static String[] l;
   private final lIIIIl II;
   private final lIIIIl Il;
   private static final long lI = 2500L;
   private final IIIllIIII ll;
   private final IIllIlIII III;
   private final lIlllII IIl;
   private final IIIllIIII IlI;
   private static final int Ill = 96;
   private final IIIllIIII lII;
   private static final int[] lIl;
   private static final String[] llI;
   private static final Object[] lll;

   private static String ll(char[] var0, long var1, int var3) {
      int var4 = lIII(242159223, 2081943418) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & lIII(242159222, 92001989);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private void IlI(llIIllI var1, class_238 var2, class_243 var3, class_243 var4, double var5, Color var7, double var8, float var10, boolean var11) {
      IIlIIIIl.llll(var1, var4, var5, lIII(242159221, -835339342), var7, var8, var10);
      if (var11) {
         IIlIIIIl.IlII(var1, var4, var5, lIII(242159220, -239311183), var7, var8, var10, false, (var6) -> this.IlIl(var3, var4, var5, var2, var6));
      }
   }

   public void llIl(llIIllI var1) {
      if (IIlIIIIl.IlIII(var1)) {
         class_310 var2 = class_310.method_1551();
         class_1309 var3 = this.lII(var2);
         if (var2 != null && var3 != null) {
            float var4 = IllllIlI.IlIIIlI(var2);
            class_243 var5 = IIlIIIIl.IIIII(var3, var4);
            class_238 var6 = var3.method_5829().method_989(var5.field_1352 - var3.method_23317(), var5.field_1351 - var3.method_23318(), var5.field_1350 - var3.method_23321());
            double var7 = Math.max(0.35, var6.method_17940());
            double var9 = Math.max(0.3, (double)var3.method_17681() * 0.65) + (Double)this.I.III();
            double var11 = (double)System.nanoTime() / (double)1.0E9F;
            double var13 = var11 * Math.PI * (double)2.0F * (Double)this.IlI.III();
            Color var15 = this.IIll();
            double var16 = (Double)this.ll.III();
            class_243 var18 = IIlIIIIl.Il(var1);
            boolean var19 = this.Illl(var2, var18, new class_243(var6.method_1005().field_1352, var6.method_1005().field_1351, var6.method_1005().field_1350));
            if ((Boolean)this.II.III()) {
               for(int var20 = 4; var20 >= 1; --var20) {
                  double var21 = var13 - (double)var20 * 0.11;
                  double var23 = (Math.sin(var21) + (double)1.0F) * (double)0.5F;
                  double var25 = var5.field_1351 + 0.04 + var23 * Math.max(0.05, var7 - 0.08);
                  double var27 = var16 * (0.3 - (double)var20 * 0.045);
                  this.IlI(var1, var6, var18, new class_243(var5.field_1352, var25, var5.field_1350), var9, var15, var27, Math.max(0.5F, ((Double)this.lII.III()).floatValue() - (float)var20 * 0.2F), var19);
               }
            }

            double var29 = (Math.sin(var13) + (double)1.0F) * (double)0.5F;
            double var22 = var5.field_1351 + 0.04 + var29 * Math.max(0.05, var7 - 0.08);
            this.IlI(var1, var6, var18, new class_243(var5.field_1352, var22, var5.field_1350), var9, var15, var16, ((Double)this.lII.III()).floatValue(), var19);
         }
      }
   }

   private class_1309 lII(class_310 var1) {
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null && this.IIl != null) {
         class_1309 var2 = this.IIl.llII();
         if (!this.IlII(var1, var2) && this.IIl.I(System.currentTimeMillis()) <= 2500L) {
            var2 = this.IIl.Ill();
         }

         return this.IlII(var1, var2) ? var2 : null;
      } else {
         return null;
      }
   }

   private static void IIII() {
      l[0] = ll(lIIl(-1054409202, 107481996).toCharArray(), 63180L, lIII(242159219, 1659948879));
      l[1] = ll(lIIl(-1054409201, -830326541).toCharArray(), 76026L, lIII(242159218, -932100564));
      l[2] = ll(lIIl(-1054409204, -1463406139).toCharArray(), 96715L, lIII(242159217, -220718953));
      l[3] = ll(lIIl(-1054409203, 1404202035).toCharArray(), 66389L, lIII(242159216, -821812367));
      l[4] = ll(lIIl(-1054409206, 710087517).toCharArray(), 67916L, lIII(242159231, -572440551));
      l[5] = ll(lIIl(-1054409205, -1269994859).toCharArray(), 24516L, lIII(242159230, -62541191));
      l[lIII(242159229, -357364892)] = ll(lIIl(-1054409208, -135571298).toCharArray(), 6485L, lIII(242159228, 2070584666));
      l[lIII(242159227, 2042905945)] = ll(lIIl(-1054409207, -383886595).toCharArray(), 24442L, lIII(242159226, 1794231256));
      l[lIII(242159225, -215735667)] = ll(lIIl(-1054409210, 1979131053).toCharArray(), 50222L, lIII(242159224, 1555168126));
      l[lIII(242159207, -1876531996)] = ll(lIIl(-1054409209, -1840569994).toCharArray(), 51878L, lIII(242159206, -1886979998));
   }

   static {
      short var6 = 24884;
      String var7 = "릓썳댾\udb2d䐀鶴ⷁ볳\u0bd8\uecb1\ue88c⁴ⴃㄬ꯫㸁蜥⑿㌽᯲訦쥉휎ॴ䫗\ue308劎铩例落刦ꪕ쌇ᡱ퀟칤\udd40ຉⴷ\u0e73㕣⃀৴軯ꃑﳿ蹱餯猨砶횫賅憚튖嗥岀꛵䊫\uf453潴\uf7ff烚챁ꅮ噆ࡇ뷒䨡\ue89bꊵ艀麌䬆뛙ﮟ珎ൻ\uf8bb埉놄읞堶\ue918婗鏎鲻覐﹂꣗퍁\uf750㦔䀤\ue2c0\uf6f1滚Ⴡ撩Ⱜ\ue790ᱫ০僡ẳ\ud8fd皨ₗ欲\udbb7꿻術冉\ue6e1䤻㚊Ї항鬍ᔘ켿蛊訝厚뼃멖ᘃ孊鞹杣盓ꔢ愗ᮆ텉褜熰풚ꔙ퓻\ue7af䝞⥑ᝁ舑\uecff韠侵텯ꑛטּꪚ\udc9c潾㑐띏▗톐䖬\ue6da\u0cdb囐ᛀ⽀垗傘✬ꖳ뻬㎀\ue465鈿ꆱ᳠ᚷ巽꾜\uf76a㗹槗㱱䞵䨁樉꣕\uf1f6（ￖ쉘\ud8fa䈐髙㦆";
      char[] var8 = "\b\b\u0010\u0010\b\b\u0004d\b\u0010".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            llI = var9;
            lll = new Object[var9.length];
            int var2 = -74442395;
            byte[] var0 = "d2íÂð\u0084Á);Ê¬Â\u0004CqÀä`u$'¼<ñ¦\u0019¥+\"b\u0014Éèô\u0092Ú\u001cf\fG\u001fL\u001cz\u0086\u0080·a\u008c;R@>Cöâ\u0006Û5\u0099\u007fe\u001cÄeÙsïÛµ\u0094È\u0006UC¹Z\u0087\u0090ö--àÐZ\u000fô \u001dÑÁ\u001fÇ»Ë rN\u007fÎý²å7äj±\u009a6³¯J".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lIl = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lIl[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            l = new String[lIII(242159205, -206941005)];
            IIII();
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 39;
                     break;
                  case 1:
                     var10000 = 15;
                     break;
                  case 2:
                     var10000 = 75;
                     break;
                  case 3:
                     var10000 = 35;
                     break;
                  case 4:
                     var10000 = 87;
                     break;
                  case 5:
                     var10000 = 39;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private Color IIll() {
      Color var1 = (Color)this.III.III();
      if ((Boolean)this.Il.III()) {
         lIllIIl var2 = lIllIIl.Il();
         lIIIllll var3 = var2 != null && var2.IIl() != null ? var2.IIl().IIII() : null;
         if (var3 != null) {
            var1 = var3.IIllII();
         }
      }

      int var4 = class_3532.method_15340((int)Math.round((Double)this.ll.III()), 0, lIII(242159204, -1351055608));
      return new Color(var1.getRed(), var1.getGreen(), var1.getBlue(), var4);
   }

   private boolean IlII(class_310 var1, class_1309 var2) {
      return var2 != null && var2 != var1.field_1724 && var2.method_5805() && !var2.method_31481() && !var2.method_7325() && !IlIII.l(var2) && var1.field_1687.method_8469(var2.method_5628()) == var2;
   }

   private boolean IlIl(class_243 var1, class_243 var2, double var3, class_238 var5, int var6) {
      double var7 = (Math.PI * 2D) * (double)var6 / (double)96.0F;
      double var9 = (Math.PI * 2D) * (double)(var6 + 1) / (double)96.0F;
      class_243 var11 = new class_243(var2.field_1352 + (Math.cos(var7) + Math.cos(var9)) * var3 * (double)0.5F, var2.field_1351, var2.field_1350 + (Math.sin(var7) + Math.sin(var9)) * var3 * (double)0.5F);
      return x.IlIllIl.IlI(var1.field_1352, var1.field_1351, var1.field_1350, var11.field_1352, var11.field_1351, var11.field_1350, var5.field_1323, var5.field_1322, var5.field_1321, var5.field_1320, var5.field_1325, var5.field_1324);
   }

   public IIIII(lIlllII var1) {
      super((Object)lIlIII.l(l[2]), lIllII.ll, (Object)lIlIII.l(l[lIII(242159203, -657262639)]));
      this.I = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(l[1]), 0.12, (double)0.0F, (double)1.0F, 0.01)).IIl(lIlIII.Il(l[lIII(242159202, -1343167711)])));
      this.IlI = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(l[0]), (double)1.0F, 0.1, (double)3.0F, 0.05));
      this.lII = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(l[3]), (double)5.0F, (double)0.5F, (double)5.0F, 0.1));
      this.ll = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(l[4]), (double)235.0F, (double)20.0F, (double)255.0F, (double)1.0F));
      this.II = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(l[5]), true));
      this.Il = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(l[lIII(242159201, -399583726)]), true));
      this.III = (IIllIlIII)this.IIIlIll(new IIllIlIII(lIlIII.l(l[lIII(242159200, 843373613)]), new Color(lIII(242159215, -2018416488), lIII(242159214, 139326190), lIII(242159213, 295020141), lIII(242159212, -1018382168))));
      this.IIl = var1;
      this.III.lIII(() -> !(Boolean)this.Il.III());
   }

   private boolean Illl(class_310 var1, class_243 var2, class_243 var3) {
      if (var1 != null && var1.field_1687 != null && var1.field_1724 != null && var2 != null && var3 != null) {
         class_3965 var4 = var1.field_1687.method_17742(new class_3959(var2, var3, class_3960.field_17558, class_242.field_1348, var1.field_1724));
         return var4 == null || var4.method_17783() == class_240.field_1333;
      } else {
         return false;
      }
   }

   private static int lIII(int var0, int var1) {
      return lIl[var0 ^ 242159223] ^ var1 ^ var0;
   }

   private static String lIIl(int var0, int var1) {
      int var3 = var0 ^ -1054409202;
      char[] var4 = llI[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])lll[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         lll[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 2009752599;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 118;
               break;
            case 1:
               var9 = 149;
               break;
            case 2:
               var9 = 37;
               break;
            case 3:
               var9 = 135;
               break;
            case 4:
               var9 = 102;
               break;
            case 5:
               var9 = 141;
               break;
            case 6:
               var9 = 32;
               break;
            case 7:
               var9 = 190;
               break;
            case 8:
               var9 = 119;
               break;
            case 9:
               var9 = 218;
               break;
            case 10:
               var9 = 151;
               break;
            case 11:
               var9 = 149;
               break;
            case 12:
               var9 = 185;
               break;
            case 13:
               var9 = 108;
               break;
            case 14:
               var9 = 170;
               break;
            case 15:
               var9 = 204;
               break;
            case 16:
               var9 = 38;
               break;
            case 17:
               var9 = 33;
               break;
            case 18:
               var9 = 245;
               break;
            case 19:
               var9 = 8;
               break;
            case 20:
               var9 = 105;
               break;
            case 21:
               var9 = 69;
               break;
            case 22:
               var9 = 166;
               break;
            case 23:
               var9 = 184;
               break;
            case 24:
               var9 = 192;
               break;
            case 25:
               var9 = 22;
               break;
            case 26:
               var9 = 29;
               break;
            case 27:
               var9 = 105;
               break;
            case 28:
               var9 = 28;
               break;
            case 29:
               var9 = 214;
               break;
            case 30:
               var9 = 178;
               break;
            case 31:
               var9 = 136;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
