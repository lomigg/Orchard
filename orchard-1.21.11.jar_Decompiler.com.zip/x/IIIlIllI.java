package x;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_124;
import net.minecraft.class_1291;
import net.minecraft.class_1292;
import net.minecraft.class_1293;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4081;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

@Environment(EnvType.CLIENT)
public final class IIIlIllI extends IIIIIIIlI implements llIlIIII {
   private final IIllIlIII I;
   private double l;
   private final IIIllIIII II;
   private final IIIllIIII Il;
   private long lI;
   private final IIIllIIII ll;
   private double III;
   private final lIIIIl IIl;
   private static final <undefinedtype> IlI;
   private static final double Ill = (double)5.0F;
   private final lIIIIl lII;
   private static final double lIl = (double)200.0F;
   private final IIIllIIII llI;
   private static final double lll = 2.3;
   private final IIIllIIII IIII;
   private final IIIllIIII IIIl;
   private static final double IIlI = (double)7.0F;
   private final lIIIIl IIll;
   private static final int IlII = 96;
   private final lIIIIl IlIl;
   private static String[] IllI;
   private static final double Illl = 5.8;
   private static final double lIII = 0.18;
   private static final double lIIl = 0.9;
   private static final double lIlI = 0.78;
   private static final double lIll = (double)6.0F;
   private static final double llII = (double)138.0F;
   private final Map<String, <undefinedtype>> llIl;
   private static final int[] lllI;
   private static final String[] llll;
   private static final Object[] IIIII;

   private void l(class_332 var1, class_327 var2, double var3, double var5, double var7, double var9, Object var11, int var12, double var13, boolean var15) {
      double var16 = IIIIlI.Il(var13);
      if (!(var16 <= 0.01)) {
         double var18 = (double)1.0F;
         double var20 = IIIIlI.Il(var16 * var18);
         lllIIlI.II(var1, IlI, var3, var5, var7, var9, var15, var16);
         double var22 = this.IIll();
         double var24 = var3 + var22 + 5.8;
         double var26 = var5 + var9 * (double)0.5F;
         double var28 = (Boolean)this.IIll.III() ? var11.l * 0.78 : (double)0.0F;
         double var30 = var3 + var7 - var22 - (double)4.0F;
         double var32 = var30 - var28;
         double var34 = var24 + 5.8 + (double)5.0F;
         double var36 = var5 + var9 * (double)0.5F;
         Objects.requireNonNull(var2);
         double var38 = var36 - (double)9.0F * 0.9 * (double)0.5F;
         double var40 = Math.max((double)22.0F, ((Boolean)this.IIll.III() && !var11.Ill.isEmpty() ? var32 - (double)7.0F : var30) - var34);
         String var42 = IIIIIIllI.lIlIlI(var2, var11.Il, var40 / 0.9);
         int var43 = lIlIIIIl.l(var12, IIIII(-1490692898, 1468823862), 0.72);
         int var44 = lIlIIIIl.IIlI(var43, 0.94 * var20);
         this.Illl(var1, var2, var42, var34, var38, var44, 0.9);
         if ((Boolean)this.IIll.III() && var11.Ill != null && !var11.Ill.isEmpty()) {
            int var45 = lIlIIIIl.IIlI(var11.II, var11.IlI ? 0.96 * var20 : 0.86 * var16);
            Objects.requireNonNull(var2);
            double var46 = var36 - (double)9.0F * 0.78 * (double)0.5F;
            this.Illl(var1, var2, var11.Ill, var32, var46, var45, 0.78);
         }

         int var48 = lIlIIIIl.l(var11.II, IIIII(-1490692897, 345849928), 0.7);
         int var49 = lIlIIIIl.IIlI(var48, var16);
         int var47 = lIlIIIIl.IIlI(var11.II, var16);
         this.lIll(var1, var24, var26, 5.8, 2.3, var11.I, var47, var49);
      }
   }

   private void II(class_332 var1, boolean var2, boolean var3) {
      class_310 var4 = class_310.method_1551();
      if (var4 != null && var4.field_1772 != null && var4.field_1724 != null) {
         class_327 var5 = var4.field_1772;
         long var6 = System.currentTimeMillis();
         double var8 = this.IlI(var6);

         for(<undefinedtype> var11 : this.llIl.values()) {
            var11.l = false;
         }

         int var33 = 0;
         ArrayList var34 = new ArrayList(var4.field_1724.method_6026());
         var34.sort(Comparator.comparingInt(class_1293::method_5584).reversed());

         for(class_1293 var13 : var34) {
            String var14 = llI(var13);
            <undefinedtype> var15 = (<undefinedtype>)this.llIl.computeIfAbsent(var14, <undefinedtype>::new);
            var15.l = true;
            var15.ll = var33++;
            int var16 = var13.method_48559() ? IIIII(-1490692900, -440836742) : Math.max(0, var13.method_5584());
            if (var13.method_48559()) {
               var15.Il = IIIII(-1490692899, -1025157865);
            } else if (var16 > var15.Il || var15.Il <= 0) {
               var15.Il = Math.max(1, var16);
            }

            var15.II = this.IlIl(var4, var5, var13, var15.Il);
         }

         List var35 = this.lIII(var8);
         if (var35.isEmpty() && var2) {
            Object var36 = new Object(lIlIII.Il(IllI[0])) {
               final String I;
               boolean l;
               <undefinedtype> II;
               int Il;
               double lI;
               int ll;

               {
                  this.I = var1;
               }
            };
            ((<undefinedtype>)var36).l = true;
            ((<undefinedtype>)var36).lI = (double)1.0F;
            ((<undefinedtype>)var36).II = this.lllI(var5);
            var35.add(var36);
         }

         if (var35.isEmpty()) {
            this.l = (double)0.0F;
         } else {
            var35.sort((var0, var1x) -> {
               int var2 = Integer.compare(var1x.II.lI, var0.II.lI);
               return var2 != 0 ? var2 : Integer.compare(var0.ll, var1x.ll);
            });
            double var37 = (Double)this.Il.III();
            double var38 = (Double)this.IIIl.III();
            double var17 = (double)138.0F;

            for(<undefinedtype> var20 : var35) {
               var17 = Math.max(var17, var20.II.ll);
            }

            double var39 = (double)var35.size() * var37 + (double)Math.max(0, var35.size() - 1) * var38;
            this.III = var17;
            this.l = var39;
            double var21 = this.ll();
            IIIIIIllI.IIIllI(var1);

            try {
               IIIIIIllI.IlII(var1, (Double)this.llI.III(), (Double)this.IIII.III());
               IIIIIIllI.lllI(var1, var21, var21);
               double var23 = (double)0.0F;
               int var25 = this.I.III() == null ? -1 : ((Color)this.I.III()).getRGB();

               for(<undefinedtype> var27 : var35) {
                  double var28 = Math.max((double)138.0F, var27.II.ll);
                  this.l(var1, var5, (double)0.0F, var23, var28, var37, var27.II, var25, var27.lI, var3);
                  var23 += var37 + var38;
               }
            } finally {
               IIIIIIllI.lIIlIl(var1);
            }

         }
      }
   }

   public void IIl(class_332 var1, int var2, int var3, float var4) {
      this.II(var1, false, false);
   }

   private double ll() {
      return Math.max(0.4, (Double)this.II.III() / (double)100.0F);
   }

   public void lIlI(double var1, double var3) {
      this.llI.III(Math.max((double)0.0F, var1));
      this.IIII.III(Math.max((double)0.0F, var3));
   }

   static {
      short var6 = 31297;
      String var7 = "婞⌑켃ｲ㊀Ꮐড閆흜皮ᅊ쨭\ueec7㍀갪ᘍ齦亠넮꧅ꃒ葷閌\uea57ﵚ쑶橀敎氱蓤\uf8e5瘪\u05cf῝㛟渪\uda25귯䟓別븳䁲섬靳颃\uf116ᰯ倠ㅙꢑ픈將긺懻扡િĥ뉴뭯⻒䰶軵\udff6鐌袥揧榻Ã긇欰堄\uea3f\ue3e6㱠쎴룏ᇶẤ㥛眄␙좙籃탋ꪏ쥌겹ᶛ\ue7e7\udc32\uefa9\ue60f䬭찋轗唨⥅\ud986뇶\udec0䩮勔ӫ实\ude68糈쇉铏壡\u2072◳⚢绊駱髍䮢놄턯芹軙㍑፫軅刎拏Ḣ䯩\uf726ꔇ鐹엗㉐\ue41aꅀ燹ꩥ蕣\ue2ad祦뜿屠尀\uf625䑓䖞琘\uf08b\ue773娒\ude7f➑옲䚑湜\ue852꧉改䊢끾㣥\ueffc湸㮯虔䀎\ue60b㌿䇶廘Ȑ✝\uedf4絮ໂ\ue8da寛鑤\u2d6c\uf374\uf397⧳㱗郩ᙽ\ueb77Ȉ䑃Őศ朲봣ﮮ敾排䨹桩뜥\uda07㠱吼醃䊤ꪐ\uf6c1Ǥ\u31ee憪絲㺢㯅㻗全ⱔ⣖建沬痃禪깏\u05ec맔\ue141쇝ぱﳬ뺸鴜ᘛō䮔кϮ倏궮鎻㯰摑줤瓟븭痶礫펉癐\uf342部⼚ᄒ䑺䉠핍덪ꛟɏﰑᤙ䇯㠹\ue4c5ໞ側ᧄྻࠉ籂ꖲ㰲\uaacf䈕垆鞋嶃᳤駖\u0eeeㅌ䖘)ᩔ႑︳猅껂셉擂ᡣ串⧢棤蟵鈨䨏嘛魯Ю䘾궛\ue07d璢俊ꗵᘃ戠丏쪋爚꤯邛力ꂨקּ絛融릅諕뿴ꔉ\ud8a8\ue365緪왁\uf8d2돦ꉡ붢석֨탉脴僗\udc79걽텠㗶ᙾ鬡\ue736㱐᷸觷غ婪\ue747\ue7a8\ue79b審仸홱⏷癬鉋鲺榽宓\uf36c㔋疆帥㳉㸺\uee5c鱓㙥亣渗췺\uf408ꍾ㻒啹ۊ휇裬\ue7a5ꖙᥭ\uf0fc䱑ᬲ槳\u187c䤍膿黝닼캕ힼ갼v颡쨳䊡ໆ䗞뜩퍩\ue88f悊滉븭赅\uf351堗싣벭㳫ꤠ\udb09邦锯夓﹥⏔鯹琙熞赱恋ᄀ⨮ꭻ\uedb4\ue5c6羝왂\ue390复禎㚃刊籞샶你堂\ueeb2\ufdd6ꉵ㲇痢혀돚ࣝ醝㳃佺㹺堋涢倬판\ue935ك\ueda9走\ufe1f\uebf0\u2efa漎\ue33b銠惘먯\ud7fc㓅萴ᣆ辗雺钥ᠺ\ud972즺⊑镓僱ꯥ忲瀚\u0e85步煠\uf380吕ᆶﴻ\uf4a1ꗋ啹즀逬\uef7e᬴璽㔋⻟喢揩㥚맦腃ﾘ쁊\udf33톜복顴\udcad䑖᧕멩羐吚Ⅶꢪ⹄໙ᒧ窴➯網ᠮ꯬綑᧙퉃審텲䧆\uf76cꂧ\uf8ae둽组ូ⩤貅\ude98텄ඩѪ䍆딆骴叨ⷃ꽿ᢢ崴\uebc2\uf17bዛ삌佔覷采姂\ue607댜䃼쎲窴믊잺锤楫ྕ킁ٍ䗛林ꄕ㎰駬쟅듡՞썈֮싧쿰䥨锫꘡摪ᔛꦀ穜ᨤ賐澴㸰鷡ᄲ\uef55垻\udabd✐ꥲ♬\ueeaf\ue0ad్㿈楲㽩";
      char[] var8 = "穉穅穅穅穅穅穅穅穅穅穉穅積穅積穱穕穑穕積穅穉積穅穑積穅穙積穉穏穉穄積穉穅穏穇穋穋穆積穒穋穉穇穋穋積穇穎穉積穏穎積穈穇穄穉穇".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            llll = var9;
            IIIII = new Object[var9.length];
            int var2 = 1134191928;
            byte[] var0 = "Lä\u00168\u000f7ì\u0087~ù\u0013aY¥\u001b\rÒ¾sWÙáé`3a+ ÞyLÒVÖ\u0012sÿ³\u0004\u009f?\u0007\u0011±\u0017´_ùÛþÊId\u009e\u001eÌV)\u0013\u008dH\u0092æÑ\u0096t\bS\u008a\u0018þ}\u0000ùÇ\u0086¤sáè`5t\u0007OÖ~ÙoIÇ¢j0B>\u008aP`\u0003Ë\u001bô²\u0003ÎÖ@s`_Bär ©Û^Á\"i2¡¤ôèxµ\u001a\u009e\u008e~\u0094B\u001bST·\u0013Î¼\u00935þ\u0088\u0014\u0003Q´eÓ\u008e\u001eKë\u0091fKùNå²i×vb~\u0088\u007fÐÐ1\u000bÓ¡9×¼î<\u000fò\u0084ÖÌP8häÿÎ\u0018\u000e\u008dh»\u0097|&\u0084\u0089\u0087\u008aÅß×\"\u0092\u0085ñ\u0007\u008a·õãN\u001eà0u\b\u0086&ß÷¶5ºXNí±ü\fB\u0012äê÷Mu?º Zé¸\u009axä\nµ\u0004\u0096#ñS\u000fËòQ'Â\u009f¢W\u00186¹×\rÕQÿxIÕË±â\u0082«þp\u001e_\u0012/¬V·xSd[©\u0006d\u0004¢\u0017Ã\u0016Û=\"6N³äëÊr|\u0090bt\u0098\u000f[jÊ@Ä½\u00ad¶ï\n\u0018\u0012\\0´ô\u0003\u0099\u0088\u0005¨[\u008bd\u00882®ZðòJYaÖõ\u0083ò3\u0014T]~,VO0ù5\u0092ï\u0002½\u0086\u0096Ôf\u009e¼u´V*S\u0003D+b\u009c\u0089æFéfôÖ¤ÈÂYFcIéùXãÆÙÿê2{\u009fª\u0096:µ\u0017ú½8_\u001e\u0081hoP-@Øí\u0012\u009a\u0082\u0013\"pìý¿.\u0006\u0014ò\u008aOs-iîã\u001aùª\u001fb\u001fiù\u009b\u009eqG%? õ´z'Ìúä\fwµ\u001aÒÝ0Ö\u008cyºk\u00113dÑ* \u0016$Ò¯H\u001eG<o\u008c=\u0014\u0007\u0091\u008dUtY\u0001\u009e\u0018\u0017\u001bá\u0080ar\u0096eËsD4\u0080Â[\u0095G\t£ð\u0005\u0086*<=\u0086\u000e(J=\u00937\u001a÷-Mi¼\u0095\u0095\u0006I±`pÖ\u0016H\u0012m\u0018\u008aÜÚ='\u0011VÛðÏ\u000bÁ\u001a\u001eÈÅ¨SØÊÔ4\u00ad\u009e9x¤Ô\u0000\f\u001b»Ó+º\u0007\u008a\u0011ÈV ö?ö_\u0096\u0098|\u0099>¨\\ÕæíµÀK&È\\¬ø\u0094Ã¿ö·ö\u009c\u0080¹&\u008c3Ë©t\\P¨Ã¬¯à\u008eØRû®½y\u0010\u000ezMÇ\u0014\u00adöF\u009bwÉ£¶²p\u0019\u008cÎ\u001d\bé[M0÷¯I PSS¤\u0000ïÜÑÌÊf\u0084²`=\u00842Ñhõ\u0086à0ÛBPnM#ÏU\u009c\u008dÐ\u0092«\u009dµ\u008d\rµ\u0095\u008aoïÓ\tÞ\u008f\u0095±ø+*ÝÛ'Æ\u007f Îç\u000fùá\u008c×öö\u008b\u001føxzJU\u009f\u008cá»Fe\u001c¦M\u0085ä\u001cÏ#\u001a«Ó¾HJF\u0016A\u0094\u0096\u001ep\"cZòÔjù\u0000q\u009ffB/\u001eQ*hË2\u0092E\u0014¦\u0006\u0096þ\u0016\u008e\u007fhrðÁ\u0000kì\u0086n~q÷\u0099×ã6·äv2*Þ\u0086Ùñ¨ßXê÷Å\u0082ú\u009a\u0007î!\u008c9ªëF\u001boê\u0005$äX\u0084\u000f<\u0083tIR\u0089\u0004æ\u009aÍ\u0006ñ\u001a?<ëbI\u001aþÓü\u001d\u0098w¢â¡büÂ\u0096[Ü\u0092\u008a½¸\u0080\u009cXÍåþ8ý1\u0087ú\u009b²ºVæôLQÊZ3lO\u0091íH§/k\u00adåö\u0013|j\u008ac\u0097ÀæZ\u009d\u0081Li\u00811\u0012ÅbX»\u0001m\u0089\b\u0084b¥í8>o\u0005}\u0085xÂy\u0098u\u0011B¢d@\u001dß&Ñü^¹ÖÕ~°|*\fC\u008e\u0010C7D\u0091\u0095¢ëô©ÿ®d@n\u0001x=\nÊd\u000fJf\u001d\u0088'ó|\u0019[\u0017ïRäôÊtÏ".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lllI = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lllI[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            IllI = new String[IIIII(-1490692902, 906085003)];
            IlII();
            IlI = null.III;
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public double Ill() {
      return (Double)this.IIII.III();
   }

   private double IlI(long var1) {
      if (this.lI <= 0L) {
         this.lI = var1;
         return 0.016666666666666666;
      } else {
         double var3 = Math.max((double)0.0F, Math.min(0.12, (double)(var1 - this.lI) / (double)1000.0F));
         this.lI = var1;
         return var3 <= (double)0.0F ? 0.016666666666666666 : var3;
      }
   }

   private static String llI(class_1293 var0) {
      class_1291 var1 = (class_1291)var0.method_5579().comp_349();
      class_2960 var2 = class_7923.field_41174.method_10221(var1);
      String var3 = var2 == null ? var1.method_5567() : var2.toString();
      String var10001 = lIlIII.Il(IllI[IIIII(-1490692901, 1029593229)]);
      int var6 = var0.method_5578();
      String var5 = var10001;
      return var3 + var5 + var6;
   }

   private static String lll(char[] var0, long var1, int var3) {
      int var4 = IIIII(-1490692904, -521630400) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IIIII(-1490692903, 986119628);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private static String IIII(int var0) {
      if (var0 <= 0) {
         return IllI[IIIII(-1490692906, -1301699689)];
      } else {
         String var10000;
         switch (var0) {
            case 1 -> var10000 = lIlIII.Il(IllI[1]);
            case 2 -> var10000 = lIlIII.Il(IllI[IIIII(-1490692905, 453817718)]);
            case 3 -> var10000 = lIlIII.Il(IllI[4]);
            case 4 -> var10000 = lIlIII.Il(IllI[IIIII(-1490692908, -608657324)]);
            case 5 -> var10000 = lIlIII.Il(IllI[2]);
            case 6 -> var10000 = lIlIII.Il(IllI[5]);
            case 7 -> var10000 = lIlIII.Il(IllI[IIIII(-1490692907, -217321956)]);
            case 8 -> var10000 = lIlIII.Il(IllI[IIIII(-1490692910, 1061256104)]);
            case 9 -> var10000 = lIlIII.Il(IllI[IIIII(-1490692909, -2145276128)]);
            case 10 -> var10000 = lIlIII.Il(IllI[3]);
            default -> var10000 = String.valueOf(var0);
         }

         return var10000;
      }
   }

   private static String IIIl(class_1293 var0, class_310 var1) {
      if (var0.method_48559()) {
         return lIlIII.Il(IllI[IIIII(-1490692912, -1298750871)]);
      } else {
         try {
            return class_1292.method_5577(var0, 1.0F, var1.field_1687 == null ? 20.0F : var1.field_1687.method_54719().method_54748()).getString();
         } catch (Throwable var6) {
            int var3 = Math.max(0, var0.method_5584() / IIIII(-1490692911, -1406314708));
            int var4 = var3 / IIIII(-1490692914, 1925953945);
            int var5 = var3 % IIIII(-1490692913, 1856458678);
            return String.format(lIlIII.Il(IllI[IIIII(-1490692916, -465144193)]), var4, var5);
         }
      }
   }

   public double lIIl() {
      return this.l * this.ll();
   }

   private double IIll() {
      return Math.max((double)8.0F, (Double)this.ll.III());
   }

   private static void IlII() {
      IllI[0] = lll(IIIIl(1016271204, 45027907).toCharArray(), 65862L, IIIII(-1490692915, -897648547));
      IllI[1] = lll(IIIIl(1016271205, 1864312519).toCharArray(), 66880L, IIIII(-1490692918, -287146213));
      IllI[2] = lll(IIIIl(1016271206, 743138624).toCharArray(), 54179L, IIIII(-1490692917, -1371619198));
      IllI[3] = lll(IIIIl(1016271207, -462460373).toCharArray(), 40475L, IIIII(-1490692920, -1481289200));
      IllI[4] = lll(IIIIl(1016271200, -1252976562).toCharArray(), 21094L, IIIII(-1490692919, 197335021));
      IllI[5] = lll(IIIIl(1016271201, -173509102).toCharArray(), 79586L, IIIII(-1490692922, 1376523767));
      IllI[IIIII(-1490692921, 799294795)] = lll(IIIIl(1016271202, -2079317754).toCharArray(), 28281L, IIIII(-1490692924, 1970094018));
      IllI[IIIII(-1490692923, -1746932040)] = lll(IIIIl(1016271203, 1819808151).toCharArray(), 64382L, IIIII(-1490692926, 554624053));
      IllI[IIIII(-1490692925, 1071739089)] = lll(IIIIl(1016271212, -1053079325).toCharArray(), 32669L, IIIII(-1490692928, 636550155));
      IllI[IIIII(-1490692927, 274188613)] = lll(IIIIl(1016271213, -1416029609).toCharArray(), 15190L, IIIII(-1490692866, -1074102167));
      IllI[IIIII(-1490692865, 1895672478)] = lll("".toCharArray(), 41069L, IIIII(-1490692868, 575683442));
      IllI[IIIII(-1490692867, 1479312432)] = lll(IIIIl(1016271214, 1491488474).toCharArray(), 22898L, IIIII(-1490692870, 1519695680));
      IllI[IIIII(-1490692869, 1356489281)] = lll(IIIIl(1016271215, -53148366).toCharArray(), 33773L, IIIII(-1490692872, 156134924));
      IllI[IIIII(-1490692871, -2097919870)] = lll(IIIIl(1016271208, 58598710).toCharArray(), 84488L, IIIII(-1490692874, -96105953));
      IllI[IIIII(-1490692873, -1830957239)] = lll(IIIIl(1016271209, -376872053).toCharArray(), 36408L, IIIII(-1490692876, -987670769));
      IllI[IIIII(-1490692875, -278130437)] = lll(IIIIl(1016271210, 1855083921).toCharArray(), 2952L, IIIII(-1490692878, 1519962549));
      IllI[IIIII(-1490692877, -347261683)] = lll(IIIIl(1016271211, 839125449).toCharArray(), 69232L, IIIII(-1490692880, 390799731));
      IllI[IIIII(-1490692879, 4227008)] = lll(IIIIl(1016271220, -1818542134).toCharArray(), 62089L, IIIII(-1490692882, -1731685818));
      IllI[IIIII(-1490692881, 1942198081)] = lll(IIIIl(1016271221, -481160398).toCharArray(), 40937L, IIIII(-1490692884, 563857487));
      IllI[IIIII(-1490692883, 996709204)] = lll(IIIIl(1016271222, -1655351885).toCharArray(), 71692L, IIIII(-1490692886, 811372018));
      IllI[IIIII(-1490692885, 1397379721)] = lll(IIIIl(1016271223, 1670338454).toCharArray(), 4871L, IIIII(-1490692888, -1862959452));
      IllI[IIIII(-1490692887, -331770085)] = lll(IIIIl(1016271216, -184863634).toCharArray(), 54580L, IIIII(-1490692890, 603958551));
      IllI[IIIII(-1490692889, -1125032840)] = lll(IIIIl(1016271217, 329469167).toCharArray(), 32519L, IIIII(-1490692892, -112755117));
      IllI[IIIII(-1490692891, 5588615)] = lll(IIIIl(1016271218, -109288854).toCharArray(), 67967L, IIIII(-1490692894, -30015674));
      IllI[IIIII(-1490692893, -1101657767)] = lll(IIIIl(1016271219, -472040789).toCharArray(), 84599L, IIIII(-1490692896, -1897376467));
      IllI[IIIII(-1490692895, -534146511)] = lll(IIIIl(1016271228, 1709460102).toCharArray(), 73834L, IIIII(-1490692962, 1421993499));
      IllI[IIIII(-1490692961, -1248300254)] = lll(IIIIl(1016271229, 1409551674).toCharArray(), 6862L, IIIII(-1490692964, -1059198123));
      IllI[IIIII(-1490692963, 1567145067)] = lll(IIIIl(1016271230, -1766324137).toCharArray(), 21857L, IIIII(-1490692966, -1169764474));
      IllI[IIIII(-1490692965, 829685853)] = lll(IIIIl(1016271231, 1385903700).toCharArray(), 43105L, IIIII(-1490692968, 1109796306));
      IllI[IIIII(-1490692967, -85941357)] = lll(IIIIl(1016271224, 78871832).toCharArray(), 93742L, IIIII(-1490692970, -1153571628));
      IllI[IIIII(-1490692969, -1210324456)] = lll(IIIIl(1016271225, 76962836).toCharArray(), 34924L, IIIII(-1490692972, -1487431012));
      IllI[IIIII(-1490692971, -209934487)] = lll(IIIIl(1016271226, -807915728).toCharArray(), 17946L, IIIII(-1490692974, -1380949368));
      IllI[IIIII(-1490692973, 1465604673)] = lll(IIIIl(1016271227, 610932580).toCharArray(), 63574L, IIIII(-1490692976, 502554468));
      IllI[IIIII(-1490692975, -1876443437)] = lll(IIIIl(1016271172, -809676757).toCharArray(), 637L, IIIII(-1490692978, -159863018));
      IllI[IIIII(-1490692977, 1494353786)] = lll(IIIIl(1016271173, -1343395928).toCharArray(), 27985L, IIIII(-1490692980, -214489288));
      IllI[IIIII(-1490692979, -737458795)] = lll(IIIIl(1016271174, 1978928741).toCharArray(), 33638L, IIIII(-1490692982, -217773735));
      IllI[IIIII(-1490692981, -1087056609)] = lll(IIIIl(1016271175, -1908666011).toCharArray(), 48306L, IIIII(-1490692984, 376858172));
      IllI[IIIII(-1490692983, 385214709)] = lll(IIIIl(1016271168, 1181708428).toCharArray(), 80086L, IIIII(-1490692986, -1138247859));
      IllI[IIIII(-1490692985, -676600380)] = lll(IIIIl(1016271169, 493251848).toCharArray(), 95891L, IIIII(-1490692988, 208412058));
      IllI[IIIII(-1490692987, -733576184)] = lll(IIIIl(1016271170, 16416575).toCharArray(), 59850L, IIIII(-1490692990, -833676092));
      IllI[IIIII(-1490692989, 1919670029)] = lll(IIIIl(1016271171, -847947351).toCharArray(), 46218L, IIIII(-1490692992, 362756370));
      IllI[IIIII(-1490692991, -823348524)] = lll(IIIIl(1016271180, -193133455).toCharArray(), 19612L, IIIII(-1490692930, 24864606));
      IllI[IIIII(-1490692929, 49895627)] = lll(IIIIl(1016271181, 1302141386).toCharArray(), 35095L, IIIII(-1490692932, -1972564767));
      IllI[IIIII(-1490692931, 652670925)] = lll(IIIIl(1016271182, 639582324).toCharArray(), 92929L, IIIII(-1490692934, -1340759230));
      IllI[IIIII(-1490692933, 125397072)] = lll(IIIIl(1016271183, -705727589).toCharArray(), 42135L, IIIII(-1490692936, -1123733609));
      IllI[IIIII(-1490692935, 1311345433)] = lll(IIIIl(1016271176, -991999301).toCharArray(), 43773L, IIIII(-1490692938, 1464054726));
      IllI[IIIII(-1490692937, -1147064119)] = lll(IIIIl(1016271177, 280760618).toCharArray(), 7572L, IIIII(-1490692940, -1749928142));
      IllI[IIIII(-1490692939, 1012048696)] = lll(IIIIl(1016271178, -443667553).toCharArray(), 26515L, IIIII(-1490692942, -457733675));
      IllI[IIIII(-1490692941, 138546837)] = lll(IIIIl(1016271179, -878440489).toCharArray(), 74692L, IIIII(-1490692944, 440761470));
      IllI[IIIII(-1490692943, -1412653871)] = lll(IIIIl(1016271188, -2044833927).toCharArray(), 43891L, IIIII(-1490692946, 211457789));
      IllI[IIIII(-1490692945, 1319162810)] = lll(IIIIl(1016271189, -74643298).toCharArray(), 71304L, IIIII(-1490692948, -1966893347));
      IllI[IIIII(-1490692947, -1778871143)] = lll(IIIIl(1016271190, 2039224499).toCharArray(), 93265L, IIIII(-1490692950, 480225723));
      IllI[IIIII(-1490692949, -1015854269)] = lll(IIIIl(1016271191, 568336246).toCharArray(), 34268L, IIIII(-1490692952, 1123607947));
      IllI[IIIII(-1490692951, 912425330)] = lll(IIIIl(1016271184, -569964492).toCharArray(), 43840L, IIIII(-1490692954, 1103577579));
      IllI[IIIII(-1490692953, -175319688)] = lll(IIIIl(1016271185, 139935456).toCharArray(), 64536L, IIIII(-1490692956, 1147897670));
      IllI[IIIII(-1490692955, 907082164)] = lll(IIIIl(1016271186, 933900869).toCharArray(), 75141L, IIIII(-1490692958, -1281638410));
      IllI[IIIII(-1490692957, -643058126)] = lll(IIIIl(1016271187, -48480211).toCharArray(), 63070L, IIIII(-1490692960, 902858822));
      IllI[IIIII(-1490692959, -450778697)] = lll(IIIIl(1016271196, -1482141717).toCharArray(), 36401L, IIIII(-1490693026, -1691135259));
      IllI[IIIII(-1490693025, -1775643498)] = lll(IIIIl(1016271197, -743041738).toCharArray(), 3575L, IIIII(-1490693028, 1618362007));
      IllI[IIIII(-1490693027, 652485657)] = lll(IIIIl(1016271198, -220246907).toCharArray(), 73182L, IIIII(-1490693030, 1156087052));
      IllI[IIIII(-1490693029, 1653968226)] = lll(IIIIl(1016271199, -1209320781).toCharArray(), 63643L, IIIII(-1490693032, 1452727294));
      IllI[IIIII(-1490693031, -651393466)] = lll(IIIIl(1016271192, -1061942521).toCharArray(), 31774L, IIIII(-1490693034, -1630651150));
   }

   public double llll() {
      return this.III * this.ll();
   }

   public double Il() {
      return (Double)this.llI.III();
   }

   private <undefinedtype> IlIl(class_310 var1, class_327 var2, class_1293 var3, int var4) {
      class_6880 var5 = var3.method_5579();
      class_1291 var6 = (class_1291)var5.comp_349();
      String var7 = class_2561.method_43471(var6.method_5567()).getString();
      int var8 = var3.method_5578();
      if ((Boolean)this.IIl.III() && var8 > 0) {
         String var10001 = lIlIII.Il(IllI[IIIII(-1490693033, 1479156839)]);
         String var24 = IIII(var8 + 1);
         String var23 = var10001;
         var7 = var7 + var23 + var24;
      }

      String var9 = (Boolean)this.IIll.III() ? IIIl(var3, var1) : IllI[IIIII(-1490693036, -1391537898)];
      int var10 = this.llII(var6);
      int var11 = var3.method_48559() ? IIIII(-1490693035, 1297483392) : Math.max(0, var3.method_5584());
      boolean var12 = !var3.method_48559() && var11 <= IIIII(-1490693038, -1985528962);
      double var13 = var3.method_48559() ? (double)1.0F : IIIIlI.Il((double)var11 / (double)Math.max(1, var4));
      double var15 = (double)var2.method_1727(var7) * 0.9;
      double var17 = var9.isEmpty() ? (double)0.0F : (double)var2.method_1727(var9);
      double var19 = (double)Math.abs(var6.method_5567().hashCode() % IIIII(-1490693037, 1048745362)) / (double)90.0F;
      Object var21 = new Object(var7, var9, var10, var12, var19, var15, var17, var13, var11) {
         final double I;
         final double l;
         final int II;
         final String Il;
         final int lI;
         double ll;
         final double III;
         final double IIl;
         final boolean IlI;
         final String Ill;

         {
            this.Il = var1;
            this.Ill = var2;
            this.II = var3;
            this.IlI = var4;
            this.III = var5;
            this.IIl = var7;
            this.l = var9;
            this.I = var11;
            this.lI = var13;
         }
      };
      ((<undefinedtype>)var21).ll = this.IIll() + 11.6 + (double)5.0F + var15 + (var9.isEmpty() ? (double)0.0F : (double)7.0F + var17 * 0.78) + this.IIll() + (double)4.0F;
      return (<undefinedtype>)var21;
   }

   private void Illl(class_332 var1, class_327 var2, String var3, double var4, double var6, int var8, double var9) {
      IIIIIIllI.IIIllI(var1);

      try {
         IIIIIIllI.IlII(var1, var4, var6);
         IIIIIIllI.lllI(var1, var9, var9);
         IIIIIIllI.llIl(var1, var2, var3, (double)0.0F, (double)0.0F, var8);
      } finally {
         IIIIIIllI.lIIlIl(var1);
      }

   }

   private List<<undefinedtype>> lIII(double var1) {
      ArrayList var3 = new ArrayList();
      Iterator var4 = this.llIl.entrySet().iterator();

      while(var4.hasNext()) {
         <undefinedtype> var5 = (<undefinedtype>)((Map.Entry)var4.next()).getValue();
         double var6 = var5.l ? (double)1.0F : (double)0.0F;
         double var8 = var5.l ? 0.24 : 0.18;
         var5.lI = IIIIlI.III(var5.lI, var6, var8, var1);
         if (!var5.l && var5.lI <= 0.015) {
            var4.remove();
         } else if (var5.II != null && var5.lI > 0.015) {
            var3.add(var5);
         }
      }

      return var3;
   }

   public IIIlIllI() {
      super((Object)lIlIII.l(IllI[IIIII(-1490693040, -1302052432)]), lIllII.IIl, (Object)lIlIII.l(IllI[IIIII(-1490693039, -276911257)]), true);
      this.llI = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IllI[3]), (double)6.0F, (double)0.0F, (double)4000.0F, (double)1.0F)).IIl(lIlIII.Il(IllI[IIIII(-1490693042, 746199344)])));
      this.IIII = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IllI[IIIII(-1490693041, 1014326619)]), (double)200.0F, (double)0.0F, (double)4000.0F, (double)1.0F)).IIl(lIlIII.Il(IllI[IIIII(-1490693044, 1226934297)])));
      this.II = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IllI[IIIII(-1490693043, 1080799599)]), (double)100.0F, (double)60.0F, (double)180.0F, (double)5.0F)).IIl(lIlIII.Il(IllI[IIIII(-1490693046, -16489918)])));
      this.Il = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IllI[IIIII(-1490693045, 1589132144)]), (double)32.0F, (double)20.0F, (double)46.0F, (double)1.0F)).IIl(lIlIII.Il(IllI[IIIII(-1490693048, 753471891)])));
      this.IIIl = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IllI[IIIII(-1490693047, -615911704)]), (double)4.0F, (double)0.0F, (double)12.0F, (double)1.0F)).IIl(lIlIII.Il(IllI[IIIII(-1490693050, 2093164629)])));
      this.ll = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IllI[IIIII(-1490693049, 1289970819)]), (double)10.0F, (double)4.0F, (double)18.0F, (double)1.0F)).IIl(lIlIII.Il(IllI[IIIII(-1490693052, 151679266)])));
      this.IIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IllI[IIIII(-1490693051, -1032327742)]), true));
      this.IIll = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IllI[IIIII(-1490693054, 472609489)]), true));
      this.IlIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IllI[IIIII(-1490693053, 302532603)]), false));
      this.lII = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IllI[IIIII(-1490693056, 1678153701)]), false));
      this.I = (IIllIlIII)this.IIIlIll(new IIllIlIII(lIlIII.l(IllI[IIIII(-1490693055, -680257516)]), new Color(IIIII(-1490692994, -1192289966), IIIII(-1490692993, 1209028887), IIIII(-1490692996, 1022183938), IIIII(-1490692995, 1506189748))));
      this.llIl = new HashMap();
      this.III = (double)138.0F;
      this.l = (double)32.0F;
   }

   public void IIIlI(class_332 var1, int var2, int var3, float var4) {
      if (this.IIIIIlI()) {
         this.II(var1, false, false);
      }
   }

   private void lIll(class_332 var1, double var2, double var4, double var6, double var8, double var10, int var12, int var13) {
      double var14 = IIIIlI.Il(var10);
      IIIIIIllI.llIlII(var1, var2, var4, var6, var8, var13);
      if (!(var14 <= 0.001)) {
         IIIIIIllI.IIIIlI(var1, var2, var4, var6, var8, var14, var12);
      }
   }

   public void III(class_332 var1, int var2, int var3, float var4, boolean var5) {
      this.II(var1, true, var5);
   }

   private int llII(class_1291 var1) {
      if ((Boolean)this.IlIl.III()) {
         class_4081 var5 = var1.method_18792();
         int var10000;
         switch (var5) {
            case field_18271 -> var10000 = IIIII(-1490692998, 1640683945);
            case field_18273 -> var10000 = IIIII(-1490692997, -1231346422);
            case field_18272 -> var10000 = IIIII(-1490693000, 1820936014);
            default -> throw new MatchException((String)null, (Throwable)null);
         }

         return var10000;
      } else {
         class_2960 var2 = class_7923.field_41174.method_10221(var1);
         if (var2 != null && var2.method_12836().equals(lIlIII.Il(IllI[IIIII(-1490692999, 1456449767)]))) {
            String var3 = var2.method_12832();
            int var4 = -1;
            switch (var3.hashCode()) {
               case -1781004809:
                  if (var3.equals(IllI[IIIII(-1490693022, 1872775450)])) {
                     var4 = IIIII(-1490693021, -1628052279);
                  }
                  break;
               case -1259714865:
                  if (var3.equals(IllI[IIIII(-1490693102, -1773178867)])) {
                     var4 = IIIII(-1490693101, -1890371760);
                  }
                  break;
               case -1248513139:
                  if (var3.equals(IllI[IIIII(-1490693008, -2071841460)])) {
                     var4 = IIIII(-1490693007, 903300297);
                  }
                  break;
               case -1206104397:
                  if (var3.equals(IllI[IIIII(-1490693092, 1526201176)])) {
                     var4 = IIIII(-1490693091, -218225245);
                  }
                  break;
               case -1130648966:
                  if (var3.equals(IllI[IIIII(-1490693005, 785987046)])) {
                     var4 = 5;
                  }
                  break;
               case -1083012136:
                  if (var3.equals(IllI[IIIII(-1490693001, -1074626152)])) {
                     var4 = 1;
                  }
                  break;
               case -1052579859:
                  if (var3.equals(IllI[IIIII(-1490693012, 736767460)])) {
                     var4 = IIIII(-1490693011, 875371200);
                  }
                  break;
               case -982749432:
                  if (var3.equals(IllI[IIIII(-1490693096, 499105933)])) {
                     var4 = IIIII(-1490693095, -2097308115);
                  }
                  break;
               case -840436278:
                  if (var3.equals(IllI[IIIII(-1490693112, -1566253316)])) {
                     var4 = IIIII(-1490693111, -509913741);
                  }
                  break;
               case -787569677:
                  if (var3.equals(IllI[IIIII(-1490693098, -1248470581)])) {
                     var4 = IIIII(-1490693097, -701631448);
                  }
                  break;
               case -736186929:
                  if (var3.equals(IllI[IIIII(-1490693094, -87059614)])) {
                     var4 = IIIII(-1490693093, -1102224040);
                  }
                  break;
               case -606546085:
                  if (var3.equals(IllI[IIIII(-1490693116, -531026982)])) {
                     var4 = IIIII(-1490693115, -498160866);
                  }
                  break;
               case -306977811:
                  if (var3.equals(IllI[IIIII(-1490693108, 1281419758)])) {
                     var4 = IIIII(-1490693107, 326775767);
                  }
                  break;
               case -251715502:
                  if (var3.equals(IllI[IIIII(-1490693010, 76507708)])) {
                     var4 = IIIII(-1490693009, -1261306765);
                  }
                  break;
               case -230491182:
                  if (var3.equals(IllI[IIIII(-1490693104, -1697757539)])) {
                     var4 = IIIII(-1490693103, 861702024);
                  }
                  break;
               case -84082086:
                  if (var3.equals(IllI[IIIII(-1490693020, 61884554)])) {
                     var4 = IIIII(-1490693019, 1751664551);
                  }
                  break;
               case 3333041:
                  if (var3.equals(IllI[IIIII(-1490693110, 2126012215)])) {
                     var4 = IIIII(-1490693109, 1753619393);
                  }
                  break;
               case 99050123:
                  if (var3.equals(IllI[IIIII(-1490693004, 1274450215)])) {
                     var4 = 2;
                  }
                  break;
               case 109641799:
                  if (var3.equals(IllI[IIIII(-1490693002, 715307398)])) {
                     var4 = 0;
                  }
                  break;
               case 121707317:
                  if (var3.equals(IllI[IIIII(-1490693106, 13206325)])) {
                     var4 = IIIII(-1490693105, 976840913);
                  }
                  break;
               case 151619372:
                  if (var3.equals(IllI[IIIII(-1490693024, 1750993447)])) {
                     var4 = IIIII(-1490693023, -2120018150);
                  }
                  break;
               case 845042688:
                  if (var3.equals(IllI[IIIII(-1490693100, 1119430631)])) {
                     var4 = IIIII(-1490693099, -231616943);
                  }
                  break;
               case 1032770443:
                  if (var3.equals(IllI[IIIII(-1490693014, 1362279638)])) {
                     var4 = IIIII(-1490693013, 1899355829);
                  }
                  break;
               case 1254846936:
                  if (var3.equals(IllI[IIIII(-1490693003, -1209264792)])) {
                     var4 = 3;
                  }
                  break;
               case 1623775714:
                  if (var3.equals(IllI[IIIII(-1490693018, -832411062)])) {
                     var4 = IIIII(-1490693017, 583045530);
                  }
                  break;
               case 1741803213:
                  if (var3.equals(IllI[IIIII(-1490693118, -665529521)])) {
                     var4 = IIIII(-1490693117, -29269286);
                  }
                  break;
               case 1749920239:
                  if (var3.equals(IllI[IIIII(-1490693090, 1633398219)])) {
                     var4 = IIIII(-1490693089, -945480965);
                  }
                  break;
               case 1791316033:
                  if (var3.equals(IllI[IIIII(-1490693006, 191062194)])) {
                     var4 = 4;
                  }
                  break;
               case 1863800889:
                  if (var3.equals(IllI[IIIII(-1490693016, 934703088)])) {
                     var4 = IIIII(-1490693015, 1896761712);
                  }
                  break;
               case 2139296513:
                  if (var3.equals(IllI[IIIII(-1490693114, 1622183312)])) {
                     var4 = IIIII(-1490693113, -1862868051);
                  }
            }

            switch (var4) {
               case 0 -> {
                  return IIIII(-1490693120, 103224165);
               }
               case 1 -> {
                  return IIIII(-1490693119, -107606982);
               }
               case 2 -> {
                  return IIIII(-1490693058, -640283430);
               }
               case 3 -> {
                  return IIIII(-1490693057, -1983216449);
               }
               case 4 -> {
                  return IIIII(-1490693060, -1680018477);
               }
               case 5 -> {
                  return IIIII(-1490693059, -21059685);
               }
               case 6 -> {
                  return IIIII(-1490693062, 717704140);
               }
               case 7 -> {
                  return IIIII(-1490693061, -1455679247);
               }
               case 8 -> {
                  return IIIII(-1490693064, -277667894);
               }
               case 9 -> {
                  return IIIII(-1490693063, 1098116823);
               }
               case 10 -> {
                  return IIIII(-1490693066, -1974330282);
               }
               case 11 -> {
                  return IIIII(-1490693065, 875256298);
               }
               case 12 -> {
                  return IIIII(-1490693068, -307480423);
               }
               case 13 -> {
                  return IIIII(-1490693067, -1860374487);
               }
               case 14 -> {
                  return IIIII(-1490693070, -39898325);
               }
               case 15 -> {
                  return IIIII(-1490693069, 1472815557);
               }
               case 16 -> {
                  return IIIII(-1490693072, 165882979);
               }
               case 17 -> {
                  return IIIII(-1490693071, -1604388700);
               }
               case 18 -> {
                  return IIIII(-1490693074, 318909607);
               }
               case 19 -> {
                  return IIIII(-1490693073, -166490197);
               }
               case 20 -> {
                  return IIIII(-1490693076, 507317075);
               }
               case 21 -> {
                  return IIIII(-1490693075, -650510752);
               }
               case 22 -> {
                  return IIIII(-1490693078, 167908105);
               }
               case 23 -> {
                  return IIIII(-1490693077, 1532858677);
               }
               case 24 -> {
                  return IIIII(-1490693080, -892539050);
               }
               case 25 -> {
                  return IIIII(-1490693079, -848678871);
               }
               case 26 -> {
                  return IIIII(-1490693082, 1733804133);
               }
               case 27 -> {
                  return IIIII(-1490693081, -1781468457);
               }
               case 28 -> {
                  return IIIII(-1490693084, 1596906354);
               }
               case 29 -> {
                  return IIIII(-1490693083, -263461091);
               }
            }
         }

         int var6 = var1.method_5556();
         return IIIII(-1490693086, -1243877004) | var6 & IIIII(-1490693085, -449285138);
      }
   }

   public boolean IIlI(double var1, double var3) {
      return var1 >= this.Il() && var1 <= this.Il() + this.llll() && var3 >= this.Ill() && var3 <= this.Ill() + this.lIIl();
   }

   private <undefinedtype> lllI(class_327 var1) {
      String var2 = lIlIII.Il(IllI[IIIII(-1490693088, 786153039)]);
      String var3 = lIlIII.Il(IllI[IIIII(-1490693087, -2103297760)]);
      int var4 = class_124.field_1075.method_532() == null ? IIIII(-1490692642, -392800702) : IIIII(-1490692641, 206627331) | class_124.field_1075.method_532();
      double var5 = (double)var1.method_1727(var2) * 0.9;
      double var7 = (double)var1.method_1727(var3);
      Object var9 = new Object(var2, var3, var4, false, 0.6, var5, var7, 0.72, IIIII(-1490692644, 276155663)) {
         final double I;
         final double l;
         final int II;
         final String Il;
         final int lI;
         double ll;
         final double III;
         final double IIl;
         final boolean IlI;
         final String Ill;

         {
            this.Il = var1;
            this.Ill = var2;
            this.II = var3;
            this.IlI = var4;
            this.III = var5;
            this.IIl = var7;
            this.l = var9;
            this.I = var11;
            this.lI = var13;
         }
      };
      ((<undefinedtype>)var9).ll = this.IIll() + 11.6 + (double)5.0F + var5 + (double)7.0F + var7 * 0.78 + this.IIll() + (double)4.0F;
      return (<undefinedtype>)var9;
   }

   private static int IIIII(int var0, int var1) {
      return lllI[var0 ^ -1490692898] ^ var1 ^ var0;
   }

   private static String IIIIl(int var0, int var1) {
      int var3 = var0 ^ 1016271204;
      char[] var4 = llll[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IIIII[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IIIII[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -1820569736;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 56;
               break;
            case 1:
               var9 = 147;
               break;
            case 2:
               var9 = 152;
               break;
            case 3:
               var9 = 158;
               break;
            case 4:
               var9 = 80;
               break;
            case 5:
               var9 = 109;
               break;
            case 6:
               var9 = 251;
               break;
            case 7:
               var9 = 221;
               break;
            case 8:
               var9 = 227;
               break;
            case 9:
               var9 = 243;
               break;
            case 10:
               var9 = 84;
               break;
            case 11:
               var9 = 77;
               break;
            case 12:
               var9 = 46;
               break;
            case 13:
               var9 = 115;
               break;
            case 14:
               var9 = 104;
               break;
            case 15:
               var9 = 112;
               break;
            case 16:
               var9 = 148;
               break;
            case 17:
               var9 = 253;
               break;
            case 18:
               var9 = 15;
               break;
            case 19:
               var9 = 5;
               break;
            case 20:
               var9 = 48;
               break;
            case 21:
               var9 = 102;
               break;
            case 22:
               var9 = 228;
               break;
            case 23:
               var9 = 158;
               break;
            case 24:
               var9 = 206;
               break;
            case 25:
               var9 = 121;
               break;
            case 26:
               var9 = 7;
               break;
            case 27:
               var9 = 101;
               break;
            case 28:
               var9 = 133;
               break;
            case 29:
               var9 = 29;
               break;
            case 30:
               var9 = 233;
               break;
            case 31:
               var9 = 182;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
