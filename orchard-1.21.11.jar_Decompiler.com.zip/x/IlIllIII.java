package x;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_437;

@Environment(EnvType.CLIENT)
public final class IlIllIII {
   private static final AtomicBoolean I = new AtomicBoolean();

   public static boolean I(class_310 var0, IIllIlII var1) {
      if (!I.compareAndSet(false, true)) {
         return false;
      } else {
         II(var0, var1);
         return true;
      }
   }

   private IlIllIII() {
   }

   public static boolean l() {
      return I.get();
   }

   private static void II(class_310 var0, IIllIlII var1) {
      lIllIIl var2 = lIllIIl.Il();
      if (var0 != null) {
         try {
            IllllIlI.IIlIlll();
         } catch (Throwable var19) {
         }

         try {
            IllllIlI.III();
         } catch (Throwable var18) {
         }

         try {
            IlIlIl.IlIIl();
         } catch (Throwable var17) {
         }

         try {
            IllII.IlIll().Illl(true);
         } catch (Throwable var16) {
         }
      }

      if (var1 != null) {
         try {
            var1.lIIlI().lII(var0);
         } catch (Throwable var15) {
         }

         try {
            var1.IllllI().IlI();
         } catch (Throwable var14) {
         }

         try {
            var1.IlIlIl().lll(var0);
         } catch (Throwable var13) {
         }

         for(IIIIIIIlI var4 : List.copyOf(var1.IIIIlII())) {
            try {
               if (var4.IIIIIlI()) {
                  var4.IIIllIl(false);
               }

               var4.llllIl(false);
               var4.IIlIlll(class_3675.field_16237);
            } catch (Throwable var12) {
            }
         }
      }

      if (var0 != null) {
         try {
            var0.method_1507((class_437)null);
         } catch (Throwable var11) {
         }
      }

      try {
         IIlllIlII.III();
      } catch (Throwable var10) {
      }

      try {
         IIlllIlI.II().lI();
      } catch (Throwable var9) {
      }

      try {
         IlIllIll.IIl();
         lIIIlIIl.IIIl();
      } catch (Throwable var8) {
      }

      try {
         IIIIIlIll.IIIlIIl(null.II, true);
         IIIIIlIll.IIllllI();
         IIIIIlIll.IIIlIlI();
         IIIIIlIll.lIIll();
         IIIIIlIll.lllIll();
         IIIIIlIll.IIl();
      } catch (Throwable var7) {
      }

      try {
         lIIlIII.I();
         IIlIIlll.l();
         IlllllI.IIII();
         Il.Ill();
         IIlIIllll.II();
      } catch (Throwable var6) {
      }

      llIl.llllI();
      llIlIl.ll();
      IlIIlIlII.lII();
      if (var2 != null) {
         var2.lIl();
      }

   }
}
