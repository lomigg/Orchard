package x;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.platform.win32.BaseTSD;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
interface IlIlII extends Library {
   IlIlII I;
   String[] l;
   int[] II;
   String[] Il;
   Object[] lI;

   static {
      short var6 = 21330;
      String var7 = "庱ก닻淐䑯ܥ촅㺬";
      char[] var8 = "\b".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            Il = var9;
            lI = new Object[var9.length];
            int var2 = 1877243825;
            byte[] var0 = "\u001a\u0002ÕïU¾\u0088iN\u007fl¯".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            II = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               II[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            l = new String[1];
            I();
            I = (IlIlII)Native.load(lIlIII.Il(l[0]), IlIlII.class);
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 95;
                     break;
                  case 1:
                     var10000 = 116;
                     break;
                  case 2:
                     var10000 = 110;
                     break;
                  case 3:
                     var10000 = 121;
                     break;
                  case 4:
                     var10000 = 28;
                     break;
                  case 5:
                     var10000 = 46;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   static void I() {
      l[0] = II(lI(-2025787748, -1823125318).toCharArray(), 48460L, Il(-1021397003, -1509224074));
   }

   void l(byte var1, byte var2, int var3, BaseTSD.ULONG_PTR var4);

   static String II(char[] var0, long var1, int var3) {
      int var4 = Il(-1021397004, -406698582) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & Il(-1021397001, -494556138);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   static int Il(int var0, int var1) {
      return II[var0 ^ -1021397003] ^ var1 ^ var0;
   }

   private static String lI(int var0, int var1) {
      int var3 = var0 ^ -2025787748;
      char[] var4 = Il[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])lI[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         lI[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -584589112;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 230;
               break;
            case 1:
               var9 = 120;
               break;
            case 2:
               var9 = 158;
               break;
            case 3:
               var9 = 61;
               break;
            case 4:
               var9 = 160;
               break;
            case 5:
               var9 = 224;
               break;
            case 6:
               var9 = 142;
               break;
            case 7:
               var9 = 228;
               break;
            case 8:
               var9 = 12;
               break;
            case 9:
               var9 = 117;
               break;
            case 10:
               var9 = 36;
               break;
            case 11:
               var9 = 28;
               break;
            case 12:
               var9 = 20;
               break;
            case 13:
               var9 = 239;
               break;
            case 14:
               var9 = 168;
               break;
            case 15:
               var9 = 164;
               break;
            case 16:
               var9 = 70;
               break;
            case 17:
               var9 = 42;
               break;
            case 18:
               var9 = 4;
               break;
            case 19:
               var9 = 128;
               break;
            case 20:
               var9 = 153;
               break;
            case 21:
               var9 = 239;
               break;
            case 22:
               var9 = 38;
               break;
            case 23:
               var9 = 30;
               break;
            case 24:
               var9 = 100;
               break;
            case 25:
               var9 = 242;
               break;
            case 26:
               var9 = 102;
               break;
            case 27:
               var9 = 121;
               break;
            case 28:
               var9 = 196;
               break;
            case 29:
               var9 = 238;
               break;
            case 30:
               var9 = 232;
               break;
            case 31:
               var9 = 134;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
