package x;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import java.io.IOException;
import java.net.URI;
import java.nio.file.FileSystem;
import java.nio.file.FileSystemAlreadyExistsException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.DosFileAttributeView;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Stream;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_3675;

@Environment(EnvType.CLIENT)
public final class IIllIIl {
   private static final <undefinedtype> I;
   private static final <undefinedtype> l;
   private static final <undefinedtype> II;
   private static final <undefinedtype> Il;
   private static final <undefinedtype> lI;
   private static final long ll;
   private FileSystem III;
   private static final <undefinedtype> IIl;
   private static final long IlI;
   private long Ill;
   private static final long lII;
   private JsonObject lIl;
   private lIllII llI;
   private static final <undefinedtype> lll;
   private static final <undefinedtype> IIII;
   private static final long IIIl;
   private static final <undefinedtype> IIlI;
   private static final <undefinedtype> IIll;
   private static final long IlII;
   private static final <undefinedtype> IlIl;
   private final Path IllI = FabricLoader.getInstance().getGameDir();
   private static final long Illl;
   private static final <undefinedtype> lIII;
   private final Path lIIl = FabricLoader.getInstance().getConfigDir();
   private static final <undefinedtype> lIlI;
   private static final <undefinedtype> lIll;
   private static final <undefinedtype> llII;
   private static final <undefinedtype> llIl;
   private static final long lllI;
   private boolean llll;
   private class_3675.class_306 IIIII;
   private static final long IIIIl;
   private static final long IIIlI;
   private static final <undefinedtype> IIIll;
   private static final long IIlII;
   private static final <undefinedtype> IIlIl;
   private class_3675.class_306 IIllI;
   private static final long IIlll;
   private static final long IlIII;
   private static final <undefinedtype> IlIIl;
   private static final long IlIlI;
   private static final long IlIll;
   private static final long IllII;
   private static final <undefinedtype> IllIl;
   private static final long IlllI;
   private static final long Illll;
   private static final <undefinedtype> lIIII;
   private static final long lIIIl;
   private static final long lIIlI;
   private static final <undefinedtype> lIIll;
   private static final <undefinedtype> lIlII;
   private static final long lIlIl;
   private static final long lIllI;
   private static final long lIlll;
   private static final <undefinedtype> llIII;
   private static final <undefinedtype> llIIl;
   private static final <undefinedtype> llIlI;
   private <undefinedtype> llIll;
   private boolean lllII;
   private static final long lllIl;
   private static final Gson llllI;
   private static final <undefinedtype> lllll;
   private static final <undefinedtype> IIIIII;
   private static final <undefinedtype> IIIIIl;
   private static final <undefinedtype> IIIIlI;
   private static final long IIIIll;
   private static final int[] IIIlII;
   private static final String[] IIIlIl;
   private static final Object[] IIIllI;

   static String l(long var0) {
      String var2 = Long.toUnsignedString(var0, IllIIl(512461174, -473495678));
      String var3 = lIlIII.Il(IllIlI(612632736, -1549372754)).substring(0, IllIIl(512461175, -398919525) - var2.length());
      return var3 + var2;
   }

   private static void II(JsonObject var0) {
      if (lIlII(var0, lIlIl)) {
         JsonObject var1 = IlIII(var0, lIlIl);
         if (var1 != null && var1.has(lIlIII.Il(IllIlI(612632739, 1805845135)))) {
            JsonObject var2 = var1.getAsJsonObject(lIlIII.Il(IllIlI(612632738, -1963055401)));
            long var3 = lIIII.lll();
            JsonElement var5 = IIIIIIIlI.IlIIIIl(var2, var3);
            if (var5 != null && var5.isJsonPrimitive()) {
               String var6 = var5.getAsString();
               if (lIlIII.Il(IllIlI(612632741, 125572992)).equalsIgnoreCase(var6)) {
                  IIIIIIIlI.IIIIIll(var2, var3, new JsonPrimitive(lIlIII.Il(IllIlI(612632740, 197075013))));
               } else {
                  if (lIlIII.Il(IllIlI(612632743, -115188516)).equalsIgnoreCase(var6) || lIlIII.Il(IllIlI(612632742, 126179622)).equalsIgnoreCase(var6)) {
                     IIIIIIIlI.IIIIIll(var2, var3, new JsonPrimitive(lIlIII.Il(IllIlI(612632745, -1633796444))));
                  }

               }
            }
         }
      }
   }

   private static JsonObject Il(JsonObject var0, JsonObject var1, boolean var2) {
      JsonObject var3 = new JsonObject();
      var3.addProperty(lIlIII.Il(IllIlI(612632744, -19183871)), var2 && llI(var1, lIlIII.l(IllIlI(612632747, -218934094)).lll(), true));
      IIIIll(var0, var3);
      var3.add(lIlIII.Il(IllIlI(612632746, 1769238291)), new JsonObject());
      return var3;
   }

   private Path lI() throws IOException {
      Path var1 = this.IlIll();
      if (var1 != null && Files.isDirectory(var1, new LinkOption[0])) {
         Stream var2 = Files.list(var1);

         Path var3;
         try {
            var3 = (Path)var2.filter((var0) -> Files.isRegularFile(var0, new LinkOption[0])).filter((var0) -> var0.getFileName().toString().endsWith(lIlIII.Il(IllIlI(612632762, -1112443466)))).filter((var0) -> !var0.getFileName().toString().contains(lIlIII.Il(IllIlI(612632737, 1774262857)))).max(Comparator.comparingLong(this::ll)).orElse((Object)null);
         } catch (Throwable var6) {
            if (var2 != null) {
               try {
                  var2.close();
               } catch (Throwable var5) {
                  var6.addSuppressed(var5);
               }
            }

            throw var6;
         }

         if (var2 != null) {
            var2.close();
         }

         return var3;
      } else {
         return null;
      }
   }

   private long ll(Path var1) {
      try {
         return Files.getLastModifiedTime(var1).toMillis();
      } catch (IOException var3) {
         return 0L;
      }
   }

   private void IIl() {
      this.IlIIll(IlllI(lIIll));
      this.llII(IlllI(IIlIl));
      this.llII(IlllI(l));
      Path var1 = this.llIIl();
      Path var2 = this.IIIlIl();
      if (var1 != null && var2 != null) {
         boolean var3 = var1.toAbsolutePath().normalize().equals(var2.toAbsolutePath().normalize());
         this.lIIlI(var1, llIl, llII, true);
         this.IlIlIl(var1.resolve(lIll.lIlI()), this.IIllIl(), true);
         if (!var3) {
            this.IlIlI(var1);
         }

      }
   }

   public void IlI(IIllIlII var1) {
      Path var2 = this.llllI();
      if (var2 != null) {
         JsonObject var3 = new JsonObject();
         JsonObject var4 = new JsonObject();
         var4.addProperty(lIlIII.Il(IllIlI(612632749, 1237414212)), this.llI.ordinal());
         if (this.lllII) {
            var4.addProperty(lIlIII.Il(IllIlI(612632748, -1361220946)), l(this.Ill));
         }

         JsonElement var5 = IllllIlI.llIIl(this.IIIII);
         if (var5 != null) {
            var4.add(lIlIII.Il(IllIlI(612632751, 1408783378)), var5);
         }

         JsonElement var6 = IllllIlI.llIIl(this.IIllI);
         if (var6 != null) {
            var4.add(lIlIII.Il(IllIlI(612632750, 1901034664)), var6);
         }

         var3.add(lIlIII.Il(IllIlI(612632753, 1544379738)), var4);
         var3.add(IIlIl(), this.lIl == null ? new JsonObject() : this.lIl.deepCopy());
         JsonObject var7 = new JsonObject();

         for(IIIIIIIlI var10 : var1.IIIIlII()) {
            var7.add(l(var10.IIlIllI()), var10.IlIlII());
         }

         var3.add(lIlIII.Il(IllIlI(612632752, -801108087)), var7);

         try {
            Files.createDirectories(var2.getParent());
            Files.writeString(var2, llllI.toJson(var3));
         } catch (IOException var11) {
         }

      }
   }

   private static String Ill() {
      return lIlIII.Il(IllIlI(612632755, -714051194));
   }

   private void lII() {
      this.lIIlI(this.IlII(null.II), IIIll, llIIl, true);
      this.IlIl(this.lIIl, true);
      this.lIIlI(this.IllI.resolve(IIIIII.lIlI()), IIIll, llIIl, true);
      this.lIIlI(this.IlII(null.Il), IIIll, llIIl, true);
      this.llII(this.lIIl.resolve(IIlIl.lIlI()));
      this.llII(this.lIIl.resolve(l.lIlI()));
      this.llII(this.IllI.resolve(IIlIl.lIlI()));
      this.llII(this.IllI.resolve(l.lIlI()));
      this.lIIlI(this.lllll(), IIIll, llIIl, false);
      this.IIl();
   }

   public boolean lIl() {
      return false;
   }

   private static boolean llI(JsonObject var0, long var1, boolean var3) {
      JsonElement var4 = IIIIIIIlI.IlIIIIl(var0, var1);
      if (var4 != null && var4.isJsonPrimitive()) {
         try {
            return var4.getAsBoolean();
         } catch (RuntimeException var6) {
            return var3;
         }
      } else {
         return var3;
      }
   }

   public Path lll(IIllIlII var1) throws IOException {
      Path var2 = this.lI();
      if (var2 == null) {
         throw new IOException(lIlIII.Il(IllIlI(612632754, -210552968)));
      } else {
         Path var3 = this.llllI();
         if (var3 == null) {
            throw new IOException(lIlIII.Il(IllIlI(612632757, -2118829068)));
         } else {
            Files.createDirectories(var3.getParent());
            Files.copy(var2, var3, StandardCopyOption.REPLACE_EXISTING);
            this.IlIIl(var1);
            return var2;
         }
      }
   }

   private static void IIII(JsonObject var0) {
      if (lIlII(var0, Illll)) {
         JsonObject var1 = IlIII(var0, Illll);
         if (var1 != null && var1.has(lIlIII.Il(IllIlI(612632756, 2140939221)))) {
            JsonObject var2 = var1.getAsJsonObject(lIlIII.Il(IllIlI(612632759, 640821668)));
            long var3 = llIlI.lll();
            JsonElement var5 = IIIIIIIlI.IlIIIIl(var2, var3);
            if (var5 != null && var5.isJsonPrimitive()) {
               String var6 = var5.getAsString();
               if (lIlIII.Il(IllIlI(612632758, 1144937116)).equalsIgnoreCase(var6) || lIlIII.Il(IllIlI(612632761, -855814050)).equalsIgnoreCase(var6)) {
                  IIIIIIIlI.IIIIIll(var2, var3, new JsonPrimitive(lIlIII.Il(IllIlI(612632760, -1569703289))));
               }

            }
         }
      }
   }

   public void IIIl() {
      if (this.III != null && this.III.isOpen()) {
         if (this.llll) {
            try {
               this.III.close();
            } catch (IOException var2) {
            }
         }

         this.III = null;
         this.llll = false;
      }

   }

   private void IIlI() {
      try {
         Files.deleteIfExists(this.IllI.resolve(Il.lIlI()));
      } catch (IOException var2) {
      }

   }

   public JsonObject IIll() {
      return this.lIl == null ? new JsonObject() : this.lIl.deepCopy();
   }

   public Path IlII(Object var1) {
      if (var1 == null) {
         return null;
      } else {
         Path var10000;
         switch (var1.ordinal()) {
            case 0 -> var10000 = this.lIIl;
            case 1 -> var10000 = this.IllI.resolve(II.lIlI());
            case 2 -> var10000 = this.lllll();
            case 3 -> var10000 = this.IIIlIl();
            default -> throw new MatchException((String)null, (Throwable)null);
         }

         return var10000;
      }
   }

   private void IlIl(Path var1, boolean var2) {
      if (var1 != null) {
         Path var3 = this.llIII(null.I);
         if (var3 != null && !Files.exists(var3, new LinkOption[0])) {
            Stream var10000 = Stream.of(I.lIlI(), lll.lIlI(), lIlIII.Il(IllIlI(612632763, -1039446403)));
            Objects.requireNonNull(var1);
            var10000.map(var1::resolve).filter((var0) -> Files.isRegularFile(var0, new LinkOption[0])).max(Comparator.comparingLong(this::ll)).ifPresent((var3x) -> this.IlIlIl(var3x, var3, var2));
         }
      }
   }

   public static Path IllI() {
      return IlllI(IlIIl);
   }

   public lIllII Illl() {
      return this.llI;
   }

   private void lIIl(Path var1, Path var2, boolean var3) {
      if (var1 != null && var2 != null && Files.isDirectory(var1, new LinkOption[0])) {
         try {
            Files.createDirectories(var2);
            Stream var4 = Files.list(var1);

            try {
               var4.filter((var0) -> Files.isRegularFile(var0, new LinkOption[0])).forEach((var3x) -> this.IlIlIl(var3x, var2.resolve(var3x.getFileName()), var3));
            } catch (Throwable var8) {
               if (var4 != null) {
                  try {
                     var4.close();
                  } catch (Throwable var7) {
                     var8.addSuppressed(var7);
                  }
               }

               throw var8;
            }

            if (var4 != null) {
               var4.close();
            }
         } catch (IOException var9) {
         }

      }
   }

   public class_3675.class_306 lIlI() {
      return this.IIllI;
   }

   public Path lIll() {
      return this.IIllI();
   }

   private void llII(Path var1) {
      if (var1 != null && Files.isDirectory(var1, new LinkOption[0])) {
         this.IlIIll(var1);
         this.lIIlI(var1, IIIll, llIIl, true);
         this.IlIl(var1, true);
         this.IlIlI(var1);
      }
   }

   private String llIl(Object var1) {
      return (var1 == null.I ? IllIl : IIIll).lIlI();
   }

   private FileSystem lllI() {
      if (this.III != null && this.III.isOpen()) {
         return this.III;
      } else {
         Path var1 = this.lIlll();
         if (var1 != null && Files.exists(var1, new LinkOption[0])) {
            try {
               String var10000 = lIlIII.Il(IllIlI(612632765, 1674407856));
               String var5 = String.valueOf(var1.toUri());
               String var4 = var10000;
               URI var2 = URI.create(var4 + var5);

               try {
                  this.III = FileSystems.newFileSystem(var2, Map.of(lIlIII.Il(IllIlI(612632764, 1162165625)), lIlIII.Il(IllIlI(612632767, -302943563))));
                  this.llll = true;
               } catch (FileSystemAlreadyExistsException var6) {
                  this.III = FileSystems.getFileSystem(var2);
                  this.llll = false;
               }

               return this.III;
            } catch (Exception var7) {
               return null;
            }
         } else {
            return null;
         }
      }
   }

   public <undefinedtype> llll() {
      return this.llIll;
   }

   private void IIIII() {
      Path var1 = this.IIllIl();
      if (var1 != null) {
         JsonObject var2 = new JsonObject();
         if (this.llIll != null) {
            var2.addProperty(lIlIII.Il(IllIlI(612632766, 357790337)), this.llIll.ordinal());
         }

         try {
            Files.createDirectories(var1.getParent());
            Files.writeString(var1, llllI.toJson(var2));
         } catch (IOException var4) {
         }

      }
   }

   public Path IIIIl(Object var1) {
      Path var2 = this.IlII(var1);
      return var2 == null ? null : var2.resolve(this.lIIIl(var1));
   }

   static void IIIll(JsonObject var0, long var1, long var3) {
      JsonElement var5 = IIllll(var0, var1);
      if (var5 != null && !lIlII(var0, var3)) {
         IIlIlI(var0, var3, var5);
      }

   }

   private static boolean IIlII(JsonObject var0) {
      return var0 != null && var0.has(lIlIII.Il(IllIlI(612632705, 781664323))) && var0.get(lIlIII.Il(IllIlI(612632704, -273908863))).getAsBoolean();
   }

   private static String IIlIl() {
      return lIlIII.Il(IllIlI(612632707, 1766869906));
   }

   public Path IIllI() {
      Path var1 = this.IlII(null.I);
      return var1 == null ? null : var1.resolve(lllll.lIlI());
   }

   public Path IIlll(String var1) throws IOException {
      Path var2 = this.llllI();
      if (var2 != null && Files.exists(var2, new LinkOption[0])) {
         Path var3 = this.IlIll();
         if (var3 == null) {
            throw new IOException(lIlIII.Il(IllIlI(612632709, -1753778093)));
         } else {
            Files.createDirectories(var3);
            String var4 = var1 != null && !var1.isBlank() ? var1.replaceAll(lIlIII.Il(IllIlI(612632711, 2039823727)), lIlIII.Il(IllIlI(612632710, -348052404))) : lIlIII.Il(IllIlI(612632708, -625970776));
            String var5 = LocalDateTime.now().format(DateTimeFormatter.ofPattern(lIlII.lIlI()));
            String var10001 = String.valueOf(var2.getFileName());
            String var10002 = lIlIII.Il(IllIlI(612632713, -12770082));
            String var10004 = lIlIII.Il(IllIlI(612632712, 370695515));
            String var12 = lIlIII.Il(IllIlI(612632715, -618586006));
            String var10 = var10004;
            String var8 = var10002;
            String var7 = var10001;
            Path var6 = var3.resolve(var7 + var8 + var5 + var10 + var4 + var12);
            Files.copy(var2, var6, StandardCopyOption.REPLACE_EXISTING);
            return var6;
         }
      } else {
         throw new IOException(lIlIII.Il(IllIlI(612632706, 1955401216)));
      }
   }

   static JsonObject IlIII(JsonObject var0, long var1) {
      JsonElement var3 = IIllll(var0, var1);
      return var3 != null && var3.isJsonObject() ? var3.getAsJsonObject() : null;
   }

   public void IlIIl(IIllIlII var1) {
      Path var2 = this.llllI();
      if (var2 != null && Files.exists(var2, new LinkOption[0])) {
         try {
            JsonElement var3 = (JsonElement)llllI.fromJson(Files.readString(var2), JsonElement.class);
            if (var3 == null || !var3.isJsonObject()) {
               return;
            }

            JsonObject var4 = var3.getAsJsonObject();
            if (var4.has(lIlIII.Il(IllIlI(612632714, 2141070576))) || var4.has(lIlIII.Il(IllIlI(612632717, -739900135)))) {
               JsonObject var5 = var4.has(lIlIII.Il(IllIlI(612632716, 558040609))) ? var4.getAsJsonObject(lIlIII.Il(IllIlI(612632719, 140066637))) : var4.getAsJsonObject(lIlIII.Il(IllIlI(612632718, 1403673740)));
               if (var5.has(lIlIII.Il(IllIlI(612632721, 881751721)))) {
                  this.llI = this.IIIIIl(var5.get(lIlIII.Il(IllIlI(612632720, 1238704618))).getAsString());
               }

               if (var5.has(lIlIII.Il(IllIlI(612632723, -1428723500)))) {
                  this.Ill = IlIIII(IllIl(var5.get(lIlIII.Il(IllIlI(612632722, 115944476))).getAsString()));
                  this.lllII = true;
               }

               if (var5.has(lIlIII.Il(IllIlI(612632725, 589709754)))) {
                  this.IIIII = IllllIlI.lIIIIl(var5.get(lIlIII.Il(IllIlI(612632724, -1624550705))));
               } else if (var5.has(lIlIII.Il(IllIlI(612632727, -1910828107)))) {
                  this.IIIII = IllllIlI.lllll(var5.get(lIlIII.Il(IllIlI(612632726, 333591233))).getAsInt());
               }

               if (var5.has(lIlIII.Il(IllIlI(612632729, -2050266291)))) {
                  this.IIllI = IllllIlI.lIIIIl(var5.get(lIlIII.Il(IllIlI(612632728, -44431336))));
               }
            }

            if (var4.has(IIlIl()) && var4.get(IIlIl()).isJsonObject()) {
               this.lIl = var4.getAsJsonObject(IIlIl()).deepCopy();
            } else if (var4.has(Ill()) && var4.get(Ill()).isJsonObject()) {
               this.lIl = var4.getAsJsonObject(Ill()).deepCopy();
            }

            if (var4.has(lIlIII.Il(IllIlI(612632731, 985006507)))) {
               JsonObject var10 = var4.getAsJsonObject(lIlIII.Il(IllIlI(612632730, 708996166)));
               IIIll(var10, IlIII, IIlII);
               IIIll(var10, lIIlI, IlIll);
               IIIll(var10, ll, lllIl);
               IIIll(var10, IlI, Illll);
               IIIll(var10, IlII, IIIIl);
               IIIll(var10, IlllI, lllI);
               IIIll(var10, IIIIll, IlIlI);
               IIIll(var10, lIllI, IIIl);
               IIlIll(var10);
               IllII(var10);
               II(var10);
               IIIlII(var10);
               IIII(var10);

               for(IIIIIIIlI var7 : var1.IIIIlII()) {
                  JsonObject var8 = IlIII(var10, var7.IIlIllI());
                  if (var8 != null) {
                     var7.IIl(var8);
                     var7.IIllIIl(var8);
                  }
               }
            }
         } catch (Exception var9) {
         }

      }
   }

   private void IlIlI(Path var1) {
      if (var1 != null && Files.isDirectory(var1, new LinkOption[0])) {
         try {
            Stream var2 = Files.list(var1);

            try {
               if (var2.findAny().isEmpty()) {
                  Files.deleteIfExists(var1);
               }
            } catch (Throwable var6) {
               if (var2 != null) {
                  try {
                     var2.close();
                  } catch (Throwable var5) {
                     var6.addSuppressed(var5);
                  }
               }

               throw var6;
            }

            if (var2 != null) {
               var2.close();
            }
         } catch (IOException var7) {
         }

      }
   }

   public Path IlIll() {
      return this.IlIllI();
   }

   private static void IllII(JsonObject var0) {
      IIIlll(var0, IIIlI);
      if (lIlII(var0, lIIIl)) {
         JsonObject var1 = IlIII(var0, lIIIl);
         if (var1 == null) {
            IIIlll(var0, lIIIl);
         } else {
            JsonObject var2 = var1.has(lIlIII.Il(IllIlI(612632733, -861261887))) ? var1.getAsJsonObject(lIlIII.Il(IllIlI(612632732, -1340663886))) : new JsonObject();
            boolean var3 = IIlII(var1);
            if (!lIlII(var0, Illl)) {
               IIlIlI(var0, Illl, Il(var1, var2, var3));
            }

            IIIlll(var0, lIIIl);
         }
      }
   }

   public IIllIIl() {
      this.llI = lIllII.l;
      this.IIIII = IllllIlI.lllll(IllIIl(512461172, -232402770));
      this.IIllI = class_3675.field_16237;
      this.lIl = new JsonObject();
      this.IIlllI();
      this.IIlIII();
      this.lII();
      this.llIll = null.I;
      this.IIIII();
      this.IIlI();
      this.IIIl();
   }

   private static long IllIl(String var0) {
      if (var0 != null && var0.length() == IllIIl(512461173, 1456627331) && var0.charAt(0) == IllIIl(512461170, 451331716)) {
         try {
            return Long.parseUnsignedLong(var0.substring(1), IllIIl(512461171, 79304286));
         } catch (NumberFormatException var2) {
         }
      }

      return lIlIII.II(var0);
   }

   private static Path IlllI(Object var0) {
      String var1 = System.getenv(lI.lIlI());
      if (var1 == null || var1.isBlank()) {
         var1 = System.getProperty(IlIl.lIlI());
         if (var1 == null || var1.isBlank()) {
            return null;
         }
      }

      return Path.of(var1, var0.lIlI());
   }

   public String Illll(Object var1) {
      if (var1 == null.lI) {
         Path var6 = this.lIlll();
         String var7;
         if (var6 != null) {
            var7 = var6.getFileName().toString();
            String var10001 = lIlIII.Il(IllIlI(612632735, -1235412368));
            String var5 = IIIIlI.lIlI();
            String var4 = var10001;
            String var3 = var7;
            var7 = var3 + var4 + var5;
         } else {
            var7 = lIlIII.Il(IllIlI(612632734, 2052730560));
         }

         return var7;
      } else {
         Path var2 = this.IlII(var1);
         return var2 == null ? lIlIII.Il(IllIlI(612632801, -1704064351)) : var2.toAbsolutePath().normalize().toString();
      }
   }

   public void lIIII(class_3675.class_306 var1) {
      this.IIIII = var1 == null ? class_3675.field_16237 : var1;
   }

   private String lIIIl(Object var1) {
      return (var1 == null.I ? lllll : llIIl).lIlI();
   }

   private void lIIlI(Path var1, Object var2, Object var3, boolean var4) {
      if (var1 != null) {
         this.IlIlIl(var1.resolve(var2.lIlI()), this.llIII(null.I), var4);
         Path var5 = var1.resolve(var3.lIlI());
         this.lIIl(var5, this.IIllI(), var4);
         this.lIIl(var5.resolve(lIII.lIlI()), this.lllII(), var4);
         this.lIIl(var1.resolve(llIII.lIlI()), this.IlIllI(), var4);
         Path var6 = var1.resolve(IIIIIl.lIlI());
         this.lIIl(var6, this.IIllI(), var4);
         if (var4) {
            this.IlIlI(var5.resolve(lIII.lIlI()));
            this.IlIlI(var5);
            this.IlIlI(var6);
            this.IlIlI(var1.resolve(llIII.lIlI()));
         }

      }
   }

   static boolean lIlII(JsonObject var0, long var1) {
      return IIllll(var0, var1) != null;
   }

   public class_3675.class_306 lIlIl() {
      return this.IIIII;
   }

   private Path lIlll() {
      return (Path)FabricLoader.getInstance().getModContainer(lIlIII.Il(IllIlI(612632800, 1293235890))).map((var0) -> (Path)var0.getOrigin().getPaths().get(0)).orElse((Object)null);
   }

   public Path llIII(Object var1) {
      Path var2 = this.IlII(var1);
      return var2 == null ? null : var2.resolve(this.llIl(var1));
   }

   private Path llIIl() {
      return IlllI(lIlI);
   }

   public String llIlI() {
      return this.lllII ? l(this.Ill) : null;
   }

   public String llIll(Object var1) {
      String var10000;
      switch (var1.ordinal()) {
         case 0 -> var10000 = lIlIII.Il(IllIlI(612632803, -367505793));
         case 1 -> var10000 = lIlIII.Il(IllIlI(612632802, 1672051409));
         case 2 -> var10000 = lIlIII.Il(IllIlI(612632805, 659845864));
         case 3 -> var10000 = IlIIl.lIlI();
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   public Path lllII() {
      Path var1 = this.IlII(null.I);
      return var1 == null ? null : var1.resolve(lIII.lIlI());
   }

   private static String lllIl(JsonObject var0, JsonObject var1) {
      boolean var2 = IIlII(var0);
      boolean var3 = IlIIIl(var0);
      if (var2 && var3) {
         return lIlIII.Il(IllIlI(612632804, 43076929));
      } else if (var3) {
         return lIlIII.Il(IllIlI(612632807, -226601392));
      } else {
         return var2 ? lIlIII.Il(IllIlI(612632806, 1920424293)) : lIlIII.Il(IllIlI(612632809, 1852914335));
      }
   }

   public Path llllI() {
      return this.llIII(null.I);
   }

   private Path lllll() {
      FileSystem var1 = this.lllI();
      return var1 == null ? null : var1.getPath(IIIIlI.lIlI());
   }

   private static JsonObject IIIIII(JsonObject var0) {
      return var0 != null && var0.has(lIlIII.Il(IllIlI(612632808, -2014230957))) ? var0.getAsJsonObject(lIlIII.Il(IllIlI(612632811, -930729179))).deepCopy() : new JsonObject();
   }

   static {
      short var6 = 7122;
      String var7 = "抓戒才扴抲扉拑抣抈拭戎抡扯抢戰拵戾抖抈拺扷戔戅戝戼戔戀抲ꢩꡦꠡꠄꣂꠃꢇ\ua8ca꣸ꢙꡔ꣏ꠛ꣒ꡟꢍꡉꢡꣂꢜꠃꡰꡠꠀ悩怵怳怅惔态悫惝惪悮怓悿致腨腮腘膉腜臶膀膷至腎臢౮೩\u0cf8ೣగೈఇషఇౕೆఴ\u0cdfత\u0cd1\u0c29ಂౠవ౾\u0cd2ಾೠ\u0cda¨n\u001d5Ò\u000b\u009d¬\uf237\uf2b7\uf2ae\uf2fc\uf24f\uf293\uf255\uf23bಗ\u0c54ధఅ೭శ\u0cfe\u0cd8閉镱锎锃间锭闤閇\uf5d6\uf522\uf57d\uf56a\uf5ab\uf553\uf5c7\uf5ac\uf592\uf5e0\uf56e\uf5c7梨契論牢吏縷轢禮禮溜雷連找拢拤拒戃拖扼戊戽批拄扨䋎䉖䉀䉦䊳䉲䊿䊽䊎䋝䈝䋜ꗓꔥꕾꕪꖫꕮꗀꖫ壷堪堞塿墊塘墎壠穀竘竰竍稾竖穎稝稃穦窑穞童稭竉穋圆埥垌垊坿垾圓圕\udb4e\udbb8\udbe3\udbf7\udb36\udbf3\udb5d\udb36\udb0f\udb4c\udbf4\udb5d\ude7b\udea2\ude96\udede\ude02\udec5\ude4b\ude37\ude39\ude59\uded2\ude33\uded7\ude7c\udec0\ude41\ude8f\ude7b\ude16\ude4c\udec5\ude8d\udee2\udeab\uf865\uf8a1\uf8d7\uf8c0\uf81a\uf8ea\uf86e\uf833\uf838\uf870\uf89f\uf824\uf8c8\uf829\uf8ea\uf849\uf881\uf825\uf815\uf863\uf8c1\uf88e\uf8e1\uf8ac\uf89c\uf889\uf8af\uf877\uf864\uf872\uf856\uf867\uf87d\uf8b6\uf8e3\uf8c1\uf83b\uf8d3\uf80b\uf830\uf85f\uf87f\uf8c7\uf86e誣詧訑訆諄訬誤諊諽誦詫諄訍談訙誄詂誾諾誤訇訥詣詺詊詜詓誣誼諩誢誎誻詆許訲璴琨琮琘瓉琜璶瓀瓷璳琎璢ⴚⶆⶀⶶⵧⶲⴘ\u2d6eⵙⴝⶠⴌ伌俳侾侖佶侯优伌佥伏俽伏侼佤俠佀쟍윎읟윁잲읕쟡쟏잚쟒읪쟃ꥄ꧆꧰ꦁꤿ꧋ꥬꤙꤔꥒꦉ\ua958꧴ꤚꧠꤎ줡짐즗즬쥞즡줓쥚쥤줒즎쥒즂쥿즐줟짟쥋줿쥡뛑뙐똏똲뛱똔뛴뚚棷栬桿桟梙桸梈棦乹仠任仂万仆丌一\ue6ca\ue629\ue64f\ue666\ue6b0\ue672\ue6b4\ue6da᩿\u1ae2\u1ae1\u1af0ᨁ\u1afdᩗᨀᨼᩛ᪾ᨍ\u1adc᩹᪁ᩚ᪀ᨲᨤᩑ↽ⅉ№℁⇀ℸ↬⇇⇹↋℅↬\ue086\ue072\ue02d\ue03a\ue0fb\ue003\ue097\ue0fc\ue0c2\ue0b0\ue03e\ue097晹曡曉更昇曯晷昤昺晟暨晡曞昗曬晁暇昷昿昿箽筹笏笘篚笲箺篔篣箸筵篚笓篙笇箚筜箠篠箺笘笻筈筕筐笯筅箯箼箫箚箠篸签笍笨篣笭箳篚篌篤笖箶顇颃飵飢頠飘顲頡領顝颵頹飩頣飥顠颯頇頙顁飦颅颔颌颬颅颯顏顒頣顰顪顔颢飫飠領飡頭頦顿顚颫題햘핮픗픑헠픥햵헑皾瘧瘔癤皜瘁皶盁盥皙癘盛瘊盨瘩皾癔盛皮皭\ue475\ue4b2\ue48d\ue4bc\uf048\uf0de\uf0f1\uf0c0ᥭ᧻᧔᧥푔퓕풊풷푴풑푱퐟炢灁瀨瀮烛瀚炷炱\udcde\udc46\udc6e\udc53\udca0\udc48\udcd0\udc83\udc9d\udcf8\udc0d\udccc\u2e7f⺜\u2ef5⻳⸆⻇\u2e6a\u2e6cݥކ߯ߩܜߝݰݶ岒尊尢尟峬射岜峏峑岴屁岀㮶㬮㬸㬞㯋㬊㯇㯅㯶㮥㭥㮤䛭䙵䙣䙅䚐䙑䚜䚞䚭䛾䘾䛿ꗮꔘꕃꕗꖖꕓꗽꖖ\u09d0दॽ३ন७ৃনⰞⳃ\u2cf7ⲖⱣⲱⱧⰉ逓郎郺邛遮邼遪逄脥膻膽膄腅膵脽腝腤脆膘脱᳜᱂᱄ᱽ\u1cbc\u1c4c᳄ᲤᲝ\u1cffᱡ\u1cc8諳詫詃詾認詥諽誮誰諕訢諭詖語詺諸\uf262\uf2fa\uf2d2\uf2ef\uf21c\uf2f4\uf26c\uf23f\uf221\uf244\uf2b3\uf27c\uf2c7\uf20f\uf2eb\uf269㖏㕹㔢㔶㗷㔲㖜㗷㗎㖍㔵㖜╻▍◖◂┃◆╨┃┺╹◁╨쎗쌋쌍쌻쏪쌿쎕쏣쏔쎐쌭쎁뼪뾶뾰뾆뽗뾂뼨뽞뽩뼭뾐뼼륾릮릁린畽疼痭痧畀痏畃甐甠畑疜甞病畠痜畔疙甩畻甥镈閠闿门键闑镻锘锞镡闣键闱锪闷锅䀉䃸䂿䂄䁶䂉䀻䁲䁌䀺䂱䀝\ue76e\ue7ef\ue786\ue7bf\ue749\ue7b4\ue70e\ue74d\ue772\ue72e\ue786\ue74f\ue79e\ue74b\ue7bf\ue73c\ue7ca\ue741\ue724\ue710\ue78f\ue7ac\ue7a5\ue79a溛減渳渎滾渿溣滭滗溵湴滵渥滾游溏湲滯溛滅⩠⪉⫖⫟⨂⫂⨋⨇⨪⩎⪙⩣⫕⨮⪌⨬ྠཤ༥ལ࿚༑ྐྵ\u0fe8\u0ff3ྨༀྩｏﾋￊﾌＵ\ufffeｖ＇＜ｇ\uffefｆ罆羂翃羅缼翷罟缎缕罎翦罏捂掄揷掄挾揤挢捌ృ\u0cdf\u0cd9೯ా೫ుషఀౄ\u0cf9ౕ䌴䎨䎮䎘䍉䎜䌶䍀䍷䌳䎎䌢䫎䨔䨠䩧䪴䩵䫘䪂䪍䫅䨌䪃䩩䪤䩀䫨䨡䪐䪂䫼䩳䨸䨿䩡\ue142\ue198\ue1ac\ue1eb\ue138\ue1f9\ue154\ue10e\ue105\ue170\ue1f5\ue139\ue1e6\ue147\ue1fa\ue164\ue1b4\ue139\ue15d\ue103\udd3e\udda6\uddb0\udd96\udd44\udda7\udd47\udd29옊웪욌욵왴욘옲왠왎옍욵옜ꍋꏋꏣꏞꌮꏯꍳꌽ媪婬娯娎嫈娝媳嫈嫱媩婎媮娗媲娆媋婋嫿嫲媒娎婃婭娙䠧䣚䢠䢶䡀䢁䠉䡌䡌䠲䣷䡔䢘䡓䢁䠟䣅䡷䡟䠋迄轄转轑辡轠迼農辈迬轱辪轿连轙运輢还辋迃轧輦轎轴㎼㍸㍌㌔㏙㍺㎍㎠㏣㎃㍊㏙㌆㏵㍗㏷퀏탋탿킧큪탉퀾큗큕퀚탇큽킱퀔킽퀚탧큺퀎큐퀖탭킺킵큲킶퀶큦큞퀺탡큎킡큼탸큘⟌✷❠❯➨❬⟬➼➄⟠✣➝❶⟓❸➂䅌䆸䇠䇳䄬䇣䅉䄠䄌䅺䇴䅝\ue6b0\ue65e\ue605\ue611\ue6d0\ue615\ue6bb\ue6d0\ue6fd\ue699\ue66c\ue6e3\ue60a\ue6aa\ue615\ue6fb읣쟣쟗쟋윀쟢음윉윌읝잲윀쟛윝잉윩臚脞腨腿膧腊臿膈膃臱脼膖腣膮腂臵脼膙臛膅퉶튲틄틓툊틃퉓툧툫퉊튼퉽\udce2\udc19\udc52\udc52\udc9f\udc7a\udc83\udca2௯ଔୟୟஒ୵௵ஜர\u0bd5େா\u0b50ளଁ\u0ba1뭌믍믖믳묮믍묡묩묝뭣뮣묃믽묢뮦묆ꘀꚁꚚꚿꙢꚁꙭꙥꙑꘪꛧꙛꚸꙵꚑꘓꛢꙖꙸꙞ洆涃涀涴浤涥洟浨浚洉深浯涼浝涥洹坐埕埖埢圲埳坉圾圏坩垣圆埪圲埴圞㺌㹴㸝㸿㻩㸿㺯㻿﵉\ufdcc\ufddfﷻﴩ\ufde9ﵵﴻﴝ﵉ﶾ﴿ﷵﴻ\ufde9ﴇ稨窭窾窏穉窈穀稣獱玞珊珆猑珆獴猥猩獘玕獳珌獨珑獦香饡餈餪駼餪馺駪駒馶饩駺餡駞餹馌볟배밮뱴볤뱭볫벨벇볋밖벭뱫벱밵법⪇⩨⨤⨣⫢⨳⪣⫱⫘⪹⨲⫴⨹⪜⩠⫍璀瑗琣琤瓽琴璤瓶瓟璾琵瓳琾璛瑧瓊摒擖擺擅搵擗搻搂滞湛湘湬溿湾滢溹溁滴渕滐믍묈묃묜믫묗뮭믙믈뮷물믧묷믖묲뮯뭫믭뮉믗ㄎ\u31e5ㆋ㆜ㅪㆽㄗㅿㅓㄴㆪ\u3103氆法沃泉決沴氲氎䀥䂽䂦䂕䁘䂈䀈䁈䁣䀑䂟䀶\uf34b\uf3cb\uf3d0\uf3e3\uf32e\uf3fe\uf37e\uf33e\uf315\uf367\uf3e9\uf340߅ݝ݆ݵ\u07b8ݨߨިރ߶܉ޏݧ߆݉߳銥鈽鈦鈕鋘鈈銈鋈鋣銖鉥鋞鈂鋙鈱銨鉜鋺鋤銎鈙鉆鉾鉓鉕鉼鈟鋙㙎㛖㛅㛧㘳㛳㙙㘀㘏㙃㚧㘺㛪㘗㛸㙷㚷㘣㙗㘉챒쳊쳙쳻찯쳯책찜찓챟첻찝쳰찭청챟첢찠찔챣쳨첩쳁쳻ᇟᅇᅔᅶᆢᅢᇈᆑᆞᇒᄶᆫᅹᆙᅓᇦᄠᇛᆿᇮᅥᄿᄜᄎ㐋㒔㒒㒲㐬㒰㐸㑄㑊㐪㒡㑀㒬㐏㒳㐲㓤㑅㑡㐑㒳㓽㓬㓛㓸㓺㒲㑱⋘≀≖≰⊢≁⊡⋏藡蕹蕍蕩薜蕧藧薚薸藽蔆薋蕇藣蕫薳\ue319\ue3f9\ue39f\ue396\ue360\ue39b\ue31b\ue355\ue35a\ue338\ue3a3\ue30f颻顊頕頗飀頁额飓飴颾頍飝頋飓顋颞顇飳飜颤項项顡頕\ue12e\ue1b3\ue1b0\ue1a1\ue150\ue1ac\ue106\ue151\ue16d\ue108\ue1e7\ue161\ue189\ue128\ue1a7\ue11d䛴䘩䙺䙅䚈䙭䛈䚖䚴䛷䙏䛦哎吚呜呔咳呼哺咖咤哳呭哄掳捀挈挏揎挶掔揸揽掸捵揈顣颹颍飊頙飘页頯頠顸颭頒飈頚飓顅颕頽頍顐颅颅颀颹颕飮颫頙嵉嶷嶪巤崻巹嵕嵟崄嵵嶯崍差崸巨嵹嶻崍崢嵶象賣賉販谜賃豙谹葨蓶蓰蓉萈蓨葨萞萩葛蓕葼蔩薷薱薈蕉薩蔩蕟蕨蔚薔蔽ẳḭḫḒồḳẳễỲẀḎầ밖벊벌벺뱫벾바뱢뱕밑벬밀앒엎었엾씯엺앐씦씑압엨아ုმႄ႓ၒႪှၕၫမ႗ှ됮뒰뒶뒏둎뒮됮둘둯됝뒓됺㼴㾴㾜㾡㽑㾐㼌㽂별뱘뱞뱨벹뱬볆벰벇볃뱾볒畞疀痃痢甤痱畟甤甝畀痰甡痱産痦畣疥甄甬畨楂槟槜槍椼槀楪椽椁楦榃椰槡楄榼楧榽椏椙楬ﴐﶍﶎﶟﵮﶒﴸﵯﵓﴴ\ufdd1ﵢﶳﴖ\ufdeeﴵ\ufdefﵝ﵋﴾뀝낁낇낱끠낵뀟끩끞뀚낧뀋㢞㠂㠄㠲㣣㠶㢜㣪㣝㢙㠤㢈\uf34a\uf3d4\uf3d2\uf3eb\uf32a\uf3ca\uf34a\uf33c\uf30b\uf379\uf3f7\uf35e\uf6b0\uf62e\uf628\uf611\uf6d0\uf630\uf6b0\uf6c6\uf6f1\uf683\uf60d\uf6a4\u20c5⁛⁝\u2064₥⁅\u20c5₳₄\u20f6⁸⃑\ue6c0\ue65e\ue658\ue661\ue6a0\ue640\ue6c0\ue6b6\ue681\ue6f3\ue67d\ue6d4";
      char[] var8 = "ᯎᯊᯞᯞᯊᯚᯚᯚᯚᯞᯞᯞᯞᯚᯚᯂᯚᯞᯊ᯾\u1bf6ᯞᯞᯂᯞᯂᯆᯚᯚᯚᯚᯆᯞᯞᯆ᯾᯾ᯚᯆᯖᯖᯖᯚᯚᯞᯚᯚᯞᯞᯞᯚᯚᯚᯚᯞᯞᯂᯂᯞᯞᯞᯞᯖᯆᯂᯞᯊᯆᯂᯞᯞᯞᯚᯞᯞᯊᯆᯚᯞᯚᯊᯆᯊᯂᯆᯂᯂᯞᯂᯂᯆᯞᯚᯂᯂᯆᯂᯂᯚᯂᯚᯂᯂᯂᯂᯂᯚᯞᯆᯞᯚᯞᯞᯂᯎᯆᯊᯊᯎᯚᯂᯞᯊᯂᯞᯞᯞᯎᯆᯚᯞᯞᯞᯞᯞᯞᯞᯚᯞᯆᯆᯆᯞᯞᯞᯞᯞᯞ".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IIIlIl = var9;
            IIIllI = new Object[var9.length];
            int var2 = 478631151;
            byte[] var0 = "áËÚ\u000bê4%\u0012ð)\fmTÞ\u0083\b\u0018ê\u001bt\u0006¶ËÒ".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IIIlII = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IIIlII[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            llllI = (new GsonBuilder()).setPrettyPrinting().create();
            IIIll = lIlIII.l(IllIlI(612632810, -841928121));
            llIIl = lIlIII.l(IllIlI(612632813, 1717383281));
            II = lIlIII.l(IllIlI(612632812, 1512445153));
            IIIIIl = lIlIII.l(IllIlI(612632815, 1091972150));
            IIIIII = lIlIII.l(IllIlI(612632814, 608915105));
            lII = lIlIII.l(IllIlI(612632817, -576117463)).lll();
            IllII = lIlIII.l(IllIlI(612632816, -819589714)).lll();
            lIlll = lIlIII.l(IllIlI(612632819, 147067481)).lll();
            lIIlI = lIlIII.l(IllIlI(612632818, -1262677684)).lll();
            IlIll = lIlIII.l(IllIlI(612632821, 1460542611)).lll();
            ll = lIlIII.l(IllIlI(612632820, 1460808753)).lll();
            lllIl = lIlIII.l(IllIlI(612632823, -1597494874)).lll();
            IlI = lIlIII.l(IllIlI(612632822, -967353869)).lll();
            Illll = lIlIII.l(IllIlI(612632825, 1638991926)).lll();
            llIlI = lIlIII.l(IllIlI(612632824, 1080257140));
            IlII = lIlIII.l(IllIlI(612632827, 115046685)).lll();
            IIIIl = lIlIII.l(IllIlI(612632826, 1433868343)).lll();
            IlllI = lIlIII.l(IllIlI(612632829, 1541824041)).lll();
            lllI = lIlIII.l(IllIlI(612632828, -1930740525)).lll();
            IIIIll = lIlIII.l(IllIlI(612632831, 1011626667)).lll();
            IlIlI = lIlIII.l(IllIlI(612632830, 553680424)).lll();
            lIllI = lIlIII.l(IllIlI(612632769, -368962823)).lll();
            IIIl = lIlIII.l(IllIlI(612632768, -799798998)).lll();
            lIIIl = lIlIII.l(IllIlI(612632771, -1182058913)).lll();
            Illl = lIlIII.l(IllIlI(612632770, 2051895334)).lll();
            lIlIl = lIlIII.l(IllIlI(612632773, -47427042)).lll();
            lIIII = lIlIII.l(IllIlI(612632772, -193838465));
            IIIlI = lIlIII.l(IllIlI(612632775, 513699085)).lll();
            IIlll = lIlIII.l(IllIlI(612632774, 1004483818)).lll();
            IlIII = lIlIII.l(IllIlI(612632777, -1383637433)).lll();
            IIlII = lIlIII.l(IllIlI(612632776, -209693616)).lll();
            IIII = lIlIII.l(IllIlI(612632779, -480872189));
            IIl = lIlIII.l(IllIlI(612632778, -371581752));
            IIIIlI = lIlIII.l(IllIlI(612632781, 1015613098));
            lIlI = lIlIII.l(IllIlI(612632780, -1240920881));
            lIIll = lIlIII.l(IllIlI(612632783, -352250061));
            IIlIl = lIlIII.l(IllIlI(612632782, -952367908));
            l = lIlIII.l(IllIlI(612632785, 1951038127));
            I = lIlIII.l(IllIlI(612632784, -2133055801));
            lll = lIlIII.l(IllIlI(612632787, 364672989));
            llIl = lIlIII.l(IllIlI(612632786, -1319676729));
            llII = lIlIII.l(IllIlI(612632789, 1263227763));
            lIll = lIlIII.l(IllIlI(612632788, -1765402321));
            llIII = lIlIII.l(IllIlI(612632791, -1290531388));
            IlIIl = lIlIII.l(IllIlI(612632790, -1514117961));
            IllIl = lIlIII.l(IllIlI(612632793, 49875629));
            lllll = lIlIII.l(IllIlI(612632792, 1678067640));
            lIII = lIlIII.l(IllIlI(612632795, 530934566));
            IIlI = lIlIII.l(IllIlI(612632794, 1714556083));
            IIll = lIlIII.l(IllIlI(612632797, -1041477044));
            lI = lIlIII.l(IllIlI(612632796, -741447295));
            IlIl = lIlIII.l(IllIlI(612632799, -458459770));
            Il = lIlIII.l(IllIlI(612632798, 528223346));
            lIlII = lIlIII.l(IllIlI(612632609, -631549839));
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private lIllII IIIIIl(String var1) {
      lIllII[] var2 = lIllII.values();

      try {
         int var3 = Integer.parseInt(var1);
         if (var3 >= 0 && var3 < var2.length) {
            return var2[var3];
         }
      } catch (NumberFormatException var7) {
      }

      if (lIlIII.Il(IllIlI(612632608, 131024697)).equalsIgnoreCase(var1)) {
         return lIllII.lI;
      } else {
         for(lIllII var6 : var2) {
            if (llllIIlI.l(var6, var1)) {
               return var6;
            }
         }

         return lIllII.l;
      }
   }

   private static void IIIIll(JsonObject var0, JsonObject var1) {
      if (var0 != null && var0.has(lIlIII.Il(IllIlI(612632611, 265829677)))) {
         var1.add(lIlIII.Il(IllIlI(612632610, 244918262)), var0.get(lIlIII.Il(IllIlI(612632613, -1794942654))).deepCopy());
      }

   }

   private static void IIIlII(JsonObject var0) {
      if (lIlII(var0, IIlll)) {
         JsonObject var1 = IlIII(var0, IIlll);
         if (var1 != null && var1.has(lIlIII.Il(IllIlI(612632612, 933583640)))) {
            JsonObject var2 = var1.getAsJsonObject(lIlIII.Il(IllIlI(612632615, 1323393568)));
            long var3 = IIl.lll();
            long var5 = IIII.lll();
            if (IIIIIIIlI.IlIIIIl(var2, var3) != null) {
               IIIIIIIlI.IIllIII(var2, var5);
            } else {
               JsonElement var7 = IIIIIIIlI.IlIIIIl(var2, var5);
               if (var7 != null) {
                  if (var7 != null && var7.isJsonPrimitive() && var7.getAsJsonPrimitive().isNumber()) {
                     double var8 = var7.getAsDouble();
                     double var10 = Math.max((double)1.0F, Math.min((double)100.0F, (double)101.0F - var8));
                     IIIIIIIlI.IIIIIll(var2, var3, new JsonPrimitive(var10));
                  }

                  IIIIIIIlI.IIllIII(var2, var5);
               }
            }
         }
      }
   }

   private Path IIIlIl() {
      return IllI();
   }

   public void IIIllI(class_3675.class_306 var1) {
      this.IIllI = var1 == null ? class_3675.field_16237 : var1;
   }

   static void IIIlll(JsonObject var0, long var1) {
      var0.remove(l(var1));
      String var3 = null;

      for(String var5 : var0.keySet()) {
         if (lIlIII.II(var5) == var1) {
            var3 = var5;
            break;
         }
      }

      if (var3 != null) {
         var0.remove(var3);
      }

   }

   private void IIlIII() {
      try {
         Path var1 = this.IlII(null.I);
         if (var1 == null) {
            return;
         }

         Files.createDirectories(var1);
         DosFileAttributeView var2 = (DosFileAttributeView)Files.getFileAttributeView(var1, DosFileAttributeView.class);
         if (var2 != null) {
            var2.setHidden(false);
            var2.setSystem(false);
         }

         Path var3 = this.IIllI();
         if (var3 != null) {
            Files.createDirectories(var3);
         }

         Path var4 = this.lllII();
         if (var4 != null) {
            Files.createDirectories(var4);
         }

         Path var5 = this.IlIllI();
         if (var5 != null) {
            Files.createDirectories(var5);
         }
      } catch (IOException var6) {
      }

   }

   private <undefinedtype> IIlIIl(String var1) {
      <undefinedtype>[] var2 = null.values();

      try {
         int var3 = Integer.parseInt(var1);
         if (var3 >= 0 && var3 < var2.length) {
            return var2[var3];
         }
      } catch (NumberFormatException var7) {
      }

      for(<undefinedtype> var6 : var2) {
         if (llllIIlI.l(var6, var1)) {
            return var6;
         }
      }

      return null;
   }

   static void IIlIlI(JsonObject var0, long var1, JsonElement var3) {
      var0.add(l(var1), var3);
   }

   private static void IIlIll(JsonObject var0) {
      if (!lIlII(var0, lIlll)) {
         JsonObject var1 = IlIII(var0, lII);
         JsonObject var2 = IlIII(var0, IllII);
         if (var1 != null || var2 != null) {
            JsonObject var3 = new JsonObject();
            var3.addProperty(lIlIII.Il(IllIlI(612632614, -1679161135)), IIlII(var1) || IIlII(var2));
            JsonElement var4 = IlIlII(var1, var2);
            if (var4 != null) {
               var3.add(lIlIII.Il(IllIlI(612632617, 1072572133)), var4);
            }

            JsonObject var5 = new JsonObject();
            IIIIIIIlI.IIIIIll(var5, lIlIII.l(IllIlI(612632616, -1259701044)).lll(), new JsonPrimitive(lllIl(var1, var2)));
            var3.add(lIlIII.Il(IllIlI(612632619, 923165237)), var5);
            var3.add(lIlIII.Il(IllIlI(612632618, -23372591)), IIIIII(var1));
            IIlIlI(var0, lIlll, var3);
         }
      }
   }

   public void IIllII(JsonObject var1) {
      this.lIl = var1 == null ? new JsonObject() : var1.deepCopy();
   }

   private Path IIllIl() {
      Path var1 = this.IIIlIl();
      return var1 == null ? null : var1.resolve(IIlI.lIlI());
   }

   private void IIlllI() {
      Path var1 = this.IIllIl();
      if (var1 == null || !Files.exists(var1, new LinkOption[0])) {
         Path var2 = this.llIIl();
         var1 = var2 == null ? null : var2.resolve(lIll.lIlI());
      }

      if (var1 == null || !Files.exists(var1, new LinkOption[0])) {
         var1 = this.IllI.resolve(Il.lIlI());
         if (!Files.exists(var1, new LinkOption[0])) {
            return;
         }
      }

      try {
         JsonElement var5 = (JsonElement)llllI.fromJson(Files.readString(var1), JsonElement.class);
         if (var5 == null || !var5.isJsonObject()) {
            return;
         }

         JsonObject var3 = var5.getAsJsonObject();
         if (!var3.has(lIlIII.Il(IllIlI(612632621, -494837541)))) {
            return;
         }

         this.llIll = this.IIlIIl(var3.get(lIlIII.Il(IllIlI(612632620, 1993562515))).getAsString());
      } catch (Exception var4) {
      }

   }

   static JsonElement IIllll(JsonObject var0, long var1) {
      if (var0 == null) {
         return null;
      } else {
         String var3 = l(var1);
         if (var0.has(var3)) {
            return var0.get(var3);
         } else {
            for(Map.Entry var5 : var0.entrySet()) {
               if (lIlIII.II((String)var5.getKey()) == var1) {
                  return (JsonElement)var5.getValue();
               }
            }

            return null;
         }
      }
   }

   private static long IlIIII(long var0) {
      if (var0 == lIIlI) {
         return IlIll;
      } else if (var0 == ll) {
         return lllIl;
      } else if (var0 != lII && var0 != IllII) {
         if (var0 == IlI) {
            return Illll;
         } else if (var0 == IlII) {
            return IIIIl;
         } else if (var0 == IlllI) {
            return lllI;
         } else if (var0 == IIIIll) {
            return IlIlI;
         } else {
            return var0 == lIllI ? IIIl : var0;
         }
      } else {
         return lIlll;
      }
   }

   private static boolean IlIIIl(JsonObject var0) {
      if (var0 != null && var0.has(lIlIII.Il(IllIlI(612632623, 967983338)))) {
         JsonObject var1 = var0.getAsJsonObject(lIlIII.Il(IllIlI(612632622, -1322173113)));

         for(String var3 : var1.keySet()) {
            if (var1.get(var3).isJsonPrimitive()) {
               try {
                  String var4 = var1.get(var3).getAsString();
                  if (!var4.isBlank()) {
                     return true;
                  }
               } catch (UnsupportedOperationException var5) {
               }
            }
         }

         return false;
      } else {
         return false;
      }
   }

   private void IlIIll(Path var1) {
      Path var2 = this.IIIlIl();
      if (var1 != null && var2 != null) {
         if (!var1.toAbsolutePath().normalize().equals(var2.toAbsolutePath().normalize())) {
            this.IlIlIl(var1.resolve(IllIl.lIlI()), this.llIII(null.I), true);
            this.lIIl(var1.resolve(lllll.lIlI()), this.IIllI(), true);
            this.lIIl(var1.resolve(IIIIIl.lIlI()), this.IIllI(), true);
            this.lIIl(var1.resolve(lIII.lIlI()), this.lllII(), true);
            this.lIIl(var1.resolve(lllll.lIlI()).resolve(lIII.lIlI()), this.lllII(), true);
            this.lIIl(var1.resolve(IIll.lIlI()), this.IlIllI(), true);
            this.lIIl(var1.resolve(llIII.lIlI()), this.IlIllI(), true);
            this.IlIlIl(var1.resolve(IIlI.lIlI()), this.IIllIl(), true);
            this.IlIlI(var1.resolve(lllll.lIlI()).resolve(lIII.lIlI()));
            this.IlIlI(var1.resolve(lllll.lIlI()));
            this.IlIlI(var1.resolve(IIIIIl.lIlI()));
            this.IlIlI(var1.resolve(lIII.lIlI()));
            this.IlIlI(var1.resolve(IIll.lIlI()));
            this.IlIlI(var1.resolve(llIII.lIlI()));
            this.IlIlI(var1);
         }
      }
   }

   private static JsonElement IlIlII(JsonObject var0, JsonObject var1) {
      if (var0 != null && var0.has(lIlIII.Il(IllIlI(612632625, 2061784106)))) {
         return var0.get(lIlIII.Il(IllIlI(612632624, 2132690257))).deepCopy();
      } else {
         return var1 != null && var1.has(lIlIII.Il(IllIlI(612632627, -1452598433))) ? var1.get(lIlIII.Il(IllIlI(612632626, 1869507035))).deepCopy() : null;
      }
   }

   private boolean IlIlIl(Path var1, Path var2, boolean var3) {
      if (var1 != null && var2 != null && Files.isRegularFile(var1, new LinkOption[0])) {
         if (var1.toAbsolutePath().normalize().equals(var2.toAbsolutePath().normalize())) {
            return false;
         } else {
            boolean var4 = false;

            try {
               Files.createDirectories(var2.getParent());
               if (!Files.exists(var2, new LinkOption[0])) {
                  if (var1.getFileSystem().equals(var2.getFileSystem())) {
                     Files.copy(var1, var2);
                  } else {
                     Files.writeString(var2, Files.readString(var1));
                  }

                  var4 = true;
               }

               if (var3 && var4) {
                  Files.deleteIfExists(var1);
               }

               return var4;
            } catch (IOException var6) {
               return false;
            }
         }
      } else {
         return false;
      }
   }

   public Path IlIllI() {
      Path var1 = this.IlII(null.I);
      return var1 == null ? null : var1.resolve(IIll.lIlI());
   }

   public void IlIlll(Object var1, IIllIlII var2) {
      this.llIll = var1;
      if (this.llIll != null.I) {
         this.llIll = null.I;
      }

      this.IIIII();
      Path var3 = this.llllI();
      if (var3 != null && Files.exists(var3, new LinkOption[0])) {
         this.IlIIl(var2);
      } else {
         this.IlI(var2);
      }

   }

   public void IllIII(lIllII var1, IIIIIIIlI var2) {
      this.llI = var1 == null ? lIllII.l : var1;
      this.lllII = var2 != null;
      this.Ill = var2 == null ? 0L : var2.IIlIllI();
   }

   private static int IllIIl(int var0, int var1) {
      return IIIlII[var0 ^ 512461174] ^ var1 ^ var0;
   }

   private static String IllIlI(int var0, int var1) {
      int var3 = var0 ^ 612632737;
      char[] var4 = IIIlIl[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IIIllI[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IIIllI[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 1364117885;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 248;
               break;
            case 1:
               var9 = 56;
               break;
            case 2:
               var9 = 77;
               break;
            case 3:
               var9 = 124;
               break;
            case 4:
               var9 = 133;
               break;
            case 5:
               var9 = 123;
               break;
            case 6:
               var9 = 209;
               break;
            case 7:
               var9 = 191;
               break;
            case 8:
               var9 = 132;
               break;
            case 9:
               var9 = 225;
               break;
            case 10:
               var9 = 19;
               break;
            case 11:
               var9 = 186;
               break;
            case 12:
               var9 = 113;
               break;
            case 13:
               var9 = 162;
               break;
            case 14:
               var9 = 90;
               break;
            case 15:
               var9 = 250;
               break;
            case 16:
               var9 = 44;
               break;
            case 17:
               var9 = 168;
               break;
            case 18:
               var9 = 176;
               break;
            case 19:
               var9 = 238;
               break;
            case 20:
               var9 = 68;
               break;
            case 21:
               var9 = 62;
               break;
            case 22:
               var9 = 58;
               break;
            case 23:
               var9 = 0;
               break;
            case 24:
               var9 = 51;
               break;
            case 25:
               var9 = 42;
               break;
            case 26:
               var9 = 19;
               break;
            case 27:
               var9 = 213;
               break;
            case 28:
               var9 = 203;
               break;
            case 29:
               var9 = 170;
               break;
            case 30:
               var9 = 250;
               break;
            case 31:
               var9 = 197;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
