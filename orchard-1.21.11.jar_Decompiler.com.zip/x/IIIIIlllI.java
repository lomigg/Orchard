package x;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.awt.Color;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_642;
import net.minecraft.class_3675.class_307;

@Environment(EnvType.CLIENT)
final class IIIIIlllI {
   private final lIllIIl I;
   private final IIllIIIIl l;
   private boolean II;
   private static final int[] Il;
   private static final String[] lI;
   private static final Object[] ll;

   private Map<String, Object> I(IlIIIlIlI<?> var1, Enum<?> var2) {
      LinkedHashMap var3 = new LinkedHashMap();
      var3.put(lIlIII.Il(IllllI(1525019838, -1764282369)), var1.IlI(var2));
      var3.put(lIlIII.Il(IllllI(1525019839, 1505632459)), var2 == null ? "" : var2.toString());
      return var3;
   }

   private llllllI<?> l(IIIIIIIlI var1, String var2) {
      if (var2 != null && !var2.isBlank()) {
         for(llllllI var4 : var1.IIIlll()) {
            if (var4.Illl().equalsIgnoreCase(var2)) {
               return var4;
            }
         }

         String var5 = lIlIII.Il(IllllI(1525019837, -1218173840));
         throw new IllegalArgumentException(var5 + var2);
      } else {
         throw new IllegalArgumentException(lIlIII.Il(IllllI(1525019836, -2031342443)));
      }
   }

   Map<String, Object> II(JsonObject var1) {
      return (Map)this.IIlIIl(() -> {
         this.llIlI(lIlIII.Il(IllllI(1525019867, 1218933370)));
         boolean var2 = this.l.IIl(this.IlIIl(var1, lIlIII.Il(IllllI(1525019864, 1799827824))), this.I.IIl());
         if (!var2) {
            throw new IllegalStateException(lIlIII.Il(IllllI(1525019865, -275952965)));
         } else {
            this.I.lll();
            return this.IlIl();
         }
      });
   }

   private Map<String, Object> Il(llIlIIII var1) {
      LinkedHashMap var2 = new LinkedHashMap();
      if (var1 instanceof IIIIIIIlI var3) {
         var2.put(lIlIII.Il(IllllI(1525019834, -1554174972)), var3.IIlllII());
         var2.put(lIlIII.Il(IllllI(1525019835, 1653757368)), var3.llll());
         var2.put(lIlIII.Il(IllllI(1525019832, -1614264353)), IlllII(var3.IlIIIII()));
         var2.put(lIlIII.Il(IllllI(1525019833, -128100370)), var3.IIIIIlI());
         var2.put(lIlIII.Il(IllllI(1525019830, 1599941981)), var3.IIlIlIl());
      } else {
         var2.put(lIlIII.Il(IllllI(1525019831, 2063605061)), var1.getClass().getSimpleName());
         var2.put(lIlIII.Il(IllllI(1525019828, -1887824794)), var1.getClass().getSimpleName());
         var2.put(lIlIII.Il(IllllI(1525019829, -1725361463)), IlllII(lIllII.IIl));
         var2.put(lIlIII.Il(IllllI(1525019826, 2090542835)), true);
         var2.put(lIlIII.Il(IllllI(1525019827, -299731577)), false);
      }

      var2.put(lIlIII.Il(IllllI(1525019824, -636544437)), var1.Il());
      var2.put(lIlIII.Il(IllllI(1525019825, -705878424)), var1.Ill());
      var2.put(lIlIII.Il(IllllI(1525019822, 1508734773)), var1.llll());
      var2.put(lIlIII.Il(IllllI(1525019823, 283988286)), var1.lIIl());
      return var2;
   }

   private void lI(String var1) {
      if (!this.II) {
         this.llIlI(var1 == null ? lIlIII.Il(IllllI(1525019820, 1747080077)) : var1);
         this.II = true;
      }
   }

   Map<String, Object> ll() {
      return (Map)this.IIlIIl(() -> this.lIllI().lIIl());
   }

   Map<String, Object> III() {
      return (Map)this.IIlIIl(() -> {
         LinkedHashMap var1 = new LinkedHashMap();
         ArrayList var2 = new ArrayList();

         for(IIIIIIIlI var4 : this.I.IIl().IIIIlII()) {
            LinkedHashMap var5 = new LinkedHashMap();
            var5.put(lIlIII.Il(IllllI(1525019653, 1856719560)), var4.IIlllII());
            var5.put(lIlIII.Il(IllllI(1525019650, 1166685784)), var4.llll());
            var5.put(lIlIII.Il(IllllI(1525019651, 1120159784)), IlllII(var4.IlIIIII()));
            var5.put(lIlIII.Il(IllllI(1525019648, 1565989855)), this.IllIIl(var4.IIIlIII()));
            var2.add(var5);
         }

         var1.put(lIlIII.Il(IllllI(1525019649, 1259673748)), true);
         var1.put(lIlIII.Il(IllllI(1525019774, 949373083)), this.IllIIl(this.I.lI().lIlIl()));
         var1.put(lIlIII.Il(IllllI(1525019775, 230323967)), var2);
         return var1;
      });
   }

   private Map<String, Object> IlI(String var1, Supplier<Map<String, Object>> var2) {
      return (Map)this.IIlIIl(() -> {
         this.lI(var1);
         return (Map)var2.get();
      });
   }

   Map<String, Object> Ill(JsonObject var1) {
      return this.IlI(lIlIII.Il(IllllI(1525019818, 1473530699)), () -> {
         this.I.lI().lIIII(this.llI(var1));
         this.I.lll();
         return this.lll(lIlIII.Il(IllllI(1525019694, 402344195)), this.IllIIl(this.I.lI().lIlIl()));
      });
   }

   private String lII() {
      class_310 var1 = class_310.method_1551();
      if (var1 == null) {
         return lIlIII.Il(IllllI(1525019819, 757555530));
      } else {
         class_642 var2 = var1.method_1558();
         if (var2 != null && var2.field_3761 != null && !var2.field_3761.isBlank()) {
            return var2.field_3761;
         } else {
            return var1.method_1542() ? lIlIII.Il(IllllI(1525019816, 1431518312)) : lIlIII.Il(IllllI(1525019817, -1665826907));
         }
      }
   }

   Map<String, Object> lIl(JsonObject var1) {
      return (Map)this.IIlIIl(() -> this.lIllI().l(this.IlIIl(var1, lIlIII.Il(IllllI(1525019821, 401605307))), this.llI(var1)));
   }

   private class_3675.class_306 llI(JsonObject var1) {
      String var2 = this.lIlII(var1, lIlIII.Il(IllllI(1525019814, -1167896415)));
      if (var2 == null) {
         var2 = this.lIlII(var1, lIlIII.Il(IllllI(1525019815, 535326752)));
      }

      int var3 = this.IIIII(var1, lIlIII.Il(IllllI(1525019812, 828969638)), -1);
      if (var3 >= 0 && var2 != null && !lIlIII.Il(IllllI(1525019813, 1658137173)).equalsIgnoreCase(var2) && !lIlIII.Il(IllllI(1525019810, 2074556896)).equalsIgnoreCase(var2)) {
         return lIlIII.Il(IllllI(1525019811, -677041638)).equalsIgnoreCase(var2) ? IllllIlI.IllII(var3) : IllllIlI.lllll(var3);
      } else {
         return class_3675.field_16237;
      }
   }

   private Map<String, Object> lll(String var1, Object var2) {
      LinkedHashMap var3 = new LinkedHashMap();
      var3.put(lIlIII.Il(IllllI(1525019808, 77944905)), true);
      var3.put(var1, var2);
      return var3;
   }

   private Object IIIl(Object var1) {
      if (var1 instanceof Color var5) {
         return this.llIIl(var5);
      } else if (var1 instanceof Enum var4) {
         LinkedHashMap var3 = new LinkedHashMap();
         var3.put(lIlIII.Il(IllllI(1525019802, 1905546691)), Integer.toString(var4.ordinal(), IlllIl(391473875, 1671149292)));
         var3.put(lIlIII.Il(IllllI(1525019803, -1197977471)), var4.toString());
         return var3;
      } else if (var1 instanceof class_3675.class_306 var2) {
         return this.IllIIl(var2);
      } else {
         return var1;
      }
   }

   Map<String, Object> IIlI() {
      return (Map)this.IIlIIl(() -> this.lll(lIlIII.Il(IllllI(1525019884, 741098045)), this.l.ll(this.I.IIl())));
   }

   Map<String, Object> IIll(JsonObject var1) {
      return (Map)this.IIlIIl(() -> this.lIllI().III(this.lIlII(var1, lIlIII.Il(IllllI(1525019701, 1094921187)))));
   }

   private Map<String, Object> IlIl() {
      Map var1 = this.lll(lIlIII.Il(IllllI(1525019799, 61894498)), this.l.IllI());
      var1.put(lIlIII.Il(IllllI(1525019796, -1828699022)), this.l.ll(this.I.IIl()));
      return var1;
   }

   Map<String, Object> IllI(JsonObject var1) {
      return (Map)this.IIlIIl(() -> {
         this.llIlI(lIlIII.Il(IllllI(1525019765, 720452464)));
         String var2 = this.IIlIII(this.IlIIl(var1, lIlIII.Il(IllllI(1525019762, 1274508804))));
         boolean var3 = this.l.IIlI(var2, this.I.IIl());
         if (!var3) {
            throw new IllegalStateException(lIlIII.Il(IllllI(1525019763, -1833420659)));
         } else {
            this.I.lll();
            return this.IlIl();
         }
      });
   }

   Map<String, Object> Illl(String var1) {
      return (Map)this.IIlIIl(() -> {
         IIIIIIIlI var2 = this.IlIll(var1);
         LinkedHashMap var3 = new LinkedHashMap();
         var3.put(lIlIII.Il(IllllI(1525019885, -711696806)), true);
         var3.put(lIlIII.Il(IllllI(1525019882, -318490918)), this.IIIll(var2, true));
         return var3;
      });
   }

   private Map<String, Object> lIII(llllllI<?> var1) {
      LinkedHashMap var2 = new LinkedHashMap();
      var2.put(lIlIII.Il(IllllI(1525019797, 363201904)), var1.Illl());
      var2.put(lIlIII.Il(IllllI(1525019794, 142900355)), this.lllII(var1));
      var2.put(lIlIII.Il(IllllI(1525019795, 1635846718)), var1.lIlI());
      Object var10000;
      if (var1 instanceof IIIIllIII var4) {
         var10000 = var4.lII();
      } else {
         var10000 = var1.III();
      }

      Object var3 = var10000;
      if (var1 instanceof IIIIllIII var5) {
         var10000 = var5.I();
      } else {
         var10000 = var1.l();
      }

      Object var13 = var10000;
      if (var1 instanceof IlIIIlIlI var14) {
         var2.put(lIlIII.Il(IllllI(1525019792, 592994396)), this.I(var14, (Enum)var3));
         var2.put(lIlIII.Il(IllllI(1525019793, 908672734)), this.I(var14, (Enum)var13));
      } else {
         var2.put(lIlIII.Il(IllllI(1525019790, 1933919722)), this.IIIl(var3));
         var2.put(lIlIII.Il(IllllI(1525019791, -1829877646)), this.IIIl(var13));
      }

      if (var1 instanceof IIIllIIII var15) {
         var2.put(lIlIII.Il(IllllI(1525019788, 725250921)), var15.lIl());
         var2.put(lIlIII.Il(IllllI(1525019789, 644489701)), var15.ll());
         var2.put(lIlIII.Il(IllllI(1525019786, -1544879271)), var15.I());
         var2.put(lIlIII.Il(IllllI(1525019787, -303624619)), var15.lII());
      } else if (var1 instanceof llllIlIl var6) {
         var2.put(lIlIII.Il(IllllI(1525019784, 821387534)), var6.IlII());
         var2.put(lIlIII.Il(IllllI(1525019785, -616299369)), var6.IlI());
         var2.put(lIlIII.Il(IllllI(1525019782, 206266000)), var6.ll());
         var2.put(lIlIII.Il(IllllI(1525019783, -1463871480)), var6.lIl());
         var2.put(lIlIII.Il(IllllI(1525019780, 144201649)), var6.I());
         var2.put(lIlIII.Il(IllllI(1525019781, -1055974528)), var6.llI());
      } else if (var1 instanceof IlIIIlIlI var7) {
         var2.put(lIlIII.Il(IllllI(1525019778, 266606818)), this.IIIIlI(var7));
      } else if (var1 instanceof IIIIllIII var8) {
         var2.put(lIlIII.Il(IllllI(1525019779, 929828649)), this.IlIlII(var8));
      } else if (var1 instanceof lllIIlIl var9) {
         var2.put(lIlIII.Il(IllllI(1525019776, 343150584)), this.IllIIl((class_3675.class_306)var9.III()));
      } else if (var1 instanceof IIllIlIII var10) {
         var2.put(lIlIII.Il(IllllI(1525019777, 815824028)), this.llIIl((Color)var10.III()));
      } else if (var1 instanceof lIIIlll var11) {
         var2.put(lIlIII.Il(IllllI(1525019902, -1133226796)), var11.IIIl());
      } else if (var1 instanceof IlIIIIllI var12) {
         var2.put(lIlIII.Il(IllllI(1525019903, -1803808521)), var12.IIl());
      }

      return var2;
   }

   Map<String, Object> lIIl(String var1) {
      return (Map)this.IIlIIl(() -> {
         Path var2 = this.llIlI(var1);
         return this.lll(lIlIII.Il(IllllI(1525019740, -1452916701)), var2.toString());
      });
   }

   private Color lIlI(JsonElement var1) {
      if (var1 != null && !var1.isJsonNull()) {
         if (var1.isJsonObject()) {
            JsonObject var7 = var1.getAsJsonObject();
            int var8 = this.IIIII(var7, lIlIII.Il(IllllI(1525019900, -700248834)), IlllIl(391473878, -1814691857));
            int var4 = this.IIIII(var7, lIlIII.Il(IllllI(1525019901, -1980542560)), IlllIl(391473877, 491477901));
            int var5 = this.IIIII(var7, lIlIII.Il(IllllI(1525019898, 1795442068)), IlllIl(391473876, 124465605));
            int var6 = this.IIIII(var7, lIlIII.Il(IllllI(1525019899, -917289413)), IlllIl(391473883, -2002674148));
            return new Color(IllIll(var8), IllIll(var4), IllIll(var5), IllIll(var6));
         } else {
            String var2 = var1.getAsString().trim();
            if (var2.startsWith(lIlIII.Il(IllllI(1525019896, -794674548)))) {
               var2 = var2.substring(1);
            }

            long var3 = Long.parseLong(var2, IlllIl(391473882, -478442699));
            return var2.length() > IlllIl(391473881, 401231726) ? new Color((int)var3, true) : new Color((int)var3 | IlllIl(391473880, -664493359), true);
         }
      } else {
         return new Color(IlllIl(391473874, -813545363), IlllIl(391473873, 938767456), IlllIl(391473872, 823893934), IlllIl(391473879, 310425277));
      }
   }

   Map<String, Object> lIll(JsonObject var1) {
      return this.IlI(lIlIII.Il(IllllI(1525019897, 936334836)), () -> {
         llIlIIII var2 = this.IIllIl(this.IlIIl(var1, lIlIII.Il(IllllI(1525019800, -298834636))));
         var2.lIlI(this.IIIlII(var1, lIlIII.Il(IllllI(1525019801, -1504179669)), var2.Il()), this.IIIlII(var1, lIlIII.Il(IllllI(1525019798, -1099012464)), var2.Ill()));
         this.I.lll();
         return this.IlIlI(false);
      });
   }

   private static String lllI(lIllII var0) {
      String var10000;
      switch (null.I[var0.ordinal()]) {
         case 1 -> var10000 = lIlIII.Il(IllllI(1525019890, 283650467));
         case 2 -> var10000 = lIlIII.Il(IllllI(1525019891, -1689252692));
         case 3 -> var10000 = lIlIII.Il(IllllI(1525019888, 1509168348));
         case 4 -> var10000 = lIlIII.Il(IllllI(1525019889, -2097197876));
         case 5 -> var10000 = lIlIII.Il(IllllI(1525019886, 2005630174));
         case 6 -> var10000 = lIlIII.Il(IllllI(1525019887, -1891080848));
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   private int IIIII(JsonObject var1, String var2, int var3) {
      return var1 != null && var1.has(var2) && !var1.get(var2).isJsonNull() ? var1.get(var2).getAsInt() : var3;
   }

   Map<String, Object> IIIIl(int var1) {
      return (Map)this.IIlIIl(() -> {
         LinkedHashMap var2 = new LinkedHashMap();
         var2.put(lIlIII.Il(IllllI(1525019732, 235274655)), true);
         var2.put(lIlIII.Il(IllllI(1525019733, 22903107)), var1);
         var2.put(lIlIII.Il(IllllI(1525019730, -1805565853)), true);
         var2.put(lIlIII.Il(IllllI(1525019731, 400045575)), false);
         var2.put(lIlIII.Il(IllllI(1525019728, -1450088002)), this.IllIIl(this.I.lI().lIlIl()));
         Path var3 = this.I.lI().IlIll();
         var2.put(lIlIII.Il(IllllI(1525019729, 1401895441)), var3 == null ? null : var3.toString());
         var2.put(lIlIII.Il(IllllI(1525019726, -692763271)), IlllII(this.I.lI().Illl()));
         var2.put(lIlIII.Il(IllllI(1525019727, 326384947)), this.I.lI().llIlI());
         var2.put(lIlIII.Il(IllllI(1525019724, 1415476970)), this.lII());
         lIIIllll var4 = this.I.IIl() == null ? null : this.I.IIl().llI();
         if (var4 != null) {
            var2.put(lIlIII.Il(IllllI(1525019725, -1536811981)), this.IlIllI(var4));
         }

         return var2;
      });
   }

   private Map<String, Object> IIIll(IIIIIIIlI var1, boolean var2) {
      LinkedHashMap var3 = new LinkedHashMap();
      var3.put(lIlIII.Il(IllllI(1525019883, 1483809883)), var1.IIlllII());
      var3.put(lIlIII.Il(IllllI(1525019880, 607935601)), var1.llll());
      var3.put(lIlIII.Il(IllllI(1525019881, -1987754046)), var1.IIlllIl());
      var3.put(lIlIII.Il(IllllI(1525019878, -1847754991)), var1.I());
      var3.put(lIlIII.Il(IllllI(1525019879, 1319447711)), IlllII(var1.IlIIIII()));
      var3.put(lIlIII.Il(IllllI(1525019876, -822221)), var1.llllll());
      var3.put(lIlIII.Il(IllllI(1525019877, -722907171)), var1.IIIIIlI());
      var3.put(lIlIII.Il(IllllI(1525019874, 180094168)), var1.IIlIlIl());
      var3.put(lIlIII.Il(IllllI(1525019875, -1548518886)), this.IllIIl(var1.IIIlIII()));
      if (var1 instanceof llIIIlII) {
         var3.put(lIlIII.Il(IllllI(1525019872, 1928414235)), lIlIII.Il(IllllI(1525019873, 401825131)));
      } else if (var1 instanceof IlllIlII) {
         var3.put(lIlIII.Il(IllllI(1525019870, -505518304)), lIlIII.Il(IllllI(1525019871, 1648321788)));
      }

      List var4 = var1.IIIlll();
      var3.put(lIlIII.Il(IllllI(1525019868, -2129107447)), !var4.isEmpty());
      if (var1 instanceof llIlIIII var5) {
         var3.put(lIlIII.Il(IllllI(1525019869, 1423717844)), this.Il(var5));
      }

      if (var2) {
         ArrayList var8 = new ArrayList();

         for(llllllI var7 : var4) {
            var8.add(this.lIII(var7));
         }

         var3.put(lIlIII.Il(IllllI(1525019866, 679230862)), var8);
      }

      return var3;
   }

   Map<String, Object> IIlIl(JsonObject var1) {
      return this.IlI(lIlIII.Il(IllllI(1525019862, 981351455)), () -> {
         IIIIIIIlI var2 = this.IlIll(this.IlIIl(var1, lIlIII.Il(IllllI(1525019698, -263228949))));
         llllllI var3 = this.l(var2, this.IlIIl(var1, lIlIII.Il(IllllI(1525019699, 1729762566))));
         if (var3 instanceof IlIIIIllI var4) {
            var4.l();
            this.I.lll();
            return this.lll(lIlIII.Il(IllllI(1525019697, 423065386)), this.lIII(var3));
         } else {
            throw new IllegalArgumentException(lIlIII.Il(IllllI(1525019696, 1835556128)));
         }
      });
   }

   private Map<String, Object> IIllI(lIllII var1) {
      LinkedHashMap var2 = new LinkedHashMap();
      var2.put(lIlIII.Il(IllllI(1525019863, -1556412403)), IlllII(var1));
      var2.put(lIlIII.Il(IllllI(1525019860, 1692147492)), llllI(var1));
      String var10001 = lIlIII.Il(IllllI(1525019861, -1867295878));
      String var10002 = lIlIII.Il(IllllI(1525019858, 1949185133));
      String var10003 = lllI(var1);
      String var5 = lIlIII.Il(IllllI(1525019859, -1511033336));
      String var4 = var10003;
      String var3 = var10002;
      var2.put(var10001, var3 + var4 + var5);
      return var2;
   }

   private void IIlll(llllllI<?> var1, JsonElement var2) {
      if (var1 instanceof lIIIIl var14) {
         var14.Il(var2 != null && var2.getAsBoolean());
      } else if (var1 instanceof IIIllIIII var13) {
         var13.III(var2.getAsDouble());
      } else if (var1 instanceof llllIlIl var12) {
         if (var2 != null && var2.isJsonArray()) {
            JsonArray var17 = var2.getAsJsonArray();
            if (var17.size() < 2) {
               throw new IllegalArgumentException(lIlIII.Il(IllllI(1525019857, 804812165)));
            } else {
               var12.IIIl(new double[]{var17.get(0).getAsDouble(), var17.get(1).getAsDouble()});
            }
         } else {
            throw new IllegalArgumentException(lIlIII.Il(IllllI(1525019856, 1806657064)));
         }
      } else if (var1 instanceof IIIIllIII var11) {
         ArrayList var16 = new ArrayList();
         if (var2 != null && var2.isJsonArray()) {
            for(JsonElement var19 : var2.getAsJsonArray()) {
               if (var19 != null && var19.isJsonPrimitive()) {
                  var16.add(var19.getAsString());
               }
            }
         }

         var11.IIIl(var16);
      } else if (var1 instanceof IlIIIlIlI var10) {
         if (var10.III() == null) {
            throw new IllegalArgumentException(lIlIII.Il(IllllI(1525019854, -763933142)));
         } else {
            Enum var15 = var10.lIl(var2.getAsString());
            if (var15 == null) {
               throw new IllegalArgumentException(lIlIII.Il(IllllI(1525019855, -1985120635)));
            } else {
               var10.I(var15);
            }
         }
      } else if (var1 instanceof lIlIlllI var9) {
         var9.ll(var2 != null && !var2.isJsonNull() ? var2.getAsString() : lIlIII.Il(""));
      } else if (!(var1 instanceof lIIIlll var3)) {
         if (var1 instanceof IIllIlIII var8) {
            var8.Il(this.lIlI(var2));
         } else if (var1 instanceof lllIIlIl var7) {
            if (var2 != null && var2.isJsonObject()) {
               var7.ll(this.llI(var2.getAsJsonObject()));
            } else {
               throw new IllegalArgumentException(lIlIII.Il(IllllI(1525019852, -269810464)));
            }
         } else {
            throw new IllegalArgumentException(lIlIII.Il(IllllI(1525019853, 1209885332)));
         }
      } else {
         ArrayList var4 = new ArrayList();
         if (var2 != null && var2.isJsonArray()) {
            for(JsonElement var6 : var2.getAsJsonArray()) {
               if (var6 != null && var6.isJsonPrimitive()) {
                  var4.add(var6.getAsString());
               }
            }
         } else if (var2 != null && var2.isJsonPrimitive()) {
            var3.II(var2);
            return;
         }

         var3.ll(var4);
      }
   }

   private String IlIIl(JsonObject var1, String var2) {
      String var3 = this.lIlII(var1, var2);
      if (var3 != null && !var3.isBlank()) {
         return var3;
      } else {
         String var4 = lIlIII.Il(IllllI(1525019710, 645081415));
         throw new IllegalArgumentException(var4 + var2);
      }
   }

   private Map<String, Object> IlIlI(boolean var1) {
      class_310 var2 = class_310.method_1551();
      if (var1 && var2 != null) {
         lIIlIII.l(var2, 0L);
      }

      int var3 = IlllIl(391473887, -152357360);
      int var4 = IlllIl(391473886, -2059269250);
      if (var2 != null && var2.method_22683() != null) {
         var3 = var2.method_22683().method_4486();
         var4 = var2.method_22683().method_4502();
      }

      ArrayList var5 = new ArrayList();

      for(llIlIIII var7 : this.I.IIl().llIlI()) {
         if (var2 != null && var2.method_22683() != null) {
            double var8 = var7.Il();
            double var10 = var7.Ill();
            double var12 = Math.max((double)0.0F, (double)var3 - var7.llll());
            double var14 = Math.max((double)0.0F, (double)var4 - var7.lIIl());
            double var16 = Math.max((double)0.0F, Math.min(var8, var12));
            double var18 = Math.max((double)0.0F, Math.min(var10, var14));
            if (var16 != var8 || var18 != var10) {
               var7.lIlI(var16, var18);
            }
         }

         var5.add(this.Il(var7));
      }

      <undefinedtype> var23 = lIIlIII.Il();
      LinkedHashMap var24 = new LinkedHashMap();
      var24.put(lIlIII.Il(IllllI(1525019711, 2058449082)), true);
      var24.put(lIlIII.Il(IllllI(1525019708, 1160708993)), var3);
      var24.put(lIlIII.Il(IllllI(1525019709, -2007684612)), var4);
      var24.put(lIlIII.Il(IllllI(1525019706, -58887974)), var23 != null);
      var24.put(lIlIII.Il(IllllI(1525019707, 1931103816)), var23 == null ? 0L : var23.l());
      String var10001 = lIlIII.Il(IllllI(1525019704, -1700500349));
      String var10002;
      if (var23 == null) {
         var10002 = null;
      } else {
         var10002 = lIlIII.Il(IllllI(1525019705, -730452002));
         long var21 = var23.l();
         String var20 = var10002;
         var10002 = var20 + var21;
      }

      var24.put(var10001, var10002);
      var24.put(lIlIII.Il(IllllI(1525019702, 1533552751)), var5);
      return var24;
   }

   private IIIIIIIlI IlIll(String var1) {
      if (var1 != null && !var1.isBlank()) {
         for(IIIIIIIlI var3 : this.I.IIl().IIIIlII()) {
            if (var3.IIlllII().equalsIgnoreCase(var1)) {
               return var3;
            }
         }

         String var4 = lIlIII.Il(IllllI(1525019700, -1172896066));
         throw new IllegalArgumentException(var4 + var1);
      } else {
         throw new IllegalArgumentException(lIlIII.Il(IllllI(1525019703, 1454983856)));
      }
   }

   Map<String, Object> lIIII() {
      return (Map)this.IIlIIl(() -> {
         LinkedHashMap var1 = new LinkedHashMap();
         ArrayList var2 = new ArrayList();

         for(lIllII var6 : lIllII.values()) {
            var2.add(this.IIllI(var6));
         }

         ArrayList var7 = new ArrayList();

         for(IIIIIIIlI var9 : this.I.IIl().IIIIlII()) {
            var7.add(this.IIIll(var9, true));
         }

         var1.put(lIlIII.Il(IllllI(1525019693, 65566992)), true);
         var1.put(lIlIII.Il(IllllI(1525019690, -1120596795)), var2);
         var1.put(lIlIII.Il(IllllI(1525019691, -1933305729)), var7);
         return var1;
      });
   }

   Map<String, Object> lIIlI(JsonObject var1) {
      return this.IlI(lIlIII.Il(IllllI(1525019692, -966909890)), () -> {
         String var2 = this.IlIIl(var1, lIlIII.Il(IllllI(1525019770, 1531207879)));
         if (var2 != null && var2.trim().length() > IlllIl(391473857, 935574007)) {
            throw new IllegalArgumentException(lIlIII.Il(IllllI(1525019771, -1315307335)));
         } else {
            String var3 = this.IIlIII(var2);
            if (!var3.isBlank() && var3.length() <= IlllIl(391473856, -1569378098)) {
               boolean var4 = this.l.lIIl(var3, this.I.IIl());
               if (!var4) {
                  throw new IllegalStateException(lIlIII.Il(IllllI(1525019769, -1267443878)));
               } else {
                  return this.IlIl();
               }
            } else {
               throw new IllegalArgumentException(lIlIII.Il(IllllI(1525019768, 1389968368)));
            }
         }
      });
   }

   IIIIIlllI(lIllIIl var1) {
      this.I = var1;
      this.l = new IIllIIIIl(var1.lI());
   }

   private String lIlII(JsonObject var1, String var2) {
      return var1 != null && var1.has(var2) && !var1.get(var2).isJsonNull() ? var1.get(var2).getAsString() : null;
   }

   Map<String, Object> lIlIl(boolean var1) {
      return (Map)this.IIlIIl(() -> this.IlIlI(var1));
   }

   private llIIIlII lIllI() {
      llIIIlII var1 = this.I.IIl().lIIlIl();
      if (var1 == null) {
         throw new IllegalStateException(lIlIII.Il(IllllI(1525019688, 1850946482)));
      } else {
         return var1;
      }
   }

   Map<String, Object> lIlll() {
      return (Map)this.IIlIIl(() -> {
         this.I.lll();
         return this.lll(lIlIII.Il(IllllI(1525019755, 1887663412)), true);
      });
   }

   Map<String, Object> llIII(JsonObject var1) {
      return this.IlI(lIlIII.Il(IllllI(1525019689, 1309306396)), () -> {
         IIIIIIIlI var2 = this.IlIll(this.IlIIl(var1, lIlIII.Il(IllllI(1525019658, 1147152820))));
         if (!var2.IIlIlIl()) {
            throw new IllegalArgumentException(lIlIII.Il(IllllI(1525019659, -604295725)));
         } else {
            if (var1.has(lIlIII.Il(IllllI(1525019656, 1703683311)))) {
               var2.IIIllIl(var1.get(lIlIII.Il(IllllI(1525019657, 821525125))).getAsBoolean());
            } else {
               var2.IIIlllI();
            }

            this.I.lll();
            return this.lll(lIlIII.Il(IllllI(1525019654, 549812743)), this.IIIll(var2, true));
         }
      });
   }

   private Map<String, Object> llIIl(Color var1) {
      LinkedHashMap var2 = new LinkedHashMap();
      Color var3 = var1 == null ? new Color(IlllIl(391473885, 75769611), IlllIl(391473884, 302941850), IlllIl(391473859, 1467798386), IlllIl(391473858, -1120850138)) : var1;
      var2.put(lIlIII.Il(IllllI(1525019686, -1066592750)), var3.getRed());
      var2.put(lIlIII.Il(IllllI(1525019687, -205516113)), var3.getGreen());
      var2.put(lIlIII.Il(IllllI(1525019684, 1778874021)), var3.getBlue());
      var2.put(lIlIII.Il(IllllI(1525019685, -1432666516)), var3.getAlpha());
      var2.put(lIlIII.Il(IllllI(1525019682, -603907649)), String.format(lIlIII.Il(IllllI(1525019683, 1942164326)), var3.getRed(), var3.getGreen(), var3.getBlue()));
      return var2;
   }

   private Path llIlI(String var1) {
      try {
         this.I.lll();
         Path var2 = this.I.lI().IIlll(var1 != null && !var1.isBlank() ? var1 : lIlIII.Il(IllllI(1525019680, 1658719144)));
         this.II = true;
         return var2;
      } catch (Exception var5) {
         String var10002 = lIlIII.Il(IllllI(1525019681, -16752528));
         String var4 = var5.getMessage();
         String var3 = var10002;
         throw new IllegalStateException(var3 + var4, var5);
      }
   }

   private String lllII(llllllI<?> var1) {
      if (var1 instanceof lIIIIl) {
         return lIlIII.Il(IllllI(1525019676, -456054914));
      } else if (var1 instanceof IIIllIIII) {
         return lIlIII.Il(IllllI(1525019677, 1222868041));
      } else if (var1 instanceof llllIlIl) {
         return lIlIII.Il(IllllI(1525019674, -1481494501));
      } else if (var1 instanceof IlIIIlIlI) {
         return lIlIII.Il(IllllI(1525019675, 1273965466));
      } else if (var1 instanceof IIIIllIII) {
         return lIlIII.Il(IllllI(1525019672, 263347262));
      } else if (var1 instanceof lllIIlIl) {
         return lIlIII.Il(IllllI(1525019673, -1174197145));
      } else if (var1 instanceof IIllIlIII) {
         return lIlIII.Il(IllllI(1525019670, -653587226));
      } else if (var1 instanceof lIlIlllI) {
         return lIlIII.Il(IllllI(1525019671, -91405822));
      } else if (var1 instanceof lIIIlll) {
         return lIlIII.Il(IllllI(1525019668, 1865305527));
      } else {
         return var1 instanceof IlIIIIllI ? lIlIII.Il(IllllI(1525019669, 1188498167)) : lIlIII.Il(IllllI(1525019666, 1484222615));
      }
   }

   Map<String, Object> lllIl(JsonObject var1) {
      return this.IlI(lIlIII.Il(IllllI(1525019667, 1267038446)), () -> {
         IIIIIIIlI var2 = this.IlIll(this.IlIIl(var1, lIlIII.Il(IllllI(1525019894, -179936299))));
         llllllI var3 = this.l(var2, this.IlIIl(var1, lIlIII.Il(IllllI(1525019895, -930334260))));
         this.IIlll(var3, var1.get(lIlIII.Il(IllllI(1525019892, -654550545))));
         this.I.lll();
         return this.lll(lIlIII.Il(IllllI(1525019893, 67051749)), this.lIII(var3));
      });
   }

   private static String llllI(lIllII var0) {
      String var10000;
      switch (null.I[var0.ordinal()]) {
         case 1 -> var10000 = lIlIII.Il(IllllI(1525019664, 315830944));
         case 2 -> var10000 = lIlIII.Il(IllllI(1525019665, -1671940441));
         case 3 -> var10000 = lIlIII.Il(IllllI(1525019662, -1211728076));
         case 4 -> var10000 = lIlIII.Il(IllllI(1525019663, -1910629048));
         case 5 -> var10000 = lIlIII.Il(IllllI(1525019660, 1120868313));
         case 6 -> var10000 = lIlIII.Il(IllllI(1525019661, 323756921));
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   private String lllll(String var1) {
      String var2 = var1.toLowerCase(Locale.ROOT);
      String var10000 = var2.substring(0, 1).toUpperCase(Locale.ROOT);
      String var4 = var2.substring(1);
      String var3 = var10000;
      return var3 + var4;
   }

   Map<String, Object> IIIIII(JsonObject var1) {
      return (Map)this.IIlIIl(() -> this.lIllI().lIIlI(this.IlIIl(var1, lIlIII.Il(IllllI(1525019761, -1055845801)))));
   }

   private List<Map<String, Object>> IIIIlI(IlIIIlIlI<?> var1) {
      ArrayList var2 = new ArrayList();
      Enum var3 = (Enum)var1.III();
      Enum[] var4 = var3 == null ? new Enum[0] : (Enum[])var3.getDeclaringClass().getEnumConstants();
      if (var4 == null) {
         return var2;
      } else {
         for(Enum var8 : var4) {
            if (var8 instanceof llIlllI) {
               llIlllI var9 = (llIlllI)var8;
               if (!var9.I()) {
                  continue;
               }
            }

            LinkedHashMap var10 = new LinkedHashMap();
            var10.put(lIlIII.Il(IllllI(1525019655, -1911868510)), var1.IlI(var8));
            var10.put(lIlIII.Il(IllllI(1525019652, 557714776)), var8.toString());
            var2.add(var10);
         }

         return var2;
      }
   }

   private double IIIlII(JsonObject var1, String var2, double var3) {
      return var1 != null && var1.has(var2) && !var1.get(var2).isJsonNull() ? var1.get(var2).getAsDouble() : var3;
   }

   Map<String, Object> IIIlIl(JsonObject var1) {
      return (Map)this.IIlIIl(() -> this.lIllI().IIll(this.IlIIl(var1, lIlIII.Il(IllllI(1525019695, -693475869)))));
   }

   private String IIlIII(String var1) {
      if (var1 == null) {
         return lIlIII.Il("");
      } else {
         String var2 = var1.replaceAll(lIlIII.Il(IllllI(1525019766, 1560556397)), lIlIII.Il("")).trim();
         if (var2.length() > IlllIl(391473863, -686530350)) {
            var2 = var2.substring(0, IlllIl(391473862, -1196600929));
         }

         return var2;
      }
   }

   private <T> T IIlIIl(Supplier<T> var1) {
      class_310 var2 = class_310.method_1551();
      if (var2 == null) {
         return (T)var1.get();
      } else if (var2.method_18854()) {
         return (T)var1.get();
      } else {
         CompletableFuture var3 = new CompletableFuture();
         var2.execute(() -> {
            try {
               var3.complete(var1.get());
            } catch (Throwable var3x) {
               var3.completeExceptionally(var3x);
            }

         });

         try {
            return (T)var3.get(3L, TimeUnit.SECONDS);
         } catch (Exception var5) {
            throw new IllegalStateException(var5.getMessage(), var5);
         }
      }
   }

   Map<String, Object> IIlIlI() {
      return (Map)this.IIlIIl(() -> {
         LinkedHashMap var1 = new LinkedHashMap();
         lIIlllll var2 = this.I.IIl().IIlIIl();
         var1.put(lIlIII.Il(IllllI(1525019850, -1652611039)), true);
         var1.put(lIlIII.Il(IllllI(1525019851, -266249971)), (Object)null);
         var1.put(lIlIII.Il(IllllI(1525019848, 2076778860)), List.of());
         var1.put(lIlIII.Il(IllllI(1525019849, -1471406611)), (Object)null);
         var1.put(lIlIII.Il(IllllI(1525019846, 1597051497)), Map.of(lIlIII.Il(IllllI(1525019847, -798332589)), false, lIlIII.Il(IllllI(1525019844, 1029853492)), 0, lIlIII.Il(IllllI(1525019845, 1543722849)), lIlIII.Il(IllllI(1525019842, 2019309155)), lIlIII.Il(IllllI(1525019843, -745908330)), ""));
         var1.put(lIlIII.Il(IllllI(1525019840, -717407392)), var2 == null ? Map.of(lIlIII.Il(IllllI(1525019841, -1476916325)), false) : var2.llII());
         return var1;
      });
   }

   Map<String, Object> IIlIll(JsonObject var1) {
      return this.IlI(lIlIII.Il(IllllI(1525019767, -790465099)), () -> {
         IIIIIIIlI var2 = this.IlIll(this.IlIIl(var1, lIlIII.Il(IllllI(1525019809, 1766727164))));
         class_3675.class_306 var3 = this.llI(var1);
         String var4 = this.lIlII(var1, lIlIII.Il(IllllI(1525019806, -724491255)));
         if (var4 != null && !var4.isBlank()) {
            llllllI var5 = this.l(var2, var4);
            if (var5 instanceof lllIIlIl) {
               lllIIlIl var6 = (lllIIlIl)var5;
               var6.ll(var3);
               this.I.lll();
               return this.lll(lIlIII.Il(IllllI(1525019805, -553878393)), this.lIII(var5));
            } else {
               throw new IllegalArgumentException(lIlIII.Il(IllllI(1525019804, 910253466)));
            }
         } else {
            var2.IIlIlll(var3);
            this.I.lll();
            return this.lll(lIlIII.Il(IllllI(1525019807, 1365010481)), this.IIIll(var2, true));
         }
      });
   }

   private llIlIIII IIllIl(String var1) {
      for(llIlIIII var3 : this.I.IIl().llIlI()) {
         if (var3 instanceof IIIIIIIlI var4) {
            if (var4.IIlllII().equalsIgnoreCase(var1)) {
               return var3;
            }
         }
      }

      String var5 = lIlIII.Il(IllllI(1525019764, 8655927));
      throw new IllegalArgumentException(var5 + var1);
   }

   Map<String, Object> IIllll(JsonObject var1) {
      return this.IlI(lIlIII.Il(IllllI(1525019760, 1643518674)), () -> {
         String var2 = this.IIlIII(this.IlIIl(var1, lIlIII.Il(IllllI(1525019772, -1925367861))));
         boolean var3 = this.l.Illl(var2);
         if (!var3) {
            throw new IllegalStateException(lIlIII.Il(IllllI(1525019773, 481173818)));
         } else {
            return this.IlIl();
         }
      });
   }

   Map<String, Object> IlIIII() {
      return (Map)this.IIlIIl(() -> {
         try {
            this.I.lll();
            this.I.lI().IIlll(lIlIII.Il(IllllI(1525019678, -805877340)));
            Path var1 = this.I.lI().lll(this.I.IIl());
            this.I.lll();
            this.II = true;
            return this.lll(lIlIII.Il(IllllI(1525019679, 2113341017)), var1.toString());
         } catch (Exception var2) {
            throw new IllegalStateException(var2.getMessage(), var2);
         }
      });
   }

   Map<String, Object> IlIIlI() {
      LinkedHashMap var1 = new LinkedHashMap();
      var1.put(lIlIII.Il(IllllI(1525019758, -509799808)), false);
      var1.put(lIlIII.Il(IllllI(1525019759, 1431390825)), lIlIII.Il(IllllI(1525019756, 1360946744)));
      return var1;
   }

   private List<Map<String, Object>> IlIlII(IIIIllIII var1) {
      ArrayList var2 = new ArrayList();

      for(<undefinedtype> var4 : var1.lIl()) {
         LinkedHashMap var5 = new LinkedHashMap();
         var5.put(lIlIII.Il(IllllI(1525019757, -1858843667)), var4.ll());
         var5.put(lIlIII.Il(IllllI(1525019754, 1782151970)), var4.IlI());
         var2.add(var5);
      }

      return var2;
   }

   private Map<String, Object> IlIllI(lIIIllll var1) {
      LinkedHashMap var2 = new LinkedHashMap();
      <undefinedtype> var3 = var1.lIlll();
      var2.put(lIlIII.Il(IllllI(1525019752, 1779654730)), var3 == null ? lIlIII.Il(IllllI(1525019753, -1485475607)) : IlllII(var3));
      var2.put(lIlIII.Il(IllllI(1525019750, -1924890846)), var3 == null ? lIlIII.Il(IllllI(1525019751, -1617019367)) : var3.toString());
      var2.put(lIlIII.Il(IllllI(1525019748, 1439446275)), this.llIIl(var1.IIllII()));
      var2.put(lIlIII.Il(IllllI(1525019749, 1265243724)), this.llIIl(var1.IIIllI()));
      var2.put(lIlIII.Il(IllllI(1525019746, -1971885983)), this.llIIl(var1.IlIII()));
      var2.put(lIlIII.Il(IllllI(1525019747, -190947085)), this.llIIl(var1.llIII()));
      var2.put(lIlIII.Il(IllllI(1525019744, 1564415056)), this.llIIl(var1.IIIIIl()));
      var2.put(lIlIII.Il(IllllI(1525019745, 372900840)), this.llIIl(var1.IIlIII()));
      var2.put(lIlIII.Il(IllllI(1525019742, 173678820)), this.llIIl(var1.llllI()));
      var2.put(lIlIII.Il(IllllI(1525019743, -490702612)), this.llIIl(var1.IIlII()));
      return var2;
   }

   Map<String, Object> IlIlll() {
      return (Map)this.IIlIIl(this::IlIl);
   }

   private Map<String, Object> IllIIl(class_3675.class_306 var1) {
      LinkedHashMap var2 = new LinkedHashMap();
      boolean var3 = IllllIlI.IllllI(var1);
      var2.put(lIlIII.Il(IllllI(1525019741, -106747477)), var3);
      var2.put(lIlIII.Il(IllllI(1525019738, 737818801)), var3 ? "" : IllllIlI.IIIlIl(var1));
      var2.put(lIlIII.Il(IllllI(1525019739, 1108959699)), var3 ? lIlIII.Il(IllllI(1525019736, -214353351)) : (var1.method_1442() == class_307.field_1672 ? lIlIII.Il(IllllI(1525019737, -1416593715)) : lIlIII.Il(IllllI(1525019734, 500565906))));
      var2.put(lIlIII.Il(IllllI(1525019735, -1388681873)), var3 ? -1 : var1.method_1444());
      return var2;
   }

   private static int IllIll(int var0) {
      return Math.max(0, Math.min(IlllIl(391473861, 2030678347), var0));
   }

   private static String IlllII(Enum<?> var0) {
      return var0 == null ? "" : (new StringBuilder(4)).append((char)IlllIl(391473860, -304123034)).append(Integer.toString(var0.ordinal(), IlllIl(391473867, -1532133003))).toString();
   }

   private static int IlllIl(int var0, int var1) {
      return Il[var0 ^ 391473875] ^ var1 ^ var0;
   }

   static {
      short var6 = 2866;
      String var7 = "ⳔⰫⰺⰋⰟⳲⳲⰗ\ue3bd\ue378\ue353\ue36f\ue376\ue398\ue3f3\ue37e㳷㰺㱦㰢㰣㳠㲶㱋㱥㳓㰚㲐㳦㲔㱏㲆㱗㳮㰥㲠൹\u0db2ද\u0d84ඪ൸ദෘ\u0de3ആඒഘ൮ജ\u0dc7എෟ൦තന\u0dbfඓු\u0df5ᥞᦋᦒᦊᦑ\u197bᤓ᧳\ud891\ud854\ud87f\ud843\ud85a\ud8b4\ud8df\ud852◊╱┥┏─◮◥╬╆□┒◌䉜䊋䊖䊍䊖䉁䈓䋳䋔䈒䋯䉙\ue558\ue59b\ue592\ue58f\ue595\ue551\ue513\ue5f3\ue5d7\ue501\ue5e4\ue506\ue557\ue52d\ue5b7\ue544섃쇖쇏쇗쇌섦셎솮㕹㖼㖗㖫㖲㕜㔷㖺⌫⎐⏄⏮⏡⌏⌄⎍⎧⍀⏳⌭욚왍왐왋왐욇웕옵옒월옩욟吧哤哭哰哪吮呬和咨呾咛呹吨呒哈吻怇惂悉悴濥漰潫潖\ue3e8\ue354\ue367\ue33a\ue321\ue3db\ue3b0\ue32dꫩꨫꨐꨏꨥꫡꪳ꩔툠틞틟틷틬툡퉎튌튵퉽틘퉈툯퉷튿퉓튜툧튾퉒틨틫튲틬퉠튍툪툑귵괧괋굊\uedd7\ued29\ued28\ued00\ued1b\uedd6\uedb9\ued7b\ued42\ued89\ued71\ued8e\uedda\uedae\ued7a\ueda2\ued6f\uedee\ued4d\ued9b\ued46\ued59\ued73\ued1d\ued97\ued6d\ued88\ued8e\ued46\ueda4\uedfb\ued3b\uedd6\ued31\ued17\ued32霥韚韩韡鞰霐靎鞂鞡靀韢靌霫霳鞅靡鞜霧韡霍\uef54\uefeb\uefd8\uefb5\uef9a\uef5e\uef1c\ueffc\uefdc\uef1e\uef9e\uef3c\uef59\uef29\ueff5\uef3a⚷♈♻♳☢⚂⛜☐☳⛒♰⛞⚹⚡☗⛳☎⚵♳⚟f´©¡®GKõî=\u0094\bꗬꔬꕣꔪꔡꗌꗌꔩ譪译讧访讠譍譍讨\ud8d1\ud802\ud81f\ud834\ud81a\ud8c8\ud896\ud868\ud853\ud8bd\ud866\ud8d0솥셚셩셁셮솃솃셦涧浲浫浠浫涨淋浤뺧븝븧븟퍯펺펣펻펠퍊팢폂滵湊渎渴渿滅溩湔湺溊湁滷\ueb7d\ueba8\uebb1\ueba9\uebb2\ueb58\ueb30\uebd0豽賚貞貤貯豕谹賄質豜貕谿豪豻貍谟賛豘購谐貮賣賝販谣賲调谏賹谕谸貍擘摧搣搙搒擨撄摹摗撧摬據쮵쭊쭛쭪쭾쮓쮓쭶ʹɼɗɫɲʜ˷ɺ向哄哝哅哞吴呜咼ᱲᲷ\u1cfc᳁єҁӚӧ릔륗륳륶륚릎마뤍뤛맍뤥릖⤣⧷⧡⧡⧬⤡⥎⦛꾗꽨꽹꽈꽜꾱꾱꽔늳뉳눼뉵뉾늓늓뉶\udbb6\udb4f\udb39\udb7d\udb7a\udb95\udbdf\udb2c\udb3a\udbec\udb01\udbb7饯首馇馵馦饌餅馪谚賝賦賎賐谾豻貄貖豖賥豵谗豳貼豜쥲즋즚즨즻쥑줘즷⣝⠚⠡⠉⠗⣹⢼⡃⡑⢑⠢⢲⣐⢴⡻⢛鄋釞醂釯鱛鲎鲵鲓᧟ᥡᤠᤍᤖ᧬᧼ᤙ埐圃圞圷圙埠埰圕諄訑詍訠慵憠憛憽뙺뚿뛳뚥뚰뙜뙐뚲뛱똥뚿뙽\u128eቋሇቑቄከኤቆሇዒቓ\u1289늬눒뉓뉾뉥늟늏뉪笸篫篶篟篱笈笘篽뗕땮딿딑딟뗰떔땱땘떯땤뗒赝跦趷趙趗赸贜跹跐货跬赚깄꺺껌꺡꺎깳깣꺆誐訫詝詍詜誑諹詒قړڿڒڈ٣رچ⹌⺭⺳⺉⺂\u2e78⸌⻩\u2ef7⸂⻳⸡⹄⸵⻔⹗汷沚泷泊㏀㌺㍇㍺턴퇝톰톍獣玼珧珚櫍橫樖樫跿贁贀质贳跾趑赓赪趡贡趇跷趒赠趌赃跸赡趍贷贴赭贳趿赒践跎佷侢侻侣侸佒伺俚犸爇牃特牲犈狤爙爷狇爌犺拋戲戣我戂拨抡戎맋르뤰뤊뤁맻릗륪륄릴륿막ꫜꨜꨉꨊꨗ\uaafcꪺꩡⅠ⇛↭↾↩ⅾℒ⇛\ue3c5\ue310\ue309\ue303\ue30e\ue3e0\ue38c\ue368\ue341\ue3af\ue32e\ue3c2㣋㠱㠰㠪㠅㣻㢭㡶춽쵼쵄쵮㕾㖬㖱㖽㖲㕟㔖㗕㗰㔦㗞㔐队雋雝雝雐阝陲隧殰權欰欈匠叵召叴可包卭厍\ue655\ue6aa\ue6bb\ue68a\ue69e\ue673\ue673\ue696騘髝髶髊髓騽驖髛㞣㝤㜨㝬㝭㞔㟬㜈㜮㟸㝦㟌㞮㟙㜚㞻⿻⼼⽰⼴⼵⿌⾴⽐⽶⾧⼄⾔⿶⾒⽝⾽\uf080\uf03b\uf06f\uf045\uf04a\uf0a4\uf0af\uf026\uf00c\uf0eb\uf058\uf086䇕䄒䄩䄚䄟䇗䆸䅌䅚䆛䄲䆈䇘䇀䅆䇍櫏樘樅樞樅櫒檀橠橇檁橼櫊뒞둝둔둉둓뒗듕됵됑듇됢듀뒑듫둱뒂ᶐᴭᵩᵜᵇᶈ᷎ᴳᴝᷛᴦᶐ쳔챮찫찘찚쳠첔챊챐첚챫첵쳜청챌쳏꧐꤂ꤟꤑꤜ꧲ꦨꥭ꥓ꦭꥭꦢ꧕ꦼꤲꦓꥥꧬꥌꦉꤝꤼꤾꥅ忻彁弄強張忏徻彥彿徵彄徚忳徂彣忠\udc1a\udce4\udcd7\udccf\udcd5\udc38\udc68\udc80\udc9f\udc47\udcaa\udc1c㼻㿹㿒㿱㿨㼳㽟㾆㾲㽳㿧㽜㼵㼪㾟㼦\ueaff\uea3e\uea06\uea2c陝離隦障隗陭阁雼雒阢雬陟\uf682\uf67c\uf67d\uf655\uf64e\uf683\uf6ec\uf62e\uf617\uf6df\uf676\uf6ff\uf68c\uf694\uf63b\uf6f5\uf638\uf6cf\uf61b\uf6c2\uf64f\uf60c\uf600\uf669\uf6c2\uf67c\uf681\uf6c0핥햜햍햿햬핆픏햠冰儓入兮兤农冂儏儭凌兪凗冷凁儧凛儛凥優凱兠內儔元凭儒凒凂儰凜冲兇葛蒥蒤蒌蒗葚萵蓷蓎萅蓤萵葟萲蓔萪蓡葵蒔萀蒐蒪蒼蒽萞蓦葑葪ᴟᷠᷱ᷀ᷔᴹᴹᷜ\udaf8\uda3d\uda16\uda2a\uda33\udadd\udab6\uda3b⺐⹂⹋\u2e70⹚⺇⺱⹔쩗쪰쫤쫇쫆쨅쩩쪰쪞쩿쪴쩵쨀쨝쪮쩣쪸쨵쪉쩖쫆쪄쪯쫷쩋쪏쩱쩉쪞쩸쨁쫷쨁쫭쫃쫮쫿쨖쩕쪱쪿쩎쫴쩻쨫쩟쪤쩹쪷쨓쪩쩚쫭쫪쪟쫭쩶쪗쩽쩌쪼쩙쨣쪃ᮖᬫᬡᬯᬀᯋᯭᬈ햖해핥핯핀햄헧픭픆헾핪헵햎헣픅헴픲햴픢헓핆픅픲핦헅픙행헥픘헐햦핑햊핣해한핫햩햿픐핤햲핦헝헷헯픈헣픲헏픨헔釁鄣鄲鄸鄗釓醰酺酑醩鄽醢釙醴酒醣酥釣酵醄鄑酒酥鄱醒酎釞醲酏醇釱鄆針鄴鄣鄋鄼釾釨酇鄳釥鄱醊醠醸酟醴酥醘酿醃汉沆沛沔沞汲氤注泙氏沶氭江氫況民泽氟泜氠沙沍泮沝氒没氒氿泃氡汶沨汔治沊沚沲汶氦泾沿氱沪氍㞓㝜㝁㝎㝄㞨㟾㜲㜃㟕㝬㟷㞅㟱㜛㟋㜧㟅㜆㟺㝃㝗㜴㝇㟈㝻㟈㟥㜙㟻㞬㝲㞎㝡㝐㝀㝨㞬㟼㜤㝥㟫㝰㟗凐兵儱億儇凐冖八充冄儺冶凅冧兯冱兲冃兔冔兜儚兪儲冋兝冒冓兜冀凵儘凍儁充儍儾减冶兕儡冶兵冔凯凜兘冮\uf627\uf6ec\uf6f1\uf6f4\uf6f6\uf61f\uf64e\uf68f\uf6bd\uf643\uf683\uf647\uf630\uf641\uf69e\uf644\uf68b\uf602\uf6a2\uf667\uf6f0\uf6f3\uf6aa\uf6f7\uf67a\uf6cb\uf678\uf67a\uf6ac\uf64b\uf614\uf6d7⍊⏰⏊⏲丕仁仄仐仁丱乧亯亟乮亥专엽씩씬씸씩엙얏앇앷얋씳얟엵얩씕엦ᙸᚬᚩᚽᚬᙜᘊᛂᛲᘎᚶᘚᙰᙬᛁᘏᛂᘵᛙᙑ\ue105\ue1d1\ue1d4\ue1c0\ue1d1\ue121\ue177\ue1bf\ue18f\ue170\ue1f1\ue178\ue10b\ue113\ue1b8\ue16f\ue1bd\ue102\ue1b9\ue15f湚溿溡溻溒湀渆滻滕渥滮湘荒莑莵莰莜荗茸菺菚茭菣荐\ue236\ue2e3\ue2c8\ue2fb\ue2fa\ue239\ue245\ue299\ue2bc\ue26a\ue287\ue231왶욼욓욵욢왏왏욪涺洄浕浣海涙淔洧欏殲毪毺毂欮正殾殌歇殶歧欁歰殖歌殳欞殒欠\u19ccᤛ\u193fᤞᤇ᧨ᦀᥤ᥄ᦨᤂᦤ類颓飏颋颊顉頟飢飌顺颽顁쒄쐾쐄쐼\ufb1cﯥﮓ\ufbcdﯕ\ufb1aﭭ﮽ﮗﭰﯿקּﬖﭢ﮺ﭳﮢ\ufb18ﯞגּ㙦㚟㛩㚷㚯㙠㘗㛇㛭㘊㚅㙵㙩㘘㛮㘢㛘㘭㛺㙈䉍䊎䊪䊟䊇䉗䈑䋥䋆䈿䋶䈰䉆䈰䋆䈹䋶䉉䋹䈎䊅䊅䊡䋚촪췩췍췸췠촰쵶춂춡쵘춈쵂촥쵄춏쵅춝촾춴쵛췹춡춌춽⒔\u2457⑳⑆\u245e⒎Ⓢ\u243c␟ⓥ⑰⓭⒞⓲⑸⒋樞櫹檭檃檉橢樂櫛櫍樜檥樠橉樨檦樇櫾橒櫈樴檊檝櫶檩樂櫸樁樉櫓樭樟櫊\ue55f\ue588\ue58d\ue58a\ue590\ue578\ue53e\ue5f9\ue5d3\ue511\ue5e9\ue55a\ue894\ue859\ue805\ue841\ue840\ue883\ue8d5\ue828\ue806\ue8b0\ue879\ue8d7\ue883\ue89b\ue82c\ue8e6\ue837\ue8c0\ue82c\ue8a4мӷӪӁӯнѣҝҦуӗѹЭе҂шҙѮҺѲұӿӋҰｷﾈﾙﾨﾼｑｑﾴ乻亮亷亯亴乞丶他\ud92b\ud994\ud9d0\ud9ea\ud9e1\ud91b\ud977\ud98a\ud9a4\ud954\ud99f\ud929퍁폦펢페펓퍩팅폸폖퍠펩팃퍖퍇펱팣폧퍤폀팬펒폓폪펦팜폍퍒팟폅팩팈펻꜆ꞹꟽꟇ\ua7ccꜶꝚꞧ꞉ꝹꞲ꜄\ua9ceꥵꤟ꤮꤇꧀ꦞꥆꥁꦐꤔ꧄꧃ꦷ\ua95dꦌ檺橨橄樅穈窶窷窟窄穉稦竤竝稕窼稵穆穞竱稿竲稅竑稈窃窩竰窥稊竓穂穹뿿뽅뽿뽇ģƘǌǦǩćČƅƯŇǹŋĨŷǋĸビ〆〟〇〜ヶゞまぞォぢピ퉛튑튌튂튏퉡툻틾틀툾틾툱퉚툭튩툯틽퉂틹툳튍튑틦튾툅틕툿툭틔툱퉟튪툙튼튻튌튥퉡툭틞튫퉽튡툤퉧툰틹툇틹툀틉툇\uf22c\uf2d2\uf2d3\uf2fb\uf2e0\uf22d\uf242\uf280\uf2b9\uf272\uf2e6\uf24e\uf224\uf246\uf289\uf25c\uf294\uf228\uf2e3\uf273\uf2e6\uf2cd\uf2d2\uf2d6\uf26c\uf2ac\uf270\uf21d籏粢糏糲俥伟佢佟혡훈횥횘ᚽᙢᘹᘄ怡惣惘惮쾺콒켙켤켸쿺쾺콉콹쾬콞쾨쿽쾥켈쾏콐쿦켠쿌\udef9\ude2c\ude17\ude1d\ude36\udedc\ude8a\ude65䌾䎝䏫䏠䏪䌒䌌䎁䎣䍂䏤䍙䌹䍏䎋䍌䎞䌦䎒䍹䏪䎤䎚䎻䍦䎦䍄䍋䎾䍶䌨䏣䌽䏃䏶䏆䏖䌑䍆䎀䎂䌞䎜䍞䍛䍄䏎䌽珑猯献猆猝珐玿獽獄玌猩玹珞玆獎玻獩珖獭玎猛猳獵猭쇕섯섮석섟쇥솑셨셚솏섻쇗壷堉堺堑堻壃墕塟塲墜塇壱\uf4c4\uf424\uf43a\uf41b\uf40c\uf4db\uf4a7\uf47cᮐ᭪᭻᭱᭞ᮚ\u1bf9᭖\uf7ca\uf71d\uf700\uf70f\uf705\uf7ee\uf7ee\uf70b뎕덃덫덉덚뎠돌댮댟돊덚돼뎛뎃댲뎏أڞۚۯ۬ػٽڀڮ٨ڕأ攭斖无旰旡攬敄旯䚬䙯䙔䙢䙥䚜䚌䙩팏폌폷폁폆팸퍀펕펂퍕펮퍷\ufaf1逸館勤墨𥉉缾穀\ue456\ue485\ue498\ue4b3\ue49d\ue44f\ue411\ue4ef\ue4d4\ue43a\ue4e1\ue457\uf7a3\uf75d\uf75c\uf774\uf76f\uf7a2\uf7cd\uf70f\uf736\uf7fe\uf705\uf7cb\uf7a7\uf7c9\uf702\uf7d4\uf719\uf7b3\uf708\uf7e3\uf76b\uf72c\uf71f\uf75c\uf7e2\uf730\uf7f3\uf7cc껩긱긤긧긺껑꺗까\u2066\u20c5₳₠₷\u2060\u200c\u20c5௹\u0b34ଭଧପ\u0bc4நୌ\u0b65\u0b8bଊ௦㈤㋆㋇㋝㋲㈌㉚㊁ﻷ︮︖︼꽴꾾꾣꾯꾠꽍꼄꿇꿢꼴꿌꼂绛縎縗縏縔绾纖繶\ue158\ue195\ue18c\ue194\ue18f\ue165\ue10d\ue1ed\ue1d9\ue10f\ue19b\ue13f\ue15e\ue128\ue1d2\ue130\ue1fd\ue100\ue1e9\ue11e\ue18b\ue1a0\ue1bf\ue1bb\ue101\ue1c1\ue11d\ue114\ue1d7\ue10f\ue15b\ue1ae張忢忿忤忿弨彺徚徽彻徆弰\u0a4eઙ\u0a84ટ\u0a84\u0a53ਁૡ\u0ac6\u0a00૽ੋ\u1a7e᪫᪲᪪᪱ᩛᨳ\u1ad3뒰둏둞둯둻뒖뒖둳ᮅᭀ᭫᭗\u1b4eᮠᯋᭆ吐哯哾哏哛吶吶哓缱翴翟翣翺缔罿翲硾磅碑碻碴硚硑磘磲砕碦硸柫杖朒朧朼柳枵杈杦枠杝柫熮焔焮焖Ȭʗ˽ˌ˥Ȣɼʤʣɲ˶Ȧȡɕʿɮ㜁㟔㟍㟕㟎㜤㝌㞬㞌㝻㞰㜆랇띸띩띘띌랡랡띄☍⚮⛘⛓⛙☡☿⚲⚐♱⛗♪☊♼⚴♐⚯♘⚏♊⛙⚗⚩⛾♐⚯♯♿⚍♡☏⛺懾愁愐愡愵懘懘愽謹讚诬评诫謿譹讏讹譯诧譍謯識讛譝讞講讕譤诫诐讑诎議计譽譯讷譿謙诎謧讟诲诫诅謂謔讏词譝讇譑謁譔讑譎讒謐讏譱桻梶棪梮梯桬栺棇棩桟梖树桩栱棵栢棛桢梵栔棰梩棖梚栢棲栾桓軗蹴踂踉踃軻軥蹨蹊身踍躰軐躥蹢躰蹳軟蹖躾踄踛蹫踃躍蹵躭躕蹚躰躟蹇柌杶朇朜杙柩枚會杛枑朡枽某枎杂枲杸柵朙枳束权李杝\uea28\uead6\uead7\ueaff\ueae4\uea29\uea46\uea84\ueabd\uea76\ueac0\uea40\uea21\uea51\ueacc\uea5f\uea92\uea38\ueab5\uea68\ueae0\ueaa7\uea94\uead7\uea69\ueabb\uea78\uea47㩐㪛㪆㪭㪃㩑㨏㫱㫊㨯㪻㩛㩓㨎㫩㨳㫷㩏㪘㨹㪅㫁㪨㪀㨉㫈㨢㨙်ჄჅჭჶျၔ႖Ⴏၧ\u10ce၇ဴာႃ၍ႀၷႣၺჰჱႊჂၸႱူဋ焽燂燓燢燶焛焛燾ꡫ\ua8c8ꢾꢵꢿꡇꡙ꣔ꣶꠗꢱꠌꡬꠚ꣨ꠂ\ua8ccꡳ꣮ꠂꢸꢧ꣗ꢿ꠱\ua8c9ꠑ꠩꣦ꠌꠣꣻ嬽寃寂寪寱嬼孓宑宨孠寉孀嬳嬫宄孊宇孰室孽寱寶寚寊孿宮孭孒聆異漏羅\ud93b\ud981\ud9bb\ud983淵洡洕洵洺混涟洴榠楇楖楼楲榞榚椕椡槱椟槠榴槀椔槌椉概椣榞椫楲楚楁槹椹槏槗椯槍榙楔槥楀楃楘楍榤榌椔楖榀楁槕槄槟植槅椄榋椩槪楟楘椢楃榝楃榺槾楉槻槢椵榸楽椱楥楲榵榖椯椁槣楍槗榶槀椪槇椃榀椤槈楶楈楟楂槻椹槛槾椯槍榝楝榿楐楺楛楆榷榐椥楔榌椂槏榛槜椤槼椎榅極槈ꦑꥮ\ua97fꥎ\ua95aꦷꦷꥒ劜剙割剎剗効勒剟䠣䢜䣈䣠䣭䠃䠍䣥劳刍剌剽剻劃勚創鿉齩鼮鼻鼇鿣龑鼘뗡딤딏딳딪뗄떯딢ꜢꞀꟅꟶꟴ꜎ꝺꞤ浨涼涵涴涢浌洖淓珎獴猱猂猀珺玎獐獰玐獨玠珆玷獝玦닓눇눎눏눙닷늭뉨뉏늸뉣닕찺쳮쳧쳦쳰찞채첁첾챎쳸챓찾챘쳒찡斟敟整敾救斿旔教\u2e9a⹚\u2e71\u2e7b⹔⺺⻒⸛⸖⻃⸥⻆㋾㈀㈑㈢㈵㋰㋑㉇㉻㊅㈞㊟㋶㊜㈖㋥\uda67\udadf\udab5\udab6\udaa9\uda65\uda11\udaa6金鄯鄾鄍鄚釐醳酦섓쇀쇝쇶쇘섊셔솪솑셿솤섒ፌᎉᎢ\u139eᎇ፩ጂᎏ窩穩稦穯穤窉窉穬쮉쭚쭇쭬쭂쮐쯎쬰쬋쯥쬾쮈錦鏳鏪鏡鏪錩鍊鏥╧◚▞▫▬╠┹◿閍锶镀镘镇閪閪镏㚰㘊㘰㘈㧮㤮㤧㤩㤤㧝㧍㤨곑걭갩갅간곲겨걾걞겲갘겾곞겴갾곍⽮⾑⾀⾪⾤⽈⽌⿃\u2fd6⼋⿐⼶⽡⼆⾋⼐⿐⽕\u2ffd⽔⾧⾞\u2fd7⾥⼯\u2fef⽨⼁⿸⽆⽗\u2fe7鄦醝釷釆釯鄨酶醮醩酸釼鄬鄫酟醵酤欸毆毗毤毳欹歚殏殁歶毢歅欰歁殕歐殂欁殈此\uee06\ueeb9\ueefd\ueedf\ueec8\uee26\uee68\ueeb9\uee89\uee5c\ueee6\uee09\uee0d\uee78\ueea3\uee47\ueeba\uee38\uee80\uee5b\ueecb\ueece\ueeea\uee91⯇⭸⬼⬞⬉⯧⮩⭸⭈⮝⬧⯎⯍⯕⭢⮨⭹⮎⭢⯪泭汒氖氪氧泷沋汐汗沷氍沆波沺汌沄汚泜氬泀鳑鱪鰀鰱鰘鳟鲁鱙鱞鲏鰋鲀鳜鲸鱴鲢鱩鳂鰔鳸";
      char[] var8 = "\u0b3a\u0b3aଦପ\u0b3a\u0b3aାାଢ\u0b3a\u0b3aାାଢଶଶ\u0b3a\u0b3aମଶଖଦଢଦା\u0b3a\u0b3aା\u0b3a\u0b3aଶ\u0b3aା\u0b3a\u0b12ା\u0b3a\u0b3a\u0b3aଶଶା\u0b3a\u0b3a\u0b3aା\u0b3aଢ\u0b3aଢଶଶ\u0b3a\u0b3aଶଶାା\u0b3a\u0b3aାା\u0b3a\u0b3a\u0b3aଢଶଶଶଶଶମ\u0b3aା\u0b3aା\u0b3a\u0b3aା\u0b3aଶା\u0b3aଶ\u0b3a\u0b3a\u0b3aଢଢାଢାଢାଢପଢାଢଶାମ\u0b3a\u0b12ମ\u0b3a\u0b3a\u0b3a୲\u0b3aଆଆଞଞଂ\u0b12ଶାଢଦଦାାା\u0b3a\u0b3aଦାାଶଦଦପପଢ\u0b12ାଦପ\u0b3a\u0b3aା\u0b12ାଢଶମଶଢାଆମଶଶଶଶଶଦ\u0b3aଂପାା\u0b3a\u0b3a\u0b3aଢା\u0b3a\u0b3aା\u0b3aାମ\u0b3a\u0b3aା\u0b3aଶା\u0b3a\u0b12ାା\u0b3a\u0b3a\u0b3a\u0b3a\u0b3aାାଶଢା\u0b3a\u0b12\u0b3aଆମ\u0b12ପମମମ\u0b3a\u0b12ମଶଶ\u0b3a\u0b46\u0b3a\u0b3a\u0b3a\u0b3a\u0b3a\u0b3a\u0b3a\u0b3aଢାଢ\u0b3aାଢ\u0b3a\u0b3aା\u0b3a\u0b3aା\u0b3a\u0b3a\u0b3aଶ\u0b3aଢ\u0b12ଢଦପଦଦଦ".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            lI = var9;
            ll = new Object[var9.length];
            int var2 = -1938188068;
            byte[] var0 = "ø·DÇT®º\u009c¬Ø\u0086\u0092ª7m]\u0089¬DI\bù\r\u001a\u0086g©{\u009cGÃ2\u0013\u008dläxWy#\u008cÆ½m¼HPÕmÇÇE\u001enø\u009c\u009f¨Õõ\u0089\"teÌP!\u0092&\u001dÝÇ¬ïKþ9YÂÆL8\u0092Ý#\u0081£\u0091â%C\u00advó\u0081\u001b?\u0081sF".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            Il = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               Il[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static String IllllI(int var0, int var1) {
      int var3 = var0 ^ 1525019838;
      char[] var4 = lI[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])ll[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         ll[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -1832544424;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 184;
               break;
            case 1:
               var9 = 91;
               break;
            case 2:
               var9 = 108;
               break;
            case 3:
               var9 = 81;
               break;
            case 4:
               var9 = 114;
               break;
            case 5:
               var9 = 163;
               break;
            case 6:
               var9 = 207;
               break;
            case 7:
               var9 = 42;
               break;
            case 8:
               var9 = 8;
               break;
            case 9:
               var9 = 217;
               break;
            case 10:
               var9 = 88;
               break;
            case 11:
               var9 = 238;
               break;
            case 12:
               var9 = 153;
               break;
            case 13:
               var9 = 246;
               break;
            case 14:
               var9 = 0;
               break;
            case 15:
               var9 = 243;
               break;
            case 16:
               var9 = 46;
               break;
            case 17:
               var9 = 161;
               break;
            case 18:
               var9 = 45;
               break;
            case 19:
               var9 = 193;
               break;
            case 20:
               var9 = 116;
               break;
            case 21:
               var9 = 110;
               break;
            case 22:
               var9 = 0;
               break;
            case 23:
               var9 = 123;
               break;
            case 24:
               var9 = 194;
               break;
            case 25:
               var9 = 31;
               break;
            case 26:
               var9 = 226;
               break;
            case 27:
               var9 = 217;
               break;
            case 28:
               var9 = 21;
               break;
            case 29:
               var9 = 205;
               break;
            case 30:
               var9 = 184;
               break;
            case 31:
               var9 = 96;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
