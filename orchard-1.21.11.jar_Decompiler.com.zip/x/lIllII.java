package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public enum lIllII {
   I,
   l;

   private static String[] Il;
   lI,
   ll,
   III,
   IIl;

   private static final int[] IlI;
   private static final String[] Ill;
   private static final Object[] lII;

   static {
      short var6 = 12325;
      String var7 = "\uf08d쉾颲뒤ꇑ률㎞炳\ueb16\uf215렅聴䁊扈㿸쐨捒딷瘈덦\ud965◭慨\uda45㉱瓉\udf96\uf05e蜅\uaad1ᤠ功連声뫠\ue995㵯㤑";
      char[] var8 = "〭〣〦〣〬〣".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            Ill = var9;
            lII = new Object[var9.length];
            int var2 = 219826503;
            byte[] var0 = "Ý\u0080\u0019þð\u0012]\u009b\u0016d}\u0007»$L02&\\\u00166:¶é\u0005OmD6V C^äË=Ò¿\u0097;".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IlI = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IlI[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            Il = new String[lI(-167765404, 647645915)];
            I();
            l = new lIllII(Il[3], 0);
            I = new lIllII(Il[1], 1);
            III = new lIllII(Il[0], 2);
            ll = new lIllII(Il[5], 3);
            IIl = new lIllII(Il[2], 4);
            lI = new lIllII(Il[4], 5);
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static void I() {
      Il[0] = Il(ll(35235, 32019, -51160865).toCharArray(), 10166L, lI(-167765403, -1295151082));
      Il[1] = Il(ll(35234, 50582, 1819633213).toCharArray(), 45383L, lI(-167765402, 157030174));
      Il[2] = Il(ll(35233, 37389, 1460633242).toCharArray(), 47276L, lI(-167765401, -1388764876));
      Il[3] = Il(ll(35232, 22922, -231377742).toCharArray(), 7212L, lI(-167765408, 1699724933));
      Il[4] = Il(ll(35239, 3900, -1321573617).toCharArray(), 47853L, lI(-167765407, 2080905485));
      Il[5] = Il(ll(35238, 23517, -65862601).toCharArray(), 75608L, lI(-167765406, -1619560075));
   }

   public static lIllII l(String var0) {
      return (lIllII)Enum.valueOf(lIllII.class, var0);
   }

   // $FF: synthetic method
   private static lIllII[] II() {
      lIllII[] var10000 = new lIllII[lI(-167765405, -850594975)];
      var10000[0] = l;
      var10000[1] = I;
      var10000[2] = III;
      var10000[3] = ll;
      var10000[4] = IIl;
      var10000[5] = lI;
      return var10000;
   }

   private static String Il(char[] var0, long var1, int var3) {
      int var4 = lI(-167765396, 288178367) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & lI(-167765395, 698729710);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private static int lI(int var0, int var1) {
      return IlI[var0 ^ -167765404] ^ var1 ^ var0;
   }

   private static String ll(int var0, int var1, int var2) {
      int var3 = var0 ^ '覣';
      char[] var4 = Ill[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])lII[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         lII[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 488;
      int var9 = 0;

      do {
         int var10 = var4[var9] ^ '엚';
         var10 ^= 19538;
         var10 ^= 1573;
         var10 -= 26103;
         var10 -= 9295;
         var10 += 26829;
         var10 -= 13098;
         var10 ^= 8583;
         var10 -= 22440;
         var10 ^= 64921;
         var4[var9] = (char)(var10 ^ var8 ^ var1 ^ var2 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
