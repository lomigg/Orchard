package x;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_239.class_240;

@Environment(EnvType.CLIENT)
public final class IlIIlllI extends IIIIIIIlI {
   private static final double I = (double)4.0F;
   private static String[] l;
   private final lIIIIl II;
   private final llllIlIl Il;
   private final llllIlIl lI;
   private static final int ll = 1;
   private int III;
   private class_243 IIl;
   private long IlI;
   private final lIIIIl Ill;
   private class_3965 lII;
   private int lIl;
   private final lIIIIl llI;
   private static final int lll = 1;
   private final IlIIIlIlI<<undefinedtype>> IIII;
   private int IIIl;
   private final lIIIIl IIlI;
   private static final long IIll = 8000L;
   private int IlII;
   private static final int[] IlIl;
   private static final String[] IllI;
   private static final Object[] Illl;

   private boolean ll(class_310 var1, class_2338 var2) {
      if (var1 != null && var1.field_1687 != null && var2 != null) {
         class_2680 var3 = var1.field_1687.method_8320(var2);
         if (!var3.method_27852(class_2246.field_10540) && !var3.method_27852(class_2246.field_9987)) {
            return false;
         } else if (!this.lIII(var1, var2.method_10084())) {
            return false;
         } else {
            class_243 var4 = class_243.method_24953(var2.method_10084());
            if ((Boolean)this.IIlI.III() && var1.field_1724 != null) {
               float var5 = llIlllll.II(var1.field_1724, var4, 6.0F);
               float var6 = var1.field_1724.method_6032() + var1.field_1724.method_6067();
               if (var6 < 4.0F && var5 >= var6) {
                  return false;
               }
            }

            return true;
         }
      } else {
         return false;
      }
   }

   private static void IlI() {
      l[0] = llII(IllIl(56782262, -812054189).toCharArray(), 69953L, IllII(-145798086, -1460891034));
      l[1] = llII(IllIl(56782263, -826663768).toCharArray(), 6431L, IllII(-145798085, 777525127));
      l[2] = llII(IllIl(56782260, -811041534).toCharArray(), 55377L, IllII(-145798088, 1809299297));
      l[3] = llII(IllIl(56782261, -1285877337).toCharArray(), 6525L, IllII(-145798087, -2095542690));
      l[4] = llII(IllIl(56782258, -831827282).toCharArray(), 21558L, IllII(-145798082, -1219297202));
      l[5] = llII(IllIl(56782259, -494502698).toCharArray(), 57832L, IllII(-145798081, -722084596));
      l[IllII(-145798084, 759750155)] = llII(IllIl(56782256, -1379843749).toCharArray(), 72906L, IllII(-145798083, 1027009774));
      l[IllII(-145798094, -666799641)] = llII(IllIl(56782257, 1447781741).toCharArray(), 51882L, IllII(-145798093, -1194935835));
      l[IllII(-145798096, -321815955)] = llII(IllIl(56782270, -1720437146).toCharArray(), 63814L, IllII(-145798095, 1011748904));
      l[IllII(-145798090, 1777055768)] = llII(IllIl(56782271, -261879351).toCharArray(), 82326L, IllII(-145798089, -612261813));
   }

   private void lII(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         if (var1.field_1724.field_6012 >= this.III) {
            class_3966 var2;
            label46: {
               var2 = null;
               class_239 var6 = var1.field_1765;
               if (var6 instanceof class_3966) {
                  class_3966 var3 = (class_3966)var6;
                  class_1297 var7 = var3.method_17782();
                  if (var7 instanceof class_1511) {
                     class_1511 var4 = (class_1511)var7;
                     if (!var4.method_31481() && var4.method_5805()) {
                        var2 = var3;
                     }
                     break label46;
                  }
               }

               class_1297 var8 = var1.field_1692;
               if (var8 instanceof class_1511) {
                  class_1511 var5 = (class_1511)var8;
                  if (!var5.method_31481() && var5.method_5805()) {
                     var2 = new class_3966(var5);
                  }
               }
            }

            if (var2 != null) {
               if (this.IIll(var1, var2)) {
                  this.III = this.IlIl(var1, this.Il);
               } else {
                  this.III = var1.field_1724.field_6012 + 1;
               }

            }
         }
      }
   }

   public void lIl() {
      this.Illl();
      this.IIlII();
   }

   public void lI() {
      this.Illl();
      this.IIlII();
   }

   static {
      short var6 = 5153;
      String var7 = "穠የ\ue6de\u1c8eм奶撁죑킃్㸗\ue402\u175eࣣ嵼崱裍ꊄ浍竰捕鉸颟逭옐纁\uf53bﮕ첔ꫂ歕䍃맀\u0cf4侳蜽㌴詿蛍岧훪瓾ᐑ쪼魌￨ଘ\uea34ᴼ\uf326ഺ읾驥ᔸឿ미둸촠ذ䱄级稉靱\ue452瘲竘留\uf465\ue08d铃钁쥘텑긱䌫湙Ꮏ䲀昡侫\uda5f㋽蓍ꪼ韟揨ꈖ嶇䥊ꛁ刐\uec15髵蒍๛୭ᾅ簜ꖅ믜踑΅ໝ踿㑫魝枱䵄确腶㥳㷡︽▿㎇ሹ쨊볋\ue5dc䵆ꓢ苩Ꜥ鏸헺ℤ爹믂䏄詏\ue759\uf45b技鉆躆发䒉ំ桞㽗侲ٶ赼䇑㲟銝⒔䞴䨅鞻츆潛騊쬄䮇\ue7f9툤펬\ud810갋뭘⿁榶얿Ⴎ༛\ue23f群̄釩\uec2e㕖雾梗웻荰\ue5e7ᩬ囹\uf040笗咯䑍첷䱳\u0cf7أ暺늢裏扯唅疃覇\udf22邐狑欌褽⺻⣏⣊⣜⠞⣕帕帐帆廄帏憪憀憛慒懄懣憣懻懤慿愲愖愲懟愊憤懣";
      char[] var8 = "ᐭᐱᐱᐕᐥᐽᐵᐱᐱᐵᐤᐤᐰ".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IllI = var9;
            Illl = new Object[var9.length];
            int var2 = 78894835;
            byte[] var0 = "\u0006f\t\u0098z\u0000ÓE\u0087\u001cg$\u001dÌO½_W\u0017¯ó\u001b\u001d\u001aÞ´DÂ\u0011«p'+½ë!o\u0089\u001c\u0017\u001f-à¦×LAk\u009a\u0017\"Ô-d´\u0083æ\u0012è%!ú!@\u001f_3Éë\u009cö\u0084<\u00860\u008f1\rá\u0013\u000e´p\u001båPdT\u0012hV?§\u00005\u0084tiïn\u0097`â\u0086ÒÇ¢\u0083".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IlIl = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IlIl[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            l = new String[IllII(-145798092, 367948520)];
            IlI();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 3;
                     break;
                  case 1:
                     var10000 = 20;
                     break;
                  case 2:
                     var10000 = 16;
                     break;
                  case 3:
                     var10000 = 8;
                     break;
                  case 4:
                     var10000 = 89;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private void llI() {
      this.lII = null;
      this.IIIl = -1;
      this.IlII = IllII(-145798091, 1376172934);
   }

   private int lll(class_1661 var1, class_1792 var2) {
      if (var1 != null && var2 != null) {
         for(int var3 = 0; var3 < IllII(-145798102, -324818663); ++var3) {
            if (var1.method_5438(var3).method_31574(var2)) {
               return var3;
            }
         }

         return -1;
      } else {
         return -1;
      }
   }

   public void Ill() {
   }

   private boolean IIII() {
      return this.IIl != null && System.currentTimeMillis() - this.IlI <= 8000L;
   }

   public IlIIlllI() {
      super((Object)lIlIII.l(l[1]), lIllII.I, (Object)lIlIII.l(l[3]));
      this.IIII = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(l[2]), <undefinedtype>.class, null.ll));
      this.Ill = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(l[IllII(-145798101, 408972373)]), false));
      llllIlIl var10002 = new llllIlIl(lIlIII.l(l[IllII(-145798104, -814044589)]), (double)1.0F, (double)1.0F, (double)1.0F, (double)4.0F, (double)1.0F);
      lIlIII.Il(l[4]);
      this.lI = (llllIlIl)this.IIIlIll(var10002.IIII(IllIl(56782268, -2084350223)));
      var10002 = new llllIlIl(lIlIII.l(l[IllII(-145798103, -1024361535)]), (double)1.0F, (double)1.0F, (double)1.0F, (double)4.0F, (double)1.0F);
      lIlIII.Il(l[4]);
      this.Il = (llllIlIl)this.IIIlIll(var10002.IIII(IllIl(56782269, -182903734)));
      this.II = new lIIIIl(lIlIII.l(l[IllII(-145798098, -45552960)]), true);
      this.llI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(l[5]), true));
      this.IIIl = -1;
      this.IlII = IllII(-145798097, -1767047544);
      this.IIlI = (lIIIIl)((IIIIIIIlI)this).IIIlIll(new lIIIIl(IllIl(56782266, -897487307), false));
   }

   private boolean IIll(class_310 var1, class_3966 var2) {
      return (Boolean)this.IIlI.III() && !(llIlllll.II(var1.field_1724, var2.method_17782().method_19538(), 6.0F) < var1.field_1724.method_6032() + var1.field_1724.method_6067()) ? false : IllllIlI.lllII(var1, var2);
   }

   private void IlII(class_310 var1) {
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null) {
         if (var1.field_1724.field_6012 >= this.lIl) {
            class_239 var3 = var1.field_1765;
            if (var3 instanceof class_3965) {
               class_3965 var2 = (class_3965)var3;
               if (var2.method_17783() == class_240.field_1332) {
                  if (!this.ll(var1, var2.method_17777())) {
                     return;
                  }

                  int var4 = this.IIlIl(var1);
                  if (var4 < 0) {
                     return;
                  }

                  this.lII = var2;
                  this.IIIl = var4;
                  this.IlII = var1.field_1724.field_6012;
                  this.IIIIl(var1);
                  return;
               }
            }

         }
      }
   }

   private int IlIl(class_310 var1, llllIlIl var2) {
      int var3 = this.IlIII(var2);
      return var1 != null && var1.field_1724 != null ? var1.field_1724.field_6012 + var3 : 0;
   }

   private void Illl() {
      this.lIl = 0;
      this.III = 0;
   }

   private boolean lIII(class_310 var1, class_2338 var2) {
      class_2680 var3 = var1.field_1687.method_8320(var2);
      return (var3.method_26215() || var3.method_45474()) && var1.field_1687.method_8335((class_1297)null, new class_238(var2)).isEmpty();
   }

   public void IIl(JsonObject var1) {
      super.IIl(var1);
      this.IlIll(var1, lIlIII.Il(l[IllII(-145798100, -510341913)]), this.lI);
      this.IlIll(var1, lIlIII.Il(l[IllII(-145798099, 1425846098)]), this.Il);
   }

   private double lIIl(class_1657 var1) {
      if (var1 != null && this.IIl != null) {
         class_243 var2 = new class_243(var1.method_23317(), var1.method_23318(), var1.method_23321());
         return Math.sqrt(var2.method_1025(this.IIl));
      } else {
         return Double.POSITIVE_INFINITY;
      }
   }

   private static String llII(char[] var0, long var1, int var3) {
      int var4 = IllII(-145798110, -602358146) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IllII(-145798109, 1687976105);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private boolean lllI(class_310 var1) {
      return var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var1.field_1690 != null && var1.field_1755 == null && var1.field_1724.method_5805();
   }

   private void IIIII(class_310 var1) {
      int var2 = var1.field_1724.field_6012;
      if (this.IlII > var2 || this.lIl > var2 + 4 || this.III > var2 + 4) {
         this.IIlll(var1);
         this.Illl();
      }
   }

   private void IIIIl(class_310 var1) {
      if (this.IIIl >= 0 && this.lII != null) {
         if (var1 != null && var1.field_1724 != null && var1.field_1724.field_6012 >= this.IlII) {
            class_3965 var2 = this.lII;
            int var3 = this.IIIl;
            class_239 var5 = var1.field_1765;
            if (var5 instanceof class_3965) {
               class_3965 var4 = (class_3965)var5;
               if (var4.method_17783() == class_240.field_1332 && var2.method_17777().equals(var4.method_17777()) && this.ll(var1, var4.method_17777())) {
                  if (!var1.field_1724.method_31548().method_5438(var3).method_31574(class_1802.field_8301)) {
                     this.IIlll(var1);
                     this.lIl = var1.field_1724.field_6012 + 1;
                     return;
                  }

                  int var7 = IllllIlI.lIIlI(var1.field_1724.method_31548());
                  if (var7 != var3) {
                     IllllIlI.IIlIlI(var1, var3, true);
                     IllllIlI.IlllI(var1);
                  }

                  boolean var6 = IllllIlI.IIlIIII(var1, var4);
                  if (var6) {
                     this.IIllI(class_243.method_24953(var4.method_17777().method_10084()));
                     this.lIl = this.IlIl(var1, this.lI);
                     this.llI();
                  } else {
                     this.lIl = var1.field_1724.field_6012 + 1;
                     this.llI();
                  }

                  return;
               }
            }

            this.llI();
         }
      } else {
         this.llI();
      }
   }

   public void IllI(class_310 var1) {
      if (!this.lllI(var1)) {
         this.IIlll(var1);
         this.Illl();
      } else {
         this.IIIII(var1);
         if (!this.IlIIl(var1)) {
            this.IIlll(var1);
         } else if ((Boolean)this.Ill.III() && !var1.field_1724.method_24828()) {
            this.IIlll(var1);
            this.Illl();
         } else {
            this.lII(var1);
            this.IlII(var1);
         }
      }
   }

   public void II(class_1297 var1, byte var2) {
   }

   private static double IIIll(double var0) {
      return var0 > (double)4.0F ? Math.max((double)1.0F, Math.min((double)4.0F, (double)Math.round(var0 / (double)50.0F))) : Math.max((double)1.0F, Math.min((double)4.0F, var0));
   }

   private void IIlII() {
      this.IIl = null;
      this.IlI = 0L;
   }

   private int IIlIl(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         class_1661 var2 = var1.field_1724.method_31548();
         int var3 = IIlllllI.IIIl(var2);
         if (var3 >= 0 && var3 < IllII(-145798112, 557529177) && var2.method_5438(var3).method_31574(class_1802.field_8301)) {
            return var3;
         } else {
            return !(Boolean)this.llI.III() ? -1 : this.lll(var2, class_1802.field_8301);
         }
      } else {
         return -1;
      }
   }

   private void IIllI(class_243 var1) {
      this.IIl = var1;
      this.IlI = System.currentTimeMillis();
   }

   private void IIlll(class_310 var1) {
      IllllIlI.IlII(var1, this, null.II);
      this.llI();
   }

   private int IlIII(llllIlIl var1) {
      double var2 = var1.IlII();
      double var4 = var1.IlI();
      return var2 == var4 ? Math.max(1, (int)Math.round(var2)) : Math.max(1, (int)Math.round(ThreadLocalRandom.current().nextDouble(var2, var4)));
   }

   public boolean IlIIl(class_310 var1) {
      if (var1 != null && var1.field_1690 != null) {
         boolean var10000;
         switch (((<undefinedtype>)this.IIII.III()).ordinal()) {
            case 0 -> var10000 = true;
            case 1 -> var10000 = var1.field_1690.field_1886 != null && var1.field_1690.field_1886.method_1434() || IllllIlI.IIIll(var1, var1.field_1690.field_1886);
            case 2 -> var10000 = var1.field_1690.field_1904 != null && var1.field_1690.field_1904.method_1434() || IllllIlI.IIIll(var1, var1.field_1690.field_1904);
            default -> throw new MatchException((String)null, (Throwable)null);
         }

         return var10000;
      } else {
         return false;
      }
   }

   private void IlIll(JsonObject var1, String var2, llllIlIl var3) {
      if (var1 != null && var2 != null && var1.has(lIlIII.Il(l[0]))) {
         JsonObject var4 = var1.getAsJsonObject(lIlIII.Il(l[0]));
         JsonElement var5 = var4.get(var2);
         if (var5 != null && !var5.isJsonNull()) {
            try {
               if (var5.isJsonArray()) {
                  JsonArray var6 = var5.getAsJsonArray();
                  if (var6.size() >= 2) {
                     double var7 = IIIll(var6.get(0).getAsDouble());
                     double var9 = IIIll(var6.get(1).getAsDouble());
                     var3.IIIl(new double[]{var7, var9});
                  }
               } else if (var5.isJsonPrimitive()) {
                  double var12 = IIIll(var5.getAsDouble());
                  var3.IIIl(new double[]{var12, var12});
               }
            } catch (Throwable var11) {
            }

         }
      }
   }

   private static int IllII(int var0, int var1) {
      return IlIl[var0 ^ -145798086] ^ var1 ^ var0;
   }

   private static String IllIl(int var0, int var1) {
      int var3 = var0 ^ 56782262;
      char[] var4 = IllI[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])Illl[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         Illl[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 1622560935;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 90;
               break;
            case 1:
               var9 = 85;
               break;
            case 2:
               var9 = 77;
               break;
            case 3:
               var9 = 159;
               break;
            case 4:
               var9 = 29;
               break;
            case 5:
               var9 = 5;
               break;
            case 6:
               var9 = 111;
               break;
            case 7:
               var9 = 59;
               break;
            case 8:
               var9 = 32;
               break;
            case 9:
               var9 = 233;
               break;
            case 10:
               var9 = 245;
               break;
            case 11:
               var9 = 199;
               break;
            case 12:
               var9 = 162;
               break;
            case 13:
               var9 = 56;
               break;
            case 14:
               var9 = 157;
               break;
            case 15:
               var9 = 107;
               break;
            case 16:
               var9 = 46;
               break;
            case 17:
               var9 = 145;
               break;
            case 18:
               var9 = 26;
               break;
            case 19:
               var9 = 222;
               break;
            case 20:
               var9 = 105;
               break;
            case 21:
               var9 = 164;
               break;
            case 22:
               var9 = 203;
               break;
            case 23:
               var9 = 39;
               break;
            case 24:
               var9 = 124;
               break;
            case 25:
               var9 = 131;
               break;
            case 26:
               var9 = 178;
               break;
            case 27:
               var9 = 200;
               break;
            case 28:
               var9 = 229;
               break;
            case 29:
               var9 = 160;
               break;
            case 30:
               var9 = 178;
               break;
            case 31:
               var9 = 146;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
