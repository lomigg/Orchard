package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1267;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_5134;
import net.minecraft.class_239.class_240;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;

@Environment(EnvType.CLIENT)
public final class llIlllll {
   private static float I(class_243 var0, class_238 var1, class_1297 var2, class_2338 var3, class_2338 var4) {
      class_310 var5 = class_310.method_1551();
      if (var0 != null && var1 != null && var2 != null && var5.field_1687 != null) {
         double var6 = (double)1.0F / (var1.method_17939() * (double)2.0F + (double)1.0F);
         double var8 = (double)1.0F / (var1.method_17940() * (double)2.0F + (double)1.0F);
         double var10 = (double)1.0F / (var1.method_17941() * (double)2.0F + (double)1.0F);
         if (!(var6 < (double)0.0F) && !(var8 < (double)0.0F) && !(var10 < (double)0.0F)) {
            double var12 = ((double)1.0F - Math.floor((double)1.0F / var6) * var6) * (double)0.5F;
            double var14 = ((double)1.0F - Math.floor((double)1.0F / var10) * var10) * (double)0.5F;
            int var16 = 0;
            int var17 = 0;

            for(double var18 = (double)0.0F; var18 <= (double)1.0F; var18 += var6) {
               for(double var20 = (double)0.0F; var20 <= (double)1.0F; var20 += var8) {
                  for(double var22 = (double)0.0F; var22 <= (double)1.0F; var22 += var10) {
                     class_243 var24 = new class_243(class_3532.method_16436(var18, var1.field_1323, var1.field_1320) + var12, class_3532.method_16436(var20, var1.field_1322, var1.field_1325), class_3532.method_16436(var22, var1.field_1321, var1.field_1324) + var14);
                     if (III(var5, var24, var0, var2, var3, var4)) {
                        ++var16;
                     }

                     ++var17;
                  }
               }
            }

            return var17 == 0 ? 0.0F : (float)var16 / (float)var17;
         } else {
            return 0.0F;
         }
      } else {
         return 0.0F;
      }
   }

   private llIlllll() {
   }

   public static float l(class_1309 var0, class_2338 var1, class_2338 var2, class_243 var3) {
      if (var0 != null && var1 != null) {
         class_310 var4 = class_310.method_1551();
         if (var4.field_1687 == null) {
            return 0.0F;
         } else {
            class_243 var5 = class_243.method_24953(var1);
            class_243 var6 = var0.method_73189();
            class_243 var7 = var3 == null ? var6 : var3;
            class_238 var8 = var0.method_5829().method_997(var7.method_1020(var6));
            float var9 = 10.0F;
            double var10 = Math.sqrt(var7.method_1025(var5)) / (double)var9;
            if (var10 > (double)1.0F) {
               return 0.0F;
            } else {
               float var12 = I(var5, var8, var0, var1, var2);
               double var13 = ((double)1.0F - var10) * (double)var12;
               float var15 = (float)((var13 * var13 + var13) * (double)0.5F * (double)7.0F * (double)var9 + (double)1.0F);
               var15 = Il(var15, var4.field_1687.method_8407());
               float var16 = (float)var0.method_6096();
               float var17 = var0.method_5996(class_5134.field_23725) == null ? 0.0F : (float)var0.method_45325(class_5134.field_23725);
               float var18 = 2.0F + var17 / 4.0F;
               float var19 = class_3532.method_15363(var16 - var15 / var18, var16 * 0.2F, 20.0F);
               return var15 * (1.0F - var19 / 25.0F);
            }
         }
      } else {
         return 0.0F;
      }
   }

   public static float II(class_1309 var0, class_243 var1, float var2) {
      if (var0 != null && var1 != null) {
         class_310 var3 = class_310.method_1551();
         if (var3.field_1687 == null) {
            return 0.0F;
         } else {
            class_243 var4 = var0.method_73189();
            class_238 var5 = var0.method_5829();
            float var6 = var2 * 2.0F;
            double var7 = Math.sqrt(var4.method_1025(var1)) / (double)var6;
            if (var7 > (double)1.0F) {
               return 0.0F;
            } else {
               float var9 = ll(var1, var5, var0);
               double var10 = ((double)1.0F - var7) * (double)var9;
               float var12 = (float)((var10 * var10 + var10) * (double)0.5F * (double)7.0F * (double)var6 + (double)1.0F);
               var12 = Il(var12, var3.field_1687.method_8407());
               float var13 = (float)var0.method_6096();
               float var14 = var0.method_5996(class_5134.field_23725) == null ? 0.0F : (float)var0.method_45325(class_5134.field_23725);
               float var15 = 2.0F + var14 / 4.0F;
               float var16 = class_3532.method_15363(var13 - var12 / var15, var13 * 0.2F, 20.0F);
               return var12 * (1.0F - var16 / 25.0F);
            }
         }
      } else {
         return 0.0F;
      }
   }

   private static float Il(float var0, class_1267 var1) {
      if (var1 == class_1267.field_5801) {
         return 0.0F;
      } else if (var1 == class_1267.field_5805) {
         return Math.min(var0 * 0.5F + 1.0F, var0);
      } else {
         return var1 == class_1267.field_5807 ? var0 * 1.5F : var0;
      }
   }

   static boolean lI(class_243 var0, class_243 var1, class_2338 var2) {
      return var0 != null && var1 != null && var2 != null ? lIlllllI.lII(var0.field_1352, var0.field_1351, var0.field_1350, var1.field_1352, var1.field_1351, var1.field_1350, (double)var2.method_10263(), (double)var2.method_10264(), (double)var2.method_10260(), (double)var2.method_10263() + (double)1.0F, (double)var2.method_10264() + (double)1.0F, (double)var2.method_10260() + (double)1.0F) : false;
   }

   private static float ll(class_243 var0, class_238 var1, class_1297 var2) {
      class_310 var3 = class_310.method_1551();
      if (var3.field_1687 == null) {
         return 0.0F;
      } else {
         double var4 = (double)1.0F / (var1.method_17939() * (double)2.0F + (double)1.0F);
         double var6 = (double)1.0F / (var1.method_17940() * (double)2.0F + (double)1.0F);
         double var8 = (double)1.0F / (var1.method_17941() * (double)2.0F + (double)1.0F);
         double var10 = ((double)1.0F - Math.floor((double)1.0F / var4) * var4) * (double)0.5F;
         double var12 = ((double)1.0F - Math.floor((double)1.0F / var8) * var8) * (double)0.5F;
         int var14 = 0;
         int var15 = 0;

         for(double var16 = (double)0.0F; var16 <= (double)1.0F; var16 += var4) {
            for(double var18 = (double)0.0F; var18 <= (double)1.0F; var18 += var6) {
               for(double var20 = (double)0.0F; var20 <= (double)1.0F; var20 += var8) {
                  class_243 var22 = new class_243(class_3532.method_16436(var16, var1.field_1323, var1.field_1320) + var10, class_3532.method_16436(var18, var1.field_1322, var1.field_1325), class_3532.method_16436(var20, var1.field_1321, var1.field_1324) + var12);
                  class_3965 var23 = var3.field_1687.method_17742(new class_3959(var22, var0, class_3960.field_17558, class_242.field_1348, var2));
                  if (var23.method_17783() == class_240.field_1333) {
                     ++var14;
                  }

                  ++var15;
               }
            }
         }

         return var15 == 0 ? 0.0F : (float)var14 / (float)var15;
      }
   }

   private static boolean III(class_310 var0, class_243 var1, class_243 var2, class_1297 var3, class_2338 var4, class_2338 var5) {
      if (var5 != null && lI(var2, var1, var5)) {
         return false;
      } else {
         class_3965 var6 = var0.field_1687.method_17742(new class_3959(var2, var1, class_3960.field_17558, class_242.field_1348, var3));
         if (var6.method_17783() == class_240.field_1333) {
            return true;
         } else {
            return var4 != null && var6.method_17777().equals(var4);
         }
      }
   }
}
