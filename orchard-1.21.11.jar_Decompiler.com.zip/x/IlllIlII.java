package x;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3532;

@Environment(EnvType.CLIENT)
public interface IlllIlII {
   <undefinedtype> IllIlll;
   <undefinedtype> IlllIII;
   <undefinedtype> IlllIIl;
   <undefinedtype> IlllIlI;
   String[] IlIlIII;
   Object[] IlIlIIl;

   static class_238 IlIIIlI(class_1309 var0, Object var1) {
      if (var0 == null) {
         return null;
      } else {
         class_238 var2 = var0.method_5829();
         <undefinedtype> var3 = var1 == null ? null.I : var1;
         double var4 = var2.field_1325 - var2.field_1322;
         double var6 = var2.field_1322 + var4 * var3.lI();
         double var8 = var2.field_1322 + var4 * var3.I();
         return new class_238(var2.field_1323, var6, var2.field_1321, var2.field_1320, Math.max(var6 + 0.01, var8), var2.field_1324);
      }
   }

   static {
      short var0 = 7529;
      String var1 = "帞幇幒幇幜幌帱常帲帨帨幦箰箸築箧箞箪箷箤篑節篋篋箸箹箳篈篆箪篬篬㻻㻳㻦㴌㴑㻽㻼㴏㻞㻫㻠㻠㻱㺿㴌㴉㻰㻷㴉㻇⾯⿇⿊⾘⾥⾩⾨⾛⿂⾿⿔⿔⾺⾺⾬⾛⿄⾿⿳⿳";
      char[] var2 = "ᵥᵽᵽᵽ".toCharArray();
      String[] var3 = new String[var2.length];
      byte var7 = -1;

      while(true) {
         int var4 = 0;
         int var5 = 0;
         int var6 = 0;
         if (var7 == 0) {
            IlIlIII = var3;
            IlIlIIl = new Object[var3.length];
            IlllIII = lIlIII.l(I((short)'뵸', -855093012, '泼'));
            IllIlll = lIlIII.l(I((short)'ﮜ', -1770888154, '泽'));
            IlllIlI = lIlIII.l(I((short)'ꛋ', -161713778, '泾'));
            IlllIIl = lIlIII.l(I((short)23116, 2075085846, '泿'));
            return;
         }

         do {
            var6 = var2[var4] ^ var0;
            var3[var4] = var1.substring(var5, var5 + var6);
            var5 += var6;
            ++var4;
         } while(var4 < var2.length);

         var7 = 0;
      }
   }

   private static void IlIIIll(List<<undefinedtype>> var0, Object var1, boolean var2) {
      if (var2 && !var0.contains(var1)) {
         var0.add(var1);
      }

   }

   <undefinedtype> IIlIll();

   static List<<undefinedtype>> IlIIlII(Object var0, boolean var1, boolean var2, boolean var3) {
      <undefinedtype> var4 = var0 == null ? null.I : var0;
      ArrayList var5 = new ArrayList(3);
      var5.add(var4);
      IlIIIll(var5, null.l, var1);
      IlIIIll(var5, null.I, var2);
      IlIIIll(var5, null.Il, var3);
      return var5;
   }

   static <undefinedtype> IlIIlIl(class_1309 var0, class_243 var1) {
      if (var0 != null && var1 != null) {
         class_238 var2 = var0.method_5829();
         double var3 = Math.max(var2.field_1325 - var2.field_1322, 0.01);
         double var5 = class_3532.method_15350((var1.field_1351 - var2.field_1322) / var3, (double)0.0F, (double)1.0F);
         if (var5 >= null.l.lI()) {
            return null.l;
         } else {
            return var5 >= null.I.lI() ? null.I : null.Il;
         }
      } else {
         return null.I;
      }
   }

   static class_243 IlIIllI(class_1309 var0, Object var1) {
      if (var0 == null) {
         return null;
      } else {
         class_238 var2 = var0.method_5829();
         class_243 var3 = var2.method_1005();
         <undefinedtype> var4 = var1 == null ? null.I : var1;
         double var5 = var2.field_1325 - var2.field_1322;
         double var7 = var2.field_1322 + var5 * var4.II();
         return new class_243(var3.field_1352, var7, var3.field_1350);
      }
   }

   static List<<undefinedtype>> IlIIlll(boolean var0, boolean var1, boolean var2) {
      ArrayList var3 = new ArrayList(3);
      IlIIIll(var3, null.l, var0);
      IlIIIll(var3, null.I, var1);
      IlIIIll(var3, null.Il, var2);
      if (var3.isEmpty()) {
         var3.add(null.l);
         var3.add(null.I);
         var3.add(null.Il);
      }

      return var3;
   }

   boolean IlIll(Object var1);

   private static String I(short var0, int var1, char var2) {
      int var3 = var2 ^ 27900;
      char[] var4 = IlIlIII[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])IlIlIIl[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         IlIlIIl[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 9893;
      int var9 = 0;

      do {
         int var10 = var4[var9] ^ 30469;
         var10 -= 9624;
         var10 += 7041;
         var10 ^= 45968;
         var10 ^= 41805;
         var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
