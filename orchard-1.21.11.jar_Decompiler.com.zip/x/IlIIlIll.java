package x;

import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;

@Environment(EnvType.CLIENT)
public final class IlIIlIll {
   private static final int I = -12960442;
   private lIIIllll l;
   private static final <undefinedtype> II;
   private static final <undefinedtype> Il;
   private class_332 lI;
   private static final double ll = (double)12.0F;
   static final int III = 10;
   private static final double IIl = (double)8.0F;
   private static final int IlI = -14013131;
   private static final <undefinedtype> Ill;
   private static final <undefinedtype> lII;
   private static final int lIl = -12170926;
   private static final <undefinedtype> llI;
   private static final double lll = (double)16.0F;
   private static final <undefinedtype> IIII;
   private static final <undefinedtype> IIIl;
   static final int IIlI = 112;
   static final int IIll = 25;
   private static final <undefinedtype> IlII;
   static final <undefinedtype> IlIl;
   private static final <undefinedtype> IllI;
   private static final <undefinedtype> Illl;
   private class_327 lIII;
   private static final <undefinedtype> lIIl;
   private static final int lIlI = -1340993006;
   private static final <undefinedtype> lIll;
   private static final <undefinedtype> llII;
   private static final <undefinedtype> llIl;
   private static final <undefinedtype> lllI;
   private static final int[] llll;
   private static final String[] IIIII;
   private static final Object[] IIIIl;

   private static class_2960 I(Object var0) {
      String var10000 = lIlIII.l(IIllII(176852108, 651761376)).lIlI();
      String var10001 = IllII();
      String var10002 = var0.lIlI();
      String var3 = lIlIII.Il(IIllII(176852109, 1643866982));
      String var2 = var10002;
      String var1 = var10001;
      return class_2960.method_60655(var10000, var1 + var2 + var3);
   }

   void l(double var1, double var3, double var5, double var7, String var9, boolean var10, double var11) {
      double var13 = IlIlI(var7, (double)0.0F, (double)1.0F);
      double var15 = var3 + (double)16.0F;
      double var17 = (double)6.0F;
      double var19 = var1 + IlIlI(var5 * var13, var17, Math.max(var17, var5 - var17));
      double var21 = Math.max((double)12.0F, var19 - var1 + var17);
      IIIIIIllI.IllIll(this.lI, var1, var15, var5, (double)12.0F, var17, IIlIll(-1608843840, 382067434));
      if (var10) {
         IIIIIIllI.IllIll(this.lI, var1, var15, var21, (double)12.0F, var17, this.lI());
      }

      IIIIIIllI.IllIll(this.lI, var19 - (double)4.0F, var15 + (double)2.0F, (double)8.0F, (double)8.0F, (double)4.0F, var10 ? -1 : this.lI());
      this.IIIIl(var1, var3, var5, var9, var11);
   }

   void II(double var1, double var3, double var5, double var7, boolean var9, boolean var10, double var11) {
      double var13 = IlIlI(var11, (double)0.0F, (double)1.0F);
      int var15 = (int)((double)255.0F * var13);
      int var16 = IIIlIl(var9 ? IIlIll(-1608843839, 261771626) : IIlIll(-1608843838, -1074291337), var15);
      IIIIIIllI.IllIll(this.lI, var1, var3, var5, var7 - (double)2.0F, (double)5.5F, var16);
      if (var10) {
         int var17 = (int)((double)220.0F * var13);
         IIIIIIllI.IllIll(this.lI, var1 + (double)1.5F, var3 + (double)6.0F, (double)2.0F, Math.max((double)2.0F, var7 - (double)14.0F), (double)1.0F, IIIlIl(this.lI(), var17));
      }

   }

   static {
      short var6 = 6271;
      String var7 = "\ud908\ud9f0\ud9a6\ud9ae\ud98f\ud973\ud9f1\ud9f2鹶麈麀麬麪鹑黓黐樳櫓檈檕檫橤檆檫橑櫽櫮樱㡶㢓㢽㢬࣏ࠠࠑࡥࡏ\u0896ࡸࡍࢶࠟࡋࢽࡦ࣡ࣀࣀ㢴㠜㠓㠟㠪㣧㠎㠱㣁㡪㠟㣐㠀㢋㢣㢹뛡뙞뙼뙥뙧뚄뙔뙠뚟똤뙸뚤뙍뛕뚩뛧\uf656\uf6ea\uf69a\uf6e1\uf6c0\uf623\uf6c1\uf6d4\uf639\uf683\uf685\uf62b\uf6fb\uf617\uf611\uf653몵먶먵먔먤뫿멐먄뫏멢먀뫁먊몘몹몥뙦뛢뚩뛆뛤똨뛕뛷똙뚡뛭똄뛛똱뙽뙴帅廴廈庄底幵应庉幮廒廓幵庰幖幔币\udf8a\udf67\udf37\udf3b\udf18\udfc3\udf31\udf1d\udff1\udf60\udf28\udff7\udf2f\udfde\udfd4\udf99۽ىيٕٲھٱٴڋ؊ٷڷىڊڮ۲ᰉᲽᲭᲣᲕ\u1c4aᲤᲕᱩ᳭ᲛᱷᲿ᱄᱉ᰗ\u19dd\u1975ᥪ\u1978ᥟᦖᥬᥙ\u19aeᤘ᥏ᦪᥱᦌᦼ\u19dc㛘㙖㙳㙭㙂㚌㙌㙂㚷㘿㙒㚫㙬㚠㚘㛅㉅㋖㋧㋸㋗㈶㋥㋕㈮㊬㋙㈤㋰㉩㈶㉎䩤䪈䫆䫐䫱䨾䫌䫥䨅䪞䫆䨙䫜䨤䨭䩚쯑쬴쬚쬋æf_Ke¬]`\u009a&7\u009eIÔ´â\u0095ö\nå3\u008a¾i";
      char[] var8 = "ᡷᡷᡳ\u187bᡯᡯᡯᡯᡯᡯᡯᡯᡯᡯᡯᡯᡯᡯ\u187bᡧ".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IIIII = var9;
            IIIIl = new Object[var9.length];
            int var2 = 2063841334;
            byte[] var0 = "ý#Xã+¹)Û\u009bÄõ¶\u0089\u009c\râßà\u00120þkÅ\u000b@ß·?¢Ñ\u00adI¸{åjª«î¡\u0002ò6\u009aÐÍC:j$úç¿\rR\u001e¤W#2ê-ÒÕ\u0015N»ù\u0012\u0091Æ{ªt\u009b¸\u0097r\u0003í\u0007Íø\tÛ£@2v7/\u0007\u0005#·êÉ\u00adö\u0000úÊä\u001d.¶ß\\^Ø×T®<\u0084<HHî\u0015\u0014\u0082*a\u0017Ç\u0096·W7ô41Xõdào»²óü\fâÇôðÃ\u008bJR\b°4&¹".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            llll = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               llll[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            IIII = null.I(lIlIII.l(IIllII(176852110, 434987635)));
            IIIl = lIlIII.l(IIllII(176852111, 1273833509));
            llII = lIlIII.l(IIllII(176852104, 2065655189));
            Ill = lIlIII.l(IIllII(176852105, 1266235034));
            lIll = lIlIII.l(IIllII(176852106, -987286932));
            IllI = lIlIII.l(IIllII(176852107, -2054133319));
            lIIl = lIlIII.l(IIllII(176852100, -916042263));
            II = lIlIII.l(IIllII(176852101, -979237544));
            llIl = lIlIII.l(IIllII(176852102, 767962086));
            IlII = lIlIII.l(IIllII(176852103, -1403428185));
            Il = lIlIII.l(IIllII(176852096, 1966084677));
            llI = lIlIII.l(IIllII(176852097, 1876174531));
            lII = lIlIII.l(IIllII(176852098, 1780231587));
            lllI = lIlIII.l(IIllII(176852099, 1157962947));
            Illl = lIlIII.l(IIllII(176852124, 1100366095));
            IlIl = lIlIII.l(IIllII(176852125, 968304855));
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   IlIIlIll() {
   }

   void Il(String var1, double var2, double var4, int var6, double var7) {
      if (var1 != null && !var1.isBlank()) {
         if (var7 == (double)1.0F) {
            this.llIII(var1, var2, var4, var6);
         } else {
            IIIIIIllI.IIIllI(this.lI);

            try {
               IIIIIIllI.IlII(this.lI, var2, var4);
               IIIIIIllI.lllI(this.lI, var7, var7);
               IIIIIIllI.llIl(this.lI, this.lIII, var1, (double)0.0F, (double)0.0F, var6);
            } finally {
               IIIIIIllI.lIIlIl(this.lI);
            }

         }
      }
   }

   int lI() {
      return IIlIIl(this.l.IIllII(), IIlIll(-1608843837, 1384466664));
   }

   void III(double var1, double var3, double var5, double var7, String var9, boolean var10) {
      this.l(var1, var3, var5, var7, var9, var10, (double)1.0F);
   }

   int IIl(String var1) {
      return var1 != null && !var1.isEmpty() ? IIIIIIllI.IlIl(this.lIII, var1) : 0;
   }

   int IlI(int var1) {
      return IIlIIl(IIIIII(this.l.IIIIIl(), this.l.IIlIl(), 0.32), var1);
   }

   private double Ill(double var1, double var3) {
      return var1 + Math.max((double)0.0F, (var3 - IIIIIIllI.lllIII(this.lIII)) * (double)0.5F);
   }

   void lII(double var1, double var3, double var5, IIllIIlII var7, boolean var8, double var9) {
      int var11 = (int)Math.round(IlIlI(var9, (double)0.0F, (double)1.0F) * (double)255.0F);
      if (var11 > 0) {
         Color var12 = var7.Il() == null ? this.l.IIllII() : var7.Il();
         Color var13 = var7.Ill() == null ? this.l.IlIII() : var7.Ill();
         int var14 = var8 ? var11 : (int)Math.round((double)var11 * 0.56);
         int var15 = var8 ? IIlIIl(this.l.lllII(), var14) : this.IlI(var14);
         IIIIIIllI.IllIll(this.lI, var1 - (double)1.0F, var3 - (double)1.0F, var5 + (double)2.0F, var5 + (double)2.0F, (double)8.0F, var15);
         IIIIIIllI.ll(this.lI, var1, var3, var5, var5, (double)7.0F, IIlIIl(var12, var11), IIlIIl(var13, var11));
      }
   }

   void lIl(Object var1, double var2, double var4, int var6, double var7) {
      <undefinedtype> var9 = this.lIIl(var1, var7);
      this.IIIll(var9, var2 - (double)this.lIII(var9) * (double)0.5F, var4, var6);
   }

   void llI(double var1, double var3, double var5, double var7, boolean var9, boolean var10) {
      this.II(var1, var3, var5, var7, var9, var10, (double)1.0F);
   }

   void lll(double var1, double var3, double var5, double var7, String var9) {
      this.l(var1, var3, var5, var7, var9, true, (double)1.0F);
   }

   int IIII(IIllIIlII var1, double var2, double var4, int var6) {
      int var7 = (int)Math.round(IlIlI((double)var6, (double)0.0F, (double)255.0F));
      return var7 <= 0 ? 0 : IIlIIl(this.l.lllII(), var7);
   }

   void IIIl(IIIlIlIII var1, double var2, double var4, double var6, double var8, boolean var10) {
      int var11 = var10 ? IIlIll(-1608843836, -71079292) : IIlIll(-1608843835, -631722547);
      int var12 = var10 ? this.IllIl() : this.IIIlII();
      double var15 = var4 + Math.max((double)0.0F, (var8 - var8) * (double)0.5F);
      IIIIIIllI.IllIll(this.lI, var2, var15, var6, var8, IIIIIIllI.IIlII(), var11);
      double var17 = (double)14.0F;
      double var19 = IIIIIIllI.IllII();
      <undefinedtype> var21 = this.lIIl(var1.I(), Math.max((double)0.0F, var6 - var17 - var19 - IIIIIIllI.IllII() * (double)2.0F));
      double var22 = var17 + var19 + (double)this.lIII(var21);
      double var24 = var2 + Math.max(IIIIIIllI.IllII(), (var6 - var22) * (double)0.5F);
      <undefinedtype> var10001;
      switch (var1) {
         case l -> var10001 = Il;
         case II -> var10001 = lII;
         case I -> var10001 = lllI;
         case lI -> var10001 = Illl;
         default -> var10001 = llI;
      }

      this.llIlI(I(var10001), var24, var15 + (var8 - var17) * (double)0.5F, var17, var12);
      this.IIIll(var21, var24 + var17 + var19, this.Ill(var15, var8), var12);
   }

   void IIlI(double var1, double var3, double var5, double var7, boolean var9) {
      IIIIIIllI.llI(this.lI, var1, var3, var5, var7, (double)10.0F, IIlIll(-1608843834, -205065521), (double)8.0F, IIlIll(-1608843833, 2043209918), 0.45);
      IIIIIIllI.IllIll(this.lI, var1, var3, var5, var7, (double)10.0F, IIlIll(-1608843832, -747588986));
   }

   private void IIll(String var1, double var2, double var4, double var6, double var8, double var10) {
      double var12 = (double)8.0F;
      String var14 = IIIIIIllI.lIlIlI(this.lIII, var1, Math.max((double)0.0F, var6 - var12 * (double)2.0F) / var10);
      double var15 = var2 + (var6 - (double)this.IIl(var14) * var10) * (double)0.5F;
      double var17 = var4 + (var8 - IIIIIIllI.lllIII(this.lIII) * var10) * (double)0.5F;
      this.Il(var14, var15, var17, -1, var10);
   }

   void IlII(Object var1, double var2, double var4, double var6, int var8) {
      this.IIIll(this.lIIl(var1, var6), var2, var4, var8);
   }

   void IlIl(double var1, double var3, double var5, double var7, Object var9, boolean var10, double var11) {
      <undefinedtype> var13 = var9 == null ? lIlIII.III("") : var9;
      int var14 = var10 ? IIlIll(-1608843831, -1903651304) : IIlIll(-1608843830, 650206803);
      int var15 = IIlIll(-1608843829, -191737963);
      byte var16 = -1;
      double var17 = Math.min(IIIIIIllI.IIlII(), var7 * (double)0.5F);
      IIIIIIllI.IllIll(this.lI, var1, var3, var5, var7, var17, var14);
      IIIIIIllI.lllII(this.lI, var1, var3, var5, var7, var17, var15);
      double var19 = IIIIIIllI.IllII();
      double var21 = var11 <= (double)0.0F ? (double)1.0F : var11;
      double var23 = Math.max((double)0.0F, var5 - var19 * (double)2.0F) / var21;
      <undefinedtype> var25 = this.lIIl(var13, var23);
      double var26 = (double)this.lIII(var25) * var21;
      double var28 = var1 + (var5 - var26) * (double)0.5F;
      double var30 = var3 + (var7 - IIIIIIllI.lllIII(this.lIII) * var21) * (double)0.5F;
      this.llIl(var25, var28, var30, var16, var21);
   }

   void IllI(double var1, double var3, double var5, double var7, String var9, boolean var10) {
      this.IlIII(var1, var3, var5, var7, var9, var10, (double)1.0F);
   }

   void Illl(double var1, double var3, double var5, double var7, double var9, String var11) {
      this.lIIIl(var1, var3, var5, var7, var9, var11, (double)1.0F);
   }

   int lIII(Object var1) {
      if (var1 != null && !var1.ll()) {
         int[] var2 = new int[]{0};
         var1.Ill((var2x) -> var2[0] += this.IIl(lllII(var2x)));
         return var2[0];
      } else {
         return 0;
      }
   }

   <undefinedtype> lIIl(Object var1, double var2) {
      if (var1 != null && !var1.ll() && !(var2 <= (double)0.0F)) {
         if ((double)this.lIII(var1) <= var2) {
            return var1;
         } else {
            int var4 = this.lIII(IIIl);
            int[] var5 = new int[]{0};
            int[] var6 = new int[]{0};
            boolean[] var7 = new boolean[]{true};
            var1.Ill((var7x) -> {
               if (var7[0]) {
                  int var8 = this.IIl(lllII(var7x));
                  if ((double)(var6[0] + var8 + var4) > var2) {
                     var7[0] = false;
                  } else {
                     var6[0] += var8;
                     int var10002 = var5[0]++;
                  }
               }
            });
            return var1.l(var5[0]).IIII(IIIl);
         }
      } else {
         return lIlIII.III("");
      }
   }

   int lIlI(int var1) {
      return IIlIIl(this.l.lllI(), var1);
   }

   void lIll(double var1, double var3, double var5, boolean var7, boolean var8) {
      this.llI(var1, var3, var5, (double)25.0F, var7, var8);
   }

   void llII(String var1, double var2, double var4, int var6, double var7) {
      String var9 = this.IIlll(var1, var7);
      this.llIII(var9, var2 - (double)this.IIl(var9) * (double)0.5F, var4, var6);
   }

   void llIl(Object var1, double var2, double var4, int var6, double var7) {
      if (var1 != null && !var1.lIIl()) {
         if (var7 == (double)1.0F) {
            this.IIIll(var1, var2, var4, var6);
         } else {
            IIIIIIllI.IIIllI(this.lI);

            try {
               IIIIIIllI.IlII(this.lI, var2, var4);
               IIIIIIllI.lllI(this.lI, var7, var7);
               this.IIIll(var1, (double)0.0F, (double)0.0F, var6);
            } finally {
               IIIIIIllI.lIIlIl(this.lI);
            }

         }
      }
   }

   void lllI(lIllII var1, double var2, double var4, int var6) {
      <undefinedtype> var10001;
      switch (null.I[var1.ordinal()]) {
         case 1 -> var10001 = lIIl;
         case 2 -> var10001 = II;
         case 3 -> var10001 = llIl;
         case 4 -> var10001 = IlII;
         case 5 -> var10001 = Il;
         case 6 -> var10001 = llI;
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      this.llIlI(I(var10001), var2, var4, (double)14.0F, var6);
   }

   int llll(int var1) {
      return IIlIIl(IIIIII(this.l.IIIIIl(), this.l.lllII(), 0.055), var1);
   }

   void IIIII(double var1, double var3, int var5) {
      this.llIlI(I(IlIl), var1, var3, (double)14.0F, var5);
   }

   private void IIIIl(double var1, double var3, double var5, String var7, double var8) {
      if (var7 != null && !var7.isBlank()) {
         double var10 = Math.max((double)14.0F, var5 - (double)4.0F) / var8;
         String var12 = this.IlllI(var7, var10);
         double var13 = (double)this.IIl(var12) * var8;
         double var15 = var3 + ((double)24.0F - IIIIIIllI.lllIII(this.lIII) * var8) * (double)0.5F;
         this.Il(var12, var1 + var5 - var13, var15, -1, var8);
      }
   }

   void IIIlI(double var1, double var3, boolean var5) {
      IIIIIIllI.IIlIl(this.lI, var1, var3, var5, var5 ? IIlIll(-1608843828, 1309114971) : IIlIll(-1608843827, -1690420528), -1);
   }

   void IIIll(Object var1, double var2, double var4, int var6) {
      if (var1 != null && !var1.lIIl()) {
         int var7 = IIII.equals(var1) ? this.lI() : var6;
         double[] var8 = new double[]{var2};
         var1.Ill((var5) -> {
            String var6 = lllII(var5);
            IIIIIIllI.llIl(this.lI, this.lIII, var6, var8[0], var4, var7);
            var8[0] += (double)this.IIl(var6);
         });
      }
   }

   private void IIlII(double var1, double var3, double var5, String var7) {
      this.IIIIl(var1, var3, var5, var7, (double)1.0F);
   }

   public void IIlIl(int var1, int var2) {
   }

   void IIllI(String var1, double var2, double var4, double var6, int var8) {
      this.llIII(this.IIlll(var1, var6), var2, var4, var8);
   }

   String IIlll(String var1, double var2) {
      if (var1 != null && !var1.isEmpty()) {
         if ((double)this.IIl(var1) <= var2) {
            return var1;
         } else {
            String var4 = lIlIII.Il(IIllII(176852126, 813393698));
            int var5 = this.IIl(var4);
            StringBuilder var6 = new StringBuilder(var1.length());

            for(int var7 = 0; var7 < var1.length(); ++var7) {
               String var10000 = var6.toString();
               char var10 = var1.charAt(var7);
               String var9 = var10000;
               String var8 = var9 + var10;
               if ((double)(this.IIl(var8) + var5) > var2) {
                  break;
               }

               var6.append(var1.charAt(var7));
            }

            return var6.append(var4).toString();
         }
      } else {
         return "";
      }
   }

   void IlIII(double var1, double var3, double var5, double var7, String var9, boolean var10, double var11) {
      int var13 = var10 ? IIlIll(-1608843826, -2139858036) : IIlIll(-1608843825, -836847079);
      int var14 = IIlIll(-1608843824, 823244621);
      byte var15 = -1;
      if (var11 == (double)1.0F) {
         IIIIIIllI.llIlll(this.lI, this.lIII, var9, var1, var3, var5, var7, false, var13, var14, var15);
      } else {
         double var16 = Math.min((double)4.5F, var7 * (double)0.5F);
         IIIIIIllI.IllIll(this.lI, var1, var3, var5, var7, var16, var14);
         IIIIIIllI.IllIll(this.lI, var1 + (double)1.0F, var3 + (double)1.0F, var5 - (double)2.0F, var7 - (double)2.0F, Math.max((double)1.0F, var16 - (double)1.0F), var13);
         double var18 = (double)8.0F;
         double var20 = Math.max((double)0.0F, var5 - var18 * (double)2.0F) / var11;
         String var22 = IIIIIIllI.lIlIlI(this.lIII, var9, var20);
         double var23 = (double)this.IIl(var22) * var11;
         double var25 = var1 + (var5 - var23) * (double)0.5F;
         double var27 = var3 + (var7 - IIIIIIllI.lllIII(this.lIII) * var11) * (double)0.5F;
         this.Il(var22, var25, var27, var15, var11);
      }
   }

   void IlIIl(IIIlIlIII var1, double var2, double var4, int var6) {
      <undefinedtype> var10001;
      switch (var1) {
         case l -> var10001 = Il;
         case II -> var10001 = lII;
         case I -> var10001 = lllI;
         case lI -> var10001 = Illl;
         default -> var10001 = llI;
      }

      this.llIlI(I(var10001), var2, var4, (double)14.0F, var6);
   }

   static double IlIlI(double var0, double var2, double var4) {
      return Math.max(var2, Math.min(var4, var0));
   }

   int IlIll() {
      return IIlIIl(this.l.IIlIII(), IIlIll(-1608843823, -913800352));
   }

   private static String IllII() {
      return lIlIII.Il(IIllII(176852127, -83412650));
   }

   int IllIl() {
      return IIlIIl(this.l.lllII(), IIlIll(-1608843822, 1903025827));
   }

   private String IlllI(String var1, double var2) {
      if (var1 != null && !var1.isEmpty() && !((double)this.IIl(var1) <= var2)) {
         int var4;
         int var5;
         for(var4 = var1.length(); var4 > 0; var4 -= Character.charCount(var5)) {
            var5 = var1.codePointBefore(var4);
            if (Character.isDigit(var5) || var5 == IIlIll(-1608843821, 1282098726) || var5 == IIlIll(-1608843820, -590037562) || var5 == IIlIll(-1608843819, 12191226)) {
               break;
            }
         }

         if (var4 > 0 && var4 < var1.length()) {
            String var11 = var1.substring(var4);
            double var6 = (double)this.IIl(var11);
            if (var6 >= var2) {
               return this.IIlll(var1, var2);
            } else {
               String var8 = this.IIlll(var1.substring(0, var4), Math.max((double)0.0F, var2 - var6));
               return var8.isBlank() ? var11 : var8 + var11;
            }
         } else {
            return this.IIlll(var1, var2);
         }
      } else {
         return var1 == null ? "" : var1;
      }
   }

   int Illll(int var1) {
      return IIlIIl(this.l.IlIII(), var1);
   }

   void lIIII(class_332 var1, class_327 var2, lIIIllll var3) {
      this.lI = var1;
      this.lIII = var2;
      this.l = var3;
   }

   void lIIIl(double var1, double var3, double var5, double var7, double var9, String var11, double var12) {
      double var14 = IlIlI(Math.min(var7, var9), (double)0.0F, (double)1.0F);
      double var16 = IlIlI(Math.max(var7, var9), (double)0.0F, (double)1.0F);
      double var18 = var3 + (double)16.0F;
      double var20 = (double)6.0F;
      double var22 = lIllI(var1, var5, var14);
      double var24 = lIllI(var1, var5, var16);
      double var26 = var22 - var20;
      double var28 = Math.max((double)12.0F, var24 - var22 + (double)12.0F);
      IIIIIIllI.IllIll(this.lI, var1, var18, var5, (double)12.0F, var20, IIlIll(-1608843818, -1647209192));
      IIIIIIllI.IllIll(this.lI, var26, var18, var28, (double)12.0F, var20, this.lI());
      IIIIIIllI.IllIll(this.lI, var22 - (double)4.0F, var18 + (double)2.0F, (double)8.0F, (double)8.0F, (double)4.0F, -1);
      IIIIIIllI.IllIll(this.lI, var24 - (double)4.0F, var18 + (double)2.0F, (double)8.0F, (double)8.0F, (double)4.0F, -1);
      this.IIIIl(var1, var3, var5, var11, var12);
   }

   void lIIlI(double var1, double var3, double var5, double var7, String var9, double var10) {
      this.l(var1, var3, var5, var7, var9, true, var10);
   }

   int lIlII(int var1) {
      return IIlIIl(IIIIII(this.l.IIlIII(), this.l.IIIIIl(), 0.72), var1);
   }

   void lIlIl(Object var1, double var2, double var4, double var6, int var8, double var9) {
      double var11 = var6 / var9;
      this.llIl(this.lIIl(var1, var11), var2, var4, var8, var9);
   }

   private static double lIllI(double var0, double var2, double var4) {
      double var6 = (double)6.0F;
      return var0 + IlIlI(var2 * var4, var6, Math.max(var6, var2 - var6));
   }

   void lIlll(class_2960 var1, double var2, double var4, double var6, int var8) {
      IIIIIIllI.IllIl(this.lI, var1, var2, var4, var6, var6, IIlIll(-1608843817, -566562229), IIlIll(-1608843816, 313832366), var8);
   }

   void llIII(String var1, double var2, double var4, int var6) {
      if (var1 != null && !var1.isBlank()) {
         int var7 = IIII.equals(var1) ? this.lI() : var6;
         IIIIIIllI.llIl(this.lI, this.lIII, var1, var2, var4, var7);
      }
   }

   void llIlI(class_2960 var1, double var2, double var4, double var6, int var8) {
      IIIIIIllI.IllllI(this.lI, var1, var2, var4, var6, var6, var8);
   }

   void llIll(double var1, double var3, int var5) {
      this.llIlI(I(Ill), var1, var3, (double)14.0F, var5);
   }

   private static String lllII(int var0) {
      return new String(Character.toChars(var0));
   }

   int lllIl(int var1) {
      return IIlIIl(this.l.IIllII(), var1);
   }

   void llllI(double var1, double var3, double var5, double var7, double var9, IIllIIlII var11, boolean var12, double var13) {
      int var15 = (int)Math.round(IlIlI(var13, (double)0.0F, (double)1.0F) * (double)255.0F);
      if (var15 > 0 && !(var5 <= (double)0.0F) && !(var7 <= (double)0.0F) && !(var9 <= (double)0.0F)) {
         double var16 = (double)5.5F;
         IIIIIIllI.IllIll(this.lI, var1, var3, var5, var7, var16, this.lIlII(var15));
         IIIIIIllI.lllII(this.lI, var1, var3, var5, var7, var16, var12 ? this.lllIl(Math.min(var15, IIlIll(-1608843815, 567517472))) : this.IlI((int)((double)var15 * 0.62)));
         double var18 = (double)2.0F;
         double var20 = Math.max((double)1.0F, Math.min(var9 - var18, var7 - var18 * (double)2.0F));
         Color var22 = var11.Il() == null ? this.l.IIllII() : var11.Il();
         Color var23 = var11.Ill() == null ? this.l.IlIII() : var11.Ill();
         IIIIIIllI.ll(this.lI, var1 + var18, var3 + var18, Math.max((double)1.0F, var5 - var18 * (double)2.0F), var20, (double)4.0F, IIlIIl(var22, var15), IIlIIl(var23, var15));
      }
   }

   void lllll(double var1, double var3, boolean var5, int var6) {
      this.llIlI(I(var5 ? IllI : lIll), var1, var3, (double)14.0F, var6);
   }

   static Color IIIIII(Color var0, Color var1, double var2) {
      double var4 = IlIlI(var2, (double)0.0F, (double)1.0F);
      Color var6 = var0 == null ? Color.WHITE : var0;
      Color var7 = var1 == null ? Color.WHITE : var1;
      return new Color((int)Math.round((double)var6.getRed() + (double)(var7.getRed() - var6.getRed()) * var4), (int)Math.round((double)var6.getGreen() + (double)(var7.getGreen() - var6.getGreen()) * var4), (int)Math.round((double)var6.getBlue() + (double)(var7.getBlue() - var6.getBlue()) * var4), (int)Math.round((double)var6.getAlpha() + (double)(var7.getAlpha() - var6.getAlpha()) * var4));
   }

   void IIIIIl(double var1, double var3, int var5) {
      this.llIlI(I(llII), var1, var3, (double)14.0F, var5);
   }

   void IIIIlI(double var1, double var3, double var5, double var7, String var9, String var10, double var11, double var13) {
      int var15 = IIlIll(-1608843814, 176535429);
      double var16 = Math.min((double)4.0F, var7 * (double)0.5F);
      IIIIIIllI.IllIll(this.lI, var1, var3, var5, var7, var16, var15);
      double var18 = (double)1.0F - Math.pow((double)1.0F - Math.max((double)0.0F, Math.min((double)1.0F, var11)), (double)3.0F);
      IIIIIIllI.lIlll(this.lI, var1, var3, var1 + var5, var3 + var7, (double)0.0F);

      try {
         if (var9 != null && !var9.isBlank() && var18 < (double)1.0F) {
            this.IIll(var9, var1, var3 - var7 * var18, var5, var7, var13);
         }

         this.IIll(var10, var1, var3 + var7 * ((double)1.0F - var18), var5, var7, var13);
      } finally {
         IIIIIIllI.lIII(this.lI);
      }

   }

   int IIIIll() {
      return IIlIIl(this.l.IIIIIl(), IIlIll(-1608843813, -2050911679));
   }

   int IIIlII() {
      return IIlIIl(this.l.IIlIl(), IIlIll(-1608843812, 1965408524));
   }

   private static int IIIlIl(int var0, int var1) {
      int var2 = Math.max(0, Math.min(IIlIll(-1608843811, -1823364351), var1));
      return var2 << IIlIll(-1608843810, -811896943) | var0 & IIlIll(-1608843809, -870241119);
   }

   void IIIllI(String var1, double var2, double var4, double var6, int var8, double var9) {
      double var11 = var6 / var9;
      this.Il(this.IIlll(var1, var11), var2, var4, var8, var9);
   }

   int IIIlll(int var1) {
      return IIlIIl(IIIIII(this.l.IIIIIl(), this.l.IIllII(), 0.18), var1);
   }

   void IIlIII(double var1, double var3, double var5, IIllIIlII var7, boolean var8) {
      this.lII(var1, var3, var5, var7, var8, (double)1.0F);
   }

   static int IIlIIl(Color var0, int var1) {
      Color var2 = var0 == null ? Color.WHITE : var0;
      int var3 = Math.max(0, Math.min(IIlIll(-1608843808, -1943097059), var1));
      return var3 << IIlIll(-1608843807, -364793685) | (var2.getRed() & IIlIll(-1608843806, 997654169)) << IIlIll(-1608843805, 686115111) | (var2.getGreen() & IIlIll(-1608843804, 485340654)) << IIlIll(-1608843803, 1347622867) | var2.getBlue() & IIlIll(-1608843802, 1798136726);
   }

   void IIlIlI(double var1, double var3, double var5, double var7, Object var9, boolean var10) {
      this.IlIl(var1, var3, var5, var7, var9, var10, (double)1.0F);
   }

   private static int IIlIll(int var0, int var1) {
      return llll[var0 ^ -1608843840] ^ var1 ^ var0;
   }

   private static String IIllII(int var0, int var1) {
      int var3 = var0 ^ 176852108;
      char[] var4 = IIIII[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IIIIl[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IIIIl[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 1918724224;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 228;
               break;
            case 1:
               var9 = 68;
               break;
            case 2:
               var9 = 113;
               break;
            case 3:
               var9 = 110;
               break;
            case 4:
               var9 = 100;
               break;
            case 5:
               var9 = 133;
               break;
            case 6:
               var9 = 77;
               break;
            case 7:
               var9 = 78;
               break;
            case 8:
               var9 = 164;
               break;
            case 9:
               var9 = 31;
               break;
            case 10:
               var9 = 112;
               break;
            case 11:
               var9 = 175;
               break;
            case 12:
               var9 = 96;
               break;
            case 13:
               var9 = 132;
               break;
            case 14:
               var9 = 164;
               break;
            case 15:
               var9 = 192;
               break;
            case 16:
               var9 = 171;
               break;
            case 17:
               var9 = 237;
               break;
            case 18:
               var9 = 23;
               break;
            case 19:
               var9 = 221;
               break;
            case 20:
               var9 = 107;
               break;
            case 21:
               var9 = 179;
               break;
            case 22:
               var9 = 235;
               break;
            case 23:
               var9 = 60;
               break;
            case 24:
               var9 = 87;
               break;
            case 25:
               var9 = 230;
               break;
            case 26:
               var9 = 110;
               break;
            case 27:
               var9 = 224;
               break;
            case 28:
               var9 = 24;
               break;
            case 29:
               var9 = 185;
               break;
            case 30:
               var9 = 84;
               break;
            case 31:
               var9 = 28;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
