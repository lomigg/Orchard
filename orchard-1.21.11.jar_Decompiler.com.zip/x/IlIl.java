package x;

import java.util.Objects;
import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2596;
import net.minecraft.class_2824;
import net.minecraft.class_2846;
import net.minecraft.class_2879;
import net.minecraft.class_2885;
import net.minecraft.class_2886;
import net.minecraft.class_310;
import net.minecraft.class_746;

@Environment(EnvType.CLIENT)
public final class IlIl extends IIIIIIIlI {
   private int I;
   private int l;
   private final IlIIIlIlI<<undefinedtype>> II;
   private final IIIllIIII Il;
   private static final long lI = 25L;
   private boolean ll;
   private long III;
   private long IIl;
   private long IlI;
   private final lIIIIl Ill;
   private boolean lII;
   private final lIIIIl lIl;
   private final llllIlIl llI;
   private static final long lll = 300L;
   private int IIII;
   private final lIIIIl IIIl;
   private final lIIIIl IIlI;
   private final llllIlIl IIll;
   private long IlII;
   private long IlIl;
   private static final int[] IllI;
   private static final String[] Illl;
   private static final Object[] lIII;

   public boolean ll(class_2596<?> var1) {
      return this.IIIII(class_310.method_1551()) && (var1 instanceof class_2824 || var1 instanceof class_2885 || var1 instanceof class_2886 || var1 instanceof class_2846 || var1 instanceof class_2879);
   }

   private void IlI(class_310 var1, class_746 var2) {
      int var3 = IllllIlI.lIIlI(var2.method_31548());
      if (!this.llI(var2.method_31548().method_5438(var3))) {
         int var4 = this.IIIIl(var2, var3);
         if (var4 >= 0) {
            this.l = var3;
            long var9 = System.currentTimeMillis();
            this.IlIl = var9;
            long var7 = this.IlII();
            IllllIlI.IIlIlI(var1, var4, true);
            if ((Boolean)this.Ill.III() && this.l >= 0 && this.l != var4) {
               this.III = var9 + var7 + 250L;
            }

         } else {
            if (!this.IIII(var2) && this.IlIl(var2)) {
               long var5 = System.currentTimeMillis();
               this.IlIl = var5;
               this.IlII = var5;
               this.IlI = Long.MIN_VALUE;
               this.IIII = -1;
               this.lII = false;
               this.ll = false;
            }

         }
      }
   }

   public void lI() {
      this.I = IIllI(-101599241, 382360905);
      this.Illl();
   }

   private boolean llI(class_1799 var1) {
      return var1 != null && !var1.method_7960() && var1.method_7909() == class_1802.field_8288;
   }

   public void lll() {
      class_310 var1 = class_310.method_1551();
      if (this.IIIIIlI() && var1 != null && var1.field_1724 != null) {
         if (!(Boolean)this.IIlI.III() || var1.field_1755 == null) {
            if (!((Double)this.Il.III() > (double)0.0F) || !(var1.field_1724.method_6032() > (float)(Double)this.Il.III())) {
               if (this.I != var1.field_1724.field_6012) {
                  this.I = var1.field_1724.field_6012;
                  if (this.II.III() == null.Il) {
                     this.IlI(var1, var1.field_1724);
                  } else if (this.IIII(var1.field_1724)) {
                     this.Illl();
                  } else if (!this.IlIl(var1.field_1724)) {
                     this.Illl();
                  } else {
                     long var2 = System.currentTimeMillis();
                     this.IlIl = var2;
                     this.IlII = var2;
                     this.IlI = Long.MIN_VALUE;
                     this.IIII = -1;
                     this.lII = false;
                     this.ll = false;
                  }
               }
            }
         }
      }
   }

   private boolean IIII(class_746 var1) {
      return var1 != null && this.llI(var1.method_6079());
   }

   public IlIl() {
      super((Object)lIlIII.l(IIlll('눥', 28520, 1590702757)), lIllII.I, (Object)lIlIII.l(IIlll('천', 28521, 1005666976)));
      this.II = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IIlll('﹖', 28522, 180300782)), <undefinedtype>.class, null.I));
      this.IIll = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(IIlll('쵦', 28523, 39662634)), (double)0.0F, (double)0.0F, (double)0.0F, (double)300.0F, (double)5.0F)).Ill(lIlIII.l(IIlll('⏊', 28524, -775457085))));
      this.llI = (llllIlIl)this.IIIlIll((llllIlIl)(new llllIlIl(lIlIII.l(IIlll('狛', 28525, 1903505084)), (double)85.0F, (double)170.0F, (double)0.0F, (double)300.0F, (double)5.0F)).Ill(lIlIII.l(IIlll('₯', 28526, 1812008461))).lIII(() -> false));
      this.lIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIlll('\u20c8', 28527, 519123587)), false));
      IIIllIIII var10002 = (new IIIllIIII(lIlIII.l(IIlll('ᅙ', 28512, 2075657061)), (double)10.0F, (double)1.0F, (double)20.0F, (double)0.5F)).IIIl(lIlIII.l(IIlll('踼', 28513, 342647752)));
      lIIIIl var10003 = this.lIl;
      Objects.requireNonNull(var10003);
      this.Il = (IIIllIIII)this.IIIlIll((IIIllIIII)var10002.lIII(var10003::III));
      this.IIIl = (lIIIIl)this.IIIlIll((lIIIIl)(new lIIIIl(lIlIII.l(IIlll('ꋀ', 28514, -2118224152)), true)).lIII(() -> false));
      this.Ill = (lIIIIl)this.IIIlIll((lIIIIl)(new lIIIIl(lIlIII.l(IIlll('\udd01', 28515, 516703495)), true)).lIII(() -> false));
      this.IIlI = (lIIIIl)this.IIIlIll((lIIIIl)(new lIIIIl(lIlIII.l(IIlll('䟧', 28516, -304741276)), false)).lIII(() -> false));
      this.I = IIllI(-101599242, 723847630);
      this.IlII = Long.MIN_VALUE;
      this.IlI = Long.MIN_VALUE;
      this.IlIl = Long.MIN_VALUE;
      this.IIII = -1;
      this.IIl = Long.MIN_VALUE;
      this.l = -1;
      this.III = Long.MIN_VALUE;
   }

   private long IlII() {
      long var1 = System.currentTimeMillis();
      boolean var3 = this.IlIl != Long.MIN_VALUE && var1 - this.IlIl <= 1500L;
      llllIlIl var4 = var3 ? this.llI : this.IIll;
      long var5 = Math.min(300L, Math.max(0L, Math.round(var4.IlII())));
      long var7 = Math.min(300L, Math.max(var5, Math.max(0L, Math.round(var4.IlI()))));
      long var9 = var5 == var7 ? var5 : ThreadLocalRandom.current().nextLong(var5, var7 + 1L);
      if (this.IIl != Long.MIN_VALUE && Math.abs(var9 - this.IIl) < 25L) {
         long var11 = var9 > this.IIl ? var9 + 25L : var9 - 25L;
         var9 = Math.max(var5, Math.min(var7, var11));
      }

      this.IIl = var9;
      return var9;
   }

   private boolean IlIl(class_746 var1) {
      return var1 != null && (this.IIII(var1) || this.IIlIl(var1) >= 0);
   }

   private void Illl() {
      this.llII();
      this.l = -1;
   }

   private void lIII(class_310 var1) {
      if ((Boolean)this.IIIl.III() && var1 != null && var1.field_1724 != null) {
         if (!this.lII) {
            lIlIllll.lll(var1);
            this.lII = true;
         }

      }
   }

   public void lIIl(class_310 var1) {
      if (var1 != null && var1.field_1724 != null && var1.field_1761 != null) {
         if (this.IIIIIlI() && this.IlII != Long.MIN_VALUE && this.IIII >= 0) {
            if (!(Boolean)this.IIIl.III() || lIlIllll.lllI(var1)) {
               long var2 = System.currentTimeMillis();
               if (var2 >= this.IlI) {
                  class_746 var4 = var1.field_1724;
                  int var5 = this.IIII;
                  if (var5 >= 0 && var5 < var4.field_7498.field_7761.size() && this.llI(((class_1735)var4.field_7498.field_7761.get(var5)).method_7677()) && var4.field_7498.method_34255().method_7960()) {
                     this.IIII = -1;
                     this.IlI = Long.MIN_VALUE;
                     this.lII = false;
                     this.ll = false;
                     lIlIllll.IllI(var1);
                     var1.field_1761.method_2906(var4.field_7498.field_7763, var5, IIllI(-101599243, -1218928392), class_1713.field_7791, var4);
                  } else {
                     this.ll = true;
                  }
               }

               this.lllI(var2);
            }
         }
      }
   }

   public void lIll() {
      this.lll();
   }

   public void Ill() {
      if (!this.IIIIIlI()) {
         this.Illl();
      } else {
         class_310 var1 = class_310.method_1551();
         long var2 = System.currentTimeMillis();
         if (this.III != Long.MIN_VALUE && var2 >= this.III) {
            this.III = Long.MIN_VALUE;
            if ((Boolean)this.Ill.III() && this.l >= 0 && this.l < IIllI(-101599244, 621685654) && var1 != null && var1.field_1724 != null) {
               IllllIlI.IIlIlI(var1, this.l, true);
               this.l = -1;
            }
         }

         if ((Boolean)this.lIl.III() && var1 != null && var1.field_1724 != null && var1.field_1724.method_6032() <= (float)(Double)this.Il.III() && !this.IIII(var1.field_1724) && this.IlIl(var1.field_1724) && this.IlII == Long.MIN_VALUE) {
            this.IlII = var2;
            this.IlIl = var2;
         }

         if (this.IlII != Long.MIN_VALUE) {
            if (var2 - this.IlIl > 1000L) {
               this.Illl();
            } else if (var1 != null && var1.field_1724 != null && var1.field_1761 != null) {
               class_746 var4 = var1.field_1724;
               if (this.IIII(var4)) {
                  this.llII();
               } else {
                  int var5 = this.IIlIl(var4);
                  boolean var6 = this.IIII >= 0 && this.IIII < var4.field_7498.field_7761.size() && this.llI(((class_1735)var4.field_7498.field_7761.get(this.IIII)).method_7677());
                  if (!var6 && var5 < 0) {
                     this.Illl();
                  } else if (this.IIII < 0) {
                     this.IIII = var5;
                     this.IlI = var2 + this.IlII();
                     this.ll = false;
                     this.lIII(var1);
                  } else {
                     if (!var6) {
                        this.IIII = var5;
                        this.ll = true;
                        this.lllI(var2);
                     }

                  }
               }
            }
         }
      }
   }

   private void llII() {
      this.IlII = Long.MIN_VALUE;
      this.IlI = Long.MIN_VALUE;
      this.IlIl = Long.MIN_VALUE;
      this.IIII = -1;
      this.lII = false;
      this.ll = false;
      this.III = Long.MIN_VALUE;
   }

   private void lllI(long var1) {
      if (this.ll && this.IIII >= 0) {
         this.ll = false;
         this.lIII(class_310.method_1551());
         this.IlI = var1 + this.IlII();
      }
   }

   public String Il() {
      return ((<undefinedtype>)this.II.III()).toString();
   }

   public void lIl() {
      this.I = IIllI(-101599245, -402429888);
      this.Illl();
   }

   public boolean IIIII(class_310 var1) {
      return this.IIIIIlI() && this.IlII != Long.MIN_VALUE && System.currentTimeMillis() - this.IlIl <= 1000L;
   }

   private int IIIIl(class_746 var1, int var2) {
      for(int var3 = 0; var3 < IIllI(-101599246, -460599550); ++var3) {
         if (var3 != var2 && this.llI(var1.method_31548().method_5438(var3))) {
            return var3;
         }
      }

      return -1;
   }

   private int IIlIl(class_746 var1) {
      for(int var2 = IIllI(-101599247, -4022492); var2 < IIllI(-101599248, -1766596016); ++var2) {
         if (this.llI(((class_1735)var1.field_7498.field_7761.get(var2)).method_7677())) {
            return var2;
         }
      }

      return -1;
   }

   private static int IIllI(int var0, int var1) {
      return IllI[var0 ^ -101599241] ^ var1 ^ var0;
   }

   static {
      short var6 = 861;
      String var7 = "\udee7\ude7b\ude3c\ude07\udeca\ude22\udeda\ude8c\udeca\uded9\udec8\udec0\udebc\ude83\ude2b\ude13쭃쬖쒴씝쭩씭씠쬜씧쒿쭐쭌쒴쓒쭚쭾씱쒒쭜쓳쭣쭰쒺씩씽쬖쭢씀씨쒹쭩쬃쭬쒢쭠쭦쭍앬쭄쭭쭐쭗쭟앨쒇쒌씶쭚쭊앨쭈쒍쒽쭅쒚쬙쒅쒿쒸쭘쭩쓓쭁쒊쭠쒓쭪쬢쭭쭚쒑쒿쒶쬕쒙쒊쭆쭅쒴쬄쭂쒏쒜쒞웞왰웚욃웠욶옛왓벮벺썺벹벝버썽쌡\uef82\uefd3\ueff5\uef8b滑弄炙廊冷離濫櫓朗累藍駱癩領笠理㸥㺴㸪㻤㎓㈛㎪㎣㎐㉩㉠㈶㏵㏌㏲㎁㉡㏙㉯㉗惕恸惈悀惦惎怗悤陈阈陦鞲Ὥᣳ᤻ά\u1f5eᢽᢑᣠ릣맶맔맚맀망맜릘맄맼뤰맀맔릤말맔Ꞧ꘣ꞦꞳꞑꞅꞞ꘣ꞎꙛꞤꞔꟵ\ua62eꙣꞩꟾꞯꙢꘛ";
      char[] var8 = "\u0010T\b\b\u0004\u0010\u0004\u0010\b\u0004\b\u0010\u0014".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            Illl = var9;
            lIII = new Object[var9.length];
            int var2 = 1241583531;
            byte[] var0 = "%:å\u0015\u0018Õ±\u0093\u0004¨\u0018\u008e\u0096þ\u0093ÀÛóÐ\u0018W{wRL2'w%CZ&".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IllI = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IllI[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 19;
                     break;
                  case 1:
                     var10000 = 91;
                     break;
                  case 2:
                     var10000 = 23;
                     break;
                  case 3:
                     var10000 = 47;
                     break;
                  case 4:
                     var10000 = 24;
                     break;
                  case 5:
                     var10000 = 26;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static String IIlll(char var0, int var1, int var2) {
      int var3 = var1 ^ 28520;
      char[] var4 = Illl[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])lIII[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         lIII[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 2414;
      int var9 = 0;

      do {
         int var10 = var4[var9] + 16669;
         var10 -= 21235;
         var10 -= 16378;
         var10 -= 9829;
         var10 ^= 38441;
         var10 ^= 47380;
         var10 -= 20484;
         var10 += 27032;
         var10 -= 7453;
         var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var2 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
