package x;

import java.util.HashSet;
import java.util.Set;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1661;
import net.minecraft.class_1684;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;

@Environment(EnvType.CLIENT)
public final class lIII extends IIIIIIIlI {
   private final IlIIIlIlI<<undefinedtype>> I;
   private final Set<Integer> l;
   private final lIIIIl II;
   private static final int[] Il;
   private static final String[] lI;
   private static final Object[] ll;

   private int ll(class_1661 var1, class_1792 var2) {
      if (var1 != null && var2 != null) {
         for(int var3 = 0; var3 < llI(281884146, 876879421); ++var3) {
            if (var1.method_5438(var3).method_31574(var2)) {
               return var3;
            }
         }

         return -1;
      } else {
         return -1;
      }
   }

   public lIII() {
      super((Object)lIlIII.l(lll(-1191226811, -2092412000)), lIllII.III, (Object)lIlIII.l(lll(-1191226812, 1718551397)));
      this.I = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(lll(-1191226809, 1240538550)), <undefinedtype>.class, null.I));
      this.II = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lll(-1191226810, 1883713018)), false));
      this.l = new HashSet();
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (this.IIIIIlI() && var1.field_1724 != null && var1.field_1687 != null) {
         class_1684 var2 = this.IlI(var1);
         if (var2 != null) {
            class_1297 var3 = var2.method_24921();
            if ((Boolean)this.II.III() && var3 instanceof class_1309) {
               class_1309 var4 = (class_1309)var3;
               if (var1.field_1724.method_6032() < var4.method_6032()) {
                  this.l.add(var2.method_5628());
                  return;
               }
            }

            int var12 = this.ll(var1.field_1724.method_31548(), class_1802.field_8634);
            if (var12 >= 0) {
               this.l.add(var2.method_5628());
               class_243 var5 = new class_243(var2.method_23317(), var2.method_23318(), var2.method_23321());
               class_243 var6 = var1.field_1724.method_33571();
               class_243 var7 = var5.method_1020(var6);
               double var8 = Math.sqrt(var7.field_1352 * var7.field_1352 + var7.field_1350 * var7.field_1350);
               float var10 = (float)(class_3532.method_15349(var7.field_1350, var7.field_1352) * (180D / Math.PI)) - 90.0F;
               float var11 = (float)(-(class_3532.method_15349(var7.field_1351, var8) * (180D / Math.PI)));
               if (this.I.III() == null.Il) {
                  var1.field_1724.method_36456(var10);
                  var1.field_1724.method_36457(var11);
               }

               IlIlIl.IIIlIl(var1, llI(281884147, -324931650), var10, var11, () -> {
                  IllllIlI.llIll(var1, this, var12, () -> {
                     if (var1.field_1724 != null && var1.field_1724.method_31548().method_5438(var12).method_31574(class_1802.field_8634)) {
                        class_1269 var2 = IllllIlI.lllIlI(var1, class_1268.field_5808);
                        boolean var3 = var2.method_23665();
                        if (var3) {
                           var1.field_1724.method_6104(class_1268.field_5808);
                        }

                        return var3;
                     } else {
                        return false;
                     }
                  });
                  return true;
               });
            }
         }
      } else {
         this.l.clear();
      }
   }

   public void lI() {
      this.l.clear();
   }

   private class_1684 IlI(class_310 var1) {
      if (var1.field_1687 != null && var1.field_1724 != null) {
         for(class_1297 var3 : var1.field_1687.method_18112()) {
            if (var3 instanceof class_1684) {
               class_1684 var4 = (class_1684)var3;
               if (!var4.method_31481() && !this.l.contains(var4.method_5628())) {
                  class_1297 var5 = var4.method_24921();
                  if (var5 != null && !var5.method_5667().equals(var1.field_1724.method_5667())) {
                     return var4;
                  }
               }
            }
         }

         return null;
      } else {
         return null;
      }
   }

   private static int llI(int var0, int var1) {
      return Il[var0 ^ 281884146] ^ var1 ^ var0;
   }

   static {
      short var6 = 4135;
      String var7 = "橢橕檋櫔樍櫄樥檐樠櫔櫊樘橵橍横機轆轲辒迢輫迼轡迂輕迳迭輠轅轱轀輝辤輲輹辴迾返迀辠辧轊辁轓轙輥迃轶輒輹辸辜轻迍轲辀轁辸迾轨輚轢輸輶迒輹輆迱辝迴辮迒迶輴辨輠轄輜述輅輭软辀辻ꃞꃼꀀꁪꂳꁄꃷꀤ饯饚馄駛餃駢饍駉餽駝駜餴饺饉饠餾";
      char[] var8 = "့ၣု့".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            lI = var9;
            ll = new Object[var9.length];
            int var2 = -1390212435;
            byte[] var0 = "\u0089ª!kQOÐ\u001a".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            Il = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               Il[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 104;
                     break;
                  case 1:
                     var10000 = 118;
                     break;
                  case 2:
                     var10000 = 127;
                     break;
                  case 3:
                     var10000 = 0;
                     break;
                  case 4:
                     var10000 = 27;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static String lll(int var0, int var1) {
      int var3 = var0 ^ -1191226811;
      char[] var4 = lI[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])ll[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         ll[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 3951334;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 244;
               break;
            case 1:
               var9 = 230;
               break;
            case 2:
               var9 = 61;
               break;
            case 3:
               var9 = 13;
               break;
            case 4:
               var9 = 243;
               break;
            case 5:
               var9 = 75;
               break;
            case 6:
               var9 = 138;
               break;
            case 7:
               var9 = 80;
               break;
            case 8:
               var9 = 248;
               break;
            case 9:
               var9 = 2;
               break;
            case 10:
               var9 = 31;
               break;
            case 11:
               var9 = 164;
               break;
            case 12:
               var9 = 193;
               break;
            case 13:
               var9 = 147;
               break;
            case 14:
               var9 = 131;
               break;
            case 15:
               var9 = 133;
               break;
            case 16:
               var9 = 57;
               break;
            case 17:
               var9 = 220;
               break;
            case 18:
               var9 = 243;
               break;
            case 19:
               var9 = 74;
               break;
            case 20:
               var9 = 13;
               break;
            case 21:
               var9 = 101;
               break;
            case 22:
               var9 = 126;
               break;
            case 23:
               var9 = 90;
               break;
            case 24:
               var9 = 66;
               break;
            case 25:
               var9 = 211;
               break;
            case 26:
               var9 = 107;
               break;
            case 27:
               var9 = 210;
               break;
            case 28:
               var9 = 183;
               break;
            case 29:
               var9 = 166;
               break;
            case 30:
               var9 = 82;
               break;
            case 31:
               var9 = 252;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
