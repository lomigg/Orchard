package x;

import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;

@Environment(EnvType.CLIENT)
public final class lIIIllll extends IIIIIIIlI {
   private static final double I = (double)1.0F;
   private final IlIIIlIlI<<undefinedtype>> l;
   private static final Color II;
   private final IlIIIlIlI<<undefinedtype>> Il;
   private final IlIIIlIlI<IIllIIlII> lI;
   private final IIllIlIII ll;
   private final lIIIIl III;
   private final IIllIlIII IIl;
   private static final Color IlI;
   private static final boolean Ill = false;
   private final lIlIlllI lII;
   private final IIllIlIII lIl;
   private final IIllIlIII llI;
   private static final double lll = (double)1.0F;
   private static final double IIII = 1.3;
   private final IIllIlIII IIIl;
   private final IIllIlIII IIlI;
   private final IIllIlIII IIll;
   private final IIIllIIII IlII;
   private static final int[] IlIl;
   private static final String[] IllI;
   private static final Object[] Illl;

   static {
      short var6 = 29936;
      String var7 = "汁民泠沨泔沱汒沄沵沛沷氿릨릒뤔륧뤻륤릢류륉륤뤙맦맊륍맲릻맆맇뤂뤻륩뤠릷린륞륥맒맭\ue938\ue901\ue987\ue9f2\ue9a8\ue9e7\ue913\ue9de\ue9c5\ue9e2\ue9bb\ue94b\ue952\ue9b0\ue95f\ue90a\ue940\ue954\ue98c\ue9c7⌭⍬⎅⏖⎿⏟⌼⎆˓ʬɳȟɇȶʌɼ嘞噟嚈固嚎囸嘔嚸囦囯嚁噫噻囑嘳嘛噢噵嚆嚂囙嚅噝噸ﾼ\uffc0］ｊＮ｣￨ｫｃｅ＊ￍ\uffddｎﾖﾸￄﾝ＝ＤｸＰ\ufff8\uffdd鼊齶龋鿼龘鿕齞鿝鿵鿳龼齻齫鿸鼠齋齻齦龫龬鿏鿅鼊鼘\ue560\ue57b\ue5cc\ue5b5셱섰쇙솊쇣솃셠솿솲솀쇢섿섑쇾셕세\uf00b\uf05d\uf0b8\uf0fd\uf098\uf0fe\uf00e\uf0de\uf0e9\uf0c0\uf0e4\uf01dͺ̬ωΌϩΏͿίΘεΊ̛̈Ω̴̚㹪㸨㻯㺡㻽㺛㹚㻂浸洺淽涳淯涉浈涵涍涰涕洑洘涷浒洲訩評誨諟誻諶詽諾論諐誟詘詈諔訇詧亸亅中之丯义亭乩乃久乐仏仒丵仭亙仄交且乃";
      char[] var8 = "瓼瓬瓤瓸瓸瓨瓨瓨瓴瓠瓼瓠瓸瓠瓠瓤".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IllI = var9;
            Illl = new Object[var9.length];
            int var2 = -127471786;
            byte[] var0 = "+boÐÒë\u0094×ØÉxÉ\u0085õHÉ_¤c\u009d^\u0007£\n¶g6í\b@\u0015\u008b\\*æ\u0083}×j2\u0094¾\u0082G©ë¿\u009fjC\u0018Ú'dR\u009e_\u0087\u000eáþ°¡}ÜÓá\u007f[êr^3ë\u0011¡\u009fK\u009dH\u009a\u007fù\u008b\f\u001cQn\u0094jK÷ð]\u0080¥ü§üâ\\;@AÃj%\u0017(÷\u0085\u007f\u0087¯Ro\u009d#wÝÞ\u00151\u000fÂu@Æg\u0085\u0015Ì\u0097\u0011¬C\r\u0000ì\u0087\u0081Ó\u009e2d`+×\u0099:\n~\u0017JxHí~Åo·\u009dzà<,Ió¦íÖ\"qqL\u008b\u0093\u0095>MjúÎõÐSLºBh-]X^ÌW\u009b7un¦u¢ý\u0002Z\"5#°\u007fnÆî\u0017eOÃ·áh\u0081îekn\u008e}þ»éa@ÂDé\u009a¼Ý_#RËÎït1\u0007\u0094|ÚËm\u0088êf\n\u0016\u0097ËÕ¨°½\u001b×àÑ\u0010q·Í\u009bòÙè".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IlIl = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IlIl[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            IlI = new Color(IIlllI(-50508042, 804900493), IIlllI(-50508041, -697289341), IIlllI(-50508044, -598550124), IIlllI(-50508043, -2123437675));
            II = new Color(IIlllI(-50508046, 1530905228), IIlllI(-50508045, 1520173570), IIlllI(-50508048, -1292068991), IIlllI(-50508047, 215725267));
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private Color ll(Color var1, boolean var2) {
      Color var3 = var1 == null ? new Color(IIlllI(-50508034, 1488013284), 0, IIlllI(-50508033, 2035075940), IIlllI(-50508036, -1876614382)) : var1;
      float[] var4 = Color.RGBtoHSB(var3.getRed(), var3.getGreen(), var3.getBlue(), (float[])null);
      float var5 = Math.max(0.16F, Math.min(0.42F, var4[1] * 0.38F));
      float var6 = var2 ? 0.105F : 0.155F;
      if (var3.getRed() > IIlllI(-50508035, -1385160984) && var3.getGreen() > IIlllI(-50508038, 1859697066) && var3.getBlue() > IIlllI(-50508037, 603976687)) {
         var5 = 0.03F;
         var6 = var2 ? 0.1F : 0.15F;
      } else if (var3.getRed() < IIlllI(-50508040, 1528606571) && var3.getGreen() < IIlllI(-50508039, -97845002) && var3.getBlue() < IIlllI(-50508058, -666353429)) {
         var5 = 0.02F;
         var6 = var2 ? 0.075F : 0.115F;
      }

      int var7 = Color.HSBtoRGB(var4[0], var5, var6);
      return new Color(var7 >> IIlllI(-50508057, 1601295359) & IIlllI(-50508060, 930132204), var7 >> IIlllI(-50508059, -1680851725) & IIlllI(-50508062, -1629202240), var7 & IIlllI(-50508061, 143126564), IIlllI(-50508064, -1863193922));
   }

   public int IlI() {
      Color var1 = this.IIll();
      return this.IIlIlI(this.IIIIll(IIlllI(-50508063, -188341936)), var1);
   }

   public void lII(IIllIIlII var1) {
      IIllIIlII var2 = var1 == null ? IIllIIlII.lIl : var1;
      this.lI.I(var2);
      if (var2 != IIllIIlII.lIl) {
         this.IIl.Il(var2.Il());
         this.ll.Il(var2.Ill());
         this.llI.Il(var2.lIl());
         this.IIll.Il(var2.lll());
         this.IIlI.Il(var2.lII());
         this.lIl.Il(var2.IlI());
         this.IIIl.Il(var2.Il());
         lIllIIl var3 = lIllIIl.Il();
         if (var3 != null) {
            var3.lll();
         }

      }
   }

   private Color IIII(Color var1, double var2) {
      return this.lIIIl(var1, Color.WHITE, var2);
   }

   private Color IIll() {
      Color var1 = this.IIlII();
      return var1 == null ? this.IIllII() : var1;
   }

   public static class_2561 IlII(class_2561 var0) {
      return var0;
   }

   public lIlIlllI IlIl() {
      return this.lII;
   }

   private boolean lIIl() {
      return this.lIlII() == IIllIIlII.lIl && this.l.III() == null.l;
   }

   public int llII() {
      Color var1 = this.IIll();
      return this.IIlIlI(this.IIIIll(IIlllI(-50508050, -130261712)), var1);
   }

   public Color lllI() {
      Color var1 = this.IIllII();
      var1 = this.IlIll(var1, this.IlIII());
      var1 = this.IlIll(var1, this.llIII());
      return var1 == null ? this.lllII() : var1;
   }

   public int IIIIl() {
      Color var1 = this.IIll();
      return this.IIlIlI(this.IIIIll(IIlllI(-50508049, 1486938582)), var1);
   }

   public IIllIlIII IIIll() {
      return this.IIl;
   }

   public Color IIlII() {
      Color var1 = this.IIllII();
      return new Color(var1.getRed(), var1.getGreen(), var1.getBlue(), 0);
   }

   public Color IIlIl() {
      return II;
   }

   public String IIlll() {
      return this.lII.IlI();
   }

   public Color IlIII() {
      IIllIIlII var1 = this.lIlII();
      if (var1 != IIllIIlII.lIl && var1.Ill() != null) {
         return var1.Ill();
      } else {
         return this.lIIl() ? (Color)this.ll.III() : this.IIII(this.IIllII(), 0.22);
      }
   }

   public double IlIIl() {
      return (double)1.0F;
   }

   private Color IlIll(Color var1, Color var2) {
      if (var1 == null) {
         return var2 == null ? IlI : var2;
      } else if (var2 == null) {
         return var1;
      } else {
         float[] var3 = Color.RGBtoHSB(var1.getRed(), var1.getGreen(), var1.getBlue(), (float[])null);
         float[] var4 = Color.RGBtoHSB(var2.getRed(), var2.getGreen(), var2.getBlue(), (float[])null);
         if (var4[1] == var3[1]) {
            return var4[2] > var3[2] ? var2 : var1;
         } else {
            return var4[1] > var3[1] ? var2 : var1;
         }
      }
   }

   public double IllII() {
      return (double)1.0F;
   }

   public static boolean IllIl() {
      lIllIIl var0 = lIllIIl.Il();
      if (var0 != null && var0.IIl() != null) {
         lIIIllll var1 = var0.IIl().llI();
         return var1 == null || var1.IIlIll();
      } else {
         return true;
      }
   }

   public Color lIIII() {
      IIllIIlII var1 = this.lIlII();
      return var1 != IIllIIlII.lIl && var1.Il() != null ? var1.Il() : (Color)this.IIIl.III();
   }

   private Color lIIIl(Color var1, Color var2, double var3) {
      Color var5 = var1 == null ? Color.WHITE : var1;
      Color var6 = var2 == null ? Color.WHITE : var2;
      double var7 = Math.max((double)0.0F, Math.min((double)1.0F, var3));
      return new Color((int)Math.round((double)var5.getRed() + (double)(var6.getRed() - var5.getRed()) * var7), (int)Math.round((double)var5.getGreen() + (double)(var6.getGreen() - var5.getGreen()) * var7), (int)Math.round((double)var5.getBlue() + (double)(var6.getBlue() - var5.getBlue()) * var7), (int)Math.round((double)var5.getAlpha() + (double)(var6.getAlpha() - var5.getAlpha()) * var7));
   }

   public static <undefinedtype> lIIll() {
      lIllIIl var0 = lIllIIl.Il();
      return var0 != null && var0.IIl() != null && var0.IIl().llI() != null ? var0.IIl().llI().IIllIl() : null.l;
   }

   public IIllIIlII lIlII() {
      IIllIIlII var1 = (IIllIIlII)this.lI.III();
      return var1 == null ? IIllIIlII.lIl : var1;
   }

   public boolean lIllI() {
      return false;
   }

   public <undefinedtype> lIlll() {
      return (<undefinedtype>)this.l.III();
   }

   public Color llIII() {
      IIllIIlII var1 = this.lIlII();
      if (var1 != IIllIIlII.lIl && var1.lIl() != null) {
         return var1.lIl();
      } else {
         return this.lIIl() ? (Color)this.llI.III() : this.lIIIl(this.IIllII(), new Color(IIlllI(-50508052, -940473136), IIlllI(-50508051, 745284690), IIlllI(-50508054, -2093681890), IIlllI(-50508053, -1715939681)), 0.46);
      }
   }

   public static boolean llIIl() {
      return lIIll().lI() != null;
   }

   public static class_2561 llIlI(String var0) {
      return IlII(class_2561.method_43470(var0));
   }

   public Color lllII() {
      return IlI;
   }

   public Color llllI() {
      IIllIIlII var1 = this.lIlII();
      if (var1 != IIllIIlII.lIl && var1.IlI() != null) {
         return var1.IlI();
      } else {
         return this.lIIl() ? (Color)this.lIl.III() : new Color(IIlllI(-50508056, -628191049), IIlllI(-50508055, -957423247), IIlllI(-50508074, 1662956611), IIlllI(-50508073, -1819669187));
      }
   }

   public IIllIlIII lllll() {
      return this.ll;
   }

   public lIIIllll() {
      super((Object)lIlIII.l(IIllll(-893963474, 1357585043)), lIllII.lI, (Object)lIlIII.l(IIllll(-893963473, -2063132643)), false);
      this.l = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IIllll(-893963476, -711696649)), <undefinedtype>.class, null.l));
      this.lI = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IIllll(-893963475, 528898532)), IIllIIlII.class, IIllIIlII.l));
      this.Il = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IIllll(-893963478, 1048336109)), <undefinedtype>.class, null.l));
      this.III = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIllll(-893963477, 1790258492)), true));
      this.lII = (lIlIlllI)this.IIIlIll(new lIlIlllI(lIlIII.l(IIllll(-893963480, -1022343803)), ""));
      this.IlII = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IIllll(-893963479, -1549398463)), (double)100.0F, (double)0.0F, (double)100.0F, (double)1.0F)).IIIl(lIlIII.l(IIllll(-893963482, -645252378))));
      this.IIl = (IIllIlIII)this.IIIlIll(new IIllIlIII(lIlIII.l(IIllll(-893963481, -36024687)), new Color(IIlllI(-50508076, 161172919), IIlllI(-50508075, -2058862617), IIlllI(-50508078, 1627097772), IIlllI(-50508077, -1650349308))));
      this.ll = (IIllIlIII)this.IIIlIll(new IIllIlIII(lIlIII.l(IIllll(-893963484, -861465539)), new Color(IIlllI(-50508080, 332519729), IIlllI(-50508079, -370842443), IIlllI(-50508066, -1291396186), IIlllI(-50508065, 951576709))));
      this.llI = (IIllIlIII)this.IIIlIll(new IIllIlIII(lIlIII.l(IIllll(-893963483, 1071016922)), new Color(IIlllI(-50508068, -1569294466), IIlllI(-50508067, 1978330542), IIlllI(-50508070, -1760649410), IIlllI(-50508069, 1851879303))));
      this.IIll = (IIllIlIII)this.IIIlIll(new IIllIlIII(lIlIII.l(IIllll(-893963486, 46296044)), new Color(IIlllI(-50508072, -725029612), IIlllI(-50508071, 1190366404), IIlllI(-50508090, 1556442605), IIlllI(-50508089, -1616063488))));
      this.IIlI = (IIllIlIII)this.IIIlIll(new IIllIlIII(lIlIII.l(IIllll(-893963485, 1372608294)), new Color(IIlllI(-50508092, -1561459871), IIlllI(-50508091, 113345454), IIlllI(-50508094, 657186542), IIlllI(-50508093, -1032473073))));
      this.lIl = (IIllIlIII)this.IIIlIll(new IIllIlIII(lIlIII.l(IIllll(-893963488, -1232792676)), new Color(IIlllI(-50508096, 1264064127), 4, IIlllI(-50508095, 1813663742), IIlllI(-50508082, 1878339354))));
      this.IIIl = (IIllIlIII)this.IIIlIll(new IIllIlIII(lIlIII.l(IIllll(-893963487, 1913654960)), new Color(IIlllI(-50508081, -98547638), IIlllI(-50508084, 1146742053), IIlllI(-50508083, -1641579461), IIlllI(-50508086, 667511469))));
      this.l.lIII(() -> false);
      this.lI.lIII(() -> false);
      this.Il.lIII(() -> true);
      this.III.lIII(() -> true);
      this.lII.lIII(() -> false);
      this.IlII.lIII(() -> false);
      this.IIl.lIII(() -> this.lIlII() == IIllIIlII.lIl);
      this.ll.lIII(() -> this.lIlII() == IIllIIlII.lIl);
      this.llI.lIII(() -> false);
      this.IIll.lIII(() -> false);
      this.IIlI.lIII(() -> false);
      this.lIl.lIII(() -> false);
      this.IIIl.lIII(() -> false);
   }

   public int IIIIII() {
      Color var1 = this.IIll();
      return this.IIlIlI(this.IIIIll(IIlllI(-50508085, -336621400)), var1);
   }

   public Color IIIIIl() {
      IIllIIlII var1 = this.lIlII();
      if (var1 != IIllIIlII.lIl && var1.lll() != null) {
         return var1.lll();
      } else {
         return this.lIIl() ? (Color)this.IIll.III() : this.ll(this.IIllII(), false);
      }
   }

   private int IIIIll(int var1) {
      return Math.max(0, Math.min(IIlllI(-50508088, -1863877718), (int)Math.round((double)var1 * 1.3)));
   }

   public double IIIlII() {
      return (Double)this.IlII.III() / (double)100.0F;
   }

   public String IIIlIl() {
      IIllIIlII var1 = this.lIlII();
      return var1 != IIllIIlII.lIl ? var1.toString() : ((<undefinedtype>)this.l.III()).toString();
   }

   public Color IIIllI() {
      return (Color)this.IIl.III();
   }

   public Color IIlIII() {
      IIllIIlII var1 = this.lIlII();
      if (var1 != IIllIIlII.lIl && var1.lII() != null) {
         return var1.lII();
      } else {
         return this.lIIl() ? (Color)this.IIlI.III() : this.ll(this.IIllII(), true);
      }
   }

   private int IIlIlI(int var1, Color var2) {
      return var1 << IIlllI(-50508087, 1762872289) | (var2.getRed() & IIlllI(-50508106, 244135636)) << IIlllI(-50508105, -785182388) | (var2.getGreen() & IIlllI(-50508108, 525091276)) << IIlllI(-50508107, 350885414) | var2.getBlue() & IIlllI(-50508110, -1620477709);
   }

   public boolean IIlIll() {
      return (Boolean)this.III.III();
   }

   public Color IIllII() {
      IIllIIlII var1 = this.lIlII();
      return var1 != IIllIIlII.lIl && var1.Il() != null ? var1.Il() : ((<undefinedtype>)this.l.III()).ll((Color)this.IIl.III());
   }

   public <undefinedtype> IIllIl() {
      <undefinedtype> var1 = (<undefinedtype>)this.Il.III();
      return var1 == null ? null.l : var1;
   }

   private static int IIlllI(int var0, int var1) {
      return IlIl[var0 ^ -50508042] ^ var1 ^ var0;
   }

   private static String IIllll(int var0, int var1) {
      int var3 = var0 ^ -893963474;
      char[] var4 = IllI[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])Illl[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         Illl[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -464142177;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 48;
               break;
            case 1:
               var9 = 73;
               break;
            case 2:
               var9 = 146;
               break;
            case 3:
               var9 = 235;
               break;
            case 4:
               var9 = 187;
               break;
            case 5:
               var9 = 226;
               break;
            case 6:
               var9 = 36;
               break;
            case 7:
               var9 = 212;
               break;
            case 8:
               var9 = 226;
               break;
            case 9:
               var9 = 203;
               break;
            case 10:
               var9 = 158;
               break;
            case 11:
               var9 = 110;
               break;
            case 12:
               var9 = 96;
               break;
            case 13:
               var9 = 249;
               break;
            case 14:
               var9 = 86;
               break;
            case 15:
               var9 = 54;
               break;
            case 16:
               var9 = 124;
               break;
            case 17:
               var9 = 16;
               break;
            case 18:
               var9 = 168;
               break;
            case 19:
               var9 = 135;
               break;
            case 20:
               var9 = 236;
               break;
            case 21:
               var9 = 190;
               break;
            case 22:
               var9 = 60;
               break;
            case 23:
               var9 = 25;
               break;
            case 24:
               var9 = 247;
               break;
            case 25:
               var9 = 236;
               break;
            case 26:
               var9 = 1;
               break;
            case 27:
               var9 = 62;
               break;
            case 28:
               var9 = 178;
               break;
            case 29:
               var9 = 208;
               break;
            case 30:
               var9 = 214;
               break;
            case 31:
               var9 = 243;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
