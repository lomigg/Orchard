package x;

import java.util.function.BooleanSupplier;

public final class lllllI {
   public static final double I = 0.02;
   public static final float l = 0.12F;
   public static final double II = (double)0.25F;
   private static final int[] Il;

   public static double I(double var0, double var2, double var4) {
      return Double.isFinite(var0) && Double.isFinite(var2) && Double.isFinite(var4) && !(var2 <= 1.0E-4) && !(var4 <= (double)0.0F) ? II(var0 / var2, (double)0.0F, Math.min((double)0.25F, var4)) : (double)0.0F;
   }

   public static double l(double var0, int var2, int var3, double var4, double var6) {
      double var8 = Math.max((double)0.0F, var0);
      double var10 = (double)5.0F + lIl(var8) + var8 * (double)0.5F * (double)Math.max(0, var3);
      double var12 = Math.max((double)0.0F, var4);
      double var14 = (double)2.0F + Math.max((double)0.0F, var6) / (double)4.0F;
      double var16 = II(var12 - var10 / var14, var12 * 0.2, (double)20.0F) / (double)25.0F;
      var16 = II(var16 - 0.15 * (double)Math.max(0, var2), (double)0.0F, (double)1.0F);
      return var10 * ((double)1.0F - var16);
   }

   private static double II(double var0, double var2, double var4) {
      return Math.max(var2, Math.min(var4, var0));
   }

   public static boolean Il(double var0, double var2) {
      return var0 > Math.max((double)0.0F, var2);
   }

   public static double lI(double var0, double var2, double var4, double var6, double var8, double var10, double var12, double var14, double var16) {
      double var18 = Math.max(var6 - var0, Math.max((double)0.0F, var0 - var12));
      double var20 = Math.max(var8 - var2, Math.max((double)0.0F, var2 - var14));
      double var22 = Math.max(var10 - var4, Math.max((double)0.0F, var4 - var16));
      return var18 * var18 + var20 * var20 + var22 * var22;
   }

   public static boolean ll(boolean var0, BooleanSupplier var1) {
      if (var0) {
         return true;
      } else {
         return var1 != null && var1.getAsBoolean();
      }
   }

   public static double III(double var0, double var2, double var4) {
      double var6 = Math.min(var0, var2);
      double var8 = Math.max(var0, var2);
      return var6 + (var8 - var6) * II(var4, (double)0.0F, (double)1.0F);
   }

   public static boolean IIl(Object var0, Object var1, double var2) {
      if (var0 == null) {
         return false;
      } else if (var1 == null) {
         return true;
      } else {
         int var4 = var0.II().compareTo(var1.II());
         if (var4 != 0) {
            return var4 > 0;
         } else if (var0.lI() != var1.lI()) {
            return var0.lI();
         } else {
            double var5 = Math.max((double)0.0F, var2);
            return var0.I() + var5 < var1.I();
         }
      }
   }

   public static double IlI(double var0) {
      return Math.max((double)0.0F, var0 - 0.02);
   }

   public static <undefinedtype> Ill(boolean var0, boolean var1, boolean var2) {
      if (!var0) {
         return null.Il;
      } else if (var1) {
         return null.I;
      } else {
         return var2 ? null.lI : null.ll;
      }
   }

   public static boolean lII(double var0, double var2, double var4, double var6, double var8, double var10, double var12, double var14, double var16, double var18, double var20, double var22, double var24) {
      double var26 = Math.max((double)0.0F, var24);
      double var28 = var26 * var26;
      double var30 = (double)0.0F;
      double var32 = (double)1.0F;

      for(int var34 = 0; var34 < IIll(-43989140, -1305507899); ++var34) {
         double var35 = (var30 * (double)2.0F + var32) / (double)3.0F;
         double var37 = (var30 + var32 * (double)2.0F) / (double)3.0F;
         double var39 = llI(var35, var0, var2, var4, var6, var8, var10, var12, var14, var16, var18, var20, var22);
         double var41 = llI(var37, var0, var2, var4, var6, var8, var10, var12, var14, var16, var18, var20, var22);
         if (var39 <= var41) {
            var32 = var37;
         } else {
            var30 = var35;
         }
      }

      double var43 = (var30 + var32) * (double)0.5F;
      return Math.min(llI((double)0.0F, var0, var2, var4, var6, var8, var10, var12, var14, var16, var18, var20, var22), Math.min(llI(var43, var0, var2, var4, var6, var8, var10, var12, var14, var16, var18, var20, var22), llI((double)1.0F, var0, var2, var4, var6, var8, var10, var12, var14, var16, var18, var20, var22))) <= var28;
   }

   public static double lIl(double var0) {
      double var2 = Math.max((double)0.0F, var0);
      if (var2 <= (double)3.0F) {
         return (double)4.0F * var2;
      } else {
         return var2 <= (double)8.0F ? (double)12.0F + (double)2.0F * (var2 - (double)3.0F) : (double)22.0F + (var2 - (double)8.0F);
      }
   }

   private static double llI(double var0, double var2, double var4, double var6, double var8, double var10, double var12, double var14, double var16, double var18, double var20, double var22, double var24) {
      return lI(var2 - var8 * var0, var4 - var10 * var0, var6 - var12 * var0, var14, var16, var18, var20, var22, var24);
   }

   public static double lll(double var0, double var2) {
      double var4 = Math.max((double)0.0F, var0);
      if (var2 > (double)0.0F) {
         return (double)0.0F;
      } else {
         return var2 > (double)-0.5F && var4 > (double)1.0F ? (double)1.0F : var4;
      }
   }

   public static boolean IIII(boolean var0, boolean var1) {
      return var0 && !var1;
   }

   private lllllI() {
   }

   public static float IIIl(double var0, boolean var2) {
      float var3 = (float)II(var0 / (double)100.0F, (double)0.0F, (double)1.0F);
      return var2 ? Math.min(var3, 0.12F) : var3;
   }

   public static boolean IIlI(Object var0, Object var1) {
      if (var0 == null) {
         return false;
      } else if (var1 == null) {
         return true;
      } else {
         int var2 = var0.II().compareTo(var1.II());
         if (var2 != 0) {
            return var2 > 0;
         } else if (var0.lI() != var1.lI()) {
            return var0.lI();
         } else {
            int var3 = Double.compare(var0.I(), var1.I());
            if (var3 != 0) {
               return var3 < 0;
            } else {
               int var4 = Double.compare(var0.ll(), var1.ll());
               if (var4 != 0) {
                  return var4 < 0;
               } else {
                  int var5 = Double.compare(var0.l(), var1.l());
                  if (var5 != 0) {
                     return var5 < 0;
                  } else {
                     return var0.Il() < var1.Il();
                  }
               }
            }
         }
      }
   }

   private static int IIll(int var0, int var1) {
      return Il[var0 ^ -43989140] ^ var1 ^ var0;
   }

   static {
      int var2 = 1140832565;
      byte[] var0 = "\f°ù\u0080".getBytes("ISO-8859-1");
      int var1 = var0.length / 4;
      Il = new int[var1];
      int var3 = 0;
      int var4 = 0;

      do {
         int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
         var5 ^= var2;
         Il[var4] = var5;
         var3 += 4;
         ++var4;
      } while(var4 < var1);

   }
}
