package x;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class IIlllIlI {
   private static final int I = 8;
   private static final long l = 320L;
   private long II;
   private static final IIlllIlI Il;
   private final Deque<<undefinedtype>> lI = new ArrayDeque();
   private static final int[] ll;
   private static final String[] III;
   private static final Object[] IIl;

   public synchronized void I(IIIIIIIlI var1, boolean var2) {
      lIllIIl var3 = lIllIIl.Il();
      if (var3 != null && var1 != null && var1.IIlIlIl()) {
         if (var3.IIl().IIIIlII().contains(var1)) {
            lIIIllII var4 = (lIIIllII)var3.IIl().IIIIIII(lIIIllII.class);
            if (var4 != null && var4.IIIIIlI()) {
               if (var4.IIIll()) {
                  this.IIl(var2 ? null.ll : null.II, lIlIII.l(Ill('섓', 1280585751, (short)31786)), var1.lllllI().IIII(lIlIII.l(Ill('섒', 900071656, (short)'킷'))).IIII(var2 ? lIlIII.l(Ill('섑', 1295213323, (short)'믵')) : lIlIII.l(Ill('섐', 1736452752, (short)8364))), var4.IlIl());
               }
            }
         }
      }
   }

   public synchronized List<<undefinedtype>> l() {
      this.ll(System.currentTimeMillis());
      return List.copyOf(this.lI);
   }

   static {
      short var6 = 30900;
      String var7 = "\ue7a5\ue83f\ue7a5\ue842\ue78a\ue827\ue843\ue828\ue78e\ue838\ue786\ue791\ue795\ue78f\udf5e\ue82b\ue838\ue774\ue836\ue836䲖䱋䴧䴧黃鸗鸑鸋黃麩鸋鷰鸋鷺鷎鷎\uef3d\uee01\uee98\uedff\uef3d\uedf9\uee33\uee49\uee55\uedf9\uee5e\uee8c";
      char[] var8 = "碠碰碸碸".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            III = var9;
            IIl = new Object[var9.length];
            int var2 = 1243754858;
            byte[] var0 = "\u0094³»]".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            ll = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               ll[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            Il = new IIlllIlI();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public static IIlllIlI II() {
      return Il;
   }

   public synchronized boolean Il() {
      this.ll(System.currentTimeMillis());
      return !this.lI.isEmpty();
   }

   public synchronized void lI() {
      this.lI.clear();
   }

   private void ll(long var1) {
      ArrayList var3 = new ArrayList();

      for(<undefinedtype> var5 : this.lI) {
         if (var5.IIl() + 320L <= var1) {
            var3.add(var5);
         }
      }

      if (!var3.isEmpty()) {
         this.lI.removeAll(var3);
      }

   }

   public synchronized void III(Object var1, String var2, String var3, long var4) {
      this.IIl(var1, lIlIII.III(var2 == null ? "" : var2), lIlIII.III(var3 == null ? "" : var3), var4);
   }

   public synchronized void IIl(Object var1, Object var2, Object var3, long var4) {
      lIllIIl var6 = lIllIIl.Il();
      if (var6 != null) {
         lIIIllII var7 = (lIIIllII)var6.IIl().IIIIIII(lIIIllII.class);
         if (var7 == null || !var7.IIIIIlI()) {
            return;
         }
      }

      long var9 = System.currentTimeMillis();
      this.ll(var9);
      this.lI.addFirst(new Record(++this.II, var1 == null ? null.Il : var1, var2 == null ? lIlIII.III("") : var2, var3 == null ? lIlIII.III("") : var3, var9, Math.max(250L, var4)) {
         private final <undefinedtype> I;
         private final <undefinedtype> l;
         private final long II;
         private final long Il;
         private final long lI;
         private final <undefinedtype> ll;

         public long I() {
            return this.lI;
         }

         public <undefinedtype> l() {
            return this.I;
         }

         public <undefinedtype> II() {
            return this.I;
         }

         public String Il() {
            return this.l.lIlI();
         }

         public <undefinedtype> lI() {
            return this.l;
         }

         public <undefinedtype> ll() {
            return this.ll;
         }

         public String III() {
            return this.I.lIlI();
         }

         public long IIl() {
            return this.II + this.lI;
         }

         public <undefinedtype> IlI() {
            return this.l;
         }

         public long Ill() {
            return this.II;
         }

         public long lII() {
            return this.Il;
         }

         public {
            this.Il = var1;
            this.ll = var3;
            this.l = var4;
            this.I = var5;
            this.II = var6;
            this.lI = var8;
         }
      });

      while(this.lI.size() > IlI(-993700889, 441768408)) {
         this.lI.removeLast();
      }

   }

   private static int IlI(int var0, int var1) {
      return ll[var0 ^ -993700889] ^ var1 ^ var0;
   }

   private static String Ill(char var0, int var1, short var2) {
      int var3 = var0 ^ '섓';
      char[] var4 = III[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])IIl[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         IIl[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 31225;
      int var9 = 0;

      do {
         int var10 = var4[var9] + '좚';
         var10 ^= 21418;
         var10 += 58103;
         var10 -= 48863;
         var10 ^= 2153;
         var10 += 48069;
         var10 ^= 6271;
         var4[var9] = (char)(var10 ^ var8 ^ var2 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
