package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1511;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_5134;
import net.minecraft.class_746;
import net.minecraft.class_1297.class_5529;
import net.minecraft.class_239.class_240;

@Environment(EnvType.CLIENT)
public final class lllIII extends IIIIIIIlI {
   private int I;
   private class_239 l;
   private static String[] II;
   private boolean Il;
   private boolean lI;
   private class_2338 ll;
   private final IlIIIlIlI<<undefinedtype>> III;
   private class_2350 IIl;
   private final lIIIIl IlI;
   private boolean Ill;
   private boolean lII;
   private boolean lIl;
   private boolean llI;
   private class_243 lll;
   private int IIII;
   private boolean IIIl;
   private static final int[] IIlI;
   private static final String[] IIll;
   private static final Object[] IlII;

   private void ll() {
      if (this.IIIl) {
         IllllIlI.IIlII(class_310.method_1551());
         this.IIIl = false;
      }

      this.llI = false;
      this.Il = false;
      this.l = null;
      this.lI = false;
      this.IIII = llIlI(554413899, -1725633442);
      this.lIl = false;
      this.Ill = false;
   }

   public void lIl() {
      this.ll();
      this.lll();
      this.I = llIlI(554413898, 920550116);
   }

   private boolean IlI(class_310 var1) {
      if (var1 != null && var1.field_1765 != null) {
         class_239 var4 = var1.field_1765;
         if (var4 instanceof class_3966) {
            class_3966 var2 = (class_3966)var4;
            class_1297 var5 = var2.method_17782();
            if (var5 instanceof class_1511) {
               class_1511 var3 = (class_1511)var5;
               return !var3.method_31481();
            }
         }

         return false;
      } else {
         return false;
      }
   }

   private static String lII(char[] var0, long var1, int var3) {
      int var4 = llIlI(554413897, 576917954) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & llIlI(554413896, -396941765);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private boolean llI(class_310 var1) {
      return var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var1.field_1755 == null && var1.field_1724.method_5805();
   }

   private void lll() {
      this.ll = null;
      this.IIl = null;
      this.lll = null;
   }

   static {
      short var6 = 15242;
      String var7 = "ͳ貲䯯﨡뱨\uda71酦ဟ뺉㽾略ꩰ\uf505祽敀ﱦ\uf4fb輈딙㣴\udecf뎵\ueb3a窑郉엙枡鰼對歲ﰐ躝ｹ㫶\ue383纎ጤ䟘\uf615\ued6d썑늹뱷띾\ue0b4擳齃瘻勽ⶏ䷬硡䣯쁛쉢⡹莵\uf1f8䚹⋐쫘안햔鞌儡\udebf社漝\ue7c3衺䜦銴\ue4cd\uebfdﮂ橆\uf25b㫚䲡䨧\u192e\ud8d5ॾ퍑畉\ue4fbﭤ緍㒟ㄣ漨䜽堸釉琑䲨觿ꗕ\uf58d澭\uf10d㉤㟦牖鎸磀⸠暳偼\ude13㾟锠꼛쇱沢\uf5fb휳䠻㟾\u242e跹Ṋ\u2072ዞ鷫ចꍄ굑끋솬賛穾칓▮捇\ue421麃ꚻ倦띏蟔\ue4d0\uf1d9㤺ྐ犧⻖帣랇㷈ﴍ\uf252⦄㾍䧽᷑ા될篱\uf44b홎⠿琢ᶕ₮䴠笋霊";
      char[] var8 = "\u0014p\b\u001c".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            IIll = var9;
            IlII = new Object[var9.length];
            int var2 = 1717835556;
            byte[] var0 = "^KT1ñ±Â\u008aZ~\u009c\u0097¯8\u009e¨\u0086\u008e«¿¸ic{Åÿ7{1í1+¹²d\u0018\u0004N5\u0080\u008d¬\u0099@ÉSA\tÑy84\u0007\u0006uá".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IIlI = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IIlI[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            II = new String[4];
            lIIlI();
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 106;
                     break;
                  case 1:
                     var10000 = 42;
                     break;
                  case 2:
                     var10000 = 42;
                     break;
                  case 3:
                     var10000 = 76;
                     break;
                  case 4:
                     var10000 = 64;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private void IIII(class_310 var1) {
      this.lIl = true;
      this.Ill = this.IIllI(var1);
   }

   public boolean IIll(class_2338 var1, class_2350 var2) {
      class_310 var3 = class_310.method_1551();
      if (!this.lIIll(var3, var1, var2)) {
         return false;
      } else if (!this.lllI(var3)) {
         return true;
      } else {
         boolean var4 = this.IlIII(var3, var1, var2);
         if (var4) {
            this.IIII(var3);
            IllllIlI.llIIlI(var3, this, 0);
         }

         return var4;
      }
   }

   private void IlII(class_310 var1) {
      if (!this.llI(var1)) {
         IllllIlI.IlII(var1, this, null.II);
         this.ll();
         this.lll();
      } else {
         this.llIII(var1);
         if (!this.IIIIl(var1)) {
            IllllIlI.IlII(var1, this, null.II);
            this.ll();
         } else if (this.IlI(var1)) {
            if (this.lIlII(var1)) {
               this.lIlll(var1);
               this.lIIII(var1);
            } else if (this.IIII != llIlI(554413903, 1105269716) && var1.field_1724.field_6012 <= this.IIII) {
               this.lIIII(var1);
            } else {
               IllllIlI.IIlII(var1);
               this.lII = true;

               try {
                  IllllIlI.IIlIlII(var1);
               } finally {
                  this.lII = false;
               }

               this.lIIII(var1);
            }
         } else {
            if (this.lIllI(var1)) {
               IllllIlI.IIlII(var1);
               class_3965 var2 = (class_3965)var1.field_1765;
               this.IIlII(var2.method_17777(), var2.method_17780(), var2.method_17784());
            }

         }
      }
   }

   private boolean IlIl(class_1297 var1, byte var2) {
      class_310 var3 = class_310.method_1551();
      if (var1 != null && var3 != null && var3.field_1724 != null && var1 != var3.field_1724 && var1 instanceof class_1309 var4) {
         return var2 == 3 || var1.method_31481() || !var1.method_5805() || var4.method_6032() <= 0.0F;
      } else {
         return false;
      }
   }

   static boolean Illl(class_746 var0) {
      return var0 != null && var0.method_45325(class_5134.field_23721) > (double)0.0F;
   }

   private boolean lIII(class_310 var1) {
      if (var1 != null && var1.field_1765 != null) {
         return this.lIllI(var1) || this.IlI(var1);
      } else {
         return false;
      }
   }

   private boolean lIIl(class_2338 var1, class_310 var2) {
      if (var2 != null && var2.field_1687 != null) {
         return var2.field_1687.method_8320(var1).method_27852(class_2246.field_10540) || var2.field_1687.method_8320(var1).method_27852(class_2246.field_9987);
      } else {
         return false;
      }
   }

   public void II(class_1297 var1, byte var2) {
      if (this.IlIl(var1, var2)) {
         class_310 var3 = class_310.method_1551();
         this.Illll(var3);
         IllllIlI.IlII(var3, this, null.II);
         this.ll();
         this.lll();
      }
   }

   public boolean llII(class_2338 var1, class_2350 var2) {
      class_310 var3 = class_310.method_1551();
      if (this.IIIIIlI() && this.llI(var3) && var1 != null && var2 != null && this.lIIl(var1, var3)) {
         var3.field_1761.method_2925();
         if (!this.lllI(var3)) {
            return true;
         } else if (!this.llIIl(var3.field_1724, class_1802.field_8301)) {
            return this.IlIll(var3);
         } else {
            if (this.IlIII(var3, var1, var2)) {
               this.IIII(var3);
               IllllIlI.llIIlI(var3, this, 0);
            }

            return true;
         }
      } else {
         return false;
      }
   }

   private boolean lllI(class_310 var1) {
      if (this.lIl) {
         return false;
      } else if (var1 != null && var1.field_1690 != null && var1.field_1690.field_1886 != null) {
         boolean var2 = this.IIllI(var1);
         boolean var3 = IllllIlI.IllIlI(var1.field_1690.field_1886) > 0;
         boolean var4 = var3 || var2 && !this.Ill;
         this.Ill = var2;
         if (!var2 && !var3) {
            this.lIl = false;
         }

         return var4;
      } else {
         return false;
      }
   }

   private boolean IIIII(class_310 var1) {
      if (this.ll != null && this.IIl != null && var1 != null && var1.field_1724 != null) {
         if (!this.lIlIl(var1)) {
            return false;
         } else if (!this.lIIl(this.ll, var1)) {
            this.lll();
            return false;
         } else if (!this.llIIl(var1.field_1724, class_1802.field_8301)) {
            return false;
         } else if (IlIlIl.ll()) {
            return false;
         } else if (var1.field_1690 != null && var1.field_1690.field_1904 != null) {
            if (IlIlIl.ll()) {
               return false;
            } else {
               class_3965 var2 = new class_3965(this.lll == null ? this.IIlll(this.ll, this.IIl) : this.lll, this.IIl, this.ll, false);
               this.l = var1.field_1765;
               var1.field_1765 = var2;
               this.Il = true;
               this.llI = true;
               IllllIlI.lIllll(var1);
               IllllIlI.IIIIllI(var1.field_1690.field_1904);
               var1.field_1690.field_1904.method_23481(false);
               if (!IllllIlI.IIllIlI(var1)) {
                  IllllIlI.IlII(var1, this, null.II);
                  this.Illll(var1);
                  return false;
               } else {
                  this.IIII(var1);
                  IllllIlI.llIIlI(var1, this, 0);
                  this.lI = true;
                  this.lll();
                  return true;
               }
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private boolean IIIIl(class_310 var1) {
      if (this.llI(var1) && var1.field_1690 != null) {
         if (!this.llIIl(var1.field_1724, class_1802.field_8301)) {
            return false;
         } else {
            return this.IIlIl(var1) && this.lIII(var1);
         }
      } else {
         return false;
      }
   }

   public lllIII() {
      super((Object)lIlIII.l(II[0]), lIllII.I, (Object)lIlIII.l(II[1]));
      this.III = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(II[2]), <undefinedtype>.class, null.I));
      this.IlI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(II[3]), false));
      this.IIII = llIlI(554413902, 2131155729);
      this.I = llIlI(554413901, 43028242);
   }

   private boolean IIIll(class_310 var1) {
      return var1 != null && var1.field_1690 != null && var1.field_1690.field_1904 != null && (IllllIlI.IIIll(var1, var1.field_1690.field_1904) || var1.field_1690.field_1904.method_1434());
   }

   private void IIlII(class_2338 var1, class_2350 var2, class_243 var3) {
      if (var1 != null && var2 != null) {
         this.ll = var1.method_10062();
         this.IIl = var2;
         this.lll = var3;
      }
   }

   private boolean IIlIl(class_310 var1) {
      return this.IIllI(var1) || this.IIIll(var1);
   }

   private boolean IIllI(class_310 var1) {
      return var1 != null && var1.field_1690 != null && var1.field_1690.field_1886 != null && (IllllIlI.IIIll(var1, var1.field_1690.field_1886) || var1.field_1690.field_1886.method_1434());
   }

   private class_243 IIlll(class_2338 var1, class_2350 var2) {
      class_2350 var3 = var2 == null ? class_2350.field_11036 : var2;
      return new class_243((double)var1.method_10263() + (double)0.5F + (double)var3.method_10148() * (double)0.5F, (double)var1.method_10264() + (double)0.5F + (double)var3.method_10164() * (double)0.5F, (double)var1.method_10260() + (double)0.5F + (double)var3.method_10165() * (double)0.5F);
   }

   private boolean IlIII(class_310 var1, class_2338 var2, class_2350 var3) {
      if (var1.field_1724 != null && var1.field_1761 != null) {
         if (IlIlIl.ll()) {
            return false;
         } else if (IlIlIl.ll()) {
            return false;
         } else {
            class_243 var4 = new class_243((double)var2.method_10263(), (double)var2.method_10264(), (double)var2.method_10260());
            class_3965 var5 = new class_3965(var4, var3, var2, false);
            return this.lIIIl(var1, var5);
         }
      } else {
         return false;
      }
   }

   public void lllIl(class_310 var1) {
      if (this.llI) {
         this.Illll(var1);
      }

   }

   private void IlIIl(class_310 var1) {
      if (var1 != null && var1.field_1690 != null && var1.field_1690.field_1904 != null) {
         IllllIlI.lIllll(var1);
         IllllIlI.IIIIllI(var1.field_1690.field_1904);
         var1.field_1690.field_1904.method_23481(false);
      }
   }

   public void IllI(class_310 var1) {
      this.IlII(var1);
      this.IIIII(var1);
   }

   private boolean IlIll(class_310 var1) {
      if ((Boolean)this.IlI.III() && var1 != null && var1.field_1724 != null) {
         int var2 = this.IllII(var1.field_1724.method_31548(), class_1802.field_8301);
         if (var2 < 0) {
            return false;
         } else if (!IllllIlI.lIIllI(var1, this, var2)) {
            return false;
         } else {
            this.ll();
            return true;
         }
      } else {
         return false;
      }
   }

   private int IllII(class_1661 var1, class_1792 var2) {
      if (var1 != null && var2 != null) {
         for(int var3 = 0; var3 < llIlI(554413900, 1988266314); ++var3) {
            if (var1.method_5438(var3).method_31574(var2)) {
               return var3;
            }
         }

         return -1;
      } else {
         return -1;
      }
   }

   public boolean IlllI(class_310 var1) {
      if (this.IIIIIlI() && this.llI(var1) && !this.Il) {
         if (this.llIIl(var1.field_1724, class_1802.field_8301) && var1.field_1690 != null) {
            boolean var2 = this.IIllI(var1);
            boolean var3 = this.IIIll(var1);
            if (var2 && var3) {
               return true;
            } else {
               return var3 && this.lIII(var1);
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public void lI() {
      this.Illll(class_310.method_1551());
      this.ll();
      this.lll();
      this.I = llIlI(554413891, 2128469119);
   }

   public void lIlI(class_1297 var1) {
      if (var1 instanceof class_1511 var2) {
         class_310 var3 = class_310.method_1551();
         if (var3 != null && !var3.method_1542() && !var2.method_31481()) {
            if (this.llIIl(var3.field_1724, class_1802.field_8301) && Illl(var3.field_1724)) {
               this.I = var3.field_1724.field_6012;
               var2.method_5650(class_5529.field_26998);
               var2.method_36209();
            }
         }
      }
   }

   private void Illll(class_310 var1) {
      if (var1 != null) {
         var1.field_1765 = this.l;
      }

      this.l = null;
      this.llI = false;
      this.Il = false;
   }

   private void lIIII(class_310 var1) {
      if (var1 != null && var1.field_1690 != null) {
         IllllIlI.llllll(var1, 1);
         this.IIIl = true;
         if (var1.field_1690.field_1886 != null) {
            IllllIlI.IIIIllI(var1.field_1690.field_1886);
         }

      }
   }

   private boolean lIIIl(class_310 var1, class_3965 var2) {
      return !this.lIlIl(var1) ? false : IlIlIl.IIlIII(var1, llIlI(554413890, 1126272284), var2.method_17784(), () -> {
         this.Il = true;

         boolean var3;
         try {
            var3 = IllllIlI.IIlIIII(var1, var2);
         } finally {
            this.Il = false;
         }

         return var3;
      });
   }

   private static void lIIlI() {
      II[0] = lII(llIll(1175069375, 30405, '\ueac6').toCharArray(), 66761L, llIlI(554413889, 1775053414));
      II[1] = lII(llIll(-1744099313, 23158, '\ueac7').toCharArray(), 17149L, llIlI(554413888, -1476043785));
      II[2] = lII(llIll(1467645614, 23664, '\ueac4').toCharArray(), 60306L, llIlI(554413895, 1119199361));
      II[3] = lII(llIll(937059609, 26809, '\ueac5').toCharArray(), 31439L, llIlI(554413894, -1770488057));
   }

   private boolean lIIll(class_310 var1, class_2338 var2, class_2350 var3) {
      if (this.IIIIIlI() && this.llI(var1) && var2 != null && var3 != null) {
         return this.llIIl(var1.field_1724, class_1802.field_8301) && this.lIIl(var2, var1);
      } else {
         return false;
      }
   }

   private boolean lIlII(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         if (!this.lI && !var1.field_1724.method_6115()) {
            return var1.field_1690 != null && var1.field_1690.field_1904 != null && (var1.field_1690.field_1904.method_1434() || IllllIlI.IllIlI(var1.field_1690.field_1904) > 0);
         } else {
            return true;
         }
      } else {
         return false;
      }
   }

   private boolean lIlIl(class_310 var1) {
      return var1 != null && var1.field_1724 != null && (this.III.III() == null.I || var1.field_1724.field_6012 > this.I);
   }

   private boolean lIllI(class_310 var1) {
      if (var1 != null && var1.field_1765 != null) {
         class_239 var3 = var1.field_1765;
         boolean var10000;
         if (var3 instanceof class_3965) {
            class_3965 var2 = (class_3965)var3;
            if (var2.method_17783() == class_240.field_1332 && this.lIIl(var2.method_17777(), var1)) {
               var10000 = true;
               return var10000;
            }
         }

         var10000 = false;
         return var10000;
      } else {
         return false;
      }
   }

   private void lIlll(class_310 var1) {
      this.IlIIl(var1);
      if (var1 != null && var1.field_1724 != null) {
         boolean var2 = var1.field_1761 != null && var1.field_1724.method_6115();
         if (var2) {
            var1.field_1761.method_2897(var1.field_1724);
         } else {
            IllllIlI.IIl(var1);
         }

         this.lI = false;
         this.IIII = var1.field_1724.field_6012;
      }
   }

   private void llIII(class_310 var1) {
      boolean var2 = this.IIllI(var1);
      if (!var2) {
         this.lIl = false;
         this.Ill = false;
      }

   }

   private boolean llIIl(class_746 var1, class_1792 var2) {
      return var1 != null && !var1.method_6047().method_7960() && var1.method_6047().method_31574(var2);
   }

   private static int llIlI(int var0, int var1) {
      return IIlI[var0 ^ 554413899] ^ var1 ^ var0;
   }

   private static String llIll(int var0, int var1, char var2) {
      int var3 = var2 ^ '\ueac6';
      char[] var4 = IIll[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])IlII[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         IlII[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 25393;
      int var9 = 0;

      do {
         int var10 = var4[var9] + 7908;
         var10 ^= 37870;
         var10 -= 848;
         var10 -= 28984;
         var10 ^= 61653;
         var10 -= 50226;
         var4[var9] = (char)(var10 ^ var8 ^ var1 ^ var0 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
