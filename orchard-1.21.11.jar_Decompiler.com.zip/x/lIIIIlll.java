package x;

import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;

@Environment(EnvType.CLIENT)
public final class lIIIIlll extends IIIIIIIlI {
   private static final double I = (double)3.0F;
   private final IlIIIlIlI<<undefinedtype>> l;
   private static final int II = 96;
   private static String[] Il;
   private static final int[] lI;
   private static final String[] ll;
   private static final Object[] III;

   private static void II() {
      Il[0] = ll(IIll(499219306, 58127, '᧯').toCharArray(), 27216L, IIII(226224118, -1768439025));
      Il[1] = ll(IIll(-1051500798, 58126, '抠').toCharArray(), 91072L, IIII(226224119, -1075066314));
      Il[2] = ll(IIll(-1770110533, 58125, '葇').toCharArray(), 14820L, IIII(226224116, -807811458));
   }

   public lIIIIlll() {
      super((Object)lIlIII.l(Il[2]), lIllII.ll, (Object)lIlIII.l(Il[0]));
      this.l = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.Il(Il[1]), <undefinedtype>.class, null.l));
   }

   private static String ll(char[] var0, long var1, int var3) {
      int var4 = IIII(226224117, -427358432) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IIII(226224114, 1939116444);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private Color IlI() {
      Color var1 = this.lII();
      return new Color(IIII(226224115, 1546968776) - var1.getRed(), IIII(226224112, -565371262) - var1.getGreen(), IIII(226224113, -1664916916) - var1.getBlue());
   }

   private Color lII() {
      lIllIIl var1 = lIllIIl.Il();
      lIIIllll var2 = var1 != null && var1.IIl() != null ? var1.IIl().IIII() : null;
      Color var3 = var2 == null ? new Color(IIII(226224126, -508818178), IIII(226224127, -1800520409), IIII(226224124, 1598946942)) : var2.IIllII();
      return new Color(var3.getRed(), var3.getGreen(), var3.getBlue(), IIII(226224125, -1784030950));
   }

   static {
      short var6 = 27501;
      String var7 = "\uea40돪晾ඍ杈\udc12癝梻趼牗͊鮬騶\ue993ଋ䩍簡\u177b䊴\udcedᯖ쥳뼚革\ue4b2ᖑ镴琹㰼뒧ꯉ瑪砏ࠤᖝ⋨ꑪ惘둵冗轱寽꘦⊷⿺\u0bd2ᴻ肆緛儽ᙀ葇ႝ펡ࢣ쏢ᒗ낖㛟ꁁ좲펾㵝ⵐ呂ꙿᚰঠ㏩⒐늌㟎쇓Ẍ滿⋖\uf7a2㓽\ue313교\ue487⣞Θ飤㦇䵘ƴ翰蕺ꅄه焊웃钠\udd11ꭰ⧒腒胅옘歕餭\ue6e8ꕣ턨\udb08\ud84f況餀嚌ᢥ夲쓗앀鶸֒ẻ\u208f鯽遉";
      char[] var8 = "欹歹歽".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            ll = var9;
            III = new Object[var9.length];
            int var2 = 1785515824;
            byte[] var0 = "7WuÕ*\u0097cé\u0099Sèâ?À\u0086Ð\u0014\u0083¹¡;#öô¹Z6½ûÔJr\u0086»$:ó¹\u0015l8ZÖMò¾ñ(<\u0007vg\u0006r¦²".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lI = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lI[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            Il = new String[3];
            II();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public void llIl(llIIllI var1) {
      class_310 var2 = class_310.method_1551();
      if (var2 != null && var2.field_1724 != null && var2.field_1687 != null && IIlIIIIl.IlIII(var1)) {
         float var3 = IllllIlI.IlIIIlI(var2);
         class_243 var4 = IIlIIIIl.IIIII(var2.field_1724, var3);
         class_243 var5 = new class_243(var4.field_1352, var4.field_1351 + 0.04, var4.field_1350);
         boolean var6 = this.llI(var2, var4, var3);
         Color var7 = var6 ? this.IlI() : this.lII();
         IIlIIIIl.llll(var1, var5, (double)3.0F, IIII(226224122, 1527799501), var7, (double)235.0F, 3.0F);
         IIlIIIIl.IlII(var1, var5, (double)3.0F, IIII(226224123, 1634045465), var7, (double)235.0F, 3.0F, false, (var0) -> true);
      }
   }

   private boolean llI(class_310 var1, class_243 var2, float var3) {
      lI var4 = lIllIIl.Il() == null ? null : lIllIIl.Il().IIl().IIIIIll();

      for(class_1657 var6 : var1.field_1687.method_18456()) {
         if (var6 != var1.field_1724 && var6.method_5805() && (var4 == null || !var4.IlI(var6))) {
            class_243 var7 = IIlIIIIl.IIIII(var6, var3);
            class_238 var8 = var6.method_5829().method_989(var7.field_1352 - var6.method_23317(), var7.field_1351 - var6.method_23318(), var7.field_1350 - var6.method_23321());
            boolean var9 = this.l.III() == null.l ? x.IlIllIl.IIlI(var2.field_1352, var2.field_1350, (double)3.0F, var8.field_1323, var8.field_1321, var8.field_1320, var8.field_1324) : x.IlIllIl.IlII(var2.field_1352, var2.field_1350, (double)3.0F, var7.field_1352, var7.field_1350);
            if (var9) {
               return true;
            }
         }
      }

      return false;
   }

   private static int IIII(int var0, int var1) {
      return lI[var0 ^ 226224118] ^ var1 ^ var0;
   }

   private static String IIll(int var0, int var1, char var2) {
      int var3 = var1 ^ '\ue30f';
      char[] var4 = ll[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])III[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         III[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 1094;
      int var9 = 0;

      do {
         int var10 = var4[var9] + 26139;
         var10 ^= 915;
         var10 += 15189;
         var10 ^= 47358;
         var10 += 51900;
         var10 += 33805;
         var10 ^= 47230;
         var10 ^= 42320;
         var10 ^= 16954;
         var10 -= 5770;
         var4[var9] = (char)(var10 ^ var8 ^ var2 ^ var0 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
