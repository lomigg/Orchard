package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public enum IIIlIlIII {
   I,
   l,
   II;

   private final <undefinedtype> Il;
   lI,
   ll,
   IIl;

   private static final int[] IlI;
   private static final String[] Ill;
   private static final Object[] lII;

   public <undefinedtype> I() {
      return this.Il;
   }

   private IIIlIlIII(Object var3) {
      this.Il = var3;
   }

   public String l() {
      return this.Il.lIlI();
   }

   public static IIIlIlIII II(String var0) {
      return (IIIlIlIII)Enum.valueOf(IIIlIlIII.class, var0);
   }

   // $FF: synthetic method
   private static IIIlIlIII[] Il() {
      IIIlIlIII[] var10000 = new IIIlIlIII[lI(-1900314420, -1557102053)];
      var10000[0] = IIl;
      var10000[1] = ll;
      var10000[2] = l;
      var10000[3] = II;
      var10000[4] = I;
      var10000[5] = lI;
      return var10000;
   }

   static {
      short var6 = 9364;
      String var7 = "Ϙϖρϐϙπϒ奝奿奝奸奐奷奻奶奸奚处处륔륨륩륟륅륨륧류륃륒륩륮륧썡쌡썠썵슍썕썠썝썜썮썽슆썓썚썮썳썕썿쌹쌹䪞䪫䪚˧˳˻˙˄˻˳˷똗똃똂똚똁똛똧쵲촲쵳쵾쵺쵷쵁쵮쵮쵴쵊쵊ꌟꌘꌛꌅꌮ䕵䕰䔱䕡䕽䕁䕻䕍䢡䣍䢰䣈䢰䢢눱눙뉇눑눸눑뉇눂";
      char[] var8 = "⒓⒘⒙⒀⒗⒜⒓⒘⒑⒜⒒⒜".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            Ill = var9;
            lII = new Object[var9.length];
            int var2 = -1354935308;
            byte[] var0 = "\u0082¶Q%".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IlI = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IlI[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            IIl = new IIIlIlIII(ll('煝', 1606040383, (short)24915), 0, lIlIII.l(ll('煜', 1466908945, (short)'輺')));
            ll = new IIIlIlIII(ll('煟', 1604261618, (short)'\ue7e4'), 1, lIlIII.l(ll('煞', -792849361, (short)'껆')));
            l = new IIIlIlIII(ll('煙', -187956885, (short)7530), 2, lIlIII.l(ll('煘', 2008163887, (short)18035)));
            II = new IIIlIlIII(ll('煛', -804971171, (short)'锡'), 3, lIlIII.l(ll('煚', 68498193, (short)26746)));
            I = new IIIlIlIII(ll('煕', 1730767022, (short)14596), 4, lIlIII.l(ll('煔', -1565558882, (short)22211)));
            lI = new IIIlIlIII(ll('煗', 1988052811, (short)'鷦'), 5, lIlIII.l(ll('煖', -70233489, (short)'뫿')));
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static int lI(int var0, int var1) {
      return IlI[var0 ^ -1900314420] ^ var1 ^ var0;
   }

   private static String ll(char var0, int var1, short var2) {
      int var3 = var0 ^ 29021;
      char[] var4 = Ill[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])lII[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         lII[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 15605;
      int var9 = 0;

      do {
         int var10 = var4[var9] ^ 7280;
         var10 -= 9974;
         var10 ^= 65220;
         var10 ^= 57721;
         var4[var9] = (char)(var10 ^ var8 ^ var2 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
