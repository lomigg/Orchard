package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class IIlIIlIll extends IIIIIIIlI {
   private static String[] I;
   private static final int[] l;
   private static final String[] II;
   private static final Object[] Il;

   public IIlIIlIll() {
      super((Object)lIlIII.l(I[0]), lIllII.l, (Object)lIlIII.l(I[1]));
   }

   private static void l() {
      I[0] = II(IlI('沿', -1066698256, 15815).toCharArray(), 5014L, ll(1955379699, 1956749967));
      I[1] = II(IlI('赻', -1709169811, 15814).toCharArray(), 1949L, ll(1955379698, -1829718940));
   }

   private static String II(char[] var0, long var1, int var3) {
      int var4 = ll(1955379697, 2078101056) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & ll(1955379696, 51469170);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   static {
      short var6 = 26328;
      String var7 = "눯鐰僷䦊鲱钆쩚鉝\ue1d8ᜫ巗\ue77f鯴\uf79c\uefa3栃윙产\u0a04ꖞ\ude52磌츉滕嚪斞ꦖ딀㞪䪋ꚞ\ud9fc唚\udc98젗䗚ǃ퓶舗僑僮瑁\u0089溔\uf605\udd29\u16fe葧苤䅝씵썔㋌捕셁\ue69b䂽ꀶ㙩\uf4e8南Ʋ쾹稜滠ገ፱枰\uf874悴\ude73\uf858뷅跿珏츤≝쭉ꌃ쒎";
      char[] var8 = "\fD".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            II = var9;
            Il = new Object[var9.length];
            int var2 = 593115865;
            byte[] var0 = "²l¸º\u0019O\u0087¿Mé÷nTÇØ¤".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            l = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               l[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            I = new String[2];
            l();
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 25;
                     break;
                  case 1:
                     var10000 = 99;
                     break;
                  case 2:
                     var10000 = 64;
                     break;
                  case 3:
                     var10000 = 33;
                     break;
                  case 4:
                     var10000 = 60;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static int ll(int var0, int var1) {
      return l[var0 ^ 1955379699] ^ var1 ^ var0;
   }

   private static String IlI(char var0, int var1, int var2) {
      int var3 = var2 ^ 15815;
      char[] var4 = II[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])Il[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         Il[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 14673;
      int var9 = 0;

      do {
         int var10 = var4[var9] + '闦';
         var10 += 65181;
         var10 += 58845;
         var10 -= 49928;
         var10 ^= 43201;
         var10 -= 10289;
         var10 -= 4221;
         var10 += 41976;
         var10 ^= 49824;
         var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
