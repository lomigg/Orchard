package x;

import com.google.gson.JsonObject;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Stream;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_7923;
import y.lIIllll;

@Environment(EnvType.CLIENT)
public final class llIllII extends IIIIIIIlI {
   private static String[] I;
   private final lIIIlll l;
   private static final String II;
   private final llllIlIl Il;
   private static final String lI;
   private static final int[] ll;
   private static final String[] III;
   private static final Object[] IIl;

   private boolean l(class_1799 var1) {
      if (var1 != null && var1.method_7909() instanceof class_1747) {
         List var2 = (List)this.l.III();
         if (var2.isEmpty()) {
            return true;
         } else {
            String var3 = class_7923.field_41178.method_10221(var1.method_7909()).toString();
            return !IlI(var3, var2);
         }
      } else {
         return false;
      }
   }

   private int ll() {
      int var1 = Math.max(1, Math.min(4, (int)Math.round(this.Il.IlII())));
      int var2 = Math.max(var1, Math.min(4, (int)Math.round(this.Il.IlI())));
      return var1 == var2 ? var1 : ThreadLocalRandom.current().nextInt(var1, var2 + 1);
   }

   public void III(class_310 var1) {
      this.IIIl(var1, true);
   }

   static boolean IlI(String var0, List<String> var1) {
      if (var0 != null && !var0.isBlank() && var1 != null && !var1.isEmpty()) {
         String var2 = var0.trim().toLowerCase(Locale.ROOT);
         Stream var10000 = var1.stream().filter((var0x) -> var0x != null && !var0x.isBlank()).map(llIllII::lll);
         Objects.requireNonNull(var2);
         return var10000.anyMatch(var2::equals);
      } else {
         return false;
      }
   }

   private boolean lII(class_310 var1) {
      class_1799 var2 = var1.field_1724.method_6047();
      return var2 != null && var2.method_7909() instanceof class_1747 ? this.l(var2) : this.l(var1.field_1724.method_6079());
   }

   public String Il() {
      int var1 = (int)Math.round(this.Il.IlII());
      int var2 = (int)Math.round(this.Il.IlI());
      String var10000;
      if (var1 == var2) {
         var10000 = Integer.toString(var1);
      } else {
         String var4 = lIlIII.Il(I[IIll(-385726818, 1820945033)]);
         var10000 = var1 + var4 + var2;
      }

      return var10000;
   }

   private static String llI(char[] var0, long var1, int var3) {
      int var4 = IIll(-385726817, -159489664) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IIll(-385726820, 2020781880);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private static String lll(String var0) {
      String var1 = var0.trim().toLowerCase(Locale.ROOT).replace((char)IIll(-385726819, 1784411668), (char)IIll(-385726822, 1788982535));
      String var10000;
      if (var1.contains(lIlIII.Il(I[1]))) {
         var10000 = var1;
      } else {
         String var2 = lIlIII.Il(I[0]);
         var10000 = var2 + var1;
      }

      return var10000;
   }

   private static void IIII() {
      I[0] = llI(IlII(773239865, -1672201826).toCharArray(), 82152L, IIll(-385726821, 170969044));
      I[1] = llI(IlII(773239864, -1576392451).toCharArray(), 56038L, IIll(-385726824, -744053271));
      I[2] = llI(IlII(773239867, -872195105).toCharArray(), 76661L, IIll(-385726823, -1796650568));
      I[3] = llI(IlII(773239866, -2016206268).toCharArray(), 85515L, IIll(-385726826, 1216405896));
      I[4] = llI(IlII(773239869, 609626440).toCharArray(), 34361L, IIll(-385726825, -219696143));
      I[5] = llI(IlII(773239868, -863081441).toCharArray(), 51800L, IIll(-385726828, -32173375));
      I[IIll(-385726827, 936936695)] = llI(IlII(773239871, -1515044542).toCharArray(), 3271L, IIll(-385726830, -824055233));
      I[IIll(-385726829, 154890156)] = llI(IlII(773239870, 2022908973).toCharArray(), 29159L, IIll(-385726832, 1183186716));
      I[IIll(-385726831, 1342341662)] = llI(IlII(773239857, -1238081778).toCharArray(), 1374L, IIll(-385726834, 203083539));
      I[IIll(-385726833, -29131408)] = llI(IlII(773239856, 1132476082).toCharArray(), 68323L, IIll(-385726836, -191131156));
   }

   public llIllII() {
      super((Object)lIlIII.l(I[5]), lIllII.l, (Object)lIlIII.l(I[2]));
      this.Il = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(I[3]), (double)1.0F, (double)4.0F, (double)1.0F, (double)4.0F, (double)1.0F)).IIII(lIlIII.Il(I[4])));
      this.l = (lIIIlll)this.IIIlIll(new lIIIlll(lI, List.of()));
   }

   public void Ill() {
      this.IIIl(class_310.method_1551(), false);
   }

   static {
      short var6 = 21078;
      String var7 = "\udf3a籷\u0af6Ë⟀֮䊳伲⳹멦⭤⑩⮲倿綊ⷆ⽻䃠곬嬥\ue168駚ﲇ\u0fe7臻荾蓵鬰\uf49fશ뷯셎ꐐ쨅\ueffe巆ᒕᱻ\uf384ⱨ셣匘 䑥㷅깘⎭ᠳЌὅ懻愶ಳ\ud96d㏝쀌ꮸ砮ᚓ⤭骶၅狑\ue130\uf773⨯ﰩ隭\uf167\u0ee9煋竅뻽靎쌧ᙔ♼曒ᣴ훞湸檜呍\ue22d썪㴃䣇䢰海뮯轥ᷔ툐\ued58벀垄暸슔溿⿑\uf4e0菪ᝦ丈\ue81dુ\uedda䃶ᔘ\u1ccb\ueffc霸\uf45f\uda11\ue247匀욺坴䤂戔驯丈\udbd6ﺯ\uf54c造ㅇㄷ䷙迋⣿㕘ﹽ㨪\u1fb5痢⌸滧跊㰍";
      char[] var8 = "剆剒剢剞剒剚剚剒剆剚".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            III = var9;
            IIl = new Object[var9.length];
            int var2 = 1586199364;
            byte[] var0 = "Û\u0000WT\u008c(¾\\Ïû\u0092\u001fÝÒËíÝ(\u0088\u0086wM¬z¸¸ï¯\u00ad¤Ü\u001d\u001cz\u0097\u0088óFÙè\u00ad6\u001c¸\u0080Q¹ r2÷8¾²R|\u0004U\f\u0080ç\u008b¿Ã>æ\u0088×IÊ@²uCß¢\u0011GH¾´\u0090²\u0006Ã³òÕï2ÄøSëÆ\f".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            ll = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               ll[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            I = new String[IIll(-385726835, -1496418947)];
            IIII();
            lI = lIlIII.Il(I[IIll(-385726838, 52006849)]);
            II = lIlIII.Il(I[IIll(-385726837, 1950011154)]);
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 97;
                     break;
                  case 1:
                     var10000 = 22;
                     break;
                  case 2:
                     var10000 = 49;
                     break;
                  case 3:
                     var10000 = 37;
                     break;
                  case 4:
                     var10000 = 104;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private void IIIl(class_310 var1, boolean var2) {
      if (this.IIIIIlI() && var1 != null && var1.field_1724 != null && this.lII(var1)) {
         if (!IllllIlI.IlllIl() && !IlIlIl.IIIII() && !lIlIllll.lIIl(var1)) {
            lIIllll var3 = (lIIllll)var1;
            int var4 = this.ll();
            if (var2 || var3.ilovcats$getUseCd() > var4) {
               var3.ilovcats$setUseCd(var4);
            }

         }
      }
   }

   public void IIl(JsonObject var1) {
      if (var1 != null && var1.has(lIlIII.Il(I[IIll(-385726840, 1488714034)]))) {
         JsonObject var2 = var1.getAsJsonObject(lIlIII.Il(I[IIll(-385726839, -463275065)]));
         if (var2 != null && !var2.has(lI) && var2.has(II)) {
            var2.add(lI, var2.get(II).deepCopy());
         }
      }

      super.IIl(var1);
   }

   private static int IIll(int var0, int var1) {
      return ll[var0 ^ -385726818] ^ var1 ^ var0;
   }

   private static String IlII(int var0, int var1) {
      int var3 = var0 ^ 773239865;
      char[] var4 = III[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IIl[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IIl[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -937037725;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 255;
               break;
            case 1:
               var9 = 106;
               break;
            case 2:
               var9 = 72;
               break;
            case 3:
               var9 = 152;
               break;
            case 4:
               var9 = 57;
               break;
            case 5:
               var9 = 216;
               break;
            case 6:
               var9 = 163;
               break;
            case 7:
               var9 = 154;
               break;
            case 8:
               var9 = 62;
               break;
            case 9:
               var9 = 217;
               break;
            case 10:
               var9 = 210;
               break;
            case 11:
               var9 = 88;
               break;
            case 12:
               var9 = 33;
               break;
            case 13:
               var9 = 216;
               break;
            case 14:
               var9 = 57;
               break;
            case 15:
               var9 = 141;
               break;
            case 16:
               var9 = 220;
               break;
            case 17:
               var9 = 146;
               break;
            case 18:
               var9 = 206;
               break;
            case 19:
               var9 = 226;
               break;
            case 20:
               var9 = 191;
               break;
            case 21:
               var9 = 81;
               break;
            case 22:
               var9 = 243;
               break;
            case 23:
               var9 = 197;
               break;
            case 24:
               var9 = 238;
               break;
            case 25:
               var9 = 94;
               break;
            case 26:
               var9 = 206;
               break;
            case 27:
               var9 = 35;
               break;
            case 28:
               var9 = 140;
               break;
            case 29:
               var9 = 187;
               break;
            case 30:
               var9 = 222;
               break;
            case 31:
               var9 = 243;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
