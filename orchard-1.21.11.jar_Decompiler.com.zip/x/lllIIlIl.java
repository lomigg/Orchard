package x;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_3675;
import net.minecraft.class_3675.class_307;

@Environment(EnvType.CLIENT)
public final class lllIIlIl extends llllllI<class_3675.class_306> {
   private static String[] I;
   private static final int[] l;
   private static final String[] II;
   private static final Object[] Il;

   public boolean I() {
      return !IllllIlI.IllllI((class_3675.class_306)this.III());
   }

   public JsonElement lI() {
      JsonElement var1 = IllllIlI.llIIl((class_3675.class_306)this.III());
      if (var1 != null) {
         return var1;
      } else {
         JsonObject var2 = new JsonObject();
         var2.addProperty(lIlIII.Il(I[1]), class_307.field_1668.name());
         var2.addProperty(lIlIII.Il(I[0]), -1);
         return var2;
      }
   }

   public lllIIlIl(Object var1, class_3675.class_306 var2) {
      super((Object)var1, var2);
   }

   private static String l(char[] var0, long var1, int var3) {
      int var4 = IlI(1549121640, 2072073375) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IlI(1549121641, -110791184);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   static {
      short var6 = 1280;
      String var7 = "\ude78〢裣龍訖鵬弟ᒎ佄ᵬ\ue7f5쟮䧖쫚祺Ը";
      char[] var8 = "\b\b".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            II = var9;
            Il = new Object[var9.length];
            int var2 = -1522582793;
            byte[] var0 = "Ú\u0001}\u009b\u0000\u000f÷\u0091Ý°ÃEz\\wè".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            l = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               l[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            I = new String[2];
            III();
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 69;
                     break;
                  case 1:
                     var10000 = 111;
                     break;
                  case 2:
                     var10000 = 53;
                     break;
                  case 3:
                     var10000 = 21;
                     break;
                  case 4:
                     var10000 = 22;
                     break;
                  case 5:
                     var10000 = 127;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public lllIIlIl(Object var1) {
      this(var1, class_3675.field_16237);
   }

   public lllIIlIl(String var1) {
      this((Object)var1);
   }

   public void ll(class_3675.class_306 var1) {
      super.Il(var1 == null ? class_3675.field_16237 : var1);
   }

   public void II(JsonElement var1) {
      this.ll(IllllIlI.lIIIIl(var1));
   }

   private static void III() {
      I[0] = l(Ill(26758, 1952016500, '夓').toCharArray(), 84625L, IlI(1549121642, -717770391));
      I[1] = l(Ill(51395, 1908823238, '夒').toCharArray(), 82435L, IlI(1549121643, -1774345162));
   }

   public lllIIlIl(String var1, class_3675.class_306 var2) {
      this((Object)var1, var2);
   }

   private static int IlI(int var0, int var1) {
      return l[var0 ^ 1549121640] ^ var1 ^ var0;
   }

   private static String Ill(int var0, int var1, char var2) {
      int var3 = var2 ^ 22803;
      char[] var4 = II[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])Il[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         Il[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 17343;
      int var9 = 0;

      do {
         int var10 = var4[var9] + 17423;
         var10 ^= 34876;
         var10 ^= 29141;
         var10 ^= 57937;
         var10 ^= 52291;
         var10 -= 35054;
         var10 ^= 36629;
         var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
