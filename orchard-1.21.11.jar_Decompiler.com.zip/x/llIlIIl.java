package x;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_746;

@Environment(EnvType.CLIENT)
public final class llIlIIl extends IIIIIIIlI {
   private static final int I = 96;
   private final IIIllIIII l;
   private static final double II = 0.035;
   private final List<<undefinedtype>> Il;
   private boolean lI;
   private final IIIllIIII ll;
   private final IIIllIIII III;
   private double IIl;
   private final IIIllIIII IlI;
   private static String[] Ill;
   private static final int[] lII;
   private static final String[] lIl;
   private static final Object[] llI;

   public llIlIIl() {
      super((Object)lIlIII.l(Ill[3]), lIllII.ll, (Object)lIlIII.l(Ill[2]));
      this.III = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(Ill[0]), 1.15, (double)0.25F, (double)3.0F, 0.05)).IIl(lIlIII.Il(Ill[4])));
      this.IlI = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(Ill[lll(1232983302, 217856093)]), (double)900.0F, (double)250.0F, (double)3000.0F, (double)50.0F)).IIl(lIlIII.Il(Ill[1])));
      this.l = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(Ill[5]), 2.2, (double)0.5F, (double)5.0F, 0.1));
      this.ll = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(Ill[lll(1232983303, 111687539)]), (double)190.0F, (double)25.0F, (double)255.0F, (double)1.0F));
      this.Il = new ArrayList();
   }

   public void lI() {
      this.Il.clear();
      this.lI = false;
      this.IIl = (double)0.0F;
   }

   public void llIl(llIIllI var1) {
      if (IIlIIIIl.IlIII(var1)) {
         long var2 = System.currentTimeMillis();
         this.llI(var2);
         if (!this.Il.isEmpty()) {
            Color var4 = this.lII();
            double var5 = Math.max((double)1.0F, (Double)this.IlI.III());
            double var7 = (Double)this.III.III();
            double var9 = (Double)this.ll.III();
            float var11 = ((Double)this.l.III()).floatValue();

            for(<undefinedtype> var13 : this.Il) {
               double var14 = class_3532.method_15350((double)(var2 - var13.I()) / var5, (double)0.0F, (double)1.0F);
               double var16 = (double)1.0F - Math.pow((double)1.0F - var14, (double)3.0F);
               double var18 = var7 * (0.28 + var16 * 0.72);
               double var20 = var9 * Math.pow((double)1.0F - var14, 1.35);
               float var22 = Math.max(0.5F, (float)((double)var11 * ((double)1.0F - var14 * 0.3)));
               IIlIIIIl.llll(var1, var13.l(), var18, lll(1232983300, 1041381887), var4, var20, var22);
            }

         }
      }
   }

   static {
      short var6 = 29260;
      String var7 = "윜㤌⅋ֳ汖\udc0d뿤㮧\uedac螼\ue7f4\uf41c\ue419Ⱙ穀〺밅敵䞭⽜Ṧ胮䉙ꭌ錋ﯬ鍒뼛籧橦蜩漤솂水\ue900䄶Ê虒쨗ボ촢㐡鏄፲渓玥䧽ᵘ浀죭뀬⓻窓꿌븈㱭恸烼塷짪\udb44七კ硋䌚\ue695\ue243爺昻寯锗駴膢緗ථ\udc13ᒟ\ue967쎵\ue0ec䁤\ue124豥맡ꖚ䲚索啠짎栋꼐䳡ڼ륋ɾ꾗嵡灟䵍⦐\u0ef4}됿뤪\uf0a9쀅ਖ虷莁⏬꼅\ueed8넑鬰끟ấ暎䰘齸璙䢙胘唓돦醱㪮撈\ue490ဠ\ue2bbᥢꌜ";
      char[] var8 = "\b\u0004@\u0010\u0004\u0010\b\f".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            lIl = var9;
            llI = new Object[var9.length];
            int var2 = 1179537206;
            byte[] var0 = "\u0003Ï¢j\t\u009b\u00adD1!£\u00ad°1ô¿ÈGfËhÂ\u000f¶|±\u0000]Ô,zu \u0097w9\u001cÎ,Å·7¡^\u0014\u0086uÊßÔVl\u009f©Yõ\u001eR¶s6\u0082Ìâi\u009d'Ý\u0089èi\u001d\u0015QÊ¬\u0018±®½\u0005w,i".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lII = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lII[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            Ill = new String[lll(1232983301, -1090359676)];
            IlI();
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 25;
                     break;
                  case 1:
                     var10000 = 38;
                     break;
                  case 2:
                     var10000 = 0;
                     break;
                  case 3:
                     var10000 = 126;
                     break;
                  case 4:
                     var10000 = 7;
                     break;
                  case 5:
                     var10000 = 46;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public void lIl() {
      this.Il.clear();
      class_310 var1 = class_310.method_1551();
      class_746 var2 = var1 == null ? null : var1.field_1724;
      this.lI = var2 != null && var2.method_24828();
      this.IIl = var2 == null ? (double)0.0F : var2.method_5829().field_1322;
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      class_746 var2 = var1 == null ? null : var1.field_1724;
      if (var2 != null && var1.field_1687 != null) {
         boolean var3 = var2.method_24828();
         if (var3) {
            this.IIl = var2.method_5829().field_1322;
         } else if (this.lI && var2.method_18798().field_1351 > 0.08) {
            this.Il.add(new Record(new class_243(var2.method_23317(), this.IIl + 0.035, var2.method_23321()), System.currentTimeMillis()) {
               private final long I;
               private final class_243 l;

               private {
                  this.l = var1;
                  this.I = var2;
               }

               public long I() {
                  return this.I;
               }

               public class_243 l() {
                  return this.l;
               }
            });
         }

         this.lI = var3;
         this.llI(System.currentTimeMillis());
      } else {
         this.Il.clear();
         this.lI = false;
      }
   }

   private static String ll(char[] var0, long var1, int var3) {
      int var4 = lll(1232983298, -740973610) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & lll(1232983299, 1743885692);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private static void IlI() {
      Ill[0] = ll(IIII('䨠', -1840118329, (short)'\ufefd').toCharArray(), 41877L, lll(1232983296, 200972840));
      Ill[1] = ll(IIII('䨡', -2146734143, (short)'\ua955').toCharArray(), 11373L, lll(1232983297, 2095399117));
      Ill[2] = ll(IIII('䨢', 1826382742, (short)10255).toCharArray(), 94975L, lll(1232983310, -1272674260));
      Ill[3] = ll(IIII('䨣', -488886877, (short)'蔑').toCharArray(), 89123L, lll(1232983311, 2128823166));
      Ill[4] = ll(IIII('䨤', 966133349, (short)'왡').toCharArray(), 3464L, lll(1232983308, 1511082589));
      Ill[5] = ll(IIII('䨥', -899280258, (short)'蒬').toCharArray(), 53546L, lll(1232983309, -1040690209));
      Ill[lll(1232983306, -790115242)] = ll(IIII('䨦', -2131798037, (short)4402).toCharArray(), 19369L, lll(1232983307, -1259530026));
      Ill[lll(1232983304, 291581002)] = ll(IIII('䨧', 643190984, (short)'눜').toCharArray(), 78919L, lll(1232983305, -1795872621));
   }

   private Color lII() {
      lIllIIl var1 = lIllIIl.Il();
      lIIIllll var2 = var1 != null && var1.IIl() != null ? var1.IIl().IIII() : null;
      Color var3 = var2 == null ? new Color(lll(1232983318, 1722727682), lll(1232983319, -2032405646), lll(1232983316, 442650858), lll(1232983317, 394409057)) : var2.lllI();
      int var4 = class_3532.method_15340((int)Math.round((Double)this.ll.III()), 0, lll(1232983314, 172275378));
      return new Color(var3.getRed(), var3.getGreen(), var3.getBlue(), var4);
   }

   private void llI(long var1) {
      double var3 = Math.max((double)1.0F, (Double)this.IlI.III());
      Iterator var5 = this.Il.iterator();

      while(var5.hasNext()) {
         if ((double)(var1 - ((<undefinedtype>)var5.next()).I()) > var3) {
            var5.remove();
         }
      }

   }

   private static int lll(int var0, int var1) {
      return lII[var0 ^ 1232983302] ^ var1 ^ var0;
   }

   private static String IIII(char var0, int var1, short var2) {
      int var3 = var0 ^ 18976;
      char[] var4 = lIl[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])llI[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         llI[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 24939;
      int var9 = 0;

      do {
         int var10 = var4[var9] + 28645;
         var10 ^= 19672;
         var10 ^= 60936;
         var10 -= 64106;
         var10 += 20659;
         var10 += 62406;
         var10 ^= 22062;
         var10 ^= 44994;
         var10 += 26360;
         var10 -= 33259;
         var4[var9] = (char)(var10 ^ var8 ^ var2 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
