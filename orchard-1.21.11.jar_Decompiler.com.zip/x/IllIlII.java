package x;

import java.util.HashSet;
import java.util.Set;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1661;
import net.minecraft.class_1684;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;

@Environment(EnvType.CLIENT)
public final class IllIlII extends IIIIIIIlI {
   private static String[] I;
   private final IlIIIlIlI<<undefinedtype>> l;
   private final Set<Integer> II;
   private final lIIIIl Il;
   private static final int[] lI;
   private static final String[] ll;
   private static final Object[] III;

   public void lI() {
      this.II.clear();
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (this.IIIIIlI() && var1.field_1724 != null && var1.field_1687 != null) {
         class_1684 var2 = this.lII(var1);
         if (var2 != null) {
            class_1297 var3 = var2.method_24921();
            if ((Boolean)this.Il.III() && var3 instanceof class_1309) {
               class_1309 var4 = (class_1309)var3;
               if (var1.field_1724.method_6032() < var4.method_6032()) {
                  this.II.add(var2.method_5628());
                  return;
               }
            }

            int var13 = this.IIII(var1.field_1724.method_31548(), class_1802.field_8634);
            if (var13 >= 0) {
               this.II.add(var2.method_5628());
               class_243 var5 = new class_243(var2.method_23317(), var2.method_23318(), var2.method_23321());
               class_243 var6 = var1.field_1724.method_33571();
               class_243 var7 = var5.method_1020(var6);
               double var8 = Math.sqrt(var7.field_1352 * var7.field_1352 + var7.field_1350 * var7.field_1350);
               float var10 = (float)(class_3532.method_15349(var7.field_1350, var7.field_1352) * (180D / Math.PI)) - 90.0F;
               float var11 = (float)(-(class_3532.method_15349(var7.field_1351, var8) * (180D / Math.PI)));
               if (this.l.III() == null.lI) {
                  var1.field_1724.method_36456(var10);
                  var1.field_1724.method_36457(var11);
               }

               IlIlIl.IIIlIl(var1, IIll(156447746, -1037156418), var10, var11, () -> IllllIlI.llIll(var1, this, var13, () -> {
                     if (var1.field_1724 != null && var1.field_1724.method_31548().method_5438(var13).method_31574(class_1802.field_8634)) {
                        boolean var2 = IllllIlI.IlIll(var1, class_1268.field_5808);
                        if (var2) {
                           var1.field_1724.method_6104(class_1268.field_5808);
                        }

                        return var2;
                     } else {
                        return false;
                     }
                  }));
            }
         }
      } else {
         this.II.clear();
      }
   }

   private static void IlI() {
      I[0] = lll(IlII((short)'갛', 255421865, 43238).toCharArray(), 39224L, IIll(156447747, 1310802803));
      I[1] = lll(IlII((short)18993, -1453509102, 43239).toCharArray(), 68712L, IIll(156447744, -1472000507));
      I[2] = lll(IlII((short)12463, 330391887, 43236).toCharArray(), 89665L, IIll(156447745, -574156500));
      I[3] = lll(IlII((short)11177, 1513575159, 43237).toCharArray(), 59986L, IIll(156447750, -1624837929));
   }

   private class_1684 lII(class_310 var1) {
      if (var1.field_1687 != null && var1.field_1724 != null) {
         for(class_1297 var3 : var1.field_1687.method_18112()) {
            if (var3 instanceof class_1684) {
               class_1684 var4 = (class_1684)var3;
               if (!var4.method_31481() && !this.II.contains(var4.method_5628())) {
                  class_1297 var5 = var4.method_24921();
                  if (var5 != null && !var5.method_5667().equals(var1.field_1724.method_5667())) {
                     return var4;
                  }
               }
            }
         }

         return null;
      } else {
         return null;
      }
   }

   static {
      short var6 = 17346;
      String var7 = "䚾ﺘ\ue6d0◲맵㈳ㅰ\uf464恦즩ꔳ簒灨⁽啄︇菧䩉᪲\ud9dc\uf5c1㱎퓝ᑋ龒闳ꉝ꺿\uf1d6驋錅\ud807憟㶩훠᥇鐩㍘켐쬻떏ݠ推㼹\ud8b4튬魥ْ\udbe9떬㷄魣쩈剌\ue3fd\ue962씏ꋷ朲섩繸请掆\u31e6\uebf1⍧妤臆䊵倳䭞闐겤ꪲ♄륖炼ꦠ\ue31d뷿娣\ufd91﹊녿ᑊ\ueffdᝐꏾￖ軱㳭龥篗ꩊ㡰赈⏠\udaa2\ue8a0ᄲⷘ㢶쑗ꅡ싚譠쯁\ue97bᛞ䩏믇퀧퇜艩⯊篜衃똧ᡋ䖞팯덗줪己춹\ueabf娚㛟鲏\uf23b離嵀뭺ﭮ䬓塨琹쨟烌콗붟ಖ֞렋ᗫટ獵癫䴀혇ﶆ⯴疝퇓쮲ᑮ茭ጾ抉ㆲ埸హ傲\ueab9莙䳩ݔ谽蔾㼖ꈹ芊";
      char[] var8 = "䎺䏒䏒䏖".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            ll = var9;
            III = new Object[var9.length];
            int var2 = -1092128036;
            byte[] var0 = "u\u009ay\u009a\u009b\u00830©3\r!STÄ  ]t\u008d\u0007õçÃÓ\u008b\u001eQdBÕGê".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lI = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lI[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            I = new String[4];
            IlI();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static String lll(char[] var0, long var1, int var3) {
      int var4 = IIll(156447751, -480961190) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IIll(156447748, 1017780035);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   public IllIlII() {
      super((Object)lIlIII.l(I[1]), lIllII.l, (Object)lIlIII.l(I[0]));
      this.l = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(I[3]), <undefinedtype>.class, null.l));
      this.Il = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(I[2]), false));
      this.II = new HashSet();
   }

   private int IIII(class_1661 var1, class_1792 var2) {
      if (var1 != null && var2 != null) {
         for(int var3 = 0; var3 < IIll(156447749, -178192070); ++var3) {
            if (var1.method_5438(var3).method_31574(var2)) {
               return var3;
            }
         }

         return -1;
      } else {
         return -1;
      }
   }

   private static int IIll(int var0, int var1) {
      return lI[var0 ^ 156447746] ^ var1 ^ var0;
   }

   private static String IlII(short var0, int var1, int var2) {
      int var3 = var2 ^ '꣦';
      char[] var4 = ll[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])III[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         III[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 24661;
      int var9 = 0;

      do {
         int var10 = var4[var9] + '過';
         var10 -= 5343;
         var10 ^= 32247;
         var10 -= 40007;
         var10 += 52568;
         var10 -= 1480;
         var10 ^= 20557;
         var10 -= 3689;
         var10 -= 45210;
         var10 -= 59622;
         var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
