package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class IIIlll extends lIIlIIII {
   private static String[] I;
   private static final int[] lIIl;
   private static final String[] lIll;
   private static final Object[] llII;

   private static String lIlIl(char[] var0, long var1, int var3) {
      int var4 = lIlll(968982098, -1953601080) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & lIlll(968982099, 1282234781);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private static void lIllI() {
      I[0] = lIlIl(llIIl(40552, -594280243, 7954).toCharArray(), 71706L, lIlll(968982096, 14215722));
      I[1] = lIlIl(llIIl(40553, 550203046, 16004).toCharArray(), 53670L, lIlll(968982097, 243336190));
   }

   static {
      short var6 = 4085;
      String var7 = "ꮈ\uda42\uf0abͶ⬫鄊ꮅⶫส㜛⠖₃탎諑伂蝘糇過롄爕䌼\ud917鄌\u202a⻤覙䞹喎뽭ﭥ틞콨ꈈ뻨⭌퉩꙰╒\ue041\ud89d졄╪幙⇽넲䥩颭∝\ue3a9\uf45a\u1bf8폅굋\ufb08ꮫ悅ᄷ䵲쳼寂䊯Ꟶ梛ꎕ᥆Ᏺ逤沂怄觬鉽蔝";
      char[] var8 = "\u0fe5\u0fcd".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            lIll = var9;
            llII = new Object[var9.length];
            int var2 = -920054165;
            byte[] var0 = "\u0002ô.,¼\u00851Z.ÉJádymP".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lIIl = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lIIl[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            I = new String[2];
            lIllI();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 126;
                     break;
                  case 1:
                     var10000 = 55;
                     break;
                  case 2:
                     var10000 = 22;
                     break;
                  case 3:
                     var10000 = 11;
                     break;
                  case 4:
                     var10000 = 54;
                     break;
                  case 5:
                     var10000 = 120;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public IIIlll() {
      super(lIlIII.l(I[0]), lIlIII.l(I[1]), null.I, false);
   }

   private static int lIlll(int var0, int var1) {
      return lIIl[var0 ^ 968982098] ^ var1 ^ var0;
   }

   private static String llIIl(int var0, int var1, int var2) {
      int var3 = var0 ^ '鹨';
      char[] var4 = lIll[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])llII[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         llII[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 15710;
      int var9 = 0;

      do {
         int var10 = var4[var9] + '资';
         var10 -= 985;
         var10 -= 53574;
         var10 += 206;
         var10 += 56305;
         var10 += 40750;
         var10 -= 57378;
         var10 += 60556;
         var10 += 18327;
         var10 += 35988;
         var4[var9] = (char)(var10 ^ var8 ^ var2 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
