package x;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class IIllIII implements ClientModInitializer {
   public void onInitializeClient() {
   }
}
