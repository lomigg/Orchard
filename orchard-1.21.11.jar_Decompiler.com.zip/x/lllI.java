package x;

import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10185;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_3675;
import net.minecraft.class_744;

@Environment(EnvType.CLIENT)
public final class lllI {
   private final Map<class_304, Map<Object, Boolean>> I = new IdentityHashMap();
   private final Map<class_304, Boolean> l = new IdentityHashMap();
   private static final lllI II = new lllI();

   public void I(class_310 var1) {
      if (!this.I.isEmpty() && !III(var1)) {
         this.l(var1, false);
      }

   }

   private void l(class_310 var1, boolean var2) {
      for(class_304 var4 : Set.copyOf(this.I.keySet())) {
         this.IIII(var1, var4, var2);
      }

      this.I.clear();
      this.l.clear();
   }

   private boolean II(class_304 var1, boolean var2) {
      Map var3 = (Map)this.I.get(var1);
      return var3 != null && !var3.isEmpty() ? lI(var3) : var2;
   }

   public void Il(class_315 var1, class_744 var2) {
      if (III(class_310.method_1551()) && var1 != null && var2 != null && !this.I.isEmpty()) {
         class_10185 var3 = var2.field_54155;
         boolean var4 = this.II(var1.field_1894, var3.comp_3159());
         boolean var5 = this.II(var1.field_1881, var3.comp_3160());
         boolean var6 = this.II(var1.field_1913, var3.comp_3161());
         boolean var7 = this.II(var1.field_1849, var3.comp_3162());
         boolean var8 = this.II(var1.field_1903, var3.comp_3163());
         boolean var9 = this.II(var1.field_1832, var3.comp_3164());
         boolean var10 = this.II(var1.field_1867, var3.comp_3165());
         var2.field_54155 = new class_10185(var4, var5, var6, var7, var8, var9, var10);
         float var11 = var4 == var5 ? 0.0F : (var4 ? 1.0F : -1.0F);
         float var12 = var6 == var7 ? 0.0F : (var6 ? 1.0F : -1.0F);
         if (var11 != 0.0F && var12 != 0.0F) {
            float var13 = 0.70710677F;
            var11 *= var13;
            var12 *= var13;
         }

         IllllIlI.llIIIl(var2, var11, var12);
      }
   }

   private static boolean lI(Map<Object, Boolean> var0) {
      return var0 != null && !var0.isEmpty() && !var0.containsValue(Boolean.FALSE) ? var0.containsValue(Boolean.TRUE) : false;
   }

   public boolean ll(class_3675.class_306 var1) {
      if (IllllIlI.IllllI(var1)) {
         return false;
      } else {
         for(class_304 var3 : this.I.keySet()) {
            if (var1.equals(IllllIlI.IIIlIIl(var3))) {
               return true;
            }
         }

         return false;
      }
   }

   private static boolean III(class_310 var0) {
      return var0 != null && var0.field_1755 == null && var0.method_22683() != null && var0.method_1569();
   }

   public void IIl(Object var1, class_310 var2) {
      if (var1 != null) {
         for(class_304 var4 : Set.copyOf(this.I.keySet())) {
            this.llI(var1, var2, var4);
         }

      }
   }

   public void IlI(Object var1, class_310 var2, class_304 var3, boolean var4) {
      if (var1 != null && var3 != null) {
         if (!III(var2)) {
            this.llI(var1, var2, var3);
         } else {
            Map var5 = (Map)this.I.computeIfAbsent(var3, (var0) -> new IdentityHashMap());
            boolean var6 = var5.isEmpty() ? IllllIlI.IIIll(var2, var3) : lI(var5);
            if (var5.isEmpty()) {
               this.l.put(var3, var6);
            }

            var5.put(var1, var4);
            boolean var7 = lI(var5);
            this.lIl(var3, var7, !var6 && var7);
         }
      }
   }

   public void lII(class_310 var1) {
      this.l(var1, true);
   }

   private void lIl(class_304 var1, boolean var2, boolean var3) {
      var1.method_23481(var2);
      class_3675.class_306 var4 = IllllIlI.IIIlIIl(var1);
      if (!IllllIlI.IllllI(var4)) {
         class_304.method_1416(var4, var2);
         if (var3) {
            class_304.method_1420(var4);
         }
      }

   }

   private void llI(Object var1, class_310 var2, class_304 var3) {
      Map var4 = (Map)this.I.get(var3);
      if (var4 != null && var4.remove(var1) != null) {
         if (!var4.isEmpty()) {
            this.lIl(var3, lI(var4), false);
         } else {
            this.I.remove(var3);
            this.IIII(var2, var3, true);
         }
      }
   }

   public static lllI lll() {
      return II;
   }

   private void IIII(class_310 var1, class_304 var2, boolean var3) {
      boolean var10000;
      label31: {
         boolean var4 = (Boolean)this.l.getOrDefault(var2, false);
         if (var3) {
            label30: {
               if (var1 == null) {
                  if (!var4) {
                     break label30;
                  }
               } else if (!IllllIlI.IIIll(var1, var2)) {
                  break label30;
               }

               var10000 = true;
               break label31;
            }
         }

         var10000 = false;
      }

      boolean var5 = var10000;
      this.l.remove(var2);
      this.lIl(var2, var5, false);
   }

   public void IIIl(Object var1, class_310 var2, class_304 var3) {
      if (var1 != null && var3 != null) {
         this.llI(var1, var2, var3);
      }

   }
}
