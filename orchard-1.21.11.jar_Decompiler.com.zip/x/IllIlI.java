package x;

import java.util.Locale;
import java.util.Objects;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

@Environment(EnvType.CLIENT)
public final class IllIlI extends IIIIIIIlI implements llIlIIII {
   private static final double I = (double)4.0F;
   private static final double l = (double)7.0F;
   private final IIIllIIII II;
   private static final <undefinedtype> Il;
   private static String[] lI;
   private double ll;
   private static final double III = (double)18.0F;
   private final IIIllIIII IIl;
   private final IIIllIIII IlI;
   private static final int[] Ill;
   private static final String[] lII;
   private static final Object[] lIl;

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (var1 != null && var1.field_1724 != null) {
         class_243 var2 = var1.field_1724.method_18798();
         this.ll = Math.hypot(var2.field_1352, var2.field_1350) * (double)20.0F;
      } else {
         this.ll = (double)0.0F;
      }
   }

   public boolean IIlI(double var1, double var3) {
      return var1 >= this.Il() && var1 <= this.Il() + this.llll() && var3 >= this.Ill() && var3 <= this.Ill() + this.lIIl();
   }

   public void III(class_332 var1, int var2, int var3, float var4, boolean var5) {
      this.IIll(var1, var5);
   }

   public double Il() {
      return (Double)this.IlI.III();
   }

   public void IIIlI(class_332 var1, int var2, int var3, float var4) {
      this.IIll(var1, false);
   }

   public double llll() {
      class_310 var1 = class_310.method_1551();
      return var1 != null && var1.field_1772 != null ? this.ll(var1.field_1772, this.IlI()) * this.llI() : (double)48.0F * this.llI();
   }

   private double ll(class_327 var1, String var2) {
      return (double)14.0F + (double)IIIIIIllI.IlIl(var1, lIlIII.Il(lI[IlII(850927634, 599157404)])) + (double)4.0F + (double)IIIIIIllI.IlIl(var1, var2);
   }

   public double Ill() {
      return (Double)this.IIl.III();
   }

   static {
      short var6 = 8860;
      String var7 = "夂뼒\uf71d矐⠓\uf8ab礕儑\udc7c踓ㄐ쇌㩲뾻敖湯坙Ȱ龥Տ삈㮠ꉵ쳒◝魃ڎ誕＄驿ఝ䩐牧\ue39a蠒料ࣇ\ufdd9譌胪发㘔\uef77\u2d68떌㡥䳮셾벞ﮩ\ufb45劌\ue709ṋ疔鳜⣥\uf681橑⬑틥㨱ᒟ瓊뢚轗\u2e62ῦƬ嵹퇐\uebaa㍖\u243fᅮ鶆킷描\ue908㷊뚺䁆Ꮫ\ude66\udaf3\uab18ꕮ\ue5ed꯶꺎믗줰\ue108\uf79bﾍ東穦悑纚㘥襉쇜렇츉⫎︱\udb7e榛鿅ᆽἑ쨅羓䰪්ŷ╰᳧ಿ㽤\ue845\uf0d7㿯豦";
      char[] var8 = "\u0004\u0004\u0004\u0004\b\u0004T\u0004\b".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            lII = var9;
            lIl = new Object[var9.length];
            int var2 = -534253096;
            byte[] var0 = "ñ)»Q!e4\u0089é{,\\GÕ¯ª1\u0083 ê{GaN\u0094²½:Ã\u001f¢\n¢î]u\u0091\u0096ÀvBM\u001c³kM\u0014Ø¿\u001b6\u0084l\u001f$lÌÒÙ¶gÈ\u000e1\u0014$?\u0001_(¿ì\u0015Ãô\u0087¹ÈN8xõ e".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            Ill = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               Ill[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            lI = new String[IlII(850927635, -201661109)];
            lII();
            Il = null.ll;
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 4;
                     break;
                  case 1:
                     var10000 = 77;
                     break;
                  case 2:
                     var10000 = 103;
                     break;
                  case 3:
                     var10000 = 111;
                     break;
                  case 4:
                     var10000 = 60;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private String IlI() {
      return String.format(Locale.ROOT, lIlIII.Il(lI[IlII(850927632, 1004862876)]), this.ll);
   }

   private static void lII() {
      lI[0] = lll(IlIl(1118661947, '旋', (short)28472).toCharArray(), 74382L, IlII(850927633, -605172218));
      lI[1] = lll(IlIl(1694180047, '旊', (short)28817).toCharArray(), 65515L, IlII(850927638, 195260710));
      lI[2] = lll(IlIl(365695434, '旉', (short)222).toCharArray(), 85075L, IlII(850927639, 358422010));
      lI[3] = lll(IlIl(1386504131, '旈', (short)32196).toCharArray(), 29011L, IlII(850927636, 417769207));
      lI[4] = lll(IlIl(988550910, '族', (short)'뮻').toCharArray(), 53517L, IlII(850927637, -384824344));
      lI[5] = lll(IlIl(208431080, '旎', (short)'ꑲ').toCharArray(), 79470L, IlII(850927642, -1579809886));
      lI[IlII(850927643, 1124667827)] = lll(IlIl(452994988, '旍', (short)'\uf686').toCharArray(), 75335L, IlII(850927640, -812935412));
      lI[IlII(850927641, -1177369314)] = lll(IlIl(-1478809437, '旌', (short)'ꎖ').toCharArray(), 94095L, IlII(850927646, 1463819987));
      lI[IlII(850927647, -1098844765)] = lll(IlIl(-769308903, '旃', (short)'삆').toCharArray(), 9100L, IlII(850927644, -1730121667));
   }

   private double llI() {
      return (Double)this.II.III() / (double)100.0F;
   }

   private static String lll(char[] var0, long var1, int var3) {
      int var4 = IlII(850927645, -1293309979) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IlII(850927618, -960762332);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   public void lIlI(double var1, double var3) {
      this.IlI.III(Math.max((double)0.0F, var1));
      this.IIl.III(Math.max((double)0.0F, var3));
   }

   public IllIlI() {
      super((Object)lIlIII.l(lI[2]), lIllII.IIl, (Object)lIlIII.l(lI[IlII(850927616, -950262439)]));
      this.IlI = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(lI[3]), (double)18.0F, (double)0.0F, (double)4000.0F, (double)1.0F)).IIl(lIlIII.Il(lI[0])));
      this.IIl = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(lI[5]), (double)99.0F, (double)0.0F, (double)4000.0F, (double)1.0F)).IIl(lIlIII.Il(lI[0])));
      this.II = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(lI[4]), (double)100.0F, (double)75.0F, (double)200.0F, (double)5.0F)).IIl(lIlIII.Il(lI[1])));
   }

   public void IIl(class_332 var1, int var2, int var3, float var4) {
      this.IIll(var1, false);
   }

   public double lIIl() {
      return (double)18.0F * this.llI();
   }

   private void IIll(class_332 var1, boolean var2) {
      class_310 var3 = class_310.method_1551();
      if (var1 != null && var3 != null && var3.field_1772 != null) {
         double var4 = this.llI();
         double var6 = this.Il();
         double var8 = this.Ill();
         class_327 var10 = var3.field_1772;
         String var11 = lIlIII.Il(lI[IlII(850927617, 1800904678)]);
         String var12 = this.IlI();
         double var13 = this.ll(var10, var12);
         IIIIIIllI.IIIllI(var1);
         IIIIIIllI.IlII(var1, var6, var8);
         IIIIIIllI.lllI(var1, var4, var4);

         try {
            lllIIlI.lI(var1, Il, (double)0.0F, (double)0.0F, var13, (double)18.0F, var2);
            double var15 = (double)7.0F;
            double var17 = var15 + (double)IIIIIIllI.IlIl(var10, var11) + (double)4.0F;
            Objects.requireNonNull(var10);
            double var19 = ((double)18.0F - (double)9.0F) * (double)0.5F;
            IIIIIIllI.IlIIll(true, () -> IIIIIIllI.llIl(var1, var10, var11, var15, var19, lllIIlI.Illl(IlII(850927619, -1917358398))));
            IIIIIIllI.llIl(var1, var10, var12, var17, var19, lllIIlI.Illl(IlII(850927622, -1435831986)));
         } finally {
            IIIIIIllI.lIIlIl(var1);
         }

      }
   }

   private static int IlII(int var0, int var1) {
      return Ill[var0 ^ 850927634] ^ var1 ^ var0;
   }

   private static String IlIl(int var0, char var1, short var2) {
      int var3 = var1 ^ 26059;
      char[] var4 = lII[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])lIl[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         lIl[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 15684;
      int var9 = 0;

      do {
         int var10 = var4[var9] - '\ue917';
         var10 ^= 40958;
         var10 += 16145;
         var10 += 60920;
         var10 ^= 10087;
         var10 -= 4710;
         var10 += 37697;
         var10 += 50556;
         var4[var9] = (char)(var10 ^ var8 ^ var2 ^ var0 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
