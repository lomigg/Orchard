package x;

import java.util.ArrayDeque;
import java.util.Deque;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_746;

@Environment(EnvType.CLIENT)
public final class IlIIIIIIl {
   private static final Deque<<undefinedtype>> I;
   private static final int[] l;

   private IlIIIIIIl() {
   }

   static {
      int var2 = 115680804;
      byte[] var0 = "d`X\u000e¢Ä3ý3\u001d\u007f\u0014".getBytes("ISO-8859-1");
      int var1 = var0.length / 4;
      l = new int[var1];
      int var3 = 0;
      int var4 = 0;

      do {
         int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
         var5 ^= var2;
         l[var4] = var5;
         var3 += 4;
         ++var4;
      } while(var4 < var1);

      I = new ArrayDeque();
   }

   public static void I(IIIIIIIlI var0) {
      class_310 var1 = class_310.method_1551();
      if (var0 != null && !I.isEmpty() && var1.field_1724 != null) {
         <undefinedtype> var2 = (<undefinedtype>)I.peek();
         if (var2 != null && var2.lI == var0) {
            I.pop();
            <undefinedtype> var3 = (<undefinedtype>)I.peek();
            int var4 = var3 != null ? var3.IlI : var2.ll;
            boolean var5 = var3 != null ? var3.Il : var2.III;
            if (var2.l) {
               lI(var1.field_1724, var4, var5);
            }

            if (var2.IIl != null) {
               var2.IIl.run();
            }
         }

      }
   }

   public static boolean l(IIIIIIIlI var0, int var1, boolean var2) {
      return II(var0, var1, var2, 0, true, (Runnable)null);
   }

   public static boolean II(IIIIIIIlI var0, int var1, boolean var2, int var3, boolean var4, Runnable var5) {
      class_310 var6 = class_310.method_1551();
      if (var0 != null && var6.field_1724 != null) {
         if (var1 >= 0 && var1 <= IlI(-1782571478, -146448376)) {
            <undefinedtype> var7 = (<undefinedtype>)I.peek();
            if (var7 != null && var7.lI == var0) {
               var7.IlI = var1;
               var7.Il = var2;
               var7.l = var4;
               var7.I = var3 < 0 ? Long.MAX_VALUE : (long)(var6.field_1724.field_6012 + var3);
               var7.II = var3 <= 0 ? null.II : null.l;
               var7.IIl = var5;
               lI(var6.field_1724, var1, var2);
               return true;
            } else if (ll(var0)) {
               return false;
            } else {
               int var8 = Il(var6.field_1724);
               if (var8 == var1) {
                  return false;
               } else {
                  <undefinedtype> var9 = (<undefinedtype>)I.peekLast();
                  int var10 = var9 != null ? var9.ll : var8;
                  boolean var11 = var9 != null ? var9.III : var2;
                  long var12 = var3 < 0 ? Long.MAX_VALUE : (long)(var6.field_1724.field_6012 + var3);
                  <undefinedtype> var14 = var3 <= 0 ? null.II : null.l;
                  I.push(new Object(var0, var10, var11, var1, var2, var4, var12, var14, var5) {
                     long I;
                     boolean l;
                     <undefinedtype> II;
                     boolean Il;
                     final IIIIIIIlI lI;
                     final int ll;
                     final boolean III;
                     Runnable IIl;
                     int IlI;

                     {
                        this.lI = var1;
                        this.ll = var2;
                        this.III = var3;
                        this.IlI = var4;
                        this.Il = var5;
                        this.l = var6;
                        this.I = var7;
                        this.II = var9;
                        this.IIl = var10;
                     }
                  });
                  lI(var6.field_1724, var1, var2);
                  return true;
               }
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public static int Il(class_746 var0) {
      if (var0 == null) {
         return -1;
      } else {
         <undefinedtype> var1 = (<undefinedtype>)I.peek();
         return var1 != null ? var1.IlI : var0.method_31548().method_67532();
      }
   }

   private static void lI(class_746 var0, int var1, boolean var2) {
      if (var0 != null && var1 >= 0 && var1 <= IlI(-1782571477, 836832250)) {
         var0.method_31548().method_61496(var1);
      }
   }

   public static boolean ll(IIIIIIIlI var0) {
      if (var0 == null) {
         return false;
      } else {
         for(<undefinedtype> var2 : I) {
            if (var2.lI == var0) {
               return true;
            }
         }

         return false;
      }
   }

   public static boolean III(IIIIIIIlI var0, int var1, boolean var2, int var3, boolean var4, Runnable var5) {
      class_310 var6 = class_310.method_1551();
      if (var0 != null && var6.field_1724 != null) {
         if (var1 >= 0 && var1 <= IlI(-1782571480, -1606924528)) {
            int var7 = Il(var6.field_1724);
            return var7 == var1 && !ll(var0) ? true : II(var0, var1, var2, var3, var4, var5);
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public static boolean IIl(IIIIIIIlI var0, int var1, boolean var2, int var3) {
      return II(var0, var1, var2, var3, true, (Runnable)null);
   }

   private static int IlI(int var0, int var1) {
      return l[var0 ^ -1782571478] ^ var1 ^ var0;
   }
}
