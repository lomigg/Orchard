package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10055;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2828;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_746;
import net.minecraft.class_239.class_240;
import y.lllll;

@Environment(EnvType.CLIENT)
public final class IlIlIl {
   private static boolean I;
   private static float l;
   private static boolean II;
   private static int Il;
   private static boolean lI;
   private static float ll;
   private static int III;
   public static final int IIl = 300;
   private static float IlI;
   private static float Ill;
   private static boolean lII;
   public static final int lIl = 400;
   private static final <undefinedtype> llI;
   public static final int lll = 175;
   public static final int IIII = 50;
   private static boolean IIIl;
   private static float IIlI;
   private static boolean IIll;
   public static final int IlII = 300;
   private static boolean IlIl;
   private static float IllI;
   private static final double Illl = 0.1;
   private static float lIII;
   public static final int lIIl = 200;
   private static int lIlI;
   private static int lIll;
   private static boolean llII;
   private static int llIl;
   private static float lllI;
   private static int llll;
   public static final int IIIII = 150;
   private static boolean IIIIl;
   private static float IIIlI;
   private static final int IIIll = 3;
   private static boolean IIlII;
   private static float IIlIl;
   private static int IIllI;
   private static float IIlll;
   public static final int IlIII = 250;
   private static boolean IlIIl;
   private static int IlIlI;
   private static boolean IlIll;
   private static int IllII;
   public static final int IllIl = 100;
   private static float IlllI;
   private static boolean Illll;
   private static float lIIII;
   private static float lIIIl;
   private static <undefinedtype> lIIlI;
   private static float lIIll;
   private static final int[] lIlII;

   public static boolean I(class_310 var0) {
      return false;
   }

   public static boolean l(class_310 var0, Object var1, int var2, float var3, float var4, Object var5, Object var6) {
      boolean var7 = IIIlll(var0, var2, var3, var4, var5);
      if (var6 != null) {
         var6.I(var7);
      }

      return var7;
   }

   public static boolean Il(class_310 var0, int var1, class_243 var2, Object var3) {
      if (lll(var0) && var2 != null) {
         float[] var4 = IlII(var0.field_1724.method_33571(), var2);
         return IlIll(var0, var1, var4[0], var4[1], var3);
      } else {
         return false;
      }
   }

   public static boolean lI(class_310 var0, int var1, class_1297 var2, Object var3) {
      return var2 == null ? false : Il(var0, var1, var2.method_33571(), var3);
   }

   public static boolean ll() {
      return Illll || lII;
   }

   public static boolean III(class_310 var0, class_3965 var1) {
      return lIll(var0, var1, false);
   }

   private static boolean IIl(class_310 var0, class_1297 var1, float var2, float var3, class_243 var4) {
      if (lll(var0) && var1 != null && var4 != null) {
         class_243 var5 = var0.field_1724.method_33571();
         double var6 = Math.max(var5.method_1022(var4) + (double)0.25F, (double)0.25F);
         class_243 var8 = var5.method_1019(lIII(var2, var3).method_1021(var6));
         return var1.method_5829().method_1014(0.1).method_992(var5, var8).isPresent();
      } else {
         return false;
      }
   }

   public static boolean IlI(class_310 var0) {
      if (lll(var0) && IIlII) {
         if (var0.field_1724.field_6012 > IlIlI) {
            IIlII = false;
            IlIll = true;
            IIllI = var0.field_1724.field_6012;
            return false;
         } else {
            return true;
         }
      } else {
         return false;
      }
   }

   private static void Ill(class_310 var0, float var1, float var2) {
      if (lll(var0)) {
         boolean var3 = IIlII && var0.field_1724.field_6012 <= IlIlI;
         lIIII = var3 ? IlI : var0.field_1724.field_6283;
         IIIlI = var3 ? lIIIl : var0.field_1724.method_36455();
         IlI = var1;
         lIIIl = class_3532.method_15363(var2, -90.0F, 90.0F);
         lIll = var0.field_1724.field_6012;
         IlIlI = var0.field_1724.field_6012 + 3;
         IIlII = true;
         IlIll = false;
         IIllI = IIlIIl(-220499617, 756632267);
      }
   }

   private static float lII(class_310 var0) {
      if (var0 != null && var0.field_1690 != null) {
         double var1 = (Double)var0.field_1690.method_42495().method_41753();
         double var3 = var1 * 0.6 + 0.2;
         double var5 = var3 * var3 * var3 * (double)8.0F * 0.15;
         return Float.isFinite((float)var5) ? (float)var5 : 0.0F;
      } else {
         return 0.0F;
      }
   }

   public static boolean lIl(class_310 var0, int var1, float var2, float var3, Object var4) {
      return IIIlII(var0, var1, var2, var3, var4, false, true, true, false);
   }

   public static boolean llI(class_310 var0, int var1, float var2, float var3) {
      if (lll(var0)) {
         var2 = lIIlI(var2, var0.field_1724.method_36454());
      }

      return IIIlII(var0, var1, var2, var3, llI, false, false, false, false);
   }

   private static boolean lll(class_310 var0) {
      boolean var1 = var0 != null && var0.field_1724 != null && var0.field_1687 != null && var0.method_1562() != null && var0.field_1724.method_5805();
      if (!var1) {
         IlIIl();
         return false;
      } else {
         int var2 = var0.field_1724.method_5628();
         int var3 = System.identityHashCode(var0.field_1724);
         if (lIlI == 0) {
            III = var2;
            lIlI = var3;
            return true;
         } else if (var2 == III && var3 == lIlI) {
            return true;
         } else {
            III = var2;
            lIlI = var3;
            IlIIl();
            return false;
         }
      }
   }

   private static void IIII(class_310 var0) {
      if (!II && Float.isFinite(ll) && Float.isFinite(IlllI)) {
         float[] var1 = lIIIl(var0);
         float[] var2 = lIIl(var0, var1[0], var1[1], lIIlI(ll, var1[0]), IlllI);
         ll = var2[0];
         IlllI = var2[1];
         II = true;
      }
   }

   public static void IIIl(class_310 var0) {
      if (lII) {
         if (lll(var0)) {
            IIIll(var0, l, Ill);
         }

         lII = false;
      }

      if (Illll) {
         if (!lll(var0)) {
            IIIIII();
         } else {
            int var1 = var0.field_1724.field_6012;
            if (var1 >= llIl) {
               if (var1 > llIl) {
                  if (IlIIl) {
                     IIIll(var0, lIIll, lllI);
                  }

                  IIIIII();
               } else {
                  class_746 var2 = var0.field_1724;
                  if (IlIIl) {
                     l = lIIll;
                     Ill = lllI;
                  } else {
                     l = var2.method_36454();
                     Ill = var2.method_36455();
                  }

                  IIII(var0);
                  var2.method_36456(ll);
                  var2.method_36457(IlllI);
                  var2.field_3932 = l;
                  var2.field_3931 = l;
                  var2.field_3916 = Ill;
                  var2.field_3914 = Ill;
                  Ill(var0, ll, IlllI);
                  if (IIll && var2 instanceof lllll) {
                     lllll var3 = (lllll)var2;
                     var3.virel$setLastXClient(var2.method_23317());
                     var3.virel$setLastYClient(var2.method_23318());
                     var3.virel$setLastZClient(var2.method_23321());
                     var3.virel$setTicksSinceLastPositionPacketSent(0);
                  }

                  if (!lI || IlIl) {
                     <undefinedtype> var10 = lIIlI;
                     lIIlI = null;
                     if (var10 != null) {
                        llII = true;

                        try {
                           IlllI(var10);
                        } catch (RuntimeException var8) {
                        } finally {
                           llII = false;
                        }
                     }
                  }

                  lII = true;
               }
            }
         }
      }
   }

   public static boolean IIlI(class_310 var0, int var1, class_1297 var2) {
      <undefinedtype> var3 = IIlIl(var0, var2);
      if (var3 == null || !IlIlI(var0) || Illll && var1 < Il) {
         return false;
      } else {
         IIIIl = true;
         IIlIl = var3.ll();
         Ill(var0, var3.III(), var3.l());
         return true;
      }
   }

   public static boolean IIll(class_310 var0) {
      if (IlIIl && lll(var0)) {
         IIIll(var0, lIIll, lllI);
         return true;
      } else {
         return false;
      }
   }

   private static float[] IlII(class_243 var0, class_243 var1) {
      double var2 = var1.field_1352 - var0.field_1352;
      double var4 = var1.field_1351 - var0.field_1351;
      double var6 = var1.field_1350 - var0.field_1350;
      double var8 = Math.sqrt(var2 * var2 + var6 * var6);
      float var10 = (float)(Math.toDegrees(Math.atan2(var6, var2)) - (double)90.0F);
      float var11 = class_3532.method_15363((float)(-Math.toDegrees(Math.atan2(var4, var8))), -90.0F, 90.0F);
      return new float[]{var10, var11};
   }

   public static boolean IlIl(class_310 var0, int var1, int var2) {
      if (!lll(var0)) {
         return false;
      } else {
         class_1297 var3 = var0.field_1687.method_8469(var2);
         return var3 != null && IIlI(var0, var1, var3);
      }
   }

   public static void IllI(class_310 var0, float var1, float var2) {
      IIIll(var0, var1, var2);
   }

   public static boolean Illl() {
      return llII;
   }

   private static class_243 lIII(float var0, float var1) {
      float var2 = -var0 * ((float)Math.PI / 180F);
      float var3 = var1 * ((float)Math.PI / 180F);
      float var4 = class_3532.method_15374((double)var2);
      float var5 = class_3532.method_15362((double)var2);
      float var6 = class_3532.method_15362((double)var3);
      float var7 = class_3532.method_15374((double)var3);
      return new class_243((double)(var4 * var6), (double)(-var7), (double)(var5 * var6));
   }

   private static float[] lIIl(class_310 var0, float var1, float var2, float var3, float var4) {
      float var5 = lII(var0);
      if (Float.isFinite(var5) && !(var5 <= 0.0F)) {
         float var6 = class_3532.method_15393(var3 - var1) + lIII;
         float var7 = class_3532.method_15363(var4, -90.0F, 90.0F) - var2 + IIlI;
         int var8 = (int)(var6 / var5);
         int var9 = (int)(var7 / var5);
         float var10 = (float)var8 * var5;
         float var11 = (float)var9 * var5;
         lIII = var6 - var10;
         IIlI = var7 - var11;
         return new float[]{lIIlI(var1 + var10, var1), class_3532.method_15363(var2 + var11, -90.0F, 90.0F)};
      } else {
         return new float[]{lIIlI(var3, var1), class_3532.method_15363(var4, -90.0F, 90.0F)};
      }
   }

   public static boolean lIlI(class_310 var0, class_10055 var1, float var2) {
      if (var1 != null && lll(var0)) {
         if (var0.field_1690.method_31044().method_31034()) {
            return false;
         } else if (!IlI(var0)) {
            return IllIl(var0, var1, var2);
         } else {
            float var3 = var0.field_1724.field_6012 == lIll ? class_3532.method_15363(var2, 0.0F, 1.0F) : 1.0F;
            var1.field_53446 = class_3532.method_17821(var3, lIIII, IlI);
            var1.field_53447 = 0.0F;
            var1.field_53448 = class_3532.method_16439(var3, IIIlI, lIIIl);
            return true;
         }
      } else {
         return false;
      }
   }

   public static boolean lIll(class_310 var0, class_3965 var1, boolean var2) {
      if (var0 != null && var1 != null) {
         class_239 var4 = var0.field_1765;
         if (var4 instanceof class_3965) {
            class_3965 var3 = (class_3965)var4;
            if (var3.method_17783() == class_240.field_1332 && var1.method_17783() == class_240.field_1332) {
               if (!var3.method_17777().equals(var1.method_17777())) {
                  return false;
               }

               return !var2 || var3.method_17780() == var1.method_17780();
            }

            return false;
         }
      }

      return false;
   }

   public static float llII(class_310 var0) {
      if (lll(var0) && IIIIl) {
         IIIIl = false;
         return IIlIl;
      } else {
         return Float.NaN;
      }
   }

   private static boolean llIl(class_310 var0, int var1) {
      return IlIlI(var0);
   }

   public static float lllI() {
      return lIIIl;
   }

   public static float llll() {
      return IlI;
   }

   public static boolean IIIII() {
      return Illll || lII;
   }

   public static boolean IIIIl(Object var0) {
      if (var0 != null && Illll) {
         class_310 var1 = class_310.method_1551();
         if (var1 != null) {
            IIIll(var1, l, Ill);
         }

         IIIIII();
         return true;
      } else {
         return false;
      }
   }

   public static boolean IIIlI(class_310 var0, class_1297 var1, double var2) {
      if (IlIlI(var0) && IIIl && var1 != null && var1 != var0.field_1724 && var1.method_5805() && !var1.method_31481() && Double.isFinite(var2) && !(var2 <= (double)0.0F)) {
         class_243 var4 = var0.field_1724.method_33571();
         class_238 var5 = var1.method_5829();
         if (var5.method_1006(var4)) {
            return true;
         } else {
            class_243 var6 = var4.method_1019(lIII(IIlll, IllI).method_1021(var2));
            class_243 var7 = (class_243)var5.method_992(var4, var6).orElse((Object)null);
            if (var7 == null) {
               return false;
            } else {
               class_3965 var8 = IllllIlI.IIIlIll(var0, var0.field_1724, var4, var7);
               return var8 == null || var8.method_17783() == class_240.field_1333 || var4.method_1025(var8.method_17784()) + 1.0E-6 >= var4.method_1025(var7);
            }
         }
      } else {
         return false;
      }
   }

   private static void IIIll(class_310 var0, float var1, float var2) {
      if (lll(var0)) {
         class_746 var3 = var0.field_1724;
         float[] var4 = lIlII(var0, var1, var2);
         if (var4 != null) {
            var1 = var4[0];
            var2 = var4[1];
            var3.method_36456(var1);
            var3.method_36457(var2);
            var3.field_3932 = var1;
            var3.field_3931 = var1;
            var3.field_3916 = var2;
            var3.field_3914 = var2;
            IllllIlI.llIlIl(var0, var1);
         }
      }
   }

   public static void IIlII(class_310 var0) {
      if (lII) {
         if (lll(var0)) {
            IIIll(var0, l, Ill);
         }

         lII = false;
         if (lI && !IlIl && lll(var0)) {
            IlIl = true;
            llIl = var0.field_1724.field_6012 + 1;
            II = false;
            IlIIl = false;
         } else {
            IIIIII();
         }
      }
   }

   private static <undefinedtype> IIlIl(class_310 var0, class_1297 var1) {
      if (lll(var0) && var1 != null && var1 != var0.field_1724 && var1.method_5805() && !var1.method_31481()) {
         float var2 = var0.field_1724.method_36454();
         float var3 = class_3532.method_15363(var0.field_1724.method_36455(), -90.0F, 90.0F);
         <undefinedtype> var4 = IIIllI(var0, var1, var2, var3, 0.1);
         if (var4 == null) {
            return null;
         } else {
            boolean var5 = IIl(var0, var1, var4.I(), var4.lI(), var4.l());
            <undefinedtype> var6 = llIll(var0, var4.Il(), var4.II(), var5);
            float var7 = lIIlI(var2 + var6.l(), var2);
            float var8 = class_3532.method_15363(var3 + var6.I(), -90.0F, 90.0F);
            return new Record(var4.l(), var7, var8, class_3532.method_15393(var7 - var2), var8 - var3, var4.Il(), var4.II()) {
               private final float I;
               private final float l;
               private final class_243 II;
               private final float Il;
               private final float lI;
               private final float ll;
               private final float III;

               public float I() {
                  return this.I;
               }

               public float l() {
                  return this.III;
               }

               public float II() {
                  return this.lI;
               }

               public float Il() {
                  return this.Il;
               }

               private {
                  this.II = var1;
                  this.ll = var2;
                  this.III = var3;
                  this.l = var4;
                  this.lI = var5;
                  this.Il = var6;
                  this.I = var7;
               }

               public class_243 lI() {
                  return this.II;
               }

               public float ll() {
                  return this.l;
               }

               public float III() {
                  return this.ll;
               }
            };
         }
      } else {
         return null;
      }
   }

   public static void IIllI(class_2596<?> var0) {
      if (var0 instanceof class_2828 var1) {
         if (var1.method_36172()) {
            class_310 var2 = class_310.method_1551();
            if (!IlIlI(var2)) {
               return;
            }

            float[] var3 = lIIIl(var2);
            float var4 = var3[0];
            float var5 = var3[1];
            IIlll = var1.method_12271(var4);
            IllI = class_3532.method_15363(var1.method_12270(var5), -90.0F, 90.0F);
            IIIl = Float.isFinite(IIlll) && Float.isFinite(IllI);
            return;
         }
      }

   }

   public static boolean IIlll(class_310 var0, int var1, float var2, float var3, Object var4) {
      return lIlIl(var0, var1, var2, var3, var4);
   }

   public static void IlIIl() {
      Illll = false;
      lIIlI = null;
      IIll = false;
      I = false;
      lI = false;
      IlIl = false;
      II = false;
      llII = false;
      IlIIl = false;
      lII = false;
      IIlII = false;
      IlIll = false;
      IIllI = IIlIIl(-220499618, -592181830);
      IlIlI = IIlIIl(-220499619, 1093627364);
      lIll = IIlIIl(-220499620, -39238069);
      lIIII = Float.NaN;
      IIIlI = Float.NaN;
      IllII = IIlIIl(-220499621, 651571079);
      llll = 0;
      IIIIl = false;
      IIIl = false;
      IIlll = 0.0F;
      IllI = 0.0F;
      lIII = 0.0F;
      IIlI = 0.0F;
   }

   private static boolean IlIlI(class_310 var0) {
      if (!lll(var0)) {
         IllII = IIlIIl(-220499622, -985859317);
         llll = 0;
         IIIIII();
         lII = false;
         IIlII = false;
         return false;
      } else {
         int var1 = System.identityHashCode(var0.field_1724);
         if (llll != var1) {
            llll = var1;
            IllII = IIlIIl(-220499623, -457031037);
            IIIIII();
            lII = false;
            IIlII = false;
         }

         return true;
      }
   }

   public static boolean IlIll(class_310 var0, int var1, float var2, float var3, Object var4) {
      return IIIlII(var0, var1, var2, var3, var4, false, true, false, false);
   }

   public static boolean IllII(class_310 var0) {
      if (Illll && I && lll(var0)) {
         int var1 = var0.field_1724.field_6012;
         if (var1 < llIl) {
            return false;
         } else {
            if (IlIIl) {
               IIIll(var0, lIIll, lllI);
            }

            if (var1 > llIl) {
               IIIIII();
               return false;
            } else {
               class_746 var2 = var0.field_1724;
               if (!IlIIl) {
                  lIIll = var2.method_36454();
                  lllI = var2.method_36455();
                  IlIIl = true;
               }

               IIII(var0);
               float[] var3 = lIlII(var0, ll, IlllI);
               if (var3 != null) {
                  ll = var3[0];
                  IlllI = var3[1];
               }

               var2.method_36456(ll);
               var2.method_36457(IlllI);
               var2.field_3932 = lIIll;
               var2.field_3931 = lIIll;
               var2.field_3916 = lllI;
               var2.field_3914 = lllI;
               return true;
            }
         }
      } else {
         return false;
      }
   }

   private static boolean IllIl(class_310 var0, class_10055 var1, float var2) {
      if (IlIll && var0.field_1724.field_6012 <= IIllI) {
         float var3 = class_3532.method_15363(var2, 0.0F, 1.0F);
         float var4 = var1.field_53446;
         float var5 = var1.field_53447;
         float var6 = var1.field_53448;
         var1.field_53446 = class_3532.method_17821(var3, IlI, var4);
         var1.field_53447 = class_3532.method_17821(var3, 0.0F, var5);
         var1.field_53448 = class_3532.method_16439(var3, lIIIl, var6);
         return true;
      } else {
         IlIll = false;
         return false;
      }
   }

   private static boolean IlllI(Object var0) {
      IllllIlI.IIIllll();

      boolean var1;
      try {
         var1 = var0.run();
      } finally {
         IllllIlI.Il();
      }

      return var1;
   }

   public static boolean Illll(class_310 var0, int var1, class_2338 var2, Object var3) {
      return var2 == null ? false : Il(var0, var1, class_243.method_24953(var2), var3);
   }

   public static boolean lIIII(class_310 var0, int var1, float var2, float var3) {
      return IIIlIl(var0, var1, var2, var3, () -> true);
   }

   private static float[] lIIIl(class_310 var0) {
      if (IIIl && Float.isFinite(IIlll) && Float.isFinite(IllI)) {
         return new float[]{IIlll, IllI};
      } else {
         return var0 != null && var0.field_1724 != null ? new float[]{var0.field_1724.method_36454(), class_3532.method_15363(var0.field_1724.method_36455(), -90.0F, 90.0F)} : new float[]{0.0F, 0.0F};
      }
   }

   private static float lIIlI(float var0, float var1) {
      float var2;
      for(var2 = var0; var2 - var1 > 180.0F; var2 -= 360.0F) {
      }

      while(var2 - var1 < -180.0F) {
         var2 += 360.0F;
      }

      return var2;
   }

   public static boolean lIIll(class_310 var0, int var1, float var2, float var3) {
      if (IlIlI(var0) && Float.isFinite(var2) && Float.isFinite(var3) && (!Illll || var1 >= Il)) {
         float var4 = var0.field_1724.method_36454();
         float var5 = lIIlI(var2, var4);
         float var6 = class_3532.method_15363(var3, -90.0F, 90.0F);
         return IIIlII(var0, var1, var5, var6, llI, false, true, false, false);
      } else {
         return false;
      }
   }

   public static float[] lIlII(class_310 var0, float var1, float var2) {
      if (Float.isFinite(var1) && Float.isFinite(var2)) {
         float[] var3 = lIIIl(var0);
         var1 = lIIlI(var1, var3[0]);
         return lIIl(var0, var3[0], var3[1], var1, var2);
      } else {
         return null;
      }
   }

   private static boolean lIlIl(class_310 var0, int var1, float var2, float var3, Object var4) {
      return IIIlII(var0, var1, var2, var3, var4, false, true, false, true);
   }

   public static boolean lIllI(class_310 var0, int var1, float var2, float var3, Object var4) {
      return IIIlII(var0, var1, var2, var3, var4, true, true, false, false);
   }

   public static boolean lIlll(class_310 var0, class_1297 var1, double var2) {
      return IIIlI(var0, var1, var2);
   }

   public static boolean llIII(class_310 var0, class_10055 var1, float var2) {
      if (var1 != null && lll(var0)) {
         lIlI(var0, var1, var2);
         return true;
      } else {
         return false;
      }
   }

   public static float llIIl() {
      return IlIIl ? lIIll : l;
   }

   public static float[] llIlI(class_310 var0, class_243 var1) {
      if (lll(var0) && var1 != null) {
         float[] var2 = IlII(var0.field_1724.method_33571(), var1);
         return llllI(var0, var0.field_1724.method_36454(), var0.field_1724.method_36455(), var2[0], var2[1]);
      } else {
         return null;
      }
   }

   public static <undefinedtype> llIll(class_310 var0, float var1, float var2, boolean var3) {
      if (var0 != null && var0.field_1690 != null && Float.isFinite(var1) && Float.isFinite(var2)) {
         float var4 = (float)(Double)var0.field_1690.method_42495().method_41753() * 0.6F + 0.2F;
         float var5 = var4 * var4 * var4 * 1.2F;
         if (Float.isFinite(var5) && !(var5 <= 0.0F)) {
            float var6 = IIIIIl(var1, var5, var3);
            float var7 = IIIIIl(var2, var5, var3);
            return new Record(var6, var7) {
               private final float I;
               private final float l;

               public {
                  this.l = var1;
                  this.I = var2;
               }

               public float I() {
                  return this.I;
               }

               public float l() {
                  return this.l;
               }
            };
         } else {
            return new Record(var1, var2) {
               private final float I;
               private final float l;

               public {
                  this.l = var1;
                  this.I = var2;
               }

               public float I() {
                  return this.I;
               }

               public float l() {
                  return this.l;
               }
            };
         }
      } else {
         return new Record(var1, var2) {
            private final float I;
            private final float l;

            public {
               this.l = var1;
               this.I = var2;
            }

            public float I() {
               return this.I;
            }

            public float l() {
               return this.l;
            }
         };
      }
   }

   public static float[] lllII(class_310 var0) {
      if (!lll(var0)) {
         return null;
      } else {
         float[] var1 = lIIIl(var0);
         return new float[]{var1[0], var1[1]};
      }
   }

   public static int lllIl() {
      return Illll ? Il : IIlIIl(-220499624, -872452307);
   }

   private static float[] llllI(class_310 var0, float var1, float var2, float var3, float var4) {
      float var5 = lII(var0);
      if (Float.isFinite(var5) && !(var5 <= 0.0F)) {
         float var6 = class_3532.method_15393(var3 - var1);
         float var7 = class_3532.method_15363(var4, -90.0F, 90.0F) - var2;
         float var8 = var1 + (float)Math.round(var6 / var5) * var5;
         float var9 = var2 + (float)Math.round(var7 / var5) * var5;
         return new float[]{lIIlI(var8, var1), class_3532.method_15363(var9, -90.0F, 90.0F)};
      } else {
         return new float[]{var3, class_3532.method_15363(var4, -90.0F, 90.0F)};
      }
   }

   private static boolean lllll() {
      return !ll() && !IllllIlI.IlllIl();
   }

   private static void IIIIII() {
      Illll = false;
      lIIlI = null;
      IIll = false;
      I = false;
      lI = false;
      IlIl = false;
      II = false;
      llII = false;
      IIIIl = false;
      IlIIl = false;
   }

   private IlIlIl() {
   }

   private static float IIIIIl(float var0, float var1, boolean var2) {
      return var2 && Math.abs(var0) > 0.0F && Math.abs(var0) < var1 ? 0.0F : (float)Math.round(var0 / var1) * var1;
   }

   static {
      int var2 = -1587178246;
      byte[] var0 = "þ§¯n\u000f\nà\u001e\u0092\u0091\u0088C.\u0017£íõhÊ&\u0016\u0082\u001e«7|§ \u0018A\u008a\u008f\u0084\u001còr\u0084©\u0003\u0081õÕ½,\u000fê3$\u007fS6m".getBytes("ISO-8859-1");
      int var1 = var0.length / 4;
      lIlII = new int[var1];
      int var3 = 0;
      int var4 = 0;

      do {
         int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
         var5 ^= var2;
         lIlII[var4] = var5;
         var3 += 4;
         ++var4;
      } while(var4 < var1);

      IllII = IIlIIl(-220499625, 1470240735);
      llIl = IIlIIl(-220499626, 1461184045);
      IIllI = IIlIIl(-220499627, 644569219);
      lIll = IIlIIl(-220499628, -598419830);
      IlIlI = IIlIIl(-220499629, -1393699900);
      III = -1;
      lIlI = 0;
      llI = () -> true;
   }

   public static boolean IIIIlI(class_310 var0, int var1, float var2, float var3, Object var4) {
      return !lllll() ? false : IIIlII(var0, var1, var2, var3, var4, false, true, true, false);
   }

   public static boolean IIIIll() {
      return Illll;
   }

   private static boolean IIIlII(class_310 var0, int var1, float var2, float var3, Object var4, boolean var5, boolean var6, boolean var7, boolean var8) {
      if (lll(var0) && var4 != null && Float.isFinite(var2) && Float.isFinite(var3)) {
         if (!IlIIl && !lII) {
            if (!Illll || !lI || !IlIl && var1 > Il) {
               if (!llIl(var0, var1)) {
                  return false;
               } else {
                  int var9 = var0.field_1724.field_6012 + 1;
                  if (Illll && llIl == var9 && var1 <= Il) {
                     return false;
                  } else {
                     float[] var10 = lIIIl(var0);
                     Illll = true;
                     llIl = var9;
                     Il = var1;
                     ll = lIIlI(var2, var10[0]);
                     IlllI = class_3532.method_15363(var3, -90.0F, 90.0F);
                     lIIlI = var4;
                     IIll = var5;
                     I = var6;
                     lI = var8;
                     IlIl = var8 && IIIl && Math.abs(class_3532.method_15393(ll - var10[0])) <= 0.001F && Math.abs(IlllI - var10[1]) <= 0.001F;
                     II = false;
                     IlIIl = false;
                     return true;
                  }
               }
            } else {
               return false;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public static boolean IIIlIl(class_310 var0, int var1, float var2, float var3, Object var4) {
      return IIIlII(var0, var1, var2, var3, var4, false, true, false, false);
   }

   public static <undefinedtype> IIIllI(class_310 var0, class_1297 var1, float var2, float var3, double var4) {
      if (lll(var0) && var1 != null && Float.isFinite(var2) && Float.isFinite(var3)) {
         class_243 var6 = var0.field_1724.method_33571();
         class_238 var7 = var1.method_5829().method_1014(var4);
         double[] var8 = new double[]{var7.field_1323, var7.field_1320};
         double[] var9 = new double[]{var7.field_1322, var7.field_1325};
         double[] var10 = new double[]{var7.field_1321, var7.field_1324};
         class_243 var11 = null;
         float var12 = 0.0F;
         float var13 = 0.0F;
         float var14 = 0.0F;
         float var15 = 0.0F;
         double var16 = Double.POSITIVE_INFINITY;
         double var18 = Double.POSITIVE_INFINITY;

         for(double var23 : var8) {
            for(double var28 : var9) {
               for(double var33 : var10) {
                  class_243 var35 = new class_243(var23, var28, var33);
                  float[] var36 = IlII(var6, var35);
                  float var37 = class_3532.method_15393(var36[0] - var2);
                  float var38 = class_3532.method_15363(var36[1], -90.0F, 90.0F) - class_3532.method_15363(var3, -90.0F, 90.0F);
                  double var39 = (double)(Math.abs(var37) + Math.abs(var38));
                  double var41 = var35.method_1025(var6);
                  if (var39 < var16 || Math.abs(var39 - var16) <= 1.0E-6 && var41 < var18) {
                     var16 = var39;
                     var18 = var41;
                     var11 = var35;
                     var12 = var36[0];
                     var13 = class_3532.method_15363(var36[1], -90.0F, 90.0F);
                     var14 = var37;
                     var15 = var38;
                  }
               }
            }
         }

         return var11 == null ? null : new Record(var11, var12, var13, var14, var15) {
            private final float I;
            private final class_243 l;
            private final float II;
            private final float Il;
            private final float lI;

            public float I() {
               return this.Il;
            }

            public class_243 l() {
               return this.l;
            }

            public float II() {
               return this.lI;
            }

            public float Il() {
               return this.I;
            }

            public {
               this.l = var1;
               this.Il = var2;
               this.II = var3;
               this.I = var4;
               this.lI = var5;
            }

            public float lI() {
               return this.II;
            }
         };
      } else {
         return null;
      }
   }

   public static boolean IIIlll(class_310 var0, int var1, float var2, float var3, Object var4) {
      return IIIlII(var0, var1, var2, var3, var4, false, true, false, false);
   }

   public static boolean IIlIII(class_310 var0, int var1, class_243 var2, Object var3) {
      if (lll(var0) && var2 != null) {
         if (!lllll()) {
            return false;
         } else {
            float[] var4 = IlII(var0.field_1724.method_33571(), var2);
            return lIlIl(var0, var1, var4[0], var4[1], var3);
         }
      } else {
         return false;
      }
   }

   private static int IIlIIl(int var0, int var1) {
      return lIlII[var0 ^ -220499617] ^ var1 ^ var0;
   }
}
