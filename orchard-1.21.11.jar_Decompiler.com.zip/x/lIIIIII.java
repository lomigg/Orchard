package x;

import java.awt.Color;
import java.util.Locale;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

@Environment(EnvType.CLIENT)
public final class lIIIIII extends IIIIIIIlI implements llIlIIII {
   private static final double I = (double)14.0F;
   private static final double l = (double)240.0F;
   private static final double II = (double)68.0F;
   private static final double Il = (double)5.0F;
   private static final double lI = (double)158.0F;
   private static final <undefinedtype> ll;
   private final IIIllIIII III;
   private final IIIllIIII IIl;
   private static String[] IlI;
   private final lIll Ill = new lIll();
   private static final double lII = (double)40.0F;
   private static final double lIl = (double)14.0F;
   private static final double llI = (double)76.0F;
   private final IIIllIIII lll;
   private static final <undefinedtype> IIII;
   private static final int[] IIIl;
   private static final String[] IIlI;
   private static final Object[] IIll;

   public boolean IIlI(double var1, double var3) {
      return var1 >= this.Il() && var1 <= this.Il() + this.llll() && var3 >= this.Ill() && var3 <= this.Ill() + this.lIIl();
   }

   public double Il() {
      return (Double)this.IIl.III();
   }

   private void ll(class_332 var1, class_2960 var2, boolean var3) {
      if (!var3 && var2 != null) {
         IIIIIIllI.llIIlI(var1, var2, (double)14.0F, (double)10.0F, (double)40.0F, (double)40.0F);
      } else {
         IIIIIIllI.lIl(var1, class_310.method_1551().field_1772, String.valueOf((char)IlIl(-1952703092, 2086514738)), (double)14.0F, (double)10.0F, (double)40.0F, (double)40.0F, lllIIlI.Illl(IlIl(-1952703091, 263945156)));
      }
   }

   private static String IlI(String var0, String var1) {
      return var0 != null && !var0.isBlank() ? var0 : var1;
   }

   public void IIl(class_332 var1, int var2, int var3, float var4) {
      this.lll(var1, false, false);
   }

   public void lI() {
      this.Ill.IIl(class_310.method_1551());
   }

   private void lII(class_332 var1, class_310 var2, Object var3, long var4, boolean var6, boolean var7) {
      class_327 var8 = var2.field_1772;
      Color var9 = lllIIlI.III();
      Color var10 = lllIIlI.lIIl();
      int var11 = lllIIlI.Illl(IlIl(-1952703090, 1141396152));
      lllIIlI.lI(var1, IIII, (double)0.0F, (double)0.0F, (double)240.0F, (double)76.0F, var7);
      if (!var6) {
         IIIIIIllI.IllIll(var1, (double)13.0F, (double)9.0F, (double)42.0F, (double)42.0F, (double)6.0F, IIIlllIII.lI(0, IlIl(-1952703089, -1156048055)));
      }

      this.ll(var1, var3.ll(), var6);
      IIIIIIllI.llIl(var1, var8, IIIIIIllI.lIlIlI(var8, IlI(var3.lI(), lIlIII.Il(IlI[0])), (double)158.0F), (double)68.0F, (double)18.0F, var11);
      IIIIIIllI.llIl(var1, var8, IIIIIIllI.lIlIlI(var8, IlI(var3.IIlI(), lIlIII.Il(IlI[1])), (double)158.0F), (double)68.0F, (double)31.0F, var11);
      long var12 = var6 ? ll.IIl() : var3.Ill(var4);
      IIIIIIllI.llIl(var1, var8, IlII(var12), (double)14.0F, (double)52.0F, var11);
      IIIIIIllI.lI(var1, var8, IlII(var3.III()), (double)226.0F, (double)52.0F, var11);
      double var14 = (double)212.0F;
      double var16 = var6 ? ll.Il(ll.II()) : var3.Il(var4);
      IIIIIIllI.IllIll(var1, (double)14.0F, (double)65.0F, var14, (double)4.0F, (double)2.0F, IIIlllIII.lI(0, IlIl(-1952703096, 501376895)));
      if (var16 > (double)0.0F) {
         IIIIIIllI.ll(var1, (double)14.0F, (double)65.0F, var14 * var16, (double)4.0F, (double)2.0F, var10.getRGB(), var9.getRGB());
      }

   }

   public lIIIIII(lIIIllll var1) {
      super((Object)lIlIII.l(IlI[1]), lIllII.IIl, (Object)lIlIII.l(IlI[IlIl(-1952703095, 1976645268)]));
      this.IIl = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IlI[IlIl(-1952703094, -958313290)]), (double)18.0F, (double)0.0F, (double)4000.0F, (double)1.0F)).IIl(lIlIII.Il(IlI[IlIl(-1952703093, -828207297)])));
      this.lll = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IlI[IlIl(-1952703100, -435164186)]), (double)132.0F, (double)0.0F, (double)4000.0F, (double)1.0F)).IIl(lIlIII.Il(IlI[IlIl(-1952703099, -1458201245)])));
      this.III = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IlI[IlIl(-1952703098, 592670118)]), (double)100.0F, (double)60.0F, (double)200.0F, (double)5.0F)).IIl(lIlIII.Il(IlI[IlIl(-1952703097, 1696211139)])));
   }

   public boolean IIIIIII() {
      return IIIIIII.I();
   }

   private double llI() {
      return (Double)this.III.III() / (double)100.0F;
   }

   private void lll(class_332 var1, boolean var2, boolean var3) {
      class_310 var4 = class_310.method_1551();
      if (var1 != null && var4 != null && var4.field_1772 != null) {
         <undefinedtype> var5 = var2 ? ll : this.Ill.lI();
         if (var5.IIII()) {
            long var6 = var2 ? ll.II() : System.currentTimeMillis();
            double var8 = this.llI();
            IIIIIIllI.IIIllI(var1);
            IIIIIIllI.IlII(var1, this.Il(), this.Ill());
            IIIIIIllI.lllI(var1, var8, var8);

            try {
               this.lII(var1, var4, var5, var6, var2, var3);
            } finally {
               IIIIIIllI.lIIlIl(var1);
            }

         }
      }
   }

   public double Ill() {
      return (Double)this.lll.III();
   }

   public double lIIl() {
      return (double)76.0F * this.llI();
   }

   private static String IIII(char[] var0, long var1, int var3) {
      int var4 = IlIl(-1952703104, 913744392) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IlIl(-1952703103, 1104754975);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   public double llll() {
      return (double)240.0F * this.llI();
   }

   public void lIl() {
      this.Ill.lIll(class_310.method_1551());
   }

   public void III(class_332 var1, int var2, int var3, float var4, boolean var5) {
      this.lll(var1, true, var5);
   }

   private static void IIll() {
      IlI[0] = IIII(Illl(58589, '\uf2d0', 753095734).toCharArray(), 72567L, IlIl(-1952703102, 1894904657));
      IlI[1] = IIII(Illl(63006, '\uf2d1', 1807763343).toCharArray(), 5171L, IlIl(-1952703101, -240045404));
      IlI[2] = IIII(Illl(53311, '\uf2d2', 1864842805).toCharArray(), 82403L, IlIl(-1952703076, 75335039));
      IlI[3] = IIII(Illl(91, '\uf2d3', -1036158470).toCharArray(), 37816L, IlIl(-1952703075, 479351511));
      IlI[4] = IIII(Illl(24910, '\uf2d4', 1718296918).toCharArray(), 93926L, IlIl(-1952703074, -2003449947));
      IlI[5] = IIII(Illl(26345, '\uf2d5', 1518341013).toCharArray(), 11320L, IlIl(-1952703073, 2001715121));
      IlI[IlIl(-1952703080, 1877070462)] = IIII(Illl(45333, '\uf2d6', -463776144).toCharArray(), 72311L, IlIl(-1952703079, -663275080));
      IlI[IlIl(-1952703078, -852534693)] = IIII(Illl(57510, '\uf2d7', 518271808).toCharArray(), 19802L, IlIl(-1952703077, 709484021));
      IlI[IlIl(-1952703084, -325442169)] = IIII(Illl(55412, '\uf2d8', -1128046742).toCharArray(), 72928L, IlIl(-1952703083, -350650018));
      IlI[IlIl(-1952703082, 788284560)] = IIII(Illl(20021, '\uf2d9', 1308183195).toCharArray(), 12631L, IlIl(-1952703081, 1241815987));
      IlI[IlIl(-1952703088, 826937400)] = IIII(Illl(18167, '\uf2da', 913972503).toCharArray(), 67770L, IlIl(-1952703087, 1914382493));
      IlI[IlIl(-1952703086, 547521871)] = IIII(Illl(35243, '\uf2db', -761836032).toCharArray(), 49700L, IlIl(-1952703085, -1704429682));
      IlI[IlIl(-1952703060, 689752820)] = IIII(Illl(64343, '\uf2dc', -1008842209).toCharArray(), 62129L, IlIl(-1952703059, 1541320737));
   }

   public void lIlI(double var1, double var3) {
      class_310 var5 = class_310.method_1551();
      double var6 = Double.MAX_VALUE;
      double var8 = Double.MAX_VALUE;
      if (var5 != null && var5.method_22683() != null) {
         var6 = Math.max((double)0.0F, (double)var5.method_22683().method_4486() - this.llll());
         var8 = Math.max((double)0.0F, (double)var5.method_22683().method_4502() - this.lIIl());
      }

      this.IIl.III(Math.max((double)0.0F, Math.min(var1, var6)));
      this.lll.III(Math.max((double)0.0F, Math.min(var3, var8)));
   }

   static {
      // $FF: Couldn't be decompiled
   }

   public void IIIlI(class_332 var1, int var2, int var3, float var4) {
      this.lll(var1, false, false);
   }

   static String IlII(long var0) {
      long var2 = Math.max(0L, var0) / 1000L;
      return String.format(Locale.ROOT, lIlIII.Il(IlI[2]), var2 / 60L, var2 % 60L);
   }

   public void Ill() {
      this.Ill.lIll(class_310.method_1551());
   }

   private static int IlIl(int var0, int var1) {
      return IIIl[var0 ^ -1952703092] ^ var1 ^ var0;
   }

   private static String Illl(int var0, char var1, int var2) {
      int var3 = var1 ^ '\uf2d0';
      char[] var4 = IIlI[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])IIll[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         IIll[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 31619;
      int var9 = 0;

      do {
         int var10 = var4[var9] - '\uf16c';
         var10 -= 56844;
         var10 ^= 58705;
         var10 -= 4192;
         var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var2 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
