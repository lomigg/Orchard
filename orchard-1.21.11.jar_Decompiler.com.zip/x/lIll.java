package x;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpClient.Redirect;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.charset.StandardCharsets;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1060;
import net.minecraft.class_2960;
import net.minecraft.class_310;

@Environment(EnvType.CLIENT)
final class lIll {
   private volatile String I;
   private volatile Process l;
   private volatile <undefinedtype> II = null.lll();
   private volatile CompletableFuture<?> Il;
   private static final ExecutorService lI;
   private boolean ll;
   private static final int III = 2097152;
   private volatile boolean IIl;
   private static final long IlI = 2000L;
   private static String[] Ill;
   private static final class_2960 lII;
   private volatile boolean lIl;
   private volatile boolean llI = true;
   private static final HttpClient lll;
   private static final int IIII = 32;
   private final Map<String, IIlIlIlIl> IIIl = new LinkedHashMap<String, IIlIlIlIl>(IIIlI(492781445, 1517074501), 0.75F, true) {
      private static final int[] l;

      protected boolean removeEldestEntry(Map.Entry<String, IIlIlIlIl> var1) {
         return this.size() > I(1545033227, -1344097075);
      }

      private static int I(int var0, int var1) {
         return l[var0 ^ 1545033227] ^ var1 ^ var0;
      }

      static {
         int var2 = -304467189;
         byte[] var0 = "\u001e/Ñí".getBytes("ISO-8859-1");
         int var1 = var0.length / 4;
         l = new int[var1];
         int var3 = 0;
         int var4 = 0;

         do {
            int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
            var5 ^= var2;
            l[var4] = var5;
            var3 += 4;
            ++var4;
         } while(var4 < var1);

      }
   };
   private static final int[] IIlI;
   private static final String[] IIll;
   private static final Object[] IlII;

   private static CompletableFuture<IIlIlIlIl> I(URI var0, boolean var1) {
      HttpRequest var2 = HttpRequest.newBuilder(var0).timeout(Duration.ofSeconds(8L)).header(lIlIII.Il(Ill[IIIlI(492781512, 1197461727)]), lIlIII.Il(Ill[IIIlI(492781513, 1053313243)])).GET().build();
      return lll.sendAsync(var2, BodyHandlers.ofString(StandardCharsets.UTF_8)).thenApply((var1x) -> {
         if (var1x.statusCode() >= IIIlI(492781473, 836872833) && var1x.statusCode() < IIIlI(492781474, 1257819367) && var1x.body() != null && ((String)var1x.body()).length() <= IIIlI(492781475, 2028713364)) {
            try {
               JsonElement var2 = JsonParser.parseString((String)var1x.body());
               JsonObject var3;
               if (var1) {
                  JsonArray var4 = var2.getAsJsonArray();
                  if (var4.isEmpty()) {
                     return IIlIlIlIl.Il;
                  }

                  var3 = var4.get(0).getAsJsonObject();
               } else {
                  var3 = var2.getAsJsonObject();
               }

               return IIlIlIlIl.IlI(IIIII(var3, lIlIII.Il(Ill[IIIlI(492781476, -397167252)])), IIIII(var3, lIlIII.Il(Ill[IIIlI(492781477, -2124109017)])));
            } catch (RuntimeException var5) {
               return IIlIlIlIl.Il;
            }
         } else {
            return IIlIlIlIl.Il;
         }
      }).exceptionally((var0x) -> IIlIlIlIl.Il);
   }

   private static CompletableFuture<IIlIlIlIl> l(Object var0) {
      String var10000 = lIlIII.Il(Ill[IIIlI(492781514, -1220454435)]);
      String var10001 = llII(var0.lI());
      String var10002 = lIlIII.Il(Ill[IIIlI(492781515, 1484927606)]);
      String var10003 = llII(var0.IIlI());
      String var10004 = lIlIII.Il(Ill[IIIlI(492781516, 1391005685)]);
      String var10005 = llII(var0.IIIl());
      String var10006 = lIlIII.Il(Ill[IIIlI(492781517, -1884553664)]);
      long var10 = Math.max(0L, Math.round((double)var0.III() / (double)1000.0F));
      String var9 = var10006;
      String var8 = var10005;
      String var7 = var10004;
      String var6 = var10003;
      String var5 = var10002;
      String var4 = var10001;
      String var3 = var10000;
      String var1 = var3 + var4 + var5 + var6 + var7 + var8 + var9 + var10;
      var4 = lIlIII.Il(Ill[IIIlI(492781518, 839746283)]);
      URI var2 = URI.create(var4 + var1);
      return I(var2, false).thenCompose((var1x) -> {
         if (!var1x.ll()) {
            return CompletableFuture.completedFuture(var1x);
         } else {
            String var10000 = lIlIII.Il(Ill[IIIlI(492781447, -1202132299)]);
            String var10001 = llII(var0.lI());
            String var10002 = lIlIII.Il(Ill[IIIlI(492781464, 1908996869)]);
            String var6 = llII(var0.IIlI());
            String var5 = var10002;
            String var4 = var10001;
            String var3 = var10000;
            URI var2 = URI.create(var3 + var4 + var5 + var6);
            return I(var2, true);
         }
      });
   }

   private static void II() {
      Ill[0] = lIlI(IIIll(-1500959799, -313505266).toCharArray(), 42194L, IIIlI(492781519, 1651448998));
      Ill[1] = lIlI(IIIll(-1500959800, 1214476758).toCharArray(), 86283L, IIIlI(492781504, 1384764671));
      Ill[2] = lIlI(IIIll(-1500959797, 1008282776).toCharArray(), 96494L, IIIlI(492781505, 601394410));
      Ill[3] = lIlI(IIIll(-1500959798, 1151357712).toCharArray(), 5020L, IIIlI(492781506, -1049262372));
      Ill[4] = lIlI(IIIll(-1500959795, 251284043).toCharArray(), 32360L, IIIlI(492781507, 874961213));
      Ill[5] = lIlI(IIIll(-1500959796, 1341355436).toCharArray(), 66387L, IIIlI(492781508, 1361101012));
      Ill[IIIlI(492781509, -803863331)] = lIlI(IIIll(-1500959793, -1361822828).toCharArray(), 47885L, IIIlI(492781510, 2723350));
      Ill[IIIlI(492781511, 1984859596)] = lIlI(IIIll(-1500959794, 661791751).toCharArray(), 62833L, IIIlI(492781528, 874718329));
      Ill[IIIlI(492781529, -1507809282)] = lIlI(IIIll(-1500959807, -699772480).toCharArray(), 31679L, IIIlI(492781530, 1884212716));
      Ill[IIIlI(492781531, 310326128)] = lIlI(IIIll(-1500959808, 1082148651).toCharArray(), 87196L, IIIlI(492781532, -281534029));
      Ill[IIIlI(492781533, -721472381)] = lIlI(IIIll(-1500959805, -945457398).toCharArray(), 5570L, IIIlI(492781534, 1351896963));
      Ill[IIIlI(492781535, 556533790)] = lIlI(IIIll(-1500959806, 1769816745).toCharArray(), 98445L, IIIlI(492781520, 1445063689));
      Ill[IIIlI(492781521, 523186858)] = lIlI(IIIll(-1500959803, -903670186).toCharArray(), 98876L, IIIlI(492781522, 1038221394));
      Ill[IIIlI(492781523, 853039466)] = lIlI(IIIll(-1500959804, -1804380538).toCharArray(), 35843L, IIIlI(492781524, 1095499266));
      Ill[IIIlI(492781525, -987123262)] = lIlI(IIIll(-1500959801, 1963736431).toCharArray(), 20688L, IIIlI(492781526, -1801583459));
      Ill[IIIlI(492781527, -966561668)] = lIlI(IIIll(-1500959802, -130190052).toCharArray(), 98415L, IIIlI(492781544, 1301334311));
      Ill[IIIlI(492781545, -918620159)] = lIlI(IIIll(-1500959783, -1386463633).toCharArray(), 58574L, IIIlI(492781546, 689238244));
      Ill[IIIlI(492781547, 1892750415)] = lIlI(IIIll(-1500959784, 17049790).toCharArray(), 8211L, IIIlI(492781548, -775636804));
      Ill[IIIlI(492781549, -1374200233)] = lIlI(IIIll(-1500959781, -2100219232).toCharArray(), 89819L, IIIlI(492781550, 769552860));
      Ill[IIIlI(492781551, 1458101131)] = lIlI(IIIll(-1500959782, -86888084).toCharArray(), 85545L, IIIlI(492781536, 460531980));
      Ill[IIIlI(492781537, 1672389667)] = lIlI("".toCharArray(), 80320L, IIIlI(492781538, -1349351866));
      Ill[IIIlI(492781539, -746108809)] = lIlI(IIIll(-1500959779, 1561225243).toCharArray(), 51160L, IIIlI(492781540, 1895615933));
      Ill[IIIlI(492781541, -966353417)] = lIlI(IIIll(-1500959780, 658209661).toCharArray(), 92243L, IIIlI(492781542, -447916797));
      Ill[IIIlI(492781543, -2102533028)] = lIlI(IIIll(-1500959777, -678081481).toCharArray(), 59255L, IIIlI(492781560, -2039691097));
      Ill[IIIlI(492781561, -1506702466)] = lIlI(IIIll(-1500959778, 724522284).toCharArray(), 64386L, IIIlI(492781562, 961624760));
      Ill[IIIlI(492781563, 812559961)] = lIlI(IIIll(-1500959791, -918066636).toCharArray(), 21567L, IIIlI(492781564, 1307089294));
      Ill[IIIlI(492781565, 1152510092)] = lIlI(IIIll(-1500959792, 1169310598).toCharArray(), 92492L, IIIlI(492781566, -1427061260));
      Ill[IIIlI(492781567, -1521433405)] = lIlI(IIIll(-1500959789, -90872708).toCharArray(), 69282L, IIIlI(492781552, -725514748));
      Ill[IIIlI(492781553, 433730469)] = lIlI(IIIll(-1500959790, -925547273).toCharArray(), 32822L, IIIlI(492781554, -593373335));
      Ill[IIIlI(492781555, -901673783)] = lIlI(IIIll(-1500959787, -2068643269).toCharArray(), 20781L, IIIlI(492781556, 2054411597));
      Ill[IIIlI(492781557, 293002547)] = lIlI(IIIll(-1500959788, 1678343562).toCharArray(), 97011L, IIIlI(492781558, -653465926));
      Ill[IIIlI(492781559, -314042688)] = lIlI(IIIll(-1500959785, 588651987).toCharArray(), 4799L, IIIlI(492781448, 593521452));
      Ill[IIIlI(492781449, -183835702)] = lIlI(IIIll(-1500959786, 1108175784).toCharArray(), 22509L, IIIlI(492781450, -395572100));
      Ill[IIIlI(492781451, -881032797)] = lIlI(IIIll(-1500959767, 1094523116).toCharArray(), 75357L, IIIlI(492781452, 1950808752));
      Ill[IIIlI(492781453, 1735937632)] = lIlI(IIIll(-1500959768, -1690338336).toCharArray(), 23927L, IIIlI(492781454, -664711765));
   }

   private Path Il() throws IOException {
      Path var1 = Path.of(System.getProperty(lIlIII.Il(Ill[IIIlI(492781455, -183696395)]), lIlIII.Il(Ill[IIIlI(492781440, -314253942)])), lIlIII.Il(Ill[IIIlI(492781441, -1358344872)]));
      Files.createDirectories(var1);
      Path var2 = var1.resolve(lIlIII.Il(Ill[IIIlI(492781442, -1241486000)]));
      InputStream var3 = lIll.class.getResourceAsStream(lIlIII.Il(Ill[IIIlI(492781443, -389221203)]));

      try {
         if (var3 == null) {
            throw new IOException(lIlIII.Il(Ill[IIIlI(492781444, 1435343161)]));
         }

         Files.copy(var3, var2, new CopyOption[]{StandardCopyOption.REPLACE_EXISTING});
      } catch (Throwable var7) {
         if (var3 != null) {
            try {
               var3.close();
            } catch (Throwable var6) {
               var7.addSuppressed(var6);
            }
         }

         throw var7;
      }

      if (var3 != null) {
         var3.close();
      }

      return var2;
   }

   lIll() {
      this.I = Ill[IIIlI(492781446, -878173501)];
   }

   <undefinedtype> lI() {
      return this.II;
   }

   void IIl(class_310 var1) {
      this.IIl = false;
      Process var2 = this.l;
      if (var2 != null) {
         var2.destroy();
      }

      this.II = null.lll();
      this.I = Ill[IIIlI(492781465, 88266709)];
      CompletableFuture var3 = this.Il;
      if (var3 != null) {
         var3.cancel(true);
      }

      if (var1 != null && this.ll) {
         var1.execute(() -> {
            if (this.ll && var1.method_1531() != null) {
               var1.method_1531().method_4615(lII);
               this.ll = false;
            }

         });
      }

   }

   private void IlI(String var1, IIlIlIlIl var2) {
      this.IIIl.put(var1, var2 == null ? IIlIlIlIl.Il : var2);
   }

   private static void Ill(class_1011 var0) {
      int var1 = var0.method_4307();
      int var2 = var0.method_4323();
      double var3 = Math.max((double)2.0F, (double)Math.min(var1, var2) * 0.105);

      for(int var5 = 0; var5 < var2; ++var5) {
         for(int var6 = 0; var6 < var1; ++var6) {
            double var7 = Math.min((double)var6 + (double)0.5F, (double)(var1 - var6) - (double)0.5F);
            double var9 = Math.min((double)var5 + (double)0.5F, (double)(var2 - var5) - (double)0.5F);
            if (!(var7 >= var3) && !(var9 >= var3)) {
               double var11 = var3 - var7;
               double var13 = var3 - var9;
               if (var11 * var11 + var13 * var13 > var3 * var3) {
                  var0.method_61941(var6, var5, var0.method_61940(var6, var5) & IIIlI(492781466, -2094958960));
               }
            }
         }
      }

   }

   static <undefinedtype> lIl(String var0) {
      if (var0 != null && !var0.isBlank() && var0.length() <= IIIlI(492781467, -2098642956)) {
         try {
            JsonObject var1 = JsonParser.parseString(var0).getAsJsonObject();
            boolean var2 = lIIl(var1, lIlIII.Il(Ill[IIIlI(492781468, 94423708)]));
            if (!var2) {
               return null.l();
            } else {
               String var3 = IIIII(var1, lIlIII.Il(Ill[IIIlI(492781469, -309320145)]));
               String var4 = IIIII(var1, lIlIII.Il(Ill[IIIlI(492781470, 2054348800)]));
               String var5 = IIIII(var1, lIlIII.Il(Ill[IIIlI(492781471, -1782861852)]));
               if (!var3.isBlank() && !var4.isBlank()) {
                  byte[] var6 = null;
                  String var7 = IIIII(var1, lIlIII.Il(Ill[IIIlI(492781456, -1697876891)]));
                  if (!var7.isBlank() && var7.length() <= IIIlI(492781457, 257057796)) {
                     try {
                        var6 = Base64.getDecoder().decode(var7);
                     } catch (IllegalArgumentException var9) {
                        var6 = null;
                     }
                  }

                  return new Record(true, var3, var4, var5, IIIII(var1, lIlIII.Il(Ill[IIIlI(492781458, -1604502157)])), IIIl(var1, lIlIII.Il(Ill[IIIlI(492781459, 1160730307)])), IIIl(var1, lIlIII.Il(Ill[IIIlI(492781460, -1404534420)])), lIIl(var1, lIlIII.Il(Ill[IIIlI(492781461, 96668507)])), var6) {
                     private final byte[] I;
                     private final String l;
                     private final String II;
                     private final String Il;
                     private final boolean lI;
                     private final long ll;
                     private final boolean III;
                     private static String[] IIl;
                     private final long IlI;
                     private final String Ill;
                     private static final int[] lII;

                     public boolean I() {
                        return this.lI;
                     }

                     static {
                        int var2 = -525139109;
                        byte[] var0 = "Ï:t£b\u000bØÖiq|\u008c".getBytes("ISO-8859-1");
                        int var1 = var0.length / 4;
                        lII = new int[var1];
                        int var3 = 0;
                        int var4 = 0;

                        do {
                           int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
                           var5 ^= var2;
                           lII[var4] = var5;
                           var3 += 4;
                           ++var4;
                        } while(var4 < var1);

                        IIl = new String[1];
                        II();
                     }

                     static <undefinedtype> l() {
                        return new <anonymous constructor>(false, IIl[0], IIl[0], IIl[0], IIl[0], 0L, 0L, false, (byte[])null);
                     }

                     private static void II() {
                        IIl[0] = Ill("".toCharArray(), 33192L, llI(576840331, -1359304030));
                     }

                     public String Il() {
                        return this.Il;
                     }

                     public String lI() {
                        return this.Ill;
                     }

                     {
                        this.lI = var1;
                        this.Il = var2;
                        this.II = var3;
                        this.Ill = var4;
                        this.l = var5;
                        this.IlI = var6;
                        this.ll = var8;
                        this.III = var10;
                        this.I = var11;
                     }

                     public long ll() {
                        return this.IlI;
                     }

                     public long III() {
                        return this.ll;
                     }

                     public String IIl() {
                        return this.II;
                     }

                     public boolean IlI() {
                        return this.III;
                     }

                     private static String Ill(char[] var0, long var1, int var3) {
                        int var4 = llI(576840330, 659636203) ^ var3;

                        for(int var5 = 0; var5 < var0.length; ++var5) {
                           int var7 = var4 ^ (int)var1 ^ ~var5;
                           int var8 = var7 ^ var3 - var5 * var0.length;
                           var4 = -var8 * var3 | var5;
                           var0[var5] = (char)(var0[var5] ^ var4);
                           int var6 = var5 & llI(576840329, -1415340639);
                           var3 = var3 << var6 | var3 >>> -var6;
                           var1 ^= (long)var6;
                        }

                        return new String(var0);
                     }

                     public byte[] lII() {
                        return this.I;
                     }

                     public String lIl() {
                        return this.l;
                     }

                     private static int llI(int var0, int var1) {
                        return lII[var0 ^ 576840331] ^ var1 ^ var0;
                     }
                  };
               } else {
                  return null;
               }
            }
         } catch (RuntimeException var10) {
            return null;
         }
      } else {
         return null;
      }
   }

   private static long IIIl(JsonObject var0, String var1) {
      JsonElement var2 = var0.get(var1);
      if (var2 != null && !var2.isJsonNull()) {
         try {
            return var2.getAsLong();
         } catch (RuntimeException var4) {
            return 0L;
         }
      } else {
         return 0L;
      }
   }

   private boolean IIll(class_310 var1, byte[] var2) {
      if (var1 != null && var1.method_1531() != null && var2.length != 0 && var2.length <= IIIlI(492781462, 563197220)) {
         class_1011 var3;
         try {
            ByteArrayInputStream var4 = new ByteArrayInputStream(var2);

            try {
               var3 = class_1011.method_4309(var4);
            } catch (Throwable var8) {
               try {
                  var4.close();
               } catch (Throwable var7) {
                  var8.addSuppressed(var7);
               }

               throw var8;
            }

            var4.close();
         } catch (IOException var9) {
            return false;
         }

         if (var3 != null && var3.method_4307() >= IIIlI(492781463, -182795417) && var3.method_4323() >= IIIlI(492781480, 691684720) && var3.method_4307() <= IIIlI(492781481, -1606093098) && var3.method_4323() <= IIIlI(492781482, -244216288)) {
            Ill(var3);
            if (this.ll) {
               var1.method_1531().method_4615(lII);
            }

            class_1060 var10000 = var1.method_1531();
            class_2960 var10001 = lII;
            class_2960 var10004 = lII;
            Objects.requireNonNull(var10004);
            var10000.method_4616(var10001, new class_1043(var10004::toString, var3));
            this.ll = true;
            return true;
         } else {
            if (var3 != null) {
               var3.close();
            }

            return false;
         }
      } else {
         return false;
      }
   }

   void IlII(boolean var1) {
      this.llI = var1;
      <undefinedtype> var2 = this.II;
      if (var1 && var2.IIII() && var2.lII().ll()) {
         this.Illl(class_310.method_1551(), var2);
      }

   }

   private void IlIl(class_310 var1, Object var2) {
      if (this.IIl) {
         if (!var2.I()) {
            this.II = null.lll();
         } else {
            class_2960 var3 = this.ll ? lII : null;
            if (var2.lII() != null) {
               if (this.IIll(var1, var2.lII())) {
                  var3 = lII;
               }
            } else if (!var2.Il().equals(this.II.llI())) {
               var3 = null;
            }

            IIlIlIlIl var4 = (IIlIlIlIl)this.IIIl.getOrDefault(var2.Il(), IIlIlIlIl.Il);
            Record var5 = new Record(true, var2.Il(), IIIIl(var2.IIl()), IIIIl(var2.lI()), IIIIl(var2.lIl()), Math.max(0L, var2.ll()), Math.max(0L, var2.III()), var2.IlI(), System.currentTimeMillis(), var3, var4) {
               private final long I;
               private final String l;
               private final String II;
               private final IIlIlIlIl Il;
               private final String lI;
               private final long ll;
               private final class_2960 III;
               private final boolean IIl;
               private final long IlI;
               private static String[] Ill;
               private final String lII;
               private final boolean lIl;
               private static final int[] llI;

               private static String I(char[] var0, long var1, int var3) {
                  int var4 = IIll(-2047272311, 1063891905) ^ var3;

                  for(int var5 = 0; var5 < var0.length; ++var5) {
                     int var7 = var4 ^ (int)var1 ^ ~var5;
                     int var8 = var7 ^ var3 - var5 * var0.length;
                     var4 = -var8 * var3 | var5;
                     var0[var5] = (char)(var0[var5] ^ var4);
                     int var6 = var5 & IIll(-2047272312, 889496581);
                     var3 = var3 << var6 | var3 >>> -var6;
                     var1 ^= (long)var6;
                  }

                  return new String(var0);
               }

               private static void l() {
                  Ill[0] = I("".toCharArray(), 41855L, IIll(-2047272309, 752970765));
               }

               public long II() {
                  return this.ll;
               }

               double Il(long var1) {
                  return this.IlI <= 0L ? (double)0.0F : Math.max((double)0.0F, Math.min((double)1.0F, (double)this.Ill(var1) / (double)this.IlI));
               }

               public String lI() {
                  return this.lII;
               }

               {
                  this.lIl = var1;
                  this.l = var2;
                  this.lII = var3;
                  this.II = var4;
                  this.lI = var5;
                  this.I = var6;
                  this.IlI = var8;
                  this.IIl = var10;
                  this.ll = var11;
                  this.III = var13;
                  this.Il = var14;
               }

               public class_2960 ll() {
                  return this.III;
               }

               public long III() {
                  return this.IlI;
               }

               public long IIl() {
                  return this.I;
               }

               public boolean IlI() {
                  return this.IIl;
               }

               long Ill(long var1) {
                  long var3 = this.I;
                  if (this.IIl) {
                     var3 += Math.max(0L, var1 - this.ll);
                  }

                  return Math.max(0L, Math.min(var3, Math.max(0L, this.IlI)));
               }

               public IIlIlIlIl lII() {
                  return this.Il;
               }

               <undefinedtype> lIl(IIlIlIlIl var1) {
                  return new <anonymous constructor>(this.lIl, this.l, this.lII, this.II, this.lI, this.I, this.IlI, this.IIl, this.ll, this.III, var1 == null ? IIlIlIlIl.Il : var1);
               }

               public String llI() {
                  return this.l;
               }

               static <undefinedtype> lll() {
                  return new <anonymous constructor>(false, Ill[0], Ill[0], Ill[0], Ill[0], 0L, 0L, false, 0L, (class_2960)null, IIlIlIlIl.Il);
               }

               public boolean IIII() {
                  return this.lIl;
               }

               public String IIIl() {
                  return this.lI;
               }

               static {
                  int var2 = -1670760781;
                  byte[] var0 = "5Èû¹,\u0097\u0088Á%1-S".getBytes("ISO-8859-1");
                  int var1 = var0.length / 4;
                  llI = new int[var1];
                  int var3 = 0;
                  int var4 = 0;

                  do {
                     int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
                     var5 ^= var2;
                     llI[var4] = var5;
                     var3 += 4;
                     ++var4;
                  } while(var4 < var1);

                  Ill = new String[1];
                  l();
               }

               public String IIlI() {
                  return this.II;
               }

               private static int IIll(int var0, int var1) {
                  return llI[var0 ^ -2047272311] ^ var1 ^ var0;
               }
            };
            this.II = var5;
            if (this.llI && var4.ll()) {
               this.Illl(var1, var5);
            }

         }
      }
   }

   static {
      short var6 = 3059;
      String var7 = "\ue21b潉겕龊䤥帨ళ鸝쿎\uf049軦昜\u0eda딥\ud9ce⚁헇\udbdb덵犚ቄᏝ⛒\uedf5团즿霚㮈癶㕇\udcd8侘暲搥\ue5fe觢㶉䤐妑ዼሀ颰恤䈵溱뵢쒎䟶ꁂ磷ꃉয鰟Ն袘砬\udd27䅸者礿䍜㨥ꑗᩭ䘢令K㒹\ue5ca蒮撾䫹젤횲ꔎ悱뢺뒅蚅♻鋼┣菾鈯㧠\ue94f華놰熔즋츕迱\uf0c7敌ꯠ暌淋싊☀\uee21쮾淤\ue1d4\u0f6f쪼郳蛞톤㥥꽑얈裊ộ京푵\ude0cꔞ筮Ṕ㯒\ud970㋯\uf31b⒬\uf0e0蹑㙶ፍ킿\ua8cb蟃扏逈氒牉圴荮\uee9d惈ꥤㄔܹ⓬\uf4bf㼋避皏틸磠ꄈ海\ue217ﲡ嵅\uf224≏ᖮ슏襛\uf451酱炥\uf631눺䷮隺ꙻ翍윾濭\uf7c2넑⭹탵흎링ᬜ洅ﬅ圂쏷隇婜퐂㋘\uee1d輳셫ݑ\uf45b动驸㹵矷\uf5d8症舊\uea61\ue4b4鑵秪䔣눵⠟倈殅\uf59f僮⩷鹖\u1c8c쫐蛲镍ኘ豪▥樵\ud988婞\udea3녂ϐ댥샔랫৭崆\ued24䇃ྛ焧鈬䳬꜆\ueb2e嫵⋥觥ꌢ㦀깦蓥ӌ貲툇鞌\uf0b1쳡鈓䖯斖\udf67䤬췾ੂ鈍艏\ue0ef揻꜏䀻ଧ웖眍듅냝䙻롑褦ٖ蟻뿠驩ℯ⍍෬₴ҏ陝읎\uec6d金쪉歬\udaba\uec01\uecd9\udb51䵨ɢ丞柵\uf773䝗꾧蜳脗俊궪촫\ueac4腙\udfe4璸\ue0b8맆鲗젿掶鍸\uf281❱擈\udb7d隼좬冮座浻芍߾\u0a61薿拌ᤞᮀ⾥\ue57e㭱ʽ츪㞏ⷀ덷舗ꄫ걶天ᡭΉъ쇵甫濣去흂ᬹ쨦\udacd摃Ȩ\ue15d붵툕Э㯰\uf2a0찞ﱌ喀ㅐ\ude55ᴒ扐Ό㛟햿ࢹ\ue3e5迏秣쐮Ⱟ\uf287Ï魦㢥篮ㇾ盦벼鷀猠ﵺꗥ㨮瞨ꓑ䇀聉䜁띹⭄売汊괪ﯺꥅ斉ܖꔀ蟅Ṛ\uebc7ꕢ贕\uf7fc\uec2d┳骴⾀⾲鋾朎\uee74蠬膹▭彰ꡗ⢠ᅻ∲蠭敌⽤ཕ❵㴉별忙ຈ䦕ᜳ┧뼄\uebcf鏆ক㶐䡣ჾ\uf354ƛ\ueeea\uee23嘺\udeaf붔迵ꬹ갛\uea0d꽜硵쏿籚\uede1먚輆昌㝠륽\ue126莛⭾๎遳淳\ue2efĠ뮉⬰ꔉ\uea4c体蘮\uf4e9蒏执⑼ჱ俠篕˧昽\ue236მবÕ태\ud7ca覦\ud984坡\udb9cḉ\ue6fb᮳㓨ᄮD㼆ꧢ멙ᕜ誾咥쬽᳒﹕㱵㜎ꥑ⟁籴橹≴繖\ue31a\uf86c\uf141\ue31fᲴㄱ螓癜헧桲主䆨睛훬耇ঘﭴ죢蘉㠫؟띠\udd9f\uec46￫湒쉘鞎\ue172둬栜㦘뀛䮍䡀ᤓ訰糞끥\u244bѱ봇肨뺂젉⤻\ufde5ꈀ분\uf2c4곞釹쒕⽢↋櫷᭷\uf4b4虌\udda0ꉉ윰캀⠥明꣼秉繮馏뢑꺔銳珶㰲꾉엍㰶\uda91\uf128⻑硌쯽坭쁜ꊆ\ue3b0诞诶稗괣\ueb6b뫪葍澤큟㢍\uec2a\ue675\ude53ඟᲁ윐鎧៛誦⥅㼥懶뼡鉌틳\u2feb蕉솶㼍\uf0dd妝햎䆐\udcaf룭뀵ᤃ㊵혠ߡ帮℄ꘝ쮷䊑儭뚔쇦㣚\u20faᓎ칍➋᧙㕦䯠\ua8c8哀\udeacی◻⢕\uda66ℏﲢ㬣飏跔\ue253逌\ue6c4垂\uf01b\ue9b8";
      char[] var8 = "\u0bd3\u0bfb௧௫\u0be3\u0bfb௧\u0be3\u0be3\u0bd3\u0be3\u0bfb\u0bfb\u0bff\u0bff\u0be3\u0bfb\u0bff\u0be3\u0bff\u0be3ௗ\u0be3௧\u0be3௫\u0bfb\u0bdf௯௫ோ௷௧ோ".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IIll = var9;
            IlII = new Object[var9.length];
            int var2 = 1715417595;
            byte[] var0 = "<?ÞæE¨FàÌ!Yù#â<^)\u0089\u0001ÛôËðaIm\u008cÈ9\u0087\u008c\u009a\u00896\u009eÆ\u009d8Z\u0010íì¹\u0006ÿ4\u0081\u00146Þñ\u001d«v\nå·\u0088fà\r.\u0083÷ïRl3Ý@©Ôsó`ùi\u001f=YÚÈ\u008e\u001a¯\u009f:¯\u0084Ü\u00104ZL\u00061¾\u0003:_dO<\u008c\u0086|\u009c\u001eI¸WO®\u0011mÐ¾I¿â\u0014*9Ð½\u0003~_Ôçts²^ö\u0003£ã\u0003I\u000b±\u001aNæYÇ\u0017ÕwPS¹¹\u009dó-\u0088Õ\u008c\u0018 QÌ\u0018Îª-T7iw¨çFzÓ\u0096\u0088]½\u0006\u0093ÿDm\u009déùÍêW(.ªÝÝQ\u0085dJ\u009aÂóK\u000e @±ã¦¾?Ñæ\u0090Á ¾øÞ0ÊÜ|¦õ×bº=³ÿN æ±!\u0082Üi)ß\\j\u0016Ó#B\u000eM3\u0096(\u0018Ó¢R\u0000Ý\u008ejí\u0098Î\u0012£É°\u001c\u008fòz\u0015\u0097Ú\u001c\u0018@4n KÍ\u008em\r \u0096$ÓÑÔiC<Í`c4\u0093¬úÊ.í\u0097Z!\f¶\u001b°È,ªÃ8äë\n¨õ~~\"Ù£ø¾\u0087\u000eù¤÷T~ÀÄè\u0096ð(X\u0001\u0012înîÛ¡\u008cá¬z\u0003t\u0018ÀÜÛ=3\n>OX¹×(\u008f\f~£\u0005;ZÑ»I\u008ezÍ\u0003RZK+Û$ð\u0084\u008a\u0011\u0088q\u0080Øp^ÝíI\u0001±\u001bWã<À÷X\u0085·\u001dÒ4ndÌJ\u0081¤\u00131\u0098Ã\u0092\u0003\u0095?L\u00933»4ú\u0004¥q\u0013ÅÈO<\u0086¥[[\u0099Å\u0088\u0006åxû\u009aý\\Z".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IIlI = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IIlI[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            Ill = new String[IIIlI(492781483, -71795155)];
            II();
            lII = class_2960.method_60655(lIlIII.Il(Ill[IIIlI(492781484, -1500690611)]), lIlIII.Il(Ill[IIIlI(492781485, -897885777)]));
            lI = Executors.newSingleThreadExecutor((var0x) -> {
               Thread var1 = new Thread(var0x, lIlIII.Il(Ill[0]));
               var1.setDaemon(true);
               return var1;
            });
            lll = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5L)).followRedirects(Redirect.NORMAL).build();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private void Illl(class_310 var1, Object var2) {
      if (this.llI && var1 != null && var2.IIII() && !var2.llI().equals(this.I)) {
         IIlIlIlIl var3 = (IIlIlIlIl)this.IIIl.get(var2.llI());
         if (var3 != null) {
            this.II = var2.lIl(var3);
         } else {
            this.I = var2.llI();
            this.Il = l(var2).exceptionally((var0) -> IIlIlIlIl.Il).thenAccept((var3x) -> var1.execute(() -> {
                  this.IlI(var2.llI(), var3x);
                  <undefinedtype> var3xx = this.II;
                  if (var3xx.llI().equals(var2.llI())) {
                     this.II = var3xx.lIl(var3x);
                  }

               }));
         }
      }
   }

   private static boolean lIIl(JsonObject var0, String var1) {
      JsonElement var2 = var0.get(var1);
      return var2 != null && !var2.isJsonNull() && var2.getAsBoolean();
   }

   private static String lIlI(char[] var0, long var1, int var3) {
      int var4 = IIIlI(492781486, 1332385935) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IIIlI(492781487, -19459207);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   void lIll(class_310 var1) {
      this.IIl = true;
      if (!this.lIl && var1 != null) {
         this.lIl = true;
         CompletableFuture.runAsync(() -> this.llll(var1), lI).whenComplete((var1x, var2) -> this.lIl = false);
      }
   }

   private static String llII(String var0) {
      return URLEncoder.encode(var0 == null ? Ill[IIIlI(492781472, 1326344835)] : var0, StandardCharsets.UTF_8);
   }

   private void llll(class_310 var1) {
      while(this.IIl) {
         try {
            Path var2 = this.Il();
            Runtime var10000 = Runtime.getRuntime();
            String[] var10001 = new String[IIIlI(492781478, 1755694613)];
            var10001[0] = lIlIII.Il(Ill[2]);
            var10001[1] = lIlIII.Il(Ill[4]);
            var10001[2] = lIlIII.Il(Ill[IIIlI(492781479, 1206299393)]);
            var10001[3] = lIlIII.Il(Ill[3]);
            var10001[4] = lIlIII.Il(Ill[1]);
            var10001[5] = lIlIII.Il(Ill[5]);
            var10001[IIIlI(492781496, 553241549)] = var2.toString();
            Process var3 = var10000.exec(var10001);
            this.l = var3;

            try {
               BufferedReader var4 = new BufferedReader(new InputStreamReader(var3.getInputStream(), StandardCharsets.UTF_8));

               String var5;
               try {
                  while(this.IIl && (var5 = var4.readLine()) != null) {
                     <undefinedtype> var6 = lIl(var5);
                     if (var6 != null) {
                        var1.execute(() -> this.IlIl(var1, var6));
                     }
                  }
               } catch (Throwable var23) {
                  try {
                     var4.close();
                  } catch (Throwable var22) {
                     var23.addSuppressed(var22);
                  }

                  throw var23;
               }

               var4.close();
            } finally {
               var3.destroy();
               if (!var3.waitFor(500L, TimeUnit.MILLISECONDS)) {
                  var3.destroyForcibly();
               }

            }
         } catch (Exception var25) {
         } finally {
            this.l = null;
         }

         if (this.IIl) {
            try {
               Thread.sleep(2000L);
            } catch (InterruptedException var21) {
               Thread.currentThread().interrupt();
               return;
            }
         }
      }

   }

   private static String IIIII(JsonObject var0, String var1) {
      JsonElement var2 = var0.get(var1);
      return var2 != null && !var2.isJsonNull() ? var2.getAsString() : Ill[IIIlI(492781497, 2105898669)];
   }

   private static String IIIIl(String var0) {
      return var0 == null ? Ill[IIIlI(492781498, -509783537)] : var0.strip();
   }

   private static int IIIlI(int var0, int var1) {
      return IIlI[var0 ^ 492781512] ^ var1 ^ var0;
   }

   private static String IIIll(int var0, int var1) {
      int var3 = var0 ^ -1500959799;
      char[] var4 = IIll[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IlII[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IlII[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 1187375341;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 34;
               break;
            case 1:
               var9 = 112;
               break;
            case 2:
               var9 = 45;
               break;
            case 3:
               var9 = 137;
               break;
            case 4:
               var9 = 122;
               break;
            case 5:
               var9 = 15;
               break;
            case 6:
               var9 = 55;
               break;
            case 7:
               var9 = 7;
               break;
            case 8:
               var9 = 22;
               break;
            case 9:
               var9 = 55;
               break;
            case 10:
               var9 = 85;
               break;
            case 11:
               var9 = 89;
               break;
            case 12:
               var9 = 27;
               break;
            case 13:
               var9 = 46;
               break;
            case 14:
               var9 = 203;
               break;
            case 15:
               var9 = 219;
               break;
            case 16:
               var9 = 26;
               break;
            case 17:
               var9 = 177;
               break;
            case 18:
               var9 = 91;
               break;
            case 19:
               var9 = 182;
               break;
            case 20:
               var9 = 18;
               break;
            case 21:
               var9 = 59;
               break;
            case 22:
               var9 = 239;
               break;
            case 23:
               var9 = 87;
               break;
            case 24:
               var9 = 239;
               break;
            case 25:
               var9 = 52;
               break;
            case 26:
               var9 = 83;
               break;
            case 27:
               var9 = 145;
               break;
            case 28:
               var9 = 93;
               break;
            case 29:
               var9 = 188;
               break;
            case 30:
               var9 = 209;
               break;
            case 31:
               var9 = 56;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
