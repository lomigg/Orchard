package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;

@Environment(EnvType.CLIENT)
public final class lIIIllI extends IIIIIIIlI {
   private static String[] I;
   private final IlIIIlIlI<<undefinedtype>> l;
   private static final int[] II;
   private static final String[] Il;
   private static final Object[] lI;

   public boolean ll() {
      return this.llI() != null.II;
   }

   public boolean IlI() {
      return true;
   }

   private boolean lII(class_310 var1, class_1309 var2) {
      if (this.IlI() && var1 != null && var1.field_1724 != null && var2 == var1.field_1724 && IlIlIl.IlI(var1)) {
         float var3 = Math.abs(class_3532.method_15393(IlIlIl.llll() - var1.field_1724.method_36454()));
         float var4 = Math.abs(IlIlIl.lllI() - var1.field_1724.method_36455());
         return var3 > 0.001F || var4 > 0.001F;
      } else {
         return false;
      }
   }

   public String Il() {
      return this.llI().toString();
   }

   public <undefinedtype> llI() {
      return (<undefinedtype>)this.l.III();
   }

   private static void lll() {
      I[0] = IIll(IlIl('\uf8c1', 1201802320, 11315).toCharArray(), 17689L, IlII(1765954478, 1522797759));
      I[1] = IIll(IlIl('珱', 1644656733, 11314).toCharArray(), 27503L, IlII(1765954479, 852525469));
      I[2] = IIll(IlIl('鷟', -304913023, 11313).toCharArray(), 39769L, IlII(1765954476, -256793480));
   }

   public lIIIllI() {
      super((Object)lIlIII.l(I[0]), lIllII.III, (Object)lIlIII.l(I[1]), false);
      this.l = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(I[2]), <undefinedtype>.class, null.II));
   }

   public class_243 IIII(class_1309 var1) {
      class_310 var2 = class_310.method_1551();
      return !this.lII(var2, var1) ? var1.method_5720() : class_243.method_1030(IlIlIl.lllI(), IlIlIl.llll());
   }

   private static String IIll(char[] var0, long var1, int var3) {
      int var4 = IlII(1765954477, 1951451222) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IlII(1765954474, 1093755391);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   static {
      short var6 = 26056;
      String var7 = "㎃༑⊗\udad2汋㼱ɳ勇爍ٲ⻃쬨襮摗쎖ஊ峡㭩ᚕ豈뤅䆂쎊厲즏┾\uf4b9䢁앖⽙ౣણ心솎筑堢嗡笟혓땃䔡\ue0d0❃ⵂ勞⏮쯈迦ጹ칛眎碠⠥䏥㱈듣똗퓬㶘亾㈄峚\ue8bc紂ᵢ火놣ꩯꠊ\udd17驿헠ꘉ\ud901퍆볖\udf19찳泐ꛈ⼦馨\ue128ﱆᄟᅆ\ue528\uf446镑㾌访薫噌㙳ℒ㌲埐\udb31龡鿿\ue8aaҸ餪鈱뵬仳눚幥";
      char[] var8 = "旄斐旀".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            Il = var9;
            lI = new Object[var9.length];
            int var2 = 924594024;
            byte[] var0 = "Ù<¬Ò×YÞØ\u001a6\u009e×ø\u008bø6\u001fo\u001dÂ".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            II = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               II[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            I = new String[3];
            lll();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static int IlII(int var0, int var1) {
      return II[var0 ^ 1765954478] ^ var1 ^ var0;
   }

   private static String IlIl(char var0, int var1, int var2) {
      int var3 = var2 ^ 11315;
      char[] var4 = Il[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])lI[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         lI[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 18524;
      int var9 = 0;

      do {
         int var10 = var4[var9] ^ 27604;
         var10 += 12158;
         var10 ^= 44241;
         var10 -= 24140;
         var10 -= 50159;
         var10 -= 59145;
         var10 ^= 28344;
         var10 += 44326;
         var10 += 6765;
         var10 ^= 61722;
         var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
