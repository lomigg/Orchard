package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_332;

@Environment(EnvType.CLIENT)
public interface llIlIIII {
   void III(class_332 var1, int var2, int var3, float var4, boolean var5);

   double lIIl();

   void IIl(class_332 var1, int var2, int var3, float var4);

   double Il();

   void lIlI(double var1, double var3);

   boolean IIlI(double var1, double var3);

   double Ill();

   double llll();
}
