package x;

import java.util.LinkedHashMap;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_243;

@Environment(EnvType.CLIENT)
class IlII extends LinkedHashMap<IIIIlllIl, class_243> {
   // $FF: synthetic field
   final IIlIlllIl I;
   private static final int[] l;

   IlII(IIlIlllIl var1, int var2, float var3, boolean var4) {
      super(var2, var3, var4);
      this.I = var1;
   }

   protected boolean removeEldestEntry(Map.Entry<IIIIlllIl, class_243> var1) {
      return this.size() > I(1147290009, 1747260804);
   }

   private static int I(int var0, int var1) {
      return l[var0 ^ 1147290009] ^ var1 ^ var0;
   }

   static {
      int var2 = 1338199938;
      byte[] var0 = "c\u0084\u001b¿".getBytes("ISO-8859-1");
      int var1 = var0.length / 4;
      l = new int[var1];
      int var3 = 0;
      int var4 = 0;

      do {
         int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
         var5 ^= var2;
         l[var4] = var5;
         var3 += 4;
         ++var4;
      } while(var4 < var1);

   }
}
