package x;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import java.math.BigDecimal;
import java.math.RoundingMode;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class llllIlIl extends llllllI<double[]> {
   private final double I;
   private final double l;
   private static final <undefinedtype> II;
   private static final <undefinedtype> Il;
   private final double lII;
   private <undefinedtype> lIl;
   private static final int[] llI;
   private static final String[] lll;
   private static final Object[] IIII;

   static {
      short var6 = 13244;
      String var7 = "旖斏斎旂敮敬斆旃旁敬旃敦斅施斠斅ⱺⰣⰖⰼⱃⱀⱹ⯱ⰚⰏⱅⱅ";
      char[] var8 = "㎬㎰".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            lll = var9;
            IIII = new Object[var9.length];
            int var2 = 2063891020;
            byte[] var0 = "^N;<".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            llI = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               llI[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            II = lIlIII.l(IllI((short)7924, '极', -1336515754));
            Il = lIlIII.l(IllI((short)6832, '枀', 1789797287));
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public double I() {
      return this.l;
   }

   public double ll() {
      return this.I;
   }

   public double IlI() {
      return ((double[])this.III())[1];
   }

   public llllIlIl Ill(Object var1) {
      <undefinedtype> var10001;
      if (var1 instanceof <undefinedtype> var2) {
         var10001 = var2;
      } else {
         var10001 = lIlIII.III(var1 == null ? "" : var1.toString());
      }

      this.lIl = var10001;
      return this;
   }

   private <undefinedtype> lII() {
      <undefinedtype> var1 = this.lIIl();
      if (var1.Il(II)) {
         return var1.l(var1.llIl() - II.llIl());
      } else {
         return var1.Il(Il) ? var1.l(var1.llIl() - Il.llIl()) : var1;
      }
   }

   public double lIl() {
      return this.lII;
   }

   public llllIlIl(String var1, double var2, double var4, double var6, double var8, double var10) {
      this((Object)var1, var2, var4, var6, var8, var10);
   }

   public llllIlIl(Object var1, double var2, double var4, double var6, double var8, double var10) {
      super((Object)var1, new double[]{var2, var4});
      this.lIl = lIlIII.III("");
      this.I = var6;
      this.lII = var8;
      this.l = var10;
   }

   public String llI() {
      return this.lIl.lIlI();
   }

   public <undefinedtype> lll() {
      return this.lIl;
   }

   public void II(JsonElement var1) {
      if (var1 != null && var1.isJsonArray()) {
         JsonArray var4 = var1.getAsJsonArray();
         if (var4.size() >= 2) {
            this.IIIl(new double[]{var4.get(0).getAsDouble(), var4.get(1).getAsDouble()});
         }

      } else {
         if (var1 != null && var1.isJsonPrimitive() && var1.getAsJsonPrimitive().isNumber()) {
            double var2 = var1.getAsDouble();
            this.IIIl(new double[]{var2, var2});
         }

      }
   }

   public JsonElement lI() {
      JsonArray var1 = new JsonArray();
      var1.add(new JsonPrimitive(((double[])this.III())[0]));
      var1.add(new JsonPrimitive(((double[])this.III())[1]));
      return var1;
   }

   public llllIlIl IIII(String var1) {
      return this.Ill(var1);
   }

   public String Illl() {
      return this.lII().lIlI();
   }

   public void IIIl(double[] var1) {
      if (var1 != null && var1.length >= 2) {
         double var2 = this.IIll(Math.max(this.I, Math.min(this.lII, var1[0])));
         double var4 = this.IIll(Math.max(this.I, Math.min(this.lII, var1[1])));
         if (var2 > var4) {
            double var6 = var2;
            var2 = var4;
            var4 = var6;
         }

         super.Il(new double[]{var2, var4});
      }
   }

   public long lllI() {
      return this.lII().lll();
   }

   private int IIlI() {
      double var1 = Math.abs(this.l);

      int var3;
      for(var3 = 0; var3 < IlIl(-1400355319, -1983772801) && Math.abs(var1 - Math.rint(var1)) > 1.0E-6; ++var3) {
         var1 *= (double)10.0F;
      }

      return var3;
   }

   private double IIll(double var1) {
      if (this.l <= (double)0.0F) {
         return var1;
      } else {
         long var3 = Math.round(var1 / this.l);
         return BigDecimal.valueOf(this.l).multiply(BigDecimal.valueOf(var3)).setScale(this.IIlI(), RoundingMode.HALF_UP).doubleValue();
      }
   }

   public double IlII() {
      return ((double[])this.III())[0];
   }

   private static int IlIl(int var0, int var1) {
      return llI[var0 ^ -1400355319] ^ var1 ^ var0;
   }

   private static String IllI(short var0, char var1, int var2) {
      int var3 = var1 ^ 26497;
      char[] var4 = lll[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])IIII[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         IIII[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 11313;
      int var9 = 0;

      do {
         int var10 = var4[var9] - '졹';
         var10 += 33605;
         var10 += 61040;
         var10 ^= 5098;
         var10 += 40372;
         var10 ^= 48418;
         var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var2 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
