package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_3965;

@Environment(EnvType.CLIENT)
record lllllIl(class_3965 impact) {
   private final class_3965 I;

   public class_3965 I() {
      return this.I;
   }

   private lllllIl(class_3965 var1) {
      this.I = var1;
   }
}
