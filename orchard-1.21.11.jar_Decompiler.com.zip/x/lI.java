package x;

import java.util.List;
import java.util.Locale;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_3966;
import net.minecraft.class_3675.class_307;

@Environment(EnvType.CLIENT)
public final class lI extends IIIIIIIlI {
   private final lIIIIl I = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lIIl(-473490956, -222857355)), false));
   private final lIIIlll l = (lIIIlll)this.IIIlIll(new lIIIlll(lIlIII.l(lIIl(-473490949, -1660063499)), List.of()));
   private boolean II;
   private final lIIIIl Il = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lIIl(-473490955, 1691692852)), true));
   private static final int[] lI;
   private static final String[] ll;
   private static final Object[] III;

   public void IllI(class_310 var1) {
      if (var1 == null) {
         this.II = false;
      } else {
         boolean var2 = IllllIlI.IlIII(var1, class_307.field_1672.method_1447(2));
         boolean var3 = var2 && !this.II;
         this.II = var2;
         if (var3 && (Boolean)this.I.III() && var1.field_1755 == null && var1.field_1724 != null) {
            class_239 var6 = var1.field_1765;
            if (var6 instanceof class_3966) {
               class_3966 var4 = (class_3966)var6;
               class_1297 var7 = var4.method_17782();
               if (var7 instanceof class_1657) {
                  class_1657 var5 = (class_1657)var7;
                  if (var5 != var1.field_1724 && var5.method_7334() != null) {
                     String var8 = lII(IIIIlII.II(var5.method_7334()));
                     if (var8.isEmpty()) {
                        return;
                     }

                     if (this.llI(var8)) {
                        this.lll(var8);
                     } else {
                        this.Illl(var8);
                     }

                     this.IIll();
                     return;
                  }
               }
            }
         }

      }
   }

   private static String ll(String var0) {
      return var0 == null ? "" : var0.trim().toLowerCase(Locale.ROOT);
   }

   public boolean IlI(class_1657 var1) {
      return this.IIIIIlI() && var1 != null && var1.method_7334() != null ? this.llI(IIIIlII.II(var1.method_7334())) : false;
   }

   public void Ill() {
      IllllIll.IlI();
   }

   private static String lII(String var0) {
      String var1 = var0 == null ? "" : var0.trim().replaceAll(lIlIII.Il(lIIl(-473490957, -842581893)), "");
      return var1.length() <= lIII(272199644, -43407205) ? var1 : var1.substring(0, lIII(272199645, -1719966477));
   }

   public boolean llI(String var1) {
      String var2 = ll(var1);
      if (var2.isEmpty()) {
         return false;
      } else {
         for(<undefinedtype> var4 : this.l.lII()) {
            if (var4.lllI(var2)) {
               return true;
            }
         }

         return false;
      }
   }

   private void lll(String var1) {
      String var2 = ll(var1);
      if (!var2.isEmpty()) {
         this.l.lIl(var2);
      }
   }

   public List<String> IIII() {
      return List.copyOf(this.l.IIIl());
   }

   private void IIll() {
      List var1 = this.IIII();
      String var10000 = this.IIlllII();
      String var10001 = lIlIII.Il(lIIl(-473490958, 314716966));
      String var4 = var1.isEmpty() ? lIlIII.Il(lIIl(-473490959, -1972825427)) : String.join(lIlIII.Il(lIIl(-473490960, -723710889)), var1);
      String var3 = var10001;
      String var2 = var10000;
      lIllIlIl.I(var2 + var3 + var4);
   }

   public boolean IlII(class_1657 var1) {
      return (Boolean)this.Il.III() && this.IlI(var1);
   }

   public lI() {
      super((Object)lIlIII.l(lIIl(-473490953, -264303741)), lIllII.lI, (Object)lIlIII.l(lIIl(-473490954, 1075196810)));
   }

   public void lI() {
      this.II = false;
      IllllIll.IlI();
   }

   public boolean IlIl(String var1) {
      if (var1 != null && !var1.isBlank()) {
         String var2 = var1.trim();
         if (var2.startsWith(lIlIII.Il(lIIl(-473490950, 1004929252))) || var2.startsWith(lIlIII.Il(lIIl(-473490951, -1735766164)))) {
            var2 = var2.substring(1).trim();
         }

         String[] var3 = var2.split(lIlIII.Il(lIIl(-473490952, 1125399395)), 3);
         if (var3.length == 0) {
            return false;
         } else {
            String var4 = var3[0];
            if (!var4.equalsIgnoreCase(lIlIII.Il(lIIl(-473490945, 1872445131))) && !var4.equalsIgnoreCase(lIlIII.Il(lIIl(-473490946, -1984077592))) && !var4.equalsIgnoreCase(lIlIII.Il(lIIl(-473490947, -1500106007)))) {
               return false;
            } else if (var3.length >= 3 && var3[1].equalsIgnoreCase(lIlIII.Il(lIIl(-473490948, -545648980)))) {
               this.Illl(var3[2]);
               this.IIll();
               return true;
            } else if (var3.length < 3 || !var3[1].equalsIgnoreCase(lIlIII.Il(lIIl(-473490973, 774387367))) && !var3[1].equalsIgnoreCase(lIlIII.Il(lIIl(-473490974, 891305961))) && !var3[1].equalsIgnoreCase(lIlIII.Il(lIIl(-473490975, -2041623951)))) {
               if (var3.length != 1 && (var3.length < 2 || !var3[1].equalsIgnoreCase(lIlIII.Il(lIIl(-473490976, 1389502007))))) {
                  if (var3.length >= 2 && var3[1].equalsIgnoreCase(lIlIII.Il(lIIl(-473490969, 2082747980)))) {
                     this.l.ll(List.of());
                     this.IIll();
                     return true;
                  } else {
                     return true;
                  }
               } else {
                  this.IIll();
                  return true;
               }
            } else {
               this.lll(var3[2]);
               this.IIll();
               return true;
            }
         }
      } else {
         return false;
      }
   }

   private void Illl(String var1) {
      String var2 = lII(var1);
      if (!var2.isEmpty() && !this.llI(var2)) {
         this.l.lll(var2);
      }
   }

   private static int lIII(int var0, int var1) {
      return lI[var0 ^ 272199644] ^ var1 ^ var0;
   }

   static {
      short var6 = 10330;
      String var7 = "ႛ၎ူზၬစქႲ၏ၟაၮ႖ၿႱႹ႐ၬჺဖ쾥켪켷쿼坈垤埰块ৼएनৣ䄥䆰䆽䄤䆖䆣䅨䄖䇱䇞䄨䆼\uf109\uf1c3\uf188\uf13b\uf1b8\uf199\uf14a\uf133\uf1d8\uf1f8\uf151\uf1ca\uf10e\uf1c8\uf11d\uf114\uf110\uf1f1\uf12c\uf1c0\uf151\uf175\uf197\uf1a9\uf140\uf119\uf112\uf1bc\uf18e\uf1ca\uf1cf\uf161\uf10d\uf1b0\uf1c5\uf121\uf1e5\uf1bf\uf158\uf111\uf1c8\uf19b\uf11a\uf1cb\uf13d\uf1ea\uf17d\uf12e\uf165\uf1d0\uf117\uf1d9\uf10e\uf15b\uf1e4\uf1b1\uf16d\uf15c\uf149\uf19c\uf18c\uf1c2\uf1df\uf126허핼핗허핸학햞헽픘픂헂핖䎯䌍䍞䎙䌞䌻䏒䎙䍭䍣䎶䍫䎪䍩䎼䎨䎦䌝䎰䍉䏶䎑䍗䌿䏠䎣䏥䍬ⰗⲂⲏⰖⲤⲑⱚⰤⳃⳬⰚⲎ\ue6c7\ue61d\ue67f\ue6d8䖫䕡䔓䖴鹴黁黓鹱닥뉨뉥닼뉎뉻늰닎哃呎呃哚周呝咖哨吏吠哖呂篨筭笏箨ȇʼʜȨ\uf351\uf3c4\uf3ca\uf371\uf3fb\uf3ed\uf35e\uf37a\ue85e\ue8f6\ue8c2\ue87a嬱宙宭嬕定宬嬱嬝辮輄轇辙較輡辠迮ꅙꆍꇨꅵꇲꇇꄘꄘ";
      char[] var8 = "\u0014\u0004\u0004\u0004\f@\f\u001c\f\u0004\u0004\u0004\b\f\u0004\u0004\b\u0004\b\b\b".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            ll = var9;
            III = new Object[var9.length];
            int var2 = 896222704;
            byte[] var0 = "Ø;\u0082§¼)NÎ".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lI = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lI[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 73;
                     break;
                  case 1:
                     var10000 = 121;
                     break;
                  case 2:
                     var10000 = 89;
                     break;
                  case 3:
                     var10000 = 87;
                     break;
                  case 4:
                     var10000 = 40;
                     break;
                  case 5:
                     var10000 = 121;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static String lIIl(int var0, int var1) {
      int var3 = var0 ^ -473490957;
      char[] var4 = ll[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])III[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         III[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -442829381;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 173;
               break;
            case 1:
               var9 = 17;
               break;
            case 2:
               var9 = 9;
               break;
            case 3:
               var9 = 160;
               break;
            case 4:
               var9 = 100;
               break;
            case 5:
               var9 = 63;
               break;
            case 6:
               var9 = 242;
               break;
            case 7:
               var9 = 140;
               break;
            case 8:
               var9 = 78;
               break;
            case 9:
               var9 = 73;
               break;
            case 10:
               var9 = 138;
               break;
            case 11:
               var9 = 79;
               break;
            case 12:
               var9 = 157;
               break;
            case 13:
               var9 = 117;
               break;
            case 14:
               var9 = 162;
               break;
            case 15:
               var9 = 147;
               break;
            case 16:
               var9 = 229;
               break;
            case 17:
               var9 = 98;
               break;
            case 18:
               var9 = 158;
               break;
            case 19:
               var9 = 66;
               break;
            case 20:
               var9 = 252;
               break;
            case 21:
               var9 = 204;
               break;
            case 22:
               var9 = 114;
               break;
            case 23:
               var9 = 24;
               break;
            case 24:
               var9 = 195;
               break;
            case 25:
               var9 = 164;
               break;
            case 26:
               var9 = 190;
               break;
            case 27:
               var9 = 57;
               break;
            case 28:
               var9 = 106;
               break;
            case 29:
               var9 = 111;
               break;
            case 30:
               var9 = 89;
               break;
            case 31:
               var9 = 210;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
