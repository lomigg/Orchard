package x;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public final class IlIllIl {
   private static final double I = (double)64.0F;
   private static String[] l;
   private static final double II = (double)382.0F;
   public static final boolean Il = true;
   private static final double lI = (double)3.0F;
   private static final double ll = (double)32.0F;
   private static final double III = (double)620.0F;
   public static final double IIl = 0.01;
   public static final double IlI = 0.01;
   private static final int[] Ill;
   private static final String[] lII;
   private static final Object[] lIl;

   public static boolean I(long var0, long var2, long var4) {
      return var4 <= 0L || var0 >= var2;
   }

   public static float l(float var0) {
      float var1 = var0 % 360.0F;
      if (var1 >= 180.0F) {
         var1 -= 360.0F;
      }

      if (var1 < -180.0F) {
         var1 += 360.0F;
      }

      return var1;
   }

   public static double II(double var0) {
      double var2 = Double.isFinite(var0) ? Math.max((double)0.0F, var0) : (double)0.0F;
      double var4 = Math.max((double)0.0F, Math.min((double)1.0F, (var2 - (double)0.5F) / (double)11.5F));
      return var4 * var4 * ((double)3.0F - (double)2.0F * var4);
   }

   public static boolean Il(boolean var0, boolean var1, double var2, double var4) {
      return var0 && !var1 && (var2 >= (double)0.0F || var4 <= (double)0.0F);
   }

   public static boolean lI(boolean var0, String var1) {
      return var0 && var1 != null && !var1.isBlank();
   }

   public static boolean ll(Object var0, Object var1) {
      return !Objects.deepEquals(var0, var1);
   }

   public static boolean III(double var0, double var2) {
      return var0 >= llIl(var2);
   }

   public static boolean IIl(boolean var0, int var1, boolean var2) {
      return !var2 && (var0 || var1 > 0);
   }

   public static boolean IlI(double var0, double var2, double var4, double var6, double var8, double var10, double var12, double var14, double var16, double var18, double var20, double var22) {
      double[] var24 = new double[]{(double)0.0F, (double)1.0F};
      if (lIII(var0, var6 - var0, Math.min(var12, var18), Math.max(var12, var18), var24) && lIII(var2, var8 - var2, Math.min(var14, var20), Math.max(var14, var20), var24) && lIII(var4, var10 - var4, Math.min(var16, var22), Math.max(var16, var22), var24)) {
         return var24[0] < 0.999999 && var24[1] >= (double)0.0F;
      } else {
         return false;
      }
   }

   public static String Ill(long var0, long var2) {
      return Long.toString(var0 + Math.max(1L, var2));
   }

   private static float lII(float var0, float var1, float var2) {
      if (var1 < 0.0F) {
         var0 += 180.0F;
      }

      float var3 = 1.0F;
      if (var1 < 0.0F) {
         var3 = -0.5F;
      } else if (var1 > 0.0F) {
         var3 = 0.5F;
      }

      if (var2 > 0.0F) {
         var0 -= 90.0F * var3;
      }

      if (var2 < 0.0F) {
         var0 += 90.0F * var3;
      }

      return var0;
   }

   public static double lIl(double var0) {
      double var2 = Double.isFinite(var0) ? Math.max((double)0.0F, var0) : (double)0.0F;
      return (double)3.0F + var2 / (double)2.0F;
   }

   private static void llI() {
      l[0] = IlIl(IIlll((short)11799, -467463033, 2925).toCharArray(), 60005L, IIllI(1705798090, -867712494));
      l[1] = IlIl(IIlll((short)'\udbcb', 1722900980, 2924).toCharArray(), 38851L, IIllI(1705798091, -2012645450));
   }

   public static <undefinedtype> lll(boolean var0, boolean var1, boolean var2, boolean var3, float var4, float var5) {
      float var6 = (var0 ? 1.0F : 0.0F) - (var1 ? 1.0F : 0.0F);
      float var7 = (var2 ? 1.0F : 0.0F) - (var3 ? 1.0F : 0.0F);
      if (var6 == 0.0F && var7 == 0.0F) {
         return new Record(0.0F, 0.0F) {
            private final float I;
            private final float l;

            public {
               this.I = var1;
               this.l = var2;
            }

            public float I() {
               return this.I;
            }

            public float l() {
               return this.l;
            }
         };
      } else {
         float var8 = lII(var5, var6, var7);
         float var9 = 0.0F;
         float var10 = 0.0F;
         float var11 = Float.MAX_VALUE;

         for(int var12 = -1; var12 <= 1; ++var12) {
            for(int var13 = -1; var13 <= 1; ++var13) {
               if (var12 != 0 || var13 != 0) {
                  float var14 = lII(var4, (float)var12, (float)var13);
                  float var15 = Math.abs(l(var8 - var14));
                  if (var15 < var11) {
                     var11 = var15;
                     var9 = (float)var12;
                     var10 = (float)var13;
                  }
               }
            }
         }

         return new Record(var9, var10) {
            private final float I;
            private final float l;

            public {
               this.I = var1;
               this.l = var2;
            }

            public float I() {
               return this.I;
            }

            public float l() {
               return this.l;
            }
         };
      }
   }

   public static double IIII(int var0, int var1) {
      if (var0 <= 0) {
         return (double)100.0F;
      } else {
         int var2 = Math.max(0, Math.min(var0, var1));
         return (double)(var0 - var2) * (double)100.0F / (double)var0;
      }
   }

   public static boolean IIIl(boolean var0, boolean var1) {
      return var0 && var1;
   }

   public static boolean IIlI(double var0, double var2, double var4, double var6, double var8, double var10, double var12) {
      double var14 = Math.max((double)0.0F, var4);
      double var16 = Math.max(Math.min(var6, var10), Math.min(var0, Math.max(var6, var10)));
      double var18 = Math.max(Math.min(var8, var12), Math.min(var2, Math.max(var8, var12)));
      double var20 = var16 - var0;
      double var22 = var18 - var2;
      return var20 * var20 + var22 * var22 <= var14 * var14;
   }

   public static double IIll(double var0, double var2) {
      return Double.isFinite(var0) && Double.isFinite(var2) && !(Math.abs(var0) <= 1.0E-9) && Math.signum(var0) == Math.signum(var2) ? Math.copySign(Math.min(Math.abs(var2), Math.abs(var0)), var0) : (double)0.0F;
   }

   public static boolean IlII(double var0, double var2, double var4, double var6, double var8) {
      double var10 = Math.max((double)0.0F, var4);
      double var12 = var6 - var0;
      double var14 = var8 - var2;
      return var12 * var12 + var14 * var14 <= var10 * var10;
   }

   private static String IlIl(char[] var0, long var1, int var3) {
      int var4 = IIllI(1705798088, 1568014893) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IIllI(1705798089, -1181982293);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   public static int IllI(int var0, int var1) {
      return var0 + 1 + Math.max(0, var1);
   }

   public static String Illl(String var0, int var1) {
      String var2 = var0 != null && !var0.isBlank() ? var0.trim() : lIlIII.Il(l[0]);
      int var4 = Math.max(1, var1);
      return var2 + var4;
   }

   private static boolean lIII(double var0, double var2, double var4, double var6, double[] var8) {
      if (!(Math.abs(var2) < 1.0E-9)) {
         double var9 = (var4 - var0) / var2;
         double var11 = (var6 - var0) / var2;
         if (var9 > var11) {
            double var13 = var9;
            var9 = var11;
            var11 = var13;
         }

         var8[0] = Math.max(var8[0], var9);
         var8[1] = Math.min(var8[1], var11);
         return var8[0] <= var8[1];
      } else {
         return var0 >= var4 && var0 <= var6;
      }
   }

   public static double lIIl(double var0, int var2, int var3) {
      double var4 = Double.isFinite(var0) ? Math.max((double)1.0F, var0) : (double)1.0F;
      double var6 = (double)Math.max(1, var2) / (double)652.0F;
      double var8 = (double)Math.max(1, var3) / (double)446.0F;
      double var10 = Math.max((double)1.0F, Math.min(var6, var8));
      return Math.min(var4, Math.min((double)3.0F, var10));
   }

   public static double lIlI(boolean var0, boolean var1) {
      if (var0 && !var1) {
         return 0.86;
      } else {
         return var1 && !var0 ? 0.58 : 0.73;
      }
   }

   public static <undefinedtype> lIll(boolean var0, boolean var1, boolean var2, boolean var3) {
      return new Record((var0 ? 1.0F : 0.0F) - (var1 ? 1.0F : 0.0F), (var2 ? 1.0F : 0.0F) - (var3 ? 1.0F : 0.0F)) {
         private final float I;
         private final float l;

         public {
            this.I = var1;
            this.l = var2;
         }

         public float I() {
            return this.I;
         }

         public float l() {
            return this.l;
         }
      };
   }

   public static double llII(double var0) {
      return IIIIl(var0, 0.85);
   }

   private static double llIl(double var0) {
      return Math.max((double)0.0F, Math.min((double)100.0F, var0));
   }

   public static double lllI(double var0) {
      double var2 = Double.isFinite(var0) ? Math.max((double)0.0F, var0) : (double)0.0F;
      double var4 = Math.min((double)1.0F, var2 / (double)30.0F);
      double var6 = var4 * var4 * ((double)3.0F - (double)2.0F * var4);
      return 0.14 + var6 * 0.86;
   }

   public static List<String> llll(String var0, String var1) {
      if (var0 != null && !var0.isBlank()) {
         String var2 = var1 != null && !var1.isBlank() ? var1 : lIlIII.Il(l[1]);
         String[] var3 = var0.split(var2);
         ArrayList var4 = new ArrayList();

         for(String var8 : var3) {
            if (var8 != null) {
               String var9 = var8.trim();
               if (!var9.isEmpty()) {
                  var4.add(var9);
               }
            }
         }

         return List.copyOf(var4);
      } else {
         return List.of();
      }
   }

   public static long IIIII(long var0, long var2, long var4) {
      return Math.max(var0, var2 + Math.max(0L, var4));
   }

   public static double IIIIl(double var0, double var2) {
      double var4 = Double.isFinite(var0) ? Math.max((double)0.0F, Math.min(var0, 0.1)) : (double)0.0F;
      double var6 = Double.isFinite(var2) ? Math.max((double)0.0F, Math.min(var2, (double)1.0F)) : 0.85;
      double var8 = (double)12.0F - var6 * (double)9.5F;
      return (double)1.0F - Math.exp(-var4 * var8);
   }

   public static double IIIlI(double var0, double var2, double var4) {
      double var6 = Double.isFinite(var0) ? var0 : (double)0.0F;
      double var8 = Double.isFinite(var2) ? var2 : (double)0.0F;
      double var10 = Double.isFinite(var4) ? Math.max((double)0.0F, var4) : (double)0.0F;
      return Math.max(var6 - var10, Math.min(var6 + var10, var8));
   }

   public static boolean IIIll(double var0, double var2) {
      return var0 < llIl(var2);
   }

   public static boolean IIlII(long var0, long var2) {
      return var0 < var2;
   }

   static {
      short var6 = 30821;
      String var7 = "\ue3d2榀䒒䁐\uf8f1\ud87c\ue38a蜐뒧䔹\u0bd3偓";
      char[] var8 = "硭硡".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            lII = var9;
            lIl = new Object[var9.length];
            int var2 = 439421422;
            byte[] var0 = "l\r\u001bÄg^\u0017ÂX§\u009a\bÆ\u0011\u0001s".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            Ill = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               Ill[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            l = new String[2];
            llI();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private IlIllIl() {
   }

   public static boolean IIlIl(double var0, double var2) {
      return Double.isFinite(var0) && var0 >= (double)0.0F && var0 <= lIl(var2);
   }

   private static int IIllI(int var0, int var1) {
      return Ill[var0 ^ 1705798090] ^ var1 ^ var0;
   }

   private static String IIlll(short var0, int var1, int var2) {
      int var3 = var2 ^ 2925;
      char[] var4 = lII[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])lIl[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         lIl[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 6160;
      int var9 = 0;

      do {
         int var10 = var4[var9] ^ '\ue86f';
         var10 -= 15596;
         var10 ^= 12516;
         var10 -= 4014;
         var10 += 63771;
         var10 ^= 7451;
         var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
