package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_3532;

@Environment(EnvType.CLIENT)
public final class IIIIlllll extends IIIIIIIlI {
   private final IIIllIIII I;
   private boolean l;
   private static final int II = 1;
   private class_1309 Il;
   private int lI;
   private boolean ll;
   private final IlIIIlIlI<<undefinedtype>> III;
   private int IIl;
   private final lIIIIl IlI;
   private final IIIllIIII Ill;
   private final lIIIIl lII;
   private static final String[] lIl;
   private static final Object[] llI;

   private boolean ll(class_310 var1, class_1309 var2) {
      if (var1.field_1724 != null && var1.field_1724.method_24828() && !var1.field_1724.method_6115()) {
         if (var2 == var1.field_1724) {
            return false;
         } else if ((Boolean)this.lII.III() && !(var2 instanceof class_1657)) {
            return false;
         } else if (!(Boolean)this.IlI.III()) {
            return true;
         } else {
            return var2 != null && this.IIll(var1.field_1724, var2);
         }
      } else {
         return false;
      }
   }

   public void IlI(class_310 var1, boolean var2) {
      if (var1 != null && var1.field_1690 != null && var1.field_1690.field_1903 != null) {
         lllI var3 = lllI.lll();
         if (var3 != null) {
            if (var2) {
               var3.IlI(this, var1, var1.field_1690.field_1903, true);
            } else {
               var3.IIIl(this, var1, var1.field_1690.field_1903);
            }
         } else {
            var1.field_1690.field_1903.method_23481(var2 || IllllIlI.IIIll(var1, var1.field_1690.field_1903));
         }

      }
   }

   public void lI() {
      this.IlI(class_310.method_1551(), false);
      this.llI();
   }

   public boolean lII(class_310 var1) {
      if (this.IIIIIlI() && var1 != null && var1.field_1724 != null && var1.field_1755 == null && var1.method_1569()) {
         if (this.IIl > 0) {
            --this.IIl;
         }

         boolean var2 = false;
         if (this.l) {
            class_1309 var3 = this.Il;
            this.IIII();
            if (this.IIl == 0 && this.ll(var1, var3) && Math.random() * (double)100.0F < (Double)this.I.III()) {
               this.IIl = ((Double)this.Ill.III()).intValue();
               if (this.III.III() == null.l) {
                  this.ll = true;
                  this.lI = 0;
                  var2 = true;
               } else {
                  this.ll = false;
                  this.lI = 1;
               }
            } else {
               this.ll = false;
               this.lI = 0;
            }
         }

         if (this.ll && !var2) {
            this.ll = false;
            this.lI = 1;
         }

         boolean var4 = this.lI > 0;
         if (this.lI > 0) {
            --this.lI;
         }

         return var4;
      } else {
         this.IlI(var1, false);
         this.llI();
         return false;
      }
   }

   private void llI() {
      this.lI = 0;
      this.ll = false;
      this.IIl = 0;
      this.IIII();
   }

   public void lll(class_1282 var1) {
      if (this.IIIIIlI()) {
         class_1297 var2 = var1 == null ? null : var1.method_5529();
         class_1309 var10001;
         if (var2 instanceof class_1309) {
            class_1309 var3 = (class_1309)var2;
            var10001 = var3;
         } else {
            var10001 = null;
         }

         this.Il = var10001;
         this.l = true;
      }
   }

   private void IIII() {
      this.l = false;
      this.Il = null;
   }

   public IIIIlllll() {
      super((Object)lIlIII.l(IlII(1929332687, -424334003)), lIllII.III, (Object)lIlIII.l(IlII(1929332686, -566596266)));
      this.III = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IlII(1929332685, 1702364546)), <undefinedtype>.class, null.I));
      this.lII = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IlII(1929332684, -479107354)), true));
      this.IlI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IlII(1929332683, 1487174090)), true));
      this.I = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IlII(1929332682, -1058601653)), (double)100.0F, (double)0.0F, (double)100.0F, (double)1.0F)).IIIl(lIlIII.l(IlII(1929332681, 1530213819))));
      this.Ill = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IlII(1929332680, -441826971)), (double)10.0F, (double)0.0F, (double)20.0F, (double)1.0F)).IIIl(lIlIII.l(IlII(1929332679, -699844073))));
   }

   private boolean IIll(class_1657 var1, class_1309 var2) {
      double var3 = var2.method_23317() - var1.method_23317();
      double var5 = var2.method_23321() - var1.method_23321();
      if (var3 * var3 + var5 * var5 < 1.0E-6) {
         return true;
      } else {
         float var7 = (float)(Math.toDegrees(Math.atan2(var5, var3)) - (double)90.0F);
         return Math.abs(class_3532.method_15393(var7 - var1.method_36454())) <= 90.0F;
      }
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (var1 == null || var1.field_1724 == null || var1.field_1755 != null || !var1.method_1569()) {
         this.IlI(var1, false);
         this.llI();
      }

   }

   static {
      short var0 = 19835;
      String var1 = "\udd8f\udd07\udd9c\uddd1\udd34\udd76\udde4\udd9b\udd09\udda1\udd37\udda0\uddae\udd88\udd62\uddbc\ue507\ue5bd\ue564\ue545\ue5bd\ue5ed\ue532\ue52f\ue582\ue53d\ue5fe\ue539\ue53a\ue50f\ue5bc\ue56d\ue54b\ue52a\ue501\ue521\ue5cc\ue5df\ue5c9\ue528\ue59b\ue56d\ue513\ue55e\ue578\ue50f\ue5c9\ue51b\ue514\ue590\ue530\ue557\ue586\ue5fd\ue571\ue519\ue5e3\ue525\ue5b8\ue529\ue504\ue503\ue5e3\ue56d\ue54f\ue523\ue531\ue521\ue5e4\ue5a1\ue584\ue521\ue5b0\ue565\ue544\ue522幅廿幣帗廾庬幸帇\ud849\ud8e6\ud876\ud819\ud8f2\ud8a6\ud834\ud875\ud8ca\ud805\ud8a1\ud803\ud860\ud87d\ud8d5\ud804掙捌掻揃挧捷揵掴挛掳挦掇掵推挩揊揓掴掩掖捓振挜掹ﯛ\ufb0fﯰﮏﭧ\ufb0aﮪﯶ恏悹恧怶\ude96\ude42\udeb1\udef6\ude2a\ude6d\udea6\udeb1\ude12\ude97\ude4a\uded1\ued6a\uedde\ued17\ued2f\uedce\uedbb\ued1b\ued36";
      char[] var2 = "䵫䵇䵳䵫䵣䵳䵿䵷䵳".toCharArray();
      String[] var3 = new String[var2.length];
      byte var7 = -1;

      while(true) {
         int var4 = 0;
         int var5 = 0;
         int var6 = 0;
         if (var7 == 0) {
            lIl = var3;
            llI = new Object[var3.length];
            return;
         }

         do {
            var6 = var2[var4] ^ var0;
            var3[var4] = var1.substring(var5, var5 + var6);
            var5 += var6;
            ++var4;
         } while(var4 < var2.length);

         var7 = 0;
      }
   }

   private static String IlII(int var0, int var1) {
      int var3 = var0 ^ 1929332687;
      char[] var4 = lIl[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])llI[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         llI[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 1216772204;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 7;
               break;
            case 1:
               var9 = 147;
               break;
            case 2:
               var9 = 33;
               break;
            case 3:
               var9 = 112;
               break;
            case 4:
               var9 = 165;
               break;
            case 5:
               var9 = 203;
               break;
            case 6:
               var9 = 115;
               break;
            case 7:
               var9 = 12;
               break;
            case 8:
               var9 = 164;
               break;
            case 9:
               var9 = 11;
               break;
            case 10:
               var9 = 231;
               break;
            case 11:
               var9 = 8;
               break;
            case 12:
               var9 = 29;
               break;
            case 13:
               var9 = 50;
               break;
            case 14:
               var9 = 164;
               break;
            case 15:
               var9 = 122;
               break;
            case 16:
               var9 = 126;
               break;
            case 17:
               var9 = 103;
               break;
            case 18:
               var9 = 15;
               break;
            case 19:
               var9 = 49;
               break;
            case 20:
               var9 = 212;
               break;
            case 21:
               var9 = 159;
               break;
            case 22:
               var9 = 196;
               break;
            case 23:
               var9 = 18;
               break;
            case 24:
               var9 = 169;
               break;
            case 25:
               var9 = 83;
               break;
            case 26:
               var9 = 83;
               break;
            case 27:
               var9 = 107;
               break;
            case 28:
               var9 = 74;
               break;
            case 29:
               var9 = 74;
               break;
            case 30:
               var9 = 248;
               break;
            case 31:
               var9 = 37;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
