package x;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Stream;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1842;
import net.minecraft.class_1844;
import net.minecraft.class_2815;
import net.minecraft.class_2848;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_490;
import net.minecraft.class_6880;
import net.minecraft.class_746;
import net.minecraft.class_7923;
import net.minecraft.class_9334;
import net.minecraft.class_2848.class_2849;

@Environment(EnvType.CLIENT)
public final class llIIIlII extends IIIIIIIlI {
   private boolean I;
   private static final int l = 40;
   private static final String II;
   private final llllIlIl Il;
   private static String[] lI;
   private boolean ll;
   private static final int[] III;
   private List<<undefinedtype>> IIl;
   private final lIIIIl IlI;
   private static final int Ill = 36;
   private long lII;
   private boolean lIl;
   private <undefinedtype> llI;
   private final Map<String, Boolean> lll;
   private String IIII;
   private long IIIl;
   private static final int IIlI = 9;
   private static final Gson IIll;
   private static final long IlII = 3000L;
   private String IlIl;
   private long IllI;
   private boolean Illl;
   private final IlIIIlIlI<<undefinedtype>> lIII;
   public static final String lIIl;
   private static final int[] lIlI;
   private static final String[] lIll;
   private static final Object[] llII;

   public Map<String, Object> l(String var1, class_3675.class_306 var2) {
      return this.IIIllI(var1, IllllIlI.IllllI(var2) ? null : var2.method_1441());
   }

   private void II(class_310 var1) {
      String var10001 = lIlIII.Il(lI[IIlIIl(1460917915, 1213692730)]);
      String var3 = this.lllll(this.llI);
      String var2 = var10001;
      this.IlIl = var2 + var3;
      this.Illl = false;
      this.llI = null;
      this.IIII = lI[1];
      this.ll = false;
      if ((Boolean)this.IlI.III()) {
         this.lIll(var1);
      } else {
         this.I = false;
         this.lIl = false;
      }

   }

   private <undefinedtype> ll(class_746 var1, Object var2) {
      if (var2 != null && var2.Il != null && !var2.Il.isEmpty()) {
         Map var3 = this.llIIl(var2);

         for(<undefinedtype> var5 : var2.Il) {
            if (var5 != null && this.lIII(var5.Il) && var5.lI != null) {
               class_1799 var6 = this.IlIII(var1, var5.Il);
               if (!this.IlII(var6, var5)) {
                  int var7 = this.IIIlIl(var1, var3, var5);
                  if (var7 >= 0) {
                     return (<undefinedtype>)(new Object(var7, var5.Il) {
                        private final int I;
                        private final int l;

                        private {
                           this.I = var1;
                           this.l = var2;
                        }
                     });
                  }
               }
            }
         }

         return null;
      } else {
         return null;
      }
   }

   public Map<String, Object> III(String var1) {
      class_310 var2 = class_310.method_1551();
      if (!this.llI(var2)) {
         throw new IllegalStateException(lIlIII.Il(lI[IIlIIl(1460917914, 986528182)]));
      } else {
         <undefinedtype> var3 = this.IlIll(var2.field_1724, var1);
         this.IIlIII(var3);
         this.IIlI();
         return this.IIIlll();
      }
   }

   private String lII(String var1) {
      String var2 = this.lIlII(var1).toLowerCase(Locale.ROOT).replaceAll(lIlIII.Il(lI[IIlIIl(1460917913, -1578003830)]), lIlIII.Il(lI[IIlIIl(1460917912, -1024589902)])).replaceAll(lIlIII.Il(lI[IIlIIl(1460917919, -961456267)]), lI[1]);
      if (var2.isBlank()) {
         var2 = lIlIII.Il(lI[IIlIIl(1460917918, -172554290)]);
      }

      String var10001 = lIlIII.Il(lI[IIlIIl(1460917917, 2023798341)]);
      String var8 = Long.toString(System.currentTimeMillis(), IIlIIl(1460917916, 1607858138));
      String var7 = var10001;
      String var3 = var2 + var7 + var8;
      String var4 = var3;

      int var9;
      for(int var5 = 2; this.lIIIl(var4) != null && Files.exists(this.lIIIl(var4), new LinkOption[0]); var4 = var3 + var8 + var9) {
         var10001 = lIlIII.Il(lI[IIlIIl(1460917907, 409311925)]);
         var9 = var5++;
         var8 = var10001;
      }

      return var4;
   }

   private boolean llI(class_310 var1) {
      return var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var1.field_1724.field_7498 != null;
   }

   private Path lll() {
      lIllIIl var1 = lIllIIl.Il();
      return var1 != null && var1.lI() != null ? var1.lI().lllII() : null;
   }

   private boolean IIII(class_1799 var1, int var2, Map<Integer, <undefinedtype>> var3) {
      <undefinedtype> var4 = (<undefinedtype>)var3.get(var2);
      return var4 != null && this.IlII(var1, var4);
   }

   private static int[] IIIl() {
      int var0 = IIlIIl(1460917906, 214412455);
      int[] var1 = new int[var0];
      int var2 = 0;

      for(int var3 = IIlIIl(1460917905, 1316032855); var3 < IIlIIl(1460917904, -664036050); var1[var2++] = var3++) {
      }

      for(int var4 = 0; var4 < IIlIIl(1460917911, -362492851); ++var4) {
         var1[var2++] = IIlIIl(1460917910, -823499646) + var4;
      }

      var1[var2] = IIlIIl(1460917909, 1654922924);
      return var1;
   }

   private void IIlI() {
      this.IIl = this.IlIIl();
      this.IllI = System.currentTimeMillis();
   }

   public Map<String, Object> IIll(String var1) {
      <undefinedtype> var2 = this.Illl(this.IIIIl(var1));
      if (var2 == null) {
         throw new IllegalArgumentException(lIlIII.Il(lI[IIlIIl(1460917908, 2138715959)]));
      } else if (!this.IIIIIlI()) {
         String var10002 = lIlIII.Il(lI[IIlIIl(1460917899, 312186031)]);
         String var10003 = lIIl;
         String var8 = lIlIII.Il(lI[IIlIIl(1460917898, 315977417)]);
         String var7 = var10003;
         String var4 = var10002;
         throw new IllegalStateException(var4 + var7 + var8);
      } else {
         this.llI = var2;
         this.IIII = var2.l == null ? lI[1] : var2.l;
         this.Illl = true;
         this.I = false;
         this.lIl = false;
         class_310 var3 = class_310.method_1551();
         this.ll = var3 != null && var3.field_1755 instanceof class_490;
         this.IIIl = 0L;
         this.lII = 0L;
         String var10001 = lIlIII.Il(lI[IIlIIl(1460917897, -333793837)]);
         String var6 = this.lllll(var2);
         String var5 = var10001;
         this.IlIl = var5 + var6;
         return this.IIIlll();
      }
   }

   private boolean IlII(class_1799 var1, Object var2) {
      if (var2 != null && this.lllI(var1, var2.lI)) {
         return var2.I != null && !var2.I.isBlank() ? var2.I.equals(this.lIlIl(var1)) : true;
      } else {
         return false;
      }
   }

   private <undefinedtype> IlIl(Path var1) {
      try {
         <undefinedtype> var2 = (<undefinedtype>)IIll.fromJson(Files.readString(var1), <undefinedtype>.class);
         if (var2 != null && var2.l != null) {
            if (var2.Il == null) {
               var2.Il = new ArrayList();
            }

            return var2;
         } else {
            return null;
         }
      } catch (Exception var3) {
         return null;
      }
   }

   private <undefinedtype> Illl(String var1) {
      if (var1 != null && !var1.isBlank()) {
         Path var2 = this.lIIIl(var1);
         return var2 != null && Files.exists(var2, new LinkOption[0]) ? this.IlIl(var2) : null;
      } else {
         return null;
      }
   }

   private boolean lIII(int var1) {
      return var1 >= IIlIIl(1460917896, 890430156) && var1 < IIlIIl(1460917903, -1193382963) || var1 >= IIlIIl(1460917902, -1843522180) && var1 < IIlIIl(1460917901, 408377026) || var1 == IIlIIl(1460917900, -1864547544);
   }

   public Map<String, Object> lIIl() {
      return this.IIIlll();
   }

   private void lIll(class_310 var1) {
      if (this.lIl) {
         if (var1 != null && var1.method_1562() != null && var1.field_1724 != null) {
            var1.method_1562().method_52787(new class_2815(var1.field_1724.field_7498.field_7763));
         }

         this.lIl = false;
      }

      if (this.I) {
         if (var1 != null && var1.field_1755 instanceof class_490) {
            var1.method_1507((class_437)null);
         }

         this.I = false;
      }
   }

   private static String llII(char[] var0, long var1, int var3) {
      int var4 = IIlIIl(1460917891, 830235287) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IIlIIl(1460917890, 480410116);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private boolean lllI(class_1799 var1, String var2) {
      return !var1.method_7960() && var2 != null && var2.equals(this.IlllI(var1));
   }

   private String IIIIl(String var1) {
      return var1 == null ? lI[1] : var1.replaceAll(lIlIII.Il(lI[0]), lI[1]);
   }

   private void IIIll(class_310 var1, class_746 var2, int var3, int var4) {
      int var5 = var2.field_7498.field_7763;
      if (var3 == IIlIIl(1460917889, -1771123906)) {
         var1.field_1761.method_2906(var5, var4, IIlIIl(1460917888, 533074677), class_1713.field_7791, var2);
      } else if (var4 == IIlIIl(1460917895, 1921637452)) {
         var1.field_1761.method_2906(var5, var3, IIlIIl(1460917894, -1172617140), class_1713.field_7791, var2);
      } else {
         var1.field_1761.method_2906(var5, var3, 0, class_1713.field_7790, var2);
         var1.field_1761.method_2906(var5, var4, 0, class_1713.field_7790, var2);
         if (!var2.field_7498.method_34255().method_7960()) {
            var1.field_1761.method_2906(var5, var3, 0, class_1713.field_7790, var2);
         }

      }
   }

   private String IIlII(Object var1) {
      class_3675.class_306 var2 = this.llIlI(var1);
      return IllllIlI.IllllI(var2) ? lI[1] : IllllIlI.IIIlIl(var2);
   }

   private int IIlIl(class_746 var1, Object var2) {
      if (var1 != null && var2 != null && var2.Il != null) {
         int var3 = 0;
         Map var4 = this.llIIl(var2);

         for(<undefinedtype> var6 : var2.Il) {
            if (var6 != null && this.lIII(var6.Il) && var6.lI != null && !this.IlII(this.IlIII(var1, var6.Il), var6) && this.IIIlIl(var1, var4, var6) >= 0) {
               ++var3;
            }
         }

         return var3;
      } else {
         return 0;
      }
   }

   private boolean IIllI(class_310 var1) {
      if (var1 == null) {
         return false;
      } else if (var1.field_1755 instanceof class_490) {
         return true;
      } else {
         return this.lIl && this.lIII.III() == null.lI && var1.field_1755 == null;
      }
   }

   private Map<String, Object> IIlll() {
      LinkedHashMap var1 = new LinkedHashMap();
      var1.put(lIlIII.Il(lI[IIlIIl(1460917893, -1515681746)]), this.Illl);
      var1.put(lIlIII.Il(lI[IIlIIl(1460917892, 1646541127)]), this.IIII);
      var1.put(lIlIII.Il(lI[IIlIIl(1460917947, 414763432)]), this.IlIl);
      class_310 var2 = class_310.method_1551();
      int var3 = this.Illl && var2 != null && var2.field_1724 != null ? this.IIlIl(var2.field_1724, this.llI) : 0;
      var1.put(lIlIII.Il(lI[IIlIIl(1460917946, 1960547378)]), var3);
      return var1;
   }

   private class_1799 IlIII(class_746 var1, int var2) {
      return var1 != null && var2 >= 0 && var2 < var1.field_7498.field_7761.size() ? ((class_1735)var1.field_7498.field_7761.get(var2)).method_7677() : class_1799.field_8037;
   }

   private List<<undefinedtype>> IlIIl() {
      Path var1 = this.lll();
      if (var1 != null && Files.isDirectory(var1, new LinkOption[0])) {
         ArrayList var2 = new ArrayList();

         try {
            Stream var3 = Files.list(var1);

            try {
               Stream var10000 = var3.filter((var0) -> var0.getFileName().toString().endsWith(lIlIII.Il(lI[3]))).map((var1x) -> this.IlIl(var1x)).filter((var0) -> var0 != null && var0.l != null && var0.Il != null);
               Objects.requireNonNull(var2);
               var10000.forEach(var2::add);
            } catch (Throwable var7) {
               if (var3 != null) {
                  try {
                     var3.close();
                  } catch (Throwable var6) {
                     var7.addSuppressed(var6);
                  }
               }

               throw var7;
            }

            if (var3 != null) {
               var3.close();
            }
         } catch (IOException var8) {
         }

         var2.sort(Comparator.comparingLong((var0) -> var0.ll).reversed().thenComparing((var1x) -> this.lllll(var1x), String.CASE_INSENSITIVE_ORDER));
         return var2;
      } else {
         return List.of();
      }
   }

   public int IlIlI() {
      return IIlIIl(1460917945, -740135090);
   }

   private <undefinedtype> IlIll(class_746 var1, String var2) {
      String var3 = this.lIlII(var2);
      if (var3.isBlank()) {
         String var10000 = lIlIII.Il(lI[IIlIIl(1460917944, -1831726585)]);
         int var12 = this.IlIIl().size() + 1;
         String var11 = var10000;
         var3 = var11 + var12;
      }

      Object var4 = new Object() {
         private String I;
         private String l;
         private String II;
         private List<<undefinedtype>> Il = new ArrayList();
         private int lI;
         private long ll;
      };
      ((<undefinedtype>)var4).lI = 1;
      ((<undefinedtype>)var4).I = var3;
      ((<undefinedtype>)var4).l = this.lII(var3);
      ((<undefinedtype>)var4).ll = System.currentTimeMillis();
      ((<undefinedtype>)var4).Il = new ArrayList();

      for(int var8 : III) {
         class_1799 var9 = this.IlIII(var1, var8);
         if (!var9.method_7960()) {
            Object var10 = new Object() {
               private String I;
               private String l;
               private int II;
               private int Il;
               private String lI;
               private String ll;
               private int III;
            };
            ((<undefinedtype>)var10).l = this.llIll(var8);
            ((<undefinedtype>)var10).II = this.lllII(var8);
            ((<undefinedtype>)var10).Il = var8;
            ((<undefinedtype>)var10).lI = this.IlllI(var9);
            ((<undefinedtype>)var10).I = this.lIlIl(var9);
            ((<undefinedtype>)var10).ll = var9.method_7964().getString();
            ((<undefinedtype>)var10).III = var9.method_7947();
            ((<undefinedtype>)var4).Il.add(var10);
         }
      }

      return (<undefinedtype>)var4;
   }

   private Map<String, Object> IllII(Object var1) {
      LinkedHashMap var2 = new LinkedHashMap();
      var2.put(lIlIII.Il(lI[IIlIIl(1460917951, -370758230)]), var1.l);
      var2.put(lIlIII.Il(lI[IIlIIl(1460917950, -868573282)]), this.lllll(var1));
      var2.put(lIlIII.Il(lI[IIlIIl(1460917949, -324944602)]), var1.ll);
      var2.put(lIlIII.Il(lI[IIlIIl(1460917948, -1569700983)]), var1.Il == null ? 0 : var1.Il.size());
      var2.put(lIlIII.Il(lI[IIlIIl(1460917939, 2039155068)]), var1.II == null ? lI[1] : var1.II);
      var2.put(lIlIII.Il(lI[IIlIIl(1460917938, -973694413)]), this.IIlII(var1));
      var2.put(lIlIII.Il(lI[IIlIIl(1460917937, -1021389620)]), this.lIlll(var1));
      ArrayList var3 = new ArrayList();
      if (var1.Il != null) {
         for(<undefinedtype> var5 : var1.Il) {
            if (var5 != null && this.lIII(var5.Il)) {
               var3.add(this.IIIIlI(var5));
            }
         }
      }

      var2.put(lIlIII.Il(lI[IIlIIl(1460917936, -958923460)]), var3);
      return var2;
   }

   public void Ill() {
      if (this.Illl) {
         class_310 var1 = class_310.method_1551();
         if (!this.llI(var1)) {
            this.IIIIll(var1, lIlIII.Il(lI[IIlIIl(1460917943, -1648480079)]));
         } else {
            class_746 var2 = var1.field_1724;
            if (!var2.field_7498.method_34255().method_7960()) {
               this.IIIIll(var1, lIlIII.Il(lI[IIlIIl(1460917942, 1791309622)]));
            } else if (!this.IIllI(var1)) {
               if (this.ll) {
                  this.IIIIll(var1, lIlIII.Il(lI[IIlIIl(1460917941, 2010277216)]));
               } else if (lIlIllll.III(var1)) {
                  this.lIIll(var1, var2);
                  lIlIllll.lll(var1);
               }
            } else {
               long var3 = System.currentTimeMillis();
               if (var3 - this.IIIl >= this.lII) {
                  <undefinedtype> var5 = this.ll(var2, this.llI);
                  if (var5 == null) {
                     this.II(var1);
                  } else if (lIlIllll.III(var1)) {
                     this.IIIll(var1, var2, var5.I, var5.l);
                     if (!var2.field_7498.method_34255().method_7960()) {
                        this.IIIIll(var1, lIlIII.Il(lI[IIlIIl(1460917940, 1254385159)]));
                     } else {
                        this.IIIl = var3;
                        this.lII = this.lIllI();
                        String var10001 = lIlIII.Il(lI[IIlIIl(1460917931, 1323754722)]);
                        String var7 = this.lllll(this.llI);
                        String var6 = var10001;
                        this.IlIl = var6 + var7;
                     }
                  }
               }
            }
         }
      }
   }

   private String IlllI(class_1799 var1) {
      return class_7923.field_41178.method_10221(var1.method_7909()).toString();
   }

   public void lI() {
      this.IIIIll(class_310.method_1551(), lIlIII.Il(lI[IIlIIl(1460917930, -1660149630)]));
      this.lll.clear();
   }

   private List<<undefinedtype>> lIIII() {
      if (this.IIl == null || System.currentTimeMillis() - this.IllI > 3000L) {
         this.IIlI();
      }

      return this.IIl;
   }

   private Path lIIIl(String var1) {
      Path var2 = this.lll();
      Path var10000;
      if (var2 == null) {
         var10000 = null;
      } else {
         String var4 = lIlIII.Il(lI[3]);
         var10000 = var2.resolve(var1 + var4);
      }

      return var10000;
   }

   public Map<String, Object> lIIlI(String var1) {
      String var2 = this.IIIIl(var1);
      if (var2.isBlank()) {
         throw new IllegalArgumentException(lIlIII.Il(lI[IIlIIl(1460917929, -1178091296)]));
      } else {
         Path var3 = this.lIIIl(var2);
         if (var3 != null && Files.exists(var3, new LinkOption[0])) {
            try {
               Files.deleteIfExists(var3);
            } catch (IOException var7) {
               String var10002 = lIlIII.Il(lI[IIlIIl(1460917935, -1410230703)]);
               String var6 = var7.getMessage();
               String var5 = var10002;
               throw new IllegalStateException(var5 + var6, var7);
            }

            if (var2.equals(this.IIII)) {
               this.IIIIll(class_310.method_1551(), lIlIII.Il(lI[IIlIIl(1460917934, 1837587770)]));
            }

            this.lll.remove(var2);
            this.IIlI();
            return this.IIIlll();
         } else {
            throw new IllegalArgumentException(lIlIII.Il(lI[IIlIIl(1460917928, 358903585)]));
         }
      }
   }

   private void lIIll(class_310 var1, class_746 var2) {
      if (this.lIII.III() == null.lI && var1.field_1755 == null && var1.method_1562() != null) {
         var1.method_1562().method_52787(new class_2848(var2, class_2849.field_12988));
         this.lIl = true;
         this.ll = true;
      } else {
         var1.method_1507(new class_490(var2));
         this.I = true;
         this.ll = true;
      }
   }

   private String lIlII(String var1) {
      return var1 == null ? lI[1] : var1.replaceAll(lIlIII.Il(lI[IIlIIl(1460917933, 637685614)]), lI[1]).trim();
   }

   private String lIlIl(class_1799 var1) {
      if (var1 != null && !var1.method_7960()) {
         class_1844 var2 = (class_1844)var1.method_58694(class_9334.field_49651);
         if (var2 == null) {
            return null;
         } else {
            StringBuilder var3 = new StringBuilder();
            if (var2.comp_2378().isPresent()) {
               class_2960 var4 = class_7923.field_41179.method_10221((class_1842)((class_6880)var2.comp_2378().get()).comp_349());
               var3.append(var4 == null ? lIlIII.Il(lI[2]) : var4.toString());
            }

            ArrayList var8 = new ArrayList();

            for(class_1293 var6 : var2.comp_2380()) {
               var8.add(var6);
            }

            if (!var8.isEmpty()) {
               var8.sort(Comparator.comparing((var0) -> {
                  class_2960 var1 = class_7923.field_41174.method_10221((class_1291)var0.method_5579().comp_349());
                  return var1 == null ? lI[1] : var1.toString();
               }));
               var3.append((char)IIlIIl(1460917932, 1178531629));

               for(int var9 = 0; var9 < var8.size(); ++var9) {
                  class_1293 var10 = (class_1293)var8.get(var9);
                  class_2960 var7 = class_7923.field_41174.method_10221((class_1291)var10.method_5579().comp_349());
                  if (var9 > 0) {
                     var3.append((char)IIlIIl(1460917923, -548866855));
                  }

                  var3.append(var7 == null ? lIlIII.Il(lI[2]) : var7.toString()).append((char)IIlIIl(1460917922, 471553947)).append(var10.method_5578()).append((char)IIlIIl(1460917921, 1400112595)).append(var10.method_5584());
               }
            }

            if (var2.comp_2379().isPresent()) {
               var3.append((char)IIlIIl(1460917920, 813175646)).append((Integer)var2.comp_2379().get());
            }

            return var3.length() == 0 ? null : var3.toString();
         }
      } else {
         return null;
      }
   }

   private long lIllI() {
      double var1 = this.Il.IlII();
      double var3 = this.Il.IlI();
      return var1 == var3 ? Math.round(var1) : Math.round(ThreadLocalRandom.current().nextDouble(var1, var3));
   }

   private Map<String, Object> lIlll(Object var1) {
      class_3675.class_306 var2 = this.llIlI(var1);
      boolean var3 = IllllIlI.IllllI(var2);
      LinkedHashMap var4 = new LinkedHashMap();
      var4.put(lIlIII.Il(lI[IIlIIl(1460917927, 1131617199)]), var3);
      var4.put(lIlIII.Il(lI[IIlIIl(1460917926, -1187390350)]), var3 ? lI[1] : IllllIlI.IIIlIl(var2));
      var4.put(lIlIII.Il(lI[IIlIIl(1460917925, 1408218262)]), var3 ? lI[1] : var2.method_1441());
      var4.put(lIlIII.Il(lI[IIlIIl(1460917924, -1053330826)]), var3 ? lIlIII.Il(lI[IIlIIl(1460917979, 1905846645)]) : var2.method_1442().name().toLowerCase(Locale.ROOT));
      var4.put(lIlIII.Il(lI[IIlIIl(1460917978, 1988785790)]), var3 ? -1 : var2.method_1444());
      return var4;
   }

   public String llIII() {
      return this.IlIl;
   }

   static {
      short var6 = 152;
      String var7 = "\uefd2⨿ế⠭′\udaa6㻈áब∃蹔꽃揮討ᜳ厓품빀쇤촽殲娸⑥灜틆魘軓쩦劾矀庘럓堧츿䰸湌嗏ᓒ셃Ḓࣶ普쑧봹鶛泭\udc8e辛\ueeaf염趝\ud97f뒽⠶ \u2dd7ﲻᄣ♂鷦⦏\u0ef8ಠ箃鸦뢅뵤踩氶갂埞親羍铍ꕎ⯶맘撬蹵퉌Ī⒋\ue224颅关赆䖣\u31e4\u1bfb\ue27b\udeb6䇩뺮輇ᕳꄖ栮\ud822ꁗ緥ᒌ\ud9ed䉱駗뚁\udc1fూ들᎔㰝\uf8a6픓䪤䯥蘀\uddf5鱾⁾뱥琡ঢ骽껎\ue297\udf15뿡싚୦셓脝顏㽉⚒费킘\uefed鑖\ud9a5㚏騢즌善퓨摞膊ꐔᙯᠳ靋䏺䘶㥿㇐\uef9d㊗꒷ṯ菵꺦耛㉎\u0a7cっ篐缎\ue7ef撐Ԥ壺ﲖ흨轼弪\u0bc9၌鼬㭵䕨ᅢ쥺社焝랝倫徔ꪕ◧闉變Ϯ튈穉ќ5죤ࠧ퓯䏞䞑嗔鴒ㅨ₄搻抪郈\uaacc煬㘹\udddf⼄남\uf467뭘圛妒\uf1c0殄퀾胃莨撚兠\ue165歐兛녙럙봁휴껞Ⲇ诉ﵰ컌䄿賔⩷\udf1a묧䛨캰\uddb8䅧韨\uf825⒫옹䋉㉮\udb93敳粢偿ŵ蚪\ue7c2붖뛙緵䫙\uf712흔瑞̖ᵺ\u1af8礢鞅烕⬓뼻꠨뼍릶傀䡣\uf46a⟗\ud868织勵鸎䮑᙮䛃垙育핬㋊룆꠬숣睘廁鶅⸵뤊Ἔꦲ㯘饱\uf797ⷄ鍺ᶙꁛ⍓\ue6a8뿞᭫馛\uefb2놗毃씞\u1ae2⩡䜥譃\u008f䆙朁\udcf1捲ﰚ擫\ue478ḗ\uf546뚦礎\uf866◼㜠弨\ud81b紙\u0df9饁鉐蹘祉ȉ耋⪌庺幹ꥋ適당肢㰣냫羓ꡙ蔜ท\udc92곇င宗童罌㥟இꖁ\ue21dק㝟摦\uebf1徦详狃ࡤ式ċ텬义㠌䲚轷\uf694ⓦ䳓칏欒뒹杭㣱⎿籝辉\u10caꖬ\ue620糩餑ཨꄳ\uf3f3vﲧ栘\ue4b1遞䏫鳪퓵﨎ⵂϵ読⨱㥬鐩\ueee2짽퐁룮빼㎢饵硌変괧蒆鰁炦\ue202潫蛘\uee34潄髒搫㙤韃ቚ坽护鿢ᜦ釻搾櫛伒腡艫剱艿ᰟ쁭䳮䝠帶\uea03趲Ѻ൵赖蜳嘮࿗➺悏ㆯ껮뜒Ȑ屽抄㎋혮矨젛鬷菂췜镄䒉Ꙝ鹋夰젙ﭒ\ud9b2쩫\ue1ae垣꛳ࢯߊꁥℑ❊贪\uf1e2⦟轹ꥺ\ue4fa솇圣齉ᦴ흈ꁀቄリ䦭䳜峨☚ᶢ띮靕퇸ᩅ\uf064⏌뱌ꬼ系錪揜淁增\ua82eⅉ龑瞆̳痺祃\uf876ᘯ㻰㭻\u1f58☤氈\uea01葲衽ꚻ箮琸抙㲸澿ⲻ\ue5f4꽌ᱨퟞؤ늳፩溪ͺ\ue0e7\ue132\udd4d编渁ꛕ죺뫁慅ꘇ鱑뻽뼏䥨\ud8c3❟\uf5a7䦡\u2e79ꉻＳ\ud9a9捕㽧饼䞩썰\uf825ꢐ￢蒛檇够䒝ꬉ渿䲄騂揞\ue17eⒾⅷ蝫돝긙姥詴䉚놄뚲죈樌㵒\uf0fc죟\ud9ee惁蛉\uf2bdᱚꥦ뺿飯䅂쬆㧞㥚鹺喋㭢❕濇蓘ꢪ\udc4a尿趪尿√\ue8dcҟ骶巹ꭈ\u0b58쥃⁂ﺼ\ue9bcધ\uea45컳⾍佹羄Ꮋꢼ⺡䷁鰩尘뫖쯯몭᠌\ue3c8採德ਜተ씑ബ썴ߟ煺㟭᙮Ȍꆜˈᖆ鯜ꧻ\uf79c⬐爩\ufae2ﭢ殿쓓펻\uef96悒簟岜啞칪侢榢최줾摾㳙ꖩ僈뉽ⁿ䤡멇궱慝檽뫖砗蒥槗⍫洆\uf52e䩬姸엍뼭㝴ꚏ庲Ѽ綫䭛瓍⺙ﾸ\uebda뾔\uddceⲫ榫\uf788앙떒⋾ℳ접⭾壶뱝깁콺\uffef㬆ﭴ\uedee\uf7ddﰑ穜\uea97贐랳\uf75c\ue9ba落疷瘾罆\ue8c0\uda41崞ஶ᪄盔雧⋰摢㨊쎞䮶ꫧ戼砪䭿햚ਸ⫨ᖃ＄旾ၪ\udde4\ud8ab小꿕₀㌼\uea99猫㩖隆忭\uf3a7\u0a61溂⭏鵅꼖㘁쒧ႁ㭢㝱ܷﰕ髾湻䃠\ufdee⎸컵郓爮\ua95e\uead1쎄창\ue77a咏꧃ᙠ졁⭮丿㽛\ue1b2셐猴蓉\u0de2깄怱\uefe6雷ᝰ魍\uf3c3쑵霊虆荍띧閰暕髱恵ק擨ᴳ鶩\ueb1b\u175cរ见孥Β洖㇀卋岬䭜\uf822ṅ閞坣Ṳ力ℒ㈯煁⺒ǲ⪐䈴\uef87\uf243ꧬ尟\ufb1b롙݆컝曢鴱\uedbeᣝ\u139e䩭礚쫾\ud9cb⿀ᅙ뱜\ue93d丁唙兣︺㬗무ݫઘ疅鞈饭랓\ue5af숵곁܅泉ᰆ\uf702맻흶ต\uda7e렳\ue6d0ꌎ\uf60e鉻⮁䊫鈕ﰆꎋ㥌驾敩実\ud86e鐵錜耭Ɫ蠎餱襔桘痶ீ\ue26c\ud8d5\ud876桰जഔၫ鈽銀쀺鮬\ue157ꢺ\udfed릭儏룆\u0ab1⢮㗔⾔⑈弩渐堗ྥ쵮끂\ue3cb씫듌\ue15b밡屣閪ࢬ쫭ទ釀ﶨ纚吻㼑ꊟ\u0ff3ꙙ㷨띡⓮諻䊼꾴급⟣ᖊῼ툋ꏺ粒䙕砠밚\udf62ଓ\uf5c7Ͼ㚥ᐶጰ\ue8e2嵮伿줢\ud875ᒄ纘פֿḌ୨톫茧⣯쀧⫓㝶\udb75峻滐\ud80d湦떯瘥솼\ueaca僇\u0ea4蔵沍ⷿ串酇鹕궭ჸ⫥ࡏ츶鴣쮽襏ꀂJ澈ܙ㔔\ud96a懜摈혀\uee96᷺ℷ鷮ﻓ\ue2acᖷ꼶㆜\ue3c5⌎菽萻Ẍ䨿쏖欸㭳㺃ༀ둕퉠眊\uef24꒧\uf283뺚⨢街簏흠\udcd3礘\ue356Ɀ嶏蝳휻欏햋䛔쇴豾恋觉깑닻伝騄鰗ᘃ줛眽︱酁餚沙閥\uf372ū\uef5cꇟ벌鬖\uf4b4ᵨﶊ尵돓⪒슃钎쓾졖";
      char[] var8 = "\u008c\u009c\u0090\u0090¸´\u0094\u0094\u0094\u008c\u0094\u0080\u0094\u009c\u0090\u0090\u008c\u0088\u009cÌ\u0094\u0094\u0094\u0090\u0090\u008c\u0090\u0094\u0090\u0094\u0090\u009c\u0094\u0094\u0090\u009c\u009c\u0090\u0088\u009c\u0080\u0094\u008c\u0094¸¬\u0094\u0094\u0094\u0090\u0090\u0088´\u0088\u0090\u0090\u009c\u008c\u0084\u0080¼\u008c\u0090\u0094\u0094\u0080´\u0080¼".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            lIll = var9;
            llII = new Object[var9.length];
            int var2 = 959911222;
            byte[] var0 = "&s¸¸Téú4ÏÕQ\u0000¬É<8¨\u0095\u0094û\u009b\u0093Ä@\u0016\u0084uÊ1ñ4TvAY4bão& UÒù¶O^¬\u0084@\u000få Î§\u0006\f\u0080Ý\"\u0011^ô¾|¿W>|ñ\u00adX\u0082>vF[6!{Öú¨Pü:Öàvs\u0095Tþù\u0080¿þPjMr\u0086¹OøJ\b¤qâÑk\u001c\u00ad\u001fÐÔ?\u008bÔË\u008cK\u0095\f\u0000úþv\u009c\n,\u001aÿW´½Æ§rüöÑ\u008e\u0087Ân\u0003¢\u001e\\5\u0082\u0085~±ÌT\u0080!\u0017¯Êä«ÒY©\u00ad:\u0017j¨ó>¥ó\u009aór\u0004áôó\u0019ö¦§$à¥Æ Â'Uó(ã\b×ã\u0003C{@¬\u0094ÅÕUõ\u0003£\u009e\u009cH&\u008cù(\u001a4Ë±l7`r?\u00945=PÆ~^\\Ðë-WØ)×\u001d\u001fû=Ëw\u001f¯\u0013±ÿ\u001f¼*\u008f\u0018®µ\u008aÃ½\bÈï{âèÍ\u0010½\u008aJÙA¾e²ëÄ»§\u001ca\u001b\u0001ER!\u0013vk\u0012\u009b]°#ÖñÅf!aaG\u0001z\u0010\u0015\t\u00adY\u0080^ì\u000eI\u0007\u0098XHz*ÖoÁZÄ~\u0012äñ¢æQ°(\u0006³µþ*Þ+ÿÇO?×ä}oPÞ\u008d#¶5«Uw\u0092~aV×\u00128q\u000fÌ^¦\u008c¶¥_2C^ ôt]0àé®Sk\u001c\u0019þj\u0017ÐÄÇ¬Z°½\u001b6ª·.Ôë>\u0007ÞÑÉ\u008d\u001b\u000e ÷¤a\"ÉÔ)÷ÈÖ\u00051b\u001c\u0082¶\u0001J\u0091$Ò0\u0012\u0016~\u00181ª#6Û·¡\u0095ÈÕèùÈSË\u007fPj}6\u009d-Ó)\u0092\u0088Æx*O^Ãº¹\u0085ã÷ý·Í\nä\u0098Î\u0015Üã]\u0085üÏÔ\u0098Ä&\b2¡o9m\bGû;\nÛ\u008cç\u0093à¤\u0092Thb'D||\u001bjÇ#)\u0084Æ,t\u0099:^¬G\u0083¹\u0094´\u008f¡¬\u0082f\u0086\u00ad\u008aåÑ4\u0014\u008aC#ÖW\u000fÒtø´2\u0019Q>î/Û\u0089`ºñÂ\u0099\u0083&\u0002xA n(oÇ;¥M\u0082¸P¡xËÇ\u001aá\u0081?*B\u0019\u009a4\u001f»\u00069_\u00135´Ó'gE×¬U\u00161\u008f\u0081\t«[Ç\u001c\u0098\b\u0004½60ú\u0010\u0006sq&\u0015'¼]ÎÛ*Å\u0015È\u0000¾m\u0018R\u008e0è\u001aÆ©]\u008d1µóæãÙØ2B\u0083\u0005\u0007½\u0015t¾ä\u0086\u001b]ÈáC\u009cðõ(«\u007fAhc©\u0018ù\u000b\u0011Ó,\u008f3\u001e\u001f>/\u0082¨kí\u0000z>\u007fÊ\u0096Z$\u001dÕù\u000eÙfPàm\u0002+\u007f÷y?\u008eGO\u0080jõ\u008bÍ\u0085\u008eTí=<\u009bÏ\u0091§\u0005w\u008b\u0097û\u009dwÚÜX¾5\u0080ÐkÒ\nî¢\u0083?BzÇÐà\u0000ÿº\u000f\u0015\u001c \u008bÕ  j¦\u008f\u001c×uÿõ\u00adG&\u0091có\u0019\u0001«¦àõ\u001b\u0096\u009e½\b¢Ñý\u0090¸{H(ÇÕ\u0003\u009c\u0003\u0005ùbÒ|\u009eN\u009b§HD\u007fb¬\u0003eìÐ\u001f+\u009cÇ¦õ¦jí]JêÛy(\u00843\u0098B\u00852\u00114\u009e®Ì¦\u0019\u0012õ\u0087¦\u0015\u0092¢\u0086#ÐÇ\u0089ü{1í?\u0099ÂÊà}õER\\\u007fÄ*Ú¹\nµ¢en5\u0084\u0018d\u009aâ\u009b0cäI\b\u008b\u007fÆ\u0015ð\u0002\u0019ü¹·}\u0080\"\u008a¿!{ç÷\r\u0007{}%\u009bÉñ%aNûÌzÂ\u0016Â\t\u0097\u009a\u0017".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lIlI = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lIlI[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            lI = new String[IIlIIl(1460917977, -1382429855)];
            llllI();
            lIIl = lIlIII.Il(lI[IIlIIl(1460917976, -2124472017)]);
            IIll = (new GsonBuilder()).setPrettyPrinting().create();
            II = lIlIII.Il(lI[IIlIIl(1460917983, -1556840885)]);
            III = IIIl();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 14;
                     break;
                  case 1:
                     var10000 = 122;
                     break;
                  case 2:
                     var10000 = 14;
                     break;
                  case 3:
                     var10000 = 66;
                     break;
                  case 4:
                     var10000 = 35;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private Map<Integer, <undefinedtype>> llIIl(Object var1) {
      HashMap var2 = new HashMap();
      if (var1 != null && var1.Il != null) {
         for(<undefinedtype> var4 : var1.Il) {
            if (var4 != null && this.lIII(var4.Il)) {
               var2.put(var4.Il, var4);
            }
         }

         return var2;
      } else {
         return var2;
      }
   }

   public void lIl() {
      if (!this.Illl) {
         this.IlIl = lIlIII.Il(lI[IIlIIl(1460917982, 620593734)]);
      }

      this.IIlI();
      this.lll.clear();
   }

   private class_3675.class_306 llIlI(Object var1) {
      if (var1 != null && var1.II != null && !var1.II.isBlank()) {
         try {
            return class_3675.method_15981(var1.II);
         } catch (Exception var3) {
            return class_3675.field_16237;
         }
      } else {
         return class_3675.field_16237;
      }
   }

   private String llIll(int var1) {
      if (var1 >= IIlIIl(1460917981, 194390027) && var1 < IIlIIl(1460917980, -712777818)) {
         return lIlIII.Il(lI[IIlIIl(1460917971, 1965393544)]);
      } else {
         return var1 == IIlIIl(1460917970, 1329051042) ? lIlIII.Il(lI[IIlIIl(1460917969, 2092932631)]) : lIlIII.Il(lI[IIlIIl(1460917968, 1307718242)]);
      }
   }

   private int lllII(int var1) {
      if (var1 >= IIlIIl(1460917975, 134587044) && var1 < IIlIIl(1460917974, 690338269)) {
         return var1 - IIlIIl(1460917973, 2066575006);
      } else {
         return var1 == IIlIIl(1460917972, -293982271) ? 0 : var1 - IIlIIl(1460917963, 656628652);
      }
   }

   public void lllIl(class_310 var1) {
      if (this.IIIIIlI() && var1 != null && var1.field_1724 != null) {
         if (var1.field_1755 == null || var1.field_1755 instanceof class_490) {
            for(<undefinedtype> var3 : this.lIIII()) {
               if (var3 != null && var3.l != null && var3.II != null && !var3.II.isBlank()) {
                  class_3675.class_306 var4;
                  try {
                     var4 = class_3675.method_15981(var3.II);
                  } catch (Exception var9) {
                     continue;
                  }

                  if (var4 != null && !var4.equals(class_3675.field_16237)) {
                     boolean var5 = IllllIlI.IlIII(var1, var4);
                     boolean var6 = (Boolean)this.lll.getOrDefault(var3.l, false);
                     this.lll.put(var3.l, var5);
                     if (var5 && !var6) {
                        try {
                           this.IIll(var3.l);
                        } catch (Exception var8) {
                        }
                     }
                  }
               }
            }

         }
      }
   }

   private static void llllI() {
      lI[0] = llII(IIlIlI(-196356710, 1306396012).toCharArray(), 35287L, IIlIIl(1460917962, 1081810780));
      lI[1] = llII("".toCharArray(), 98774L, IIlIIl(1460917961, -1301258778));
      lI[2] = llII(IIlIlI(-196356709, 1291586887).toCharArray(), 92553L, IIlIIl(1460917960, -134051078));
      lI[3] = llII(IIlIlI(-196356712, -1554827217).toCharArray(), 695L, IIlIIl(1460917967, -1392288608));
      lI[4] = llII(IIlIlI(-196356711, -1024257190).toCharArray(), 64064L, IIlIIl(1460917966, 1594305381));
      lI[5] = llII(IIlIlI(-196356706, 19795932).toCharArray(), 29116L, IIlIIl(1460917965, 686377994));
      lI[IIlIIl(1460917964, -1847358269)] = llII(IIlIlI(-196356705, 1466244097).toCharArray(), 74354L, IIlIIl(1460917955, 1591597272));
      lI[IIlIIl(1460917954, 1056591568)] = llII(IIlIlI(-196356708, 571366293).toCharArray(), 54103L, IIlIIl(1460917953, -1196890906));
      lI[IIlIIl(1460917952, 431406495)] = llII(IIlIlI(-196356707, -1727365582).toCharArray(), 58564L, IIlIIl(1460917959, -2051673851));
      lI[IIlIIl(1460917958, 522915751)] = llII(IIlIlI(-196356718, 632782292).toCharArray(), 50834L, IIlIIl(1460917957, -310544111));
      lI[IIlIIl(1460917956, 823558310)] = llII(IIlIlI(-196356717, -857463796).toCharArray(), 51912L, IIlIIl(1460918011, -533288669));
      lI[IIlIIl(1460918010, 1589914217)] = llII(IIlIlI(-196356720, -935121514).toCharArray(), 48279L, IIlIIl(1460918009, 2078593371));
      lI[IIlIIl(1460918008, -1873882094)] = llII(IIlIlI(-196356719, 1372482139).toCharArray(), 2440L, IIlIIl(1460918015, 2023453529));
      lI[IIlIIl(1460918014, -560342797)] = llII(IIlIlI(-196356714, -798269122).toCharArray(), 33218L, IIlIIl(1460918013, -1905334378));
      lI[IIlIIl(1460918012, -2061843430)] = llII(IIlIlI(-196356713, 1739675395).toCharArray(), 81000L, IIlIIl(1460918003, 1939857844));
      lI[IIlIIl(1460918002, 1619276911)] = llII(IIlIlI(-196356716, -22135755).toCharArray(), 30846L, IIlIIl(1460918001, 1439133250));
      lI[IIlIIl(1460918000, 1205013248)] = llII(IIlIlI(-196356715, -22059882).toCharArray(), 46927L, IIlIIl(1460918007, 1493265389));
      lI[IIlIIl(1460918006, -325926245)] = llII(IIlIlI(-196356726, -1957422143).toCharArray(), 57225L, IIlIIl(1460918005, 1762777031));
      lI[IIlIIl(1460918004, 2083700168)] = llII(IIlIlI(-196356725, 200096014).toCharArray(), 9493L, IIlIIl(1460917995, 1062277748));
      lI[IIlIIl(1460917994, -1248632230)] = llII(IIlIlI(-196356728, 493903835).toCharArray(), 27113L, IIlIIl(1460917993, 495983216));
      lI[IIlIIl(1460917992, -1502148427)] = llII(IIlIlI(-196356727, 848389935).toCharArray(), 478L, IIlIIl(1460917999, -863944748));
      lI[IIlIIl(1460917998, -217509660)] = llII(IIlIlI(-196356722, 1275225423).toCharArray(), 12519L, IIlIIl(1460917997, -2083662577));
      lI[IIlIIl(1460917996, 1147903247)] = llII(IIlIlI(-196356721, -396738803).toCharArray(), 14669L, IIlIIl(1460917987, 731633085));
      lI[IIlIIl(1460917986, -1713802226)] = llII(IIlIlI(-196356724, -1021310627).toCharArray(), 40235L, IIlIIl(1460917985, 1217690823));
      lI[IIlIIl(1460917984, 2079858835)] = llII(IIlIlI(-196356723, -1678562712).toCharArray(), 51274L, IIlIIl(1460917991, 421238697));
      lI[IIlIIl(1460917990, -153033279)] = llII(IIlIlI(-196356734, 798761875).toCharArray(), 27185L, IIlIIl(1460917989, -1055622197));
      lI[IIlIIl(1460917988, 53249075)] = llII(IIlIlI(-196356733, -943567409).toCharArray(), 74998L, IIlIIl(1460917787, 722029115));
      lI[IIlIIl(1460917786, -1984486509)] = llII(IIlIlI(-196356736, 2051435165).toCharArray(), 94595L, IIlIIl(1460917785, 1669734951));
      lI[IIlIIl(1460917784, 1231077198)] = llII(IIlIlI(-196356735, 1158768650).toCharArray(), 28045L, IIlIIl(1460917791, -1592724612));
      lI[IIlIIl(1460917790, 1201669401)] = llII(IIlIlI(-196356730, -1126298330).toCharArray(), 19104L, IIlIIl(1460917789, 587829303));
      lI[IIlIIl(1460917788, -1033682803)] = llII(IIlIlI(-196356729, 132072663).toCharArray(), 16097L, IIlIIl(1460917779, -1014590908));
      lI[IIlIIl(1460917778, -1029265987)] = llII(IIlIlI(-196356732, 811301358).toCharArray(), 98434L, IIlIIl(1460917777, 407751388));
      lI[IIlIIl(1460917776, 1513113925)] = llII(IIlIlI(-196356731, 816994533).toCharArray(), 68028L, IIlIIl(1460917783, -279955095));
      lI[IIlIIl(1460917782, -1135592523)] = llII(IIlIlI(-196356678, 1221006785).toCharArray(), 7188L, IIlIIl(1460917781, 1668987194));
      lI[IIlIIl(1460917780, -2146756471)] = llII(IIlIlI(-196356677, -1952682222).toCharArray(), 91925L, IIlIIl(1460917771, -493460882));
      lI[IIlIIl(1460917770, -139991779)] = llII(IIlIlI(-196356680, 659889058).toCharArray(), 51328L, IIlIIl(1460917769, 1588794181));
      lI[IIlIIl(1460917768, 1179321377)] = llII(IIlIlI(-196356679, -1710205788).toCharArray(), 93408L, IIlIIl(1460917775, 1179418279));
      lI[IIlIIl(1460917774, 1048951766)] = llII(IIlIlI(-196356674, -651293320).toCharArray(), 75728L, IIlIIl(1460917773, 1465759308));
      lI[IIlIIl(1460917772, 1359905029)] = llII(IIlIlI(-196356673, 1272058948).toCharArray(), 90096L, IIlIIl(1460917763, -711401602));
      lI[IIlIIl(1460917762, 1746770944)] = llII(IIlIlI(-196356676, -982248753).toCharArray(), 61711L, IIlIIl(1460917761, -1016668840));
      lI[IIlIIl(1460917760, 157357234)] = llII(IIlIlI(-196356675, -1038590471).toCharArray(), 48061L, IIlIIl(1460917767, 1587998235));
      lI[IIlIIl(1460917766, -282236862)] = llII(IIlIlI(-196356686, 776684139).toCharArray(), 18939L, IIlIIl(1460917765, 277412044));
      lI[IIlIIl(1460917764, 1788474664)] = llII(IIlIlI(-196356685, 1300128263).toCharArray(), 60809L, IIlIIl(1460917819, -1232281788));
      lI[IIlIIl(1460917818, 520279552)] = llII(IIlIlI(-196356688, 1475229235).toCharArray(), 91663L, IIlIIl(1460917817, -1717437770));
      lI[IIlIIl(1460917816, 1155651306)] = llII(IIlIlI(-196356687, 2128042736).toCharArray(), 4242L, IIlIIl(1460917823, 1973537867));
      lI[IIlIIl(1460917822, 1017836493)] = llII(IIlIlI(-196356682, 692663315).toCharArray(), 16606L, IIlIIl(1460917821, -1274485604));
      lI[IIlIIl(1460917820, -485132585)] = llII(IIlIlI(-196356681, -665583557).toCharArray(), 40781L, IIlIIl(1460917811, 952850975));
      lI[IIlIIl(1460917810, 1550204974)] = llII(IIlIlI(-196356684, -1330759390).toCharArray(), 93648L, IIlIIl(1460917809, 428639377));
      lI[IIlIIl(1460917808, -792705747)] = llII(IIlIlI(-196356683, 921000358).toCharArray(), 94997L, IIlIIl(1460917815, 1829885991));
      lI[IIlIIl(1460917814, -220973543)] = llII(IIlIlI(-196356694, -51695349).toCharArray(), 46188L, IIlIIl(1460917813, -1651047452));
      lI[IIlIIl(1460917812, 227400649)] = llII(IIlIlI(-196356693, 735998496).toCharArray(), 53455L, IIlIIl(1460917803, -308879082));
      lI[IIlIIl(1460917802, -518529744)] = llII(IIlIlI(-196356696, 58343867).toCharArray(), 37728L, IIlIIl(1460917801, -1655247261));
      lI[IIlIIl(1460917800, 97108816)] = llII(IIlIlI(-196356695, -38315435).toCharArray(), 59079L, IIlIIl(1460917807, -456319470));
      lI[IIlIIl(1460917806, 872472312)] = llII(IIlIlI(-196356690, -739757802).toCharArray(), 48793L, IIlIIl(1460917805, -703377581));
      lI[IIlIIl(1460917804, 1053077038)] = llII(IIlIlI(-196356689, -1369893827).toCharArray(), 2388L, IIlIIl(1460917795, 1561625133));
      lI[IIlIIl(1460917794, 1370129516)] = llII(IIlIlI(-196356692, 896865925).toCharArray(), 98418L, IIlIIl(1460917793, -458789397));
      lI[IIlIIl(1460917792, -1549709958)] = llII(IIlIlI(-196356691, -1121100990).toCharArray(), 46346L, IIlIIl(1460917799, -1167273621));
      lI[IIlIIl(1460917798, -1581947860)] = llII(IIlIlI(-196356702, -1996799220).toCharArray(), 59338L, IIlIIl(1460917797, 1853914258));
      lI[IIlIIl(1460917796, -212657676)] = llII(IIlIlI(-196356701, 1862937171).toCharArray(), 91319L, IIlIIl(1460917851, 2028538474));
      lI[IIlIIl(1460917850, -1102114467)] = llII(IIlIlI(-196356704, 410327075).toCharArray(), 45620L, IIlIIl(1460917849, 400074003));
      lI[IIlIIl(1460917848, 744359042)] = llII(IIlIlI(-196356703, -219008820).toCharArray(), 51713L, IIlIIl(1460917855, -446567627));
      lI[IIlIIl(1460917854, 1630658421)] = llII(IIlIlI(-196356698, 1373510301).toCharArray(), 93312L, IIlIIl(1460917853, -2018138685));
      lI[IIlIIl(1460917852, 75648072)] = llII(IIlIlI(-196356697, 1008022990).toCharArray(), 26655L, IIlIIl(1460917843, 346275836));
      lI[IIlIIl(1460917842, -1016863286)] = llII(IIlIlI(-196356700, 1179194648).toCharArray(), 89427L, IIlIIl(1460917841, 750357842));
      lI[IIlIIl(1460917840, -981326893)] = llII(IIlIlI(-196356699, 501304614).toCharArray(), 21951L, IIlIIl(1460917847, -1899852801));
      lI[IIlIIl(1460917846, 1720062684)] = llII(IIlIlI(-196356646, -685164231).toCharArray(), 9318L, IIlIIl(1460917845, -1220602255));
      lI[IIlIIl(1460917844, 1189287459)] = llII(IIlIlI(-196356645, 882708602).toCharArray(), 63940L, IIlIIl(1460917835, 676807971));
      lI[IIlIIl(1460917834, 217497505)] = llII(IIlIlI(-196356648, 847672673).toCharArray(), 68488L, IIlIIl(1460917833, 995386905));
      lI[IIlIIl(1460917832, 710648214)] = llII(IIlIlI(-196356647, -1504114594).toCharArray(), 62414L, IIlIIl(1460917839, 1540948657));
      lI[IIlIIl(1460917838, 1896833018)] = llII(IIlIlI(-196356642, 1784828190).toCharArray(), 25313L, IIlIIl(1460917837, 687837794));
   }

   private String lllll(Object var1) {
      return var1 != null && var1.I != null && !var1.I.isBlank() ? var1.I : lIlIII.Il(lI[4]);
   }

   public List<<undefinedtype>> IIIIII() {
      ArrayList var1 = new ArrayList();

      for(<undefinedtype> var3 : this.lIIII()) {
         if (var3 != null && var3.l != null) {
            var1.add(new Record(var3.l, this.lllll(var3), this.IIlII(var3), var3.Il == null ? 0 : var3.Il.size()) {
               private final int I;
               private final String l;
               private final String II;
               private final String Il;

               public String I() {
                  return this.II;
               }

               public int l() {
                  return this.I;
               }

               public String II() {
                  return this.Il;
               }

               public {
                  this.l = var1;
                  this.II = var2;
                  this.Il = var3;
                  this.I = var4;
               }

               public String Il() {
                  return this.l;
               }
            });
         }
      }

      return var1;
   }

   public llIIIlII() {
      super((Object)lIIl, lIllII.l, (Object)lIlIII.Il(lI[IIlIIl(1460917836, -2089186940)]));
      this.Il = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(lI[IIlIIl(1460917827, -1252135965)]), (double)75.0F, (double)125.0F, (double)0.0F, (double)1000.0F, (double)5.0F)).IIII(lIlIII.Il(lI[IIlIIl(1460917826, 1572635106)])));
      this.IlI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lI[IIlIIl(1460917825, 1547040760)]), true));
      this.lIII = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(lI[IIlIIl(1460917824, -1058511494)]), <undefinedtype>.class, null.I));
      this.IIII = lI[1];
      this.IlIl = lIlIII.Il(lI[IIlIIl(1460917831, 2094089415)]);
      this.IIl = new ArrayList();
      this.IllI = 0L;
      this.lll = new HashMap();
   }

   private Map<String, Object> IIIIlI(Object var1) {
      LinkedHashMap var2 = new LinkedHashMap();
      var2.put(lIlIII.Il(lI[IIlIIl(1460917830, 2075550158)]), var1.l);
      var2.put(lIlIII.Il(lI[IIlIIl(1460917829, 1307837645)]), var1.II);
      var2.put(lIlIII.Il(lI[IIlIIl(1460917828, -1839205717)]), var1.Il);
      var2.put(lIlIII.Il(lI[IIlIIl(1460917883, 1371341236)]), var1.lI);
      if (var1.I != null && !var1.I.isBlank()) {
         var2.put(lIlIII.Il(lI[IIlIIl(1460917882, -1906756039)]), var1.I);
      }

      var2.put(lIlIII.Il(lI[IIlIIl(1460917881, 1014545597)]), var1.ll != null && !var1.ll.isBlank() ? var1.ll : var1.lI);
      var2.put(lIlIII.Il(lI[IIlIIl(1460917880, 1157528182)]), var1.III);
      String var10001 = lIlIII.Il(lI[IIlIIl(1460917887, -611932650)]);
      String var10002 = lIlIII.Il(lI[IIlIIl(1460917886, 1537268505)]);
      String var10003 = URLEncoder.encode(var1.lI, StandardCharsets.UTF_8);
      String var10004 = lIlIII.Il(lI[IIlIIl(1460917885, -188327870)]);
      String var6 = II;
      String var5 = var10004;
      String var4 = var10003;
      String var3 = var10002;
      var2.put(var10001, var3 + var4 + var5 + var6);
      return var2;
   }

   private void IIIIll(class_310 var1, String var2) {
      if (this.Illl && (Boolean)this.IlI.III()) {
         this.lIll(var1);
      } else {
         this.I = false;
         this.lIl = false;
      }

      this.Illl = false;
      this.llI = null;
      this.IIII = lI[1];
      this.ll = false;
      this.IlIl = var2 != null && !var2.isBlank() ? var2 : lIlIII.Il(lI[IIlIIl(1460917884, 230722130)]);
   }

   private int IIIlIl(class_746 var1, Map<Integer, <undefinedtype>> var2, Object var3) {
      int var4 = -1;
      int var5 = IIlIIl(1460917875, 1700463952);

      for(int var9 : III) {
         if (var9 != var3.Il) {
            class_1799 var10 = this.IlIII(var1, var9);
            if (this.IlII(var10, var3) && !this.IIII(var10, var9, var2)) {
               int var11 = IIlIIl(1460917874, -1641621168) - Math.abs(var10.method_7947() - var3.III);
               if (!var2.containsKey(var9)) {
                  var11 += 100;
               }

               if (var11 > var5) {
                  var5 = var11;
                  var4 = var9;
               }
            }
         }
      }

      return var4;
   }

   public Map<String, Object> IIIllI(String var1, String var2) {
      String var3 = this.IIIIl(var1);
      if (var3.isBlank()) {
         throw new IllegalArgumentException(lIlIII.Il(lI[IIlIIl(1460917873, -678183173)]));
      } else {
         <undefinedtype> var4 = this.Illl(var3);
         if (var4 == null) {
            throw new IllegalArgumentException(lIlIII.Il(lI[IIlIIl(1460917872, 1286503500)]));
         } else {
            if (var2 != null && !var2.isBlank() && !lIlIII.Il(lI[IIlIIl(1460917879, 365114487)]).equals(var2)) {
               try {
                  class_3675.method_15981(var2);
               } catch (Exception var8) {
                  String var6 = lIlIII.Il(lI[IIlIIl(1460917878, 1767882335)]);
                  throw new IllegalArgumentException(var6 + var2);
               }

               var4.II = var2;
            } else {
               var4.II = null;
            }

            this.IIlIII(var4);
            this.IIlI();
            this.lll.remove(var3);
            return this.IIIlll();
         }
      }
   }

   private Map<String, Object> IIIlll() {
      LinkedHashMap var1 = new LinkedHashMap();
      var1.put(lIlIII.Il(lI[IIlIIl(1460917877, -169004440)]), true);
      ArrayList var2 = new ArrayList();

      for(<undefinedtype> var4 : this.IlIIl()) {
         var2.add(this.IllII(var4));
      }

      var1.put(lIlIII.Il(lI[IIlIIl(1460917876, 258619523)]), var2);
      var1.put(lIlIII.Il(lI[IIlIIl(1460917867, 350672272)]), this.IIlll());
      return var1;
   }

   private void IIlIII(Object var1) {
      Path var2 = this.lll();
      if (var2 == null) {
         throw new IllegalStateException(lIlIII.Il(lI[IIlIIl(1460917866, 1739807053)]));
      } else {
         try {
            Files.createDirectories(var2);
            String var10001 = var1.l;
            String var8 = lIlIII.Il(lI[3]);
            String var4 = var10001;
            Files.writeString(var2.resolve(var4 + var8), IIll.toJson(var1));
         } catch (IOException var7) {
            String var10002 = lIlIII.Il(lI[5]);
            String var6 = var7.getMessage();
            String var5 = var10002;
            throw new IllegalStateException(var5 + var6, var7);
         }
      }
   }

   private static int IIlIIl(int var0, int var1) {
      return lIlI[var0 ^ 1460917915] ^ var1 ^ var0;
   }

   private static String IIlIlI(int var0, int var1) {
      int var3 = var0 ^ -196356710;
      char[] var4 = lIll[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])llII[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         llII[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 1347676284;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 225;
               break;
            case 1:
               var9 = 100;
               break;
            case 2:
               var9 = 167;
               break;
            case 3:
               var9 = 166;
               break;
            case 4:
               var9 = 243;
               break;
            case 5:
               var9 = 16;
               break;
            case 6:
               var9 = 30;
               break;
            case 7:
               var9 = 22;
               break;
            case 8:
               var9 = 74;
               break;
            case 9:
               var9 = 232;
               break;
            case 10:
               var9 = 230;
               break;
            case 11:
               var9 = 158;
               break;
            case 12:
               var9 = 152;
               break;
            case 13:
               var9 = 228;
               break;
            case 14:
               var9 = 145;
               break;
            case 15:
               var9 = 139;
               break;
            case 16:
               var9 = 113;
               break;
            case 17:
               var9 = 52;
               break;
            case 18:
               var9 = 87;
               break;
            case 19:
               var9 = 147;
               break;
            case 20:
               var9 = 147;
               break;
            case 21:
               var9 = 148;
               break;
            case 22:
               var9 = 77;
               break;
            case 23:
               var9 = 192;
               break;
            case 24:
               var9 = 168;
               break;
            case 25:
               var9 = 37;
               break;
            case 26:
               var9 = 43;
               break;
            case 27:
               var9 = 18;
               break;
            case 28:
               var9 = 203;
               break;
            case 29:
               var9 = 138;
               break;
            case 30:
               var9 = 203;
               break;
            case 31:
               var9 = 182;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
