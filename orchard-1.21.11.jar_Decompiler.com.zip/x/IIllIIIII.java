package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_310;

@Environment(EnvType.CLIENT)
public final class IIllIIIII extends IIIIIIIlI {
   private final IlIIIlIlI<<undefinedtype>> I;
   private static String[] l;
   private final IIIllIIII II;
   private final lIIIIl Il;
   private static final int[] lI;
   private static final String[] ll;
   private static final Object[] III;

   public IIllIIIII() {
      super((Object)lIlIII.l(l[1]), lIllII.III, (Object)lIlIII.l(l[0]));
      this.II = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(l[3]), 0.6, 0.6, (double)1.0F, 0.1));
      this.Il = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(l[4]), true));
      this.I = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(l[2]), <undefinedtype>.class, null.II));
   }

   public boolean ll(class_1657 var1) {
      return this.IIIIIlI() && this.IIII(var1);
   }

   public double IlI() {
      return Math.max(0.6, Math.min((double)1.0F, (Double)this.II.III()));
   }

   static {
      short var6 = 17507;
      String var7 = "ﾪ뼕ᯓ\ud87b炗벎딩堢柺㤞맅励风ꥣ蘍奼㵈눭㦟揦⤀讝勗ᰄ䉻\ue53b胇\uf5c4᳝룂ﾚ䉁䗈㷉꺂筽䅪\udc72꧳퀦륺삸匘塁⨔\uf1de䳞峲䁞䗘褬\ue668વ⯻喸쵻\udecf秀씨ᦣ䌓撯ퟠ⯀镅㠈ަ鮺䣦윻찯豌咶㫬ၠ腰큃ᡉ讓⸼躉뻿ヱ≦窩憐\u2e79鐢\udfc0ᥑ줺䖨⟟琔Ϲⴇ瘻ꨲ⤂़뇯౸ὓϷ\uea2e櫔閴\uf522띷偰ᢃ퍭찳鐠ꪄ\ue8fcǅ\udb28㵊ﻣ鈱⸆슡ﾫ\uf663᭣썪▬寬\ud9b8ꮻꝃ\uefc6ҩ簕봴拠⩮┠臫ኛ棂狳脜";
      char[] var8 = "L\u0010\u0018\u0014\b".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            ll = var9;
            III = new Object[var9.length];
            int var2 = -1653075338;
            byte[] var0 = "OõM\u0015\u008e0½Ð©Tý\u0090%\u0010Á\u001c\u0005\u0086B»o{Û2@á¼ã".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lI = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lI[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            l = new String[5];
            llI();
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 21;
                     break;
                  case 1:
                     var10000 = 70;
                     break;
                  case 2:
                     var10000 = 105;
                     break;
                  case 3:
                     var10000 = 114;
                     break;
                  case 4:
                     var10000 = 19;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public boolean lII(class_1657 var1) {
      if (this.IIIIIlI() && (Boolean)this.Il.III() && this.IIII(var1)) {
         boolean var10000;
         switch (((<undefinedtype>)this.I.III()).ordinal()) {
            case 0 -> var10000 = true;
            case 1 -> var10000 = !var1.method_24828();
            case 2 -> var10000 = var1.method_24828();
            default -> throw new MatchException((String)null, (Throwable)null);
         }

         return var10000;
      } else {
         return false;
      }
   }

   private static void llI() {
      l[0] = lll(IlII(-2119912228, 559954196).toCharArray(), 33493L, IIll(-86184371, 1362675261));
      l[1] = lll(IlII(-2119912227, -1626250446).toCharArray(), 30615L, IIll(-86184372, 231861765));
      l[2] = lll(IlII(-2119912226, 825710317).toCharArray(), 6527L, IIll(-86184369, 1135019900));
      l[3] = lll(IlII(-2119912225, -2144779972).toCharArray(), 91492L, IIll(-86184370, 349580639));
      l[4] = lll(IlII(-2119912232, 1327434445).toCharArray(), 77512L, IIll(-86184375, 1663520139));
   }

   private static String lll(char[] var0, long var1, int var3) {
      int var4 = IIll(-86184376, -1313487548) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IIll(-86184373, 658849825);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private boolean IIII(class_1657 var1) {
      class_310 var2 = class_310.method_1551();
      return var1 != null && var2 != null && var1 == var2.field_1724;
   }

   private static int IIll(int var0, int var1) {
      return lI[var0 ^ -86184371] ^ var1 ^ var0;
   }

   private static String IlII(int var0, int var1) {
      int var3 = var0 ^ -2119912228;
      char[] var4 = ll[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])III[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         III[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 744923954;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 246;
               break;
            case 1:
               var9 = 62;
               break;
            case 2:
               var9 = 204;
               break;
            case 3:
               var9 = 72;
               break;
            case 4:
               var9 = 29;
               break;
            case 5:
               var9 = 53;
               break;
            case 6:
               var9 = 10;
               break;
            case 7:
               var9 = 35;
               break;
            case 8:
               var9 = 99;
               break;
            case 9:
               var9 = 35;
               break;
            case 10:
               var9 = 66;
               break;
            case 11:
               var9 = 66;
               break;
            case 12:
               var9 = 14;
               break;
            case 13:
               var9 = 28;
               break;
            case 14:
               var9 = 24;
               break;
            case 15:
               var9 = 60;
               break;
            case 16:
               var9 = 217;
               break;
            case 17:
               var9 = 174;
               break;
            case 18:
               var9 = 41;
               break;
            case 19:
               var9 = 134;
               break;
            case 20:
               var9 = 166;
               break;
            case 21:
               var9 = 175;
               break;
            case 22:
               var9 = 27;
               break;
            case 23:
               var9 = 249;
               break;
            case 24:
               var9 = 2;
               break;
            case 25:
               var9 = 167;
               break;
            case 26:
               var9 = 111;
               break;
            case 27:
               var9 = 194;
               break;
            case 28:
               var9 = 201;
               break;
            case 29:
               var9 = 231;
               break;
            case 30:
               var9 = 131;
               break;
            case 31:
               var9 = 234;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
