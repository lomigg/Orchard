package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
enum IIlllIllI {
   I;

   private static String[] l;
   Il;

   private final <undefinedtype> lI;
   ll;

   private static final int[] III;
   private static final String[] IIl;
   private static final Object[] IlI;

   static {
      short var6 = 27613;
      String var7 = "蚆玷ꅥ鹽応劍햴嚅懭ꊶ䐊冘ꢏ킆Ȓ廊\ufb1c镫\uf8cd䣟휧\ufde8≙汉鯚㻨퀬㳓メ⺥棡耈ᗜￛꞢ⾉た芁섺걠䆕쮮蘭덿举襫\uf14cᢲḵ\udebe";
      char[] var8 = "\b\u0007\f\u0007\f\u0004".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            IIl = var9;
            IlI = new Object[var9.length];
            int var2 = 932048714;
            byte[] var0 = "\u0004\u001aéÊBÂË\u0015VsÌàù£%båö!àD\tùq\u0013ÿ¼§Û}ß\u008eBóÄã".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            III = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               III[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            l = new String[lI(255671019, 1017789549)];
            I();
            I = new IIlllIllI(l[5], 0, lIlIII.Il(l[0]));
            Il = new IIlllIllI(l[3], 1, lIlIII.Il(l[4]));
            ll = new IIlllIllI(l[1], 2, lIlIII.Il(l[2]));
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 2;
                     break;
                  case 1:
                     var10000 = 77;
                     break;
                  case 2:
                     var10000 = 69;
                     break;
                  case 3:
                     var10000 = 121;
                     break;
                  case 4:
                     var10000 = 12;
                     break;
                  case 5:
                     var10000 = 70;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static void I() {
      l[0] = II(ll(-1435657405, -2025897887).toCharArray(), 2646L, lI(255671018, -306976212));
      l[1] = II(ll(-1435657406, -1424942350).toCharArray(), 14238L, lI(255671017, -2010933277));
      l[2] = II(ll(-1435657407, 633618013).toCharArray(), 15654L, lI(255671016, -905903404));
      l[3] = II(ll(-1435657408, -1948689541).toCharArray(), 74765L, lI(255671023, 765959131));
      l[4] = II(ll(-1435657401, -1361873361).toCharArray(), 90919L, lI(255671022, 545367155));
      l[5] = II(ll(-1435657402, 970925631).toCharArray(), 66578L, lI(255671021, 782156895));
   }

   public static IIlllIllI l(String var0) {
      return (IIlllIllI)Enum.valueOf(IIlllIllI.class, var0);
   }

   private static String II(char[] var0, long var1, int var3) {
      int var4 = lI(255671020, 550380087) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & lI(255671011, 2051215797);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   public String toString() {
      return this.lI.lIlI();
   }

   // $FF: synthetic method
   private static IIlllIllI[] Il() {
      return new IIlllIllI[]{I, Il, ll};
   }

   private IIlllIllI(String var3) {
      this.lI = lIlIII.III(var3);
   }

   private static int lI(int var0, int var1) {
      return III[var0 ^ 255671019] ^ var1 ^ var0;
   }

   private static String ll(int var0, int var1) {
      int var3 = var0 ^ -1435657405;
      char[] var4 = IIl[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IlI[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IlI[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 1925630628;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 41;
               break;
            case 1:
               var9 = 29;
               break;
            case 2:
               var9 = 10;
               break;
            case 3:
               var9 = 95;
               break;
            case 4:
               var9 = 17;
               break;
            case 5:
               var9 = 123;
               break;
            case 6:
               var9 = 75;
               break;
            case 7:
               var9 = 196;
               break;
            case 8:
               var9 = 206;
               break;
            case 9:
               var9 = 38;
               break;
            case 10:
               var9 = 122;
               break;
            case 11:
               var9 = 181;
               break;
            case 12:
               var9 = 232;
               break;
            case 13:
               var9 = 120;
               break;
            case 14:
               var9 = 9;
               break;
            case 15:
               var9 = 52;
               break;
            case 16:
               var9 = 5;
               break;
            case 17:
               var9 = 96;
               break;
            case 18:
               var9 = 250;
               break;
            case 19:
               var9 = 194;
               break;
            case 20:
               var9 = 105;
               break;
            case 21:
               var9 = 123;
               break;
            case 22:
               var9 = 140;
               break;
            case 23:
               var9 = 33;
               break;
            case 24:
               var9 = 55;
               break;
            case 25:
               var9 = 183;
               break;
            case 26:
               var9 = 134;
               break;
            case 27:
               var9 = 93;
               break;
            case 28:
               var9 = 226;
               break;
            case 29:
               var9 = 41;
               break;
            case 30:
               var9 = 39;
               break;
            case 31:
               var9 = 152;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
