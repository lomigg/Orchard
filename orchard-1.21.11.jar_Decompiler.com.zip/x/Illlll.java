package x;

import com.google.gson.JsonObject;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1665;
import net.minecraft.class_1753;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2680;
import net.minecraft.class_2846;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_638;
import net.minecraft.class_6880;
import net.minecraft.class_746;
import net.minecraft.class_9304;
import net.minecraft.class_9334;
import net.minecraft.class_239.class_240;
import net.minecraft.class_2846.class_2847;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;

@Environment(EnvType.CLIENT)
public final class Illlll extends IIIIIIIlI {
   private static final double I = (double)0.0625F;
   private int l;
   private int II;
   private boolean Il;
   private final lIIIIl lI;
   private static final double ll = (double)0.125F;
   private static final int III = 20;
   private <undefinedtype> IIl;
   private final IlIlIll IlI;
   private static final double Ill = (double)20.25F;
   private int lII;
   private final Set<UUID> lIl;
   private final Set<UUID> llI;
   private boolean lll;
   private long IIII;
   private final IlIIIlIlI<<undefinedtype>> IIIl;
   private static final double IIlI = 0.05;
   private static final int IIll = 320;
   private int IlII;
   private static final int IlIl = 20;
   private final IIIllIIII IllI;
   private static final double Illl = (double)4.5F;
   private boolean lIII;
   private final IIIlllllI lIIl;
   private boolean lIlI;
   private long lIll;
   private boolean llII;
   private final llllIlIl llIl;
   private int lllI;
   private float llll;
   private <undefinedtype> IIIII;
   private static final double IIIIl = 0.99;
   private int IIIlI;
   private class_638 IIIll;
   private float IIlII;
   private int IIlIl;
   private int IIllI;
   private float IIlll;
   private static final long IlIII = 250L;
   private int IlIIl;
   private long IlIlI;
   private int IlIll;
   private class_746 IllII;
   private static final int IllIl = 2;
   private static final float IlllI = 0.1F;
   private class_2338 Illll;
   private int lIIII;
   private static final int[] lIIIl;
   private static final String[] lIIlI;
   private static final Object[] lIIll;

   public void llllII(class_2596<?> var1) {
      if (var1 instanceof class_2846 var2) {
         if (var2.method_12363() == class_2847.field_12974) {
            class_310 var3 = class_310.method_1551();
            if (var3 != null && var3.field_1724 != null && this.llII) {
               this.IlIlll(var3);
            }
         }
      }

   }

   private boolean IlI(class_310 var1, long var2, class_2338 var4, int var5) {
      if (var2 == this.IIII && this.Illll != null && this.Illll.equals(var4)) {
         this.IlII = IllIII(1125461560, 949846522);
         if (this.IIlll(var1, var4)) {
            this.lIIIl();
            this.lIII = false;
            this.IlIllI(var1, var5);
            this.IIllII();
            return true;
         } else {
            this.IIllI(var1, var5);
            return false;
         }
      } else {
         return false;
      }
   }

   private class_3965 lII(class_2338 var1) {
      return var1 == null ? null : new class_3965(this.lIIl(var1), class_2350.field_11036, var1, false);
   }

   private void llI(class_310 var1) {
      this.lIl.clear();
      if (var1 != null && var1.field_1687 != null) {
         for(class_1297 var3 : var1.field_1687.method_18112()) {
            if (var3 instanceof class_1665) {
               class_1665 var4 = (class_1665)var3;
               this.lIl.add(var4.method_5667());
            }
         }

      }
   }

   public Illlll() {
      super((Object)lIlIII.l(IllIIl((short)3614, 932143534, '柶')), lIllII.I, (Object)lIlIII.l(IllIIl((short)'횉', -717742801, '柷')));
      this.IIIl = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IllIIl((short)32322, -1784144808, '柴')), <undefinedtype>.class, null.I));
      this.IllI = (IIIllIIII)this.IIIlIll((IIIllIIII)(new IIIllIIII(lIlIII.l(IllIIl((short)'Ꜹ', -1010888746, '柵')), (double)50.0F, (double)1.0F, (double)100.0F, (double)1.0F)).lIII(() -> this.IIIl.III() == null.II));
      this.IlI = new IlIlIll();
      this.lIll = 0L;
      this.lI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IllIIl((short)26868, 1658782198, '柲')), true));
      this.llIl = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(IllIIl((short)'뺄', 508585222, '柳')), (double)0.0F, (double)0.0F, (double)0.0F, (double)300.0F, (double)5.0F)).Ill(lIlIII.l(IllIIl((short)'뒯', -1936780689, '柰'))));
      this.lIl = new HashSet();
      this.llI = new HashSet();
      this.IIlIl = IllIII(1125461561, 477066021);
      this.lIIII = -1;
      this.lllI = IllIII(1125461562, 1018872507);
      this.IlII = IllIII(1125461563, -1748892568);
      this.l = IllIII(1125461564, -1788360796);
      this.IIII = Long.MIN_VALUE;
      this.IIIlI = IllIII(1125461565, -1656910127);
      this.IIllI = -1;
      this.lIIl = new IIIlllllI();
   }

   private boolean IIII(class_310 var1, class_2338 var2) {
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null && var2 != null) {
         class_239 var3 = var1.field_1724.method_5745((double)4.5F, 1.0F, false);
         boolean var10000;
         if (var3 instanceof class_3965) {
            class_3965 var4 = (class_3965)var3;
            if (var4.method_17783() == class_240.field_1332 && var4.method_17777().equals(var2) && var4.method_17780() == class_2350.field_11036 && this.IIll(var1.field_1687.method_8320(var2))) {
               var10000 = true;
               return var10000;
            }
         }

         var10000 = false;
         return var10000;
      } else {
         return false;
      }
   }

   private boolean IIll(class_2680 var1) {
      return var1 != null && (var1.method_27852(class_2246.field_10167) || var1.method_27852(class_2246.field_10425) || var1.method_27852(class_2246.field_10025) || var1.method_27852(class_2246.field_10546));
   }

   private boolean IlII(class_310 var1, class_2338 var2) {
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null && var2 != null) {
         class_2680 var3 = var1.field_1687.method_8320(var2);
         class_2338 var4 = var2.method_10074();
         class_243 var5 = this.IlIIll(var2);
         return var1.field_1687.method_8621().method_11952(var2) && var1.field_1687.method_8621().method_11952(var4) && (var3.method_26215() || var3.method_45474()) && this.IlIIl(var1, var4) && var1.field_1724.method_33571().method_1025(var5) <= (double)20.25F && this.IIlIl(var1, this.IIlllI(var2), var4);
      } else {
         return false;
      }
   }

   private void IlIl(class_310 var1) {
      if (this.IIIl.III() == null.II && !this.lIII && var1 != null && var1.field_1724 != null) {
         this.IIlll = var1.field_1724.method_36454();
         this.IIlII = var1.field_1724.method_36455();
         this.lIII = true;
      }
   }

   private class_2338 Illl(class_310 var1, class_243 var2, class_243 var3) {
      class_243 var4 = var2;
      class_243 var5 = var3;

      for(int var6 = 0; var6 < IllIII(1125461566, 1705882876); ++var6) {
         class_243 var7 = var4.method_1019(var5);
         class_3965 var8 = var1.field_1687.method_17742(new class_3959(var4, var7, class_3960.field_17558, class_242.field_1348, var1.field_1724));
         if (var8 != null && var8.method_17783() == class_240.field_1332) {
            return this.llllI(var1, var8);
         }

         var4 = var7;
         var5 = var5.method_1021(0.99).method_1023((double)0.0F, 0.05, (double)0.0F);
      }

      return null;
   }

   private boolean lIII(class_310 var1, class_2338 var2) {
      return var1 != null && var1.field_1724 != null && var1.field_1687 != null && var2 != null && var1.field_1687.method_8621().method_11952(var2) && var1.field_1724.method_33571().method_1025(this.lIIl(var2)) <= (double)20.25F;
   }

   private class_243 lIIl(class_2338 var1) {
      return class_243.method_24955(var1).method_1031((double)0.0F, (double)0.125F, (double)0.0F);
   }

   private int llII(class_1657 var1) {
      return this.lIlIl(var1, class_1802.field_8069);
   }

   private void lllI() {
      this.IIllI = -1;
      this.IlIll = 0;
   }

   private boolean IIIII(class_310 var1, class_2338 var2) {
      return this.IlII(var1, var2) && this.lIII(var1, var2);
   }

   private void IIIIl(UUID var1) {
      if (var1 != null) {
         if (this.llI.size() >= IllIII(1125461567, 358692558)) {
            this.llI.clear();
         }

         this.llI.add(var1);
      }
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (this.IIIIlI(var1)) {
         this.lllII(var1);
         if (this.lIlI || this.IIIll()) {
            this.llIlI(var1);
         }

         this.IIIlIl(var1);
      }
   }

   private boolean IIIll() {
      return this.IIIII != null || this.Illll != null || this.IIllI >= 0;
   }

   private boolean IIlII(class_1799 var1) {
      if (var1 != null && !var1.method_7960() && var1.method_7909() instanceof class_1753) {
         class_9304 var2 = (class_9304)var1.method_58695(class_9334.field_49633, class_9304.field_49385);

         for(class_6880 var4 : var2.method_57534()) {
            String var5 = (String)var4.method_40230().map((var0) -> var0.method_29177().method_12832()).orElse("");
            if (lIlIII.Il(IllIIl((short)17275, 1470778644, '柱')).equals(var5) && var2.method_57536(var4) > 0) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   private boolean IIlIl(class_310 var1, class_243 var2, class_2338 var3) {
      class_3965 var4 = var1.field_1687.method_17742(new class_3959(var1.field_1724.method_33571(), var2, class_3960.field_17559, class_242.field_1348, var1.field_1724));
      return var4 != null && var4.method_17777().equals(var3);
   }

   public void IllI(class_310 var1) {
      if (this.IIIIlI(var1)) {
         if (this.lIlI || this.IIIll()) {
            this.llIlI(var1);
         }

         this.IlIlIl(var1);
         this.IIIlIl(var1);
         this.IlIII(var1);
      }
   }

   private void IIllI(class_310 var1, int var2) {
      ++this.lII;
      this.lIIIl();
      if (this.lII > IllIII(1125461552, -1538346255)) {
         this.llIll(var1);
         this.IlIllI(var1, var2);
         this.IIllII();
      }

   }

   private boolean IIlll(class_310 var1, class_2338 var2) {
      if (this.Il) {
         return true;
      } else {
         int var3 = IllllIlI.IIlIl(var1);
         if (this.lIII(var1, var2) && var3 >= 0 && this.IIIIII(var1.field_1724.method_31548().method_5438(var3))) {
            this.IlIIII(var1);
            long var4 = IllllIlI.IIlIIIl();
            boolean var6 = IllllIlI.lIlIl();

            try {
               IllllIlI.lIlII(var1, class_1268.field_5808, this.lII(var2));
            } finally {
               this.Il |= IllllIlI.IIlIIIl() != var4;
               if (var6) {
                  IllllIlI.IIlllI();
               }

            }

            return this.Il;
         } else {
            return false;
         }
      }
   }

   private void IlIII(class_310 var1) {
      if (this.IIllI >= 0) {
         if (var1 != null && var1.field_1724 != null) {
            if (var1.field_1724.field_6012 >= this.IlIll) {
               int var2 = this.IIllI;
               IllllIlI.llll(var1, this, var2, 0);
               this.lllI();
            }
         } else {
            this.lllI();
         }
      }
   }

   private boolean IlIIl(class_310 var1, class_2338 var2) {
      class_2680 var3 = var1.field_1687.method_8320(var2);
      return var3 != null && !var3.method_26215() && var3.method_26227().method_15769() && !var3.method_26220(var1.field_1687, var2).method_1110();
   }

   private boolean IlIll(class_310 var1) {
      return var1 != null && var1.field_1724 == this.IllII && var1.field_1687 == this.IIIll;
   }

   private class_2338[] IllII(class_3965 var1) {
      class_2338 var2 = var1.method_17777();
      class_2350 var3 = var1.method_17780();
      if (var3 == class_2350.field_11036) {
         return new class_2338[]{var2.method_10084(), var2.method_10095().method_10084(), var2.method_10072().method_10084(), var2.method_10078().method_10084(), var2.method_10067().method_10084()};
      } else {
         return var3.method_10166().method_10179() ? new class_2338[]{var2.method_10093(var3), var2.method_10084(), var2.method_10093(var3).method_10084(), var2.method_10093(var3.method_10170()).method_10084(), var2.method_10093(var3.method_10160()).method_10084()} : new class_2338[]{var2.method_10093(var3), var2.method_10084()};
      }
   }

   private long IllIl(llllIlIl var1) {
      double var2 = var1.IlII();
      double var4 = var1.IlI();
      return var2 == var4 ? Math.max(0L, Math.round(var2)) : Math.max(0L, Math.round(ThreadLocalRandom.current().nextDouble(var2, var4)));
   }

   boolean IlllI() {
      return this.IIIIIlI() && (this.lIlI || this.IIIll());
   }

   private class_3965 Illll(class_2338 var1) {
      return var1 == null ? null : new class_3965(this.IlIIll(var1), class_2350.field_11036, var1.method_10074(), false);
   }

   private void lIIII(class_310 var1, Object var2) {
      if (this.IIIII == var2) {
         ++this.II;
         this.lIIIl();
         if (this.II > IllIII(1125461553, 77590363)) {
            this.IIIII = null;
            this.IIlIl = IllIII(1125461554, 870573670);
            this.llIll(var1);
            this.IlIllI(var1, var2.II());
         }

      }
   }

   private void lIIIl() {
      this.IIl = null;
      this.lIIl.II();
   }

   private void lIIlI(class_310 var1, boolean var2) {
      if (var2) {
         this.llIll(var1);
      }

      if (var1 != null && var1.field_1724 != null) {
         IllllIlI.IlII(var1, this, null.II);
      }

      this.IIIII = null;
      this.II = 0;
      this.IIlIl = IllIII(1125461555, -1230972207);
      this.lll = false;
      this.IIllII();
      this.lllI();
      this.lIIIl();
   }

   private void lIlII(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         if (!(Boolean)this.lI.III()) {
            IllllIlI.IlII(var1, this, null.Il);
         } else {
            int var2 = this.IIllI;
            if (var2 < 0 && this.lIIII >= 0) {
               var2 = this.lIIII;
            }

            if (var2 < 0 && this.IIIII != null) {
               var2 = this.IIIII.II();
            }

            if (var2 >= 0 && var2 < IllIII(1125461556, -1420387973)) {
               IllllIlI.llIIlI(var1, this, var2);
            } else {
               IllllIlI.IlII(var1, this, null.II);
            }

         }
      }
   }

   private int lIlIl(class_1657 var1, class_1792 var2) {
      for(int var3 = 0; var3 < IllIII(1125461557, 863454219); ++var3) {
         class_1799 var4 = var1.method_31548().method_5438(var3);
         if (var4.method_31574(var2)) {
            return var3;
         }
      }

      return -1;
   }

   public void IIl(JsonObject var1) {
      super.IIl(var1);
      this.llIlIl(var1, lIlIII.Il(IllIIl((short)'ꅐ', 1311450750, '柾')), new llllIlIl[]{this.llIl});
      this.llIlIl(var1, lIlIII.Il(IllIIl((short)'︑', -2117896217, '柿')), new llllIlIl[]{this.llIl});
   }

   private class_243 lIlll(class_310 var1, float var2, float var3) {
      float var4 = var2 * ((float)Math.PI / 180F);
      float var5 = var3 * ((float)Math.PI / 180F);
      float var6 = class_3532.method_15362((double)var5);
      float var7 = class_3532.method_15374((double)var5);
      float var8 = class_3532.method_15362((double)var4);
      float var9 = class_3532.method_15374((double)var4);
      class_243 var10 = new class_243((double)(-var9 * var6), (double)(-var7), (double)(var8 * var6));
      return var1.field_1724.method_33571().method_1019(var10.method_1021((double)5.0F));
   }

   private int llIII(class_1657 var1) {
      for(int var2 = 0; var2 < IllIII(1125461558, -354455550); ++var2) {
         class_1799 var3 = var1.method_31548().method_5438(var2);
         if (this.IlIIIl(var3)) {
            return var2;
         }
      }

      return -1;
   }

   private boolean llIIl(class_310 var1, class_2338 var2) {
      return IlIlIl.III(var1, this.Illll(var2));
   }

   private void llIlI(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         this.IIIlI = Math.max(this.IIIlI, IllllIlI.Illll(var1));
      }
   }

   private void llIll(class_310 var1) {
      if (this.lIII) {
         if (this.IIIl.III() == null.II && var1 != null && var1.field_1724 != null) {
            IllllIlI.IIIlIII(var1, this.IIlll, this.IIlII);
         }

         this.lIII = false;
      }
   }

   private void lllII(class_310 var1) {
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null) {
         class_746 var2 = var1.field_1724;
         class_1799 var3 = var2.method_6030();
         if (var2.method_6115() && this.IIlII(var3)) {
            this.llll = class_1753.method_7722(var2.method_6048());
            this.llII = this.llll >= 0.1F;
         } else {
            if (this.llII) {
               this.IlIlll(var1);
            }

            if (this.lIlI) {
               ++this.IlIIl;
               if (this.IlIIl > IllIII(1125461559, -1082464105) || this.Illll != null) {
                  this.lIlI = false;
                  return;
               }

               for(class_1297 var5 : var1.field_1687.method_18112()) {
                  if (var5 instanceof class_1665) {
                     class_1665 var6 = (class_1665)var5;
                     if (var6.field_6012 <= IllIII(1125461544, -1678214504) && var6.method_5809() && !this.lIl.contains(var6.method_5667()) && !this.llI.contains(var6.method_5667())) {
                        double var7 = var6.method_5858(var2);
                        if (var7 < (double)25.0F && (var6.method_24921() == var2 || var6.method_24921() == null && var6.field_6012 <= 3 && var7 < (double)9.0F) && this.IlIIlI(var1, new class_243(var6.method_23317(), var6.method_23318(), var6.method_23321()), var6.method_18798())) {
                           this.IIIIl(var6.method_5667());
                           this.IlIlIl(var1);
                           this.lIlI = false;
                           this.lIl.clear();
                           break;
                        }
                     }
                  }
               }
            }

         }
      } else {
         this.IIIIll();
         this.lIlI = false;
      }
   }

   private class_2338 llllI(class_310 var1, class_3965 var2) {
      for(class_2338 var6 : this.IllII(var2)) {
         if (this.IIIII(var1, var6)) {
            return var6.method_10062();
         }
      }

      return null;
   }

   private boolean lllll(class_310 var1, long var2, class_2338 var4, int var5, float var6, float var7, boolean var8) {
      this.IlII = var1.field_1724.field_6012;
      boolean var9 = IlIlIl.IIIIlI(var1, IllIII(1125461545, 58035868), var6, var7, () -> this.IlI(var1, var2, var4, var5));
      if (!var9) {
         this.IlII = IllIII(1125461546, -207022442);
         this.l = IllIII(1125461547, 40986035);
      }

      return var9;
   }

   private boolean IIIIII(class_1799 var1) {
      return var1 != null && !var1.method_7960() && var1.method_31574(class_1802.field_8069);
   }

   private void IIIIIl(class_310 var1) {
      IllllIlI.IlII(var1, this, null.Il);
      this.IIIIll();
      this.lIlI = false;
      this.IlIIl = 0;
      this.lIl.clear();
      this.llI.clear();
      this.IIIII = null;
      this.II = 0;
      this.IIlIl = IllIII(1125461548, 1057468042);
      this.lll = false;
      this.IIllII();
      this.lllI();
      this.lIIIl();
      this.lIII = false;
      this.IIIlI = IllIII(1125461549, -280391987);
      this.IllII = null;
      this.IIIll = null;
   }

   private boolean IIIIlI(class_310 var1) {
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null) {
         if (this.IllII == null && this.IIIll == null) {
            this.IllII = var1.field_1724;
            this.IIIll = var1.field_1687;
            return true;
         } else if (!this.IlIll(var1)) {
            this.IIIIIl(var1);
            this.IllII = var1.field_1724;
            this.IIIll = var1.field_1687;
            return false;
         } else {
            return true;
         }
      } else {
         if (this.IllII != null || this.IIIll != null) {
            this.IIIIIl(var1);
         }

         return false;
      }
   }

   private void IIIIll() {
      this.llII = false;
      this.llll = 0.0F;
   }

   private void IIIlIl(class_310 var1) {
      if (this.Illll != null && var1 != null && var1.field_1724 != null && var1.field_1724.field_6012 >= this.lllI && var1.field_1724.field_6012 >= this.IIIlI) {
         class_2338 var2 = this.Illll;
         int var3 = this.lIIII;
         long var4 = this.IIII;
         if (var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null) {
            if (this.IlII != IllIII(1125461550, -1340905936)) {
               if (var1.field_1724.field_6012 <= this.IlII) {
                  return;
               }

               this.IlII = IllIII(1125461551, 1066708751);
               this.l = IllIII(1125461536, -1941861678);
            }

            if (!this.lIII(var1, var2)) {
               this.IIllI(var1, var3);
            } else {
               int var6 = this.llII(var1.field_1724);
               if (var6 < 0) {
                  this.IIllI(var1, var3);
               } else {
                  boolean var7 = this.IIlIlI(var1, var6);
                  boolean var8 = var1.field_1724.field_6012 == this.l;
                  if (this.IIlIII(var1, var2)) {
                     if (var7) {
                        this.lllll(var1, var4, var2, var3, var1.field_1724.method_36454(), var1.field_1724.method_36455(), var8);
                     }

                  } else {
                     float[] var9 = IlIlIl.llIlI(var1, this.lIIl(var2));
                     if (var9 == null) {
                        this.IIllI(var1, var3);
                     } else if (this.IIIl.III() != null.II) {
                        if (var7) {
                           this.lllll(var1, var4, var2, var3, var9[0], var9[1], var8);
                        }
                     } else {
                        if (this.lIll == 0L) {
                           this.lIll = System.currentTimeMillis();
                        }

                        boolean var10 = this.IIlIII(var1, var2);
                        float var11 = var10 ? 0.0F : this.IlI.IlIl(var1, this.lIlll(var1, var9[0], var9[1]), ((Double)this.IllI.III()).floatValue());
                        if (var7) {
                           if (var10 || var11 <= 0.5F || System.currentTimeMillis() - this.lIll >= 250L) {
                              float var12 = var10 ? var1.field_1724.method_36454() : var9[0];
                              float var13 = var10 ? var1.field_1724.method_36455() : var9[1];
                              if (this.lllll(var1, var4, var2, var3, var12, var13, var8)) {
                                 this.lIll = 0L;
                              }
                           }

                        }
                     }
                  }
               }
            }
         } else {
            this.IlIllI(var1, var3);
            this.IIllII();
         }
      }
   }

   private boolean IIlIII(class_310 var1, class_2338 var2) {
      return IlIlIl.III(var1, this.lII(var2));
   }

   public void lI() {
      class_310 var1 = class_310.method_1551();
      this.lIlII(var1);
      this.llIll(var1);
      this.IIIIll();
      this.IIIII = null;
      this.II = 0;
      this.IIlIl = IllIII(1125461537, -1684325049);
      this.IIllII();
      this.lllI();
      this.lIIIl();
      this.lIlI = false;
      this.IlIIl = 0;
      this.lIl.clear();
      this.llI.clear();
      this.IlI.IIIlIll();
      this.lIll = 0L;
   }

   private boolean IIlIIl(class_310 var1, Object var2) {
      if (this.IIIII != var2) {
         return false;
      } else {
         this.IIlIl = IllIII(1125461538, 534246242);
         if (this.IIllIl(var1, var2.l())) {
            this.lIIIl();
            this.IIIII = null;
            this.II = 0;
            this.IIlIll(var1, var2.l(), var2.II());
            this.IIIlIl(var1);
            return true;
         } else {
            this.lIIII(var1, var2);
            return false;
         }
      }
   }

   private boolean IIlIlI(class_310 var1, int var2) {
      if (var1 != null && var1.field_1724 != null && var2 >= 0 && var2 < IllIII(1125461539, -1752997589)) {
         if (!this.lIIl.l(var2)) {
            if (this.IIl == null || !this.IIl.III() || this.IIl.ll() != var2) {
               boolean var3 = IllllIlI.IIlIl(var1) != var2;
               int var4 = var3 ? this.IIllll(this.llIl) : 0;
               this.IIl = IllllIlI.lIll(var1, this, var2, var4, true);
            }

            if (!IllllIlI.IlIllII(var1, this.IIl)) {
               return false;
            }

            this.IIl = null;
            this.lIIl.lI(var2, System.currentTimeMillis(), 0L);
         }

         return this.lIIl.Il(var2, System.currentTimeMillis());
      } else {
         return false;
      }
   }

   private void IIlIll(class_310 var1, class_2338 var2, int var3) {
      this.Illll = var2.method_10062();
      this.lIIII = var3;
      this.lllI = var1.field_1724.field_6012;
      this.lII = 0;
      this.IlII = IllIII(1125461540, 11479486);
      this.l = var1.field_1724.field_6012;
      this.IIII = ++this.IlIlI;
      this.Il = false;
      int var4 = this.llII(var1.field_1724);
      if (var4 >= 0) {
         this.IIlIlI(var1, var4);
      }

   }

   private void IIllII() {
      this.Illll = null;
      this.lIIII = -1;
      this.lllI = IllIII(1125461541, 190851969);
      this.lII = 0;
      this.IlII = IllIII(1125461542, 1114868988);
      this.l = IllIII(1125461543, -2049045768);
      this.IIII = Long.MIN_VALUE;
      this.Il = false;
      this.lIll = 0L;
   }

   private boolean IIllIl(class_310 var1, class_2338 var2) {
      if (this.lll) {
         return true;
      } else {
         int var3 = IllllIlI.IIlIl(var1);
         if (this.IIIII(var1, var2) && var3 >= 0 && this.IlIIIl(var1.field_1724.method_31548().method_5438(var3))) {
            this.IlIIII(var1);
            long var4 = IllllIlI.IIlIIIl();
            boolean var6 = IllllIlI.lIlIl();

            try {
               IllllIlI.lIlII(var1, class_1268.field_5808, this.Illll(var2));
            } finally {
               this.lll |= IllllIlI.IIlIIIl() != var4;
               if (var6) {
                  IllllIlI.IIlllI();
               }

            }

            return this.lll;
         } else {
            return false;
         }
      }
   }

   private class_243 IIlllI(class_2338 var1) {
      return this.IlIIll(var1).method_1023((double)0.0F, (double)0.0625F, (double)0.0F);
   }

   private int IIllll(llllIlIl var1) {
      return IIIlllllI.I(this.IllIl(var1));
   }

   public void lIl() {
      this.IlI.IIlIIII();
   }

   private void IlIIII(class_310 var1) {
      if (var1 != null && var1.field_1690 != null && var1.field_1690.field_1904 != null) {
         IllllIlI.IIIIllI(var1.field_1690.field_1904);
         var1.field_1690.field_1904.method_23481(false);
      }
   }

   private boolean IlIIIl(class_1799 var1) {
      return var1 != null && !var1.method_7960() && (var1.method_31574(class_1802.field_8129) || var1.method_31574(class_1802.field_8848) || var1.method_31574(class_1802.field_8211) || var1.method_31574(class_1802.field_8655));
   }

   private boolean IlIIlI(class_310 var1, class_243 var2, class_243 var3) {
      if (var1 != null && var1.field_1724 != null && this.llIII(var1.field_1724) >= 0 && this.llII(var1.field_1724) >= 0) {
         class_2338 var4 = this.Illl(var1, var2, var3);
         if (var4 != null && this.IIIII(var1, var4)) {
            class_243 var5 = this.IlIIll(var4);
            float[] var6 = IlIlIl.llIlI(var1, var5);
            if (var6 == null) {
               return false;
            } else {
               this.IlIl(var1);
               int var7 = this.IIIII != null ? this.IIIII.II() : IllllIlI.lIIlI(var1.field_1724.method_31548());
               this.IIIII = new Record(var4.method_10062(), var7, var6[0], var6[1]) {
                  private final float I;
                  private final class_2338 l;
                  private final float II;
                  private final int Il;

                  public float I() {
                     return this.I;
                  }

                  private {
                     this.l = var1;
                     this.Il = var2;
                     this.I = var3;
                     this.II = var4;
                  }

                  public class_2338 l() {
                     return this.l;
                  }

                  public int II() {
                     return this.Il;
                  }

                  public float Il() {
                     return this.II;
                  }
               };
               this.II = 0;
               this.IIlIl = IllIII(1125461528, 811618851);
               this.lll = false;
               return true;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private class_243 IlIIll(class_2338 var1) {
      return class_243.method_24955(var1);
   }

   private void IlIlIl(class_310 var1) {
      if (this.IIIII != null) {
         <undefinedtype> var2 = this.IIIII;
         if (var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null) {
            if (var1.field_1724.field_6012 >= this.IIIlI) {
               if (this.IIlIl != IllIII(1125461530, 875704203)) {
                  if (var1.field_1724.field_6012 <= this.IIlIl) {
                     return;
                  }

                  this.IIlIl = IllIII(1125461531, -1420818339);
               }

               if (!this.IIIII(var1, var2.l())) {
                  this.IIIII = null;
                  this.IlIllI(var1, var2.II());
               } else {
                  int var3 = this.llIII(var1.field_1724);
                  if (var3 < 0) {
                     this.IIIII = null;
                     this.IlIllI(var1, var2.II());
                  } else {
                     boolean var4 = this.IIlIlI(var1, var3);
                     if (this.IIIl.III() != null.II) {
                        if (var4) {
                           if (this.IIIl.III() == null.I) {
                              this.IIlIl = var1.field_1724.field_6012;
                              boolean var10 = IlIlIl.IIIIlI(var1, IllIII(1125461534, 101579542), var2.I(), var2.Il(), () -> this.IIlIIl(var1, var2));
                              if (!var10) {
                                 this.IIlIl = IllIII(1125461535, -57920680);
                              }

                           } else {
                              this.IIlIl = var1.field_1724.field_6012;
                              if (!IlIlIl.IIIIlI(var1, IllIII(1125461520, -471981311), var2.I(), var2.Il(), () -> this.IIlIIl(var1, var2))) {
                                 this.IIlIl = IllIII(1125461521, 1203455806);
                              }

                           }
                        }
                     } else {
                        if (this.lIll == 0L) {
                           this.lIll = System.currentTimeMillis();
                        }

                        boolean var5 = this.llIIl(var1, var2.l());
                        float var6 = var5 ? 0.0F : this.IlI.IlIl(var1, this.lIlll(var1, var2.I(), var2.Il()), ((Double)this.IllI.III()).floatValue());
                        if (var4) {
                           if (var5 || var6 <= 0.5F || System.currentTimeMillis() - this.lIll >= 250L) {
                              float var7 = var5 ? var1.field_1724.method_36454() : var2.I();
                              float var8 = var5 ? var1.field_1724.method_36455() : var2.Il();
                              this.IIlIl = var1.field_1724.field_6012 + 2;
                              boolean var9 = IlIlIl.IIIIlI(var1, IllIII(1125461532, -2020300964), var7, var8, () -> this.IIlIIl(var1, var2));
                              if (!var9) {
                                 this.IIlIl = IllIII(1125461533, 858168594);
                              } else {
                                 this.lIll = 0L;
                              }
                           }

                        }
                     }
                  }
               }
            }
         } else {
            this.IIIII = null;
            this.IIlIl = IllIII(1125461529, 573147084);
         }
      }
   }

   private void IlIllI(class_310 var1, int var2) {
      if (var1 != null && var1.field_1724 != null && var2 >= 0 && var2 < IllIII(1125461522, 1694372637)) {
         if (!(Boolean)this.lI.III()) {
            IllllIlI.IlII(var1, this, null.Il);
            this.lllI();
            this.lIIIl();
         } else {
            this.lIIIl();
            this.IIllI = var2;
            this.IlIll = var1.field_1724.field_6012 + (this.IIIl.III() == null.II ? 1 : 0);
         }
      }
   }

   private void IlIlll(class_310 var1) {
      float var2 = this.llll > 0.0F ? this.llll : 1.0F;
      this.llII = false;
      this.llll = 0.0F;
      this.lIIlI(var1, true);
      this.llI(var1);
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null) {
         float var3 = var2 * 3.0F;
         class_243 var4 = var1.field_1724.method_5828(1.0F);
         class_243 var5 = var1.field_1724.method_33571().method_1023((double)0.0F, (double)0.1F, (double)0.0F);
         class_243 var6 = var4.method_1021((double)var3);
         if (this.IlIIlI(var1, var5, var6)) {
            this.IlIlIl(var1);
            this.lIlI = false;
            return;
         }
      }

      this.lIlI = true;
      this.IlIIl = 0;
   }

   private static int IllIII(int var0, int var1) {
      return lIIIl[var0 ^ 1125461560] ^ var1 ^ var0;
   }

   static {
      short var6 = 17126;
      String var7 = "琲璖璅璎琨琹琟璔璞琤琤瑊\ue292\ue236\ue225\ue22e\ue288\ue297\ue221\ue234\ue221\ue251\ue234\ue232\ue250\ue239\ue23d\ue235\ue225\ue27f\ue21f\ue23c\ue288\ue27f\ue29a\ue237\ue232\ue236\ue256\ue239\ue235\ue287\ue22e\ue23c\ue29b\ue284\ue224\ue233\ue224\ue23e\ue254\ue283\ue241\ue293\ue255\ue235\ue29d\ue235\ue29e\ue239\ue224\ue29b\ue239\ue250\ue250\ue23d\udfb0\ue229\ue286\ue297\ue288\ue23c\ue288\ue256\ue286\ue220\ue29a\ue239\ue29b\ue283\ue288\ue287\ue253\ue237\ue232\ue23e\ue255\ue225\ue251\ue253\ue284\ue239\ue251\ue293\ue254\ue23c\ue29d\ue252\ue292\ue22e\ue225\ue226\ue294\ue234\ue237\ue29b\ue253\ue226\ue241\ue23e\ue22a\ue22a䩉䩈䩜䧹䩒䧩䪉䨭䨐䩰䧴䨐䧾䧮䧶䨬䧷䨫䪅䪅씤섑얓얞씸얃씡얄얃얓얄샨\ue808\ue7dd\ue7b3\ue7ed\ue800\ue7b7\ue809\ue7eb\ue80c\ue80d\ue7db\ue7ba\ue7b6\ue7dc\ue7a8\ue7c4ﳳľňﳮﳻńﳲﴐůŎﳻŕńŜğŃ秪禧稁秛鶔鶆鶞鴼鶁鴨鶝鵃戰挌抠抻挘抣抳拇툺퇧튁툷툲퉭툻툹튖튗툲튜퉭튕퇦퉪";
      char[] var8 = "䋪䊂䋲䋪䋶䋶䋢䋮䋮䋶".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            lIIlI = var9;
            lIIll = new Object[var9.length];
            int var2 = -448127746;
            byte[] var0 = "\u001eÂ³<:0Aâ\u001aåð\u007f±\u009d6\u00ad³8õf»b¼\u0012Ãò\u0087|³>\u0004\u008f\u0002\u0011\u0080+¢ÀÝ\u0080\u0015¼Ôª\u0090ÿè\u001c\r\t«¸\u0095(vÉL\u0080BÃ\u0019%ÚJ=§HD¥*¼\u0083Õö$B$.Wf\u0019X\u009cXÉ\u0016¼\u001e\u0096LTà\u0019Ë\u009dÞª\u001e¸\f½Ä\u000f\u00989\u0088Á¾1ÜSÿ&ð\u001bd-?\u0019Zd,¾$£\u00818!\u0016?`Å\u0004vµ+\u0012m\u001do\u008d\u000f:¸!Ë\u0095v\u0015y¯ñ RÉ>ÚÓ\u0001¹E\u0081\u0011'aäuÑÂ¡!ø".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lIIIl = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lIIIl[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static String IllIIl(short var0, int var1, char var2) {
      int var3 = var2 ^ 26614;
      char[] var4 = lIIlI[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])lIIll[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         lIIll[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 5199;
      int var9 = 0;

      do {
         int var10 = var4[var9] - 'ײַ';
         var10 ^= 29328;
         var10 -= 37635;
         var10 ^= 11451;
         var10 += 42081;
         var10 += 28819;
         var10 -= 40959;
         var10 += 30932;
         var10 -= 8187;
         var10 += 53838;
         var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
