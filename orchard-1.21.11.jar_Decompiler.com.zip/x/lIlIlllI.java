package x;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class lIlIlllI extends llllllI<String> {
   private <undefinedtype> I;
   private final <undefinedtype> l;

   private static <undefinedtype> I(Object var0) {
      return lIlIII.IIIl(var0);
   }

   public lIlIlllI(Object var1, Object var2) {
      super((Object)var1, "");
      this.l = I(var2);
      this.I = this.l;
   }

   public void ll(String var1) {
      this.Ill(lIlIII.III(var1 == null ? "" : var1));
   }

   public JsonElement lI() {
      return new JsonPrimitive(this.IlI());
   }

   public lIlIlllI(String var1, String var2) {
      this((Object)var1, (Object)var2);
   }

   public void IIl() {
      this.Ill(this.l);
   }

   public String IlI() {
      return this.I.lIlI();
   }

   public void Ill(Object var1) {
      <undefinedtype> var2 = var1 == null ? lIlIII.III("") : var1;
      if (!this.I.lIII(var2)) {
         this.I = var2;
         this.llII();
      }

   }

   public <undefinedtype> lII() {
      return this.I;
   }

   public lIlIlllI(Object var1, String var2) {
      this((Object)var1, (Object)var2);
   }

   public void II(JsonElement var1) {
      if (var1 != null && var1.isJsonPrimitive()) {
         this.ll(var1.getAsString());
      }

   }

   public String lIl() {
      return this.l.lIlI();
   }
}
