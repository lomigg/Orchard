package x;

import net.fabricmc.api.ModInitializer;

public final class lIllIIlI implements ModInitializer {
   private static String[] I;
   public static final String l;
   private static final int[] II;
   private static final String[] Il;
   private static final Object[] lI;

   private static void I() {
      I[0] = l(Il(1786165582, 1197085021).toCharArray(), 97889L, II(-30282932, 2102021639));
   }

   static {
      short var6 = 14247;
      String var7 = "㖼腹몋饙³餹\ud874퍌꿂훫ﺹ\ue626";
      char[] var8 = "\f".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            Il = var9;
            lI = new Object[var9.length];
            int var2 = 67881713;
            byte[] var0 = "·ñË·¼ú8ø~O¦,".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            II = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               II[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            I = new String[1];
            I();
            l = lIlIII.Il(I[0]);
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 59;
                     break;
                  case 1:
                     var10000 = 108;
                     break;
                  case 2:
                     var10000 = 6;
                     break;
                  case 3:
                     var10000 = 95;
                     break;
                  case 4:
                     var10000 = 0;
                     break;
                  case 5:
                     var10000 = 11;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public void onInitialize() {
   }

   private static String l(char[] var0, long var1, int var3) {
      int var4 = II(-30282931, -2109550600) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & II(-30282930, -2072672404);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private static int II(int var0, int var1) {
      return II[var0 ^ -30282932] ^ var1 ^ var0;
   }

   private static String Il(int var0, int var1) {
      int var3 = var0 ^ 1786165582;
      char[] var4 = Il[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])lI[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         lI[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -1173798030;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 156;
               break;
            case 1:
               var9 = 25;
               break;
            case 2:
               var9 = 32;
               break;
            case 3:
               var9 = 116;
               break;
            case 4:
               var9 = 138;
               break;
            case 5:
               var9 = 6;
               break;
            case 6:
               var9 = 144;
               break;
            case 7:
               var9 = 240;
               break;
            case 8:
               var9 = 107;
               break;
            case 9:
               var9 = 189;
               break;
            case 10:
               var9 = 127;
               break;
            case 11:
               var9 = 142;
               break;
            case 12:
               var9 = 135;
               break;
            case 13:
               var9 = 254;
               break;
            case 14:
               var9 = 8;
               break;
            case 15:
               var9 = 96;
               break;
            case 16:
               var9 = 60;
               break;
            case 17:
               var9 = 90;
               break;
            case 18:
               var9 = 39;
               break;
            case 19:
               var9 = 140;
               break;
            case 20:
               var9 = 130;
               break;
            case 21:
               var9 = 146;
               break;
            case 22:
               var9 = 238;
               break;
            case 23:
               var9 = 201;
               break;
            case 24:
               var9 = 167;
               break;
            case 25:
               var9 = 218;
               break;
            case 26:
               var9 = 96;
               break;
            case 27:
               var9 = 29;
               break;
            case 28:
               var9 = 16;
               break;
            case 29:
               var9 = 113;
               break;
            case 30:
               var9 = 45;
               break;
            case 31:
               var9 = 160;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
