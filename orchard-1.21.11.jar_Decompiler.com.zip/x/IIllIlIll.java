package x;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1109;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2791;
import net.minecraft.class_2806;
import net.minecraft.class_310;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_7923;

@Environment(EnvType.CLIENT)
public final class IIllIlIll extends IIIIIIIlI {
   private static String[] I;
   private final Set<String> l;
   private final lIIIlll II;
   private static final int Il = 40;
   private static final int lI = 2048;
   private int ll;
   private final IIIllIIII III;
   private static final int IIl = 64;
   private static final int IlI = 64;
   private static final int Ill = 4;
   private static final int lII = 36;
   private static final int[] lIl;
   private static final String[] llI;
   private static final Object[] lll;

   private void I() {
      class_310 var1 = class_310.method_1551();
      if (var1 != null && var1.method_1483() != null) {
         var1.method_1483().method_4873(class_1109.method_4757((class_3414)class_3417.field_14793.comp_349(), 1.25F, 0.9F));
      }
   }

   private static String l(char[] var0, long var1, int var3) {
      int var4 = lll(-1342064469, -283802352) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & lll(-1342064470, 1084944236);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private List<class_2338> II(class_310 var1, class_1937 var2, class_2338 var3) {
      ArrayList var4 = new ArrayList();
      int var5 = var3.method_10263() >> 4;
      int var6 = var3.method_10260() >> 4;
      int var7 = Math.max(var2.method_31607(), var3.method_10264() - lll(-1342064471, -2102410593));
      int var8 = Math.min(var2.method_31600(), var3.method_10264() + lll(-1342064472, -389152792));
      class_2338.class_2339 var9 = new class_2338.class_2339();

      for(int var10 = lll(-1342064465, 1387748981); var10 <= 4; ++var10) {
         for(int var11 = lll(-1342064466, 1177460141); var11 <= 4; ++var11) {
            int var12 = var5 + var10;
            int var13 = var6 + var11;
            class_2791 var14 = var2.method_8402(var12, var13, class_2806.field_12803, false);
            if (var14 != null) {
               int var15 = var12 << 4;
               int var16 = var13 << 4;

               for(int var17 = 0; var17 < lll(-1342064467, 1199070221); ++var17) {
                  int var18 = var15 + var17;

                  for(int var19 = 0; var19 < lll(-1342064468, 1624303338); ++var19) {
                     int var20 = var16 + var19;

                     for(int var21 = var7; var21 <= var8; ++var21) {
                        var9.method_10103(var18, var21, var20);
                        if (this.ll(var14.method_8320(var9))) {
                           var4.add(var9.method_10062());
                           if (var4.size() >= lll(-1342064477, 1067958581)) {
                              return var4;
                           }
                        }
                     }
                  }
               }
            }
         }
      }

      return var4;
   }

   private class_2338 Il(List<class_2338> var1) {
      long var2 = 0L;
      long var4 = 0L;
      long var6 = 0L;

      for(class_2338 var9 : var1) {
         var2 += (long)var9.method_10263();
         var4 += (long)var9.method_10264();
         var6 += (long)var9.method_10260();
      }

      int var10 = Math.max(1, var1.size());
      return new class_2338(Math.round((float)var2 / (float)var10), Math.round((float)var4 / (float)var10), Math.round((float)var6 / (float)var10));
   }

   public IIllIlIll() {
      super((Object)lIlIII.l(I[lll(-1342064478, -2093320980)]), lIllII.ll, (Object)lIlIII.l(I[lll(-1342064479, 658050295)]));
      this.III = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(I[lll(-1342064480, -1366923789)]), (double)5.0F, (double)2.0F, (double)32.0F, (double)1.0F));
      this.II = (lIIIlll)this.IIIlIll(new lIIIlll(lIlIII.l(I[lll(-1342064473, 45035182)]), List.of()));
      this.l = new HashSet();
   }

   private boolean ll(class_2680 var1) {
      if (var1 != null && !var1.method_26215()) {
         class_2248 var2 = var1.method_26204();
         String var3 = class_7923.field_41175.method_10221(var2).method_12832().toLowerCase(Locale.ROOT);
         return var3.endsWith(lIlIII.Il(I[3])) || var3.endsWith(lIlIII.Il(I[4])) || var3.endsWith(lIlIII.Il(I[5]));
      } else {
         return false;
      }
   }

   private List<class_2338> III(class_2338 var1, Set<class_2338> var2) {
      ArrayList var3 = new ArrayList();
      ArrayDeque var4 = new ArrayDeque();
      var2.remove(var1);
      var4.add(var1);

      while(!var4.isEmpty()) {
         class_2338 var5 = (class_2338)var4.remove();
         var3.add(var5);
         ArrayList var6 = new ArrayList();

         for(class_2338 var8 : var2) {
            if (var5.method_10262(var8) <= (double)36.0F) {
               var6.add(var8);
            }
         }

         for(class_2338 var10 : var6) {
            var2.remove(var10);
            var4.add(var10);
         }
      }

      return var3;
   }

   private static void IIl() {
      I[0] = l("".toCharArray(), 13163L, lll(-1342064474, -1575494062));
      I[1] = l(IIII(717838549, '\ue3b5', (short)'莆').toCharArray(), 4474L, lll(-1342064475, 1840693678));
      I[2] = l(IIII(50661241, '\ue3b4', (short)24199).toCharArray(), 11080L, lll(-1342064476, 1577481608));
      I[3] = l(IIII(-805546196, '\ue3b7', (short)19534).toCharArray(), 17668L, lll(-1342064453, -1910020421));
      I[4] = l(IIII(1877279066, '\ue3b6', (short)'첲').toCharArray(), 18656L, lll(-1342064454, -896463083));
      I[5] = l(IIII(1925723715, '\ue3b1', (short)2201).toCharArray(), 20649L, lll(-1342064455, 1208685995));
      I[lll(-1342064456, -1719945369)] = l(IIII(-474729976, '\ue3b0', (short)'鮼').toCharArray(), 70382L, lll(-1342064449, 306001245));
      I[lll(-1342064450, 453832715)] = l(IIII(1464348201, '\ue3b3', (short)'슅').toCharArray(), 14957L, lll(-1342064451, -1707421745));
      I[lll(-1342064452, 224516256)] = l(IIII(-1085208376, '\ue3b2', (short)'蓦').toCharArray(), 93133L, lll(-1342064461, -1154025762));
      I[lll(-1342064462, -1873871368)] = l(IIII(-1983182998, '\ue3bd', (short)'鄂').toCharArray(), 3173L, lll(-1342064463, -551894712));
      I[lll(-1342064464, 705875864)] = l(IIII(-1701044707, '\ue3bc', (short)18108).toCharArray(), 47933L, lll(-1342064457, 1141370610));
      I[lll(-1342064458, -776003012)] = l(IIII(1346993024, '\ue3bf', (short)'ﯺ').toCharArray(), 60517L, lll(-1342064459, 191758995));
      I[lll(-1342064460, 899614055)] = l(IIII(-742180363, '\ue3be', (short)'왑').toCharArray(), 14718L, lll(-1342064501, 2111069584));
      I[lll(-1342064502, 568282464)] = l(IIII(798629248, '\ue3b9', (short)7876).toCharArray(), 11127L, lll(-1342064503, 716045882));
   }

   public void lI() {
      this.ll = 0;
   }

   static {
      short var6 = 15691;
      String var7 = "罋㩈⾤蚪\udff3͑\udd0fࢰ풖쇝㘠緄껆蹕焿颼▩탃앿亜䭳ࠇ魢췮⛬됮덎옯惖\uf3b3䍦瑉ᥡ鞫혰斃⬡剡뵷༖㾟먈镺浶ꪕ\ue9ff拼낌嘌낟榘㡛ᅟ\uec61\uef5b柏⚔Ẉෟꪴ䨝य़鐪ὕೳ멕媮\uf6c4ტ爵\ue282쩰礧\ue863掁㿠\udf56\u1fc5蔜뙄\ue000酈⫿\ua83e\ud8bf〉㪬䎻⫨ๆ\ue446勺⇵ả椡醉\uef45ĢΌຠ\ue263蔹累礍\ue015Ᏹ㙡螨쥑鄂㺣魧㒷癬㴆刔酗௬鵱⤟箦쌌蚿ꪐ✹\uee04䝀䈱蠂쪬传斋㕙묞\udd46ₚ傚捠䰵⺮薠䀝⎖\u169f经\uebefᾶ钬뜏댗\ue772ࢮ⁹菷\udd84雯뫗靣\ue5a4뾐욚⃛녇槇žꨭ\uf6ae魯쌲詔\uf0e2ᅱꦊ讠\udf2d喖㍃䵡\udcfe綼톷婅ၫ騔膌ᾇ輄賳ⓑᴓ໖㬞艭༌㩳⟲";
      char[] var8 = "\u0004\u0004\b\b\u0010\u0010\u0004\u0010\u0004\u0014\u0010\u0014<".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            llI = var9;
            lll = new Object[var9.length];
            int var2 = 918032900;
            byte[] var0 = "Pî(\u008aÆ\u0013E=\u0004\u0016hrntU\u0004+ñ\u000b\"?hÈûÁÁö´æiLR¹\u001ec\u0092\u0005\u0083ÞA¡\u0080¦_(?Ï[\u0084\u0016\u0084\u0007\u0007\u0017`¡ x\u001eñ,<Úþ8Tþú\u009d\u0003\u0017\u0002\u0011º'#\u001fÂ\u001dÝ§&~b\u009dµZ¶Ùs\u0010\u0098\u008bØr\u0010\u0098\u0004K\u0097\u0016÷WG(\u0006n\u0085¬«e&<}ÚjW\u0006\u0088\u0085\u0083%ê\u0096³&¯Û®\u0082¥\\§fçã&{ë\u0080\u0095Ó\u00ad\u0096\u00148M=Æ¨eÞ[\u0003H\u0011ñ&¹TÕ\u0005\u00959òÜC\u00992A¨;I \u0094\u001a".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lIl = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lIl[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            I = new String[lll(-1342064504, 325715732)];
            IIl();
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 12;
                     break;
                  case 1:
                     var10000 = 34;
                     break;
                  case 2:
                     var10000 = 101;
                     break;
                  case 3:
                     var10000 = 50;
                     break;
                  case 4:
                     var10000 = 115;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private String IlI(String var1) {
      if (var1 == null) {
         return I[0];
      } else {
         String[] var2 = var1.trim().split(lIlIII.Il(I[2]));
         if (var2.length < 3) {
            return I[0];
         } else {
            String var10000 = var2[0];
            String var10001 = lIlIII.Il(I[1]);
            String var10002 = var2[1];
            String var10003 = lIlIII.Il(I[1]);
            String var7 = var2[2];
            String var6 = var10003;
            String var5 = var10002;
            String var4 = var10001;
            String var3 = var10000;
            return var3 + var4 + var5 + var6 + var7;
         }
      }
   }

   public void Ill() {
      if (++this.ll >= lll(-1342064497, -1836980322)) {
         this.ll = 0;
         class_310 var1 = class_310.method_1551();
         if (var1 != null && var1.field_1724 != null && var1.field_1687 != null) {
            List var2 = this.II(var1, var1.field_1687, var1.field_1724.method_24515());
            if (!var2.isEmpty()) {
               this.lII(var2);
            }
         }
      }
   }

   private void lII(List<class_2338> var1) {
      HashSet var2 = new HashSet(var1);
      int var3 = Math.max(1, (int)Math.round((Double)this.III.III()));

      while(!var2.isEmpty()) {
         class_2338 var4 = (class_2338)var2.iterator().next();
         List var5 = this.III(var4, var2);
         if (var5.size() >= var3) {
            this.llI(var5);
         }
      }

   }

   public void lIl() {
      this.ll = 0;
      this.l.clear();

      for(String var2 : (List)this.II.III()) {
         String var3 = this.IlI(var2);
         if (!var3.isEmpty()) {
            this.l.add(var3);
         }
      }

   }

   private void llI(List<class_2338> var1) {
      class_2338 var2 = this.Il(var1);
      int var10000 = var2.method_10263();
      String var10001 = lIlIII.Il(I[1]);
      int var10002 = var2.method_10264();
      String var10003 = lIlIII.Il(I[1]);
      int var10 = var2.method_10260();
      String var9 = var10003;
      int var8 = var10002;
      String var7 = var10001;
      int var6 = var10000;
      String var3 = var6 + var7 + var8 + var9 + var10;
      if (this.l.add(var3)) {
         var10000 = var2.method_10263();
         var10001 = lIlIII.Il(I[lll(-1342064498, 1074909011)]);
         var10002 = var2.method_10264();
         var10003 = lIlIII.Il(I[lll(-1342064499, -574954849)]);
         int var10004 = var2.method_10260();
         String var10005 = lIlIII.Il(I[lll(-1342064500, 2006914005)]);
         int var10006 = var1.size();
         String var14 = lIlIII.Il(I[lll(-1342064509, 1404846008)]);
         int var13 = var10006;
         String var12 = var10005;
         int var11 = var10004;
         String var20 = var10003;
         int var18 = var10002;
         String var16 = var10001;
         int var15 = var10000;
         String var4 = var15 + var16 + var18 + var20 + var11 + var12 + var13 + var14;
         ArrayList var5 = new ArrayList((Collection)this.II.III());
         var5.add(0, var4);

         while(var5.size() > lll(-1342064510, 1952835935)) {
            var5.remove(var5.size() - 1);
         }

         this.II.ll(var5);
         IIlllIlI var22 = IIlllIlI.II();
         <undefinedtype> var24 = null.Il;
         String var26 = lIlIII.Il(I[lll(-1342064511, -1258814794)]);
         int var28 = var1.size();
         String var19 = lIlIII.Il(I[lll(-1342064512, -820429160)]);
         int var17 = var28;
         var22.III(var24, var26, var17 + var19, 4500L);
         this.I();
      }
   }

   private static int lll(int var0, int var1) {
      return lIl[var0 ^ -1342064469] ^ var1 ^ var0;
   }

   private static String IIII(int var0, char var1, short var2) {
      int var3 = var1 ^ '\ue3b5';
      char[] var4 = llI[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])lll[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         lll[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 2961;
      int var9 = 0;

      do {
         int var10 = var4[var9] + '\uf305';
         var10 += 11416;
         var10 += 10657;
         var10 += 10754;
         var4[var9] = (char)(var10 ^ var8 ^ var2 ^ var0 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
