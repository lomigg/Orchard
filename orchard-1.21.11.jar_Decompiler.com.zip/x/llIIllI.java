package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4604;
import net.minecraft.class_757;
import org.joml.Matrix4f;

@Environment(EnvType.CLIENT)
public interface llIIllI {
   Matrix4f Ill();

   Matrix4f I();

   class_4597 ll();

   class_4184 III();

   class_4587 lI();

   class_757 IlI();

   class_4604 l();
}
