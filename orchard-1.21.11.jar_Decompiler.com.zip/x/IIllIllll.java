package x;

import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_746;

@Environment(EnvType.CLIENT)
public final class IIllIllll extends IIIIIIIlI {
   private long I;
   private int l;
   private final llllIlIl II = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(IIIII(-437575962, 2047110306)), (double)45.0F, (double)45.0F, (double)0.0F, (double)500.0F, (double)5.0F)).Ill(lIlIII.l(IIIII(-437575967, -704415573))));
   private final lIIIIl Il = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIIII(-437575968, 874064092)), true));
   private final lllIIlIl lI = (lllIIlIl)this.IIIlIll(new lllIIlIl(lIlIII.l(IIIII(-437575961, 1420308469))));
   private <undefinedtype> ll;
   private boolean III;
   private static final int IIl = 9;
   private int IlI;
   private static final int[] Ill;
   private static final String[] lII;
   private static final Object[] lIl;

   private boolean II(class_746 var1) {
      return this.lll(var1.method_6118(class_1304.field_6174));
   }

   private boolean ll(class_310 var1) {
      return var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var1.field_1755 == null;
   }

   private void IlI(class_310 var1) {
      class_3675.class_306 var2 = (class_3675.class_306)this.lI.III();
      boolean var3 = !IllllIlI.IllllI(var2) && IllllIlI.IlIII(var1, var2);
      if (var3 && !this.III) {
         <undefinedtype> var4 = this.IlII(var1.field_1724) ? null.I : null.II;
         if (!this.lIIl(var1, var4)) {
            this.lIIl(var1, var4 == null.II ? null.I : null.II);
         }
      }

      this.III = var3;
   }

   public boolean lII() {
      return this.ll != null.I;
   }

   private boolean llI(class_1799 var1) {
      return var1 != null && !var1.method_7960() && var1.method_31574(class_1802.field_8833);
   }

   public void lI() {
      this.IIII(class_310.method_1551());
      this.IIll();
      this.III = false;
   }

   public void IllI(class_310 var1) {
      if (!this.ll(var1)) {
         this.IIII(var1);
         this.IIll();
         this.III = false;
      } else if (this.ll == null.Il) {
         if (System.currentTimeMillis() >= this.I) {
            this.llII(var1);
         }

      } else if (this.ll != null.l) {
         this.IlI(var1);
      }
   }

   private boolean lll(class_1799 var1) {
      return var1 != null && !var1.method_7960() && (var1.method_31574(class_1802.field_8577) || var1.method_31574(class_1802.field_8873) || var1.method_31574(class_1802.field_8523) || var1.method_31574(class_1802.field_8678) || var1.method_31574(class_1802.field_8058) || var1.method_31574(class_1802.field_22028) || var1.method_31574(class_1802.field_61344));
   }

   public void lIl() {
      this.IIll();
      this.III = false;
   }

   private void IIII(class_310 var1) {
      if ((Boolean)this.Il.III() && var1 != null && var1.field_1724 != null && this.l >= 0 && this.l < lllI(-556714122, -809686185) && this.l != this.IlI) {
         IllllIlI.llIIlI(var1, this, this.l);
      }
   }

   private void IIll() {
      this.ll = null.I;
      this.I = 0L;
      this.l = -1;
      this.IlI = -1;
   }

   private boolean IlII(class_746 var1) {
      return this.llI(var1.method_6118(class_1304.field_6174));
   }

   public boolean IlIl(class_310 var1, class_1309 var2) {
      return false;
   }

   public void lllIl(class_310 var1) {
      if (this.ll == null.l) {
         this.IIII(var1);
         this.IIll();
      }
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (!this.ll(var1)) {
         this.IIII(var1);
         this.IIll();
         this.III = false;
      }

   }

   public String Il() {
      return null;
   }

   private int Illl(class_746 var1, Object var2) {
      class_1661 var3 = var1.method_31548();

      for(int var4 = 0; var4 < lllI(-556714121, -963946244); ++var4) {
         class_1799 var5 = var3.method_5438(var4);
         if (var2 == null.II && this.llI(var5)) {
            return var4;
         }

         if (var2 == null.I && this.lll(var5)) {
            return var4;
         }
      }

      return -1;
   }

   private long lIII() {
      double var1 = this.II.IlII();
      double var3 = this.II.IlI();
      return var1 == var3 ? Math.max(0L, Math.round(var1)) : Math.max(0L, Math.round(ThreadLocalRandom.current().nextDouble(var1, var3)));
   }

   public IIllIllll() {
      super((Object)lIlIII.l(IIIII(-437575963, -639549144)), lIllII.l, (Object)lIlIII.l(IIIII(-437575964, -1364889051)));
      this.ll = null.I;
      this.l = -1;
      this.IlI = -1;
   }

   private boolean lIIl(class_310 var1, Object var2) {
      class_746 var3 = var1.field_1724;
      if (var2 == null.II && this.IlII(var3)) {
         return false;
      } else if (var2 == null.I && this.II(var3)) {
         return false;
      } else {
         int var4 = this.Illl(var3, var2);
         if (var4 < 0) {
            return false;
         } else {
            class_1661 var5 = var3.method_31548();
            this.l = IllllIlI.lIIlI(var5);
            this.IlI = var4;
            this.ll = null.Il;
            long var6 = System.currentTimeMillis();
            boolean var8 = IllllIlI.IIlIl(var1) != var4;
            this.I = var6 + (var8 ? this.lIII() : 0L);
            if (this.I <= var6) {
               this.llII(var1);
            }

            return true;
         }
      }
   }

   private boolean lIll(class_310 var1) {
      if (var1 != null && var1.field_1724 != null && this.IlI >= 0 && this.IlI < lllI(-556714124, -2000900317)) {
         class_1799 var2 = var1.field_1724.method_31548().method_5438(this.IlI);
         if (var2.method_7960()) {
            return false;
         } else if (this.IlII(var1.field_1724)) {
            return this.lll(var2);
         } else {
            return this.llI(var2) || this.lll(var2);
         }
      } else {
         return false;
      }
   }

   private void llII(class_310 var1) {
      if (this.lIll(var1) && !var1.field_1724.method_6115()) {
         int var2 = IllllIlI.lIIlI(var1.field_1724.method_31548());
         if (!IllllIlI.IIIIlll(var1, this.IlI)) {
            if (var2 != this.IlI) {
               this.ll = null.Il;
               this.I = System.currentTimeMillis();
            } else {
               this.IIII(var1);
               this.IIll();
            }
         } else {
            this.ll = null.l;
         }
      } else {
         this.IIII(var1);
         this.IIll();
      }
   }

   private static int lllI(int var0, int var1) {
      return Ill[var0 ^ -556714122] ^ var1 ^ var0;
   }

   static {
      short var6 = 12658;
      String var7 = "筀笯筑篙箠箇箂筛筏篶笉笯笸筶笄箽ఃఅళಅ೧ೃೝఐఇಗ\u0c74\u0c64౿\u0c29ళಅ\u0c50థ\u0c29ఫచౕಆ౯\u0cd3౸ఀಧ\u0cc9ಹౕ೧\u0c5eళ\u0c3bತ೯ಗಶఉ\u0c72\u0cbaఅ\u0c11ృళఘ\u0cc9ధ\u0c5e\u0c3aపఫచ\u0c91ౙ್ఠప಄\u0ce5ೝహಊ\u0c49జభ\u0cd0ದಁಏనౕ೪ఐఎౙ౯\u0c4eೞషఋ౧ీఓలಥి\u0c91ఄౢ೫\uf60e\uf608\uf63e\uf688\uf6ea\uf6c9\uf6d3\uf674\uf608\uf69a\uf67e\uf665\ud8a2\ud8a4\ud892\ud816\ud845\ud861\ud863\ud88f\ud8b6\ud820\ud8f0\ud8ce\ud8d8\ud898\ud8e9\ud824璸瓎璸瑈隿隹随阋陘陼陾隒隫阽隲雗雄雺隐际";
      char[] var8 = "\u0010\\\f\u0010\u0004\u0010".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            lII = var9;
            lIl = new Object[var9.length];
            int var2 = -1898654462;
            byte[] var0 = "\u009f¸É*\u0096\u008eº\u0080Ø¹M\\".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            Ill = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               Ill[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 55;
                     break;
                  case 1:
                     var10000 = 80;
                     break;
                  case 2:
                     var10000 = 115;
                     break;
                  case 3:
                     var10000 = 37;
                     break;
                  case 4:
                     var10000 = 102;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static String IIIII(int var0, int var1) {
      int var3 = var0 ^ -437575963;
      char[] var4 = lII[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])lIl[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         lIl[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 58416114;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 253;
               break;
            case 1:
               var9 = 217;
               break;
            case 2:
               var9 = 182;
               break;
            case 3:
               var9 = 78;
               break;
            case 4:
               var9 = 83;
               break;
            case 5:
               var9 = 13;
               break;
            case 6:
               var9 = 90;
               break;
            case 7:
               var9 = 131;
               break;
            case 8:
               var9 = 207;
               break;
            case 9:
               var9 = 27;
               break;
            case 10:
               var9 = 183;
               break;
            case 11:
               var9 = 212;
               break;
            case 12:
               var9 = 240;
               break;
            case 13:
               var9 = 238;
               break;
            case 14:
               var9 = 163;
               break;
            case 15:
               var9 = 75;
               break;
            case 16:
               var9 = 255;
               break;
            case 17:
               var9 = 214;
               break;
            case 18:
               var9 = 252;
               break;
            case 19:
               var9 = 147;
               break;
            case 20:
               var9 = 166;
               break;
            case 21:
               var9 = 205;
               break;
            case 22:
               var9 = 40;
               break;
            case 23:
               var9 = 181;
               break;
            case 24:
               var9 = 75;
               break;
            case 25:
               var9 = 189;
               break;
            case 26:
               var9 = 208;
               break;
            case 27:
               var9 = 62;
               break;
            case 28:
               var9 = 1;
               break;
            case 29:
               var9 = 12;
               break;
            case 30:
               var9 = 151;
               break;
            case 31:
               var9 = 70;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
