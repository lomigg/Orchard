package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class IllllIIl extends lIIlIIII {
   private static String[] I;
   private static final int[] lIIl;
   private static final String[] lIll;
   private static final Object[] llII;

   public IllllIIl() {
      super(lIlIII.l(I[1]), lIlIII.l(I[0]), null.Il, false);
   }

   private static void lIlIl() {
      I[0] = lIllI(llIIl(-1356888625, 799564207).toCharArray(), 6205L, lIlll(1258452591, -19850663));
      I[1] = lIllI(llIIl(-1356888626, 450434294).toCharArray(), 41430L, lIlll(1258452590, -784124968));
   }

   private static String lIllI(char[] var0, long var1, int var3) {
      int var4 = lIlll(1258452589, 1564328779) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & lIlll(1258452588, 1714023290);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   static {
      short var6 = 5622;
      String var7 = "ꄺ\uddedꪌ襰ᑶ\uec7a뾱╇擵熼뗥\uebd9錅শ뀄▥ꆩ࡞蕖踵ᶩ逇扄馷荙鄐꠪쫩쩛娴䐗抜앓蘤侚\uf728\udbfc惘땰䌒罔བⱬ秒瘈宨疇霒筤形\udb27욛뀺ᇚ᮪㕗밷\uec52\uee0f籽ꆐꆣ么ﱍ";
      char[] var8 = "ᗆᗦ".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            lIll = var9;
            llII = new Object[var9.length];
            int var2 = -398979820;
            byte[] var0 = "\u0006vÙå;\u0098\u0096\u000bKÜ\u009e\u008dÅ\u0013\u0090ý".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lIIl = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lIIl[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            I = new String[2];
            lIlIl();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static int lIlll(int var0, int var1) {
      return lIIl[var0 ^ 1258452591] ^ var1 ^ var0;
   }

   private static String llIIl(int var0, int var1) {
      int var3 = var0 ^ -1356888625;
      char[] var4 = lIll[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])llII[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         llII[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 222880289;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 124;
               break;
            case 1:
               var9 = 198;
               break;
            case 2:
               var9 = 102;
               break;
            case 3:
               var9 = 166;
               break;
            case 4:
               var9 = 254;
               break;
            case 5:
               var9 = 109;
               break;
            case 6:
               var9 = 219;
               break;
            case 7:
               var9 = 208;
               break;
            case 8:
               var9 = 250;
               break;
            case 9:
               var9 = 144;
               break;
            case 10:
               var9 = 149;
               break;
            case 11:
               var9 = 71;
               break;
            case 12:
               var9 = 172;
               break;
            case 13:
               var9 = 156;
               break;
            case 14:
               var9 = 104;
               break;
            case 15:
               var9 = 92;
               break;
            case 16:
               var9 = 231;
               break;
            case 17:
               var9 = 213;
               break;
            case 18:
               var9 = 27;
               break;
            case 19:
               var9 = 114;
               break;
            case 20:
               var9 = 150;
               break;
            case 21:
               var9 = 106;
               break;
            case 22:
               var9 = 214;
               break;
            case 23:
               var9 = 104;
               break;
            case 24:
               var9 = 242;
               break;
            case 25:
               var9 = 64;
               break;
            case 26:
               var9 = 202;
               break;
            case 27:
               var9 = 10;
               break;
            case 28:
               var9 = 178;
               break;
            case 29:
               var9 = 252;
               break;
            case 30:
               var9 = 3;
               break;
            case 31:
               var9 = 213;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
