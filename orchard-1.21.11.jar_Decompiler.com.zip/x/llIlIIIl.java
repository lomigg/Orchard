package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2480;
import net.minecraft.class_310;
import net.minecraft.class_3965;

@Environment(EnvType.CLIENT)
public final class llIlIIIl extends IIIIIIIlI {
   private static String[] I;
   private static final int[] l;
   private static final String[] II;
   private static final Object[] Il;

   private static void l() {
      I[0] = II(lII(106782348, (short)'誧', 36108).toCharArray(), 83952L, IlI(1160642246, -1808731629));
      I[1] = II(lII(-1379377380, (short)'ﶚ', 36109).toCharArray(), 87464L, IlI(1160642247, -849565282));
   }

   private static String II(char[] var0, long var1, int var3) {
      int var4 = IlI(1160642244, 1720515167) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IlI(1160642245, 1406321136);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   public llIlIIIl() {
      super((Object)lIlIII.l(I[1]), lIllII.l, (Object)lIlIII.l(I[0]));
   }

   static {
      short var6 = 9243;
      String var7 = "⫣獣ᩝ墚ᎍ쌻㗼墵\ueeeb\uf88dႠꗂ力딽\uf5dd莟Ꚃ楶㎃팳跬䅰：Ⳗ饰㳕\ue571¢钪眇狝쥸ᢂ\ue5ff殎섭疃鄷ཻ릊ꖲ㋷ﯧᙰᦕ┬೧耍崌\uea33Ð밒撨祈Ⲫ뿫쒣襊鰧ƪ\ued70揋临\uda8a牬ш몁깎㎙냅㖭㝶㠝殏\uee01ɇ硫懪둍爿ﮒ鞰㧴╞෦蛷荚犪";
      char[] var8 = "H\u0010".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            II = var9;
            Il = new Object[var9.length];
            int var2 = 994039781;
            byte[] var0 = "È#ê qör\u00196û¯|-Àè/".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            l = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               l[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            I = new String[2];
            l();
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 27;
                     break;
                  case 1:
                     var10000 = 87;
                     break;
                  case 2:
                     var10000 = 60;
                     break;
                  case 3:
                     var10000 = 74;
                     break;
                  case 4:
                     var10000 = 44;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public boolean ll(class_310 var1, class_3965 var2) {
      if (this.IIIIIlI() && var1 != null && var1.field_1687 != null && var2 != null) {
         class_2248 var3 = var1.field_1687.method_8320(var2.method_17777()).method_26204();
         return var3 == class_2246.field_10034 || var3 == class_2246.field_10380 || var3 == class_2246.field_10443 || var3 == class_2246.field_16328 || var3 instanceof class_2480;
      } else {
         return false;
      }
   }

   private static int IlI(int var0, int var1) {
      return l[var0 ^ 1160642246] ^ var1 ^ var0;
   }

   private static String lII(int var0, short var1, int var2) {
      int var3 = var2 ^ '贌';
      char[] var4 = II[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])Il[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         Il[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 28975;
      int var9 = 0;

      do {
         int var10 = var4[var9] - 6446;
         var10 += 24160;
         var10 ^= 52757;
         var10 -= 12774;
         var10 -= 46207;
         var10 += 13;
         var10 += 12755;
         var10 ^= 38805;
         var4[var9] = (char)(var10 ^ var8 ^ var1 ^ var0 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
