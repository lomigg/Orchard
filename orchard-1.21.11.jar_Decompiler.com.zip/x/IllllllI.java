package x;

import java.util.Locale;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_746;

@Environment(EnvType.CLIENT)
public final class IllllllI extends IIIIIIIlI {
   private final lIIIIl I;
   private final IIIllIIII l;
   private static String[] II;
   private static final int[] Il;
   private static final String[] lI;
   private static final Object[] ll;

   static {
      short var6 = 10886;
      String var7 = "櫢ʋ⃀腗Ѿ\ue64f䲃氰㏈ָꌠ馪讉㩯㸿ฝﹼ냗᎙\ue562놇쵹䔔숴幕\uf17e廁\ue7e8둜\udb6b๕\uec0eᤕ\u0099蕮늎\ued97᬴ನ岇茆\ue3b3\ua7ee洷㚎溣‧\ue91f敬\u2063ﲵг낹\uda62ꖎ鞤咐뎯㩙㋜깖쩵爃ꄿᬦ漍묂Ჯ⩮\ue190ꭑ⥵밈똀া㱅갞ꁓ⎇霘计跒\uda86뒧ڢ佭陔ꎼ䲫眨এ⎬फ䊎곈ᠧ\uf8f5칀鲿ࡣ";
      char[] var8 = "⪎⪶⪖⪊⪎⪎".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            lI = var9;
            ll = new Object[var9.length];
            int var2 = -94925940;
            byte[] var0 = "\u0086¼U5]W*\u00891v:ê+Päù\u0002û+\u001at\u009e\u0085Ö!@,¬û§Ö8\u008aæ§é".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            Il = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               Il[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            II = new String[lll(-1294701951, -834685890)];
            ll();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public IllllllI() {
      super((Object)lIlIII.l(II[0]), lIllII.III, (Object)lIlIII.l(II[1]));
      this.l = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(II[3]), (double)3.0F, (double)-10.0F, (double)10.0F, (double)1.0F)).IIl(lIlIII.Il(II[4])));
      this.I = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(II[2]), true));
   }

   private static void ll() {
      II[0] = lII(IIII(1571959475, 1570335590).toCharArray(), 17914L, lll(-1294701952, 1123584114));
      II[1] = lII(IIII(1571959474, 331972212).toCharArray(), 7748L, lll(-1294701949, 41507671));
      II[2] = lII(IIII(1571959473, 1416842518).toCharArray(), 51357L, lll(-1294701950, -659704933));
      II[3] = lII(IIII(1571959472, 271997106).toCharArray(), 81144L, lll(-1294701947, -28888315));
      II[4] = lII(IIII(1571959479, -392880540).toCharArray(), 11153L, lll(-1294701948, 629886809));
      II[5] = lII(IIII(1571959478, 857343599).toCharArray(), 67993L, lll(-1294701945, 1604424919));
   }

   private static String lII(char[] var0, long var1, int var3) {
      int var4 = lll(-1294701946, 728170820) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & lll(-1294701943, -1033550317);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   public String Il() {
      return String.format(Locale.ROOT, lIlIII.Il(II[5]), this.l.III());
   }

   public void lIl() {
      class_310 var1 = class_310.method_1551();
      if (var1.field_1724 != null && var1.field_1687 != null && var1.method_1562() != null) {
         double var2 = (Double)this.l.III();
         var1.execute(() -> this.llI(var1, var1.field_1724, var2));
         this.IIIllIl(false);
      } else {
         this.IIIllIl(false);
      }
   }

   private void llI(class_310 var1, class_746 var2, double var3) {
      if (var2 != null && !(Math.abs(var3) < 1.0E-4)) {
         double var5 = var2.method_23317();
         double var7 = var2.method_23318() + var3;
         double var9 = var2.method_23321();
         var2.method_5814(var5, var7, var9);
         IIlllllI.IlII(var2, var5);
         IIlllllI.lI(var2, var7);
         IIlllllI.IIll(var2, var9);
         IIlllllI.IllI(var2, 0);
         IllllIlI.lll(var1, var5, var7, var9, var2.method_24828());
         if ((Boolean)this.I.III()) {
            var2.method_18800((double)0.0F, (double)0.0F, (double)0.0F);
         }

         var2.field_6017 = (double)0.0F;
      }
   }

   private static int lll(int var0, int var1) {
      return Il[var0 ^ -1294701951] ^ var1 ^ var0;
   }

   private static String IIII(int var0, int var1) {
      int var3 = var0 ^ 1571959475;
      char[] var4 = lI[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])ll[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         ll[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 1803783;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 122;
               break;
            case 1:
               var9 = 249;
               break;
            case 2:
               var9 = 71;
               break;
            case 3:
               var9 = 240;
               break;
            case 4:
               var9 = 78;
               break;
            case 5:
               var9 = 170;
               break;
            case 6:
               var9 = 71;
               break;
            case 7:
               var9 = 67;
               break;
            case 8:
               var9 = 69;
               break;
            case 9:
               var9 = 155;
               break;
            case 10:
               var9 = 61;
               break;
            case 11:
               var9 = 91;
               break;
            case 12:
               var9 = 202;
               break;
            case 13:
               var9 = 14;
               break;
            case 14:
               var9 = 231;
               break;
            case 15:
               var9 = 169;
               break;
            case 16:
               var9 = 188;
               break;
            case 17:
               var9 = 89;
               break;
            case 18:
               var9 = 0;
               break;
            case 19:
               var9 = 182;
               break;
            case 20:
               var9 = 151;
               break;
            case 21:
               var9 = 125;
               break;
            case 22:
               var9 = 127;
               break;
            case 23:
               var9 = 249;
               break;
            case 24:
               var9 = 139;
               break;
            case 25:
               var9 = 184;
               break;
            case 26:
               var9 = 183;
               break;
            case 27:
               var9 = 122;
               break;
            case 28:
               var9 = 107;
               break;
            case 29:
               var9 = 233;
               break;
            case 30:
               var9 = 64;
               break;
            case 31:
               var9 = 102;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
