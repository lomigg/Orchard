package x;

import com.mojang.authlib.GameProfile;
import java.util.UUID;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;

@Environment(EnvType.CLIENT)
public final class IIIIIl extends IIIIIIIlI {
   private final IlIIIlIlI<<undefinedtype>> I;
   private static String[] l;
   private static final int[] II;
   private static final String[] Il;
   private static final Object[] lI;

   public void lI() {
      x.Il.IlIl((IIIIIl)null);
   }

   public void lIl() {
      x.Il.IlIl(this);
   }

   public boolean I(UUID var1) {
      return x.Il.IllI(var1);
   }

   private static String l(char[] var0, long var1, int var3) {
      int var4 = IIII(-303670060, -246557084) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IIII(-303670059, 1680986325);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   public String II() {
      return null;
   }

   public IIIIIl() {
      super((Object)lIlIII.l(l[1]), lIllII.ll, (Object)lIlIII.l(l[0]));
      this.I = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(l[2]), <undefinedtype>.class, null.ll));
   }

   public String Il() {
      return ((<undefinedtype>)this.I.III()).lI();
   }

   public boolean ll(class_1657 var1) {
      return var1 != null && this.I(var1.method_5667());
   }

   public void Ill() {
      x.Il.IlIl(this.IIIIIlI() ? this : null);
   }

   public <undefinedtype> III() {
      return null;
   }

   private static void IIl() {
      l[0] = l(IIll(-2037511947, -414888888).toCharArray(), 54532L, IIII(-303670058, -1108474751));
      l[1] = l(IIll(-2037511948, 1417619009).toCharArray(), 43413L, IIII(-303670057, 978607489));
      l[2] = l(IIll(-2037511945, 1779565844).toCharArray(), 47005L, IIII(-303670064, 1690183331));
      l[3] = l("".toCharArray(), 12201L, IIII(-303670063, 2102541411));
      l[4] = l(IIll(-2037511946, 924269718).toCharArray(), 60108L, IIII(-303670062, -398152875));
   }

   static {
      short var6 = 2786;
      String var7 = "郱腱쏬伷뭊\ue4e4燑킁킊ӽ㑯␐䗞\uf66bੋ裞\uf515룿肼㙿媅病蝎ᶧ\udd18\udb20愼쳜븓宥Ο쒢\ue4b5뙘灑꒐쎷ኡ黐Ἃ箏싐⭇䒻ꍇ㵏䱮≹\uf8eaጘ뷂亊ᄯ䘢ᚾ▤邃槬话㴑\udfbe웗외裇긬\uf8f3쌖嫗쁻ሐ唽⺜顗땈\u20f3\u31ea툕岸闋耞\ue8d6\u2e79䏫⦍桞ꨃ\u0a46襝怵壂毇\ue196植\uddb1莜ᯏꚔ\u0c54ᬢ벡締\ud7c7퀵及⪐熙佛彏\uee6b춼㩨⚍治혌轲纀\u0eef㬿渕譩";
      char[] var8 = "શ\u0af2૪૮".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            Il = var9;
            lI = new Object[var9.length];
            int var2 = -267696816;
            byte[] var0 = "¯:+æyÜÉ¯Æ®ºa\u0003³\u009fÎ\u001b\u0007\u007f§f5\u0012\u0003MÐjû".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            II = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               II[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            l = new String[5];
            IIl();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public boolean IlI() {
      return false;
   }

   public <undefinedtype> lII() {
      return (<undefinedtype>)this.I.III();
   }

   public String llI() {
      String var10000;
      switch (((<undefinedtype>)this.I.III()).ordinal()) {
         case 0 -> var10000 = l[3];
         case 1 -> var10000 = l[3];
         case 2 -> var10000 = lIlIII.Il(l[4]);
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   public boolean lll(GameProfile var1) {
      return var1 != null && this.I(IIIIlII.I(var1));
   }

   private static int IIII(int var0, int var1) {
      return II[var0 ^ -303670060] ^ var1 ^ var0;
   }

   private static String IIll(int var0, int var1) {
      int var3 = var0 ^ -2037511947;
      char[] var4 = Il[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])lI[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         lI[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -1935165430;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 88;
               break;
            case 1:
               var9 = 138;
               break;
            case 2:
               var9 = 194;
               break;
            case 3:
               var9 = 172;
               break;
            case 4:
               var9 = 172;
               break;
            case 5:
               var9 = 209;
               break;
            case 6:
               var9 = 84;
               break;
            case 7:
               var9 = 81;
               break;
            case 8:
               var9 = 169;
               break;
            case 9:
               var9 = 60;
               break;
            case 10:
               var9 = 240;
               break;
            case 11:
               var9 = 51;
               break;
            case 12:
               var9 = 234;
               break;
            case 13:
               var9 = 116;
               break;
            case 14:
               var9 = 15;
               break;
            case 15:
               var9 = 99;
               break;
            case 16:
               var9 = 35;
               break;
            case 17:
               var9 = 159;
               break;
            case 18:
               var9 = 20;
               break;
            case 19:
               var9 = 69;
               break;
            case 20:
               var9 = 50;
               break;
            case 21:
               var9 = 146;
               break;
            case 22:
               var9 = 191;
               break;
            case 23:
               var9 = 187;
               break;
            case 24:
               var9 = 187;
               break;
            case 25:
               var9 = 125;
               break;
            case 26:
               var9 = 95;
               break;
            case 27:
               var9 = 84;
               break;
            case 28:
               var9 = 209;
               break;
            case 29:
               var9 = 164;
               break;
            case 30:
               var9 = 25;
               break;
            case 31:
               var9 = 244;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
