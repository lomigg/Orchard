package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2684;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_465;
import net.minecraft.class_636;
import net.minecraft.class_746;
import y.IIlIl;
import y.lIIllll;
import y.lIlIIIl;
import y.llIII;
import y.lllIllIl;
import y.lllll;
import y.llllllIl;
import y.lllllll;

@Environment(EnvType.CLIENT)
public final class IIlllllI {
   public static float I(class_746 var0) {
      return ((lllll)var0).virel$getLastPitchClient();
   }

   public static int l(class_636 var0) {
      return ((llIII)var0).q96_getLastSelectedSlot();
   }

   public static void II(class_310 var0, int var1) {
      ((lIIllll)var0).q96_setAtkCd(var1);
   }

   public static void Il(class_746 var0, float var1) {
      ((lllll)var0).virel$setLastPitchClient(var1);
   }

   public static void lI(class_746 var0, double var1) {
      ((lllll)var0).virel$setLastYClient(var1);
   }

   public static void ll(class_310 var0) {
      ((lIIllll)var0).q96_doItemUse();
   }

   public static void III(class_636 var0) {
      ((llIII)var0).q96_invokeSyncSelectedSlot();
   }

   public static class_1799 IIl(class_636 var0) {
      return ((llIII)var0).q96_getSelectedStack();
   }

   public static void IlI(class_1309 var0, int var1) {
      ((IIlIl)var0).virel$setJumpingCooldown(var1);
   }

   public static int Ill(class_310 var0) {
      return ((lIIllll)var0).q96_getAtkCd();
   }

   public static void lII(class_636 var0, class_1799 var1) {
      ((llIII)var0).q96_setSelectedStack(var1);
   }

   public static int lIl(class_636 var0) {
      return ((llIII)var0).q96_getBbCooldown();
   }

   public static void llI(class_746 var0, float var1) {
      ((lllll)var0).virel$setLastYawClient(var1);
   }

   public static void lll(class_304 var0, int var1) {
      ((lllIllIl)var0).virel$setTimesPressed(var1);
   }

   public static void IIII(class_636 var0, int var1) {
      ((llIII)var0).q96_setBbCooldown(var1);
   }

   public static int IIIl(class_1661 var0) {
      return ((llllllIl)var0).q96_getSelectedSlot();
   }

   public static double IIlI(class_746 var0) {
      return ((lllll)var0).virel$getLastXClient();
   }

   private IIlllllI() {
   }

   public static void IIll(class_746 var0, double var1) {
      ((lllll)var0).virel$setLastZClient(var1);
   }

   public static void IlII(class_746 var0, double var1) {
      ((lllll)var0).virel$setLastXClient(var1);
   }

   public static void IlIl(class_310 var0, int var1) {
      ((lIIllll)var0).q96_setUseCd(var1);
   }

   public static void IllI(class_746 var0, int var1) {
      ((lllll)var0).virel$setTicksSinceLastPositionPacketSent(var1);
   }

   public static int Illl(class_2684 var0) {
      return ((lllllll)var0).ilovcats$getId();
   }

   public static double lIII(class_746 var0) {
      return ((lllll)var0).virel$getLastZClient();
   }

   public static class_1735 lIIl(class_465<?> var0) {
      return ((lIlIIIl)var0).q96fbb2be();
   }

   public static int lIlI(class_310 var0) {
      return ((lIIllll)var0).q96_getUseCd();
   }

   public static void lIll(class_636 var0, int var1) {
      ((llIII)var0).q96_setLastSelectedSlot(var1);
   }

   public static void llII(class_1661 var0, int var1) {
      ((llllllIl)var0).q96_setSelectedSlot(var1);
   }

   public static void llIl(class_310 var0, int var1) {
      ((lIIllll)var0).q96_setUseCd(var1);
   }

   public static boolean lllI(class_310 var0) {
      return ((lIIllll)var0).q96_doAttack();
   }

   public static double llll(class_746 var0) {
      return ((lllll)var0).virel$getLastYClient();
   }

   public static float IIIII(class_746 var0) {
      return ((lllll)var0).virel$getLastYawClient();
   }

   public static int IIIIl(class_304 var0) {
      return ((lllIllIl)var0).virel$getTimesPressed();
   }

   public static class_3675.class_306 IIIlI(class_304 var0) {
      return ((lllIllIl)var0).virel$getBoundKey();
   }

   public static int IIIll(class_746 var0) {
      return ((lllll)var0).virel$getTicksSinceLastPositionPacketSent();
   }

   public static boolean IIlII(class_636 var0) {
      return ((llIII)var0).q96_isBreakingBlock();
   }
}
