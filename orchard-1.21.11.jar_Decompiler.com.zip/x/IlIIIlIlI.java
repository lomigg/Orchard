package x;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class IlIIIlIlI<E extends Enum<E>> extends llllllI<E> {
   private final Class<E> I;
   private static final int[] l;

   public JsonElement lI() {
      return new JsonPrimitive(this.IlI((Enum)this.III()));
   }

   public void II(JsonElement var1) {
      if (var1 != null && var1.isJsonPrimitive()) {
         Enum var2 = this.lIl(var1.getAsString());
         if (var2 != null) {
            this.I(var2);
         }
      }

   }

   public void I(E var1) {
      super.Il(this.ll(var1));
   }

   private E ll(E var1) {
      if (var1 instanceof llIlllI var2) {
         return (E)var2.l();
      } else {
         return (E)var1;
      }
   }

   public String IlI(Enum<?> var1) {
      return var1 != null && this.I.isInstance(var1) ? (new StringBuilder(4)).append((char)llI(-544499111, 1360769543)).append(Integer.toString(var1.ordinal(), llI(-544499112, 194611417))).toString() : "";
   }

   public IlIIIlIlI(String var1, Class<E> var2, E var3) {
      this((Object)var1, var2, var3);
   }

   private boolean Ill(E var1) {
      boolean var10000;
      if (var1 instanceof llIlllI var2) {
         if (!var2.I()) {
            var10000 = false;
            return var10000;
         }
      }

      var10000 = true;
      return var10000;
   }

   public void lII() {
      Enum[] var1 = (Enum[])this.I.getEnumConstants();
      int var2 = ((Enum)this.III()).ordinal();

      for(int var3 = 0; var3 < var1.length; ++var3) {
         var2 = (var2 + 1) % var1.length;
         if (this.Ill(var1[var2])) {
            this.I(var1[var2]);
            return;
         }
      }

   }

   public IlIIIlIlI(Object var1, Class<E> var2, E var3) {
      super((Object)var1, var3);
      this.I = var2;
   }

   public E lIl(String var1) {
      if (var1 != null && !var1.isBlank()) {
         Enum[] var2 = (Enum[])this.I.getEnumConstants();
         if (var1.length() > 1 && var1.charAt(0) == llI(-544499109, 509850256)) {
            try {
               int var3 = Integer.parseInt(var1.substring(1), llI(-544499110, -421784288));
               if (var3 >= 0 && var3 < var2.length) {
                  return (E)var2[var3];
               }
            } catch (NumberFormatException var7) {
            }
         }

         for(Enum var6 : var2) {
            if (llllIIlI.l(var6, var1)) {
               return (E)var6;
            }
         }

         return null;
      } else {
         return null;
      }
   }

   private static int llI(int var0, int var1) {
      return l[var0 ^ -544499111] ^ var1 ^ var0;
   }

   static {
      int var2 = -866933357;
      byte[] var0 = "BÃ\u008d¨\u0018A·6\r»\u008d=õ\u0004*Í".getBytes("ISO-8859-1");
      int var1 = var0.length / 4;
      l = new int[var1];
      int var3 = 0;
      int var4 = 0;

      do {
         int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
         var5 ^= var2;
         l[var4] = var5;
         var3 += 4;
         ++var4;
      } while(var4 < var1);

   }
}
