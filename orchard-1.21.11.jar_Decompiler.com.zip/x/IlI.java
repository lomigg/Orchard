package x;

import java.awt.Color;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_310;

@Environment(EnvType.CLIENT)
public final class IlI extends IIIIIIIlI {
   private final lIIIlll I;
   private final IIllIlIII l;
   private static final String II;
   private final lIIIIl Il;
   private static String[] lI;
   private static final int[] ll;
   private static final String[] III;
   private static final Object[] IIl;

   private boolean ll(class_310 var1, llIIllI var2, class_1297 var3, float var4) {
      class_243 var5 = IIlIIIIl.IIIII(var3, var4);
      return IIlIIIIl.IIlIlI(var1, var2, var3, var5);
   }

   public IlI() {
      super((Object)lIlIII.l(lI[5]), lIllII.ll, (Object)lIlIII.l(lI[IIII(-1077631811, 859240356)]));
      this.l = (IIllIlIII)this.IIIlIll(new IIllIlIII(lIlIII.l(lI[4]), new Color(IIII(-1077631812, -896512680), IIII(-1077631809, -919696566), IIII(-1077631810, -132474633), IIII(-1077631815, -467124837))));
      this.Il = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(lI[3]), true));
      this.I = (lIIIlll)this.IIIlIll(new lIIIlll(lIlIII.l(lI[IIII(-1077631816, -1506263783)]), x.IlIllIl.llll(II, lIlIII.Il(lI[2])), lIlIII.Il(lI[2])));
   }

   public void lI() {
      IllllIll.I();
   }

   private static boolean IlI(String var0, Set<String> var1) {
      return var1.contains(var0.toLowerCase());
   }

   public void llIl(llIIllI var1) {
      if (this.IIIIIlI() && IIlIIIIl.IlIII(var1)) {
         class_310 var2 = class_310.method_1551();
         if (var2.field_1724 != null && var2.field_1687 != null) {
            float var3 = IllllIlI.IlIIIlI(var2);
            Color var4 = (Color)this.l.III();

            for(class_1297 var6 : var2.field_1687.method_18112()) {
               if (var6 instanceof class_1657) {
                  class_1657 var7 = (class_1657)var6;
                  if (IIlIIIIl.llIIl(var2, var7) && IllllIll.l(var7.method_5667()) && this.ll(var2, var1, var7, var3)) {
                     class_243 var8 = IIlIIIIl.IIIII(var7, var3);
                     if ((Boolean)this.Il.III()) {
                        String var9 = var7.method_5477().getString();
                        int var10 = (int)Math.ceil((double)var7.method_6032());
                        String var10001 = lIlIII.Il(lI[IIII(-1077631813, -63656728)]);
                        String var16 = lIlIII.Il(lI[IIII(-1077631814, 1030835871)]);
                        String var14 = var10001;
                        String var11 = var9 + var14 + var10 + var16;
                        class_243 var12 = var8.method_1031((double)0.0F, (double)var7.method_17682() + 0.3, (double)0.0F);
                        IIlIIIIl.lIlIl(var1, var11, var12, var4, (double)1.0F, false);
                     }
                  }
               }
            }

         }
      }
   }

   private Set<String> lII() {
      HashSet var1 = new HashSet();

      for(String var3 : (List)this.I.III()) {
         String var4 = var3 == null ? lI[0] : var3.trim();
         if (!var4.isEmpty()) {
            var1.add(var4.toLowerCase());
         }
      }

      return var1;
   }

   static {
      short var6 = 15942;
      String var7 = "諕ꀗ壚桎㚊\udc67\uebddᲕ훸驋?\u0e7c\ua7f0᧚䌉\uee3e勛䶊ࢸ鿖ᬻ䮅믲\uf6d2ᠶ흋땀酿\u1bf5ꕜ\ue826\u1cc9ጅ氎柡튆譁\uef20ɭﲒꌔ\uf302㓚톧乤룎؊蓣\uef58\u1759弽郏\ue2b5➥⇅幄˿춖킭ꌥ㈿灗냚彬ﳼ\ue7f0䅭諒揬圏㥜陀礕\uf7d8\ude53\ued1e獔쬗矚ឰ\u18ac⥑䖿癦붨᐀䵊ڮ䂿ꁷ⓵묑䮡縘\u1ade㛂측㔄禰泟牙돒요齐絸㔥⮻袚૾疡\ue7f5㜓臺햍䶚诃ꚹ듐왯⺺灤푟葄旈癉ຣॐ練颠\ue882袊뷜韐䟸ꔗ礣\u2060皻\uf22cୗᕛ齤㱩橦껩\udbff秜\uf633喨\uec43꽨˒껻䁝襓슳돵\uf528ハ㝐ᚣ\u0dc9拰庳ȇঊ\uf6d0핿ᜀꝅ犢ﻫ䁛ⴠ轗癭蚞䐘륨붊盿檌띪寯䍝ᑥ涫偙";
      char[] var8 = "㹞㹖㹊㹎㹒㸞㹊㹂㹂".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            III = var9;
            IIl = new Object[var9.length];
            int var2 = -523818472;
            byte[] var0 = "l5y\u0007\u0095\u0093Ã\u0003\u0096-\u0005ß§\u0019\u0016c»+³\u008eù;³¾£7\"CbrÀ4p¿V\u0092Jýä\u008b´+Û¤\u0094;oÈ\u0016\u001cØÙä\u0019`Ã6Ù\u001c\u009dâ\u001f\u0083\f>µ\u0001\u0016ÇÔU1øá\u0004Y¨¿¢w)/ñ¨éwãlï¦ÉÔ\u0016ë\b\u0015¯©U;".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            ll = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               ll[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            lI = new String[IIII(-1077631819, 800905269)];
            lll();
            II = lIlIII.Il(lI[1]);
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static String llI(char[] var0, long var1, int var3) {
      int var4 = IIII(-1077631820, 921099447) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & IIII(-1077631817, -349678092);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private static void lll() {
      lI[0] = llI("".toCharArray(), 10023L, IIII(-1077631818, 745895376));
      lI[1] = llI(IIll(-863011335, 1378357657).toCharArray(), 78009L, IIII(-1077631823, 768168776));
      lI[2] = llI(IIll(-863011336, 1261113578).toCharArray(), 53541L, IIII(-1077631824, -126484525));
      lI[3] = llI(IIll(-863011333, -461748710).toCharArray(), 1891L, IIII(-1077631821, -1304056464));
      lI[4] = llI(IIll(-863011334, 613819455).toCharArray(), 54224L, IIII(-1077631822, 1896331602));
      lI[5] = llI(IIll(-863011331, -446881512).toCharArray(), 26984L, IIII(-1077631827, 2028603354));
      lI[IIII(-1077631828, -1730684029)] = llI(IIll(-863011332, -1798474388).toCharArray(), 93105L, IIII(-1077631825, -1259514698));
      lI[IIII(-1077631826, -138662714)] = llI(IIll(-863011329, 1740596728).toCharArray(), 59282L, IIII(-1077631831, -1651317444));
      lI[IIII(-1077631832, -1233883692)] = llI(IIll(-863011330, 448598776).toCharArray(), 19497L, IIII(-1077631829, -2095046502));
      lI[IIII(-1077631830, 1239975598)] = llI(IIll(-863011343, -915782813).toCharArray(), 19529L, IIII(-1077631835, -1267475367));
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (var1.field_1724 != null && var1.field_1687 != null) {
         IllllIll.I();
         Color var2 = (Color)this.l.III();
         IllllIll.IIl(var2.getRGB());
         Set var3 = this.lII();
         if (!var3.isEmpty()) {
            for(class_1297 var5 : var1.field_1687.method_18112()) {
               if (var5 instanceof class_1657) {
                  class_1657 var6 = (class_1657)var5;
                  if (IIlIIIIl.llIIl(var1, var6) && IlI(var6.method_5477().getString(), var3)) {
                     IllllIll.III(var6.method_5667());
                  }
               }
            }

         }
      }
   }

   private static int IIII(int var0, int var1) {
      return ll[var0 ^ -1077631811] ^ var1 ^ var0;
   }

   private static String IIll(int var0, int var1) {
      int var3 = var0 ^ -863011335;
      char[] var4 = III[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IIl[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IIl[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 865727980;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 254;
               break;
            case 1:
               var9 = 211;
               break;
            case 2:
               var9 = 93;
               break;
            case 3:
               var9 = 160;
               break;
            case 4:
               var9 = 25;
               break;
            case 5:
               var9 = 254;
               break;
            case 6:
               var9 = 114;
               break;
            case 7:
               var9 = 245;
               break;
            case 8:
               var9 = 244;
               break;
            case 9:
               var9 = 193;
               break;
            case 10:
               var9 = 200;
               break;
            case 11:
               var9 = 59;
               break;
            case 12:
               var9 = 91;
               break;
            case 13:
               var9 = 61;
               break;
            case 14:
               var9 = 120;
               break;
            case 15:
               var9 = 215;
               break;
            case 16:
               var9 = 141;
               break;
            case 17:
               var9 = 178;
               break;
            case 18:
               var9 = 148;
               break;
            case 19:
               var9 = 159;
               break;
            case 20:
               var9 = 240;
               break;
            case 21:
               var9 = 133;
               break;
            case 22:
               var9 = 35;
               break;
            case 23:
               var9 = 140;
               break;
            case 24:
               var9 = 96;
               break;
            case 25:
               var9 = 3;
               break;
            case 26:
               var9 = 195;
               break;
            case 27:
               var9 = 90;
               break;
            case 28:
               var9 = 196;
               break;
            case 29:
               var9 = 188;
               break;
            case 30:
               var9 = 191;
               break;
            case 31:
               var9 = 27;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
