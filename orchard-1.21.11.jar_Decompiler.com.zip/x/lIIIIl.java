package x;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public final class lIIIIl extends llllllI<Boolean> {
   public JsonElement lI() {
      return new JsonPrimitive((Boolean)this.III());
   }

   public lIIIIl(String var1, boolean var2) {
      this((Object)var1, var2);
   }

   public void II(JsonElement var1) {
      if (var1 != null && var1.isJsonPrimitive()) {
         this.Il(var1.getAsBoolean());
      }

   }

   public lIIIIl(Object var1, boolean var2) {
      super((Object)var1, var2);
   }
}
