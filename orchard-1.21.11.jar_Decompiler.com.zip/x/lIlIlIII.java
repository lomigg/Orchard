package x;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_4184;
import net.minecraft.class_7923;
import net.minecraft.class_9362;

@Environment(EnvType.CLIENT)
public final class lIlIlIII extends IIIIIIIlI implements IlllIlII {
   private final IIIllIIII I;
   private boolean l;
   private final IIIllIIII II;
   private static final float Il = 0.0035F;
   private final lIIIIl lI;
   private float ll;
   private final IIIllIIII III;
   private static final float IIl = 0.05F;
   private static final float IlI = 1.07F;
   private static final float Ill = 0.35F;
   private final IIIllIIII lII;
   private final IIIllIIII lIl;
   private final IIIllIIII llI;
   private static final float lll = 2.5F;
   private static final <undefinedtype> IIII;
   private boolean IIIl;
   private final IIIllIIII IIlI;
   private final IIIIllIII IIll;
   private static final float IlII = 1.12F;
   private static final float IlIl = 0.065F;
   private static final float IllI = 0.018F;
   private final IIIllIIII Illl;
   private static final float lIII = 0.95F;
   private final lllIIlIl lIIl;
   private final lIIIIl lIlI;
   private final IIIllIIII lIll;
   private static final float llII = 0.55F;
   private final lIIIIl llIl;
   private static final int lllI = 4;
   private static final float llll = 1.08F;
   private final IIIllIIII IIIII;
   private float IIIIl;
   private float IIIlI;
   private final IIIllIIII IIIll;
   private static final float IIlII = 0.92F;
   private static final float IIlIl = 1.25F;
   private final IIIllIIII IIllI;
   private final IlIlIll IIlll;
   private final IIIllIIII IlIII;
   private static final float IlIIl = 0.005F;
   private static final float IlIlI = 0.3F;
   private final IlIIIlIlI<<undefinedtype>> IlIll;
   private static final float IllII = 0.1F;
   private float IllIl;
   private static final float IlllI = 0.022F;
   private static final float Illll = 0.07F;
   private final lIIIIl lIIII;
   private final IIIllIIII lIIIl;
   private static final float lIIlI = 0.04F;
   private static final <undefinedtype> lIIll;
   private float lIlII;
   private static final float lIlIl = 0.38F;
   private float lIllI;
   private final IIIllIIII lIlll;
   private static final float llIII = -90.0F;
   private final IIIllIIII llIIl;
   private static final float llIlI = 2.0F;
   private float llIll;
   private final IIIllIIII lllII;
   private float lllIl;
   private static final float llllI = 0.0125F;
   private static final float lllll = 3.0F;
   private static final float IIIIII = 2.6F;
   private boolean IIIIIl;
   private final IlIIIlIlI<<undefinedtype>> IIIIlI;
   private boolean IIIIll;
   private final lIIIIl IIIlII;
   private static final float IIIlIl = 0.018F;
   private final IIIllIIII IIIllI;
   private static final float IIIlll = 1.45F;
   private final IIIllIIII IIlIII;
   private static final float IIlIIl = 0.16F;
   private static final float IIlIlI = 0.94F;
   private static final float IIlIll = 0.2F;
   private final IIIllIIII IIllII;
   private static final float IIllIl = 6.5F;
   private static final float IIlllI = 0.0F;
   private static final float IIllll = 2.1F;
   private final IlIIIlIlI<<undefinedtype>> IlIIII;
   private final IIIllIIII IlIIIl;
   private class_243 IlIIlI;
   private float IlIIll;
   private float IlIlII;
   private static final float IlIlIl = 2.7F;
   private float IlIllI;
   private final IIIllIIII IlIlll;
   private static final float IllIII = 0.6F;
   private long IllIIl;
   private static final float IllIlI = 0.035F;
   private final IIIllIIII IllIll;
   private float IlllII;
   private static final float IlllIl = 0.0015F;
   private static final float IllllI = 0.06666667F;
   private float Illlll;
   private static final float lIIIII = 0.4F;
   private static final float lIIIIl = 0.65F;
   private float lIIIlI;
   private float lIIIll;
   private float lIIlII;
   private static final float lIIlIl = 0.0015F;
   private static final float lIIllI = 0.91F;
   private static final float lIIlll = 0.052F;
   private float lIlIII;
   private static final float lIlIIl = 0.8F;
   private static final float lIlIlI = 0.18F;
   private static final float lIlIll = 1.06F;
   private float lIllII;
   private float lIllIl;
   private long lIlllI;
   private static final float lIllll = 0.016F;
   private static final float llIIII = 0.024F;
   private static final float llIIIl = 0.88F;
   private final IIIllIIII llIIlI;
   private final IIIllIIII llIIll;
   private static final float llIlII = 0.38F;
   private final IIIllIIII llIlIl;
   private float llIllI;
   private float llIlll;
   private static final float lllIII = 0.025F;
   private static final double lllIIl = 1.0E-6;
   private long lllIlI;
   private static final float lllIll = 1.8F;
   private static final float llllII = 0.18F;
   private float llllIl;
   private int lllllI;
   private float llllll;
   private final IIIllIIII IIIIIII;
   private final <undefinedtype> IIIIIIl;
   private static final float IIIIIlI = 0.42F;
   private int IIIIIll;
   private final IIIllIIII IIIIlII;
   private static final float IIIIlIl = 179.0F;
   private float IIIIllI;
   private float IIIIlll;
   private long IIIlIII;
   private float IIIlIIl;
   private static final float IIIlIlI = 14.0F;
   private final lIlllII IIIlIll;
   private float IIIllII;
   private static final int IIIllIl = 4;
   private float IIIlllI;
   private static final float IIIllll = 1.4F;
   private final IIIllIIII IIlIIII;
   private final IIIllIIII IIlIIIl;
   private static final List<<undefinedtype>> IIlIIlI;
   private final <undefinedtype> IIlIIll;
   private static final float IIlIlII = 0.016666668F;
   private static final <undefinedtype> IIlIlIl;
   private final lIIIIl IIlIllI;
   private float IIlIlll;
   private float IIllIII;
   private static final float IIllIIl = 0.76F;
   private float IIllIlI;
   private final IIIllIIII IIllIll;
   private final <undefinedtype> IIlllII;
   private float IIlllIl;
   private float IIllllI;
   private float IIlllll;
   private float IlIIIII;
   private static final float IlIIIIl = 0.14F;
   private static final float IlIIIlI = 0.72F;
   private float IlIIIll;
   private static final float IlIIlII = 0.01F;
   private final lIIIIl IlIIlIl;
   private static final float IlIIllI = 90.0F;
   private int IlIIlll;
   private static final int[] IlllIll;
   private static final String[] IllllII;
   private static final Object[] IllllIl;

   private double l(class_310 var1, Object var2) {
      return var1 != null && var1.field_1724 != null && var2 != null && var2.ll() != null ? var1.field_1724.method_33571().method_1022(var2.ll()) : Double.POSITIVE_INFINITY;
   }

   private float II(int var1) {
      return (float)(var1 & IlIlIII(-981072953, 140347182)) / (float)Integer.MAX_VALUE;
   }

   private float ll(float var1) {
      for(this.lIllII += Math.max(0.0F, var1) * 2.1F; this.lIllII >= 1.0F; this.lIIIll = ThreadLocalRandom.current().nextFloat() * 2.0F - 1.0F) {
         --this.lIllII;
         this.ll = this.lIIIll;
      }

      float var2 = class_3532.method_15363(this.lIllII, 0.0F, 1.0F);
      float var3 = var2 * var2 * (3.0F - 2.0F * var2);
      return class_3532.method_16439(var3, this.ll, this.lIIIll) * 0.0035F;
   }

   private int III(int var1) {
      int var2 = var1 ^ var1 << IlIlIII(-981072954, -2111537157);
      var2 ^= var2 >>> IlIlIII(-981072955, 537800904);
      var2 ^= var2 << 5;
      return var2;
   }

   private <undefinedtype> IlI(float var1, float var2, float var3, float var4, boolean var5, float var6, float var7, float var8, boolean var9) {
      float var10 = this.IlIllI(var7, var8);
      float var11 = this.Illll(var4, var7, var8);
      float var12 = class_3532.method_15363(var6, 0.0033333334F, 0.055555556F);
      if (var5) {
         return new Record(var1, this.llIIl(var3, 0.0F, var11 * var12 * 1.25F)) {
            private final float I;
            private final float l;

            private {
               this.I = var1;
               this.l = var2;
            }

            public float I() {
               return this.I;
            }

            public float l() {
               return this.l;
            }
         };
      } else if (this.IlIll.III() != null.lI && this.IlIll.III() != null.l) {
         return var9 ? this.IlIII(var1, var2, var3, var10, var11, var12) : this.IlIIlI(var1, this.IIlll(var2), var3, var10, var11, var12);
      } else {
         return this.lIIll(var1, var2, var11, var12, var7, var9, (<undefinedtype>)this.IlIll.III());
      }
   }

   private float lII() {
      return this.IIII(0.38F, 0.16F, this.lIllll());
   }

   private boolean llI() {
      lIllIIl var1 = lIllIIl.Il();
      if (var1 == null) {
         return false;
      } else {
         lIIlllll var2 = var1.IIl().IIlIIl();
         return var2 != null && var2.IIIIIlI() && var2.ll();
      }
   }

   private float lll() {
      return this.IIII(1.8F, 2.6F, this.lIllll());
   }

   private float IIII(float var1, float var2, float var3) {
      return class_3532.method_16439(class_3532.method_15363(var3, 0.0F, 1.0F), var1, var2);
   }

   private float IIIl(float var1) {
      if (this.llIIII()) {
         return 0.0F;
      } else if (this.llllIl <= 0.2F) {
         return 0.0F;
      } else {
         float var2 = Math.max(1.0E-4F, 0.2F);
         float var3 = class_3532.method_15363((this.llllIl - 0.2F) / var2, 0.0F, 1.0F);
         var3 = var3 * var3 * (3.0F - 2.0F * var3);
         float var4 = class_3532.method_15363(1.0F - var1, 0.0F, 1.0F);
         return var3 * var4;
      }
   }

   private boolean IIlI(Object var1) {
      boolean var10000;
      switch (var1) {
         case l -> var10000 = this.IIll.IIII(IIlIlIl);
         case I -> var10000 = this.IIll.IIII(IIII);
         case Il -> var10000 = this.IIll.IIII(lIIll);
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   public void IIIlI(class_332 var1, int var2, int var3, float var4) {
      this.IlllIl();
      class_310 var5 = class_310.method_1551();
      this.lIlIlI(var5, false);
      boolean var6 = !this.llI() && this.llIII(var5);
      this.IIlll.llIIlI(var5, this.lIIIl(), var6, var6 ? this.Illlll(var5) : null, this.llIIII());
   }

   private <undefinedtype> IIll(class_310 var1) {
      if (this.IlIIII.III() == null.l) {
         <undefinedtype> var2 = this.IIlIlI(var1, this.IIIlIll.Ill(), true);
         if (var2 != null) {
            return var2;
         }
      }

      <undefinedtype> var7 = null;

      for(class_1297 var4 : var1.field_1687.method_18112()) {
         if (var4 instanceof class_1309 var5) {
            <undefinedtype> var6 = this.IIlIlI(var1, var5, false);
            if (var6 != null && (var7 == null || this.llIll(var6, var7))) {
               var7 = var6;
            }
         }
      }

      return var7;
   }

   private boolean IlII(class_310 var1, class_1309 var2, Object var3, class_1309 var4, Object var5) {
      if (var5 == null) {
         return true;
      } else {
         double var6 = this.l(var1, var3);
         double var8 = this.l(var1, var5);
         double var10 = (double)(var3.IlI() * var3.Il());
         double var12 = (double)(var5.IlI() * var5.Il());
         double var14 = var2 == null ? Double.POSITIVE_INFINITY : (double)var2.method_6032();
         double var16 = var4 == null ? Double.POSITIVE_INFINITY : (double)var4.method_6032();
         boolean var10000;
         switch (((<undefinedtype>)this.IlIIII.III()).ordinal()) {
            case 0:
            case 3:
               var10000 = this.IIllll(var10, var12, var6, var8, var14, var16);
               break;
            case 1:
               var10000 = this.IIllll(var6, var8, var10, var12, var14, var16);
               break;
            case 2:
               var10000 = this.IIllll(var14, var16, var6, var8, var10, var12);
               break;
            default:
               throw new MatchException((String)null, (Throwable)null);
         }

         return var10000;
      }
   }

   private class_243 IlIl(class_243 var1, class_1309 var2) {
      class_238 var3 = var2.method_5829();
      return new class_243(class_3532.method_15350(var1.field_1352, var3.field_1323, var3.field_1320), class_3532.method_15350(var1.field_1351, var3.field_1322, var3.field_1325), class_3532.method_15350(var1.field_1350, var3.field_1321, var3.field_1324));
   }

   private float Illl(Object var1, float var2, float var3) {
      float var4 = this.lIlIll(var2, var3);
      float var5 = Math.max(this.lIIIll(), 1.0F);
      float var6 = class_3532.method_15363(var4 / var5, 0.0F, 1.0F);
      return Math.max(var1.I(), var6);
   }

   private <undefinedtype> lIII(class_310 var1, class_1309 var2, Object var3, boolean var4) {
      if (!this.IllIII(var1, var2)) {
         return null;
      } else if (this.IlIIII.III() == null.II) {
         class_243 var5 = this.IIlIIl(var1);
         return var5 == null ? null : this.IIlll.lIIII(var1, var2, var3, var4, false, var1.field_1724.method_33571(), var5);
      } else {
         return this.IIlll.IIlIlI(var1, var2, var3, var4);
      }
   }

   private float lIIl(int var1, int var2, int var3, float var4, float var5) {
      int var6 = this.III(var1 * IlIlIII(-981072956, 835670118) + var3 * IlIlIII(-981072957, -815200871) + var2);
      int var7 = Math.floorMod(var6, 3);
      float var8 = this.II(this.III(var1 * IlIlIII(-981072958, 2109183592) + var3 * IlIlIII(-981072959, 396120675) + var2 * 3));
      float var9 = this.IIII(var4, 0.992F, 0.72F);
      float var10 = this.IIII(1.008F, var5, 0.28F);
      float var10000;
      switch (var7) {
         case 0 -> var10000 = this.IIII(var4, var9, var8);
         case 1 -> var10000 = this.IIII(var10, var5, var8);
         default -> var10000 = this.IIII(var9, var10, var8);
      }

      return var10000;
   }

   private float lIll(class_310 var1) {
      if (var1 != null && var1.field_1690 != null) {
         double var2;
         try {
            var2 = (Double)var1.field_1690.method_42495().method_41753();
         } catch (Exception var8) {
            var2 = (double)0.5F;
         }

         double var4 = var2 * 0.6 + 0.2;
         double var6 = var4 * var4 * var4;
         return (float)(var6 * (double)8.0F * 0.15);
      } else {
         return 0.0F;
      }
   }

   public lIlIlIII(lIlllII var1) {
      super(x.lIlIII.Il(IlIlIIl(8187, 62490, -1170178063)), x.lIllII.I, x.lIlIII.Il(IlIlIIl(31610, 62491, -2593382)));
      this.IlIll = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(x.lIlIII.Il(IlIlIIl(3358, 62488, -801294565)), <undefinedtype>.class, null.III));
      this.IlIIII = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(x.lIlIII.Il(IlIlIIl(40187, 62489, 2090745368)), <undefinedtype>.class, null.II));
      this.lIIIl = (IIIllIIII)this.IIIlIll((new IIIllIIII(x.lIlIII.Il(IlIlIIl(31705, 62494, -78619940)), 3.65, (double)1.0F, (double)8.0F, 0.05)).IIl(x.lIlIII.Il(IlIlIIl(47557, 62495, 546846320))));
      this.IIlIII = (IIIllIIII)this.IIIlIll((new IIIllIIII(x.lIlIII.Il(IlIlIIl(23187, 62492, 1518211483)), (double)180.0F, (double)2.0F, (double)360.0F, (double)1.0F)).IIl(x.lIlIII.Il(IlIlIIl(25076, 62493, -84841516))));
      this.I = (IIIllIIII)this.IIIlIll(new IIIllIIII(x.lIlIII.Il(IlIlIIl(32217, 62482, 1035215215)), (double)100.0F, (double)1.0F, (double)100.0F, (double)1.0F));
      this.IIIllI = (IIIllIIII)this.IIIlIll((new IIIllIIII(x.lIlIII.Il(IlIlIIl(37451, 62483, 627251228)), (double)100.0F, (double)0.0F, (double)100.0F, (double)1.0F)).IIl(x.lIlIII.Il(IlIlIIl(16157, 62480, 1092812999))));
      this.llIIlI = (IIIllIIII)this.IIIlIll((new IIIllIIII(x.lIlIII.l(IlIlIIl(50621, 62481, 561276584)), (double)15.0F, (double)0.0F, (double)100.0F, (double)1.0F)).IIIl(x.lIlIII.l(IlIlIIl(15565, 62486, -596496371))));
      this.llIIl = (IIIllIIII)this.IIIlIll((new IIIllIIII(x.lIlIII.Il(IlIlIIl(20884, 62487, 1557361973)), (double)195.0F, (double)0.0F, (double)500.0F, (double)5.0F)).IIl(x.lIlIII.Il(IlIlIIl(4575, 62484, -820173085))));
      this.III = (IIIllIIII)this.IIIlIll((new IIIllIIII(x.lIlIII.Il(IlIlIIl(57336, 62485, -798873759)), (double)26.0F, (double)0.0F, (double)100.0F, (double)1.0F)).IIl(x.lIlIII.Il(IlIlIIl(54900, 62474, -1182636333))));
      this.lIlll = (IIIllIIII)this.IIIlIll((new IIIllIIII(x.lIlIII.Il(IlIlIIl(22986, 62475, -668262339)), (double)39.0F, (double)0.0F, (double)100.0F, (double)1.0F)).IIl(x.lIlIII.Il(IlIlIIl(40723, 62472, 565923061))));
      this.lIl = (IIIllIIII)this.IIIlIll((new IIIllIIII(x.lIlIII.Il(IlIlIIl(12727, 62473, -989171766)), (double)65.0F, (double)0.0F, (double)100.0F, (double)1.0F)).IIl(x.lIlIII.Il(IlIlIIl(59516, 62478, 629746365))));
      this.lIIII = (lIIIIl)this.IIIlIll(new lIIIIl(x.lIlIII.Il(IlIlIIl(34040, 62479, 1856140445)), true));
      this.lIlI = (lIIIIl)this.IIIlIll(new lIIIIl(x.lIlIII.Il(IlIlIIl(63940, 62476, -643429461)), true));
      this.IlIIlIl = (lIIIIl)this.IIIlIll(new lIIIIl(x.lIlIII.l(IlIlIIl(12499, 62477, -838532389)), false));
      this.IIIlII = (lIIIIl)this.IIIlIll(new lIIIIl(x.lIlIII.Il(IlIlIIl(49252, 62466, -1045341027)), true));
      this.lI = (lIIIIl)this.IIIlIll(new lIIIIl(x.lIlIII.Il(IlIlIIl(41454, 62467, -1064488222)), false));
      this.IIlIllI = (lIIIIl)this.IIIlIll(new lIIIIl(x.lIlIII.Il(IlIlIIl(14460, 62464, -1788144797)), false));
      this.lIIl = (lllIIlIl)this.IIIlIll(new lllIIlIl(x.lIlIII.Il(IlIlIIl(29587, 62465, -1627887402))));
      this.IIll = (IIIIllIII)this.IIIlIll(new IIIIllIII(IlllIlII.IlllIII, IIlIIlI, Set.of(IIlIlIl)));
      this.IIIIlI = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(x.lIlIII.Il(IlIlIIl(33913, 62470, -328306774)), <undefinedtype>.class, null.l));
      this.IIlIIII = (new IIIllIIII(x.lIlIII.Il(IlIlIIl(4825, 62471, 918249171)), 0.12, 0.02, (double)5.0F, 0.01)).IIl(x.lIlIII.Il(IlIlIIl(21739, 62468, 1640711682)));
      this.lllII = (new IIIllIIII(x.lIlIII.Il(IlIlIIl(44593, 62469, 1551903048)), 0.58, 0.02, (double)5.0F, 0.01)).IIl(x.lIlIII.Il(IlIlIIl(32990, 62522, 1730554497)));
      this.IlIlll = new IIIllIIII(x.lIlIII.Il(IlIlIIl(45717, 62523, 318643084)), 0.86, 0.05, (double)3.0F, 0.01);
      this.IlIII = new IIIllIIII(x.lIlIII.Il(IlIlIIl(52518, 62520, -1245879704)), 1.2, 0.05, (double)3.0F, 0.01);
      this.lII = new IIIllIIII(x.lIlIII.Il(IlIlIIl(37294, 62521, 43535721)), 0.84, 0.05, (double)3.0F, 0.01);
      this.IIllIll = new IIIllIIII(x.lIlIII.Il(IlIlIIl(41218, 62526, 986787999)), 1.18, 0.05, (double)3.0F, 0.01);
      this.IIlI = new IIIllIIII(x.lIlIII.Il(IlIlIIl(5829, 62527, 824081754)), 0.88, 0.05, (double)3.0F, 0.01);
      this.IIlIIIl = new IIIllIIII(x.lIlIII.Il(IlIlIIl(42684, 62524, -1001176868)), 1.16, 0.05, (double)3.0F, 0.01);
      this.llI = (new IIIllIIII(x.lIlIII.Il(IlIlIIl(49692, 62525, -1095957379)), 0.12, (double)0.0F, (double)1.0F, 0.01)).IIl(x.lIlIII.Il(IlIlIIl(40293, 62514, 353978951)));
      this.IllIll = new IIIllIIII(x.lIlIII.Il(IlIlIIl(256, 62515, 1887508453)), 1.02, (double)0.0F, (double)5.0F, 0.01);
      this.llIlIl = new IIIllIIII(x.lIlIII.Il(IlIlIIl(47207, 62512, 1712483669)), 0.82, (double)0.0F, (double)5.0F, 0.01);
      this.llIIll = new IIIllIIII(x.lIlIII.Il(IlIlIIl(43270, 62513, -1729086234)), 0.48, (double)0.0F, (double)5.0F, 0.01);
      this.II = new IIIllIIII(x.lIlIII.Il(IlIlIIl(22049, 62518, -1801228170)), 0.34, (double)0.0F, (double)5.0F, 0.01);
      this.IIllII = new IIIllIIII(x.lIlIII.Il(IlIlIIl(19053, 62519, 1786077038)), (double)0.5F, (double)0.0F, (double)5.0F, 0.01);
      this.IIIIlII = new IIIllIIII(x.lIlIII.Il(IlIlIIl(64066, 62516, 1344423708)), 0.16, (double)0.0F, (double)2.0F, 0.01);
      this.IIIll = new IIIllIIII(x.lIlIII.Il(IlIlIIl(9102, 62517, -371249689)), 0.3, (double)0.0F, (double)5.0F, 0.01);
      this.Illl = new IIIllIIII(x.lIlIII.Il(IlIlIIl(49360, 62506, 931940644)), 0.46, (double)0.0F, (double)1.0F, 0.01);
      this.lIll = new IIIllIIII(x.lIlIII.Il(IlIlIIl(17624, 62507, 1230469016)), 0.82, (double)0.0F, (double)1.0F, 0.01);
      this.IIllI = new IIIllIIII(x.lIlIII.Il(IlIlIIl(54207, 62504, 1066102927)), 0.62, (double)0.0F, (double)5.0F, 0.01);
      this.IIIIIII = new IIIllIIII(x.lIlIII.Il(IlIlIIl(19877, 62505, 1777629063)), (double)1.0F, (double)0.0F, (double)3.0F, 0.01);
      this.IIIII = new IIIllIIII(x.lIlIII.Il(IlIlIIl(63100, 62510, 190580054)), (double)1.0F, 0.05, (double)4.0F, 0.01);
      this.IlIIIl = new IIIllIIII(x.lIlIII.Il(IlIlIIl(44949, 62511, -1528226093)), (double)1.0F, 0.05, (double)3.0F, 0.01);
      this.llIl = (lIIIIl)this.IIIlIll((lIIIIl)(new lIIIIl(x.lIlIII.Il(IlIlIIl(39117, 62508, 1177635279)), false)).lIII(this::IlllI).llll());
      this.IIIIIll = -1;
      this.IIlllII = (<undefinedtype>)(new Object() {
         private float I = 1.0F;
         private float l;
         private float II = 1.0F;
         private float Il;
         private float lI = 1.0F;
         private int ll = -1;
         private int III;

         private void I() {
            this.II = 1.0F;
            this.lI = 1.0F;
            this.I = 1.0F;
            this.l = 0.0F;
            this.Il = 0.0F;
            this.ll = -1;
            this.III = 0;
         }
      });
      this.IIlIIll = (<undefinedtype>)(new Object() {
         private float I = 1.0F;
         private float l;
         private float II = 1.0F;
         private float Il;
         private float lI = 1.0F;
         private int ll = -1;
         private int III;

         private void I() {
            this.II = 1.0F;
            this.lI = 1.0F;
            this.I = 1.0F;
            this.l = 0.0F;
            this.Il = 0.0F;
            this.ll = -1;
            this.III = 0;
         }
      });
      this.IIIIIIl = (<undefinedtype>)(new Object() {
         private float I = 1.0F;
         private float l;
         private float II = 1.0F;
         private float Il;
         private float lI = 1.0F;
         private int ll = -1;
         private int III;

         private void I() {
            this.II = 1.0F;
            this.lI = 1.0F;
            this.I = 1.0F;
            this.l = 0.0F;
            this.Il = 0.0F;
            this.ll = -1;
            this.III = 0;
         }
      });
      this.ll = ThreadLocalRandom.current().nextFloat() * 2.0F - 1.0F;
      this.lIIIll = ThreadLocalRandom.current().nextFloat() * 2.0F - 1.0F;
      this.IIlllIl = ThreadLocalRandom.current().nextFloat() * 2.0F - 1.0F;
      this.IIIlIIl = ThreadLocalRandom.current().nextFloat() * 2.0F - 1.0F;
      this.llllIl = 0.0F;
      this.lIIIlI = 0.0F;
      this.IllIl = 0.0F;
      this.IIIIl = (float)(Math.random() * 6.2831853);
      this.IIllllI = (float)(Math.random() * 6.2831853);
      this.llIlll = 1.0F;
      this.IlIllI = 1.0F;
      this.IIllIII = 1.0F;
      this.lllIl = (float)(Math.random() * 6.2831853);
      this.IIllIlI = (float)(Math.random() * 6.2831853);
      this.lIlII = (float)(Math.random() * 6.2831853);
      this.llIll = 1.0F;
      this.lIIlII = 1.0F;
      this.IIIlI = 1.0F;
      this.llllll = 1.0F;
      this.llIllI = (float)(Math.random() * 6.2831853);
      this.IIlll = new IlIlIll();
      this.IIIlIll = var1;
      lllIIlIl var10000 = this.lIIl;
      lIIIIl var10001 = this.IIlIllI;
      Objects.requireNonNull(var10001);
      var10000.lIII(var10001::III);
      this.IlllIl();
   }

   private float llII(float var1) {
      if (Math.abs(var1) >= 179.0F) {
         if (this.IIIlllI == 0.0F) {
            this.IIIlllI = var1 >= 0.0F ? 1.0F : -1.0F;
         }

         return this.IIIlllI * 180.0F;
      } else {
         this.IIIlllI = 0.0F;
         return var1;
      }
   }

   private float lllI() {
      ThreadLocalRandom var1 = ThreadLocalRandom.current();
      return (var1.nextFloat() + var1.nextFloat() + var1.nextFloat()) / 1.5F - 1.0F;
   }

   private float IIIII(class_310 var1, class_243 var2, class_243 var3) {
      class_243 var4 = var3.method_1020(var2);
      double var5 = Math.sqrt(var4.field_1352 * var4.field_1352 + var4.field_1350 * var4.field_1350);
      if (var5 <= 1.0E-4) {
         return 0.016F;
      } else {
         float var7 = (float)(Math.toDegrees(Math.atan2(var4.field_1350, var4.field_1352)) - (double)90.0F);
         float var8 = (float)(-Math.toDegrees(Math.atan2(var4.field_1351, var5)));
         float var9 = class_3532.method_15393(var7 - var1.field_1724.method_36454());
         float var10 = var8 - this.IIlll(var1.field_1724.method_36455());
         float var11 = (float)Math.sqrt((double)(var9 * var9 + var10 * var10));
         float var12 = class_3532.method_15363((var11 - 2.5F) / 11.5F, 0.0F, 1.0F);
         return 0.016F + var12 * 0.084F;
      }
   }

   public void IIl(JsonObject var1) {
      if (var1 != null && var1.has(x.lIlIII.Il(IlIlIIl(60952, 62509, -1560406121)))) {
         JsonObject var2 = var1.getAsJsonObject(x.lIlIII.Il(IlIlIIl(14330, 62498, 535961439)));
         JsonElement var3 = var2.get(this.IlIll.Illl());
         if (var3 != null) {
            this.IlIll.II(var3);
            this.IlllIl();
         }

         this.lIllII(var2);
      }

      super.IIl(var1);
   }

   private float IIIIl() {
      if (this.IlllI()) {
         return class_3532.method_15363(this.IIII(0.14F, 0.01F, this.lIllll()), 0.01F, 0.14F);
      } else {
         float var1 = class_3532.method_15363(this.lllll(), 1.0F, this.IIlllI());
         float var2 = var1 / 155.0F;
         return class_3532.method_15363(1.01F - var2, 0.01F, 1.0F);
      }
   }

   private <undefinedtype> IIIll() {
      <undefinedtype> var1 = null.lIII(this.lllll(), null.I);
      float var2 = Math.min(this.lIlII(this.IlIlll, this.IlIII), var1.lII());
      float var3 = Math.max(this.lIIIlI(this.IlIlll, this.IlIII), var1.llIl());
      float var4 = Math.min(this.lIlII(this.lII, this.IIllIll), var1.III());
      float var5 = Math.max(this.lIIIlI(this.lII, this.IIllIll), var1.IIll());
      float var6 = Math.min(this.lIlII(this.IIlI, this.IIlIIIl), var1.lll());
      float var7 = Math.max(this.lIIIlI(this.IIlI, this.IIlIIIl), var1.IIlI());
      float var8 = Math.min(this.lIlII(this.IIlIIII, this.lllII), var1.II());
      float var9 = Math.min(this.lIIIlI(this.IIlIIII, this.lllII), var1.IIl());
      float var10 = this.lIlII(this.Illl, this.lIll);
      float var11 = this.lIIIlI(this.Illl, this.lIll);
      return new Record(var2, var3, var4, var5, var6, var7, var8, var9, Math.max(this.llllI(this.llI), var1.Illl()), Math.max(this.llllI(this.IllIll), var1.lIlI()), Math.max(this.llllI(this.llIlIl), var1.IlI()), Math.max(this.llllI(this.llIIll), var1.llI()), Math.max(this.llllI(this.II), var1.IlIl()), Math.max(this.llllI(this.IIllII), var1.llII()), Math.max(this.llllI(this.IIIIlII), var1.Ill()), this.llllI(this.IIIll), var10, var11, this.llllI(this.IIllI), 0.0F, var1.IllI() * this.llllI(this.IIIIIII), var1.IlII() * this.llllI(this.IIIII), var1.lIll() * this.llllI(this.IlIIIl)) {
         private final float I;
         private final float l;
         private final float II;
         private final float Il;
         private final float lI;
         private final float ll;
         private final float III;
         private final float IIl;
         private final float IlI;
         private final float Ill;
         private final float lII;
         private final float lIl;
         private final float llI;
         private final float lll;
         private final float IIII;
         private final float IIIl;
         private final float IIlI;
         private final float IIll;
         private final float IlII;
         private final float IlIl;
         private final float IllI;
         private final float Illl;
         private final float lIII;

         public float I() {
            return this.lII;
         }

         static <undefinedtype> l() {
            return new <anonymous constructor>(1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
         }

         public float II() {
            return this.l;
         }

         static <undefinedtype> Il() {
            return new <anonymous constructor>(0.88F, 1.14F, 0.86F, 1.12F, 0.9F, 1.1F, 0.12F, 0.5F, 0.075F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 0.0F, 1.0F, 0.1F, 0.6F, 1.0F, 0.4F, 1.0F, 1.0F, 1.0F);
         }

         public static <undefinedtype> lI(float var0, float var1) {
            <undefinedtype> var2 = lIl(var0);
            float var3 = class_3532.method_15363(var1, 0.0F, 1.0F);
            float var4 = class_3532.method_15363((var0 - 500.0F) / 200.0F, 0.0F, 1.0F);
            float var5 = x.IlIlIll.lIlll(var2.IlII() * 0.72F, var2.IlII() * 0.86F, var3);
            float var6 = x.IlIlIll.lIlll(var2.lIll() * 1.22F, var2.lIll() * 1.36F, var3);
            return new <anonymous constructor>(x.IlIlIll.lIlll(0.78F, 0.72F, var3), x.IlIlIll.lIlll(1.32F, 1.42F, var3), x.IlIlIll.lIlll(0.78F, 0.72F, var3), x.IlIlIll.lIlll(1.3F, 1.38F, var3), x.IlIlIll.lIlll(0.8F, 0.74F, var3), x.IlIlIll.lIlll(1.28F, 1.36F, var3), x.IlIlIll.lIlll(0.055F, 0.045F, var3), x.IlIlIll.lIlll(0.32F, 0.24F, var3), 0.0F, x.IlIlIll.lIlll(var2.lIlI() * 1.18F, 1.58F, var3), x.IlIlIll.lIlll(1.52F, 1.96F, var3), x.IlIlIll.lIlll(0.86F, 1.08F, var3), x.IlIlIll.lIlll(0.72F, 0.98F, var3), x.IlIlIll.lIlll(0.78F, 1.04F, var3), x.IlIlIll.lIlll(var2.Ill() * 0.55F, 0.28F, var3), x.IlIlIll.lIlll(var2.IIII(), 0.3F, var3), x.IlIlIll.lIlll(var2.I(), 0.42F, var3), x.IlIlIll.lIlll(var2.ll(), 0.82F, var3), x.IlIlIll.lIlll(var2.IIIl(), 0.68F, var3), x.IlIlIll.lIlll(var2.lIIl(), 0.04F, var3), x.IlIlIll.lIlll(var2.IllI() * 1.34F, var2.IllI() * 1.52F, var3), x.IlIlIll.lIlll(var5, var5 * 0.84F, var4), x.IlIlIll.lIlll(var6, var6 * 1.1F, var4));
         }

         public float ll() {
            return this.IIl;
         }

         public float III() {
            return this.Illl;
         }

         public float IIl() {
            return this.lIII;
         }

         public float IlI() {
            return this.Ill;
         }

         public float Ill() {
            return this.ll;
         }

         public float lII() {
            return this.III;
         }

         public {
            var1 = x.IlIlIll.IIlIlIl(var1, 0.05F, 5.0F);
            var2 = x.IlIlIll.IIlIlIl(Math.max(var2, var1), var1, 5.0F);
            var3 = x.IlIlIll.IIlIlIl(var3, 0.05F, 5.0F);
            var4 = x.IlIlIll.IIlIlIl(Math.max(var4, var3), var3, 5.0F);
            var5 = x.IlIlIll.IIlIlIl(var5, 0.05F, 5.0F);
            var6 = x.IlIlIll.IIlIlIl(Math.max(var6, var5), var5, 5.0F);
            var7 = x.IlIlIll.IIlIlIl(var7, 0.02F, 5.0F);
            var8 = x.IlIlIll.IIlIlIl(Math.max(var8, var7), var7, 5.0F);
            var9 = x.IlIlIll.IIlIlIl(var9, 0.0F, 1.0F);
            var10 = x.IlIlIll.IIlIlIl(var10, 0.0F, 8.0F);
            var11 = x.IlIlIll.IIlIlIl(var11, 0.0F, 8.0F);
            var12 = x.IlIlIll.IIlIlIl(var12, 0.0F, 8.0F);
            var13 = x.IlIlIll.IIlIlIl(var13, 0.0F, 8.0F);
            var14 = x.IlIlIll.IIlIlIl(var14, 0.0F, 8.0F);
            var15 = x.IlIlIll.IIlIlIl(var15, 0.0F, 4.0F);
            var16 = x.IlIlIll.IIlIlIl(var16, 0.0F, 8.0F);
            var17 = x.IlIlIll.IIlIlIl(var17, 0.0F, 1.0F);
            var18 = x.IlIlIll.IIlIlIl(Math.max(var18, var17), var17, 1.0F);
            var19 = x.IlIlIll.IIlIlIl(var19, 0.0F, 8.0F);
            var20 = x.IlIlIll.IIlIlIl(var20, 0.0F, 1.0F);
            var21 = x.IlIlIll.IIlIlIl(var21, 0.0F, 8.0F);
            var22 = x.IlIlIll.IIlIlIl(var22, 0.02F, 8.0F);
            var23 = x.IlIlIll.IIlIlIl(var23, 0.05F, 24.0F);
            this.III = var1;
            this.lIl = var2;
            this.Illl = var3;
            this.IIll = var4;
            this.IllI = var5;
            this.lI = var6;
            this.l = var7;
            this.lIII = var8;
            this.IlIl = var9;
            this.I = var10;
            this.Ill = var11;
            this.llI = var12;
            this.IIIl = var13;
            this.II = var14;
            this.ll = var15;
            this.Il = var16;
            this.lII = var17;
            this.IIl = var18;
            this.IlI = var19;
            this.IlII = var20;
            this.IIlI = var21;
            this.lll = var22;
            this.IIII = var23;
         }

         private static <undefinedtype> lIl(float var0) {
            float var1 = x.IlIlIll.llIlIl(var0);
            return new <anonymous constructor>(0.7F, 1.55F, 0.7F, 1.5F, 0.78F, 1.3F, 0.12F, 0.58F, 0.08F, 1.02F, 1.8F, 1.3F, 1.2F, 1.35F, x.IlIlIll.lIlll(0.35F, 1.7F, var1), 0.36F, 0.46F, 0.82F, 0.68F, 0.08F, x.IlIlIll.lIlll(1.45F, 2.15F, var1), x.IlIlIll.lIlll(0.46F, 0.24F, var1), x.IlIlIll.lIlll(1.35F, 2.85F, var1));
         }

         public float llI() {
            return this.llI;
         }

         public float lll() {
            return this.IllI;
         }

         public float IIII() {
            return this.Il;
         }

         public float IIIl() {
            return this.IlI;
         }

         public float IIlI() {
            return this.lI;
         }

         public float IIll() {
            return this.IIll;
         }

         public float IlII() {
            return this.lll;
         }

         public float IlIl() {
            return this.IIIl;
         }

         public float IllI() {
            return this.IIlI;
         }

         public float Illl() {
            return this.IlIl;
         }

         static <undefinedtype> lIII(float var0, Object var1) {
            if (var1 != null.I) {
               return Il();
            } else {
               float var2 = x.IlIlIll.llII(var0);
               return new <anonymous constructor>(0.7F, 1.55F, 0.7F, 1.5F, 0.78F, 1.3F, 0.12F, 0.58F, 0.08F, 1.02F, 1.8F, 1.3F, 1.2F, 1.35F, x.IlIlIll.lIlll(0.35F, 1.7F, var2), 0.36F, 0.46F, 0.82F, 0.68F, 0.08F, x.IlIlIll.lIlll(1.45F, 2.15F, var2), x.IlIlIll.lIlll(0.46F, 0.24F, var2), x.IlIlIll.lIlll(1.35F, 2.85F, var2));
            }
         }

         public float lIIl() {
            return this.IlII;
         }

         public float lIlI() {
            return this.I;
         }

         public float lIll() {
            return this.IIII;
         }

         public float llII() {
            return this.II;
         }

         public float llIl() {
            return this.lIl;
         }
      };
   }

   private void IIlII() {
      this.lIlllI = 0L;
      this.Illlll = 0.0F;
   }

   public float IIlIl(float var1) {
      return class_3532.method_16439(var1, this.IIIIlll, this.IIIIllI);
   }

   private boolean IIllI(class_310 var1) {
      if (var1 != null && var1.field_1690 != null) {
         boolean var2 = var1.field_1690.field_1886 != null && (var1.field_1690.field_1886.method_1434() || IllllIlI.IllIlI(var1.field_1690.field_1886) > 0);
         boolean var3 = var1.field_1690.field_1904 != null && (var1.field_1690.field_1904.method_1434() || IllllIlI.IllIlI(var1.field_1690.field_1904) > 0);
         return var2 || var3;
      } else {
         return false;
      }
   }

   public void lI() {
      this.lIlIlI(class_310.method_1551(), false);
      this.IlllIl();
      this.IIlll.IIIlIll();
   }

   private float IIlll(float var1) {
      return class_3532.method_15363(var1, -90.0F, 90.0F);
   }

   private <undefinedtype> IlIII(float var1, float var2, float var3, float var4, float var5, float var6) {
      float var7 = class_3532.method_15393(var2 - var1);
      float var8 = var1 + var7;
      return this.IlIIlI(var1, var8, var3, var4, var5, var6);
   }

   private int IlIIl(float var1, float var2, float var3, int var4, boolean var5) {
      if (Math.abs(var3) <= 0.01F) {
         return 0;
      } else {
         float var6 = var5 ? class_3532.method_15393(var1 - var2) : var1 - var2;
         return Math.abs(var6) >= 0.8F && Math.signum(var6) != Math.signum(var3) ? 4 : Math.max(0, var4 - 1);
      }
   }

   public boolean IlIll(Object var1) {
      return var1 != null && ((<undefinedtype>)this.IIIIlI.III()).lI == var1;
   }

   private float IllII(Object var1, int var2, int var3, float var4, float var5, float var6) {
      if (var1.ll != var2) {
         var1.ll = var2;
         var1.III = 0;
         var1.II = 1.0F;
         var1.lI = 1.0F;
         var1.I = this.lIIl(var2, var3, 0, var5, var6);
         var1.Il = this.IIIlIl(var2, var3, 0);
         var1.l = 0.0F;
      }

      for(var1.l += Math.max(var4, 0.0F); var1.l >= var1.Il; var1.Il = this.IIIlIl(var2, var3, var1.III)) {
         var1.l -= var1.Il;
         var1.II = var1.I;
         var1.lI = var1.II;
         ++var1.III;
         var1.I = this.lIIl(var2, var3, var1.III, var5, var6);
      }

      float var7 = var1.Il <= 1.0E-4F ? 1.0F : class_3532.method_15363(var1.l / var1.Il, 0.0F, 1.0F);
      float var8 = var7 * var7 * (3.0F - 2.0F * var7);
      var1.II = class_3532.method_16439(var8, var1.lI, var1.I);
      return var1.II;
   }

   private void IllIl() {
      this.lllII();
      this.IlIIlll = 0;
      this.lllllI = 0;
      this.IlIIlI = null;
      this.IIIIIll = -1;
      this.IIIlllI = 0.0F;
      this.IllIIl = 0L;
      this.IIIlIII = 0L;
      this.lIlllI = 0L;
      this.Illlll = 0.0F;
      this.IIlllII.I();
      this.IIlIIll.I();
      this.IIIIIIl.I();
      this.lIllI = 0.0F;
      this.IIllIII = 1.0F;
      this.llllIl = 0.0F;
      this.lIIIlI = 0.0F;
      this.IllIl = 0.0F;
      this.lllIlI = 0L;
   }

   private boolean IlllI() {
      return false;
   }

   private float Illll(float var1, float var2, float var3) {
      float var4 = Math.max(var1, 0.005F);
      float var5 = this.IIIIl();
      float var6 = var4 * 20.0F * (0.95F + (1.0F - var5) * 0.55F + var2 * 0.95F) * var3 * 1.12F;
      if (this.IlllI()) {
         var6 *= this.IlllII();
      }

      if (this.IlIll.III() == null.Il) {
         var6 *= 1.35F;
      } else if (this.IlIll.III() == null.I) {
         var6 *= 0.86F;
      } else if (this.IlIll.III() == null.lI) {
         var6 *= 1.65F;
      } else if (this.IlIll.III() == null.l) {
         var6 *= 1.95F;
      }

      return var6;
   }

   private class_243 lIIII(class_243 var1, class_243 var2, class_243 var3) {
      class_243 var4 = var3.method_1020(var2);
      double var5 = var4.method_1027();
      if (var5 <= 1.0E-6) {
         return var3;
      } else {
         double var7 = var4.method_1026(var1.method_1020(var2)) / var5;
         var7 = class_3532.method_15350(var7, (double)0.0F, (double)1.0F);
         return var2.method_1019(var4.method_1021(var7));
      }
   }

   private <undefinedtype> lIIIl() {
      boolean var1 = this.IlllI();
      float var2 = this.llllI(this.IIIllI);
      float var3 = class_3532.method_15363(var2 / 100.0F, 0.0F, 1.0F);
      float var4 = 0.35F + 0.65F * (float)Math.pow((double)var3, 0.85);
      float var5 = this.llllI(this.llIIlI) / 100.0F;
      float var6 = this.llllI(this.llIIl) / 1000.0F;
      float var7 = this.llllI(this.III) / 100.0F;
      float var8 = this.llllI(this.lIlll) / 100.0F;
      return new Record(this.lllll(), var1 ? null.Il : null.I, var1 ? null.I : null.l, (Boolean)this.IIIlII.III(), var1 ? this.IIIll() : null.Il(), new Record(var4, var6, var7, var8, this.llllI(this.lIl) / 100.0F, var5, 1.0F, 1.0F) {
         private final float I;
         private final float l;
         private final float II;
         private final float Il;
         private final float lI;
         private final float ll;
         private final float III;
         private final float IIl;

         {
            this(var1, var2, var3, var4, var5, 0.0F, var6, var7);
         }

         public float I() {
            return this.IIl;
         }

         public float l() {
            return this.I;
         }

         public float II() {
            return this.lI;
         }

         static <undefinedtype> Il() {
            return new <anonymous constructor>(0.85F, 0.08F, 0.0F, 0.0F, 0.65F, 0.0F, 1.0F, 1.0F);
         }

         public float lI() {
            return this.II;
         }

         public float ll() {
            return this.l;
         }

         public float III() {
            return this.III;
         }

         public float IIl() {
            return this.ll;
         }

         public {
            var1 = x.IlIlIll.IIlIlIl(var1, 0.0F, 1.0F);
            var2 = x.IlIlIll.IIlIlIl(var2, 0.0F, 0.5F);
            var3 = x.IlIlIll.IIlIlIl(var3, 0.0F, 1.0F);
            var4 = x.IlIlIll.IIlIlIl(var4, 0.0F, 1.0F);
            var5 = x.IlIlIll.IIlIlIl(var5, 0.0F, 1.0F);
            var6 = x.IlIlIll.IIlIlIl(var6, 0.0F, 1.0F);
            var7 = x.IlIlIll.IIlIlIl(var7, 0.0F, 1.0F);
            var8 = x.IlIlIll.IIlIlIl(var8, 0.0F, 1.0F);
            this.IIl = var1;
            this.ll = var2;
            this.lI = var3;
            this.III = var4;
            this.Il = var5;
            this.II = var6;
            this.I = var7;
            this.l = var8;
         }

         public float IlI() {
            return this.Il;
         }
      }, false, 1.0F) {
         private final <undefinedtype> I;
         private final <undefinedtype> l;
         private final <undefinedtype> II;
         private final float Il;
         private final <undefinedtype> lI;
         private final boolean ll;
         private final boolean III;
         private final float IIl;
         private final boolean IlI;

         public boolean I() {
            return this.IlI;
         }

         public <undefinedtype> l() {
            return this.lI;
         }

         static <undefinedtype> II(float var0) {
            float var1 = Float.isFinite(var0) ? var0 : 0.0F;
            float var2 = class_3532.method_15363(var1 / 100.0F, 0.01F, 1.0F);
            float var3 = class_3532.method_15363(var1 * 4.5F, 120.0F, 420.0F);
            float var4 = class_3532.method_15363(var1 / 23.0F, 1.0F, 6.0F);
            float var5 = class_3532.method_15363(1.0512F - var2 * 0.36F, 0.4F, 0.85F);
            return new <anonymous constructor>(var3, null.l, null.l, true, null.lIII(var3, null.l), new Record(var5, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, var2, var2) {
               private final float I;
               private final float l;
               private final float II;
               private final float Il;
               private final float lI;
               private final float ll;
               private final float III;
               private final float IIl;

               {
                  this(var1, var2, var3, var4, var5, 0.0F, var6, var7);
               }

               public float I() {
                  return this.IIl;
               }

               public float l() {
                  return this.I;
               }

               public float II() {
                  return this.lI;
               }

               static <undefinedtype> Il() {
                  return new <anonymous constructor>(0.85F, 0.08F, 0.0F, 0.0F, 0.65F, 0.0F, 1.0F, 1.0F);
               }

               public float lI() {
                  return this.II;
               }

               public float ll() {
                  return this.l;
               }

               public float III() {
                  return this.III;
               }

               public float IIl() {
                  return this.ll;
               }

               public {
                  var1 = x.IlIlIll.IIlIlIl(var1, 0.0F, 1.0F);
                  var2 = x.IlIlIll.IIlIlIl(var2, 0.0F, 0.5F);
                  var3 = x.IlIlIll.IIlIlIl(var3, 0.0F, 1.0F);
                  var4 = x.IlIlIll.IIlIlIl(var4, 0.0F, 1.0F);
                  var5 = x.IlIlIll.IIlIlIl(var5, 0.0F, 1.0F);
                  var6 = x.IlIlIll.IIlIlIl(var6, 0.0F, 1.0F);
                  var7 = x.IlIlIll.IIlIlIl(var7, 0.0F, 1.0F);
                  var8 = x.IlIlIll.IIlIlIl(var8, 0.0F, 1.0F);
                  this.IIl = var1;
                  this.ll = var2;
                  this.lI = var3;
                  this.III = var4;
                  this.Il = var5;
                  this.II = var6;
                  this.I = var7;
                  this.l = var8;
               }

               public float IlI() {
                  return this.Il;
               }
            }, false, var4);
         }

         public boolean Il() {
            return this.III;
         }

         public float lI() {
            return this.IIl;
         }

         public float ll() {
            return this.Il;
         }

         public {
            this(var1, var2, var3, var4, var5, var6, var7, var8, false);
         }

         public <undefinedtype> III() {
            return this.II;
         }

         {
            this(var1, var2, var3, var4, var5, null.Il(), false, 1.0F);
         }

         static <undefinedtype> IIl(float var0) {
            float var1 = class_3532.method_15363(var0 * 144.0F, 500.0F, 680.0F);
            return new <anonymous constructor>(var1, null.l, null.I, true, null.lIII(var1, null.I), new Record(0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F) {
               private final float I;
               private final float l;
               private final float II;
               private final float Il;
               private final float lI;
               private final float ll;
               private final float III;
               private final float IIl;

               {
                  this(var1, var2, var3, var4, var5, 0.0F, var6, var7);
               }

               public float I() {
                  return this.IIl;
               }

               public float l() {
                  return this.I;
               }

               public float II() {
                  return this.lI;
               }

               static <undefinedtype> Il() {
                  return new <anonymous constructor>(0.85F, 0.08F, 0.0F, 0.0F, 0.65F, 0.0F, 1.0F, 1.0F);
               }

               public float lI() {
                  return this.II;
               }

               public float ll() {
                  return this.l;
               }

               public float III() {
                  return this.III;
               }

               public float IIl() {
                  return this.ll;
               }

               public {
                  var1 = x.IlIlIll.IIlIlIl(var1, 0.0F, 1.0F);
                  var2 = x.IlIlIll.IIlIlIl(var2, 0.0F, 0.5F);
                  var3 = x.IlIlIll.IIlIlIl(var3, 0.0F, 1.0F);
                  var4 = x.IlIlIll.IIlIlIl(var4, 0.0F, 1.0F);
                  var5 = x.IlIlIll.IIlIlIl(var5, 0.0F, 1.0F);
                  var6 = x.IlIlIll.IIlIlIl(var6, 0.0F, 1.0F);
                  var7 = x.IlIlIll.IIlIlIl(var7, 0.0F, 1.0F);
                  var8 = x.IlIlIll.IIlIlIl(var8, 0.0F, 1.0F);
                  this.IIl = var1;
                  this.ll = var2;
                  this.lI = var3;
                  this.III = var4;
                  this.Il = var5;
                  this.II = var6;
                  this.I = var7;
                  this.l = var8;
               }

               public float IlI() {
                  return this.Il;
               }
            }, false, 1.0F);
         }

         public <undefinedtype> IlI() {
            return this.I;
         }

         public <undefinedtype> Ill() {
            return this.l;
         }

         public boolean lII() {
            return this.ll;
         }

         {
            this(var1, var2, var3, var4, null.lIII(var1, var3), null.Il(), false, 1.0F);
         }

         {
            this(var1, var2, var3, var4, var5, null.Il(), var6, 1.0F);
         }

         {
            this(var1, var2, var3, var4, var5, var6, false, 1.0F);
         }

         public {
            if (var5 == null) {
               var5 = null.lIII(var1, var3);
            }

            if (var6 == null) {
               var6 = null.Il();
            }

            if (!Float.isFinite(var8) || var8 <= 0.0F) {
               var8 = 1.0F;
            }

            this.IIl = var1;
            this.lI = var2;
            this.II = var3;
            this.IlI = var4;
            this.I = var5;
            this.l = var6;
            this.ll = var7;
            this.Il = var8;
            this.III = var9;
         }
      };
   }

   private class_243 lIIlI(class_243 var1, class_243 var2, class_1309 var3) {
      class_238 var4 = var3.method_5829();
      class_243 var5 = var4.method_1005();
      double var6 = var4.field_1325 - var4.field_1322;
      class_243 var8 = new class_243(var5.field_1352, var4.field_1322, var5.field_1350);
      class_243 var9 = new class_243(var5.field_1352, var4.field_1322 + var6, var5.field_1350);
      return this.lIIII(var1, var8, var9);
   }

   private <undefinedtype> lIIll(float var1, float var2, float var3, float var4, float var5, boolean var6, Object var7) {
      float var8 = var6 ? var1 + class_3532.method_15393(var2 - var1) : this.IIlll(var2);
      float var9 = var8 - var1;
      float var10 = Math.abs(var9);
      if (var10 <= 1.0E-4F) {
         return new Record(var8, 0.0F) {
            private final float I;
            private final float l;

            private {
               this.I = var1;
               this.l = var2;
            }

            public float I() {
               return this.I;
            }

            public float l() {
               return this.l;
            }
         };
      } else {
         float var11 = var3;
         if (var7 == null.lI) {
            var11 = var3 * 1.45F;
         } else if (var7 == null.l) {
            var11 = var3 * 1.85F;
         }

         float var12 = Math.max(0.005F, var11 * var4);
         float var13;
         if (var7 == null.l) {
            float var14 = class_3532.method_15363(0.2F + var5 * 0.36F + var10 / 90.0F, 0.22F, 0.78F);
            var13 = Math.max(0.005F, var10 * var14);
         } else {
            var13 = var12;
         }

         float var15 = Math.min(var10, Math.min(var12, var13)) * Math.signum(var9);
         return new Record(var1 + var15, 0.0F) {
            private final float I;
            private final float l;

            private {
               this.I = var1;
               this.l = var2;
            }

            public float I() {
               return this.I;
            }

            public float l() {
               return this.l;
            }
         };
      }
   }

   private float lIlII(IIIllIIII var1, IIIllIIII var2) {
      return Math.min(this.llllI(var1), this.llllI(var2));
   }

   private float lIlIl(float var1) {
      if (this.llIIII()) {
         this.lIllI = 0.0F;
         this.IIllIII = 1.0F;
         return 1.0F;
      } else {
         float var2 = Math.max(0.0F, Math.min(var1, 0.1F));
         if (this.lIllI > 0.0F) {
            this.lIllI -= var2;
            if (this.lIllI > 0.0F) {
               return this.IIllIII;
            }

            this.lIllI = 0.0F;
            this.IIllIII = 1.0F;
         }

         float var3 = 0.18F * var2;
         float var4 = 0.55F;
         float var5 = 0.88F;
         float var6 = 0.018F;
         float var7 = 0.07F;
         if (this.IlllI()) {
            var3 *= 0.42F;
            var4 = 0.38F;
            var5 = 0.76F;
            var6 *= 0.72F;
            var7 *= 0.72F;
         }

         ThreadLocalRandom var8 = ThreadLocalRandom.current();
         if (var8.nextFloat() < var3) {
            this.lIllI = var6 + var8.nextFloat() * (var7 - var6);
            this.IIllIII = var4 + var8.nextFloat() * (var5 - var4);
            return this.IIllIII;
         } else {
            return 1.0F;
         }
      }
   }

   private void lIllI() {
      this.l = false;
      this.IIlllll = 0.0F;
      this.lIllIl = 0.0F;
      this.IllIl();
   }

   private class_243 lIlll(float var1, float var2) {
      double var3 = Math.toRadians((double)var1);
      double var5 = Math.toRadians((double)var2);
      double var7 = Math.cos(var5);
      return (new class_243(-Math.sin(var3) * var7, -Math.sin(var5), Math.cos(var3) * var7)).method_1029();
   }

   private boolean llIII(class_310 var1) {
      if (var1.field_1724 != null && var1.field_1687 != null && var1.field_1690 != null && var1.field_1755 == null) {
         if (var1.field_1724.method_5805() && !var1.field_1724.method_6115() && !var1.field_1724.method_5765()) {
            if ((Boolean)this.lIlI.III() && !this.IIIIII(var1.field_1724.method_6047())) {
               return false;
            } else if ((Boolean)this.IIlIllI.III() && !this.IIllIl(var1)) {
               return false;
            } else {
               return !(Boolean)this.IlIIlIl.III() || this.lIIIII(var1);
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private float llIIl(float var1, float var2, float var3) {
      return var1 < var2 ? Math.min(var1 + var3, var2) : Math.max(var1 - var3, var2);
   }

   private void llIlI(class_310 var1, long var2) {
      if (this.lIlllI == 0L) {
         this.lIlllI = var2;
         this.Illlll = 0.0F;
         this.IllIll(var1, 0.016666668F, var2);
      } else {
         float var4 = class_3532.method_15363((float)(var2 - this.lIlllI) / 1.0E9F, 0.0F, 0.2F);
         this.lIlllI = var2;
         this.Illlll = Math.min(this.Illlll + var4, 0.06666667F);

         int var5;
         for(var5 = 0; this.Illlll >= 0.016666668F && var5 < 4; ++var5) {
            this.IllIll(var1, 0.016666668F, var2);
            this.Illlll -= 0.016666668F;
         }

         if (var5 == 0 && this.Illlll > 0.0F) {
            float var6 = class_3532.method_15363(this.Illlll, 0.0033333334F, 0.016666668F);
            this.Illlll = 0.0F;
            this.IllIll(var1, var6, var2);
         }

      }
   }

   private boolean llIll(Object var1, Object var2) {
      boolean var10000;
      switch (((<undefinedtype>)this.IlIIII.III()).ordinal()) {
         case 0:
         case 3:
            var10000 = this.IIllll(var1.ll(), var2.ll(), var1.Il(), var2.Il(), var1.lI(), var2.lI());
            break;
         case 1:
            var10000 = this.IIllll(var1.Il(), var2.Il(), var1.ll(), var2.ll(), var1.lI(), var2.lI());
            break;
         case 2:
            var10000 = this.IIllll(var1.lI(), var2.lI(), var1.Il(), var2.Il(), var1.ll(), var2.ll());
            break;
         default:
            throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   static {
      short var6 = 19248;
      String var7 = "ﭘﯭ\ufbd2ﯚﮪﮥﭛﯦ\ufb11ﬡ﮶ﯲﯯ﯁褐祖騁髧騖驿驯驳餛驀髁骁骬髶髭騔騴骞髫餂髚騽驜髧驃髟骒騀騩驟髏骮饌髾騒髜骇騍髇髼餯骐騉驞髭髉驨骝驋髧髚马騐髸髣驭騧驼騀養騲骁饇驊騳髌驪骱餟餋\ud8fd퍵\ud8b3퍉\ud8e8팤펒펆☽☯☯☙☪☻♡☹☟♇♴☼☹☘☬➊蚪蛵虋蘗蚞蚧蛲蚐齧龌齼齟Չԟԁԣ髹髏髟髪䛆䟕䘻䙑䛢䙥䙅䘨䘈䙅䙦䟘\uf68f\uf161\uf6c0\uf6b1\uf6a1\uf685\uf195\uf696\uf14f\uf6a2\uf683\uf171\uf17b\uf6e8\uf103\uf133룋롯뢟뢼㫛㫁㤟㤤㫁㪸㪵㪻㤪㫗㥐㤑╖☢┚┹̇͠ΙΪ̏͢ͺ̺Ψ͕̙ΟͳΦ̋τΔ̼̜́\ud8b8\udf13\ud8b9\ud8c8\u09b5ै৷ॿএईৣै०४ॹ॒꤃ꦷꤗꤴ虄蟣螓蘿虦蟭蘑蟗螏螯虖蘈螿蜞蜷蜆ｉ\uf8f5\uf8fd\uf8de쨖쫇줘쫋쨱쨃쫰쫭쫃쩃쥕쫵쫨쫀쪖쥒쌐쎴쌔쌷ᐹᒘᐪᒻᑔᐚᐮᒈᑴᗉᑱᖢᒄᑑᐎᓉ曂枧映昳昪晲昰昤昀晀晫昰昼晔晙枅㣱㣫㢦㢉㣚㢸㼟㣖㢾㽾㽗㢇㼍㼡㢁㢻㼒㼄㢃㽺㣥㢽㠷㠔߲؏ޕػߘߴ߭\u0605ތ߄߮؊؊ށޞَؚ߸ػ݊Ꞔ곚ꞛꜾꜯ\ua7ce곛곆\ue32e\ue8a1\ue37f\ue8b5\ue31c\ue8f3\ue8a9\ue8c5\ue8fa\ue340\ue8f8\ue32a\ue8ce\ue8e6\ue8b7\ue321\ue8cb\ue324\ue346\ue8a0\ue326\ue370\ue8ca\ue351⏊⌭⎋⌉⏠⍫⎗⣂⌋⍟⍲⌿긴꿑긾꿦깞꿾깳꿉꿿꾳꾊꿝꿎꾵긁꾀稾穠稠稚箷穷篓稝稌稬穓稉稼窩竼竗稺箑窣穜稟箧築稰竽穪稇稢烟炧୵ୖ㰍㳳㳓㳉㍤㲤㳀㳾㳟㰿㲰㳪㳯㱺㱯㰄㳹㌂㰐㱏㰌㌔㌚㳃㱎㱹㌍㳯⁇\u200f⅍Ⅾ\ue63b\ue62d\ue625\ue657\ue7ba\ue63a\ue665\ue628\ue602\ue7bc\ue6c4\ue68b\ue674\ue609\ue7bc\ue66c\ue62f\ue68b\ue7e7\ue6e5\ue6d0\ue7de\ue69a\ue7e5\ue651\ue667\ue62e\ue7ce뺫빝븵빧뺊븊빕빘븲뺌뺴뻻비빹뺌빜빟뻻뻗뺕뺠뺮뻪뻕븻블븆뺾銒鵼鵬鵾鷳鴓鋖鋏鵃鴮鴻鋘鵭鵶銼鴵鵲鋊鋣銲鋻鵼鋟鵃鴒鴬鵻鵣鵚鴝鴙鵃藣萕藽萯薂葂薿薮萺葷薪薉萜萧藕薜萓薓薚藣藪萕薾萺薃葅萚藒萠藞蕸蔢懫思懵性慊恅憯憡怦憯恂怏懔怯懭恔怛憫懒懫懢思懶懲憋憽怒懒总憬憰懪ꍏ겹곱겛갶겹ꌓꌅ겂곫곮겳겨것ꍡ고겷곗곖겯ꍎ겹ꌂ겶겏곱곦겮겄ꍺ간걞눍닳닓닉녤늓너닓닝늁눒닉軂踱这迺랝뜃띃띹럔뜃랸띃띭뜱랢띙띊띦랛뜋띎럪띦뜻랶랄럼띢띃뜂랼램\ud8d1\ud83f\ud82f\ud80d\ud9a0\ud860\ud899\ud829\ud81c\ud85e\ud8d5\ud831\ud82b\ud8ae\ud86d\ud86e\ud801\ud827\ud81b\ud9ea癒瞼瞬瞾眳矓瘊瘌瞜矞癁瞹첞찀챀챺쳗찗첻챟찞찱챹찧챟챻쳙쳞챈첧찵찱첶챐첪첈柸柞柆柤昉枉晥柁柸柯昧柑柁柭晇晶柕晸晙柎昡柝晻明퓀푦퐾퐜햱푮퐶퐺퐍푗햀퐹퐹푑푄푝퐷푳햖헋㑭㒓㑳㒩㐄㐳㒋㐐㒣㑀㐭㑀㒚㒡㗊㐚㒚㐺㑞㑑㐴㐫㐠㐉㓽㐙㒐㐬㒣㑐㐶㑬ㄼ㆚ㆂㆨㄅ㇊ㅂㄡㅲㄉ㛼㆙㆛ㅐㄓ㇃㆓ㄻㆧㅘㄵㅢㅗㄇㄩㅩㅭㅹί͙̑ͻϖ̡͙̲͡Κϯ͚͈ͣϐ̀̀Ϩ̴ΛϦρ̹̈́͘͢ξΪ⎔≲≪≰⋽∢≪⏉≚⎡⋔≱≣≈⋻∫≻⏃≏⎰⋍⏊⏅≍∀⎎⊔≢≛⎺⋖≷穭窓穳窩稄稳稹稯窠竡竌窙窚窡稏穢穩稭穅穑㢀㢦㍾㍜㏱㌱㣘㣙㍇㢺㌵㍴㍹㢕㏿㢇㍴㢶㍛㌑㢋㢧㍵㍖甜町產甈થ番畦甭畒痾痌甴甯લ痾畣甁્甎ધ\ud89c\udf1b\ud8be\ud8d5\udf77\ud8bc\udf18\ud858\ud8d2\ud888\ud8e9\ud8af\ud8a7\udf3b\ud86a\ud817昂攌曫曇昲暩曳替曘晨敗攔婨婮媉媭婘娳婩媅媺婂娵宦ܥ\u0cd2ೊ\u0cf9ܟೳݥݱ䣒䧐䡽䠈䣽䣌䦡䧌奔祐著頻徭瘝練瘝훇\ud7a9획혎혬훀황혝";
      char[] var8 = "\u0010D\b\u0010\b\u0004\u0004\u0004\f\u0010\u0004\f\u0004\u0014\u0004\f\u0004\u0010\u0004\u0010\u0004\u0010\u0010\u0018\u0014\b\u0018\f\u0010\u001c\u0004\u001c\u0004\u001c\u001c    \f\u0004\u001c\u0014\f\u0018\u0018\u0014 \u001c\u001c \u0014\u0018\u0014\u0010\f\f\b\b\b\b".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            IllllII = var9;
            IllllIl = new Object[var9.length];
            int var2 = 1429088748;
            byte[] var0 = "ç\nRú\u0012\u008cUÜ°¦\u001að¡gzQ_Á/§í\u001f¼'\u00874xkhiñäU»¤À#\u009e~+Ù\u0093¡ìÃ\tÖ£\u0091Ø£¥vjÅ]²\u0012)\t|xQ\u008agê<[sE\u000fÔ\u0014\u0088îAiºs\u0011b%×7SÌu\bq\u00875ª\u0092^\u007f&ÿØ]ø\u0096¸q»".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IlllIll = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IlllIll[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            IIlIlIl = x.lIlIII.l(IlIlIIl(58333, 62499, 42015473));
            IIII = x.lIlIII.l(IlIlIIl(12985, 62496, -1667474844));
            lIIll = x.lIlIII.l(IlIlIIl(58431, 62497, -1594746320));
            IIlIIlI = List.of(new Object(IIlIlIl, IIlIlIl) {
               private final <undefinedtype> I;
               private final int l;
               private final <undefinedtype> II;
               private final long Il;
               private final int lI;
               private static final int[] ll;

               public {
                  this((Object)var1, (Object)var2);
               }

               private static <undefinedtype> I(Object var0) {
                  return x.lIlIII.IIIl(var0);
               }

               public <undefinedtype> l() {
                  return this.I;
               }

               public JsonElement II() {
                  return new JsonPrimitive(this.ll());
               }

               public <undefinedtype> Il() {
                  return this.II;
               }

               public long lI() {
                  return this.Il;
               }

               public {
                  this((String)var1, (Object)var2);
               }

               public {
                  this((Object)var1, (Object)var2);
               }

               public String ll() {
                  return this.II.lIlI();
               }

               private static int III(Object var0) {
                  int[] var1 = new int[]{0};
                  var0.Ill((var1) -> {
                     if (Character.isBmpCodePoint(var1)) {
                        var0[0] = Ill(-1117285940, 345343004) * var0[0] + var1;
                     } else {
                        char[] var2 = Character.toChars(var1);
                        var0[0] = Ill(-1117285939, 1915072505) * var0[0] + var2[0];
                        var0[0] = Ill(-1117285938, 1789475354) * var0[0] + var2[1];
                     }
                  });
                  return var1[0];
               }

               // $FF: synthetic method
               private static void IIl(int[] var0, int var1) {
                  if (Character.isBmpCodePoint(var1)) {
                     var0[0] = Ill(-1117285940, 345343004) * var0[0] + var1;
                  } else {
                     char[] var2 = Character.toChars(var1);
                     var0[0] = Ill(-1117285939, 1915072505) * var0[0] + var2[0];
                     var0[0] = Ill(-1117285938, 1789475354) * var0[0] + var2[1];
                  }
               }

               public int hashCode() {
                  return Ill(-1117285937, -372372636) * this.l + this.lI;
               }

               public String IlI() {
                  return this.I.lIlI();
               }

               public {
                  this.II = I(var1);
                  this.I = I(var2);
                  this.Il = this.II.lll();
                  this.l = III(this.II);
                  this.lI = III(this.I);
               }

               public boolean equals(Object var1) {
                  if (var1 == this) {
                     return true;
                  } else {
                     if (var1 instanceof <undefinedtype>) {
                        <undefinedtype> var2 = (<undefinedtype>)var1;
                        if (this.Il == var2.Il && this.I.lll() == var2.I.lll()) {
                           return this.ll().equals(var2.ll()) && this.IlI().equals(var2.IlI());
                        }
                     }

                     return false;
                  }
               }

               private static int Ill(int var0, int var1) {
                  return ll[var0 ^ -1117285940] ^ var1 ^ var0;
               }

               static {
                  int var2 = 1128642418;
                  byte[] var0 = "ê·¢½\u008c\u0007\u0089Y\u0094\u008b\u001c¹\u0017ì-Æ".getBytes("ISO-8859-1");
                  int var1 = var0.length / 4;
                  ll = new int[var1];
                  int var3 = 0;
                  int var4 = 0;

                  do {
                     int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
                     var5 ^= var2;
                     ll[var4] = var5;
                     var3 += 4;
                     ++var4;
                  } while(var4 < var1);

               }
            }, new Object(IIII, IIII) {
               private final <undefinedtype> I;
               private final int l;
               private final <undefinedtype> II;
               private final long Il;
               private final int lI;
               private static final int[] ll;

               public {
                  this((Object)var1, (Object)var2);
               }

               private static <undefinedtype> I(Object var0) {
                  return x.lIlIII.IIIl(var0);
               }

               public <undefinedtype> l() {
                  return this.I;
               }

               public JsonElement II() {
                  return new JsonPrimitive(this.ll());
               }

               public <undefinedtype> Il() {
                  return this.II;
               }

               public long lI() {
                  return this.Il;
               }

               public {
                  this((String)var1, (Object)var2);
               }

               public {
                  this((Object)var1, (Object)var2);
               }

               public String ll() {
                  return this.II.lIlI();
               }

               private static int III(Object var0) {
                  int[] var1 = new int[]{0};
                  var0.Ill((var1) -> {
                     if (Character.isBmpCodePoint(var1)) {
                        var0[0] = Ill(-1117285940, 345343004) * var0[0] + var1;
                     } else {
                        char[] var2 = Character.toChars(var1);
                        var0[0] = Ill(-1117285939, 1915072505) * var0[0] + var2[0];
                        var0[0] = Ill(-1117285938, 1789475354) * var0[0] + var2[1];
                     }
                  });
                  return var1[0];
               }

               // $FF: synthetic method
               private static void IIl(int[] var0, int var1) {
                  if (Character.isBmpCodePoint(var1)) {
                     var0[0] = Ill(-1117285940, 345343004) * var0[0] + var1;
                  } else {
                     char[] var2 = Character.toChars(var1);
                     var0[0] = Ill(-1117285939, 1915072505) * var0[0] + var2[0];
                     var0[0] = Ill(-1117285938, 1789475354) * var0[0] + var2[1];
                  }
               }

               public int hashCode() {
                  return Ill(-1117285937, -372372636) * this.l + this.lI;
               }

               public String IlI() {
                  return this.I.lIlI();
               }

               public {
                  this.II = I(var1);
                  this.I = I(var2);
                  this.Il = this.II.lll();
                  this.l = III(this.II);
                  this.lI = III(this.I);
               }

               public boolean equals(Object var1) {
                  if (var1 == this) {
                     return true;
                  } else {
                     if (var1 instanceof <undefinedtype>) {
                        <undefinedtype> var2 = (<undefinedtype>)var1;
                        if (this.Il == var2.Il && this.I.lll() == var2.I.lll()) {
                           return this.ll().equals(var2.ll()) && this.IlI().equals(var2.IlI());
                        }
                     }

                     return false;
                  }
               }

               private static int Ill(int var0, int var1) {
                  return ll[var0 ^ -1117285940] ^ var1 ^ var0;
               }

               static {
                  int var2 = 1128642418;
                  byte[] var0 = "ê·¢½\u008c\u0007\u0089Y\u0094\u008b\u001c¹\u0017ì-Æ".getBytes("ISO-8859-1");
                  int var1 = var0.length / 4;
                  ll = new int[var1];
                  int var3 = 0;
                  int var4 = 0;

                  do {
                     int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
                     var5 ^= var2;
                     ll[var4] = var5;
                     var3 += 4;
                     ++var4;
                  } while(var4 < var1);

               }
            }, new Object(lIIll, lIIll) {
               private final <undefinedtype> I;
               private final int l;
               private final <undefinedtype> II;
               private final long Il;
               private final int lI;
               private static final int[] ll;

               public {
                  this((Object)var1, (Object)var2);
               }

               private static <undefinedtype> I(Object var0) {
                  return x.lIlIII.IIIl(var0);
               }

               public <undefinedtype> l() {
                  return this.I;
               }

               public JsonElement II() {
                  return new JsonPrimitive(this.ll());
               }

               public <undefinedtype> Il() {
                  return this.II;
               }

               public long lI() {
                  return this.Il;
               }

               public {
                  this((String)var1, (Object)var2);
               }

               public {
                  this((Object)var1, (Object)var2);
               }

               public String ll() {
                  return this.II.lIlI();
               }

               private static int III(Object var0) {
                  int[] var1 = new int[]{0};
                  var0.Ill((var1) -> {
                     if (Character.isBmpCodePoint(var1)) {
                        var0[0] = Ill(-1117285940, 345343004) * var0[0] + var1;
                     } else {
                        char[] var2 = Character.toChars(var1);
                        var0[0] = Ill(-1117285939, 1915072505) * var0[0] + var2[0];
                        var0[0] = Ill(-1117285938, 1789475354) * var0[0] + var2[1];
                     }
                  });
                  return var1[0];
               }

               // $FF: synthetic method
               private static void IIl(int[] var0, int var1) {
                  if (Character.isBmpCodePoint(var1)) {
                     var0[0] = Ill(-1117285940, 345343004) * var0[0] + var1;
                  } else {
                     char[] var2 = Character.toChars(var1);
                     var0[0] = Ill(-1117285939, 1915072505) * var0[0] + var2[0];
                     var0[0] = Ill(-1117285938, 1789475354) * var0[0] + var2[1];
                  }
               }

               public int hashCode() {
                  return Ill(-1117285937, -372372636) * this.l + this.lI;
               }

               public String IlI() {
                  return this.I.lIlI();
               }

               public {
                  this.II = I(var1);
                  this.I = I(var2);
                  this.Il = this.II.lll();
                  this.l = III(this.II);
                  this.lI = III(this.I);
               }

               public boolean equals(Object var1) {
                  if (var1 == this) {
                     return true;
                  } else {
                     if (var1 instanceof <undefinedtype>) {
                        <undefinedtype> var2 = (<undefinedtype>)var1;
                        if (this.Il == var2.Il && this.I.lll() == var2.I.lll()) {
                           return this.ll().equals(var2.ll()) && this.IlI().equals(var2.IlI());
                        }
                     }

                     return false;
                  }
               }

               private static int Ill(int var0, int var1) {
                  return ll[var0 ^ -1117285940] ^ var1 ^ var0;
               }

               static {
                  int var2 = 1128642418;
                  byte[] var0 = "ê·¢½\u008c\u0007\u0089Y\u0094\u008b\u001c¹\u0017ì-Æ".getBytes("ISO-8859-1");
                  int var1 = var0.length / 4;
                  ll = new int[var1];
                  int var3 = 0;
                  int var4 = 0;

                  do {
                     int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
                     var5 ^= var2;
                     ll[var4] = var5;
                     var3 += 4;
                     ++var4;
                  } while(var4 < var1);

               }
            });
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 5) {
                  case 0:
                  default:
                     var10000 = 116;
                     break;
                  case 1:
                     var10000 = 46;
                     break;
                  case 2:
                     var10000 = 58;
                     break;
                  case 3:
                     var10000 = 25;
                     break;
                  case 4:
                     var10000 = 68;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private void lllII() {
      this.IlIIll = 0.0F;
      this.IIIllII = 0.0F;
   }

   private float llllI(IIIllIIII var1) {
      return ((Double)var1.III()).floatValue();
   }

   private float lllll() {
      return class_3532.method_15363(((Double)this.I.III()).floatValue(), 1.0F, this.IIlllI());
   }

   private boolean IIIIII(class_1799 var1) {
      if (var1.method_7960()) {
         return false;
      } else if (!(var1.method_7909() instanceof class_1743) && !(var1.method_7909() instanceof class_9362)) {
         String var2 = class_7923.field_41178.method_10221(var1.method_7909()).method_12832();
         return var2.endsWith(x.lIlIII.Il(IlIlIIl(9741, 62502, 445267607)));
      } else {
         return true;
      }
   }

   private float IIIIIl(float var1, float var2) {
      float var3 = this.IIIIl();
      return class_3532.method_15363(0.024F + var3 * 0.038F + (1.0F - var2) * 0.09F - var1 * 0.018F, 0.024F, 0.14F);
   }

   private float IIIIlI() {
      float var1 = this.IIIIl();
      float var2 = (1.0F + (1.0F - var1) * 1.55F) * 1.12F;
      if (this.IlllI()) {
         var2 *= this.IlllII();
      }

      if (this.IlIll.III() == null.Il) {
         var2 *= 1.25F;
      } else if (this.IlIll.III() == null.I) {
         var2 *= 0.82F;
      } else if (this.IlIll.III() == null.lI) {
         var2 *= 1.55F;
      } else if (this.IlIll.III() == null.l) {
         var2 *= 1.75F;
      }

      return var2;
   }

   private <undefinedtype> IIIIll() {
      return new Record((Double)this.lIIIl.III(), this.lIIIll(), (Boolean)this.lI.III(), this.IIlIll(), this.IIll.IIII(IIlIlIl), this.IIll.IIII(IIII), this.IIll.IIII(lIIll), true) {
         private final double I;
         private final boolean l;
         private final float II;
         private final boolean Il;
         private final boolean lI;
         private final double ll;
         private final boolean III;
         private final boolean IIl;
         private final boolean IlI;
         private final boolean Ill;
         private final <undefinedtype> lII;

         {
            this(var1, var3, var4, var5, var6, var7, var8, var9, true, false, (double)1.0F);
         }

         public {
            this.ll = var1;
            this.II = var3;
            this.Il = var4;
            this.lII = var5;
            this.Ill = var6;
            this.IlI = var7;
            this.IIl = var8;
            this.l = var9;
            this.III = var10;
            this.lI = var11;
            this.I = var12;
         }

         public boolean I() {
            return this.lI;
         }

         public float l() {
            return this.II;
         }

         public double II() {
            return this.ll;
         }

         public boolean Il() {
            return this.III;
         }

         public boolean lI() {
            return this.Il;
         }

         public double ll() {
            return this.I;
         }

         public boolean III() {
            return this.IIl;
         }

         public boolean IIl() {
            return this.IlI;
         }

         public <undefinedtype> IlI() {
            return this.lII;
         }

         public boolean Ill() {
            return this.l;
         }

         public boolean lII() {
            return this.Ill;
         }
      };
   }

   private float IIIlII(float var1) {
      float var2 = this.lllI();
      float var3 = Math.abs(var1);
      float var4 = Math.max(0.0015F, var3 * 0.018F);
      var4 = Math.min(var4, 0.035F);
      if (this.llIIII()) {
         var4 *= 0.35F;
      } else if (this.IlllI()) {
         var4 *= 1.45F;
      }

      return var2 * var4;
   }

   private float IIIlIl(int var1, int var2, int var3) {
      float var4 = this.II(this.III(var1 * IlIlIII(-981072960, -121512963) + var3 * IlIlIII(-981072945, -988573954) + var2 * 5));
      return this.IIII(0.18F, 0.65F, var4);
   }

   private double IIIllI(class_243 var1, class_243 var2, class_243 var3) {
      class_243 var4 = var3.method_1020(var1);
      double var5 = Math.max((double)0.0F, var4.method_1026(var2));
      class_243 var7 = var1.method_1019(var2.method_1021(var5));
      return var3.method_1025(var7);
   }

   public List<llllllI<?>> IIIlll() {
      this.IlllIl();
      return super.IIIlll();
   }

   public float IIlIII(float var1) {
      return class_3532.method_17821(var1, this.IlIIIll, this.IIlIlll);
   }

   private class_243 IIlIIl(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         if (this.IIIl) {
            return this.lIlll(this.IIlIlll, this.IIIIllI);
         } else if (var1.field_1773 != null && var1.field_1773.method_19418() != null) {
            class_4184 var2 = var1.field_1773.method_19418();
            return this.lIlll(var2.method_19330(), var2.method_19329());
         } else {
            return this.lIIllI(var1);
         }
      } else {
         return null;
      }
   }

   private <undefinedtype> IIlIlI(class_310 var1, class_1309 var2, boolean var3) {
      if (!this.IllIII(var1, var2)) {
         return null;
      } else {
         class_243 var4 = var1.field_1724.method_33571();
         class_243 var5 = this.IlIIII.III() == null.II ? this.IIlIIl(var1) : this.lIIllI(var1);
         if (!IlIIIl(var5)) {
            return null;
         } else {
            class_243 var6 = this.llIIIl(var1, var4, var5, var2);
            if (!IlIIIl(var6)) {
               return null;
            } else {
               double var7 = (Double)this.lIIIl.III();
               double var9 = var4.method_1025(var6);
               if (var9 > var7 * var7) {
                  return null;
               } else {
                  class_243 var11 = var6.method_1020(var4);
                  double var12 = Math.sqrt(var11.field_1352 * var11.field_1352 + var11.field_1350 * var11.field_1350);
                  if (var12 <= 1.0E-4) {
                     return null;
                  } else {
                     float var14 = (float)(Math.toDegrees(Math.atan2(var11.field_1350, var11.field_1352)) - (double)90.0F);
                     float var15 = this.IIlll((float)(-Math.toDegrees(Math.atan2(var11.field_1351, var12))));
                     float var16 = class_3532.method_15393(var14 - var1.field_1724.method_36454());
                     float var10000 = var15 - this.IIlll(var1.field_1724.method_36455());
                     float var18 = this.lIIIll();
                     float var19 = this.IIllII(var5, var11);
                     if (var19 > var18 + 2.0F) {
                        return null;
                     } else {
                        double var20 = Math.sqrt(this.IIIllI(var4, var5, var6));
                        double var22 = (double)var19 + var20 * 1.8 + Math.sqrt(var9) * 1.1;
                        if (var3) {
                           var22 -= (double)2.0F;
                        }

                        float var24 = class_3532.method_15363(var19 / Math.max(var18, 1.0F), 0.0F, 1.0F);
                        return new Record(var2.method_5628(), var6, var24, var22, Math.sqrt(var9), (double)var19, (double)var2.method_6032()) {
                           private final double I;
                           private final double l;
                           private final double II;
                           private final int Il;
                           private final double lI;
                           private final class_243 ll;
                           private final float III;

                           public float I() {
                              return this.III;
                           }

                           public class_243 l() {
                              return this.ll;
                           }

                           private {
                              this.Il = var1;
                              this.ll = var2;
                              this.III = var3;
                              this.I = var4;
                              this.II = var6;
                              this.l = var8;
                              this.lI = var10;
                           }

                           public double II() {
                              return this.I;
                           }

                           public double Il() {
                              return this.II;
                           }

                           public double lI() {
                              return this.lI;
                           }

                           public double ll() {
                              return this.l;
                           }

                           public int III() {
                              return this.Il;
                           }
                        };
                     }
                  }
               }
            }
         }
      }
   }

   public <undefinedtype> IIlIll() {
      <undefinedtype> var1 = ((<undefinedtype>)this.IIIIlI.III()).lI;
      if (this.IIlI(var1)) {
         return var1;
      } else if (this.IIll.IIII(IIII)) {
         return null.I;
      } else if (this.IIll.IIII(IIlIlIl)) {
         return null.l;
      } else {
         return this.IIll.IIII(lIIll) ? null.Il : null.I;
      }
   }

   private float IIllII(class_243 var1, class_243 var2) {
      double var3 = var1.method_1033();
      double var5 = var2.method_1033();
      if (!(var3 <= 1.0E-6) && !(var5 <= 1.0E-6)) {
         double var7 = var1.method_1026(var2) / (var3 * var5);
         var7 = class_3532.method_15350(var7, (double)-1.0F, (double)1.0F);
         return (float)Math.toDegrees(Math.acos(var7));
      } else {
         return Float.POSITIVE_INFINITY;
      }
   }

   private boolean IIllIl(class_310 var1) {
      if ((Boolean)this.IIlIllI.III() && var1 != null && var1.method_22683() != null) {
         return !this.lIIl.I() ? false : IllllIlI.IlIII(var1, (class_3675.class_306)this.lIIl.III());
      } else {
         return !(Boolean)this.IIlIllI.III();
      }
   }

   private float IIlllI() {
      return 100.0F;
   }

   private boolean IIllll(double var1, double var3, double var5, double var7, double var9, double var11) {
      int var13 = Double.compare(var1, var3);
      if (var13 != 0) {
         return var13 < 0;
      } else {
         int var14 = Double.compare(var5, var7);
         if (var14 != 0) {
            return var14 < 0;
         } else {
            return Double.compare(var9, var11) < 0;
         }
      }
   }

   private void IlIIII(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         this.IllIl();
         this.IllllI(var1.field_1724.method_36454(), this.IIlll(var1.field_1724.method_36455()));
      } else {
         this.lIllI();
      }
   }

   private static boolean IlIIIl(class_243 var0) {
      return var0 != null && Double.isFinite(var0.field_1352) && Double.isFinite(var0.field_1351) && Double.isFinite(var0.field_1350);
   }

   private <undefinedtype> IlIIlI(float var1, float var2, float var3, float var4, float var5, float var6) {
      float var7 = Math.max(0.003F, var4);
      float var8 = 2.0F / var7;
      float var9 = var8 * var6;
      float var10 = 1.0F / (1.0F + var9 + 0.48F * var9 * var9 + 0.235F * var9 * var9 * var9);
      float var11 = var1 - var2;
      float var12 = var2;
      float var13 = var5 * var7;
      var11 = class_3532.method_15363(var11, -var13, var13);
      var2 = var1 - var11;
      float var14 = (var3 + var8 * var11) * var6;
      float var15 = (var3 - var8 * var14) * var10;
      float var16 = var2 + (var11 + var14) * var10;
      boolean var17 = var12 - var1 > 0.0F == var16 > var12;
      if (var17) {
         var16 = var12;
         var15 *= 0.25F;
      }

      return new Record(var16, var15) {
         private final float I;
         private final float l;

         private {
            this.I = var1;
            this.l = var2;
         }

         public float I() {
            return this.I;
         }

         public float l() {
            return this.l;
         }
      };
   }

   private float IlIIll(float var1, float var2) {
      if (this.llllI(this.lIl) <= 0.0F) {
         return var1;
      } else {
         float var3 = this.IIlll(var2);
         return Math.abs(var3 - var1) <= 0.0125F ? var1 : var3;
      }
   }

   private <undefinedtype> IlIlIl(class_310 var1, Object var2, float var3, float var4, float var5) {
      class_243 var6 = var1.field_1724.method_33571();
      class_243 var7 = var2.l();
      if (!IlIIIl(var7)) {
         return new Record(var3, this.IIlll(var4)) {
            private final float I;
            private final float l;

            private {
               this.l = var1;
               this.I = var2;
            }

            public float I() {
               return this.I;
            }

            public float l() {
               return this.l;
            }
         };
      } else {
         if (this.IIIIIll == var2.III() && IlIIIl(this.IlIIlI)) {
            this.IlIIlI = var7;
         } else {
            this.IIIIIll = var2.III();
            this.IlIIlI = var7;
            this.llllIl = 0.0F;
            this.lIIIlI = 0.0F;
            this.IllIl = 0.0F;
            this.lIllIl(var2.III());
         }

         class_243 var8 = this.lIIlll(var6, this.IlIIlI, var5);
         class_243 var9 = var8.method_1020(var6);
         double var10 = Math.sqrt(var9.field_1352 * var9.field_1352 + var9.field_1350 * var9.field_1350);
         if (var10 <= 1.0E-4) {
            return new Record(var3, this.IIlll(var4)) {
               private final float I;
               private final float l;

               private {
                  this.l = var1;
                  this.I = var2;
               }

               public float I() {
                  return this.I;
               }

               public float l() {
                  return this.l;
               }
            };
         } else {
            float var12 = (float)(Math.toDegrees(Math.atan2(var9.field_1350, var9.field_1352)) - (double)90.0F);
            float var13 = this.IIlll((float)(-Math.toDegrees(Math.atan2(var9.field_1351, var10))));
            return new Record(var12, var13) {
               private final float I;
               private final float l;

               private {
                  this.l = var1;
                  this.I = var2;
               }

               public float I() {
                  return this.I;
               }

               public float l() {
                  return this.l;
               }
            };
         }
      }
   }

   private float IlIllI(float var1, float var2) {
      float var3 = this.IIIIl();
      float var4 = class_3532.method_15363(0.035F + var3 * 0.145F - var1 * 0.02F, 0.03F, 0.22F);
      float var5 = class_3532.method_15363(var4 * class_3532.method_15363(2.0F - var2, 0.95F, 1.05F), 0.03F, 0.22F);
      if (this.IlllI()) {
         var5 *= this.lII();
         return class_3532.method_15363(var5, 0.025F, 0.2F);
      } else if (this.IlIll.III() == null.Il) {
         return class_3532.method_15363(var5 * 0.85F, 0.025F, 0.2F);
      } else {
         return this.IlIll.III() == null.I ? class_3532.method_15363(var5 * 1.15F, 0.035F, 0.24F) : var5;
      }
   }

   private float IlIlll() {
      float var1 = this.IIIIl();
      float var2 = (0.74F + (1.0F - var1) * 1.15F) * 1.12F;
      if (this.IlllI()) {
         var2 *= this.IlllII();
      }

      if (this.IlIll.III() == null.Il) {
         var2 *= 1.2F;
      } else if (this.IlIll.III() == null.I) {
         var2 *= 0.84F;
      } else if (this.IlIll.III() == null.lI) {
         var2 *= 1.48F;
      } else if (this.IlIll.III() == null.l) {
         var2 *= 1.68F;
      }

      return var2 * 0.42F;
   }

   private boolean IllIII(class_310 var1, class_1309 var2) {
      if (var2 != null && var2 != var1.field_1724 && var2.method_5805() && !var2.method_31481() && !var2.method_5767()) {
         if (x.IlIII.l(var2)) {
            return false;
         } else {
            return !(Boolean)this.lIIII.III() || var2 instanceof class_1657;
         }
      } else {
         return false;
      }
   }

   private float IllIIl(float var1, float var2) {
      float var3 = this.IIIIl();
      float var4 = class_3532.method_15363((0.05F + (1.0F - var3) * 0.11F + var1 * 0.08F) * var2, 0.035F, 0.26F);
      if (this.IlllI()) {
         var4 *= this.lll();
         return class_3532.method_15363(var4, 0.08F, 0.72F);
      } else {
         return var4;
      }
   }

   public boolean IllIlI() {
      class_310 var1 = class_310.method_1551();
      return this.IIIl && var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1755 == null ? this.lIIIIl(var1) : false;
   }

   private void IllIll(class_310 var1, float var2, long var3) {
      if (this.llI()) {
         this.IlIIII(var1);
         this.IllIIl = var3;
      } else if (!this.llIII(var1)) {
         this.IlIIII(var1);
         this.IllIIl = var3;
      } else {
         <undefinedtype> var5 = this.IIll(var1);
         if (var5 == null) {
            this.IlIIII(var1);
            this.IllIIl = var3;
         } else {
            this.lIIlII(var1, var5, var2);
            this.IllIIl = var3;
         }
      }
   }

   private float IlllII() {
      return this.IIII(3.0F, 6.5F, this.lIllll());
   }

   public void lIl() {
      this.IlllIl();
      this.IIlll.IIlIIII();
      this.lIlIlI(class_310.method_1551(), true);
   }

   private void IlllIl() {
      if (this.IlllI()) {
         this.IIlIII.IIII((double)2.0F, (double)360.0F);
         this.I.IIII((double)1.0F, (double)100.0F);
         this.lIIIl.IIII((double)1.0F, (double)100.0F);
      } else {
         this.IIlIII.IIII((double)2.0F, (double)360.0F);
         this.I.IIII((double)1.0F, (double)100.0F);
         this.lIIIl.IIII((double)1.0F, (double)8.0F);
      }

   }

   private void IllllI(float var1, float var2) {
      this.l = true;
      this.IIlllll = var1;
      this.lIllIl = this.IIlll(var2);
   }

   private <undefinedtype> Illlll(class_310 var1) {
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null) {
         <undefinedtype> var2 = this.IIIIll();
         if (this.IlIIII.III() == null.l) {
            <undefinedtype> var3 = this.lIII(var1, this.IIIlIll.Ill(), var2, true);
            if (var3 != null) {
               return var3;
            }
         }

         <undefinedtype> var9 = null;
         class_1309 var4 = null;

         for(class_1297 var6 : var1.field_1687.method_18112()) {
            if (var6 instanceof class_1309) {
               class_1309 var7 = (class_1309)var6;
               <undefinedtype> var8 = this.lIII(var1, var7, var2, false);
               if (var8 != null && (var9 == null || this.IlII(var1, var7, var8, var4, var9))) {
                  var9 = var8;
                  var4 = var7;
               }
            }
         }

         return var9;
      } else {
         return null;
      }
   }

   private boolean lIIIII(class_310 var1) {
      long var2 = System.currentTimeMillis();
      if (this.IIllI(var1)) {
         this.lllIlI = var2 + 120L;
         return true;
      } else {
         return var2 <= this.lllIlI;
      }
   }

   private boolean lIIIIl(class_310 var1) {
      return this.llIII(var1) && this.Illlll(var1) != null;
   }

   private float lIIIlI(IIIllIIII var1, IIIllIIII var2) {
      return Math.max(this.llllI(var1), this.llllI(var2));
   }

   private float lIIIll() {
      return class_3532.method_15363(((Double)this.IIlIII.III()).floatValue() * 0.5F, 0.5F, 180.0F);
   }

   private void lIIlII(class_310 var1, Object var2, float var3) {
      float var4 = var1.field_1724.method_36454();
      float var5 = this.IIlll(var1.field_1724.method_36455());
      <undefinedtype> var6 = this.IlIlIl(var1, var2, var4, var5, var3);
      float var7 = var6.l();
      float var8 = this.IlIIll(var5, var6.I());
      float var9 = this.llII(class_3532.method_15393(var7 - var4));
      if (this.IIIlllI != 0.0F) {
         var7 = var4 + var9;
      }

      float var10 = var8 - var5;
      this.llIIlI(var4, var5, var9, var10);
      float var11 = this.IllII(this.IIlllII, var2.III(), IlIlIII(-981072946, -1288285148), var3, 0.92F, 1.08F);
      float var12 = this.IllII(this.IIlIIll, var2.III(), IlIlIII(-981072947, 1228639130), var3, 0.91F, 1.07F);
      float var13 = this.Illl(var2, var9, var10);
      float var14 = this.IIIIIl(var13, var11);
      float var15 = this.IIIIIl(var13, var12) * 0.78F;
      float var16 = Math.max(0.0F, Math.min(var3, 0.1F));
      this.llllIl += var16;
      float var17 = this.IIIl(var13);
      if (Math.abs(var9) <= var14 && Math.abs(var10) <= var15) {
         this.lllII();
         this.IllllI(var4, var5);
      } else {
         boolean var18 = this.IlIIlll > 0;
         boolean var19 = this.lllllI > 0;
         if (var18 && var19) {
            this.lllII();
            this.IllllI(var4, var5);
         } else {
            float var20 = this.IIIIlI();
            float var21 = this.IlIlll();
            <undefinedtype> var22 = this.IlI(var4, var7, this.IlIIll, var20, var18, var3, var13, var11, true);
            Object var23 = var10 == 0.0F ? new Record(var5, 0.0F) {
               private final float I;
               private final float l;

               private {
                  this.I = var1;
                  this.l = var2;
               }

               public float I() {
                  return this.I;
               }

               public float l() {
                  return this.l;
               }
            } : this.IlI(var5, var8, this.IIIllII, var21, var19, var3, var13, var12, false);
            float var24 = class_3532.method_15393(var22.I() - var4);
            float var25 = ((<undefinedtype>)var23).I() - var5;
            this.IlIIll = var22.l();
            this.IIIllII = ((<undefinedtype>)var23).l();
            if (Math.abs(var8 - var5) <= 0.0015F || Math.abs(var25) <= 0.0015F) {
               var25 = 0.0F;
               this.IIIllII = 0.0F;
            }

            if (Math.abs(var24) <= 0.01F && Math.abs(var25) <= 0.01F) {
               this.IllllI(var4, var5);
            } else {
               float var26 = this.lIlIl(var3);
               var24 *= var26;
               var25 *= var26;
               var24 += this.IIIlII(var24);
               var25 += this.IIIlII(var25) * 0.16F;
               var24 += this.lIIlIl(var16) * var17;
               var25 += this.ll(var3) * var17;
               if (this.lIIIlI == 0.0F && this.IllIl == 0.0F) {
                  if (var17 > 0.95F && !this.llIIII()) {
                     ThreadLocalRandom var27 = ThreadLocalRandom.current();
                     if (var27.nextFloat() < 0.022F * var16) {
                        float var28 = 0.025F + var27.nextFloat() * 0.04F;
                        float var29 = var24 * var28;
                        float var30 = var25 * var28;
                        var24 += var29;
                        var25 += var30 * 0.35F;
                        this.lIIIlI = -var29;
                        this.IllIl = -var30;
                     }
                  }
               } else {
                  var24 += this.lIIIlI;
                  var25 += this.IllIl;
                  this.lIIIlI = 0.0F;
                  this.IllIl = 0.0F;
               }

               float var39 = this.lIll(var1);
               var24 = this.lIlIII(var24, var39);
               var25 = this.lIlIII(var25, var39);
               float var40 = var4 + var24;
               float var41 = this.IIlll(var5 + var25);
               IllllIlI.IIIlIII(var1, var40, var41);
               this.IllllI(var40, var41);
            }
         }
      }
   }

   private float lIIlIl(float var1) {
      for(this.IlIIIII += Math.max(0.0F, var1) * 2.7F; this.IlIIIII >= 1.0F; this.IIIlIIl = ThreadLocalRandom.current().nextFloat() * 2.0F - 1.0F) {
         --this.IlIIIII;
         this.IIlllIl = this.IIIlIIl;
      }

      float var2 = class_3532.method_15363(this.IlIIIII, 0.0F, 1.0F);
      float var3 = var2 * var2 * (3.0F - 2.0F * var2);
      return class_3532.method_16439(var3, this.IIlllIl, this.IIIlIIl) * 0.04F;
   }

   public void Ill() {
      this.IlllIl();
      class_310 var1 = class_310.method_1551();
      this.lIlIlI(var1, false);
      boolean var2 = !this.llI() && this.llIII(var1);
      this.IIlll.IIllIl(var1, this.lIIIl(), var2, var2 ? this.Illlll(var1) : null, this.llIIII());
   }

   private class_243 lIIllI(class_310 var1) {
      class_243 var2 = var1.field_1724.method_5828(1.0F);
      double var3 = var2.method_1027();
      return var3 <= 1.0E-6 ? null : var2.method_1021((double)1.0F / Math.sqrt(var3));
   }

   private class_243 lIIlll(class_243 var1, class_243 var2, float var3) {
      if (!this.IIIIll) {
         ThreadLocalRandom var4 = ThreadLocalRandom.current();
         this.llIlll = var4.nextFloat() * 0.9F + 0.35F;
         this.IlIllI = var4.nextFloat() * 0.9F + 0.35F;
         this.llllll = var4.nextFloat() * 0.9F + 0.35F;
         this.lIlIII = var4.nextFloat() * ((float)Math.PI * 2F);
         this.IlIlII = var4.nextFloat() * ((float)Math.PI * 2F);
         this.IlllII = var4.nextFloat() * ((float)Math.PI * 2F);
         this.IIIIll = true;
      }

      float var24 = Math.max(0.0F, Math.min(var3, 0.1F));
      ThreadLocalRandom var5 = ThreadLocalRandom.current();
      float var6 = 1.0F + (var5.nextFloat() - 0.5F) * 0.12F;
      float var7 = 1.0F + (var5.nextFloat() - 0.5F) * 0.12F;
      float var8 = 1.0F + (var5.nextFloat() - 0.5F) * 0.12F;
      this.IIIIl += var24 * this.llIlll * var6 * ((float)Math.PI * 2F);
      this.IIllllI += var24 * this.IlIllI * var7 * ((float)Math.PI * 2F);
      this.llIllI += var24 * this.llllll * var8 * ((float)Math.PI * 2F);
      float var9 = (float)(Math.sin((double)(this.IIIIl + this.lIlIII)) * (double)0.5F + Math.sin((double)this.IIIIl * 1.7 + (double)this.IlIlII) * 0.3 + Math.sin((double)this.llIllI * 2.3 + (double)this.IlllII) * 0.2);
      float var10 = (float)(Math.sin((double)(this.IIllllI + this.IlIlII)) * 0.45 + Math.sin((double)this.IIllllI * 1.3 + (double)this.lIlIII) * 0.3 + Math.sin((double)this.llIllI * 1.9 + (double)this.IlllII) * (double)0.25F);
      var9 += (var5.nextFloat() - 0.5F) * 0.15F;
      var10 += (var5.nextFloat() - 0.5F) * 0.15F;
      class_243 var11 = var2.method_1020(var1);
      double var12 = Math.sqrt(var11.field_1352 * var11.field_1352 + var11.field_1350 * var11.field_1350);
      if (var12 <= 1.0E-4) {
         return var2;
      } else {
         double var14 = -var11.field_1350 / var12;
         double var16 = var11.field_1352 / var12;
         double var18 = var14 * (double)var9 * (double)0.052F;
         double var20 = var16 * (double)var9 * (double)0.052F;
         double var22 = (double)(var10 * 0.052F);
         return var2.method_1031(var18, var22, var20);
      }
   }

   private float lIlIII(float var1, float var2) {
      if (!(var2 <= 1.0E-6F) && Float.isFinite(var2) && Float.isFinite(var1)) {
         float var3 = Math.abs(var1);
         return var3 < var2 * 0.5F ? 0.0F : (float)Math.round(var1 / var2) * var2;
      } else {
         return var1;
      }
   }

   private class_243 lIlIIl(class_243 var1, class_238 var2, float var3, float var4) {
      if (!this.IIIIIl) {
         ThreadLocalRandom var5 = ThreadLocalRandom.current();
         this.llIll = var5.nextFloat() * 1.0999999F + 0.3F;
         this.lIIlII = var5.nextFloat() * 1.0999999F + 0.3F;
         this.IIIlI = var5.nextFloat() * 1.0999999F + 0.3F;
         this.IIIIIl = true;
      }

      float var15 = Math.max(0.0F, Math.min(var3, 0.1F));
      this.lllIl += var15 * this.llIll * ((float)Math.PI * 2F);
      this.IIllIlI += var15 * this.lIIlII * ((float)Math.PI * 2F);
      this.lIlII += var15 * this.IIIlI * ((float)Math.PI * 2F);
      float var6 = (float)(Math.sin((double)this.lllIl) * 0.6 + Math.sin((double)this.lllIl * 1.9) * 0.4);
      float var7 = (float)(Math.sin((double)this.IIllIlI) * 0.55 + Math.sin((double)this.IIllIlI * (double)1.5F) * 0.45);
      float var8 = (float)(Math.sin((double)this.lIlII) * 0.65 + Math.sin((double)this.lIlII * 1.7) * 0.35);
      double var9 = var1.field_1352 + (double)(var6 * var4);
      double var11 = var1.field_1351 + (double)(var7 * var4);
      double var13 = var1.field_1350 + (double)(var8 * var4);
      return new class_243(class_3532.method_15350(var9, var2.field_1323, var2.field_1320), class_3532.method_15350(var11, var2.field_1322, var2.field_1325), class_3532.method_15350(var13, var2.field_1321, var2.field_1324));
   }

   private void lIlIlI(class_310 var1, boolean var2) {
      boolean var3 = this.IIIIIlI() && this.IlllI() && (Boolean)this.llIl.III() && var1 != null && var1.field_1724 != null && var1.field_1687 != null && this.lIIIIl(var1);
      if (var3 == this.IIIl) {
         if (var3) {
            this.IlIIIll = this.IIlIlll;
            this.IIIIlll = this.IIIIllI;
         }

      } else {
         this.IIIl = var3;
         if (var3) {
            this.IIlIlll = var1.field_1724.method_36454();
            this.IIIIllI = var1.field_1724.method_36455();
            this.IlIIIll = this.IIlIlll;
            this.IIIIlll = this.IIIIllI;
         } else {
            if (!var2) {
               this.IlIIIll = var1 != null && var1.field_1724 != null ? var1.field_1724.method_36454() : this.IlIIIll;
               this.IIIIlll = var1 != null && var1.field_1724 != null ? var1.field_1724.method_36455() : this.IIIIlll;
            }

         }
      }
   }

   private float lIlIll(float var1, float var2) {
      return (float)Math.hypot((double)var1, (double)var2);
   }

   private void lIllII(JsonObject var1) {
      if (var1 != null) {
         JsonElement var2 = var1.get(this.I.Illl());
         if (var2 != null && var2.isJsonPrimitive() && var2.getAsJsonPrimitive().isNumber()) {
            double var3 = var2.getAsDouble();
            if (var3 >= (double)0.0F && var3 <= (double)10.0F) {
               var1.addProperty(this.I.Illl(), Math.min((double)100.0F, Math.max((double)1.0F, var3 * (double)20.0F)));
            }

         }
      }
   }

   private void lIllIl(int var1) {
      int var2 = this.III(var1 * IlIlIII(-981072948, 1403124878) + IlIlIII(-981072949, 24152477));
      int var3 = this.III(var1 * IlIlIII(-981072950, -423432344) + IlIlIII(-981072951, 582615809));
      this.IlIIIII = this.II(var2);
      this.IIlllIl = this.II(this.III(var2 ^ IlIlIII(-981072952, -321855989))) * 2.0F - 1.0F;
      this.IIIlIIl = this.II(this.III(var2 ^ IlIlIII(-981072937, -146650054))) * 2.0F - 1.0F;
      this.lIllII = this.II(var3);
      this.ll = this.II(this.III(var3 ^ IlIlIII(-981072938, -470974389))) * 2.0F - 1.0F;
      this.lIIIll = this.II(this.III(var3 ^ IlIlIII(-981072939, -2078237150))) * 2.0F - 1.0F;
      int var4 = this.III(var1 * IlIlIII(-981072940, -116238018) + IlIlIII(-981072941, -225575559));
      this.llIlll = 0.35F + this.II(var4) * 0.9F;
      this.IlIllI = 0.35F + this.II(this.III(var4 ^ IlIlIII(-981072942, -1016837023))) * 0.9F;
      this.llllll = 0.35F + this.II(this.III(var4 ^ IlIlIII(-981072943, -516998145))) * 0.9F;
      this.lIlIII = this.II(this.III(var4 ^ IlIlIII(-981072944, 49702614))) * ((float)Math.PI * 2F);
      this.IlIlII = this.II(this.III(var4 ^ IlIlIII(-981072929, 1869659128))) * ((float)Math.PI * 2F);
      this.IlllII = this.II(this.III(var4 ^ IlIlIII(-981072930, 101724703))) * ((float)Math.PI * 2F);
      this.IIIIll = true;
   }

   private float lIlllI(long var1) {
      if (this.IllIIl == 0L) {
         return 0.05F;
      } else {
         float var3 = (float)(var1 - this.IllIIl) / 1.0E9F;
         return class_3532.method_15363(var3, 0.0033333334F, 0.055555556F);
      }
   }

   private float lIllll() {
      float var1 = class_3532.method_15363(this.lllll(), 0.0F, this.IIlllI());
      return class_3532.method_15363(var1 / Math.max(1.0F, this.IIlllI()), 0.0F, 1.0F);
   }

   private boolean llIIII() {
      return false;
   }

   private class_243 llIIIl(class_310 var1, class_243 var2, class_243 var3, class_1309 var4) {
      double var5 = (Double)this.lIIIl.III();
      float var7 = this.lIIIll();
      boolean var8 = this.IIll.IIII(IIlIlIl);
      boolean var9 = this.IIll.IIII(IIII);
      boolean var10 = this.IIll.IIII(lIIll);
      boolean var11 = var8 && var9 && var10;
      class_243 var12 = null;
      double var13 = Double.POSITIVE_INFINITY;

      for(<undefinedtype> var16 : IlllIlII.IlIIlll(var8, var9, var10)) {
         class_243 var17 = IlllIlII.IlIIllI(var4, var16);
         if ((Boolean)this.lI.III()) {
            class_238 var18 = IlllIlII.IlIIIlI(var4, var16);
            float var19 = this.IIIII(var1, var2, var17);
            var17 = this.lIlIIl(var17, var18 == null ? var4.method_5829() : var18, 0.05F, var19);
         }

         if (IlIIIl(var17) && !(var2.method_1025(var17) > var5 * var5)) {
            class_243 var26 = var17.method_1020(var2);
            float var27 = this.IIllII(var3, var26);
            if (!(var27 > var7 + 2.0F)) {
               double var20 = var2.method_1025(var17);
               double var22;
               if (var11) {
                  var22 = var20;
               } else {
                  double var24 = Math.sqrt(this.IIIllI(var2, var3, var17));
                  var22 = (double)var27 + var24 * 1.8 + Math.sqrt(var20) * 1.1;
               }

               if (var22 < var13) {
                  var13 = var22;
                  var12 = var17;
               }
            }
         }
      }

      return var12;
   }

   private void llIIlI(float var1, float var2, float var3, float var4) {
      if ((Boolean)this.IIIlII.III() && this.l) {
         this.IlIIlll = this.IlIIl(var1, this.IIlllll, var3, this.IlIIlll, true);
         this.lllllI = this.IlIIl(var2, this.lIllIl, var4, this.lllllI, false);
      } else {
         this.IlIIlll = 0;
         this.lllllI = 0;
      }
   }

   public boolean llIIll(class_1297 var1) {
      class_310 var2 = class_310.method_1551();
      return var2 != null && var2.field_1724 != null && var1 == var2.field_1724 && this.IllIlI();
   }

   public void llIlII(float var1, float var2, float var3, float var4) {
      float var5 = class_3532.method_15393(var3 - var1);
      float var6 = var4 - var2;
      this.IIlIlll = class_3532.method_15393(this.IIlIlll + var5);
      this.IIIIllI = class_3532.method_15363(this.IIIIllI + var6, -90.0F, 90.0F);
   }

   private static int IlIlIII(int var0, int var1) {
      return IlllIll[var0 ^ -981072953] ^ var1 ^ var0;
   }

   private static String IlIlIIl(int var0, int var1, int var2) {
      int var3 = var1 ^ '\uf41a';
      char[] var4 = IllllII[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])IllllIl[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         IllllIl[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 15096;
      int var9 = 0;

      do {
         int var10 = var4[var9] - 29407;
         var10 -= 45613;
         var10 += 52981;
         var10 ^= 33370;
         var10 += 63013;
         var10 ^= 62989;
         var4[var9] = (char)(var10 ^ var8 ^ var0 ^ var2 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
