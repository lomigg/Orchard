package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public enum llIll {
   I,
   l;

   private static String[] II;
   lI;

   private final <undefinedtype> ll;
   private static final int[] III;
   private static final String[] IIl;
   private static final Object[] IlI;

   private static void I() {
      II[0] = Il(ll(142864682, -219077011).toCharArray(), 79270L, lI(1479134880, -1368683773));
      II[1] = Il(ll(142864683, 219026640).toCharArray(), 94387L, lI(1479134881, 181280344));
      II[2] = Il(ll(142864680, -132032594).toCharArray(), 75546L, lI(1479134882, -1901002631));
      II[3] = Il(ll(142864681, 554701400).toCharArray(), 18320L, lI(1479134883, -2143576037));
      II[4] = Il(ll(142864686, 317332391).toCharArray(), 43303L, lI(1479134884, 600907567));
      II[5] = Il(ll(142864687, 1794538210).toCharArray(), 88538L, lI(1479134885, 1254919843));
   }

   static {
      short var6 = 12497;
      String var7 = "碁ﾘ蚹붉椖傳迟욾㧑\u0080燵ቐ\ue05b돛徤步郙눼뗷ན烰懴㫵\uec0a\ueebe棇霰э≞둗쓕ᕉ";
      char[] var8 = "\b\u0004\u0005\u0003\u0004\b".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         char var12 = '\u0000';
         if (var13 == 0) {
            IIl = var9;
            IlI = new Object[var9.length];
            int var2 = 1200668646;
            byte[] var0 = "wV,\u0089§\u0083ÿËêý\u008c]^ÎíMõÑ\u0014S\u0095loª§îB\u0096(Ó\u001e`«ìeX".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            III = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               III[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            II = new String[lI(1479134886, -1202244656)];
            I();
            l = new llIll(II[2], 0, lIlIII.III(lIlIII.Il(II[0])));
            I = new llIll(II[3], 1, lIlIII.III(lIlIII.Il(II[4])));
            lI = new llIll(II[1], 2, lIlIII.III(lIlIII.Il(II[5])));
            return;
         }

         do {
            var12 = var8[var10];
            char[] var14 = var7.substring(var11, var11 + var12).toCharArray();
            int var15 = 0;

            do {
               byte var10000;
               switch (var15 % 6) {
                  case 0:
                  default:
                     var10000 = 61;
                     break;
                  case 1:
                     var10000 = 32;
                     break;
                  case 2:
                     var10000 = 123;
                     break;
                  case 3:
                     var10000 = 13;
                     break;
                  case 4:
                     var10000 = 117;
                     break;
                  case 5:
                     var10000 = 47;
               }

               byte var16 = var10000;
               var14[var15] = (char)(var14[var15] ^ var16 ^ var6);
               ++var15;
            } while(var15 < var14.length);

            var9[var10] = (new String(var14)).intern();
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   public String toString() {
      return this.ll.lIlI();
   }

   public static llIll l(String var0) {
      return (llIll)Enum.valueOf(llIll.class, var0);
   }

   // $FF: synthetic method
   private static llIll[] II() {
      return new llIll[]{l, I, lI};
   }

   private static String Il(char[] var0, long var1, int var3) {
      int var4 = lI(1479134887, -1864715174) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & lI(1479134888, -1269492503);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private llIll(Object var3) {
      this.ll = var3;
   }

   private static int lI(int var0, int var1) {
      return III[var0 ^ 1479134880] ^ var1 ^ var0;
   }

   private static String ll(int var0, int var1) {
      int var3 = var0 ^ 142864682;
      char[] var4 = IIl[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])IlI[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         IlI[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ 1100314231;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 252;
               break;
            case 1:
               var9 = 196;
               break;
            case 2:
               var9 = 219;
               break;
            case 3:
               var9 = 52;
               break;
            case 4:
               var9 = 189;
               break;
            case 5:
               var9 = 226;
               break;
            case 6:
               var9 = 53;
               break;
            case 7:
               var9 = 133;
               break;
            case 8:
               var9 = 169;
               break;
            case 9:
               var9 = 9;
               break;
            case 10:
               var9 = 130;
               break;
            case 11:
               var9 = 149;
               break;
            case 12:
               var9 = 82;
               break;
            case 13:
               var9 = 93;
               break;
            case 14:
               var9 = 101;
               break;
            case 15:
               var9 = 182;
               break;
            case 16:
               var9 = 252;
               break;
            case 17:
               var9 = 91;
               break;
            case 18:
               var9 = 141;
               break;
            case 19:
               var9 = 216;
               break;
            case 20:
               var9 = 232;
               break;
            case 21:
               var9 = 132;
               break;
            case 22:
               var9 = 39;
               break;
            case 23:
               var9 = 149;
               break;
            case 24:
               var9 = 15;
               break;
            case 25:
               var9 = 150;
               break;
            case 26:
               var9 = 109;
               break;
            case 27:
               var9 = 99;
               break;
            case 28:
               var9 = 177;
               break;
            case 29:
               var9 = 82;
               break;
            case 30:
               var9 = 116;
               break;
            case 31:
               var9 = 210;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
