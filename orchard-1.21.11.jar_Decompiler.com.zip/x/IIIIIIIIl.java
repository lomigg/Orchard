package x;

import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Consumer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_5134;
import net.minecraft.class_6880;
import net.minecraft.class_746;
import net.minecraft.class_7923;
import net.minecraft.class_9304;
import net.minecraft.class_9334;
import net.minecraft.class_9362;
import net.minecraft.class_239.class_240;

@Environment(EnvType.CLIENT)
public final class IIIIIIIIl extends IIIIIIIlI {
   private long I;
   private static final double l = (double)3.0F;
   private boolean II;
   private boolean Il;
   private final IIIllIIII lI;
   private int ll;
   private final llllIlIl III;
   private final lIIIIl IIl;
   private static final long IlI = 1L;
   private static String[] Ill;
   private int lII;
   private <undefinedtype> lIl;
   private static final long llI = 1000L;
   private final lIIIIl lll;
   private long IIII;
   private static final int IIIl = 3;
   private <undefinedtype> IIlI;
   private boolean IIll;
   private int IlII;
   private int IlIl;
   private long IllI;
   private static final long Illl = 350L;
   private boolean lIII;
   private Consumer<Boolean> lIIl;
   private static final long lIlI = 1500L;
   private boolean lIll;
   private boolean llII;
   private int llIl;
   private double lllI;
   private boolean llll;
   private final lIIIIl IIIII;
   private long IIIIl;
   private boolean IIIlI;
   private final IIIllIIII IIIll;
   private <undefinedtype> IIlII;
   private class_1309 IIlIl;
   private static final int IIllI = 9;
   private class_239 IIlll;
   private double IlIII;
   private long IlIIl;
   private long IlIlI;
   private static final int[] IlIll;
   private static final String[] IllII;
   private static final Object[] IllIl;

   private boolean ll(class_310 var1, class_3966 var2, class_1309 var3) {
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null && var3 != null && var3 != var1.field_1724 && var3.method_5805() && !var3.method_31481() && var1.field_1687.method_8469(var3.method_5628()) == var3) {
         if (var2 != null && var2.method_17782() == var3 && var2.method_17784() != null) {
            class_243 var4 = var1.field_1724.method_33571();
            class_243 var5 = var2.method_17784();
            return var4.method_1025(var5) <= (double)9.0F && this.IlllI(var1, var4, var5);
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   static {
      short var6 = 17679;
      String var7 = "뉇䵨돹澶␃碥웵鵢鄗佮씥ᙦ彽孜벗磫㴩ᇅꄬ⃐\ueb0d䪙⋗˞㫴ㅡ铏䜛顶䞵헕⥒혅ꖚ\uf3bb푼\u1776巵萔\uab08ᗮ쀢㸅軰⾺肴ܯ⧶숣ナҁᅡ缌⸱㖼ꢻ溞Ꭷꥐ黋\ud82e㣨큗\uec21귂荵櫵્뙥金䉋䬊挠攓䡺髌ꬭ\uf6dd欲갾\ue602퇭遖\ue8ee\ude52옷Ӕ\udd98袼 \uf4bc敏媢씻粀⮤뼮䯫∽藏Í珇\uf231\ue407쳘埨馥臚\uee18\ue2c8ꝥ綸頀\ueb3f饌֖嬵\uf363䙙儺\ueea6怣༮醊鿭年䂰㟚ꄪ뀿䢙\udf6f⒎炻抋쩗㧷ꄖ\u07b3搆켉㑏惥\ued65缼셃\u0adc퓉\ue32b芿⾔鎧ඌ閌蓚쪗ﰚଳ奁\uf442\ue350䒬犵驢㛋ာ炆붤ᯇ쿓荤ℹ㏗猯迒疣教╛ᯁ麨꽢蕍ᛶ\ue9d2ࣹ峚쓋\ue8f5熘ৎ\uaad3땒驪㣞흶뺼\ud8ce晀\uf543\uf71e燶됍\ue592Ᏽ";
      char[] var8 = "䔇䔇䔗䔟䕏䔟䔃䔃䔋䔋䔟䔛".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            IllII = var9;
            IllIl = new Object[var9.length];
            int var2 = 1389024003;
            byte[] var0 = "®\u0085ßlÅÍ\u0007ue\u009b\u0087Óy\u008bÈ\u009b\u0089\u0099\\ÑéË\u00adùìjê\u0096 \u0012\u0094S$h\u008dd\u0097Ø%\u009cü 1.\n3+iºß\u001aìû;[`\u0010ÄÊ§ü\u0090ïäLwÁ°\u0016¨1©\u0081ãÁ!\u008e1¥\u0082´\u009cXH\u009bÔ\u0001YVÕn1'þãì(r*6ÇÂº7\u0095\u0003OØ©E\u0015\u0096ål\u0088Ã\u0001\u0007£Ñ\u0013XÝó¢Q\u000eá\u009e\u0010\u008dÿÞ \u0003ÏLÖ\u0088\f\u00984ð;\u0007$©\u007f\u009d9è Ú\u0003T\u0015Ò\u008fEgØÓÀÛq\r\u0093N¸\u0017f¯Ì\u0099\u0004ONkô['v1oô\u0092û\u0092ðæ¯-hFÏ÷".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            IlIll = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               IlIll[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            Ill = new String[lIIIll(-1275383496, 1337212250)];
            IlIllI();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static double lII(double var0, double var2, double var4) {
      return Math.max(var2, Math.min(var4, var0));
   }

   private boolean llI(class_746 var1) {
      return var1 != null && !var1.method_24828() && !var1.method_6128() && !var1.method_5799() && !var1.method_5869() && !var1.method_5771() && !var1.method_6101() && !var1.method_5765() && !var1.method_31549().field_7479 && !IllllIlI.ll(var1);
   }

   private boolean lll(class_310 var1, class_3966 var2) {
      if (this.Il) {
         if (!this.llIII(var1)) {
            return false;
         }

         IllllIlI.lIllll(var1);
      }

      return this.IllIII(var1, var2, this.llIl);
   }

   private void IIII(class_310 var1, long var2) {
      if (this.lIll) {
         this.lIlll(var2);
      } else if (var1 != null && var1.field_1724 != null && this.llI(var1.field_1724)) {
         if (var1.field_1724.field_6012 >= this.ll) {
            if (!IllllIlI.IlIllIl(var1, this.IIlIl)) {
               if (!this.IIIIlI(var1)) {
                  if (this.IIlIlI(var2)) {
                     this.IIlIl(var1, var2);
                     this.lIlll(var2);
                  }

               } else if (!this.IIIll(var1, this.llIl, false)) {
                  if (var2 - this.IlIlI > 350L) {
                     this.IIlIl(var1, var2);
                     this.lIlll(var2);
                  }

               } else {
                  class_3966 var4 = this.IIlllI(var1, this.IIlIl);
                  if (var4 == null) {
                     if (this.IIlIlI(var2)) {
                        this.IIlIl(var1, var2);
                        this.lIlll(var2);
                     }

                  } else {
                     this.lIIl = (var2x) -> {
                        long var3 = System.currentTimeMillis();
                        if (!var2x) {
                           if (this.lII++ < 3 && this.llI(var1.field_1724) && !this.IIlIlI(var3)) {
                              this.lIl = null.lI;
                              this.I = var3;
                           } else {
                              this.lIlll(var3);
                           }
                        } else {
                           this.lIll = true;
                           this.llII = true;
                           this.IIII = var3 + 0L;
                           this.lIlll(var3);
                        }
                     };
                     if (!this.IlIl(var1, var4, this.llIl)) {
                        this.lIIl = null;
                        if (this.IIlIlI(var2)) {
                           this.IIlIl(var1, var2);
                           this.lIlll(var2);
                        }
                     }

                  }
               }
            }
         }
      } else {
         this.lIlll(var2);
      }
   }

   private boolean IIll(class_1799 var1) {
      return var1 != null && !var1.method_7960() && var1.method_7909() instanceof class_9362 && this.llIlI(var1, null.III.Il) > 0;
   }

   private void IlII(class_310 var1, long var2) {
      if (this.IlIl >= 0 && this.IIIIll(var1, false)) {
         if (!IllllIlI.IlIllIl(var1, this.IIlIl)) {
            class_3966 var4 = this.lIII(var1, this.IIlIl);
            if (var4 == null) {
               if (this.IIlIlI(var2)) {
                  this.lIlll(var2);
               }

            } else {
               this.IllIlI(var1);
               if (!this.IIIll(var1, this.IlIl, true)) {
                  this.I = var2;
               } else {
                  this.lIIl = (var2x) -> {
                     long var3 = System.currentTimeMillis();
                     if (!var2x) {
                        this.lIlll(var3);
                     } else {
                        this.ll = var1.field_1724.field_6012 + 1;
                        this.lIl = null.lI;
                        this.IlIlI = var3;
                        if (this.IIIIlI(var1) && !this.IllII(var1)) {
                           this.lIIll(var1, this.llIl);
                        }

                        this.I = var3;
                     }
                  };
                  boolean var5 = this.IlIl(var1, var4, this.IlIl);
                  if (!var5) {
                     this.lIIl = null;
                     this.lIlll(var2);
                  }

               }
            }
         }
      } else {
         this.lIlll(var2);
      }
   }

   private boolean IlIl(class_310 var1, class_3966 var2, int var3) {
      return this.IllIII(var1, var2, var3);
   }

   private boolean Illl(class_310 var1) {
      if (!this.IIIIlI(var1)) {
         return false;
      } else if (this.Il) {
         return this.llIII(var1);
      } else {
         return this.lIIll(var1, this.llIl) && this.IllII(var1);
      }
   }

   private class_3966 lIII(class_310 var1, class_1309 var2) {
      if (var1 != null && var1.field_1724 != null && var2 != null) {
         class_239 var5 = var1.field_1765;
         class_3966 var3;
         class_3966 var4 = var5 instanceof class_3966 ? (var3 = (class_3966)var5) : null;
         if (!this.ll(var1, var4, var2)) {
            var4 = IllllIlI.IlIIllI(var1, (double)3.0F);
         }

         return this.ll(var1, var4, var2) ? var4 : this.IlIIll(var1, var2);
      } else {
         return null;
      }
   }

   private int lIIl(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         for(int var2 = 0; var2 < lIIIll(-1275383495, 620553542); ++var2) {
            class_1799 var3 = var1.field_1724.method_31548().method_5438(var2);
            if (!var3.method_7960() && var3.method_7909() instanceof class_1743 && IllllIlI.lIl(var3)) {
               return var2;
            }
         }

         return -1;
      } else {
         return -1;
      }
   }

   private void llII(class_310 var1, long var2) {
      if (this.lIll) {
         this.lIlll(var2);
      } else if (!IllllIlI.IlIllIl(var1, this.IIlIl)) {
         if (!this.IIIIll(var1, true)) {
            if (!this.llll || this.IIlIlI(var2)) {
               this.IIlIl(var1, var2);
               this.lIlll(var2);
            }

         } else if (!this.IIIIlI(var1)) {
            if (!this.llll || this.IIlIlI(var2)) {
               this.IIlIl(var1, var2);
               this.lIlll(var2);
            }

         } else {
            if (!this.Illl(var1)) {
               if (var2 - this.IlIlI > 350L) {
                  this.IIlIl(var1, var2);
                  this.lIlll(var2);
                  return;
               }

               if (!this.lIIll(var1, this.llIl)) {
                  return;
               }
            }

            if (this.Il || this.IllII(var1)) {
               class_3966 var4 = this.llll ? this.IIlllI(var1, this.IIlIl) : this.lIII(var1, this.IIlIl);
               if (var4 == null) {
                  var4 = this.IlIIll(var1, this.IIlIl);
               }

               if (var4 == null) {
                  if (!this.llll || this.IIlIlI(var2)) {
                     this.IIlIl(var1, var2);
                     this.lIlll(var2);
                  }

               } else {
                  this.lIIl = (var1x) -> {
                     long var2 = System.currentTimeMillis();
                     if (!var1x) {
                        this.lIlll(var2);
                     } else {
                        this.lIll = true;
                        this.llII = true;
                        this.IIII = var2 + 0L;
                        this.lIlll(var2);
                     }
                  };
                  boolean var5 = this.llll ? this.IlIl(var1, var4, this.llIl) : this.lll(var1, var4);
                  if (!var5) {
                     this.lIIl = null;
                     if (!this.llll || this.IIlIlI(var2)) {
                        this.IIlIl(var1, var2);
                        this.lIlll(var2);
                     }
                  }

               }
            }
         }
      }
   }

   private class_3966 lllI(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         class_3966 var2 = IllllIlI.IlIIllI(var1, (double)3.0F);
         class_1309 var3 = IllllIlI.lIIII(var1, var2);
         if (var3 != null && this.ll(var1, var2, var3)) {
            return var2;
         } else {
            class_239 var6 = var1.field_1765;
            if (var6 instanceof class_3966) {
               class_3966 var4 = (class_3966)var6;
               class_1297 var7 = var4.method_17782();
               if (var7 instanceof class_1309) {
                  class_1309 var5 = (class_1309)var7;
                  if (this.ll(var1, var4, var5)) {
                     return var4;
                  }
               }
            }

            return null;
         }
      } else {
         return null;
      }
   }

   private boolean IIIII(class_746 var1) {
      return this.llI(var1) && (var1.method_18798().field_1351 < -0.01 || var1.field_6017 > (double)0.0F);
   }

   private int IIIIl(class_1799 var1, Object var2, boolean var3) {
      int var4 = this.llIlI(var1, var2.Il);
      int var5 = this.llIlI(var1, var2.ll);
      return var4 * lIIIll(-1275383494, -2069207550) + var5 * lIIIll(-1275383493, -1732629817) + (var3 ? 1 : 0);
   }

   private boolean IIIll(class_310 var1, int var2, boolean var3) {
      if (var1 != null && var1.field_1724 != null && var2 >= 0 && var2 < lIIIll(-1275383492, 1755889383)) {
         class_1799 var4 = var1.field_1724.method_31548().method_5438(var2);
         boolean var5 = var3 ? var4.method_7909() instanceof class_1743 && IllllIlI.lIl(var4) : var4.method_7909() instanceof class_9362;
         if (!var5) {
            return false;
         } else {
            boolean var6 = IllllIlI.IIlIl(var1) != var2;
            int var7 = var6 ? this.IlIlll(this.III) : 0;
            this.IIlI = IllllIlI.lIll(var1, this, var2, var7, true);
            return this.IIlI != null && this.IIlI.III() && IllllIlI.IIlIl(var1) == var2 && (IllllIlI.llllII() || IllllIlI.IIlIIlI(var1, var2));
         }
      } else {
         return false;
      }
   }

   private void IIlII(class_746 var1) {
      class_310 var5 = class_310.method_1551();
      if (var1 != null && var5 != null && var5.field_1687 != null) {
         if (Double.isNaN(this.lllI)) {
            this.lllI = var1.method_23318();
         }

         long var3;
         if ((var3 = var5.field_1687.method_75260()) == this.IlIIl) {
            if (!this.llI(var1)) {
               this.IIIIl = 0L;
               this.IlIII = (double)0.0F;
               this.lllI = var1.method_23318();
               this.llII = false;
            } else {
               this.lllI = Math.max(this.lllI, var1.method_23318());
               this.IlIII = Math.max(this.IlIII, this.lIIIII(var1));
               if (!this.IIIII(var1)) {
                  this.IIIIl = 0L;
               }

            }
         } else {
            this.IlIIl = var3;
            boolean var6 = this.llI(var1);
            boolean var2 = var6 && this.IIIII(var1);
            if (!var6) {
               this.IIIIl = 0L;
               this.IlIII = (double)0.0F;
               this.lllI = var1.method_23318();
               this.llII = false;
            } else {
               this.lllI = Math.max(this.lllI, var1.method_23318());
               if (!var2) {
                  this.IIIIl = 0L;
                  if (var1.method_18798().field_1351 > (double)0.0F) {
                     this.llII = false;
                     this.IlIII = (double)0.0F;
                     this.lllI = Math.max(Double.isNaN(this.lllI) ? var1.method_23318() : this.lllI, var1.method_23318());
                  } else {
                     this.IlIII = Math.max(this.IlIII, this.lIIIII(var1));
                  }

               } else {
                  if (this.IIIIl == 0L && this.llII) {
                     this.llII = false;
                     this.IlIII = (double)0.0F;
                     this.lllI = var1.method_23318();
                  }

                  ++this.IIIIl;
                  this.IlIII = Math.max(this.IlIII, this.lIIIII(var1));
               }
            }
         }
      } else {
         this.IIIlIl();
      }
   }

   private boolean IIlIl(class_310 var1, long var2) {
      if (!this.lIll && var1 != null && var1.field_1724 != null && var1.field_1761 != null && this.IIlIl != null) {
         if (!this.llI(var1.field_1724)) {
            return false;
         } else if (!this.Illl(var1)) {
            return false;
         } else {
            class_3966 var4 = this.llll ? this.IIlllI(var1, this.IIlIl) : this.lIII(var1, this.IIlIl);
            if (var4 == null) {
               var4 = this.IlIIll(var1, this.IIlIl);
            }

            if (var4 == null) {
               return false;
            } else {
               this.lIIl = (var1x) -> {
                  long var2 = System.currentTimeMillis();
                  if (!var1x) {
                     this.lIlll(var2);
                  } else {
                     this.lIll = true;
                     this.llII = true;
                     this.IIII = var2 + 0L;
                     this.lIlll(var2);
                  }
               };
               boolean var5 = this.llll ? this.IlIl(var1, var4, this.llIl) : this.lll(var1, var4);
               if (!var5) {
                  this.lIIl = null;
                  return false;
               } else {
                  return true;
               }
            }
         }
      } else {
         return false;
      }
   }

   private int IIllI(class_310 var1, Object var2, boolean var3) {
      return this.lllII(var1, var2, var3) ? this.IIIlII(var1) : this.Illll(var1, var2);
   }

   public boolean IIlll(class_1309 var1) {
      return this.lIl != null.Il && this.IIlIl != null && (var1 == null || var1 == this.IIlIl);
   }

   private boolean IlIII(class_310 var1, class_1309 var2) {
      return this.IlllIl(var1, var2) && this.IlIIl(var2);
   }

   public void lIl() {
      IllllIlI.IlII(class_310.method_1551(), this, null.Il);
      this.IIll = false;
      this.IIII = 0L;
      this.IIIlIl();
      this.IlIll();
   }

   private boolean IlIIl(class_1309 var1) {
      class_310 var2 = class_310.method_1551();
      return (Boolean)this.lll.III() && var2 != null && var2.field_1724 != null && var1 != null && this.IIIIII(var2, var1) && this.lIIl(var2) >= 0;
   }

   public void lllIl(class_310 var1) {
      if (this.IIIIIlI() && var1 != null && var1.field_1724 != null && var1.field_1690 != null) {
         this.IIlII(var1.field_1724);
         if (this.lIl != null.Il) {
            this.IllIlI(var1);
         }

         this.II = false;
      } else {
         this.II = false;
      }
   }

   public void Ill() {
      class_310 var1 = class_310.method_1551();
      if (var1 != null) {
         this.IIlII(var1.field_1724);
         if (this.lIl != null.Il) {
            this.IIllII(var1);
         }
      }

   }

   private void IlIll() {
      this.lIl = null.Il;
      this.IlIlI = 0L;
      this.I = 0L;
      this.IlIl = -1;
      this.llIl = -1;
      this.IlII = -1;
      this.IIlIl = null;
      this.llll = false;
      this.IIlII = null;
      this.lIll = false;
      this.lII = 0;
      this.ll = lIIIll(-1275383491, -1996861497);
      this.IIIlI = false;
      this.Il = false;
      this.IIlI = null;
      this.lIIl = null;
   }

   private boolean IllII(class_310 var1) {
      return var1 != null && var1.field_1724 != null && this.llIl >= 0 && this.llIl < lIIIll(-1275383490, 224069794) && IllllIlI.IIlIl(var1) == this.llIl && IllllIlI.IIlIIlI(var1, this.llIl) && var1.field_1724.method_31548().method_5438(this.llIl).method_7909() instanceof class_9362 && (!this.Il || this.llIlI(var1.field_1724.method_31548().method_5438(this.llIl), null.III.Il) > 0) && this.llllI(var1, this.llIl);
   }

   public boolean IllIl() {
      return this.lIl != null.Il;
   }

   private boolean IlllI(class_310 var1, class_243 var2, class_243 var3) {
      if (var1 != null && var1.field_1687 != null && var2 != null && var3 != null) {
         class_3965 var4 = IllllIlI.IIIlIll(var1, var1.field_1724, var2, var3);
         if (var4 != null && var4.method_17783() != class_240.field_1333) {
            return var2.method_1025(var4.method_17784()) + 1.0E-4 >= var2.method_1025(var3);
         } else {
            return true;
         }
      } else {
         return false;
      }
   }

   private int Illll(class_310 var1, Object var2) {
      if (var1 != null && var1.field_1724 != null) {
         int var3 = IllllIlI.lIIlI(var1.field_1724.method_31548());
         if (this.IIlIl != null) {
            double var4 = this.lIlIl(var1.field_1724);
            double var6 = this.IIlIl.method_45325(class_5134.field_23724);
            double var8 = this.IIlIl.method_45325(class_5134.field_23725);
            int var10 = -1;
            double var11 = Double.NEGATIVE_INFINITY;

            for(int var13 = 0; var13 < lIIIll(-1275383489, -1054640538); ++var13) {
               class_1799 var14 = var1.field_1724.method_31548().method_5438(var13);
               if (!var14.method_7960() && var14.method_7909() instanceof class_9362) {
                  double var15 = lllllI.l(var4, this.llIlI(var14, null.III.Il), this.llIlI(var14, null.I.Il), var6, var8);
                  if (var15 > var11 || Double.compare(var15, var11) == 0 && var13 == var3) {
                     var11 = var15;
                     var10 = var13;
                  }
               }
            }

            if (var10 >= 0) {
               return var10;
            }
         }

         int var17 = -1;
         int var5 = lIIIll(-1275383504, 1163489111);
         int var18 = -1;

         for(int var7 = 0; var7 < lIIIll(-1275383503, 1995032487); ++var7) {
            class_1799 var19 = var1.field_1724.method_31548().method_5438(var7);
            if (!var19.method_7960() && var19.method_7909() instanceof class_9362) {
               if (var18 < 0 || var7 == var3) {
                  var18 = var7;
               }

               int var9 = this.IIIIl(var19, var2, var7 == var3);
               if (var9 > var5) {
                  var5 = var9;
                  var17 = var7;
               }
            }
         }

         return var17 >= 0 ? var17 : var18;
      } else {
         return -1;
      }
   }

   public boolean lIIII(class_310 var1, class_1309 var2) {
      if (this.lIl == null.Il) {
         this.IIlIl = var2;
         if (this.lIIlI(var1)) {
            this.IllIlI(var1);
            return true;
         } else {
            boolean var4 = this.IlIIl(var2);
            boolean var7 = var4 ? this.IlIII(var1, var2) : this.IlllIl(var1, var2);
            if (!var7) {
               this.IIlIl = null;
               return false;
            } else if (this.lIIIIl(var1, var2) == null) {
               this.IIlIl = null;
               return false;
            } else {
               boolean var6 = this.lIIIl(var1, var2);
               if (var6) {
                  this.IIllII(var1);
                  if (!this.II) {
                     this.IllIlI(var1);
                  }
               }

               return var6;
            }
         }
      } else {
         boolean var3 = var2 != null && var2 == this.IIlIl;
         if (var3) {
            this.IllIlI(var1);
         }

         return var3;
      }
   }

   private boolean lIIIl(class_310 var1, class_1309 var2) {
      this.IIlIl = var2;
      <undefinedtype> var3 = this.IlIIIl(var1.field_1724);
      if (var3 == null) {
         this.IIlIl = null;
         return false;
      } else {
         int var4 = IllllIlI.lIIlI(var1.field_1724.method_31548());
         int var5 = this.IIllI(var1, var3, this.IlIIl(var2));
         if (var5 < 0) {
            this.IIlIl = null;
            return false;
         } else {
            boolean var6 = this.IlIIl(var2);
            int var7 = -1;
            if (var6 && (var7 = this.lIIl(var1)) < 0) {
               this.IIlIl = null;
               return false;
            } else if (this.lllII(var1, var3, var6) && !this.IIIllI(var1, var5)) {
               IllllIlI.IlII(var1, this, null.II);
               this.IIlI = null;
               this.IIlIl = null;
               return false;
            } else {
               return this.llIll(var1, var2, var5, var7, var6, var3, var4);
            }
         }
      }
   }

   private boolean lIIlI(class_310 var1) {
      return var1 != null && var1.field_1724 != null && this.lIl != null.Il && this.llII && this.llI(var1.field_1724) && System.currentTimeMillis() < this.IIII;
   }

   private boolean lIIll(class_310 var1, int var2) {
      if (var1 != null && var1.field_1724 != null && var2 >= 0 && var2 < lIIIll(-1275383502, 496096022)) {
         if (IllllIlI.IIlIl(var1) == var2 && IllllIlI.IIlIIlI(var1, var2)) {
            this.IIlI = null;
            return true;
         } else {
            if (this.IIlI == null || !this.IIlI.III() || !IllllIlI.IIII(var1, this.IIlI) || this.IIlI.ll() != var2) {
               this.IIlI = IllllIlI.lIll(var1, this, var2, 0, true);
            }

            if (IllllIlI.IlIllII(var1, this.IIlI) && IllllIlI.IIlIIlI(var1, var2)) {
               this.IIlI = null;
               return true;
            } else {
               return false;
            }
         }
      } else {
         return false;
      }
   }

   private void lIlII(class_310 var1) {
      if (this.lIII && var1 != null) {
         var1.field_1765 = this.IIlll;
      }

      this.lIII = false;
      this.IIlll = null;
      IllllIlI.IlIIlI(false);
   }

   private double lIlIl(class_746 var1) {
      return var1 == null ? (double)0.0F : lllllI.lll(this.IIlIIl(var1), var1.method_18798().field_1351);
   }

   public boolean lIllI(class_310 var1, class_1309 var2) {
      if (this.lIl != null.Il) {
         return var2 != null && var2 == this.IIlIl;
      } else {
         this.IIlIl = var2;
         if (this.lIIlI(var1)) {
            return true;
         } else {
            boolean var4 = this.IlIIl(var2);
            boolean var3 = var4 ? this.IlIII(var1, var2) : this.IlllIl(var1, var2);
            if (var3 && this.lIIIIl(var1, var2) != null) {
               <undefinedtype> var6 = this.IlIIIl(var1.field_1724);
               boolean var7 = var6 != null && this.IIllI(var1, var6, var4) >= 0 && (!var4 || this.IIlIII(var1, var2, var6));
               if (!var7) {
                  this.IIlIl = null;
               }

               return var7;
            } else {
               this.IIlIl = null;
               return false;
            }
         }
      }
   }

   private void lIlll(long var1) {
      if (this.lIl != null.III) {
         this.lIl = null.ll;
         this.IlIlI = var1;
         this.I = var1;
      }
   }

   private boolean llIII(class_310 var1) {
      return this.lIIll(var1, this.llIl);
   }

   private int llIlI(class_1799 var1, String var2) {
      class_9304 var3 = (class_9304)var1.method_58695(class_9334.field_49633, class_9304.field_49385);

      for(class_6880 var5 : var3.method_57534()) {
         String var6 = (String)var5.method_40230().map((var0) -> var0.method_29177().method_12832()).orElse(Ill[2]);
         if (var2.equals(var6)) {
            return var3.method_57536(var5);
         }
      }

      return 0;
   }

   private boolean llIll(class_310 var1, class_1309 var2, int var3, int var4, boolean var5, Object var6, int var7) {
      this.IIlIl = var2;
      this.IlIl = var4;
      this.llIl = var3;
      this.llll = var5;
      this.IIlII = var6;
      this.Il = this.lllII(var1, var6, var5);
      this.lIll = false;
      this.lII = 0;
      this.ll = lIIIll(-1275383501, 1795344729);
      this.IIIlI = false;
      this.IlII = var7;
      boolean var8 = false;
      if (var4 < 0 && !this.Il && IllllIlI.lIIlI(var1.field_1724.method_31548()) != var3) {
         var8 = true;
         this.lIIll(var1, var3);
      }

      long var9 = System.currentTimeMillis();
      this.lIl = var4 >= 0 ? null.II : null.I;
      this.IlIlI = var9;
      this.I = var9;
      return true;
   }

   private boolean lllII(class_310 var1, Object var2, boolean var3) {
      return (Boolean)this.IIIII.III() && !var3 && var2 == null.III && this.IllIIl(var1);
   }

   private boolean llllI(class_310 var1, int var2) {
      return this.IIlI == null || this.IIlI.ll() != var2 || IllllIlI.IlIllII(var1, this.IIlI);
   }

   private boolean lllll(class_310 var1, boolean var2) {
      boolean var3 = var2 && var1 != null && var1.field_1724 != null && (Boolean)this.IIl.III() && this.IlII >= 0 && this.IlII < lIIIll(-1275383500, 1542387922);
      if (!var3) {
         IllllIlI.IlII(var1, this, null.Il);
         this.IIlI = null;
         this.IIIlI = false;
         return true;
      } else {
         if (!this.IIIlI) {
            IllllIlI.IlII(var1, this, null.II);
            this.IIlI = null;
            this.IIIlI = true;
         }

         int var4 = IllllIlI.lIIlI(var1.field_1724.method_31548());
         return !IllllIlI.llIIII(this) && IllllIlI.IIlIIlI(var1, var4);
      }
   }

   private boolean IIIIII(class_310 var1, class_1309 var2) {
      if (var1 != null && var1.field_1724 != null && var2 != null && IllllIlI.lllllI(var2)) {
         class_243 var3 = new class_243(var1.field_1724.method_23317() - var2.method_23317(), var1.field_1724.method_23318() - var2.method_23318(), var1.field_1724.method_23321() - var2.method_23321());
         class_243 var4 = var2.method_5828(1.0F);
         double var5 = Math.hypot(var3.field_1352, var3.field_1350);
         if (var5 <= 1.0E-5) {
            return true;
         } else {
            return (var4.field_1352 * var3.field_1352 + var4.field_1350 * var3.field_1350) / var5 > (double)0.0F;
         }
      } else {
         return false;
      }
   }

   private boolean IIIIIl(class_746 var1) {
      this.IIlII(var1);
      if (this.IIIII(var1) && this.IIIIl >= 1L) {
         return class_9362.method_58659(var1) && Math.max((double)0.0F, var1.field_6017) >= Math.max((double)1.5F, (Double)this.lI.III());
      } else {
         return false;
      }
   }

   private boolean IIIIlI(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         <undefinedtype> var2 = this.IIlII != null ? this.IIlII : this.IlIIIl(var1.field_1724);
         if (var2 == null) {
            return false;
         } else {
            int var4 = this.Il ? this.IIIlII(var1) : this.Illll(var1, var2);
            if (var4 < 0) {
               this.llIl = -1;
               return false;
            } else {
               this.llIl = var4;
               class_1799 var5 = var1.field_1724.method_31548().method_5438(this.llIl);
               return var5.method_7909() instanceof class_9362 && (!this.Il || this.llIlI(var5, null.III.Il) > 0);
            }
         }
      } else {
         return false;
      }
   }

   public void IllI(class_310 var1) {
      if (this.IIIIIlI() && var1 != null && var1.field_1724 != null && var1.field_1690 != null) {
         this.IIlII(var1.field_1724);
         this.II = false;
         if (this.lIl != null.Il) {
            this.IIllII(var1);
            if (!this.II) {
               this.IllIlI(var1);
            }

         } else if (this.lIIlI(var1)) {
            this.IllIlI(var1);
            this.IIll = false;
         } else {
            boolean var2 = var1.field_1690.field_1886.method_1434();
            boolean var3 = var2 && !this.IIll;
            this.IIll = var2;
            if (var3 || IllllIlI.IllIlI(var1.field_1690.field_1886) > 0) {
               class_3966 var4 = this.lllI(var1);
               class_1309 var5 = IllllIlI.lIIII(var1, var4);
               this.IIlIl = var5;
               if (var5 != null && this.ll(var1, var4, var5) && this.IlllIl(var1, var5)) {
                  if (this.lIIIl(var1, var5)) {
                     this.IIllII(var1);
                     this.IllIlI(var1);
                  } else {
                     this.IIlIl = null;
                  }

               } else {
                  this.IIlIl = null;
               }
            }
         }
      } else {
         this.IIll = false;
         this.IIlII((class_746)null);
      }
   }

   private boolean IIIIll(class_310 var1, boolean var2) {
      if (this.IIIIIlI() && var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var1.field_1755 == null && this.IIlIl != null && this.IIlIl != var1.field_1724 && this.IIlIl.method_5805() && !x.IlIII.l(this.IIlIl) && !lIlIllll.lIIl(var1) && System.currentTimeMillis() >= this.IIII) {
         if (!IllllIlI.lllllI(this.IIlIl) || (Boolean)this.lll.III() && this.lIIl(var1) >= 0) {
            if (var2 && !this.llI(var1.field_1724)) {
               return false;
            } else {
               boolean var3 = !this.IllIll(var1.field_1724);
               if (!var3) {
                  this.IIlIl = null;
               }

               return var3;
            }
         } else {
            this.IIlIl = null;
            return false;
         }
      } else {
         this.IIlIl = null;
         return false;
      }
   }

   private int IIIlII(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         int var2 = IllllIlI.lIIlI(var1.field_1724.method_31548());
         if (var2 >= 0 && var2 < lIIIll(-1275383499, 436910431) && var1.field_1724.method_31548().method_5438(var2).method_7909() instanceof class_9362 && this.llIlI(var1.field_1724.method_31548().method_5438(var2), null.III.Il) > 0) {
            return var2;
         } else {
            for(int var3 = 0; var3 < lIIIll(-1275383498, -235591525); ++var3) {
               class_1799 var4 = var1.field_1724.method_31548().method_5438(var3);
               if (var4 != null && !var4.method_7960() && var4.method_7909() instanceof class_9362 && this.llIlI(var4, null.III.Il) > 0) {
                  return var3;
               }
            }

            return -1;
         }
      } else {
         return -1;
      }
   }

   private void IIIlIl() {
      this.IlIIl = Long.MIN_VALUE;
      this.IIIIl = 0L;
      this.IlIII = (double)0.0F;
      this.lllI = Double.NaN;
      this.llII = false;
   }

   private boolean IIIllI(class_310 var1, int var2) {
      if (var1 != null && var1.field_1724 != null && var2 >= 0 && var2 < lIIIll(-1275383497, 497094105)) {
         class_1799 var3 = var1.field_1724.method_31548().method_5438(var2);
         return !this.IIll(var3) ? false : this.IIIll(var1, var2, false);
      } else {
         return false;
      }
   }

   private boolean IIlIII(class_310 var1, class_1309 var2, Object var3) {
      return this.IlIIl(var2) && var3 != null && this.Illll(var1, var3) >= 0 && this.lIIl(var1) >= 0;
   }

   private double IIlIIl(class_746 var1) {
      return Math.max(this.IlIII, this.lIIIII(var1));
   }

   private boolean IIlIlI(long var1) {
      return var1 - this.IlIlI > 1500L;
   }

   private class_3966 IIlIll(class_310 var1, class_1309 var2) {
      if (var1 != null && var1.field_1724 != null && var2 != null) {
         class_239 var5 = var1.field_1765;
         class_3966 var10000;
         if (var5 instanceof class_3966) {
            class_3966 var4 = (class_3966)var5;
            var10000 = var4;
         } else {
            var10000 = null;
         }

         class_3966 var3 = var10000;
         if (!this.ll(var1, var3, var2)) {
            var3 = IllllIlI.IlIIllI(var1, (double)3.0F);
         }

         return this.ll(var1, var3, var2) ? var3 : null;
      } else {
         return null;
      }
   }

   private void IIllII(class_310 var1) {
      if (this.lIl != null.Il) {
         if (var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var1.field_1755 == null) {
            long var2 = System.currentTimeMillis();
            if (this.lIl == null.III) {
               if (var2 - this.IlIlI > 1000L) {
                  this.lIIl = null;
                  this.lIl = null.I;
                  this.lIlll(var2);
               }

            } else if (this.lIl == null.II) {
               if (var2 >= this.I) {
                  this.IlII(var1, var2);
               }

            } else if (this.lIl == null.lI) {
               if (var2 >= this.I) {
                  if (this.llll) {
                     this.IIII(var1, var2);
                     return;
                  }

                  this.llII(var1, var2);
               }

            } else if (this.lIl == null.I) {
               if (var2 >= this.I) {
                  this.llII(var1, var2);
               }

            } else {
               if (this.lIl == null.ll && var2 >= this.I && this.lllll(var1, true)) {
                  this.IlIll();
               }

            }
         } else {
            this.lllll(var1, true);
            this.IlIll();
         }
      }
   }

   private static String IIllIl(char[] var0, long var1, int var3) {
      int var4 = lIIIll(-1275383512, 799318256) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & lIIIll(-1275383511, -140913796);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   public void lI() {
      this.lllll(class_310.method_1551(), true);
      this.IIll = false;
      this.IIII = 0L;
      this.IIIlIl();
      this.IlIll();
   }

   private class_3966 IIlllI(class_310 var1, class_1309 var2) {
      class_3966 var3 = this.lIII(var1, var2);
      return var3 != null ? var3 : this.IlIIll(var1, var2);
   }

   private void IlIIII(long var1, boolean var3) {
      if (var1 == this.IllI && this.lIl == null.III) {
         Consumer var4 = this.lIIl;
         this.lIIl = null;
         this.lIl = null.I;
         if (var4 != null) {
            var4.accept(var3);
         } else {
            this.lIlll(System.currentTimeMillis());
         }

      }
   }

   private <undefinedtype> IlIIIl(class_746 var1) {
      if (var1 == null) {
         return null;
      } else if (this.lIl != null.Il && this.IIlII != null) {
         return this.IIlII;
      } else if (this.lIIIlI(var1)) {
         return null.III;
      } else {
         double var2 = this.lIlIl(var1);
         return lllllI.Il(var2, (Double)this.IIIll.III()) ? null.I : null.III;
      }
   }

   private boolean IlIIlI(class_310 var1) {
      return var1 != null && var1.field_1724 != null && this.IlIl >= 0 && this.IlIl < lIIIll(-1275383510, 1624384257) && IllllIlI.IIlIl(var1) == this.IlIl && IllllIlI.IIlIIlI(var1, this.IlIl) && var1.field_1724.method_31548().method_5438(this.IlIl).method_7909() instanceof class_1743 && IllllIlI.lIl(var1.field_1724.method_31548().method_5438(this.IlIl)) && this.llllI(var1, this.IlIl);
   }

   private class_3966 IlIIll(class_310 var1, class_1309 var2) {
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null && var2 != null) {
         class_243 var3 = var1.field_1724.method_33571();
         class_238 var4 = var2.method_5829();
         class_243 var5 = new class_243(lII(var3.field_1352, var4.field_1323, var4.field_1320), lII(var3.field_1351, var4.field_1322, var4.field_1325), lII(var3.field_1350, var4.field_1321, var4.field_1324));
         return !(var3.method_1025(var5) > 9.0001) && this.IlllI(var1, var3, var5) ? new class_3966(var2, var5) : null;
      } else {
         return null;
      }
   }

   private static void IlIllI() {
      Ill[0] = IIllIl(lIIlII(347743778, '즖', 49840).toCharArray(), 76032L, lIIIll(-1275383509, 1799407162));
      Ill[1] = IIllIl(lIIlII(-822662043, '즗', 54523).toCharArray(), 7371L, lIIIll(-1275383508, 1057038280));
      Ill[2] = IIllIl("".toCharArray(), 69747L, lIIIll(-1275383507, 2138362426));
      Ill[3] = IIllIl(lIIlII(420027271, '즔', 18612).toCharArray(), 43099L, lIIIll(-1275383506, 1675366841));
      Ill[4] = IIllIl(lIIlII(-713815791, '즕', 25192).toCharArray(), 76776L, lIIIll(-1275383505, 1459231390));
      Ill[5] = IIllIl(lIIlII(-1314695442, '즒', 15344).toCharArray(), 81051L, lIIIll(-1275383520, -1756396510));
      Ill[lIIIll(-1275383519, 653482003)] = IIllIl(lIIlII(520564697, '즓', 16607).toCharArray(), 38437L, lIIIll(-1275383518, -1903648151));
      Ill[lIIIll(-1275383517, 1215625137)] = IIllIl(lIIlII(397416817, '즐', 36446).toCharArray(), 58116L, lIIIll(-1275383516, 1757624171));
      Ill[lIIIll(-1275383515, -533315073)] = IIllIl(lIIlII(86966966, '즑', 27088).toCharArray(), 85700L, lIIIll(-1275383514, 242859041));
      Ill[lIIIll(-1275383513, 1130425548)] = IIllIl(lIIlII(815729001, '즞', 30668).toCharArray(), 81398L, lIIIll(-1275383528, -1920009320));
      Ill[lIIIll(-1275383527, 1058136543)] = IIllIl(lIIlII(215354733, '즟', 17023).toCharArray(), 40301L, lIIIll(-1275383526, 2106537080));
      Ill[lIIIll(-1275383525, 2030375464)] = IIllIl(lIIlII(-1678347218, '즜', 37153).toCharArray(), 52511L, lIIIll(-1275383524, -629114164));
      Ill[lIIIll(-1275383523, 2080901682)] = IIllIl(lIIlII(1360667787, '증', 1888).toCharArray(), 88140L, lIIIll(-1275383522, 1020253192));
   }

   private int IlIlll(llllIlIl var1) {
      return Math.max(0, (int)Math.ceil((double)this.Illlll(var1) / (double)50.0F));
   }

   private boolean IllIII(class_310 var1, class_3966 var2, int var3) {
      if (var1 != null && var1.field_1724 != null && var2 != null && var3 >= 0 && var3 < lIIIll(-1275383521, 868132722)) {
         if (!IllllIlI.IlIllIl(var1, this.IIlIl) && !IllllIlI.IlIllIl(var1, var2.method_17782())) {
            boolean var10000;
            label192: {
               label191: {
                  boolean var4 = var3 == this.IlIl && this.llll;
                  boolean var5 = this.llll && (var3 == this.IlIl || var3 == this.llIl);
                  boolean var6 = var5 ? this.IIIll(var1, var3, var4) : this.lIIll(var1, var3) && IllllIlI.IIlIIlI(var1, var3);
                  class_1799 var7 = var6 ? var1.field_1724.method_31548().method_5438(var3) : class_1799.field_8037;
                  if (!var7.method_7960()) {
                     if (var4) {
                        if (var7.method_7909() instanceof class_1743 && IllllIlI.lIl(var7)) {
                           break label191;
                        }
                     } else if (var7.method_7909() instanceof class_9362) {
                        break label191;
                     }
                  }

                  var10000 = false;
                  break label192;
               }

               var10000 = true;
            }

            boolean var8 = var10000;
            class_3966 var9 = var8 && this.ll(var1, var2, this.IIlIl) ? var2 : (var8 ? this.IIlIll(var1, this.IIlIl) : null);
            if (var9 == null) {
               return false;
            } else {
               long var10 = ++this.IllI;
               this.lIl = null.III;
               this.IlIlI = System.currentTimeMillis();
               this.I = 0L;
               this.II = true;
               boolean var12 = false;
               boolean var13 = IllllIlI.lIlIl();
               IllllIlI.IlIIlI(true);

               try {
                  IllllIlI.IlIIIll(var1);
                  var12 = IllllIlI.lIIll(var1, var9);
               } finally {
                  IllllIlI.IlIIlI(false);
                  if (var13) {
                     IllllIlI.IIlllI();
                  }

               }

               this.IlIIII(var10, var12);
               return true;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private boolean IllIIl(class_310 var1) {
      if (var1 != null && var1.field_1724 != null) {
         class_1799 var2 = var1.field_1724.method_6047();
         if (var2 != null && !var2.method_7960()) {
            String var3 = class_7923.field_41178.method_10221(var2.method_7909()).method_12832();
            return var3.endsWith(lIlIII.Il(Ill[1])) || var3.endsWith(lIlIII.Il(Ill[0]));
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public IIIIIIIIl() {
      super((Object)lIlIII.l(Ill[lIIIll(-1275383536, 971121359)]), lIllII.I, (Object)lIlIII.l(Ill[5]));
      this.lll = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(Ill[lIIIll(-1275383535, -1875087020)]), true));
      this.IIIII = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(Ill[lIIIll(-1275383534, 1495696568)]), true));
      this.III = (llllIlIl)this.IIIlIll((new llllIlIl(lIlIII.l(Ill[lIIIll(-1275383533, 766043732)]), (double)55.0F, (double)60.0F, (double)0.0F, (double)300.0F, (double)5.0F)).IIII(lIlIII.Il(Ill[lIIIll(-1275383532, -1353050554)])));
      this.lI = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(Ill[3]), (double)1.5F, (double)1.5F, (double)12.0F, (double)0.25F)).IIl(lIlIII.Il(Ill[lIIIll(-1275383531, -968371344)])));
      this.IIIll = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(Ill[lIIIll(-1275383530, 363010443)]), (double)1.5F, (double)0.0F, (double)12.0F, (double)0.25F)).IIl(lIlIII.Il(Ill[lIIIll(-1275383529, 299322672)])));
      this.IIl = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(Ill[4]), true));
      this.IlIIl = Long.MIN_VALUE;
      this.lllI = Double.NaN;
      this.lIl = null.Il;
      this.IlIl = -1;
      this.llIl = -1;
      this.IlII = -1;
      this.ll = lIIIll(-1275383544, 158805500);
   }

   private void IllIlI(class_310 var1) {
      if (var1 != null && var1.field_1690 != null && var1.field_1690.field_1886 != null) {
         IllllIlI.IIIIllI(var1.field_1690.field_1886);
         var1.field_1690.field_1886.method_23481(false);
      }
   }

   private boolean IllIll(class_746 var1) {
      if (IllllIlI.lllllI(var1)) {
         return true;
      } else if (!var1.method_6115()) {
         return false;
      } else if (var1.method_6058() == class_1268.field_5810) {
         return true;
      } else {
         class_1799 var2 = var1.method_6030();
         return var2 != null && IllllIlI.IlllII(var2);
      }
   }

   public boolean IlllII(class_310 var1, class_1309 var2) {
      if (this.lIl == null.Il) {
         this.IIlIl = var2;
         if (!this.IlIII(var1, var2)) {
            this.IIlIl = null;
            return false;
         } else {
            <undefinedtype> var3 = this.IlIIIl(var1.field_1724);
            boolean var4 = this.IIlIII(var1, var2, var3);
            if (!var4) {
               this.IIlIl = null;
            }

            return var4;
         }
      } else {
         return this.llll && var2 != null && var2 == this.IIlIl;
      }
   }

   private boolean IlllIl(class_310 var1, class_1309 var2) {
      this.IIlIl = var2;
      if (this.IIIIIlI() && var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.field_1761 != null && var1.field_1755 == null && var2 != null && var2 != var1.field_1724 && var2.method_5805() && !x.IlIII.l(var2) && !lIlIllll.lIIl(var1) && System.currentTimeMillis() >= this.IIII) {
         if (!this.IIIIIl(var1.field_1724)) {
            this.IIlIl = null;
            return false;
         } else if (!IllllIlI.lllllI(var2) || (Boolean)this.lll.III() && this.lIIl(var1) >= 0) {
            boolean var3 = !this.IllIll(var1.field_1724);
            if (!var3) {
               this.IIlIl = null;
            }

            return var3;
         } else {
            this.IIlIl = null;
            return false;
         }
      } else {
         this.IIlIl = null;
         return false;
      }
   }

   public String Il() {
      return Ill[2];
   }

   private long Illlll(llllIlIl var1) {
      double var2 = var1.IlII();
      double var4 = var1.IlI();
      return var2 == var4 ? Math.max(0L, Math.round(var2)) : Math.max(0L, Math.round(ThreadLocalRandom.current().nextDouble(var2, var4)));
   }

   private double lIIIII(class_746 var1) {
      if (var1 == null) {
         return (double)0.0F;
      } else {
         double var2 = Double.isNaN(this.lllI) ? (double)0.0F : Math.max((double)0.0F, this.lllI - var1.method_23318());
         return Math.max(var1.field_6017, var2);
      }
   }

   private class_3966 lIIIIl(class_310 var1, class_1309 var2) {
      if (var1 != null && var1.field_1724 != null && var2 != null) {
         class_3966 var3 = IllllIlI.IlIIllI(var1, (double)3.0F);
         if (this.ll(var1, var3, var2)) {
            return var3;
         } else {
            class_239 var5 = var1.field_1765;
            if (var5 instanceof class_3966) {
               class_3966 var4 = (class_3966)var5;
               if (var4.method_17782() == var2 && this.ll(var1, var4, var2)) {
                  return var4;
               }
            }

            return this.IlIIll(var1, var2);
         }
      } else {
         return null;
      }
   }

   private boolean lIIIlI(class_746 var1) {
      class_310 var2 = class_310.method_1551();
      return var1 != null && var2 != null && var2.field_1724 == var1 && (Boolean)this.IIIII.III() && (this.IIlIl == null || !this.IlIIl(this.IIlIl)) && this.IllIIl(var2) && this.IIIlII(var2) >= 0;
   }

   private static int lIIIll(int var0, int var1) {
      return IlIll[var0 ^ -1275383496] ^ var1 ^ var0;
   }

   private static String lIIlII(int var0, char var1, int var2) {
      int var3 = var1 ^ '즖';
      char[] var4 = IllII[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])IllIl[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         IllIl[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 7768;
      int var9 = 0;

      do {
         int var10 = var4[var9] - '뫆';
         var10 ^= 44345;
         var10 += 58313;
         var10 += 5471;
         var10 += 56155;
         var4[var9] = (char)(var10 ^ var8 ^ var2 ^ var0 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
