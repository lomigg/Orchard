package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public interface llllIIlI {
   long I();

   static boolean l(Enum<?> var0, String var1) {
      if (var0 != null && var1 != null) {
         if (var0 instanceof llllIIlI) {
            llllIIlI var2 = (llllIIlI)var0;
            return var2.I() == lIlIII.II(var1);
         } else {
            return var0.name().equals(var1);
         }
      } else {
         return false;
      }
   }
}
