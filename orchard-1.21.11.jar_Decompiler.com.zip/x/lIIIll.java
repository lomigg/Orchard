package x;

import java.awt.Color;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_12249;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_4588;
import net.minecraft.class_239.class_240;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;
import org.joml.Matrix4f;

@Environment(EnvType.CLIENT)
public final class lIIIll extends IIIIIIIlI {
   private static final double I = (double)3.0F;
   private static String[] l;
   private static final double II = 0.05;
   private static final int Il = 72;
   private static final int lI = 8;
   private static final int[] ll;
   private static final String[] III;
   private static final Object[] IIl;

   private Color l(Color var1, Color var2, double var3) {
      double var5 = Math.max((double)0.0F, Math.min((double)1.0F, var3));
      int var7 = (int)Math.round((double)var1.getRed() + (double)(var2.getRed() - var1.getRed()) * var5);
      int var8 = (int)Math.round((double)var1.getGreen() + (double)(var2.getGreen() - var1.getGreen()) * var5);
      int var9 = (int)Math.round((double)var1.getBlue() + (double)(var2.getBlue() - var1.getBlue()) * var5);
      return new Color(var7, var8, var9);
   }

   private static String II(char[] var0, long var1, int var3) {
      int var4 = lll(-380568079, -1673844185) ^ var3;

      for(int var5 = 0; var5 < var0.length; ++var5) {
         int var7 = var4 ^ (int)var1 ^ ~var5;
         int var8 = var7 ^ var3 - var5 * var0.length;
         var4 = -var8 * var3 | var5;
         var0[var5] = (char)(var0[var5] ^ var4);
         int var6 = var5 & lll(-380568080, 786945317);
         var3 = var3 << var6 | var3 >>> -var6;
         var1 ^= (long)var6;
      }

      return new String(var0);
   }

   private static void ll() {
      l[0] = II(IIII('ﲓ', -336710183, (short)'붺').toCharArray(), 18808L, lll(-380568077, 1310572348));
      l[1] = II(IIII('ﲒ', 1629713968, (short)13839).toCharArray(), 75353L, lll(-380568078, 1052571980));
   }

   public lIIIll() {
      super((Object)lIlIII.l(l[1]), lIllII.ll, (Object)lIlIII.l(l[0]));
   }

   public void llIl(llIIllI var1) {
      if (this.IIIIIlI() && IIlIIIIl.IlIII(var1)) {
         class_310 var2 = class_310.method_1551();
         if (var2 != null && var2.field_1687 != null && var2.field_1724 != null) {
            float var3 = IllllIlI.IlIIIlI(var2);

            for(class_1657 var5 : var2.field_1687.method_18456()) {
               if (var5 != null && var5.method_5805() && !var5.method_31481() && !var5.method_7325() && var5 != var2.field_1724) {
                  class_243 var6 = IIlIIIIl.IIIII(var5, var3);
                  class_243 var7 = this.lII(var2, var5, var6);
                  if (var7 != null) {
                     this.IlI(var1, var7);
                  }
               }
            }

         }
      }
   }

   static {
      short var6 = 22746;
      String var7 = "ᳵ幉䫩൚祦\ud963\udb12㽴ᜦ樨뤐欴䷖ٱ霤뇉Ⲑ잾\uf8be嬕\uf2f4䉞迸걼\uecfc蒥ꂦ鑪\u1c4b᠒尘耯흫ണż彸屍摷画\uf250肢끑\ue428싋ạ壄\ue786䇖躱诩ᘓ끲헲㗦ﻵⵏ䃒\uf8c8䐪䟴뇩䴵ᴕ\ue61b榃娅㰍Ẇ㖧돓᬴´優惔\ue28a閉靚㠜锧\udf20庢㜁鍤惧ဋ\uf5ee鰈닥碊\ue4a4葐邯趇誒\udbfe뱻聸慠歔筋";
      char[] var8 = "墎壊".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            III = var9;
            IIl = new Object[var9.length];
            int var2 = -2056172741;
            byte[] var0 = "\u001250wBÆc\u0011³m}6pb\u009a|ö\u0001µ\u0016\u00038\u008fÓ¸ª\u0092\u0001Ó\u00988±\u0013 P\u0016MGi\u008d\u0018FÛÖZÈ\u009bùñ;Uæ¥ûÑÅ@\r®4K°\u000eÄ\u0083ØÒ.1q\u007f]".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            ll = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               ll[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            l = new String[2];
            ll();
            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private Color III(double var1) {
      if (var1 >= (double)0.5F) {
         double var3 = (var1 - (double)0.5F) * (double)2.0F;
         return this.l(new Color(lll(-380568075, -1709178073), lll(-380568076, 1863924109), lll(-380568073, -729078567)), new Color(lll(-380568074, -1078358397), lll(-380568071, 2139219703), lll(-380568072, 560389953)), var3);
      } else {
         return this.l(new Color(lll(-380568069, 1952935401), lll(-380568070, 921251289), lll(-380568067, -1659182313)), new Color(lll(-380568068, -908433411), lll(-380568065, 741087329), lll(-380568066, 663861269)), var1 * (double)2.0F);
      }
   }

   private void IlI(llIIllI var1, class_243 var2) {
      class_243 var3 = IIlIIIIl.Il(var1);
      Matrix4f var4 = var1.lI().method_23760().method_23761();
      class_4588 var5 = IIlIIIIl.IIIlI(var1).method_73477(class_12249.method_76023());

      for(int var6 = 0; var6 < lll(-380568095, -268868356); ++var6) {
         double var7 = (double)3.0F * (double)var6 / (double)8.0F;
         double var9 = (double)3.0F * (double)(var6 + 1) / (double)8.0F;
         double var11 = (double)1.0F - (double)var6 / (double)8.0F;
         double var13 = (double)1.0F - (double)(var6 + 1) / (double)8.0F;
         Color var15 = this.III(var11);
         Color var16 = this.III(var13);
         float var17 = (float)var15.getRed() / 255.0F;
         float var18 = (float)var15.getGreen() / 255.0F;
         float var19 = (float)var15.getBlue() / 255.0F;
         float var20 = (float)(((double)24.0F + var11 * (double)126.0F) / (double)255.0F);
         float var21 = (float)var16.getRed() / 255.0F;
         float var22 = (float)var16.getGreen() / 255.0F;
         float var23 = (float)var16.getBlue() / 255.0F;
         float var24 = (float)(((double)24.0F + var13 * (double)126.0F) / (double)255.0F);

         for(int var25 = 0; var25 < lll(-380568096, 1565575630); ++var25) {
            class_243 var26 = this.llI(var2, var9, var25);
            class_243 var27 = this.llI(var2, var9, var25 + 1);
            if (var6 == 0) {
               Color var28 = this.III((double)1.0F);
               float var29 = (float)var28.getRed() / 255.0F;
               float var30 = (float)var28.getGreen() / 255.0F;
               float var31 = (float)var28.getBlue() / 255.0F;
               float var32 = 0.5882353F;
               var5.method_22918(var4, (float)(var2.field_1352 - var3.field_1352), (float)(var2.field_1351 - var3.field_1351), (float)(var2.field_1350 - var3.field_1350)).method_22915(var29, var30, var31, var32);
               var5.method_22918(var4, (float)(var26.field_1352 - var3.field_1352), (float)(var26.field_1351 - var3.field_1351), (float)(var26.field_1350 - var3.field_1350)).method_22915(var21, var22, var23, var24);
               var5.method_22918(var4, (float)(var27.field_1352 - var3.field_1352), (float)(var27.field_1351 - var3.field_1351), (float)(var27.field_1350 - var3.field_1350)).method_22915(var21, var22, var23, var24);
               var5.method_22918(var4, (float)(var2.field_1352 - var3.field_1352), (float)(var2.field_1351 - var3.field_1351), (float)(var2.field_1350 - var3.field_1350)).method_22915(var29, var30, var31, var32);
            } else {
               class_243 var33 = this.llI(var2, var7, var25);
               class_243 var34 = this.llI(var2, var7, var25 + 1);
               var5.method_22918(var4, (float)(var33.field_1352 - var3.field_1352), (float)(var33.field_1351 - var3.field_1351), (float)(var33.field_1350 - var3.field_1350)).method_22915(var17, var18, var19, var20);
               var5.method_22918(var4, (float)(var26.field_1352 - var3.field_1352), (float)(var26.field_1351 - var3.field_1351), (float)(var26.field_1350 - var3.field_1350)).method_22915(var21, var22, var23, var24);
               var5.method_22918(var4, (float)(var27.field_1352 - var3.field_1352), (float)(var27.field_1351 - var3.field_1351), (float)(var27.field_1350 - var3.field_1350)).method_22915(var21, var22, var23, var24);
               var5.method_22918(var4, (float)(var33.field_1352 - var3.field_1352), (float)(var33.field_1351 - var3.field_1351), (float)(var33.field_1350 - var3.field_1350)).method_22915(var17, var18, var19, var20);
               var5.method_22918(var4, (float)(var33.field_1352 - var3.field_1352), (float)(var33.field_1351 - var3.field_1351), (float)(var33.field_1350 - var3.field_1350)).method_22915(var17, var18, var19, var20);
               var5.method_22918(var4, (float)(var27.field_1352 - var3.field_1352), (float)(var27.field_1351 - var3.field_1351), (float)(var27.field_1350 - var3.field_1350)).method_22915(var21, var22, var23, var24);
               var5.method_22918(var4, (float)(var34.field_1352 - var3.field_1352), (float)(var34.field_1351 - var3.field_1351), (float)(var34.field_1350 - var3.field_1350)).method_22915(var17, var18, var19, var20);
               var5.method_22918(var4, (float)(var33.field_1352 - var3.field_1352), (float)(var33.field_1351 - var3.field_1351), (float)(var33.field_1350 - var3.field_1350)).method_22915(var17, var18, var19, var20);
            }
         }
      }

   }

   private class_243 lII(class_310 var1, class_1657 var2, class_243 var3) {
      class_243 var4 = var3.method_1031((double)0.0F, (double)1.0F, (double)0.0F);
      class_243 var5 = new class_243(var3.field_1352, (double)var1.field_1687.method_31607() - (double)1.0F, var3.field_1350);
      class_3965 var6 = var1.field_1687.method_17742(new class_3959(var4, var5, class_3960.field_17558, class_242.field_1348, var2));
      if (var6 != null && var6.method_17783() == class_240.field_1332) {
         class_243 var7 = var6.method_17784();
         return new class_243(var3.field_1352, var7.field_1351 + 0.05, var3.field_1350);
      } else {
         return null;
      }
   }

   private class_243 llI(class_243 var1, double var2, int var4) {
      double var5 = (Math.PI * 2D) * (double)var4 / (double)72.0F;
      return var1.method_1031(Math.cos(var5) * var2, (double)0.0F, Math.sin(var5) * var2);
   }

   private static int lll(int var0, int var1) {
      return ll[var0 ^ -380568079] ^ var1 ^ var0;
   }

   private static String IIII(char var0, int var1, short var2) {
      int var3 = var0 ^ 'ﲓ';
      char[] var4 = III[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])IIl[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         IIl[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 32018;
      int var9 = 0;

      do {
         int var10 = var4[var9] ^ '逮';
         var10 -= 45664;
         var10 += 59953;
         var10 -= 36608;
         var10 -= 37277;
         var10 -= 52647;
         var4[var9] = (char)(var10 ^ var8 ^ var2 ^ var1 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
