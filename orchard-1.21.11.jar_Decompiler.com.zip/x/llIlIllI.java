package x;

import java.awt.Color;
import java.util.Objects;
import java.util.Set;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10264;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2604;
import net.minecraft.class_2663;
import net.minecraft.class_2684;
import net.minecraft.class_2709;
import net.minecraft.class_2716;
import net.minecraft.class_2743;
import net.minecraft.class_2777;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_8038;
import net.minecraft.class_8143;
import y.lllllll;

@Environment(EnvType.CLIENT)
public final class llIlIllI extends IIIIIIIlI implements IllIl {
   private static final int I = 20;
   private long l;
   private static final int II = 26;
   private final IlIIIlIlI<<undefinedtype>> Il;
   private final IIIllIIII lI;
   private static final double ll = (double)2.0F;
   private final IlIIIlIlI<<undefinedtype>> III;
   private static final double IIl = 0.18;
   private volatile class_1297 IlI;
   private static final long Ill = 1000L;
   private final lIIIIl lII;
   private static final int lIl = 10;
   private final IIIllIIII llI;
   private final IIIllIIII lll;
   private volatile class_243 IIII;
   private static final double IIIl = (double)64.0F;
   private static final double IIlI = (double)2.0F;
   private static final double IIll = (double)16.0F;
   private double IlII;
   private static final double IlIl = (double)4.0F;
   private static final long IllI = 100L;
   private static final double Illl = (double)8.0F;
   private static final long lIII = 10000L;
   private long lIIl;
   private int lIlI;
   private final IIIllIIII lIll;
   private static final long llII = 10000L;
   private long llIl;
   private long lllI;
   private long llll;
   private final lIIIIl IIIII;
   private final IIIllIIII IIIIl;
   private static final double IIIlI = (double)8.0F;
   private volatile boolean IIIll;
   private static final double IIlII = (double)6.0F;
   private class_243 IIlIl;
   private long IIllI;
   private double IIlll;
   private static final double IlIII = (double)3.0F;
   private final IIIllIIII IlIIl;
   private final lIIIIl IlIlI;
   private long IlIll;
   private final lIIIIl IllII;
   private static final double IllIl = 0.32;
   private static final float IlllI = 2.4F;
   private static final double Illll = (Math.PI * 2D);
   private final lIIIIl lIIII;
   private static final int[] lIIIl;
   private static final String[] lIIlI;
   private static final Object[] lIIll;

   public boolean II(class_1297 var1) {
      return var1 != null && var1 == this.IlI && this.lIIIl();
   }

   static boolean ll(class_2596<?> var0, int var1) {
      return IIIIlI(var0, var1, -1, 0L);
   }

   static class_243 IlI(class_243 var0, class_243 var1, Set<class_2709> var2) {
      if (var1 == null) {
         return var0;
      } else {
         return var0 != null && var2 != null && !var2.isEmpty() ? new class_243(var2.contains(class_2709.field_12400) ? var0.field_1352 + var1.field_1352 : var1.field_1352, var2.contains(class_2709.field_12398) ? var0.field_1351 + var1.field_1351 : var1.field_1351, var2.contains(class_2709.field_12403) ? var0.field_1350 + var1.field_1350 : var1.field_1350) : var1;
      }
   }

   public llIlIllI() {
      super((Object)lIlIII.l(IIIlIl('讓', '벤', -243655705)), lIllII.I, (Object)lIlIII.l(IIIlIl('讒', 'ⲿ', -816707039)));
      this.Il = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IIIlIl('讑', 'ᙹ', 727672073)), <undefinedtype>.class, null.I));
      this.III = (IlIIIlIlI)this.IIIlIll(new IlIIIlIlI(lIlIII.l(IIIlIl('讐', 'ዣ', 439898948)), <undefinedtype>.class, null.Il));
      this.IlIIl = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IIIlIl('讗', '衑', 705302449)), (double)3.0F, (double)2.0F, (double)4.0F, 0.1)).IIIl(lIlIII.l(IIIlIl('讖', '巍', -1355271524))));
      this.IllII = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIIlIl('讕', '懳', 1155428311)), true));
      this.lI = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IIIlIl('讔', 'ᯖ', -1840172430)), (double)8.0F, (double)2.0F, (double)16.0F, 0.1)).IIIl(lIlIII.l(IIIlIl('讛', '組', -1194363716))));
      this.IlIlI = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIIlIl('讚', '\uec7e', -480503216)), true));
      this.lll = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IIIlIl('讙', '̠', -1075750849)), (double)1000.0F, (double)1000.0F, (double)10000.0F, (double)50.0F)).IIIl(lIlIII.l(IIIlIl('讘', '玲', -1631234795))));
      this.IIIII = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIIlIl('讟', '㐙', -1456713212)), false));
      this.lIll = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IIIlIl('讞', '勵', 1607403660)), (double)1000.0F, (double)0.0F, (double)10000.0F, (double)50.0F)).IIIl(lIlIII.l(IIIlIl('讝', '쿚', 610365863))));
      this.lIIII = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIIlIl('讜', '胔', -1984560685)), true));
      this.lII = (lIIIIl)this.IIIlIll(new lIIIIl(lIlIII.l(IIIlIl('讃', 'ﰺ', 215705014)), true));
      this.IIIIl = (IIIllIIII)this.IIIlIll((new IIIllIIII(lIlIII.l(IIIlIl('讂', '漈', 784227387)), (double)9.0F, (double)5.0F, (double)16.0F, (double)1.0F)).IIIl(lIlIII.l(IIIlIl('讁', 'ꈅ', -1294322636))));
      this.llI = (IIIllIIII)this.IIIlIll(new IIIllIIII(lIlIII.l(IIIlIl('讀', '窇', -1798150316)), (double)215.0F, (double)80.0F, (double)255.0F, (double)5.0F));
      this.lIlI = -1;
      this.IlIIl.lIII(() -> this.III.III() == null.II);
      this.IllII.lIII(() -> this.Il.III() == null.ll);
      this.lI.lIII(() -> this.Il.III() == null.ll && (Boolean)this.IllII.III());
      this.IlIlI.lIII(() -> this.Il.III() == null.ll);
      IIIllIIII var10000 = this.lIll;
      lIIIIl var10001 = this.IIIII;
      Objects.requireNonNull(var10001);
      var10000.lIII(var10001::III);
      var10000 = this.IIIIl;
      var10001 = this.lII;
      Objects.requireNonNull(var10001);
      var10000.lIII(var10001::III);
      var10000 = this.llI;
      var10001 = this.lII;
      Objects.requireNonNull(var10001);
      var10000.lIII(var10001::III);
   }

   private static class_243 lII(class_1297 var0) {
      if (var0 == null) {
         return null;
      } else {
         class_243 var1 = var0.method_43389().method_60933();
         return var1 != null ? var1 : var0.method_73189();
      }
   }

   static double llI(Object var0, boolean var1, double var2) {
      if (var0 == null.lI) {
         return (double)6.0F;
      } else if (var0 == null.l) {
         return (double)8.0F;
      } else {
         return var0 == null.ll && var1 ? Math.max((double)2.0F, Math.min((double)16.0F, var2)) : Double.POSITIVE_INFINITY;
      }
   }

   public void lIlI(class_1297 var1) {
      class_310 var2 = class_310.method_1551();
      if (this.IlIl(var2) && !this.IIll(var2)) {
         if (this.III.III() == null.Il) {
            if (var1 instanceof class_1657 && var1 != var2.field_1724) {
               if (this.lIIll(var2, var1) && this.llIll()) {
                  if (this.lIlI < 0 || var1.method_5628() == this.lIlI) {
                     long var3 = System.currentTimeMillis();
                     this.IIllI = var3;
                     if (!this.IIIll && this.IIIII(var3)) {
                        this.Illl(var1, var3);
                        this.llllI();
                     }

                  }
               }
            }
         }
      }
   }

   private boolean lll() {
      return this.Il.III() == null.l || this.Il.III() == null.ll && (Boolean)this.IlIlI.III();
   }

   public void lIl() {
      this.llll = 0L;
      this.lIIl = 0L;
      this.IIIll = false;
      this.IlI = null;
      this.IIII = null;
      this.IIlIl = null;
      this.llIl = 0L;
      this.l = 0L;
      this.IlIll = 0L;
      this.llllI();
      IIIIIlIll.IIl();
      x.IllII.IlIll().Illl(false);
   }

   public void IIIlI(class_332 var1, int var2, int var3, float var4) {
      class_310 var5 = class_310.method_1551();
      if ((Boolean)this.lII.III() && var1 != null && var5 != null && var5.field_1724 != null && !var5.field_1690.field_1842 && this.IIlII(var5, System.currentTimeMillis()) && System.currentTimeMillis() - this.l <= 100L) {
         this.IlIIl(var1, this.IIlll, this.IlII);
      }
   }

   private boolean IIII(class_310 var1, class_1297 var2, double var3) {
      return this.llIII(var1, var2) && lIlllII.lIll(var1.field_1724.method_5858(var2), var3);
   }

   private boolean IIll(class_310 var1) {
      return (Boolean)this.lIIII.III() && var1 != null && var1.field_1724 != null && (var1.field_1724.method_5799() || var1.field_1724.method_5869());
   }

   private void IlII() {
      if (!this.IIIll) {
         IIIIIlIll.IIl();
         this.IIlIl = null;
         this.llIl = 0L;
         this.l = 0L;
      } else {
         IllII var1 = x.IllII.IlIll();
         IIIIIlIll.lIIllI();
         IIIIIlIll.IIl();
         var1.IIIlI(false);
         var1.IlII();
         IIIIIlIll.IIllllI();
         IIIIIlIll.IIIlIlI();
         this.IIIll = false;
         this.llll = 0L;
         this.lIIl = (Boolean)this.IIIII.III() ? System.currentTimeMillis() + this.llII() : 0L;
         this.IlI = null;
         this.IIII = null;
         this.IIlIl = null;
         this.llIl = 0L;
         this.l = 0L;
      }
   }

   private boolean IlIl(class_310 var1) {
      return this.IIIIIlI() && var1 != null && var1.field_1724 != null && var1.field_1687 != null && var1.method_1562() != null;
   }

   private void Illl(class_1297 var1, long var2) {
      if (!this.IIIll(var1)) {
         IllII var4 = x.IllII.IlIll();
         var4.lIlI(false, true);
         var4.IlI(false);
         var4.IIlI(true, null.II, 0);
         this.llll = var2 + this.Illll();
         this.IlI = var1;
         this.IIII = lII(var1);
         this.IIlIl = this.IIII;
         this.llIl = 0L;
         this.IIIll = true;
         IIIIIlIll.IllIlI(this::IIIIII, this::lIIl);
         var4.IIIlI(true);
      }
   }

   public void lIIl(class_2596<?> var1) {
      if (this.IIIll && this.IlI != null && var1 != null) {
         if (var1 instanceof class_8038) {
            class_8038 var9 = (class_8038)var1;

            for(class_2596 var11 : var9.method_48324()) {
               this.lIIl(var11);
               if (!this.IIIll) {
                  break;
               }
            }

         } else if (llIlI(var1, this.IlI)) {
            this.llllI();
            this.lIIII();
         } else {
            int var2 = this.IlI.method_5628();
            class_310 var3 = class_310.method_1551();
            int var4 = var3 != null && var3.field_1724 != null ? var3.field_1724.method_5628() : -1;
            if (this.lll() && var4 >= 0 && IIIIlI(var1, var4, var2, this.IIllI)) {
               this.IIlIl(var2);
            } else if (!x.IllII.lII(var1.getClass().getName()) && !IlIll(var1, var2)) {
               if (this.IIII == null) {
                  this.IIII = lII(this.IlI);
               }

               if (var1 instanceof class_10264) {
                  class_10264 var5 = (class_10264)var1;
                  if (var5.comp_3223() == var2) {
                     class_243 var8 = var5.comp_3224() != null ? var5.comp_3224().comp_3148() : null;
                     if (var8 != null) {
                        this.IIII = var8;
                     }
                  }
               } else if (var1 instanceof class_2777) {
                  class_2777 var6 = (class_2777)var1;
                  if (var6.comp_3237() == var2) {
                     class_243 var12 = var6.comp_3238() != null ? IlI(this.IIII, var6.comp_3238().comp_3148(), var6.comp_3239()) : null;
                     if (var12 != null) {
                        this.IIII = var12;
                     }
                  }
               } else if (var1 instanceof class_2684) {
                  class_2684 var7 = (class_2684)var1;
                  if (((lllllll)var7).ilovcats$getId() == var2) {
                     this.IIII = lIlIl(this.IIII, (long)var7.method_36150(), (long)var7.method_36151(), (long)var7.method_36152());
                  }
               }

               this.lllII();
            } else {
               this.lIIII();
            }
         }
      }
   }

   private class_238 lIll() {
      class_1297 var1 = this.IlI;
      class_243 var2 = this.IIII;
      return var1 != null && var2 != null ? var1.method_18377(var1.method_18376()).method_30757(var2) : null;
   }

   private long llII() {
      return Math.max(0L, Math.min(10000L, Math.round((Double)this.lIll.III())));
   }

   public void llIl(llIIllI var1) {
      class_310 var2 = class_310.method_1551();
      if ((Boolean)this.lII.III() && var1 != null && this.IIlII(var2, System.currentTimeMillis())) {
         if (!this.llIII(var2, this.IlI)) {
            this.l = 0L;
         } else {
            class_238 var3 = this.IlIII();
            if (var3 != null) {
               this.lIIlI(var1, var3);
            }

            <undefinedtype> var4 = IIlIIIIl.llII(var1, this.IllII(this.IlI.method_5829()));
            if (var4 == null) {
               this.l = 0L;
            } else {
               this.IIlll = var4.II();
               this.IlII = var4.l();
               this.l = System.currentTimeMillis();
            }
         }
      } else {
         this.l = 0L;
      }
   }

   static boolean lllI(long var0, long var2, boolean var4) {
      return !var4 || var0 >= var2;
   }

   private boolean IIIII(long var1) {
      return lllI(var1, this.lIIl, (Boolean)this.IIIII.III());
   }

   static class_243 IIIIl(class_243 var0, class_243 var1, double var2) {
      if (var1 == null) {
         return null;
      } else {
         return var0 != null && !(var0.method_1025(var1) > (double)64.0F) ? var0.method_35590(var1, Math.max((double)0.0F, Math.min((double)1.0F, var2))) : var1;
      }
   }

   private boolean IIIll(class_1297 var1) {
      boolean var10000;
      if (var1 instanceof class_1657 var2) {
         if (var2.method_6128()) {
            var10000 = true;
            return var10000;
         }
      }

      var10000 = false;
      return var10000;
   }

   private boolean IIlII(class_310 var1, long var2) {
      return this.IIIll && var2 < this.llll && this.IlI != null && x.IllII.IlIll().IlIlI() && x.IllII.IlIll().lll() && this.llIII(var1, this.IlI);
   }

   private void IIlIl(int var1) {
      int var2 = IIIIll((<undefinedtype>)this.III.III());
      this.IlII();
      x.IllII.IlIll().Illl(false);
      this.lIlI = var1;
      this.lllI = this.IlIll + (long)var2;
   }

   private boolean IIllI() {
      return Double.isFinite(this.IIIIIl());
   }

   private class_1657 IIlll(class_310 var1, double var2) {
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null) {
         double var4 = this.IIllI() ? Math.min(var2, this.IIIIIl()) : var2;
         double var6 = var4 * var4;
         class_1657 var8 = null;
         double var9 = var6;

         for(class_1657 var12 : var1.field_1687.method_18456()) {
            if (var12 != var1.field_1724 && this.llIII(var1, var12) && !var12.method_7325() && !this.IIIll(var12) && !x.IlIII.I(var12)) {
               double var13 = var1.field_1724.method_5858(var12);
               if (var13 <= var9) {
                  var8 = var12;
                  var9 = var13;
               }
            }
         }

         return var8;
      } else {
         return null;
      }
   }

   private class_238 IlIII() {
      class_1297 var1 = this.IlI;
      class_243 var2 = this.IIII;
      if (var1 != null && var2 != null) {
         long var3 = System.nanoTime();
         long var5 = this.llIl;
         this.llIl = var3;
         double var7 = var5 == 0L ? 0.016666666666666666 : Math.max((double)0.0F, (double)(var3 - var5) / (double)1.0E9F);
         double var9 = IIIIlI.ll(0.32, var7);
         this.IIlIl = IIIIl(this.IIlIl, var2, var9);
         return var1.method_18377(var1.method_18376()).method_30757(this.IIlIl);
      } else {
         return null;
      }
   }

   private void IlIIl(class_332 var1, double var2, double var4) {
      double var6 = (Double)this.IIIIl.III();
      double var8 = Math.max(1.6, var6 * 0.22);
      double var10 = (double)System.nanoTime() / (double)1.0E9F * (Math.PI * 2D) * 1.35;
      int var12 = Math.max(0, Math.min(IIIlII(965761979, 1317101611), (int)Math.round((Double)this.llI.III())));
      int var13 = lllIIlI.III().getRGB();

      for(int var14 = 0; var14 < IIIlII(965761978, 924406952); ++var14) {
         double var15 = (double)var14 / (double)26.0F;
         double var17 = (double)(var14 + 1) / (double)26.0F;
         double var19 = var10 + var15 * Math.PI;
         double var21 = var10 + var17 * Math.PI;
         double var23 = 0.35 + 0.65 * var17;
         int var25 = Math.max(IIIlII(965761977, 1387340336), Math.min(IIIlII(965761976, 1993701339), (int)Math.round((double)var12 * var23)));
         int var26 = IIIlllIII.lI(var13, var25);
         double var27 = var2 + Math.cos(var19) * var6;
         double var29 = var4 + Math.sin(var19) * var6;
         double var31 = var2 + Math.cos(var21) * var6;
         double var33 = var4 + Math.sin(var21) * var6;
         IIIIIIllI.IlIlI(var1, var27, var29, var31, var33, var8, var26);
         if (var14 == 0 || var14 == IIIlII(965761983, 1718653690)) {
            IIIIIIllI.lIIII(var1, var14 == 0 ? var27 : var31, var14 == 0 ? var29 : var33, var8 * (double)0.5F, var26);
         }
      }

   }

   static boolean IlIll(class_2596<?> var0, int var1) {
      boolean var10000;
      if (var0 instanceof class_2604 var2) {
         if (var2.method_11169() == class_1299.field_6133 && var2.method_11166() == var1) {
            var10000 = true;
            return var10000;
         }
      }

      var10000 = false;
      return var10000;
   }

   private class_243 IllII(class_238 var1) {
      return new class_243((var1.field_1323 + var1.field_1320) * (double)0.5F, (var1.field_1322 + var1.field_1325) * (double)0.5F, (var1.field_1321 + var1.field_1324) * (double)0.5F);
   }

   static boolean IlllI(class_243 var0, class_238 var1, double var2) {
      if (var0 != null && var1 != null) {
         double var4 = Math.max(var1.field_1323, Math.min(var0.field_1352, var1.field_1320));
         double var6 = Math.max(var1.field_1322, Math.min(var0.field_1351, var1.field_1325));
         double var8 = Math.max(var1.field_1321, Math.min(var0.field_1350, var1.field_1324));
         double var10 = var0.field_1352 - var4;
         double var12 = var0.field_1351 - var6;
         double var14 = var0.field_1350 - var8;
         double var16 = Math.max((double)0.0F, var2);
         return var10 * var10 + var12 * var12 + var14 * var14 > var16 * var16;
      } else {
         return false;
      }
   }

   private long Illll() {
      return Math.max(1000L, Math.min(10000L, Math.round((Double)this.lll.III())));
   }

   private void lIIII() {
      this.IlII();
      x.IllII.IlIll().Illl(false);
   }

   public boolean lIIIl() {
      return this.IIIll && x.IllII.IlIll().IlIlI() && x.IllII.IlIll().lll();
   }

   private void lIIlI(llIIllI var1, class_238 var2) {
      Color var3 = lllIIlI.III();
      double var4 = Math.max((double)0.0F, Math.min((double)255.0F, (Double)this.llI.III()));
      IIlIIIIl.IIll(var1, var2, var3, var4 * 0.18);
      IIlIIIIl.I(var1, var2, var3, var4, 2.4F);
   }

   private boolean lIIll(class_310 var1, class_1297 var2) {
      return this.IIllI() ? this.IIII(var1, var2, this.IIIIIl()) : this.llIII(var1, var2);
   }

   static class_243 lIlIl(class_243 var0, long var1, long var3, long var5) {
      return var0 == null ? null : new class_243(var0.field_1352 + (double)var1 / (double)4096.0F, var0.field_1351 + (double)var3 / (double)4096.0F, var0.field_1350 + (double)var5 / (double)4096.0F);
   }

   private class_1657 lIllI(class_310 var1) {
      if (this.lIlI >= 0 && var1 != null && var1.field_1687 != null) {
         class_1297 var2 = var1.field_1687.method_8469(this.lIlI);
         if (var2 instanceof class_1657) {
            class_1657 var3 = (class_1657)var2;
            if (var3 != var1.field_1724 && !var3.method_7325() && !this.IIIll(var3) && !x.IlIII.I(var3) && this.lIIll(var1, var3)) {
               return var3;
            }
         }

         return null;
      } else {
         return null;
      }
   }

   private void lIlll(class_310 var1) {
      if (this.III.III() == null.II && !this.IIll(var1) && this.llIll() && this.IIIII(System.currentTimeMillis())) {
         class_1657 var2 = this.lIllI(var1);
         if (var2 == null) {
            this.lIlI = -1;
            var2 = this.IIlll(var1, (Double)this.IlIIl.III());
         }

         if (var2 != null) {
            this.Illl(var2, System.currentTimeMillis());
            this.llllI();
         }

      }
   }

   private boolean llIII(class_310 var1, class_1297 var2) {
      return var1 != null && var1.field_1724 != null && var1.field_1687 != null && var2 != null && var2.method_5805() && !var2.method_31481() && var1.field_1687.method_8469(var2.method_5628()) == var2;
   }

   static boolean llIlI(class_2596<?> var0, class_1297 var1) {
      if (var0 != null && var1 != null) {
         if (var0 instanceof class_2716) {
            class_2716 var4 = (class_2716)var0;
            return var4.method_36548().contains(var1.method_5628());
         } else {
            if (var0 instanceof class_2663) {
               class_2663 var2 = (class_2663)var0;
               if (var2.method_11470() == 3) {
                  class_310 var3 = class_310.method_1551();
                  return var3 != null && var3.field_1687 != null && var2.method_11469(var3.field_1687) == var1;
               }
            }

            return false;
         }
      } else {
         return false;
      }
   }

   public void Ill() {
      ++this.IlIll;
      class_310 var1 = class_310.method_1551();
      if (!this.IlIl(var1)) {
         this.IlII();
         x.IllII.IlIll().Illl(false);
      } else {
         if (!this.lll()) {
            this.llllI();
         }

         if (!this.IIIll) {
            this.lIlll(var1);
         } else {
            IllII var2 = x.IllII.IlIll();
            if (var2.IIlll() && var2.IlIlI()) {
               long var3 = System.currentTimeMillis();
               boolean var5 = this.IIllI() && IlllI(var1.field_1724.method_33571(), this.lIll(), this.IIIIIl());
               boolean var6 = !this.llIII(var1, this.IlI);
               if (this.IIIll(this.IlI) || var5 || this.IIll(var1) || var6 || var3 >= this.llll) {
                  this.IlII();
                  x.IllII.IlIll().Illl(false);
               }

            } else {
               this.IlII();
               var2.Illl(false);
            }
         }
      }
   }

   private boolean llIll() {
      return this.IlIll >= this.lllI;
   }

   private void lllII() {
      if (this.IIIll && this.IIllI()) {
         class_310 var1 = class_310.method_1551();
         if (var1 != null && var1.field_1724 != null && IlllI(var1.field_1724.method_33571(), this.lIll(), this.IIIIIl() + 0.35)) {
            this.lIIII();
         }
      }
   }

   public String Il() {
      return ((<undefinedtype>)this.Il.III()).toString();
   }

   public void lI() {
      this.IlII();
      this.llllI();
      x.IllII.IlIll().Illl(false);
   }

   private void llllI() {
      this.lllI = 0L;
      this.lIlI = -1;
   }

   public boolean lllll(class_310 var1, class_1297 var2) {
      if (this.IIIIIlI() && this.IIIll) {
         if (var2 != null && this.IlI != null && var2.method_5628() != this.IlI.method_5628()) {
            this.IlII();
            x.IllII.IlIll().Illl(false);
            return true;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public boolean IIIIII(class_2596<?> var1) {
      class_1297 var2 = this.IlI;
      if (this.IIIll && var2 != null && var1 != null) {
         if (var1 instanceof class_8038) {
            class_8038 var6 = (class_8038)var1;

            for(class_2596 var5 : var6.method_48324()) {
               if (this.IIIIII(var5)) {
                  return true;
               }
            }

            return false;
         } else {
            int var3 = var2.method_5628();
            if (!llIlI(var1, var2) && !x.IllII.lII(var1.getClass().getName()) && !IlIll(var1, var3)) {
               if (var1 instanceof class_10264) {
                  class_10264 var8 = (class_10264)var1;
                  return var8.comp_3223() == var3;
               } else if (var1 instanceof class_2777) {
                  class_2777 var7 = (class_2777)var1;
                  return var7.comp_3237() == var3;
               } else if (var1 instanceof class_2684) {
                  class_2684 var4 = (class_2684)var1;
                  return ((lllllll)var4).ilovcats$getId() == var3;
               } else {
                  return false;
               }
            } else {
               return true;
            }
         }
      } else {
         return false;
      }
   }

   private double IIIIIl() {
      return llI((<undefinedtype>)this.Il.III(), (Boolean)this.IllII.III(), (Double)this.lI.III());
   }

   static boolean IIIIlI(class_2596<?> var0, int var1, int var2, long var3) {
      if (var0 != null && var1 >= 0) {
         if (var0 instanceof class_8143) {
            class_8143 var19 = (class_8143)var0;
            if (var19.comp_1267() != var1) {
               return false;
            } else if (var2 >= 0) {
               return var19.comp_1269() == var2 || var19.comp_1270() == var2;
            } else {
               return var19.comp_1269() >= 0 && var19.comp_1269() != var1;
            }
         } else if (var0 instanceof class_2743) {
            class_2743 var5 = (class_2743)var0;
            if (var5.method_11818() != var1) {
               return false;
            } else {
               long var6 = System.currentTimeMillis();
               if (var6 - var3 < 400L) {
                  return false;
               } else {
                  class_243 var8 = var5.method_73085();
                  if (var8 == null) {
                     return false;
                  } else {
                     double var9 = var8.field_1352;
                     double var11 = var8.field_1351;
                     double var13 = var8.field_1350;
                     double var15 = var9 * var9 + var13 * var13;
                     double var17 = var15 + var11 * var11;
                     return var11 >= 0.1 || var15 >= 0.0484 || var17 >= (double)0.0625F;
                  }
               }
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   static int IIIIll(Object var0) {
      return var0 == null.II ? IIIlII(965761982, 1321539224) : IIIlII(965761981, 198086256);
   }

   private static int IIIlII(int var0, int var1) {
      return lIIIl[var0 ^ 965761979] ^ var1 ^ var0;
   }

   static {
      short var6 = 13266;
      String var7 = "㥟㦬㦶㧸㦶㧴㦦㥈㦢㦡㦘㧽㥂㥇㧸㦭Ὀᾷᾧὔὀᾤ\u1f4e\u1fb5ᾢὟᾢὑᾥᾧᾷ\u1fb5\u1f5eᾧᾭῳᾎῺ\u1f5cᾌᾣᾌᾨ῾ᾯᾯὕ῾ΏὂῸᾡ\u1fb5ᾯᾬᾡὗὍᾆ\u1fffΏᾄὒᾼ\u1f5eὅ\u1ff1ᾢ\u1f58ᾁᾣᾼΏὅ\u1f46ᾧᾏ\u1f4eῴ\u1fffΏὛᾯὔΌᾯᾯᾮ\u1f58ὟᾏᾷὑὛῬὛὟῬ\u1fffᾤᾎὍᾃᾌᾤᾌᾕᾯᾨ\u1f46Ὓ῾ῲὂ\u1f5eῴᾣ\u1f58\u1f58ᾐ⠊⡤⠊⡷⢳⡷⧃⧃쉞싹슯쉂슷싲슚싴싱쉁싴싺쉁스싦싦\udcde\udf7a\udf71\udcce\udf29\udf2b\udf79\udf74\udf7e\udcdb\udf7f\udf7b\udf2c\udcd3\udf1e\udf7b\udcc8\udcd5\udf7a\udf66\uec48\uec4a\uef38\uef38〄」っゴ　〕。ふゾ〕のの〞㇈つ㇐䗫䖍䖉䐲䖌䖜䗫䖐䖏䖟䗪䗬釦醔醶醶塚難見響視者拓響響者華謁礼ﯗ逸難﨑\ufbc3羽勇華ﯗ况並뚷뛳뙇뙈뙟뙐뙀뛤ᧃ᧞ᠬᢲ䠀䧀䢹䠗䠎䡷䧜䠔䡧䢽䡤䡸낅끅난낊낃냪냹낑낚댸냤나냪낑낇냽\ue797\ue79a\ue788\ue746에쐗쐌엛쑿쐫엉쐢쑹엂쐩쐩엙쐗쐫쐏\uea4a\ueaa3\uea49\ueab0\ueafd\ueaab\uea49\ueab6\ueaab\uea5b\uea5e\ueaa7㶅㶔㶆㷧㶂㷼㶆㶙㷼㷌㷡㷰㷥㷭㰾㷧㷰㶊㶟㷳쪶쩖쩘쪚ᬦ\u1b7fᬥᣜᬡᣇᬥ᭺ᣇᣗᣂᣋᣆᣁᣗᣏᣉᣙᣉ᭽ᬤᬢᣐᬘ";
      char[] var8 = "㏂㎺㏚㏂㏆㏖㏂㏞㏖㏊㏚㏖㏞㏂㏖㏂㏞㏆㏖㏊".toCharArray();
      String[] var9 = new String[var8.length];
      byte var13 = -1;

      while(true) {
         int var10 = 0;
         int var11 = 0;
         int var12 = 0;
         if (var13 == 0) {
            lIIlI = var9;
            lIIll = new Object[var9.length];
            int var2 = 963623455;
            byte[] var0 = "N~\u0081p7æµ\u0017RNÃ\u0082v*\u0096\u0083f\u008fsCN:÷-\u000b1oØ".getBytes("ISO-8859-1");
            int var1 = var0.length / 4;
            lIIIl = new int[var1];
            int var3 = 0;
            int var4 = 0;

            do {
               int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
               var5 ^= var2;
               lIIIl[var4] = var5;
               var3 += 4;
               ++var4;
            } while(var4 < var1);

            return;
         }

         do {
            var12 = var8[var10] ^ var6;
            var9[var10] = var7.substring(var11, var11 + var12);
            var11 += var12;
            ++var10;
         } while(var10 < var8.length);

         var13 = 0;
      }
   }

   private static String IIIlIl(char var0, char var1, int var2) {
      int var3 = var0 ^ '讓';
      char[] var4 = lIIlI[var3].toCharArray();
      StackTraceElement[] var5 = (StackTraceElement[])lIIll[var3];
      StackTraceElement[] var6;
      if (var5 != null) {
         var6 = var5;
      } else {
         var6 = (new Throwable()).getStackTrace();
         lIIll[var3] = var6;
      }

      StackTraceElement var7 = var6[1];
      int var8 = (var7.getClassName().hashCode() ^ var7.getMethodName().hashCode()) >> 16 ^ 18837;
      int var9 = 0;

      do {
         int var10 = var4[var9] ^ '餬';
         var10 += 32005;
         var10 -= 50342;
         var10 ^= 20532;
         var10 -= 25547;
         var4[var9] = (char)(var10 ^ var8 ^ var1 ^ var2 >> 16);
         ++var9;
      } while(var9 < var4.length);

      return (new String(var4)).intern();
   }
}
