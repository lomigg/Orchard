package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_315;

@Environment(EnvType.CLIENT)
public final class IlIIII extends IIIIIIIlI {
   private long I;
   private long l;
   private long II;
   private boolean Il;
   private long lI;
   private boolean ll;
   private boolean III;
   private boolean IIl;
   private static final String[] IlI;
   private static final Object[] Ill;

   public void lIl() {
      this.IIl = false;
      this.III = false;
      this.Il = false;
      this.ll = false;
      this.II = 0L;
      this.l = 0L;
      this.lI = 0L;
      this.I = 0L;
   }

   private static boolean ll(boolean var0, boolean var1, long var2, long var4, boolean var6) {
      if (var0 && var1) {
         boolean var7 = var2 > var4;
         return var6 ? var7 : !var7;
      } else {
         return var6 ? var0 : var1;
      }
   }

   private void IlI(class_310 var1, class_304 var2, boolean var3, boolean var4, class_304 var5, boolean var6, boolean var7) {
      lllI var8 = lllI.lll();
      if (var8 != null) {
         if (var3 && var6) {
            var8.IlI(this, var1, var2, var4);
            var8.IlI(this, var1, var5, var7);
         } else {
            var8.IIIl(this, var1, var2);
            var8.IIIl(this, var1, var5);
         }

      }
   }

   public void lllIl(class_310 var1) {
      if (var1 != null && var1.field_1724 != null && var1.field_1690 != null && var1.field_1755 == null) {
         lIllIIl var2 = lIllIIl.Il();
         if (var2 == null || var2.IIl() == null || var2.IIl().IlIIlI() == null || !var2.IIl().IlIIlI().lIII()) {
            class_315 var3 = var1.field_1690;
            boolean var4 = IllllIlI.IIIll(var1, var3.field_1913);
            boolean var5 = IllllIlI.IIIll(var1, var3.field_1849);
            boolean var6 = IllllIlI.IIIll(var1, var3.field_1894);
            boolean var7 = IllllIlI.IIIll(var1, var3.field_1881);
            long var8 = System.currentTimeMillis();
            if (var4 && !this.IIl) {
               this.II = var8;
            }

            if (var5 && !this.III) {
               this.l = var8;
            }

            if (var6 && !this.Il) {
               this.lI = var8;
            }

            if (var7 && !this.ll) {
               this.I = var8;
            }

            this.IIl = var4;
            this.III = var5;
            this.Il = var6;
            this.ll = var7;
            boolean var10 = ll(var4, var5, this.II, this.l, true);
            boolean var11 = ll(var4, var5, this.II, this.l, false);
            boolean var12 = ll(var7, var6, this.I, this.lI, false);
            boolean var13 = ll(var7, var6, this.I, this.lI, true);
            this.IlI(var1, var3.field_1913, var4, var10, var3.field_1849, var5, var11);
            this.IlI(var1, var3.field_1894, var6, var12, var3.field_1881, var7, var13);
            var3.field_1913.method_23481(var10);
            var3.field_1849.method_23481(var11);
            var3.field_1894.method_23481(var12);
            var3.field_1881.method_23481(var13);
         }
      }
   }

   public void lI() {
      class_310 var1 = class_310.method_1551();
      if (var1 != null && var1.field_1690 != null) {
         lllI var2 = lllI.lll();
         if (var2 != null) {
            var2.IIl(this, var1);
         }

         class_315 var3 = var1.field_1690;
         var3.field_1913.method_23481(IllllIlI.IIIll(var1, var3.field_1913));
         var3.field_1849.method_23481(IllllIlI.IIIll(var1, var3.field_1849));
         var3.field_1894.method_23481(IllllIlI.IIIll(var1, var3.field_1894));
         var3.field_1881.method_23481(IllllIlI.IIIll(var1, var3.field_1881));
      }
   }

   public IlIIII() {
      super((Object)lIlIII.l(lII(2026162116, -1703451117)), lIllII.III, (Object)lIlIII.l(lII(2026162117, -1613620682)));
   }

   static {
      short var0 = 15846;
      String var1 = "खহ৶६\u09baঠঊফग॓ীऩಶ\u0c73\u0c75\u0cf9ఘగ\u0c71ఁ\u0cbbೀడ\u0cf9\u0c64ನౙಔ\u0cba೩ಏೈಹఐ\u0c5eಔౖ\u0cdcಝಖ\u0cf0ౢృచಙణౕ೫ొఱఅఏ\u0ca9ಳఔಸౙಉిಡ\u0cd2ಫಱಗತంౄ\u0cbaఁಂ\u0cf0\u0ca9೨\u0c65౫ెಉ\u0c54ఞ\u0cdbఙఌయ\u0c70ತೣఱ಼ఉೇ\u0c53ಶ\u0cfaಕಯ\u0ccfಙజఀತ\u0c52\u0cd0\u0cd8\u0cb4";
      char[] var2 = "\f\\".toCharArray();
      String[] var3 = new String[var2.length];
      byte var7 = -1;

      while(true) {
         int var4 = 0;
         int var5 = 0;
         char var6 = '\u0000';
         if (var7 == 0) {
            IlI = var3;
            Ill = new Object[var3.length];
            return;
         }

         do {
            var6 = var2[var4];
            char[] var8 = var1.substring(var5, var5 + var6).toCharArray();
            int var9 = 0;

            do {
               byte var10000;
               switch (var9 % 5) {
                  case 0:
                  default:
                     var10000 = 8;
                     break;
                  case 1:
                     var10000 = 65;
                     break;
                  case 2:
                     var10000 = 61;
                     break;
                  case 3:
                     var10000 = 44;
                     break;
                  case 4:
                     var10000 = 42;
               }

               byte var10 = var10000;
               var8[var9] = (char)(var8[var9] ^ var10 ^ var0);
               ++var9;
            } while(var9 < var8.length);

            var3[var4] = (new String(var8)).intern();
            var5 += var6;
            ++var4;
         } while(var4 < var2.length);

         var7 = 0;
      }
   }

   private static String lII(int var0, int var1) {
      int var3 = var0 ^ 2026162116;
      char[] var4 = IlI[var3].toCharArray();
      StackTraceElement[] var2 = (StackTraceElement[])Ill[var3];
      StackTraceElement[] var5;
      if (var2 != null) {
         var5 = var2;
      } else {
         var5 = (new Throwable()).getStackTrace();
         Ill[var3] = var5;
      }

      StackTraceElement var6 = var5[1];
      int var7 = (var6.getClassName().hashCode() ^ var6.getMethodName().hashCode()) >> 16 ^ -1667729435;
      int var8 = 0;

      do {
         short var9;
         switch (var8 & 31) {
            case 0:
            default:
               var9 = 212;
               break;
            case 1:
               var9 = 118;
               break;
            case 2:
               var9 = 0;
               break;
            case 3:
               var9 = 173;
               break;
            case 4:
               var9 = 65;
               break;
            case 5:
               var9 = 80;
               break;
            case 6:
               var9 = 65;
               break;
            case 7:
               var9 = 122;
               break;
            case 8:
               var9 = 209;
               break;
            case 9:
               var9 = 131;
               break;
            case 10:
               var9 = 78;
               break;
            case 11:
               var9 = 238;
               break;
            case 12:
               var9 = 5;
               break;
            case 13:
               var9 = 174;
               break;
            case 14:
               var9 = 21;
               break;
            case 15:
               var9 = 211;
               break;
            case 16:
               var9 = 164;
               break;
            case 17:
               var9 = 174;
               break;
            case 18:
               var9 = 238;
               break;
            case 19:
               var9 = 153;
               break;
            case 20:
               var9 = 196;
               break;
            case 21:
               var9 = 122;
               break;
            case 22:
               var9 = 24;
               break;
            case 23:
               var9 = 229;
               break;
            case 24:
               var9 = 55;
               break;
            case 25:
               var9 = 144;
               break;
            case 26:
               var9 = 135;
               break;
            case 27:
               var9 = 214;
               break;
            case 28:
               var9 = 149;
               break;
            case 29:
               var9 = 3;
               break;
            case 30:
               var9 = 7;
               break;
            case 31:
               var9 = 38;
         }

         var4[var8] = (char)(var4[var8] ^ var9 ^ var1 >> 16 ^ var7);
         ++var8;
      } while(var8 < var4.length);

      return (new String(var4)).intern();
   }
}
