package x;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_243;

@Environment(EnvType.CLIENT)
record llIIII(class_243 point, float yaw, float pitch, float yawDelta, float pitchDelta, float rawYawDelta, float rawPitchDelta) {
   private final float I;
   private final float l;
   private final float II;
   private final float Il;
   private final class_243 lI;
   private final float ll;
   private final float III;

   public class_243 I() {
      return this.lI;
   }

   private llIIII(class_243 var1, float var2, float var3, float var4, float var5, float var6, float var7) {
      this.lI = var1;
      this.II = var2;
      this.ll = var3;
      this.III = var4;
      this.l = var5;
      this.I = var6;
      this.Il = var7;
   }

   public float l() {
      return this.I;
   }

   public float II() {
      return this.II;
   }

   public float Il() {
      return this.Il;
   }

   public float lI() {
      return this.ll;
   }

   public float ll() {
      return this.III;
   }

   public float III() {
      return this.l;
   }
}
