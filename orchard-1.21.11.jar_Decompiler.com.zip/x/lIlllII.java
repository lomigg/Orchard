package x;

import java.util.Arrays;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_3966;
import net.minecraft.class_640;

@Environment(EnvType.CLIENT)
public final class lIlllII {
   private double I;
   private class_1309 l;
   private final <undefinedtype> II = (<undefinedtype>)(new Object() {
      private int I;
      private int l;
      private double II;
      private boolean Il;
      private static final int lI = 12;
      private double ll;
      private int III;
      private final int[] IIl = new int[III(378537891, 1331651641)];
      private static final int[] IlI;

      private double I() {
         return this.Il ? this.II : (double)this.III;
      }

      private void l(int var1) {
         if (var1 > 0) {
            this.III = var1;
            this.IIl[this.l] = var1;
            this.l = (this.l + 1) % III(378537889, -1259635846);
            if (this.I < III(378537888, -881516511)) {
               ++this.I;
            }

            if (!this.Il) {
               this.II = (double)var1;
               this.ll = (double)var1 / (double)2.0F;
               this.Il = true;
            } else {
               this.ll = (double)0.75F * this.ll + (double)0.25F * Math.abs(this.II - (double)var1);
               this.II = (double)0.875F * this.II + (double)0.125F * (double)var1;
            }
         }
      }

      private double II(double var1) {
         if (this.I <= 0) {
            return this.I();
         } else {
            double var3 = Math.max((double)0.0F, Math.min((double)1.0F, var1));
            int[] var5 = new int[this.I];
            System.arraycopy(this.IIl, 0, var5, 0, this.I);
            Arrays.sort(var5);
            int var6 = Math.max(0, Math.min(var5.length - 1, (int)Math.round((double)(var5.length - 1) * var3)));
            return (double)var5[var6];
         }
      }

      private void Il() {
         this.II = (double)0.0F;
         this.ll = (double)0.0F;
         this.III = 0;
         this.Il = false;
         this.I = 0;
         this.l = 0;
      }

      private int lI() {
         return this.III;
      }

      private double ll() {
         return this.Il ? this.ll : (double)0.0F;
      }

      private static int III(int var0, int var1) {
         return IlI[var0 ^ 378537889] ^ var1 ^ var0;
      }

      static {
         int var2 = -1849582157;
         byte[] var0 = "3ºádL$º>È\u000eþ%".getBytes("ISO-8859-1");
         int var1 = var0.length / 4;
         IlI = new int[var1];
         int var3 = 0;
         int var4 = 0;

         do {
            int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
            var5 ^= var2;
            IlI[var4] = var5;
            var3 += 4;
            ++var4;
         } while(var4 < var1);

      }
   });
   private double Il;
   private static final double lI = (double)0.25F;
   private long ll;
   private static final double III = (double)0.125F;
   private double IIl;
   private long IlI;
   private double Ill;
   private double lII;
   private boolean lIl;
   private class_1309 llI;
   private final <undefinedtype> lll = (<undefinedtype>)(new Object() {
      private int I;
      private int l;
      private double II;
      private boolean Il;
      private static final int lI = 12;
      private double ll;
      private int III;
      private final int[] IIl = new int[III(378537891, 1331651641)];
      private static final int[] IlI;

      private double I() {
         return this.Il ? this.II : (double)this.III;
      }

      private void l(int var1) {
         if (var1 > 0) {
            this.III = var1;
            this.IIl[this.l] = var1;
            this.l = (this.l + 1) % III(378537889, -1259635846);
            if (this.I < III(378537888, -881516511)) {
               ++this.I;
            }

            if (!this.Il) {
               this.II = (double)var1;
               this.ll = (double)var1 / (double)2.0F;
               this.Il = true;
            } else {
               this.ll = (double)0.75F * this.ll + (double)0.25F * Math.abs(this.II - (double)var1);
               this.II = (double)0.875F * this.II + (double)0.125F * (double)var1;
            }
         }
      }

      private double II(double var1) {
         if (this.I <= 0) {
            return this.I();
         } else {
            double var3 = Math.max((double)0.0F, Math.min((double)1.0F, var1));
            int[] var5 = new int[this.I];
            System.arraycopy(this.IIl, 0, var5, 0, this.I);
            Arrays.sort(var5);
            int var6 = Math.max(0, Math.min(var5.length - 1, (int)Math.round((double)(var5.length - 1) * var3)));
            return (double)var5[var6];
         }
      }

      private void Il() {
         this.II = (double)0.0F;
         this.ll = (double)0.0F;
         this.III = 0;
         this.Il = false;
         this.I = 0;
         this.l = 0;
      }

      private int lI() {
         return this.III;
      }

      private double ll() {
         return this.Il ? this.ll : (double)0.0F;
      }

      private static int III(int var0, int var1) {
         return IlI[var0 ^ 378537889] ^ var1 ^ var0;
      }

      static {
         int var2 = -1849582157;
         byte[] var0 = "3ºádL$º>È\u000eþ%".getBytes("ISO-8859-1");
         int var1 = var0.length / 4;
         IlI = new int[var1];
         int var3 = 0;
         int var4 = 0;

         do {
            int var5 = (var0[var3] & 255) << 24 | (var0[var3 + 1] & 255) << 16 | (var0[var3 + 2] & 255) << 8 | var0[var3 + 3] & 255;
            var5 ^= var2;
            IlI[var4] = var5;
            var3 += 4;
            ++var4;
         } while(var4 < var1);

      }
   });

   public long I(long var1) {
      return this.ll <= 0L ? Long.MAX_VALUE : Math.max(0L, var1 - this.ll);
   }

   public double l() {
      return this.lll.ll();
   }

   public double II() {
      return this.lIIl() * 0.7 + this.lll() * (double)0.25F + this.llIl() * 1.6 + this.l() * 0.7;
   }

   private void Il(class_1309 var1) {
      if (this.llI != var1) {
         this.llI = var1;
         this.lIl = false;
         this.IIl = (double)0.0F;
         this.Il = (double)0.0F;
         this.lII = (double)0.0F;
         this.II.Il();
      }

      this.IlI = System.currentTimeMillis();
   }

   public double lI(double var1) {
      return this.II.II(var1);
   }

   private void ll() {
      this.llI = null;
      this.IlI = 0L;
      this.IIl = (double)0.0F;
      this.Il = (double)0.0F;
      this.lII = (double)0.0F;
      this.lIl = false;
      this.II.Il();
   }

   public int III(class_310 var1) {
      int var2 = this.lll.lI();
      return var2 > 0 ? var2 : this.Illl(var1, var1.field_1724);
   }

   private void IIl(class_310 var1) {
      if (var1.field_1724 != null && this.llI != null) {
         double var2 = (double)var1.field_1724.method_5739(this.llI);
         if (this.lIl) {
            this.Il = this.IIl - var2;
         } else {
            this.Il = (double)0.0F;
         }

         this.IIl = var2;
         double var4 = this.llI.method_23317() - this.Ill;
         double var6 = this.llI.method_23321() - this.I;
         this.lII = this.lIl ? Math.sqrt(var4 * var4 + var6 * var6) : (double)0.0F;
         this.Ill = this.llI.method_23317();
         this.I = this.llI.method_23321();
         this.lIl = true;
      }
   }

   public double IlI() {
      return this.Il;
   }

   public class_1309 Ill() {
      return this.l;
   }

   private boolean lII(class_310 var1, class_1309 var2) {
      return var2 == null || !var2.method_5805() || var2.method_31481() || IlIII.l(var2) || var1.field_1724.method_5739(var2) > 16.0F;
   }

   public void lIl(class_310 var1) {
      if (var1.field_1724 != null && var1.field_1687 != null) {
         this.lll.l(this.Illl(var1, var1.field_1724));
         if (this.llI != null && this.lII(var1, this.llI)) {
            this.ll();
         }

         if (this.l != null && this.lIlI(this.l)) {
            this.l = null;
            this.ll = 0L;
         }

         class_239 var3 = var1.field_1765;
         if (var3 instanceof class_3966) {
            class_3966 var2 = (class_3966)var3;
            class_1297 var5 = var2.method_17782();
            if (var5 instanceof class_1309) {
               class_1309 var4 = (class_1309)var5;
               if (var5 != var1.field_1724 && !IlIII.l(var4)) {
                  this.Il(var4);
               }
            }
         }

         if (this.llI != null && System.currentTimeMillis() - this.IlI > 2500L) {
            this.ll();
         } else {
            if (this.llI != null) {
               this.II.l(this.Illl(var1, this.llI));
               this.IIl(var1);
            }

         }
      } else {
         this.ll();
      }
   }

   public double llI() {
      return this.lIIl() + this.llIl() * 1.35;
   }

   public double lll() {
      return this.lll.I();
   }

   public double IIII() {
      return this.IIl;
   }

   public double IIIl() {
      return this.lII;
   }

   public long IIlI() {
      return this.ll;
   }

   public double IIll(double var1) {
      return this.lll.II(var1);
   }

   public boolean IlII(class_310 var1, double var2) {
      if (var1 != null && var1.field_1724 != null && var1.field_1687 != null && this.llI != null) {
         if (this.llI.method_5805() && !this.llI.method_31481()) {
            return var1.field_1687.method_8469(this.llI.method_5628()) != this.llI ? false : lIll(var1.field_1724.method_5858(this.llI), var2);
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public void IlIl() {
      this.ll();
      this.l = null;
      this.ll = 0L;
      this.lll.Il();
   }

   public void IllI(class_1297 var1) {
      if (var1 instanceof class_1309 var2) {
         if (!IlIII.l(var2)) {
            this.Il(var2);
            this.l = var2;
            this.ll = System.currentTimeMillis();
         }
      }

   }

   private int Illl(class_310 var1, class_1297 var2) {
      if (var2 instanceof class_1657 var3) {
         if (var1.method_1562() != null) {
            class_640 var4 = var1.method_1562().method_2871(var3.method_5667());
            return var4 == null ? 0 : var4.method_2959();
         }
      }

      return 0;
   }

   public int lIII(class_310 var1) {
      int var2 = this.II.lI();
      return var2 > 0 ? var2 : this.Illl(var1, this.llI);
   }

   public double lIIl() {
      return this.II.I();
   }

   private boolean lIlI(class_1309 var1) {
      return var1 == null || !var1.method_5805() || var1.method_31481() || IlIII.l(var1);
   }

   public static boolean lIll(double var0, double var2) {
      double var4 = Math.max((double)0.0F, var2);
      return var0 >= (double)0.0F && var0 <= var4 * var4;
   }

   public class_1309 llII() {
      return this.llI;
   }

   public double llIl() {
      return this.II.ll();
   }
}
